sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"./model/models",
	"./controller/ListSelector",
	"./controller/ErrorHandler",
	"sap/ui/model/json/JSONModel",
], function (UIComponent, Device, models, ListSelector, ErrorHandler, JSONModel) {
	"use strict";

	return UIComponent.extend("zdwo_nx_drss_ven.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * In this method, the device models are set and the router is initialized.
		 * @public
		 * @override
		 */
		init: function () {

			this.oListSelector = new ListSelector();
			this._oErrorHandler = new ErrorHandler(this);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			this.setModel(models.createAppView(), "appView");

			// call the base component's init function and create the App view
			UIComponent.prototype.init.apply(this, arguments);

			// Global Model to read the OC Details in Job Logging View
			this.setModel(models.createDeviceModel(), "itemsModel");
			this.setModel(models.createDeviceModel(), "oWSModel");

			var oJoblogFormsObject = {
				Tvd: false,
				Sos: false,
				Operations: false,
				NonCharge: false
			}
			var JoblogFormsModel = new JSONModel(oJoblogFormsObject);
			this.setModel(JoblogFormsModel, "JoblogFormsModel");

			var oDisputeVisibilityObject = {
				DisputeVisibility: false,
			}
			var DisputeVisibilityModel = new JSONModel(oDisputeVisibilityObject);
			this.setModel(DisputeVisibilityModel, "DisputeVisibilityModel");

			var JobTypeModel = new JSONModel();
			this.setModel(JobTypeModel, "JobTypeeTicketModel");

			// create the views based on the url/hash
			this.getRouter().initialize();
			if (this.getModel("VendorService").oMetadata.bFailed) {
				this.getRouter().navTo("notFound", {}, true);
			}

			this.getUserInfo();
		},

		/**
		 * The component is destroyed by UI5 automatically.
		 * In this method, the ListSelector and ErrorHandler are destroyed.
		 * @public
		 * @override
		 */
		destroy: function () {
			this.oListSelector.destroy();
			this._oErrorHandler.destroy();
			// call the base component's destroy function
			UIComponent.prototype.destroy.apply(this, arguments);
		},

		getUserInfo: function () {
		
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();

			var oData = {
				Active: "X",
				DrillCountR: "17",
				DrillCountS: "31",
				DrillEx: "X",
				ELearning: "http://dwotd.aramco.com.sa/website/dwo-integrated-logistics-invoice-processing-platform-dilip/index.html",
				Edrss: "",
				EticFollUp: "",
				EticketGen: "",
				FullAcc: "",
				HaulingVend: "",
				InbCount: "280",
				JobLog: "",
				MorningReport: "https://dp4.aramco.com.sa/irj/servlet/prt/portal/prtroot/pcd!3a!2f!2fportal_content!2fcom.sap.portal.migrated!2fep_5.0!2ftemplat",
				NotifCount: "722",
				PriceVisible: "true",
				SalesFin: "",
				TaxiVendor: "",
				UserProHide: "true",
				VenUserId: "T_CBAD_SOAX",
				Vendor: "10102102",
				VendorName: "Schlumberger - B2C"
			};
			oData.InbCount = parseInt(oData.InbCount, 0);
			oData.NotifCount = parseInt(oData.NotifCount, 0);
			this.setModel(new JSONModel(oData), "UserInfoModel");
			//console.log(oData);
			busyDialog.close();

			// var oModel = this.getModel("VendorService");
			// oModel.read("/VenTileCountSet('T_CBAD_SOAX')", { 
			// 	success: function(oData) {
			// 		oData.InbCount = parseInt(oData.InbCount, 0);
			// 		oData.NotifCount = parseInt(oData.NotifCount, 0);
			// 		//this.getView().setModel(new JSONModel(oData), "UserInfoModel");
			// 		this.setModel(new JSONModel(oData), "UserInfoModel");
			// 		//console.log(oData);
			// 		busyDialog.close();
			// 	}.bind(this),
			// 	error: function(oResponse) {					
			// 		var msg = this.getErrorMessages(oResponse)[0].message;
			// 		//sap.m.MessageBox.error(msg);
			// 		sap.m.MessageToast.show(msg);

			// 		sap.m.MessageBox.warning(msg, {
			// 			actions: [sap.m.MessageBox.Action.OK],
			// 			emphasizedAction: sap.m.MessageBox.Action.OK,
			// 			onClose: function (sAction) {
			// 				this.getRouter().navTo("notFound", {}, true);
			// 			}.bind(this)
			// 		});				
			// 		busyDialog.close();
			// 	}.bind(this)
			// });
		},

		getErrorMessages: function (oResponse) {
			var messageList = [];
			//error in xml format
			if (oResponse.hasOwnProperty("responseRaw")) {
				var start = oResponse.responseRaw.indexOf("<errordetail>") + 13;
				var end = oResponse.responseRaw.indexOf("</errordetail>");
				var message = oResponse.responseRaw.substring(start, end);
				start = message.indexOf("<message>") + 9;
				end = message.indexOf("</message>");
				message = message.substring(start, end)
				message = message.replace(new RegExp("&" + "#" + "39;", "g"), "'");
				var msg = {
					severity: "Error",
					message: message,
					description: message
				};
				var messageList = [];
				messageList.push(msg);
			} else if (oResponse.responseText.indexOf("<error") > -1) {
				var start = oResponse.responseText.indexOf("<code>") + 6;
				var end = oResponse.responseText.indexOf("</code>");
				var message = oResponse.responseText.substring(start, end)
				message = message.replace(new RegExp("&" + "#" + "39;", "g"), "'");
				var msg = {
					severity: "Error",
					message: message,
					description: message
				};
				var messageList = [];
				messageList.push(msg);
			}
			//error in json format
			else {
				if (oResponse.responseText.indexOf("error") > -1) {
					var error = JSON.parse(oResponse.responseText).error;
					if (error.hasOwnProperty("innererror")) {
						var innererror = error.innererror;
						if (innererror.hasOwnProperty("errordetails") && innererror.errordetails.length > 0) {
							var errordetails = innererror.errordetails;
							for (var i = 0; i < errordetails.length; i++) {
								var errorItem = errordetails[i];
								errorItem.severity = errorItem.severity.charAt(0).toUpperCase() + errorItem.severity.substr(1);
								if (errorItem.code !== "/IWBEP/CX_MGW_BUSI_EXCEPTION" && errorItem.severity.length > 0) {
									messageList.push(errorItem);
								}
							}
						} else {
							if (error.hasOwnProperty("message")) {
								var message = error.message;
								if (message.hasOwnProperty("value")) {
									var msg = {
										severity: "Error",
										message: message.value,
										description: message.value
									};
									messageList.push(msg);
								}
							}
						}
					}
				} else if (error.hasOwnProperty("message")) {
					var message = JSON.parse(oResponse.responseText).error.message;
					var messageList = [];
					var msg = {
						severity: "Error",
						message: message,
						description: message
					};
					messageList.push(msg);
				}
			}
			return messageList;
		},

		/**
		 * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
		 * design mode class should be set, which influences the size appearance of some controls.
		 * @public
		 * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
		 */
		getContentDensityClass: function () {
			if (this._sContentDensityClass === undefined) {
				// check whether FLP has already set the content density class; do nothing in this case
				// eslint-disable-next-line sap-no-proprietary-browser-api
				if (document.body.classList.contains("sapUiSizeCozy") || document.body.classList.contains("sapUiSizeCompact")) {
					this._sContentDensityClass = "";
				} else if (!Device.support.touch) { // apply "compact" mode if touch is not supported
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					// "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		}

	});
});