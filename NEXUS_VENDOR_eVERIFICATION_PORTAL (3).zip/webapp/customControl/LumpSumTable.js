var oLSController;
sap.ui.define([
	"sap/ui/core/Control",
	"sap/ui/core/format/DateFormat"
], function(Control, DateFormat) {
	"use strict";
	return Control.extend("zdwo_nx_drss_ven.customControl.LumpSumTable", {
		metadata: {
			properties: {
				oTableData: {
					type: "array",
					defaultValue: []
				},
				columns: {
					type: "array",
					defaultValue: []
				},
				rows: {
					type: "array",
					defaultValue: []
				},
				idKeyName: {
					type: "string",
					defaultValue: ""
				},
				groupingKeyName: {
					type: "string",
					defaultValue: ""
				},
				startDateKeyName: {
					type: "string",
					defaultValue: ""
				},
				endDateKeyName: {
					type: "string",
					defaultValue: ""
				},
				serviceKeyName: {
					type: "string",
					defaultValue: ""
				},
				valueKeyName: {
					type: "string",
					defaultValue: ""
				},
				displayColumns: {
					type: "array",
					defaultValue: ""
				},
				newLumpSumData: {
					type: "array",
					defaultValue: ""
				},
				newLumpSumColumns: {
					type: "array",
					defaultValue: ""
				},
				iGrandTotalAmount: {
					type: "string",
					defaultValue: ""
				},
				
				ExportExcelHtmlTable: {
					type: "string",
					defaultValue: ""
				}
			}
		},
		init: function() {
			debugger;

			oLSController = this;
		},
		generateTableColumnsArray: function(oTableData) {
			var aUniqueDates = [];
			var oDateFormat = DateFormat.getDateInstance({
				format: "yyyyMMdd"
			});
			var oMonthFormat = DateFormat.getDateInstance({
				format: "MMMdd"
			});
			oTableData.sort((a, b) => {
				return a.startDate - b.startDate;
			});
			oTableData.forEach(e => {
				var sStartDate = oDateFormat.format(e.startDate);
				var sEndDate = oDateFormat.format(e.endDate);
				var sMonth = oMonthFormat.format(e.startDate);
				if (sStartDate !== sEndDate) { // lump sum
					var iDifferenceBetweenDays = e.endDate - e.startDate;
					iDifferenceBetweenDays = Math.ceil(iDifferenceBetweenDays / (1000 * 3600 * 24));
					for (var i = 0; i <= iDifferenceBetweenDays; i++) {
						var oNewDate = new Date(e.startDate);
						oNewDate.setDate(oNewDate.getDate() + i);
						var oCurrentDate = i > 0 ? oNewDate : e.startDate;
						var sMonth = oMonthFormat.format(oCurrentDate);
						var sUniqueDate = aUniqueDates.find(x => x === `${sMonth}`);
						if (!sUniqueDate) {
							aUniqueDates.push(`${sMonth}`);
						};
					}
				} else { // non lump sum
					var sUniqueDate = aUniqueDates.find(x => x === sMonth);
					if (sUniqueDate === undefined) { //!sUniqueDate
						aUniqueDates.push(sMonth);
					}
				}
			});


			this.setProperty("newLumpSumColumns", aUniqueDates)
			return aUniqueDates;
		},
		//		buildTableModel: function(oTableData) {
		//
		//			var oDateFormat = DateFormat.getDateInstance({
		//				format: "yyyyMMdd"
		//			});
		//			var oMonthFormat = DateFormat.getDateInstance({
		//				format: "MMMdd"
		//			});
		//			var oTableModeData = [];
		//			var aServices = [];
		//			oTableData.forEach(e => {
		//				var sService = aServices.find(x => x === e.service);
		//				if (!sService) {
		//					aServices.push(e.service);
		//				}
		//			});
		//			var aColumns = this.generateTableColumnsArray(oTableData);
		//			var aDisplayColumns = this.getProperty("displayColumns");
		//			//console.log("aServices", aServices);
		//			//var aDates = [];
		//			aServices.forEach(sService => { // for non overlapping records
		//				var obj = {};
		//				obj.service = sService;
		//				obj.iTotalQty = 0;
		//				var oFilteredTableData = oTableData.filter(x => x.bIsOverLab === false);
		//				aColumns.forEach(sColumn => {
		//					var oTableObject = oFilteredTableData.find(x => sColumn === oMonthFormat.format(x.startDate) && sService === x.service);
		//					if (oTableObject) {
		//						obj.bIsOverLab = false;
		//						if (aDisplayColumns.length > 0) {
		//							aDisplayColumns.forEach(oDisplayCol => {
		//								obj[oDisplayCol.keyName] = oTableObject[oDisplayCol.keyName];
		//							});
		//						}
		//						obj.group = oTableObject.groupDescription;
		//						obj.id = oTableObject.id;
		//						obj[sColumn] = oTableObject.value;
		//						if (parseFloat(oTableObject.value)) { // to calculate the total quantity
		//							obj.iTotalQty = parseFloat(obj.iTotalQty) + parseFloat(oTableObject.value);
		//						}
		//						if (oTableObject.startDate !== oTableObject.endDate) { // lump sum fields:
		//							var iDifferenceBetweenDays = oTableObject.endDate - oTableObject.startDate;
		//							iDifferenceBetweenDays = Math.ceil(iDifferenceBetweenDays / (1000 * 3600 * 24));
		//							obj[`${sColumn}_isLumpSum`] = true;
		//							obj[`${sColumn}_colspan`] = iDifferenceBetweenDays > 1 ? iDifferenceBetweenDays + 1 : 0;
		//							//obj[`${sColumn}_colspan`] = endDay - startDay + 1;
		//						} else {
		//							obj[`${sColumn}_isLumpSum`] = false;
		//							obj[`${sColumn}_colspan`] = 0;
		//						}
		//
		//					}
		//				});
		//				if (obj.TotalAmount) { // re-calculate the total amount
		//					obj.TotalAmount = obj.iTotalQty * parseFloat(obj.UnitPrice);
		//					obj.TotalAmount = obj.TotalAmount.toFixed(2);
		//				}
		//				obj.iTotalQty = obj.iTotalQty.toFixed(2);
		//
		//				oTableModeData.push(obj);
		//			});
		//
		//
		//			aServices.forEach(sService => { // for overlapping records
		//				var obj = {};
		//				obj.service = sService;
		//				obj.bIsOverLab = true;
		//				var oFilteredTableData = oTableData.filter(x => x.bIsOverLab === true);
		//				aColumns.forEach(sColumn => {
		//					var oTableObject = oFilteredTableData.find(x => sColumn === oMonthFormat.format(x.startDate) && sService === x.service);
		//					if (oTableObject) {
		//						obj.id = oTableObject.id;
		//						obj[sColumn] = oTableObject.value;
		//						if (oTableObject.startDate !== oTableObject.endDate) { // lump sum fields:
		//							var iDifferenceBetweenDays = oTableObject.endDate - oTableObject.startDate;
		//							iDifferenceBetweenDays = Math.ceil(iDifferenceBetweenDays / (1000 * 3600 * 24));
		//							obj[`${sColumn}_isLumpSum`] = true;
		//							obj[`${sColumn}_colspan`] = iDifferenceBetweenDays > 1 ? iDifferenceBetweenDays + 1 : 0;
		//							//obj[`${sColumn}_colspan`] = endDay - startDay + 1;
		//						} else {
		//							obj[`${sColumn}_isLumpSum`] = false;
		//							obj[`${sColumn}_colspan`] = 0;
		//						}
		//					}
		//
		//				});
		//				oTableModeData.push(obj);
		//
		//			});
		//
		//
		//			//////////////////////
		//
		//			//console.log("oTableModeData", oTableModeData);
		//
		//			//this.setProperty("oConvertedTableModel", oTableModeData);
		//
		//			return oTableModeData;
		//		},
		getGroups(oTableData) {
			var aGroups = [];
			oTableData.forEach(e => {
				var sGroup = aGroups.find(x => x === e.groupId);
				if (!sGroup) {
					aGroups.push(e.groupId);
				}
			});

			return aGroups;
		},
		getServices(oTableData) {
			var aServices = [];
			oTableData.forEach(e => {
				var sService = aServices.find(x => x === e.service);
				if (!sService) {
					aServices.push(e.service);
				}
			});

			return aServices;
		},
		setRows: function(aRows) {
			debugger;
			//console.log("aRows", aRows);
			oLSController = this;
			this.setProperty("rows", aRows, true);
			this.getStructuredData();
			this.rerender();
		},
		getStructuredData: function() {
			var aRows = this.getProperty("rows");
			
			var aDisplayColumns = this.getProperty("displayColumns");
			var sStartDate = this.getProperty("startDateKeyName");
			var sEndDate = this.getProperty("endDateKeyName");
			var sService = this.getProperty("serviceKeyName");
			var sValue = this.getProperty("valueKeyName");
			var sGroup = this.getProperty("groupingKeyName");
			var sId = this.getProperty("idKeyName");
			var oTableData = $.map(aRows, function(row, i) {
				var obj = {
					service: row[sService],
					startDate: row[sStartDate],
					endDate: row[sEndDate],
					value: parseFloat(row[sValue]).toFixed(3),
					groupDescription: row[sGroup],
					id: row[sId],
					Zeile: row.Zeile,
					JobId: row.JobId,
					groupId: row.JobLog
				};
				if (aDisplayColumns.length > 0) {
					aDisplayColumns.forEach(oDisplayCol => {
					obj[oDisplayCol.keyName] = row[oDisplayCol.keyName];
					// for two decimal added on 6/26/2024
					if (oDisplayCol.keyName === 'UnitPrice'){
					  obj[oDisplayCol.keyName] = parseFloat(row[oDisplayCol.keyName]).toFixed(2);
					}
						
					});
				}
				return obj;
			});

			var aColumns = this.generateTableColumnsArray(oTableData);

			this.setOverLappingRecords(oTableData);
			var oNewTableModel = this.getTableRows(oTableData);
			
			return {
				aColumns: aColumns,
				oNewTableModel: oNewTableModel
			}
		},
		getTableRows: function(oTableData) {
			var aDisplayColumns = this.getProperty("displayColumns");
			var aServices = this.getServices(oTableData);
			var aGroups = this.getGroups(oTableData);
			var oDateFormat = DateFormat.getDateInstance({
				format: "yyyyMMdd"
			});
			var oMonthFormat = DateFormat.getDateInstance({
				format: "MMMdd"
			});
			var aServicesPerGroup = [];
			var aRecordsPerService = [];
			var oNewTableModel = [];
			aGroups.forEach(sGroup => {
				var obj = {};
				obj.groupId = sGroup;
				obj.services = [];
				aServicesPerGroup = oTableData.filter(x => x.groupId === sGroup);
				if(aServicesPerGroup.length > 0) {
					obj.group = aServicesPerGroup[0].groupDescription;
				}
				aServicesPerGroup.forEach(oServiceRecord => {
					var oServiceObject = {};
//					// For CAD 
//					oServiceObject.unitPrice = oServiceRecord.unitPrice;
//					oServiceObject.currency = oServiceRecord.currency;
//					oServiceObject.totalQty = oServiceRecord.totalQty;
//					oServiceObject.totalAmount = oServiceRecord.totalAmount;
//					//-----------------------

					oServiceObject.serviceName = oServiceRecord.service;
					oServiceObject.Zeile = oServiceRecord.Zeile;
					oServiceObject.JobId = oServiceRecord.JobId;
					oServiceObject.id = oServiceRecord.id;
					oServiceObject.iNewTotalQty = 0;
					oServiceObject.iNewTotalAmount = 0;
					oServiceObject.iNewTotalAmountDisplay = 0;
					// display columns
					if (aDisplayColumns.length > 0) {
						aDisplayColumns.forEach(e => {
							oServiceObject[e.keyName] = oServiceRecord[e.keyName];
						});
					}
					//oServiceObject.TotalAmount = 0;
					//oServiceObject.unitPrice = oServiceObject.unitPrice.toFixed(2);
					oServiceObject.rows = [];
					//aRecordsPerService = oTableData.filter(x => x.service === oServiceRecord.service);
					aRecordsPerService = oTableData.filter(x => x.Zeile === oServiceRecord.Zeile && x.JobId === oServiceRecord.JobId);
					aRecordsPerService.forEach(oRecord => {
						oServiceObject.iNewTotalQty += parseFloat(oRecord.value);
						oServiceObject.iNewTotalAmount += parseFloat(oRecord.Amount);
						oRecord.fromDate = oMonthFormat.format(oRecord.startDate);
						oRecord.toDate = oMonthFormat.format(oRecord.endDate);
						if (oDateFormat.format(oRecord.startDate) !== oDateFormat.format(oRecord.endDate)) { // lump sum fields:
							var iDifferenceBetweenDays = oRecord.endDate - oRecord.startDate;
							iDifferenceBetweenDays = Math.ceil(iDifferenceBetweenDays / (1000 * 3600 * 24));
							oRecord.colspan = iDifferenceBetweenDays > 0 ? iDifferenceBetweenDays + 1 : 0;
						} else { // none lump sum
							oRecord.colspan = 0;
						}
						oServiceObject.rows.push(oRecord);
					});
					
					
					//oServiceObject.iNewTotalAmountDisplay = oServiceObject.iNewTotalAmount.toFixed(2);
					oServiceObject.iNewTotalAmountDisplay = oServiceObject.iNewTotalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 });

					oServiceObject.iNewTotalQty = oServiceObject.iNewTotalQty.toFixed(3);
					oServiceObject.iNewTotalAmountDisplay = oServiceObject.iNewTotalQty * parseFloat(oServiceObject.UnitPrice);
					oServiceObject.iNewTotalAmountDisplay = oServiceObject.iNewTotalAmountDisplay.toFixed(2);
					var oCurrentService = obj.services.find(x => x.JobId === oServiceObject.JobId && x.Zeile === oServiceObject.Zeile);
					if (!oCurrentService) {
						obj.services.push(oServiceObject);
					}

				});
				//aServicesPerGroup.push(obj);
				oNewTableModel.push(obj);
			});
			
			var oTransportationRecords = oNewTableModel.find(x => x.groupId == 'JL0002'); // Sort Transportation First
			oNewTableModel = oNewTableModel.filter(x => x.groupId != "JL0002");
			if(oTransportationRecords) {
				oNewTableModel = $.merge( [oTransportationRecords], oNewTableModel );
			}	
			this.setProperty("newLumpSumData", oNewTableModel);
			return oNewTableModel;



		},
		setOverLappingRecords: function(oTableData) {
			var oFilteredData = [];
			var oDatesPerService = {};
			//var aServices = this.getServices(oTableData);
			var oDateFormat = DateFormat.getDateInstance({
				format: "yyyyMMdd"
			});
			var aServices = [];
			oTableData.forEach(obj => {
				var aFilteredServices = aServices.filter(x => x.Zeile === obj.Zeile && x.JobId === obj.JobId);
				if (aFilteredServices.length === 0) {
					aServices.push(obj);
				}
				//var sService = aServices.find(x => x === e.service);
				//				try {
				//					var aFilteredServices = aServices.filter(x => x.Zeile === e.Zeile && x.JobId === e.JobId);
				//					if (aFilteredServices.length > 0) {
				//						aServices.push(oService[0]);
				//					}
				//
				//				} catch (ex) {
				//					aServices.push(e);
				//				}

			});
			aServices.forEach(oService => {
				var sServiceKey = oService.Zeile + "_" + oService.JobId;
				oDatesPerService[sServiceKey] = [];
				//oFilteredData = oTableData.filter(x => x.service === sService);
				oFilteredData = oTableData.filter(x => x.Zeile === oService.Zeile && x.JobId === oService.JobId);
				oFilteredData.forEach(e => {
					if (oDateFormat.format(e.startDate) === oDateFormat.format(e.endDate)) { // none lump sum fields will be in first row:
						var sDate = oDateFormat.format(e.startDate);
						var sUniqueDate = oDatesPerService[sServiceKey].find(x => x === `${sDate}`);
						if (!sUniqueDate) {
							e.bIsOverLab = false;
							oDatesPerService[sServiceKey].push(sDate);
						} else {
							e.bIsOverLab = true;
							//oDatesPerService[sService].push(e);
						}
					}
				});
				oFilteredData.forEach(e => {
					if (oDateFormat.format(e.startDate) !== oDateFormat.format(e.endDate)) { // lump sum fields with overlap will be in seperate row:
						var iDifferenceBetweenDays = e.endDate - e.startDate;
						iDifferenceBetweenDays = Math.ceil(iDifferenceBetweenDays / (1000 * 3600 * 24));
						for (var i = 0; i <= iDifferenceBetweenDays; i++) {
							var oNewDate = new Date(e.startDate);
							oNewDate.setDate(oNewDate.getDate() + i);
							var oCurrentDate = i > 0 ? oNewDate : e.startDate;
							var sDate = oDateFormat.format(oCurrentDate);
							var sUniqueDate = oDatesPerService[sServiceKey].find(x => x === `${sDate}`);
							if (!sUniqueDate) {
								if (!e.bIsOverLab) {
									e.bIsOverLab = false;
								}
								oDatesPerService[sServiceKey].push(sDate);
							} else {
								e.bIsOverLab = true;
							}
						}
					}
				});

				//				oFilteredData.forEach(oFilteredItem => {
				//					oNewTableData.push(oFilteredItem);
				//				});
			});

			//	console.log("oDatesPerService", oDatesPerService);
		},
//		getSumOfOverlapping: function(oTableData) {
//			oTableData.forEach(oRecordPerGroup => {
//				oRecordPerGroup.services.forEach(oRecordPerService => {
//					var iSummedValue = 0;
//					oRecordPerService.rows.forEach(oRow => {
//						if(oRow.colspan === 0 && oRow.bIsOverLab) {
//							iSummedValue += parseFloat(oRow.value);
//						}
//					});
//					var bIsSumPropAdded = false;
//					for (var i = 0; i < oRecordPerService.rows.length; i++) {
//						if(oRecordPerService.rows[i].colspan === 0 && oRecordPerService.rows[i].bIsOverLab) {
//							if(!bIsSumPropAdded) {
//								oRecordPerService.rows[i].value = iSummedValue;
//								bIsSumPropAdded = true;
//							} else {
//								delete oRecordPerService.rows[i];
//							}
//						}
//					}
//					
//					
//				});
//			});
//			
//			console.log("test", oTableData);
//			
//		},
		renderer: function(oRM, oControl) {
//			//var oTableData = oControl.getProperty("oTableData");
//			var aRows = oControl.getProperty("rows");

          // var oUserInfoModel =  controller.getModel("UserInfoModel").getData();
//			
			var aDisplayColumns = oControl.getProperty("displayColumns");
//			var sStartDate = oControl.getProperty("startDateKeyName");
//			var sEndDate = oControl.getProperty("endDateKeyName");
//			var sService = oControl.getProperty("serviceKeyName");
//			var sValue = oControl.getProperty("valueKeyName");
//			var sGroup = oControl.getProperty("groupingKeyName");
//			var sId = oControl.getProperty("idKeyName");
//			var oTableData = $.map(aRows, function(row, i) {
//				var obj = {
//					service: row[sService],
//					startDate: row[sStartDate],
//					endDate: row[sEndDate],
//					value: parseFloat(row[sValue]).toFixed(2),
//					groupDescription: row[sGroup],
//					id: row[sId],
//					Zeile: row.Zeile,
//					JobId: row.JobId,
//					groupId: row.JobLog
//				};
//				if (aDisplayColumns.length > 0) {
//					aDisplayColumns.forEach(oDisplayCol => {
//						obj[oDisplayCol.keyName] = row[oDisplayCol.keyName];
//					});
//				}
//				obj.newTotalQty = 0;
//				return obj;
//			});
//
//			var aColumns = oControl.generateTableColumnsArray(oTableData);
//
//			oControl.setOverLappingRecords(oTableData);
//			var oNewTableModel = oControl.getTableRows(oTableData);
			var oStructuredData = oControl.getStructuredData();
			var aColumns = oStructuredData.aColumns;
			var oNewTableModel = oStructuredData.oNewTableModel;

			var iGrandTotalAmount = 0;


			//var oConvertedTableModel = oControl.buildTableModel(oNewTableData);


			//			var aGroups = [];
			//			oConvertedTableModel.forEach(e => {
			//				var sGroup = aGroups.find(x => x === e.group);
			//				if (!sGroup) {
			//					aGroups.push(e.group);
			//				}
			//			});

			oRM.write("<div");
			oRM.writeControlData(oControl);
			oRM.addClass("overflow-scroll");
			oRM.writeClasses();
			oRM.write(">");


			var sHtml = "<table border='1px' class='custom-lump-sum-table'>"; // table
			sHtml += "<thead>"; // table head
			sHtml += "<tr>"; // header row
			sHtml += `<th >Reference No.</th>`; // header cells
			sHtml += `<th >Description</th>`; // header cells
			aColumns.forEach(sColumn => { // render months header
				sHtml += `<th >${sColumn}</th>`; // header cells
			});
			sHtml += `<th>Total Quantity</th>`;
			//render display fields header: 
			if (aDisplayColumns.length > 0) {
				aDisplayColumns.forEach(e => { // render display fields header
					sHtml += `<th >${e.label}</th>`;
				});
			}

			sHtml += "</tr>"; // end of header row
			sHtml += "</thead>"; // end of table head
			sHtml += "<tbody>"; // table body

			oNewTableModel.forEach(oRecordPerGroup => {
				sHtml += `<tr><td class='grouping-row' colspan='${aColumns.length + aDisplayColumns.length + 3}'>${oRecordPerGroup.group}</td></tr>`;
				oRecordPerGroup.services.forEach(oRecordPerService => {
					var aNonOverLappingRecords = oRecordPerService.rows.filter(x => x.bIsOverLab === false);
					var aOverLappingRecords = oRecordPerService.rows.filter(x => x.bIsOverLab === true);
					var iRowSpan = aOverLappingRecords.length;
					sHtml += "<tr>";
					sHtml += `<td rowspan='${iRowSpan + 1}'>${oRecordPerService.id || ''}</td>`;
					sHtml += `<td rowspan='${iRowSpan + 1}'>${oRecordPerService.serviceName}</td>`;
					for (var i = 0; i < aColumns.length; i++) { // render months
						var sColumn = aColumns[i];
						var oRecord = aNonOverLappingRecords.find(x => x.fromDate === sColumn);
						if (oRecord) {
							var sTdValue = oRecord.value;
							var iColspan = oRecord.colspan;
							if (iColspan) {
								sHtml += `<td colspan='${iColspan}' class='custom-comp-lump-sum-cell'>${sTdValue}</td>`;
								i = i + iColspan - 1;
							} else {
								sHtml += `<td>${sTdValue}</td>`;
							}
						} else {
							sHtml += `<td> </td>`;
						}

					}

					sHtml += `<td rowspan='${iRowSpan + 1}'><b>${oRecordPerService.iNewTotalQty}</b></td>`; // total amount
					// render display columns
					if (aDisplayColumns.length > 0) {
						aDisplayColumns.forEach(e => {
							//sHtml += `<td rowspan='${iRowSpan + 1}'>${oRecordPerService[e.keyName]}</td>`;
							try {
								if (e.keyName === 'Amount') {
									sHtml += `<td rowspan='${iRowSpan + 1}'>${oRecordPerService.iNewTotalAmountDisplay}</td>`;
									iGrandTotalAmount += parseFloat(oRecordPerService.iNewTotalAmount);
									//iGrandTotalAmount += parseFloat(oRecordPerService[e.keyName]);
								} else {
									sHtml += `<td rowspan='${iRowSpan + 1}'>${oRecordPerService[e.keyName]}</td>`;
								}
							} catch (ex) {
								sHtml += `<td rowspan='${iRowSpan + 1}'>${oRecordPerService[e.keyName]}</td>`;
							 }
						});
					}


					sHtml += "</tr>";
					// render overlapping records (rows) :
					aOverLappingRecords.forEach(oRecord => {
						sHtml += "<tr>";
						//sHtml += "<td></td><td></td>"; // empty td for the id and description
						for (var i = 0; i < aColumns.length; i++) { // render months
							var sColumn = aColumns[i];
							if (sColumn === oRecord.fromDate) {
								var sTdValue = oRecord.value;
								if (sTdValue) {
									var iColspan = oRecord.colspan;
									if (iColspan) {
										sHtml += `<td colspan='${iColspan}' class='custom-comp-lump-sum-cell'>${sTdValue}</td>`;
										i = i + iColspan - 1;
									} else {
										sHtml += `<td>${sTdValue}</td>`;
									}
								} else {
									sHtml += `<td> </td>`;
								}
							} else {
								sHtml += `<td> </td>`;
							}

						}
						sHtml += "</tr>";
					});

				});
			});

			var aTotalAmount = aDisplayColumns.filter(x => x.keyName === 'Amount');

			// For Total Amount
			if (aTotalAmount.length > 0) {
				sHtml += "<tr>";
				sHtml += `<td class='grouping-row' colspan='${aColumns.length + aDisplayColumns.length + 2}'>Total eTicket Value: </td>`;
				sHtml += `<td><b> ${iGrandTotalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })} </b></td>`;
				sHtml += "</tr>";
			}




			sHtml += "</tbody>"; // end of table body
			sHtml += "</table>"; // end of table


			oRM.write(sHtml);

           oControl.setProperty("ExportExcelHtmlTable", sHtml);

			oRM.write('</div>');



			///////////////////////////////////////









			//			var oDateFormat = DateFormat.getDateInstance({
			//				format: "yyyyMMdd"
			//			});
			//
			//			var aServices = [];
			//			oTableData.forEach(e => {
			//				var sService = aServices.find(x => x === e.service);
			//				if (!sService) {
			//					aServices.push(e.service);
			//				}
			//			});
			//
			//			var oNewTableData = [];
			//			var oFilteredData = [];
			//			var oDatesPerService = {};
			//			aServices.forEach(sService => {
			//				oDatesPerService[sService] = [];
			//				oFilteredData = oTableData.filter(x => x.service === sService);
			//				oFilteredData.forEach(e => {
			//					if (e.startDate !== e.endDate) { // lump sum fields:
			//						var iDifferenceBetweenDays = e.endDate - e.startDate;
			//						iDifferenceBetweenDays = Math.ceil(iDifferenceBetweenDays / (1000 * 3600 * 24));
			//						for (var i = 0; i <= iDifferenceBetweenDays; i++) {
			//							var oNewDate = new Date(e.startDate);
			//							oNewDate.setDate(oNewDate.getDate() + i);
			//							var oCurrentDate = i > 0 ? oNewDate : e.startDate;
			//							var sDate = oDateFormat.format(oCurrentDate);
			//							var sUniqueDate = oDatesPerService[sService].find(x => x === `${sDate}`);
			//							if (!sUniqueDate) {
			//								e.bIsOverLab = false;
			//								oDatesPerService[sService].push(sDate);
			//							} else {
			//								e.bIsOverLab = true;
			//							}
			//						}
			//					} else { // none lump sum
			//						var sDate = oDateFormat.format(e.startDate);
			//						var sUniqueDate = oDatesPerService[sService].find(x => x === `${sDate}`);
			//						if (!sUniqueDate) {
			//							e.bIsOverLab = false;
			//							oDatesPerService[sService].push(sDate);
			//						} else {
			//							e.bIsOverLab = true;
			//							//oDatesPerService[sService].push(e);
			//						}
			//					}
			//				});
			//
			//				oFilteredData.forEach(oFilteredItem => {
			//					oNewTableData.push(oFilteredItem);
			//				});
			//			});
			//
			//			debugger;
			//
			//			var aColumns = oControl.generateTableColumnsArray(oNewTableData);
			//			var oConvertedTableModel = oControl.buildTableModel(oNewTableData);
			//
			//
			//			var aGroups = [];
			//			oConvertedTableModel.forEach(e => {
			//				var sGroup = aGroups.find(x => x === e.group);
			//				if (!sGroup) {
			//					aGroups.push(e.group);
			//				}
			//			});
			//
			//			oRM.write("<div")
			//			oRM.writeControlData(oControl);
			//			oRM.addClass("overflow-scroll");
			//			oRM.writeClasses();
			//			oRM.write(">");
			//
			//
			//			var sHtml = "<table border='1px' class='custom-lump-sum-table'>"; // table
			//			sHtml += "<thead>"; // table head
			//			sHtml += "<tr>"; // header row
			//			sHtml += `<th >Reference No.</th>`; // header cells
			//			sHtml += `<th >Description</th>`; // header cells
			//			aColumns.forEach(sColumn => { // render months header
			//				sHtml += `<th >${sColumn}</th>`; // header cells
			//			});
			//			sHtml += `<th>Total Quantity</th>`;
			//			//render display fields header: 
			//			if (aDisplayColumns.length > 0) {
			//				aDisplayColumns.forEach(e => { // render display fields header
			//					sHtml += `<th >${e.label}</th>`;
			//				});
			//			}
			//
			//			sHtml += "</tr>"; // end of header row
			//			sHtml += "</thead>"; // end of table head
			//			sHtml += "</tbody>"; // table body
			//			aGroups.forEach(sGroup => {
			//				sHtml += `<tr><td class='grouping-row' colspan='${aColumns.length + aDisplayColumns.length + 3}'>${sGroup}</td></tr>`;
			//				var aRowsPerGroup = oConvertedTableModel.filter(x => x.group === sGroup && x.bIsOverLab === false);
			//				aRowsPerGroup.forEach(oRow => {
			//					if (!oRow.bIsOverLab && oRow.iTotalQty > 0) {
			//
			//						sHtml += "<tr>";
			//						sHtml += `<td>${oRow.id}</td>`;
			//						sHtml += `<td>${oRow.service}</td>`;
			//						for (var i = 0; i < aColumns.length; i++) { // render months
			//							var sColumn = aColumns[i];
			//							var sTdValue = oRow[sColumn];
			//							if (sTdValue) {
			//								var iColspan = oRow[sColumn + "_colspan"];
			//								if (iColspan) {
			//									sHtml += `<td colspan='${iColspan}' class='custom-comp-lump-sum-cell'>${sTdValue}</td>`;
			//									i = i + iColspan - 1;
			//								} else {
			//									sHtml += `<td>${sTdValue}</td>`;
			//								}
			//							} else {
			//								sHtml += `<td>0</td>`;
			//							}
			//						}
			//
			//						sHtml += `<td>${oRow.iTotalQty}</td>`;
			//						// render display columns
			//						if (aDisplayColumns.length > 0) {
			//							aDisplayColumns.forEach(e => {
			//								sHtml += `<td>${oRow[e.keyName]}</td>`;
			//							});
			//						}
			//
			//
			//						sHtml += "</tr>";
			//
			//					}
			//
			//					// for overlapping records:
			//					var aOverLappingRow = oConvertedTableModel.filter(x => x.group === sGroup && x.service === oRow.service && x.bIsOverLab === true);
			//					aOverLappingRow.forEach(oRow => {
			//
			//						sHtml += "<tr>";
			//						sHtml += `<td>${oRow.id}</td>`;
			//						sHtml += `<td>${oRow.service}</td>`;
			//						for (var i = 0; i < aColumns.length; i++) { // render months
			//							var sColumn = aColumns[i];
			//							var sTdValue = oRow[sColumn];
			//							if (sTdValue) {
			//								var iColspan = oRow[sColumn + "_colspan"];
			//								if (iColspan) {
			//									sHtml += `<td colspan='${iColspan}' class='custom-comp-lump-sum-cell'>${sTdValue}</td>`;
			//									i = i + iColspan - 1;
			//								} else {
			//									sHtml += `<td>${sTdValue}</td>`;
			//								}
			//							} else {
			//								sHtml += `<td>0</td>`;
			//							}
			//						}
			//
			//						sHtml += `<td>${oRow.iTotalQty}</td>`;
			//						// render display columns
			//						if (aDisplayColumns.length > 0) {
			//							aDisplayColumns.forEach(e => {
			//								sHtml += `<td>${oRow[e.keyName]}</td>`;
			//							});
			//						}
			//
			//
			//						sHtml += "</tr>";
			//					});
			//
			//				});
			//
			//			});
			//
			//			sHtml += "</tbody>"; // end of table body
			//			sHtml += "</table>"; // end of table
			//
			//
			//			oRM.write(sHtml);
			//			oRM.write('</div>');
		}
	});
});