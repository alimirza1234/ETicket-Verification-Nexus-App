sap.ui.define([
		"sap/ui/base/Object",
		"sap/ui/model/json/JSONModel",
		"sap/m/MessageBox",
		"zdwo_nx_drss_ven/model/formatter",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator"
	], function (BaseObject, JSONModel, MessageBox, formatter, Filter, FilterOperator) {
		"use strict";

		return  BaseObject.extend("zdwo_nx_drss_ven.utils.POContractSelector", {
			
			formatter: formatter,
			
			constructor : function (oView, oModel, oController, sVendor, sRqtype, fnSuccess) { 
				
				this._oView 		= 	oView;
				this._oModel		= 	oModel;
				this._oController	=	oController;
				this._sVendor		=	sVendor;
				this._sRqtype		= 	sRqtype;
				this._fnSuccess		=	fnSuccess; 
				
				// PO/Contract Model
				var oPOContract 		= new JSONModel([]);
				this._oPOContractModel	= oPOContract;
				
				// ViewModel
				var oViewModel = new JSONModel({
					currentType: "K",
					searchValue: "",
					POdialog:	 true,
					COdialog:	 true
				});
				
				this._oViewModel	= oViewModel;
				
				// Show/Hide COTRACT/PO tabs per config
				//var oFieldsOps = this._oController.getOwnerComponent().oFieldsOps
				var oPOtabDialog = this._oController.getModel("configModel").getData().potabdialog;
				var oCOtabDialog = this._oController.getModel("configModel").getData().cotabdialog;
							
				
				if(typeof oPOtabDialog !== "undefined") {
					this._oViewModel.setProperty("/POdialog",(oPOtabDialog.Visible === true));
				}
				
				if(typeof oCOtabDialog !== "undefined") {
					this._oViewModel.setProperty("/COdialog",(oCOtabDialog.Visible === true) );
					// If only contract is visible, make sure we get items for the contract not POs
					if(typeof oPOtabDialog !== "undefined" && oPOtabDialog.Visible !== true) {
						this._oViewModel.setProperty("/currentType","K");
					}
				}
				
				// Create the dialog..
				if(!this._POContractDialog) {
					
					this._POContractDialog = sap.ui.xmlfragment("zdwo_nx_drss_ven.view.Dialogs.POContractSelector", this);
					
					this._POContractDialog.addStyleClass(this._oController.getOwnerComponent().getContentDensityClass());
					
					this._POContractDialog.setModel(oViewModel,"ViewModel");
					
					oView.addDependent(this._POContractDialog);
					
					// Job List
					this._oList = sap.ui.getCore().byId("POContractList");
					this._oList.setModel(this._oPOContractModel,"POContractItems");
					
					// Add double click event to the list
			        var that = this;
			        this._oList.onAfterRendering = function() {
				      	this._oList.$().bind("dblclick",function() { 
				      		this.onOK();
				      	}.bind(this));
			        }.bind(this);

				}
				
				
				this._POContractDialog.setBusy(true);
				this.getPOLineItems();
		
				
				
			},
			
			
			getPOLineItems : function() {
				
				var oPoItemsPromise = this.getPOLineItemsPromise(this._sVendor,this._oViewModel.getProperty("/currentType"),this._sRqtype);
				
				oPoItemsPromise.then(function(responce){
					this._oPOContractModel.setData(responce.results);
					this._POContractDialog.setBusy(false);
					//console.log(responce);
				}.bind(this));
				
				oPoItemsPromise.catch(function(){
					this._POContractDialog.setBusy(false);
					//MessageBox.error("Unable to get line items of the selected PO line item");
					//this._POContractDialog.close();
				}.bind(this));
				
				this._POContractDialog.open();
				
				
				
			},
			
			
			getPOLineItemsPromise : function (sVendorId,sBstyp,sRqtype) {
						
			          var oVendorFilter = new sap.ui.model.Filter("LIFNR",sap.ui.model.FilterOperator.EQ, sVendorId);
			          var oRqtypeFilter	= new sap.ui.model.Filter("RQTYPE",sap.ui.model.FilterOperator.EQ, sRqtype);
			          var oBstypFilter	= new sap.ui.model.Filter("BSTYP",sap.ui.model.FilterOperator.EQ, sBstyp);

                      var model = controller.getView().getModel("itemsModel");
                      var data = "";
                      if (model.getObject("/")['SrvtypeCode']){
	                      data = model.getObject("/");
                      }else {
	                     var model = controller.getView().getModel("oWSModel");
	                     data = model.getObject("/");
                       }

			          if(data.SrvtypeCode !==""){
			        	  var oServiceTypeFilter	= new sap.ui.model.Filter("SrvtypeCode",sap.ui.model.FilterOperator.EQ, data.SrvtypeCode);  
			        	  var aArray = [oVendorFilter, oBstypFilter, oRqtypeFilter, oServiceTypeFilter];
			          }else{
			        	  var aArray = [oVendorFilter, oBstypFilter, oRqtypeFilter];
			          }
			          
			          if(data.EstSdt !== null){
			        	  var EstSdt	= new sap.ui.model.Filter("EstSdt",sap.ui.model.FilterOperator.EQ, data.EstSdt);
			        	  aArray.push(EstSdt)
			          }
			          
			          if(data.EstEdt !== null){
			        	  var EstEdt	= new sap.ui.model.Filter("EstEdt",sap.ui.model.FilterOperator.EQ, data.EstEdt);
			        	  aArray.push(EstEdt)
			          }
			          
			          var oPromise = new  Promise(function(resolve, reject) {

			            this._oModel.read("/PurchaseOrderSet",{
			              filters : aArray,
			              success: function(oData)  { resolve(oData); },
			              error:   function(Error)  { reject(Error);  }
			            });
			          }.bind(this));

			          return oPromise;

			 },
			
			/* =========================================================== */
			/* Event Handler                                               */
			/* =========================================================== */
			
			onOK: function(oEvent) {
				
				if(typeof this._oList.getSelectedItem() !== "undefiend" && this._oList.getSelectedItem() !== null ) {
				
					var oItem = this._oList.getSelectedItem().getBindingContext("POContractItems").getObject();
					
					if(oItem.FRGKE !== "R"){
						sap.m.MessageBox.error("Purchase Order is : " + oItem.FRGET);
						return;
					}
					
					
					if(this.numberCheck(oItem.PoPerce) > this.numberCheck(oItem.PoPerLimit)){						
						/*sap.m.MessageBox.warning( "PO Value has been exceeded by " + oItem.PoPerce + "% percentage. Do you still want to continue ?" , {
							actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				          	styleClass: "sapUiSizeCompact",
				          	onClose: function(sAction) {
				            	if(sAction === "YES"){
				            		if(typeof this._fnSuccess !== "undefined") {
										this._fnSuccess(oItem);
									}									
									this._POContractDialog.close();
				            	}else{
				                  
				                }
				          	}.bind(this)
				          	 });*/
						if(Number(oItem.PoPerce) > 100){
							const exceed = (parseFloat(oItem.PoPerce) - 100).toFixed(2);

							sap.m.MessageBox.warning( "PO Value has been exceeded by " + exceed + "% percentage. Do you still want to continue ?" , {
								actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					          	styleClass: "sapUiSizeCompact",
					          	onClose: function(sAction) {
					            	if(sAction === "YES"){
					            		if(typeof this._fnSuccess !== "undefined") {
											this._fnSuccess(oItem);
										}									
										this._POContractDialog.close();
					            	}else{
					                  
					                }
					          	}.bind(this)
					          	 });
						}else{			
							if(typeof this._fnSuccess !== "undefined") {
								this._fnSuccess(oItem);
							}									
							this._POContractDialog.close();
						}
						
					}else{
						if(typeof this._fnSuccess !== "undefined") {
							this._fnSuccess(oItem);
						}									
						this._POContractDialog.close();
					}
					
				}
				
			},
			
			numberCheck : function(oEvent){
				if(parseFloat(oEvent)){
					return parseFloat(oEvent);
				}else{
					return 0;
				}
			},
			
			onTabChange: function(oEvent) {
				//var sKey = oEvent.getParameters().selectedKey;
				
				this._POContractDialog.setBusy(true);
				this.clearFilters();
				this.getPOLineItems();
			},
			
			onAfterClose : function (oEvent) {
				oEvent.getSource().destroy();
			},
			
			onCancel : function (oEvent) {
				this._POContractDialog.close();
				oEvent.getSource().destroy();
			},
			
			onSearch : function (oEvent) {
				
				var  sValue = oEvent.getSource().getValue(),
				 	 binding = this._oList.getBinding("items");
			
					var aFilters 	= [],
						filter1 	= new Filter("TXZ01", sap.ui.model.FilterOperator.Contains, sValue),
						filter2 	= new Filter("EBELN", sap.ui.model.FilterOperator.Contains, sValue),
						filter3 	= new Filter("EBELP", sap.ui.model.FilterOperator.Contains, sValue),
						filters 	= [filter1,filter2,filter3],
						finalFilter = new sap.ui.model.Filter({filters:filters, and:false});
						aFilters.push(finalFilter);
		           
					binding.filter(aFilters);
				
			},
			
			clearFilters : function (oEvent) {
				var binding = this._oList.getBinding("items");
				
				this._oViewModel.setProperty("/searchValue", "");
				
				binding.filter([]);
			}
		
		});
		
});	