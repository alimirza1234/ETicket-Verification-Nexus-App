sap.ui.define([
	"sap/ui/base/Object",
	'sap/ui/core/util/Export',
	'sap/ui/core/util/ExportTypeCSV'
	], function(Object,Export,ExportTypeCSV){

	return Object.extend("zdwo_nx_drss_ven.utils.ExportToExcel",{

		constructor: function(oTable,reportName,isFormatted,flag){
		},
		
		
		setDateFormatter: function (sDate) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({pattern:"MM/dd/YYYYY"});
			var dateFormatted = dateFormat.format(sDate);
			return dateFormatted;
			
		},
		
		formatDate: function (sDate) {
			
			if (typeof sDate === 'string') {
				return sDate;
			}
			
			var dateFormatted;
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({pattern:"MM/dd/YYYY"});
			
			dateFormatted = dateFormat.format(sDate);
			
			/*try {
				dateFormatted = dateFormat.format(sDate);
			} catch (oError) {
				return "";
			}*/
			
			return dateFormatted;
		},
		
		setTimeFormatter: function (oTime, bNoSeconds) {
			var dateFormat, dateFormatted, oDate, oTimeOffset;
			
			if (bNoSeconds) {
				dateFormat = sap.ui.core.format.DateFormat.getTimeInstance({pattern:"HH:mm"});
			} else {
				dateFormat = sap.ui.core.format.DateFormat.getTimeInstance({pattern:"HH:mm:ss"});
			}
			
			oTimeOffset = new Date(0).getTimezoneOffset() * 60 * 1000;
			
			oDate = new Date(oTime.ms + oTimeOffset);
			
			dateFormatted = dateFormat.format(oDate);
			return dateFormatted;
			
		},
		
		exportHTMLFormat : function(html,reportName){
			this.performExport(reportName,html); 
		},
		
		
		performExport : function(reportTitle,html){
			var hContent = "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:excel' xmlns='http://www.w3.org/TR/REC-html40'><head></head><body>";
			var closeContent = '</body></html>';
			
			var htmlPage = hContent + html +  closeContent;
			var url = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(htmlPage);
//			var url = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,' + encodeURIComponent(htmlPage);
			var blob = new Blob(['\ufeff', htmlPage], {
		        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
		    });
			
			var filename = reportTitle+".xls";
		    // Create download link element
		    var downloadLink = document.createElement("a");
		    document.body.appendChild(downloadLink);
		    if(navigator.msSaveOrOpenBlob ){
		        navigator.msSaveOrOpenBlob(blob, filename);
		    }
		    else{
		        // Create a link to the file
		        downloadLink.href = url;
		        // Setting the file name
		        downloadLink.download = filename;
		        //triggering the function
		        downloadLink.click();
		    }
		    document.body.removeChild(downloadLink);


			
		}
		
		
			
	});
});


