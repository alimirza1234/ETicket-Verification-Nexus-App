sap.ui.define([
	"sap/ui/base/Object",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"zdwo_nx_drss_ven/utils/POContractSelector",
	//"zdwo_nx_drss_ven/controller/changeHistory",
	"zdwo_nx_drss_ven/model/formatter"
], function (UI5Object, MessageBox, JSONModel, MessageToast, POContractSelector, formatter) {
	"use strict";

	return UI5Object.extend("zdwo_nx_drss_ven.utils.DispatchedServicesSplit", {
		formatter: formatter,

		constructor: function (oController, sFragmentName) {
			this._oController = oController;
			this._sFragmentName = sFragmentName;
			this.flatArray = [];
			this.sServiceId = "";
			this.MultiSrvLines = false;

		},

		_initialize: function (objectId, item, EBELN, EBELP, pkg_num, lim_ind, co_ind, serviceId, srvText, oSelectedItem, contractNo, KTPNR) {
			if (objectId === undefined) {
				this._objectId = objectId;
			} else {
				this._objectId = "" + objectId;
			}

			if (item === undefined) {
				this._item = item;
			} else {
				this._item = "" + item;
			}

			if (EBELN === undefined) {
				this._EBELN = EBELN;
			} else {
				this._EBELN = "" + EBELN;
			}

			if (EBELP === undefined) {
				this._EBELP = EBELP;
			} else {
				this._EBELP = "" + EBELP;
			}

			if (pkg_num === undefined) {
				this._pkg_num = pkg_num;
			} else {
				this._pkg_num = "" + pkg_num;
			}

			if (lim_ind === undefined) {
				this._lim_ind = lim_ind;
			} else {
				this._lim_ind = "" + lim_ind;
			}

			if (co_ind === undefined) {
				this._co_ind = co_ind;
			} else {
				this._co_ind = "" + co_ind;
			}

			if (serviceId === '') {
				this._serviceId = serviceId;
			} else {
				this._serviceId = "" + serviceId;
			}

			if (srvText === '') {
				this.srvText = "" + oSelectedItem['ServLtext'];

			} else {
				this.srvText = srvText;
			}

			if (oSelectedItem['Menge'] === undefined) {
				this.sMenge = oSelectedItem['Menge'];
			} else {
				this.sMenge = "" + oSelectedItem['Menge'];
			}

			if (this.srvText === '') {
				this.srvText = oSelectedItem['Maktxo'];
			}

			if (oSelectedItem.MultiSrvLines === undefined) {
				this.MultiSrvLines = false;
			} else {
				this.MultiSrvLines = oSelectedItem.MultiSrvLines;
			}

			if (contractNo === '') {
				this.contractNo = "" + contractNo;
			} else {
				this.contractNo = contractNo;
			}

			if (KTPNR === '') {
				this.KTPNR = "" + KTPNR;
			} else {
				this.KTPNR = KTPNR;
			}

			/*  if (oSelectedItem['Maktxo'] === '') {
	                this.Maktxo = "" + oSelectedItem['Maktxo'];
		        } else {
		        	this.Maktxo = oSelectedItem['ServLtext'];
		        }*/
		},

		createFragment: function (objectId, item, EBELN, EBELP, pkg_num, lim_ind, co_ind, serviceId, ServTxt, oSelectedItem, contractNo,
			KTPNR) {

			this.oSelectedItem = oSelectedItem;
			this._initialize(objectId, item, EBELN, EBELP, pkg_num, lim_ind, co_ind, serviceId, ServTxt, oSelectedItem, contractNo, KTPNR);
			// View model to control the UI. 
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				readOnly: false,
				change: false,
				InitMengeDisplay: false,
				MengeDisplay: false,
				InitMengeVisible: false,
				MengeVisible: false,
				DiscountDisplay: false,
				DiscountVisible: false,
				PageTitle: "Filling Line items", // Page title
				TotalCost: 0.0, // Total cost
				TotalInitial: 0.0, // Total inital cost
				Docno: "", // Current Request
				Zeile: "2", // Current Line item
				PO: "", // Current PO
				POItem: "", // Current PO Line item
				LineNo: "",
				srvText: this.srvText
			});

			this._oViewModel = oViewModel;

			if (!this._oFragment) {
				this._oFragment = sap.ui.xmlfragment(this._sFragmentName, this);
				// Services list
				//this.ESVItems_template =  sap.ui.getCore().byId("servicesList").getBindingInfo("items").template;
			}

			this._oController.getView().addDependent(this._oFragment);

			this._oFragment.setModel(this._oViewModel, "ViewModel");

			// Model to store the selected Services
			this.oServices = new JSONModel([]);
			// Assign the model to the table.
			var selectedServicesTable = sap.ui.getCore().byId("selectedServicesList");
			selectedServicesTable.setModel(this._oViewModel, "ViewModel");
			selectedServicesTable.setModel(this.oServices, "selServices");

			this.UserInfoModel = new JSONModel();
			this.UserInfoModel.setData(controller.getView().getModel("UserInfoModel").getData());
			this._oFragment.setModel(this.UserInfoModel, "UserInfoModel");

			// PO Items model.
			this._oPOItemsModel = new JSONModel([]);
			sap.ui.getCore().byId("onTreeTable").setValue("");
			// Global Service id

			this.sServiceId = serviceId;
			this.sSrvText = this.srvText;

			// Current Docno,Zeilie
			this.Docno = "";
			this.Zeile = "";

			// Instantiate Tree Master
			this._onLogMatched(this._objectId, this._item, this._EBELN, this._EBELP, this._pkg_num, this._lim_ind, this._co_ind, this._serviceId,
				ServTxt, oSelectedItem['']);

			// Instantiate ESV Items
			this._onESVMatched(this._objectId, this._item, this._EBELN, this._EBELP, this._pkg_num, this._lim_ind, this._co_ind, this._serviceId,
				ServTxt);

			// forward compact/cozy style into Dialog
			this._oFragment.addStyleClass(this._oController.getOwnerComponent().getContentDensityClass());

			this._oFragment.open();

			selectedServicesTable.getModel("ViewModel").refresh();
			selectedServicesTable.getModel("selServices").refresh();
			//   this._oController._DispServicesDialog.getModel("POModel").refresh();
			/*if (this.sServiceId !==''){
	               sap.ui.getCore().byId("INITIALMENGE_txt").setText("Requested Quantity");
                 //  sap.ui.getCore().byId("ReqQuantity").setEditable(false);
                  // sap.ui.getCore().byId("ProposedQuantity").setVisible(false);
                }else {
	               sap.ui.getCore().byId("INITIALMENGE_txt").setText("Proposed Quantity");
                 //  sap.ui.getCore().byId("ReqQuantity").setEditable(true);
                  // sap.ui.getCore().byId("ProposedQuantity").setVisible(true);
                }*/
			this.calculateTotalCost();
			// this._oController._DispServicesDialog.getModel("POModel").refresh()               

			return this._oFragment;
		},

		_onLogMatched: function (objectId, item, EBELN, EBELP, pkg_num, lim_ind, co_ind, serviceId, srvText) {
			var sReqId = objectId,
				sItemId = item,
				sPOId = EBELN,
				sPOItemId = EBELP,
				sObjectPath,
				that = this._oController;

			var chkDiffPO = ((this.sPOId !== EBELN) || this.sPOItemId !== EBELP || this.sCo_ind !== co_ind);

			this.sReqId = objectId;
			this.sItemId = item;
			this.sPOId = EBELN;
			this.sPOItemId = EBELP;

			this.sPkgNo = pkg_num;

			this.sLim_ind = lim_ind;
			this.sCo_ind = co_ind;
			this.sRecordNum = serviceId;

			if (typeof this.sLim_ind === "undefined") this.sLim_ind = "0";
			if (typeof this.sCo_ind === "undefined") this.sCo_ind = "C";
			/*	var oPOBtn = sap.ui.getCore().byId("POBtn");
				var oCOBtn = sap.ui.getCore().byId("COBtn");*/
			/*	if(sPOId.substring(0,2) === "66") {
						oPOBtn.setVisible(false);
						oCOBtn.setVisible(false);
				} else {
				
					if(this.sLim_ind === "S") {
						oPOBtn.setVisible(true);
						oCOBtn.setVisible(false);
					} else if(this.sLim_ind === "L") {
						oPOBtn.setVisible(false);
						oCOBtn.setVisible(true);
					} else {
						oPOBtn.setVisible(true);
						oCOBtn.setVisible(true);
					}
				}
				*/
			this.sLim_ind === "L";

			/*if(this.sCo_ind === "CO") {
				oCOBtn.setPressed(true);
				oPOBtn.setPressed(false);
			} else if(this.sCo_ind === "PO") {
				oPOBtn.setPressed(true);
				oCOBtn.setPressed(false);
			} */
			this.tree = sap.ui.getCore().byId("tree");

			/*if (sap.ui.getCore().byId("treeMaster")){
	                sap.ui.getCore().byId("treeMaster").setBusy(true);
                 }*/

			//	this.getModel().metadataLoaded().then( function() {
			sObjectPath = that.getModel("VendorService").createKey("PurchaseOrderSet", {
				Docno: sReqId,
				ZEILE: sItemId,
				EBELN: sPOId,
				EBELP: sPOItemId,
				Limit_ind: this.sLim_ind,
				Co_ind: this.sCo_ind,
				RECORD_NO: this.sRecordNum
			});
			if (chkDiffPO) {
				//console.log("inside chkDiffPO",chkDiffPO);
				// Bind the tree with the services.
				var oModel = this._oController.getModel("oDataModel");
				oModel.read("/" + sObjectPath + "/POToESVTree", {
					method: "POST",
					success: function (oData) {
						if (sap.ui.getCore().byId("treeMaster")) {
							sap.ui.getCore().byId("treeMaster").setBusy(false);
						}
						this.flatArray = oData['results'];

						var data = this.buildHierV2(oData['results'], "PARENT", "NODEID", "1");

						//var data = this.buildHierV3(oData['results'],"EXT_LINE","LINE_NO", "1"); 

						//  this.tree.setBusy(false); 

						/*	var aHier = [];
								$.each(oData.results, function(ind, obj) {
		                         
                                    if (obj['OUTL_LEVEL'] === 1){
	                                    var lineNum = obj['LINE_NO'];
                                        
                                      
                                    }
                                     

                                    if(!aHier["L1"+obj.PCKG_NO]){
										aHier["L1"+obj.PCKG_NO]  ={lineNumber:obj.PCKG_NO, children:[]};
									}
									
									aHier["L1"+obj.PCKG_NO].children.push({name: obj.SHORT_TEXT , EBELN:obj.EBELN, EBELP:obj.EBELP, SUBPCKG_NO:obj.SUBPCKG_NO, lineNumber :obj.LINE_NO , Children:[]});
								}.bind(this));
								
								this.data  = [];
								for (var node in aHier){
									if (aHier[node]){
										this.data.push(aHier[node]);
									}
									
								    var i = 0;
									var ind = 1;
									var nextChild = aHier[node].children;
									for(var node1 in nextChild){
		                               i++;
					                   ind = ind-1;
					                   if (i === 1){
						                   this.data[this.data.length-1].children = [];
					                    }
									   this.data[this.data.length-1].children.push(nextChild[node1]);
				                    }
								}*/

						if (this.data < 1) {
							//	MessageBox.warning( "The selected PO does not have any items" );
						}

						var oData = [];
						oData['Items'] = data;
						oData['ServiceId'] = this.sServiceId;

						var model = new JSONModel(oData);
						this._oController._DispServicesDialog.setModel(model, "POModel");
						this._oController._DispServicesDialog.getModel("POModel").setSizeLimit(1000);
						this._oController._DispServicesDialog.getModel("POModel").refresh();

						this._oController._DispServicesDialog.setTitle('Filling Line items for PO No:' + this.sPOId + '')

						try {
							this._oController.getModel("oFlagsModel").setProperty("/bServicesBusy", false);
						} catch (ex) {}

					}.bind(this),
					error: function (oResponse, error) {
						// this.tree.setBusy(false); 
						/*var msgs = this.getErrorMessages(oResponse);
							this.instantiateErrorMessageModel(msgs);
							this.createMessagePopoverModel();*/
						//  this.getView().setBusy(false);
					}.bind(this)
				});

				/*	
					
					
					tree.bindItems({ path :  "/" + sObjectPath + "/POToESVTree",
									factory: function (sId, oContext) {
										return new sap.m.StandardTreeItem({title: "{name}"});
									},
									events: {
										dataRequested : function(oEvent) {
											tree.setBusy(true); 
										},
										dataReceived  : function(oEvent) {
											tree.setBusy(false); 
											var oPram = oEvent.getParameters();
											var aHier = [];
											$.each(oPram.data.results, function(ind, obj) {
					                           if(!aHier["L1"+obj.PCKG_NO]){
													aHier["L1"+obj.PCKG_NO]  ={name:obj.PCKG_NO, children:[]};
												}
												
												aHier["L1"+obj.PCKG_NO].children.push({name: obj.SHORT_TEXT , lineNumber :obj.LINE_NO , Children:[]});
											}.bind(this));
											
											this.data  = [];
											for (var node in aHier){
												if (aHier[node]){
													this.data.push(aHier[node]);
												}
												
											    var i = 0;
												var ind = 1;
												var nextChild = aHier[node].children;
												for(var node1 in nextChild){
                                                   i++;
								                   ind = ind-1;
								                   if (i === 1){
									                   this.data[this.data.length-1].children = [];
								                    }
												   this.data[this.data.length-1].children.push(nextChild[node1]);
							                    }
											}
											oPram.data.results = this.data;
											if(typeof oPram.data !== "undefined" && oPram.data.results < 1) {
												MessageBox.warning( "The selected PO does not have any items" );
											}
												
										}
										
									}
								});
					tree.removeSelections();
				}*/

				//}.bind(this));

			}
		},

		buildHierV2: function (flatArray, parentProperty, idProperty, rootNodeParentId) {

			var flat = {};
			for (var i = 0; i < flatArray.length; i++) {
				//if( flatArray[i]["OUTL_LEVEL"] !== 0){

				var key = 'n' + flatArray[i][idProperty];

				flatArray[i].__metadata = "";

				// flatten to object with string keys that can
				// be easily referenced later
				if (flatArray[i][parentProperty] == rootNodeParentId) {
					flatArray[i][parentProperty] = "";
				}

				flat[key] = flatArray[i];
				//}

			}

			// add child container array to each node
			for (var i in flat) {
				flat[i].children = []; // add children							&nbsp;&nbsp;
			}

			// populate the child container arrays
			for (var i in flat) {
				var parentkey = 'n' + flat[i][parentProperty];
				if (flat[parentkey]) {

					//  flat[i]['selected']= "false";
					flat[parentkey].children.push(flat[i]);
				}
			}

			// find the root nodes (no parent found) and create
			// the hierarchy tree from them
			var hierArray = [];
			for (var i in flat) {
				var parentkey = 'n' + flat[i][parentProperty];
				if (!flat[parentkey]) {
					hierArray.push(flat[i]);
				}
			}

			return hierArray;
		},

		buildHierV3: function (flatArray, parentProperty, idProperty, rootNodeParentId) {

			var flat = {};
			for (var i = 0; i < flatArray.length; i++) {
				//if( flatArray[i]["OUTL_LEVEL"] !== 0){

				var key = 'P' + flatArray[i]['PCKG_NO'] + 'L' + flatArray[i]['LINE_NO'];

				flatArray[i].__metadata = "";

				// flatten to object with string keys that can
				// be easily referenced later
				if (flatArray[i][parentProperty] == rootNodeParentId) {
					flatArray[i][parentProperty] = "";
				}

				this.updateChildrenParentID(flatArray, flatArray[i]['LINE_NO'], key)

				/*
					
				var oParent = this.getParent(flatArray , flatArray[i]['PCKG_NO']);
					
					
					
				var sParentID = "";
				if(oParent){
					sParentID = 'node_h' + oParent['PCKG_NO'] + oParent['LINE_NO'];
				}
					
					
				flatArray[i]['parentID'] = sParentID;*/
				flat[key] = flatArray[i];
				//}

			}

			// add child container array to each node
			for (var i in flat) {
				flat[i].children = []; // add children							&nbsp;&nbsp;
			}

			// populate the child container arrays
			for (var i in flat) {
				var parentkey = flat[i]['parentID'];
				if (flat[parentkey]) {

					//  flat[i]['selected']= "false";
					flat[parentkey].children.push(flat[i]);
				}
			}

			// find the root nodes (no parent found) and create
			// the hierarchy tree from them
			var hierArray = [];
			for (var i in flat) {
				var parentkey = flat[i]['parentID'];;
				if (!flat[parentkey]) {
					hierArray.push(flat[i]);
				}
			}

			return hierArray;
		},

		getParent: function (flatArray, sPackageNumber) {
			var oParent = null;
			for (var i = 0; i < flatArray.length; i++) {
				if (flatArray[i]['SUBPCKG_NO'] == sPackageNumber) {
					oParent = flatArray[i];
					break;
				}

			}

			return oParent;
		},
		updateChildrenParentID: function (aFlatArray, sLineNo, sParentKey) {
			for (var i = 0; i < aFlatArray.length; i++) {
				if (aFlatArray[i]['EXT_LINE'] == sLineNo) {
					aFlatArray[i]["parentID"] = sParentKey;
				}

			}
		},

		onSelectionChange: function (evt) {

			var source = evt.getSource();
			//var isSelected = source.getSelected();
			var oSearchModel = this._oController._DispServicesDialog.getModel("POModel");
			var selectedItem = evt.getSource().getBindingContext("POModel").getObject();
			//var index = oSearchModel.getData().indexOf(selectedItem);
			var leafModel = sap.ui.getCore().byId("selectedServicesList").getModel("selServices");
			var cObjParam = this.onAddNewService(selectedItem);

			if (selectedItem['Drill_state'] === "expanded") {
				evt.getSource().setSelected(false);
				evt.getSource().setActive(false);
				return;
			}
			var grPrice = parseFloat(cObjParam["GrPrice"]).toFixed(2);

			if ((this.sServiceId !== "" && this.sServiceId !== undefined) && (this.MultiSrvLines === false)) {
				var data = [cObjParam];
				if (grPrice !== '0.00') {
					leafModel.setData(data);
				}

				// sap.ui.getCore().byId("INITIALMENGE_txt").setText("Requested Quantity");
				// sap.ui.getCore().byId("ReqQuantity").setEditable(false);
			} else {
				//if (typeof obj !== "undefined"){
				if (!this.isItemAlreadySelected(selectedItem) && grPrice !== '0.00') {
					leafModel.getData().push(cObjParam);
				}
				//   sap.ui.getCore().byId("INITIALMENGE_txt").setText("Proposed Quantity");
				//sap.ui.getCore().byId("ReqQuantity").setEditable(true);
			}

			if (cObjParam["NODEID"] === "DUMMYSRV") {
				if (!this.isItemAlreadySelected(selectedItem) && cObjParam["NODEID"] === "DUMMYSRV") {
					leafModel.getData().push(cObjParam);
				}
			}

			leafModel.refresh();
			this.checkTableItems();

			this.calculateTotalCost();
		},

		onModelContextChange: function (oEvent) {
			var sId = oEvent.getParameter("id");
			var tbl = sap.ui.getCore().byId(sId);
			var header = tbl.$().find('thead');
			var selectAllCb = header.find('.sapMCb');
			selectAllCb.remove();

			tbl.getItems().forEach(function (r) {
				var obj = r.getBindingContext("POModel").getObject();

				/*debugger;*/
				var bSelectable = obj.SERV_IND === "X";
				var cb = r.$().find('.sapMCb');
				var oCb = sap.ui.getCore().byId(cb.attr('id'));

				if (oCb) {
					if (!bSelectable) {
						oCb.setEnabled(false);
					} else {
						oCb.setEnabled(true);
					}
				}

			});
		},

		isItemAlreadySelected: function (item) {
			var leafModel = sap.ui.getCore().byId("selectedServicesList").getModel("selServices");
			var oData = leafModel.getData();

			var bItemFound = false;
			//$.each(oData,function(ind,obj){

			for (var ind in oData) {
				if (oData[ind]['PckgNo'] === item['PCKG_NO'] && oData[ind]['LineNo'].toString() == item['LINE_NO']) {
					sap.m.MessageToast.show("This is already added!");
					bItemFound = true;
					break;
				}
			}

			//}.bind(this));

			return bItemFound;

		},

		addGrPrice: function (evt) {
			var leafModel = sap.ui.getCore().byId("selectedServicesList").getModel("selServices");

			if (evt.getSource().getValue().length > 8) {
				evt.getSource().setValue(evt.getSource().getValue().slice(0, -1))
			} else {
				var oValue = evt.getParameter('value');
				var gObject = evt.getSource().getParent().getBindingContext("selServices").getObject();
				var nGrPrice = Number(oValue) * Number(gObject['GrPrice']);
				evt.getSource().getParent().getBindingContext("selServices").getObject()['InitialMenge'] = nGrPrice.toFixed(2);
				leafModel.refresh();
				this.calculateTotalCost();

			}
		},

		calculateTotalCost: function () {
			var leafModel = sap.ui.getCore().byId("selectedServicesList").getModel("selServices");
			var oSelData = leafModel.getData();
			var nActualGRPrice = '';
			for (var ind in oSelData) {
				if (ind == 0) {
					nActualGRPrice = oSelData[ind]['InitialMenge'];
				} else {
					nActualGRPrice = Number(nActualGRPrice) + Number(oSelData[ind]['InitialMenge']);
				}
			}

			var viewModelData = sap.ui.getCore().byId("selectedServicesList").getModel("ViewModel").getData();

			var oActualGRPrice = Number(nActualGRPrice);
			viewModelData["TotalCost"] = oActualGRPrice.toFixed(2);
			sap.ui.getCore().byId("selectedServicesList").getModel("ViewModel").refresh();

		},

		checkTableItems: function (obj) {
			var oTableItems = sap.ui.getCore().byId("treeMaster").getItems();
			$.each(oTableItems, function (ind, obj) {
				if (typeof obj !== "undefined") {
					obj.setSelected(true);
				} else {
					obj.setSelected(false);
				}

			});
			var oTreeModel = sap.ui.getCore().byId("treeMaster").getModel("POModel");
			if (oTreeModel) {
				oTreeModel.refresh();
			}

		},

		/*		
				// on mode select
				onDeleteService :function(evt){
		            var oSelectedTableItem = evt.getParameter("listItem").getBindingContext("selServices").getObject(); 
		            var sSelTabItemProperty = oSelectedTableItem['Serviceid'];
		            var aTreeItems =  sap.ui.getCore().byId("treeMaster");
		            for(var x=0; x<aTreeItems.getItems().length; x++){
						var oTempItemData = aTreeItems.getItems()[x].getBindingContext("POModel").getObject(); 
						if (sSelTabItemProperty === oTempItemData['Serviceid']){
							oTempItemData['selected'] = false;
						}
		            }
		            aTreeItems.getModel("POModel").refresh();
		            var oSearchModel = aTreeItems.getModel("POModel");
		            var index = oSearchModel.getData().indexOf(oSelectedTableItem);
		            oSearchModel.getData().splice(index,1);
		            oSearchModel.refresh();
		            this.checkTableItems();
				},	*/

		onDeleteService: function (oEvent) {
			//this.savedFlag = false;
			this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", false);
			var oObj = oEvent.getSource().getBindingContext("selServices").getObject();
			var selectedServicesTable = sap.ui.getCore().byId("selectedServicesList");
			var index = selectedServicesTable.indexOfItem(oEvent.getSource().getParent());
			selectedServicesTable.getModel("selServices").getData().splice(index, 1);
			// this.oServices.getProperty("/").splice(index,1);
			// if(this.oServices.getProperty("/").length < 1) {
			//   sap.ui.getCore().byId("changepobtn").setVisible(true);
			// }

			selectedServicesTable.getModel("selServices").refresh();
			// this.oServices.refresh();

			this._calculateCost();
			this.checkTableItems();

		},

		onTreeSearchMaster: function (evt) {

			var oTable = sap.ui.getCore().byId("treeMaster");
			var oBinding = oTable.getBinding("items");
			oTable.expandToLevel(100);
			var aFilters = [];
			var sQuery = evt.getSource().getValue();

			/*	const aWords = sQuery.split(" ");
				var sWord = "";
				for(var x = 0 ; x < aWords.length ; x++){
					sWord = aWords[x];
					aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord.toLowerCase()));
					aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord.toUpperCase()));
					if (sWord !==""){
						aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord[0].toUpperCase() + sWord.substr(1).toLowerCase()));
					}
					
					aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord));
				}
				var oFilter = [ new sap.ui.model.Filter(aFilters,false)];
				oBinding.filter(oFilter);*/

			aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sQuery, false));
			var oFilter = [new sap.ui.model.Filter(aFilters, false)];
			oBinding.filter(oFilter);

		},

		TreeFormat: function (result) {
			var aHier = [];
			$.each(oData.results, function (ind, obj) {

				if (!aHier["L1" + obj.PCKG_NO]) {
					aHier["L1" + obj.PCKG_NO] = {
						name: obj.PCKG_NO,
						Children: []
					};
				}

				aHier["L1" + obj.PCKG_NO].Children.push({
					name: obj.SHORT_TEXT,
					lineNumber: obj.LINE_NO,
					Children: []
				});

			}.bind(this));
			console.log(aHier);
			return aHier;
		},

		_bindView: function (sObjectPath) {
			var that = this._oController;

			sap.ui.getCore().bindElement({
				path: sObjectPath,
				events: {
					//change : this._onBindingChange.bind(this),
					dataRequested: function () {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);

					}
				}
			});

		},

		/*			treeChange : function(oEvent) {
						
						var oContx = oEvent.getSource().getBindingContext("POModel");
						if (oContx.getObject()['children'].length>0){
							 var sSubPackageNum = oContx.getObject()['SUBPCKG_NO'];
						     var data = [];
							     $.each(this.flatArray,function(ind,obj){
								   if (obj['PCKG_NO'] === sSubPackageNum){
									data.push(obj);
								 }
						      }.bind(this))
						 }else {
							 var data =  [oContx.getObject()];
						 }
						 var leafTable =  sap.ui.getCore().byId("LeafNodeTable");
				         var model =  new JSONModel(data);
		                 leafTable.setModel(model,"LeafModel");
		                 leafTable.getModel().refresh(); 
						/*var sEBELN = oContx.getProperty("EBELN"),
							sEBELP = oContx.getProperty("EBELP"),
							sPKG   = oContx.getProperty("SUBPCKG_NO");
						*/
		//console.log(sEBELN);
		// this.loadLeaf(oContx.getObject());  
		// this._navToNode(sEBELN,sEBELP,sPKG);
		/*	},*/

		treeCellClick: function (oEvent) {

			if (typeof oEvent.getParameters().rowBindingContext === "undefined") return;
			var sEBELN = oEvent.getParameters().rowBindingContext.getProperty("EBELN"),
				sEBELP = oEvent.getParameters().rowBindingContext.getProperty("EBELP"),
				sPKG = oEvent.getParameters().rowBindingContext.getProperty("SUBPCKG_NO"),
				tree = sap.ui.getCore().byId("tree");
			tree.setSelectedIndex(oEvent.getParameters().rowIndex);
			this._navToNode(sEBELN, sEBELP, sPKGm, sRECORD_NO, TXZ01);
		},

		/*	loadLeaf :function(item){
				 var sSubPackageNum = item['SUBPCKG_NO'];
			     var array = [];
			     $.each(this.flatArray,function(ind,obj){
				   
				   if (obj['PCKG_NO'] === sSubPackageNum){
					array.push(obj);
				}
				 
			   }.bind(this))
				
				return array;
			},
			*/
		_navToNode: function (sEBELN, sEBELP, sPKG, sRECORD_NO) {

			/*this.getRouter().navTo("DispatchedServices", {
				objectId 	: this.sReqId, 
				item		: this.sItemId, 
				EBELN		: sEBELN, 
				EBELP		: sEBELP,
				pkg_num		: sPKG,
				lim_ind		: this.sLim_ind,
				co_ind		: this.sCo_ind 
			}, true);*/

			// Instantiate Tree Master
			this._onLogMatched(this.sReqId, this.sItemId, sEBELN, sEBELP, sPKG, this.sLim_ind, this.sCo_ind);

			// Instantiate ESV Items
			this._onESVMatched(this.sReqId, this.sItemId, sEBELN, sEBELP, sPKG, this.sLim_ind, this.sCo_ind);
		},

		/*			onNavBack: function(oEvent) {
						var savedDispFlag = this._oController.getOwnerComponent().getModel("appView").getProperty("/savedDispFlag");
						
						if (!savedDispFlag){
							sap.m.MessageBox.confirm(
								"Are you sure you want to dismiss All the changes?", {
									styleClass: this._oController.getOwnerComponent().getContentDensityClass(),
									onClose: function(oAction) {
											if (oAction === sap.m.MessageBox.Action.OK) {
												this.navBack();
											}
									}.bind(this)
								}
							);
						}
						
						else {
							this.navBack();	
						}
						
						
					},*/

		onCOPress: function (oEvent) {
			var oPOBtn = sap.ui.getCore().byId("POBtn");
			var oCOBtn = oEvent.getSource();

			/* Old
			oCOBtn.setPressed(true);
				
			if(oPOBtn.getPressed()) {
				oPOBtn.setPressed(false);
			}
			*/

			//ASSIAA0F - onCO toggle based on config
			// depend on config to allow contract 

			// ViewModel
			var oViewModel = new JSONModel({
				currentType: "F",
				searchValue: "",
				POdialog: true,
				COdialog: true
			});

			this._oViewModel = oViewModel;

			// Show/Hide COTRACT/PO tabs per config
			var oFieldsOps = this._oController.getOwnerComponent().oFieldsOps
			var oPOtabDialog = oFieldsOps.getFieldbyId("POTABDIALOG");
			var oCOtabDialog = oFieldsOps.getFieldbyId("COTABDIALOG");

			if (oCOtabDialog.Visible === 'X') {
				oCOBtn.setPressed(true);

				if (oPOBtn.getPressed()) {
					oPOBtn.setPressed(false);
				}

				// Instantiate Tree Master
				this._onLogMatched(this.sReqId, this.sItemId, this.sPOId, this.sPOItemId, this.sPkgNo, this.sLim_ind, "CO");

				// Instantiate ESV Items
				this._onESVMatched(this.sReqId, this.sItemId, this.sPOId, this.sPOItemId, this.sPkgNo, this.sLim_ind, "CO");
			} else {
				oCOBtn.setPressed(false);
				oPOBtn.setPressed(true);
				MessageBox.warning("Contact selection disabled");
				//message for no CO
			}

			// end ASSIAA0F

		},

		onPOPress: function (oEvent) {
			var oCOBtn = sap.ui.getCore().byId("COBtn");
			var oPOBtn = oEvent.getSource();

			oPOBtn.setPressed(true);

			if (oCOBtn.getPressed()) {
				oCOBtn.setPressed(false);
			}

			/*this.getRouter().navTo("DispatchedServices", {
				objectId 	: this.sReqId, 
				item		: this.sItemId, 
				EBELN		: this.sPOId , 
				EBELP		: this.sPOItemId,
				pkg_num		: this.sPkgNo,
				lim_ind		: this.sLim_ind,
				co_ind		: "PO"	
			}, true);*/

			// Instantiate Tree Master
			this._onLogMatched(this.sReqId, this.sItemId, this.sPOId, this.sPOItemId, this.sPkgNo, this.sLim_ind, "PO");

			// Instantiate ESV Items
			this._onESVMatched(this.sReqId, this.sItemId, this.sPOId, this.sPOItemId, this.sPkgNo, this.sLim_ind, "PO");

		},

		navBack: function () {
			this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", true);
			this._oController.getOwnerComponent().getModel("appView").setProperty("/navBackMTreeFlag", true);

			//var oESVItemsTable  =   sap.ui.getCore().byId("servicesList");
			//oESVItemsTable.unbindItems();

			/*this._oController.getRouter().navTo("object", {
				objectId 	: this.sReqId,
				year		: this._oController.getReqYear(),
				action 		: "view",
				item		: this.sItemId,
				folder		: this._oController.getFolder(),
				WFType		: this._oController.getWFType()
			});*/

			this.sReqId = "";
			this.sItemId = "";
			this.sPOId = "";
			this.sPOItemId = "";

			this._oFragment.close();
		},

		/* =========================================================== */
		/* Event Handler                                               */
		/* =========================================================== */

		/**
		 * This function will be called when clicking on Add button.
		 * 
		 * @public
		 */

		onAddNewService: function (selectedItem) {
			var ServiceId = "";
			var Data = this._oController.getModel("itemsModel").getObject("/HeaderToItemNav");
			for (var i = 0; i < Data.length; i++) {
				if (Data[i].Zeile === this.sItemId) {
					ServiceId = Data[i].ServiceId;
				}
			}

			/*  if((ServiceId !=="") && (this.oServices.getProperty("/").length !== 0)){
				 // sap.m.MessageBox.error("Cannot select more than one service for this line item");
				  return;
			  }*/
			//this.savedFlag = false;
			this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", false);

			//var oSelObj = oEvent.getSource().getBindingContext().getObject(),

			var oSelObj = selectedItem,

				//  var oSelObj = oEvent.getSource().getParent().getBindingContext('LeafModel').getObject(),
				oObj = {};

			// Check if there is already exisiting record with the same PKJ/LINE
			var iIndex = $.inArray(oSelObj.KONT_PACK + oSelObj.KONT_ZEILE,
				$.map(this.oServices.getObject("/"), function (n) {
					return n.PckgNo + n.LineNo
				}));

			if (iIndex !== -1) { // In case a record exsists, Increase the quantity by 1 
				if (this._oViewModel.getProperty("/InitMengeDisplay")) {

					var iQuan = parseInt(this.oServices.getObject("/" + iIndex).InitialMenge);
					iQuan += 1;
					iQuan = iQuan + "";
					this.oServices.getObject("/" + iIndex).InitialMenge = iQuan;
					this.oServices.refresh();
					return;

				} else if (this._oViewModel.getProperty("/MengeDisplay")) {

					var iQuan = parseInt(this.oServices.getObject("/" + iIndex).Menge);
					iQuan += 1;
					iQuan = iQuan + "";
					this.oServices.getObject("/" + iIndex).Menge = iQuan;
					this.oServices.refresh();
					return;
				}

			}
			// In case no record, Add to the list.

			// Set the properties
			oObj.PoNo = oSelObj.EBELN;
			oObj.PoItem = oSelObj.EBELP;

			oObj.Docno = this.Docno;
			oObj.Zeile = this.Zeile;
			//oObj.Mjahr = "";

			/* oObj.PckgNo   = oSelObj.KONT_PACK;
		        oObj.LineNo   = oSelObj.KONT_ZEILE;
		        oObj.Txz01    = oSelObj.Short_text;
		        oObj.Meins    = oSelObj.UOM;
*/
			oObj.PckgNo = oSelObj.PCKG_NO;
			oObj.LineNo = oSelObj.LINE_NO.toString();
			oObj.Txz01 = oSelObj.SHORT_TEXT;
			oObj.Meins = oSelObj.BASE_UOM;

			oObj['OUTL_NO'] = oSelObj['OUTL_NO'];
			//oObj.GrPrice  = Number.parseFloat(oSelObj.GR_PRICE).toExponential();
			//oObj.GrPrice  = new sap.ui.model.odata.type.Decimal().parseValue(oSelObj.GR_PRICE,"float");
			/*   oObj.GrPrice  = parseFloat(oSelObj.GR_PRICE) + "";*/
			oObj.GrPrice = oSelObj.GR_PRICE.toString();

			oObj.ContractItem = oSelObj.CONTRACT_ITEM;
			oObj.ContractNo = oSelObj.CONTRACT_NO;
			oObj.Curr = oSelObj.CURR;
			oObj.ContRef = oSelObj.CONT_REF;
			oObj.Extrow = (oSelObj.EXTROW).toString();

			oObj.Menge = "0";

			if (this.sServiceId !== "") {
				/*oObj.Menge      = Number(this.sMenge).toFixed(2);*/
				oObj.Menge = Number(this.sMenge).toFixed(3);
			}

			var actualMeng = Number(oObj.Menge) * Number(oSelObj.GR_PRICE);
			oObj.InitialMenge = actualMeng.toFixed(2);

			// Add Discount
			oObj.Discount = "0";

			oObj.NODEID = oSelObj.NODEID;

			oObj.NonCharge = oSelObj.NonCharge;

			// Push the object to model
			// this.oServices.getProperty("/").push(oObj);

			// Refresh
			this.oServices.refresh();

			this._calculateCost();

			return oObj;
		},

		/**
		 * This function will be called when a change happened in input field.
		 * 
		 * @public
		 */

		detectLiveChange: function () {
			this.savedFlag = false;
			this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", false);
		},

		/**
		 * This function will be called when a change happened in input field.
		 * 
		 * @public 
		 */

		onlyDecimal: function (oEvent) {
			this.savedFlag = false;
			this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", false);

			var nValue = Number(oEvent.getParameter('value'));
			//var sResult = formatter.toDecimal(oEvent, true);
			this._calculateCost();
			return nValue;
		},

		/**
		 * This function will be called when clicking on Delete button.
		 * onListCheck
		 * @public
		 */

		/**
		 * This function will be called when clicking on Save button.
		 * 
		 * @public
		 */

		/*		      onSavePress : function(oEvent) {

				        var obj = {
				                Docno   : this.Docno,
				                Zeile   : this.Zeile,
				                toESVItems  : this.oServices.getObject("/")
				              },
				          that = this._oController;
				        
				        if (!this._validateCalculatedCost()) {
					      	  MessageBox.error("Total cost should be greater than zero.");
					      	  that.getView().setBusy(false);
					            return;
					  	  }
				        
				        if (!this._oConfirmFragment) {
			                this._oConfirmFragment = sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.DispatchedServicesSplitConfirm", this);
			              }

				        this._oController.getView().addDependent(this._oConfirmFragment);

			              this._oConfirmFragment.setModel(this._oViewModel, "ViewModel");
			              
			              // Assign the model to the table.
			              var selectedServicesTable   =  sap.ui.getCore().byId("selectedServices");
			              selectedServicesTable.setModel(this._oViewModel, "ViewModel");
			              selectedServicesTable.setModel(this.oServices,"selServices");
			              
			           // forward compact/cozy style into Dialog
			              this._oConfirmFragment.addStyleClass(this._oController.getOwnerComponent().getContentDensityClass());
			              
			              this.formatConfirmFields();
			              
			              this._calculateCost();
			
			              this._oConfirmFragment.open();


				        /*that.getView().setBusy(true);

				        this._saveServices(obj).then(function(date){
				            MessageToast.show("Service line items have been successfully saved.");
				            //this.savedFlag = true;
				            this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", true);
				            that.getView().setBusy(false);
				        }.bind(this))
				          .catch(function(){
				            MessageToast.show("An error occured while saving.");
				            that.getView().setBusy(false);
				        });

				      },*/

		/**
		 * This function will be called when clicking on Change PO button.
		 * 
		 * @public
		 */

		ChangePO: function (oEvent) {
			//console.log(sap.ui.getCore().byId("selectedServicesList").getItems().length);

			if (sap.ui.getCore().byId("selectedServicesList").getItems().length > 0) {
				MessageBox.error("There are items releted to the selected PO, They must be removed first.");
				return;
			}

			var oModel = this._oController.getOwnerComponent().getModel("VendorService");

			var oItemPath = oModel.createKey("ReqItemsSet", {
				Docno: this.Docno,
				Zeile: this.Zeile,
				Mjahr: this._oController.Mjahr
			});

			//console.log(oItemPath);

			new POContractSelector(this._oController.getView(), oModel, this._oController,
				this._oController.getVendor(), this._oController.getReqType(),
				function (oPOItem) {

					this._oPOItem = oPOItem;

					//console.log(oPOItem);

					// Store the new PO/Line item in the Request item
					// As for each line item, a po and po line item
					oModel.callFunction("/SetPOForReqItm", {
						method: "GET",

						urlParameters: {
							Docno: this.Docno,
							Zeile: this.Zeile,
							PO: oPOItem.EBELN,
							PONO: oPOItem.EBELP,
							Limit_ind: oPOItem.Limit_ind,
							Co_ind: oPOItem.Co_ind

						},
						success: function (oData) {
							//this.savedFlag = false;
							// this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", false);

							sap.ui.getCore().byId("servicesList").unbindItems();

							oModel.setProperty("/" + oItemPath + "/PoItem", oPOItem.EBELP);
							oModel.setProperty("/" + oItemPath + "/PoNum", oPOItem.EBELN);
							oModel.setProperty("/" + oItemPath + "/Limit_ind", oPOItem.Limit_ind);
							oModel.setProperty("/" + oItemPath + "/Co_ind", oPOItem.Co_ind);

							//this.getRouter().navTo("DispatchedServices", {objectId : this.Docno , item: this.Zeile, EBELN: oPOItem.EBELN, EBELP: oPOItem.EBELP, lim_ind: oPOItem.Limit_ind, co_ind: oPOItem.Co_ind  }, true);

							// Instantiate Tree Master
							this._onLogMatched(this.Docno, this.Zeile, oPOItem.EBELN, oPOItem.EBELP, undefined, oPOItem.Limit_ind, oPOItem.Co_ind);

							// Instantiate ESV Items
							this._onESVMatched(this.Docno, this.Zeile, oPOItem.EBELN, oPOItem.EBELP, undefined, oPOItem.Limit_ind, oPOItem.Co_ind);

						}.bind(this),
						error: function (error) {
							MessageToast.show("An error occured while changing PO.");
						}
					});

				}.bind(this));

			//this._showPODialog();

		},

		/**
		 * This function will be called when changing quantity.
		 * 
		 * @public
		 */
		mengeChange: function (oEvent) {

			this._calculateCost();
		},

		/**
		 * This function will be called when clicking on Back button.
		 * 
		 * @public
		 */

		onNavBack: function (oEvent) {
			var savedDispFlag = this._oController.getOwnerComponent().getModel("appView").getProperty("/savedDispFlag");
			if (!savedDispFlag) {
				sap.m.MessageBox.confirm(
					"Are you sure you want to dismiss All the changes?", {
						styleClass: this._oController.getOwnerComponent().getContentDensityClass(),
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.OK) {

								this.navBack();
								this._oController.getModel().refresh();
							}
						}.bind(this)
					}
				);
			} else {
				this.navBack();
				this._oController.getModel().refresh();
			}
		},

		/**
		 * This function will called to nav back .
		 * 
		 * @public
		 */

		/*		      navBack : function () {
				        var oServicesList = sap.ui.getCore().byId("servicesList");
				        var oSelectedServicesList = sap.ui.getCore().byId("selectedServicesList");
				        this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", true);

				        //oServicesList.unbindItems();
				        //oSelectedServicesList.unbindItems();
				        this.oServices.setProperty("/", []);

				        this._oController.getRouter().navTo("object", {
				                objectId  : this.Docno,
				                year      : this._oController.getReqYear(),
				                item      : this.Zeile,
				                action    : "view",
				                folder    : this._oController.getFolder(),
				                WFType    : "M"
				              });
				        
				        this._oFragment.close();
				        
				      },*/

		/**
		 * This function will be called when clicking OK in the Select PO pop-up.
		 * 
		 * @public
		 */

		onOKNavToDispServ: function (oEvent) {
			var oPOList = sap.ui.getCore().byId("changePO--POList");

			var oSelectedPO = oPOList.getSelectedItem().getBindingContext("POItems").getObject();

			var oModel = this._oController.getOwnerComponent().getModel("VendorService");

			var sVendor = this._oController.getVendor();

			if (typeof oSelectedPO !== "undefined") {

				// Store the new PO/Line item in the Request item
				// As for each line item, a po and po line item
				oModel.callFunction("/SetPOForReqItm", {
					method: "GET",

					urlParameters: {
						Docno: this.Docno,
						Zeile: this.Zeile,
						PO: oSelectedPO.EBELN,
						PONO: oSelectedPO.EBELP,
						Limit_ind: oSelectedPO.Limit_ind,
						Co_ind: oSelectedPO.Co_ind

					},
					success: function (oData) {
						sap.ui.getCore().byId("servicesList").unbindItems();

						//this.getRouter().navTo("DispatchedServices", {objectId : this.Docno , item: this.Zeile, EBELN: oSelectedPO.EBELN, EBELP: oSelectedPO.EBELP }, true);

						// Instantiate Tree Master
						this._onLogMatched(this.Docno, this.Zeile, oSelectedPO.EBELN, oSelectedPO.EBELP, undefined, undefined, undefined);

						// Instantiate ESV Items
						this._onESVMatched(this.Docno, this.Zeile, oSelectedPO.EBELN, oSelectedPO.EBELP, undefined, undefined, undefined);

						//console.log("unbinding...");
					}.bind(this),
					error: function (error) {
						MessageToast.show("An error occured while changing PO.");
					}
				});

			}

			this._PODialog.close();
		},

		/**
		 * This function will be called when clicking on Cancel button in the Select PO pop-up.
		 * 
		 * @public
		 */
		onCancelPO: function (oEvent) {
			this._PODialog.close();
		},

		/*showHistoryChange : function(oEvent){
		    	  var oModel  = this._oController.getOwnerComponent().getModel();
//		          var oItems = sap.ui.getCore().byId("lineItemsList").getItems();
//		          var aItems = [];
//		          
//		          for(var i = 0; i < oItems.length ; i++) {
//		            aItems.push(oItems[i].getBindingContext().getObject());
//		          }
		          
//		          console.log(oItems);
		          new changeHistory(this._oController.getView(), oModel, this._oController, this.Docno,this.Zeile );
		      },*/

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * This function is used to submit line items as deep entity
		 * "VendorESVHeaderSet"
		 * Request Id
		 * Item Id
		 * toESVItems :[] list of selected services
		 * 
		 * @public
		 */

		_saveServices: function (obj) {

			var oData = this._oController.getOwnerComponent().getModel("VendorService"),
				reqModel = this._oController.getOwnerComponent().getModel("VendorService");
			var that = this;
			for (var ind in obj['toESVItems']) {

				delete obj['toESVItems'][ind]['OUTL_NO'];
				delete obj['toESVItems'][ind]['NODEID'];
			}

			var oPromise = new Promise(function (resolve, reject) {

				oData.create("/VendorESVHeaderSet", obj, {
					success: function (data) {
						resolve(data);
					},
					error: function (error) {
						sap.m.MessageBox.error(JSON.parse(error.responseText).error.innererror.errordetails[0].message);
						that._oController.getView().setBusy(false);
					}
				});
			});
			return oPromise;

		},

		/**
		 * This function is used to get ESV line items 
		 * "RequestItemSet/toVendorESV"
		 * After getting the data the model "this.oServices" will have the
		 * the values. 
		 * 
		 * @public
		 */

		_getReqServices: function (Docno, Zeile) {

			var oModel = this._oController.getOwnerComponent().getModel("VendorService"),
				that = this._oController;

			var oChangePoBtn = sap.ui.getCore().byId("changepobtn");

			//this.getModel().metadataLoaded().then( function() {

			var sObjectPath = oModel.createKey("ReqItemsSet", {
				Docno: Docno,
				Zeile: Zeile,
				Mjahr: this._oController.Mjahr
			});

			oModel.read("/" + sObjectPath + "/toVendorESV", {
				success: function (data) {
					this.data = [];
					// var data = this.changeObjEntrys(data);
					$.each(data['results'], function (ind, obj) {
						var obj1 = {};
						obj1['PckgNo'] = obj['PckgNo'];
						obj1['LineNo'] = obj['LineNo'];
						obj1['Txz01'] = obj['Txz01'];
						obj1['Meins'] = obj['Meins'];
						obj1['GrPrice'] = obj['GrPrice'];
						obj1['Curr'] = obj['Curr'];
						obj1['Discount'] = obj['Discount'];
						//obj1['InitialMenge'] = obj['InitialMenge'];
						obj1['Menge'] = obj['Menge'];
						obj1['PoNo'] = obj['PoNo'];
						obj1['Zeile'] = obj['Zeile']; // not There
						obj1['Docno'] = obj['Docno'];
						obj1['PoItem'] = obj['PoItem'];
						obj1['OUTL_NO'] = obj['OutlNo'];
						obj1.Extrow = obj['Extrow'];
						obj1.Jobid = obj['Jobid'];
						//obj1['Menge'] = this.sMenge;
						/*if (this.sServiceId !== ""){
								obj1['Menge'] = this.sMenge;
							}else {
								obj1['Menge'] = '0';
							}
						*/
						var oActualMenge = Number(obj['GrPrice']) * Number(obj1['Menge']);
						obj1['InitialMenge'] = oActualMenge.toFixed(2);

						this.data.push(obj1);
					}.bind(this));

					var leafTable = sap.ui.getCore().byId("selectedServicesList");
					var model = new JSONModel(this.data);
					leafTable.setModel(model, "selServices");
					leafTable.getModel("selServices").refresh();

					// this.oServices.setData(data.results);

					// If no items saved already...
					//if(data.results.length < 1) {
					//  console.log("no items...");
					//  oChangePoBtn.setVisible(true);
					//} else {
					//  console.log("there are items");
					//  oChangePoBtn.setVisible(false);
					//}

					this.oServices.refresh();
					this._calculateCost();
				}.bind(this),
				error: function (error) {

				}
			});
			//    this.calculateTotalCost();
			//});

		},

		/*        DispItmFactory : function(id,context) { 
		            

		            var oItem = new sap.m.ColumnListItem({
		                cells : [
		                  new sap.m.Text({
		                    text: "{KONT_PACK}"
		                  }),
		                  new sap.m.Text({
		                     text: "{KONT_ZEILE}"
		                  }),
		                  new sap.m.Text({
		                   text: "{Short_text}"
		                  }),
		                  new sap.m.Text({
		                     text: "{UOM}"
		                   }),
		                  new sap.m.Text({
		                     text: formatter.currencyValue(context.getProperty("GR_PRICE"))
		                     
		                   }), 
		                  new sap.m.Text({
		                     text: "{CURR}"
		                   }),  
		                  new sap.m.Button({
		                     icon: "sap-icon://add",
		                     press: this.onAddNewService.bind(this)
		                  }) 
		                  ]});
		            
		            return oItem;
		            
		          },*/

		/**
		 * Binds the view to the given PO/Line item and fetch line items of the table
		 * and binds them.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'DispatchedServices'
		 * @private
		 */
		/*  changeObjectData:function(){
	            },*/

		/*       changeObjEntrys :function(oData){
	             	this.data = [];
                    $.each(oData['results'],function(ind,obj){
								
								if (obj['CURR']){
									var obj1 = {};
									obj1['PckgNo'] = obj['KONT_PACK'];
									obj1['LineNo'] = this.Zeile; 
									obj1['Txz01'] = obj['Short_text'];
									obj1['Meins'] = obj['UOM'];
									obj1['GrPrice'] = obj['GR_PRICE'].toString();
									obj1['Curr'] = obj['CURR'];
									obj1['Discount'] = "0";
									obj1['InitialMenge'] = "0";
									obj1['Menge'] = "0";
									obj1['PoNo'] = obj['EBELN'];
									obj1['Zeile'] = this.Zeile; // not There
									obj1['Docno'] = this._objectId;
									obj1['PoItem'] = obj['EBELP'];
									this.data.push(obj1);
								}else{
									
									
									
								}
								
								
							}.bind(this));
							
	                return this.data;
               },*/

		callESVtems: function (aFilters) {
			if (controller._DispServices) {
				// if (this._oController._DispServices._oController._DispServicesDialog){
				controller._DispServices._oFragment.setBusy(true);

				//  }
				//    this._oController._DispServices._oController._DispServicesDialog.setBusy(true)
			}

			var oModel = this._oController.getModel("oDataModel");
			oModel.read("/ESVItemSet", {
				filters: aFilters,
				success: function (oData) {
					var leafTable = sap.ui.getCore().byId("selectedServicesList");
					this.serviceModel = leafTable.getModel("selServices");

					if (oData['results'].length > 0) {
						// var odata = this.changeObjEntrys(oData);
						this.data = [];
						$.each(oData['results'], function (ind, obj) {
							var obj1 = {};
							obj1['PckgNo'] = obj['KONT_PACK'];
							//obj1['LineNo'] = this.Zeile; 
							obj1['Txz01'] = obj['Short_text'];
							obj1['Meins'] = obj['UOM'];
							obj1['GrPrice'] = obj['GR_PRICE'].toString();
							obj1['Curr'] = obj['CURR'];
							obj1['Discount'] = "0";
							obj1['PoNo'] = obj['EBELN'];
							obj1['Zeile'] = this.Zeile; // not There
							obj1['Docno'] = this._objectId;
							obj1['PoItem'] = obj['EBELP'];
							obj1['OUTL_NO'] = obj['OUTL_NO'];

							obj1['PoConsum'] = obj['PoConsum'];
							obj1['PoPerce'] = obj['PoPerce'];
							obj1['PoValue'] = obj['PoValue'];
							obj1['PoPerLimit'] = obj['PoPerLimit'];
							//obj1['Extrow'] = obj['KONT_ZEILE'];

							obj1['LineNo'] = obj['KONT_ZEILE'];
							obj1['Extrow'] = obj['OUTL_NO'];

							if (this.sServiceId !== "") {
								obj1['Menge'] = this.sMenge;
							} else {
								obj1['Menge'] = '0';
							}

							var oActualMenge = obj['GR_PRICE'] * Number(obj1['Menge']);
							obj1['InitialMenge'] = oActualMenge.toFixed(2);
							//obj1['InitialMenge'] = obj['GR_PRICE'] * Number(obj1['Menge']).toFixed(2);

							if (this.serviceModel.getData().length === 0) {
								this.serviceModel.getData().push(obj1);
							} else {
								this.serviceModel.getData()[0].PoConsum = obj['PoConsum'];
								this.serviceModel.getData()[0].PoPerce = obj['PoPerce'];
								this.serviceModel.getData()[0].PoValue = obj['PoValue'];
								this.serviceModel.getData()[0].PoPerLimit = obj['PoPerLimit'];
							}

						}.bind(this));
						leafTable.getModel("selServices").refresh();
					}
					if (controller._DispServices) {
						//if (this._oController._DispServices._oController._DispServicesDialog){
						controller._DispServices._oFragment.setBusy(false);

						//}
					}
				}.bind(this),
				error: function (oResponse, error) {
					/* this.tree.setBusy(false); 
			                var msgs = this.getErrorMessages(oResponse);
							this.instantiateErrorMessageModel(msgs);
							this.createMessagePopoverModel();
							  this.getView().setBusy(false);*/
				}.bind(this)
			});
			this.calculateTotalCost();
		},

		_onESVMatched: function (objectId, item, EBELN, EBELP, pkg_num, lim_ind, co_ind, serviceId, srvText) {
			var oModel = this._oController.getOwnerComponent().getModel();

			var sReqId = objectId,
				sItemId = item,
				sPOId = EBELN,
				sPOItemId = EBELP,
				sPkg_num = pkg_num,
				sLim_ind = lim_ind,
				sCo_ind = co_ind,
				sServiceId = serviceId,

				selectedServicesTable = sap.ui.getCore().byId("selectedServicesList"),
				sObjectPath,
				that = this._oController;

			this.srvText = this.srvText;

			//  var oESVItemsTable  =   sap.ui.getCore().byId("servicesList");

			var navBackMTreeFlag = this._oController.getOwnerComponent().getModel("appView").getProperty("/navBackMTreeFlag");
			//console.log("navBackMTreeFlag = "+ navBackMTreeFlag);
			if (navBackMTreeFlag) {
				this.oServices.setProperty("/", []);
				this._oController.getOwnerComponent().getModel("appView").setProperty("/navBackMTreeFlag", false);
			}

			//		            if((typeof this._sReqId == "undefined" || this._sReqId == sReqId)&&
			//		               (typeof this._sItemId == "undefined" || this._sItemId == sItemId)&&
			//		               (typeof this._sPOId == "undefined" || this._sPOId == sPOId)&&
			//		               (typeof this._sPOItemId == "undefined" || this._sPOItemId == sPOItemId)&&
			//		               (typeof this._sPkg_num == "undefined" || this._sPkg_num == sPkg_num)
			//		               ){
			//		              console.log("Adnan");
			//		              console.log("this._sPOId = "+ this._sPOId + "\t sPOId = "+ sPOId);
			//		              console.log("this._sPOItemId = "+ this._sPOItemId + "\t sPOItemId = "+ sPOItemId);
			//
			//		              this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", true);
			//		            }
			//		            else 
			if (this._sReqId != sReqId || this._sItemId != sItemId) {
				this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", true);
			} else {
				//this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", false);
				//this.savedFlag = false;
			}

			var bCoFlg = (this._sCo_ind !== sCo_ind);

			this._sReqId = sReqId;
			this._sItemId = sItemId;
			this._sPOId = sPOId;
			this._sPOItemId = sPOItemId;
			this._sPkg_num = sPkg_num;
			this._sCo_ind = sCo_ind;
			this._sLim_ind = sLim_ind;

			if (bCoFlg && (sPOId.substring(0, 2) !== "66")) {

				// 	  oESVItemsTable.unbindItems();

				/*this.getRouter().navTo("DispatchedServices", {
		  					objectId 	: sReqId, 
		  					item		: sItemId, 
		  					EBELN		: sPOId, 
		  					EBELP		: sPOItemId,
		  					pkg_num		: "0",
		  					lim_ind		: sLim_ind,
		  					co_ind		: sCo_ind 
		  				}, true);
*/
				// Instantiate Tree Master
				this._onLogMatched(sReqId, sItemId, sPOId, sPOItemId, "0", sLim_ind, sCo_ind);

				// Instantiate ESV Items
				this._onESVMatched(sReqId, sItemId, sPOId, sPOItemId, "0", sLim_ind, sCo_ind);

				return;
			}

			this._oViewModel.setProperty("/Docno", sReqId);
			this._oViewModel.setProperty("/Zeile", sItemId);

			this._oViewModel.setProperty("/PO", sPOId);
			this._oViewModel.setProperty("/POItem", sPOItemId);
			this._oViewModel.setProperty("/srvText", this.srvText);

			var oEBELNFilter = new sap.ui.model.Filter("EBELN", sap.ui.model.FilterOperator.EQ, sPOId);
			var oEBELPFilter = new sap.ui.model.Filter("EBELP", sap.ui.model.FilterOperator.EQ, sPOItemId);
			var oSUBPCKG_NOFilter = new sap.ui.model.Filter("SUBPCKG_NO", sap.ui.model.FilterOperator.EQ, sPkg_num);
			var oDocnoFilter = new sap.ui.model.Filter("Docno", sap.ui.model.FilterOperator.EQ, sReqId);
			var oShortText = new sap.ui.model.Filter("Short_text", sap.ui.model.FilterOperator.EQ, this.sSrvText);
			var Contract = new sap.ui.model.Filter("CONTRACT_NO", sap.ui.model.FilterOperator.EQ, this.contractNo);
			var KTPNR = new sap.ui.model.Filter("CONTRACT_ITEM", sap.ui.model.FilterOperator.EQ, this.KTPNR);
			var afilter = [oEBELNFilter, oEBELPFilter, oSUBPCKG_NOFilter, oDocnoFilter, oShortText, Contract, KTPNR];
			if (typeof this.sServiceId !== "undefined" && this.sServiceId !== "") {
				var oServiceIdFilter = new sap.ui.model.Filter("Record_no", sap.ui.model.FilterOperator.EQ, this.sServiceId);
				afilter.push(oServiceIdFilter);
			}
			var gViewModel = sap.ui.getCore().byId("selectedServicesList").getModel("ViewModel")
			this.callESVtems(afilter);

			/*   if (this.sServiceId !== ""){
	                    gViewModel.getData()['InitMengeDisplay'] = false;
                        gViewModel.refresh();
                        sap.ui.getCore().byId("INITIALMENGE_input").setEditable(false);
                       
                    }else {
	                    sap.ui.getCore().byId("INITIALMENGE_input").setEditable(true);
                   }*/

			// if(typeof sPkg_num !== "undefined" && sPkg_num !== "") {

			/*  oESVItemsTable.bindItems({
			    path  :   "/ESVItemSet",
			   // template:   this.ESVItems_template, //oESVItemsTable.getBindingInfo("items").template,
			    factory: 	this.DispItmFactory.bind(this),
			    filters : afilter

			  });*/
			// }

			var sSelServiceLength = this.oServices.getProperty("/").length;
			//console.log("Model length = "+ this.oServices.getProperty("/").length);

			// Check if this is differnet request/item

			var savedDispFlag = this._oController.getOwnerComponent().getModel("appView").getProperty("/savedDispFlag");

			//console.log("savedDispFlag = "+ savedDispFlag);
			if ((this.Docno === "" || this.Zeile === "") || (this.Docno !== sReqId || this.Zeile !== sItemId) ||
				(sSelServiceLength == 0 && savedDispFlag)) {

				this._getReqServices(sReqId, sItemId);
				this.Docno = sReqId;
				this.Zeile = sItemId;
			}

			this._sSelPOItemId = sPOItemId;

			//// [Fields Config.....] 
			if (this._oController.getModel("feildsModel")) {
				var oFields = this._oController.getModel("feildsModel").getObject("/");

				if (controller.getView().getModel("UserInfoModel").getData().PriceVisible) {
					var oDispFields = ["GR_PRICE",
						"CURR",
						"INITIALMENGE",
						"DISPMENGE",
						"DELETEDISPSERVICE",
						"ADDDISPSERVICE",
						"DISPSAVEBTN",
						"DISCOUNT",
						"CALCULATE",
						"TOTAL_INITAL",
						"TOTAL",
						"CHANGE_PO",
						"DISP_CHANGE_HISTORY"
					];
				} else {
					var oDispFields = [
						"DISPMENGE",
						"DELETEDISPSERVICE",
						"ADDDISPSERVICE",
						"DISPSAVEBTN",
						"CHANGE_PO",
						"DISP_CHANGE_HISTORY"
					];
				}

				for (var i = 0; i < oDispFields.length; i++) {

					var iIndex = $.inArray(oDispFields[i],
						$.map(oFields.results, function (n) {
							return n.FieldId
						}));
					var curr_field = oFields.results[iIndex];
					var oFieldContorl = sap.ui.getCore().byId(curr_field.FieldId);
					var oFieldLabel = sap.ui.getCore().byId(curr_field.FieldId + "_lbl");

					if (typeof oFieldContorl === "undefined") continue;

					(curr_field.Visible === "X") ? oFieldContorl.setVisible(true): oFieldContorl.setVisible(false);

					if (typeof oFieldLabel !== "undefined") {
						(curr_field.Visible === "X") ? oFieldLabel.setVisible(true): oFieldLabel.setVisible(false);
					}
					var oField_2Contorl = sap.ui.getCore().byId(curr_field.FieldId + "_2");

					if (typeof oField_2Contorl !== "undefined") {
						(curr_field.Visible === "X") ? oField_2Contorl.setVisible(true): oField_2Contorl.setVisible(false);
					}

					var oField_input = sap.ui.getCore().byId(curr_field.FieldId + "_input");

					var oField_btn = sap.ui.getCore().byId(curr_field.FieldId);
					if (typeof oField_input !== "undefined") {

						if (curr_field.FieldId === "INITIALMENGE") {
							(curr_field.Display !== "X") ? this._oViewModel.setProperty("/InitMengeDisplay", true): this._oViewModel.setProperty(
								"/InitMengeDisplay", false);
							(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/InitMengeVisible", true): this._oViewModel.setProperty(
								"/InitMengeVisible", false);

						}

						if (curr_field.FieldId === "DISPMENGE") {
							(curr_field.Display !== "X") ? this._oViewModel.setProperty("/MengeDisplay", true): this._oViewModel.setProperty(
								"/MengeDisplay", false);
							(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/MengeVisible", true): this._oViewModel.setProperty(
								"/MengeVisible", false);

						}

						if (curr_field.FieldId === "DISCOUNT") {
							(curr_field.Display !== "X") ? this._oViewModel.setProperty("/DiscountDisplay", true): this._oViewModel.setProperty(
								"/DiscountDisplay", false);
							(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/DiscountVisible", true): this._oViewModel.setProperty(
								"/DiscountVisible", false);

						}

						if (curr_field.FieldId === "CALCULATE") {
							(curr_field.Display !== "X") ? this._oViewModel.setProperty("/CalculateDisplay", true): this._oViewModel.setProperty(
								"/DiscountVisible", false);
							(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/CalculateVisible", true): this._oViewModel.setProperty(
								"/CalculateVisible", false);

						}

						if (curr_field.FieldId === "TOTAL_INITAL") {
							(curr_field.Display !== "X") ? this._oViewModel.setProperty("/TotalInitalDisplay", true): this._oViewModel.setProperty(
								"/TotalInitalDisplay", false);
							(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/TotalInitalVisible", true): this._oViewModel.setProperty(
								"/TotalInitalVisible", false);

						}

						this._oViewModel.refresh();
					}

					if (curr_field.FieldId === "TOTAL") {
						(curr_field.Display !== "X") ? this._oViewModel.setProperty("/TotalDisplay", true): this._oViewModel.setProperty("/TotalDisplay",
							false);
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/TotalVisible", true): this._oViewModel.setProperty("/TotalVisible",
							false);

					}

					if (curr_field.FieldId === "CHANGE_PO") {
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/ChangePOVisible", true): this._oViewModel.setProperty(
							"/ChangePOVisible", false);

					}

					if (curr_field.FieldId === "DISP_CHANGE_HISTORY") {
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/ShowDispHistoryVisible", true): this._oViewModel.setProperty(
							"/ShowDispHistoryVisible", false);

					}

					if (curr_field.FieldId === "CALCULATE") {
						(curr_field.Display !== "X") ? this._oViewModel.setProperty("/CalculateDisplay", true): this._oViewModel.setProperty(
							"/DiscountVisible", false);
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/CalculateVisible", true): this._oViewModel.setProperty(
							"/CalculateVisible", false);

					}

					if (curr_field.FieldId === "CHANGE_PO") {
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/ChangePOVisible", true): this._oViewModel.setProperty(
							"/ChangePOVisible", false);

					}

					if (curr_field.FieldId === "DISP_CHANGE_HISTORY") {
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/ShowDispHistoryVisible", true): this._oViewModel.setProperty(
							"/ShowDispHistoryVisible", false);

					}

					this._oViewModel.refresh();

					var oCoulmnTxt = sap.ui.getCore().byId(curr_field.FieldId + "_txt");
					if (typeof oCoulmnTxt !== "undefined") {
						oCoulmnTxt.setText(curr_field.FieldLabel);
					}
				}
			}

		},

		/**
		 * Show PO dialog, in case the vendor wanted to change PO 
		 * Keeping in mind that, the selected line items assoicated to the PO,
		 * So Selecting another PO means deleting the current line items.
		 * @function
		 * @private
		 */

		_showPODialog: function () {

			var oModel = this._oController.getOwnerComponent().getModel();

			var sPoPath = this._oController.getModel().createKey("ReqItemsSet", {
				Docno: this.Docno,
				Zeile: this.Zeile,
				Mjahr: this._oController.Mjahr

			});

			var oPOList;
			var sVendor = this._oController.getVendor();

			if (!this._PODialog) {
				this._PODialog = sap.ui.xmlfragment("changePO", "zdwo_nx_drss_ven.view.PODialog", this);
				sap.ui.getCore().addDependent(this._PODialog);
				// forward compact/cozy style into Dialog
				this._PODialog.addStyleClass(this._oController.getOwnerComponent().getContentDensityClass());

				oPOList = sap.ui.getCore().byId("changePO--POList");
				oPOList.setModel(this._oPOItemsModel, "POItems");

			}

			var oPoItemsPromise = this._oController.getOwnerComponent().oFieldsOps.getPOLineItems(sVendor);

			oPoItemsPromise.then(function (responce) {
				this._oPOItemsModel.setData(responce.results);
				this._PODialog.setBusy(false);
				this._oPOItemsModel.refresh();

				//console.log(responce);
			}.bind(this));

			oPoItemsPromise.catch(function () {
				this._PODialog.setBusy(false);
				MessageBox.error("Unable to get line items of the selected PO line item");
			}.bind(this));

			this._PODialog.open();

		},

		/**
		 * Calculate cost of the selected line items in the table
		 * and set the values in the view model to be reflected in the UI.
		 * 
		 * @function
		 * @private
		 */

		_calculateCost: function () {

			var oItems = sap.ui.getCore().byId("selectedServicesList").getItems(),
				cost = 0.0,
				init_cost = 0.0,
				final_cost = 0.0,
				final_init_cost = 0.0;

			for (var i = 0; i < oItems.length; i++) {

				var curr_item = oItems[i].getBindingContext("selServices").getObject();

				cost = parseFloat(curr_item.Menge) * parseFloat(curr_item.GrPrice);
				final_cost += parseFloat(cost) * ((100.0 - parseFloat(curr_item.Discount)) / 100.0);

				init_cost = parseFloat(curr_item.InitialMenge) * parseFloat(curr_item.GrPrice);
				final_init_cost += parseFloat(init_cost) * ((100.0 - parseFloat(curr_item.Discount)) / 100.0);
			}
			this._oViewModel.setProperty("/TotalCost", final_cost);
			this._oViewModel.setProperty("/TotalInitial", final_init_cost);

			this._oViewModel.refresh();
		},

		/**
		 * Calculate cost of the selected line items in the table
		 * and set the values in the view model to be reflected in the UI.
		 * 
		 * @function
		 * @private
		 */

		_validateCalculatedCost: function () {

			var oItems = sap.ui.getCore().byId("selectedServicesList").getItems(),
				cost = 0,
				init_cost = 0,
				final_cost = 0,
				final_init_cost = 0;

			for (var i = 0; i < oItems.length; i++) {

				var curr_item = oItems[i].getBindingContext("selServices").getObject();

				cost = parseInt(curr_item.Menge) * parseFloat(curr_item.GrPrice);
				final_cost += parseFloat(cost) * ((100 - parseFloat(curr_item.Discount)) / 100.0);

				init_cost = parseInt(curr_item.InitialMenge) * parseFloat(curr_item.GrPrice);
				final_init_cost += parseFloat(init_cost) * ((100 - parseFloat(curr_item.Discount)) / 100.0);
			}

			if (final_cost < 0 || final_init_cost < 0) {
				return false;
			} else {
				return true;
			}
		},

		formatConfirmFields: function () {
			if (this._oController.getModel("feildsModel")) {
				var oFields = this._oController.getModel("feildsModel").getObject("/");

				var oDispFields = ["GR_PRICE_confirm",
					"CURR_confirm",
					"INITIALMENGE_confirm",
					"DISPMENGE_confirm",
					"DELETEDISPSERVICE_confirm",
					"ADDDISPSERVICE_confirm",
					"DISPSAVEBTN_confirm",
					"DISCOUNT_confirm",
					"CALCULATE_confirm",
					"TOTAL_INITAL_confirm",
					"TOTAL_confirm",
					"CHANGE_PO_confirm",
					"DISP_CHANGE_HISTORY_confirm"
				];

				for (var i = 0; i < oDispFields.length; i++) {

					var iIndex = $.inArray(oDispFields[i],
						$.map(oFields.results, function (n) {
							return n.FieldId + "_confirm"
						}));
					var curr_field = oFields.results[iIndex];
					var oFieldContorl = sap.ui.getCore().byId(curr_field.FieldId + "_confirm");
					var oFieldLabel = sap.ui.getCore().byId(curr_field.FieldId + "_confirm_lbl");

					if (typeof oFieldContorl === "undefined") continue;

					(curr_field.Visible === "X") ? oFieldContorl.setVisible(true): oFieldContorl.setVisible(false);

					if (typeof oFieldLabel !== "undefined") {
						(curr_field.Visible === "X") ? oFieldLabel.setVisible(true): oFieldLabel.setVisible(false);
					}
					var oField_2Contorl = sap.ui.getCore().byId(curr_field.FieldId + "_confirm_2");

					if (typeof oField_2Contorl !== "undefined") {
						(curr_field.Visible === "X") ? oField_2Contorl.setVisible(true): oField_2Contorl.setVisible(false);
					}

					var oField_input = sap.ui.getCore().byId(curr_field.FieldId + "_confirm_input");

					var oField_btn = sap.ui.getCore().byId(curr_field.FieldId);
					if (typeof oField_input !== "undefined") {

						if (curr_field.FieldId === "INITIALMENGE_confirm") {
							(curr_field.Display !== "X") ? this._oViewModel.setProperty("/InitMengeDisplay", true): this._oViewModel.setProperty(
								"/InitMengeDisplay", false);
							(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/InitMengeVisible", true): this._oViewModel.setProperty(
								"/InitMengeVisible", false);

						}

						if (curr_field.FieldId === "DISPMENGE_confirm") {
							(curr_field.Display !== "X") ? this._oViewModel.setProperty("/MengeDisplay", true): this._oViewModel.setProperty(
								"/MengeDisplay", false);
							(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/MengeVisible", true): this._oViewModel.setProperty(
								"/MengeVisible", false);

						}

						if (curr_field.FieldId === "DISCOUNT_confirm") {
							(curr_field.Display !== "X") ? this._oViewModel.setProperty("/DiscountDisplay", true): this._oViewModel.setProperty(
								"/DiscountDisplay", false);
							(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/DiscountVisible", true): this._oViewModel.setProperty(
								"/DiscountVisible", false);

						}

						if (curr_field.FieldId === "CALCULATE_confirm") {
							(curr_field.Display !== "X") ? this._oViewModel.setProperty("/CalculateDisplay", true): this._oViewModel.setProperty(
								"/DiscountVisible", false);
							(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/CalculateVisible", true): this._oViewModel.setProperty(
								"/CalculateVisible", false);

						}

						if (curr_field.FieldId === "TOTAL_INITAL_confirm") {
							(curr_field.Display !== "X") ? this._oViewModel.setProperty("/TotalInitalDisplay", true): this._oViewModel.setProperty(
								"/TotalInitalDisplay", false);
							(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/TotalInitalVisible", true): this._oViewModel.setProperty(
								"/TotalInitalVisible", false);

						}

						this._oViewModel.refresh();
					}

					if (curr_field.FieldId === "TOTAL_confirm") {
						(curr_field.Display !== "X") ? this._oViewModel.setProperty("/TotalDisplay", true): this._oViewModel.setProperty("/TotalDisplay",
							false);
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/TotalVisible", true): this._oViewModel.setProperty("/TotalVisible",
							false);

					}

					if (curr_field.FieldId === "CHANGE_PO_confirm") {
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/ChangePOVisible", true): this._oViewModel.setProperty(
							"/ChangePOVisible", false);

					}

					if (curr_field.FieldId === "DISP_CHANGE_HISTORY_confirm") {
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/ShowDispHistoryVisible", true): this._oViewModel.setProperty(
							"/ShowDispHistoryVisible", false);

					}

					if (curr_field.FieldId === "CALCULATE_confirm") {
						(curr_field.Display !== "X") ? this._oViewModel.setProperty("/CalculateDisplay", true): this._oViewModel.setProperty(
							"/DiscountVisible", false);
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/CalculateVisible", true): this._oViewModel.setProperty(
							"/CalculateVisible", false);

					}

					if (curr_field.FieldId === "CHANGE_PO_confirm") {
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/ChangePOVisible", true): this._oViewModel.setProperty(
							"/ChangePOVisible", false);

					}

					if (curr_field.FieldId === "DISP_CHANGE_HISTORY_confirm") {
						(curr_field.Visible !== "X") ? this._oViewModel.setProperty("/ShowDispHistoryVisible", true): this._oViewModel.setProperty(
							"/ShowDispHistoryVisible", false);

					}

					this._oViewModel.refresh();

					var oCoulmnTxt = sap.ui.getCore().byId(curr_field.FieldId + "_confirm_txt");
					if (typeof oCoulmnTxt !== "undefined") {
						oCoulmnTxt.setText(curr_field.FieldLabel);
					}
				}
			}

		},

		onCancelConfirmation: function (oEvent) {
			//this._sFragmentName.destroy();
			this._oConfirmFragment.close();
			//this._oConfirmFragment.destroy();
		},

		pad: function (num, size) {
			var s = num + "";
			while (s.length < size) s = "0" + s;
			return s;
		},

		numberCheck: function (oEvent) {
			if (parseFloat(oEvent)) {
				return parseFloat(oEvent);
			} else {
				return 0;
			}
		},

		onAcceptConfirmation: function (oEvent) {
			this.SelModel = sap.ui.getCore().byId("selectedServicesList").getModel("selServices");
			this.SelModel = this.SelModel.getData();
			if (this.SelModel.length > 0) {
				if (this.numberCheck(this.SelModel[0].PoPerce) > this.numberCheck(this.SelModel[0].PoPerLimit)) {
					/*sap.m.MessageBox.warning( "PO Value has been exceeded by " + this.SelModel[0].PoPerce + "% percentage. Do you still want to continue ?" , {
								actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					          	styleClass: "sapUiSizeCompact",
					          	onClose: function(sAction) {
					            	if(sAction === "YES"){
					            		this.onsavePoDetails(oEvent);
					            	}else{
					                  
					                }
					          	}.bind(this)
					          	 });
							*/
					if (Number(this.SelModel[0].PoPerce) > 100) {
						const exceed = (parseFloat(this.SelModel[0].PoPerce) - 100).toFixed(2);

						sap.m.MessageBox.warning("PO Value has been exceeded by " + exceed + "% percentage. Do you still want to continue ?", {
							actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
							styleClass: "sapUiSizeCompact",
							onClose: function (sAction) {
								if (sAction === "YES") {
									this.confirmJlItemAdd();
								} else {

								}
							}.bind(this)
						});
					} else {
						this.onsavePoDetails(oEvent);
					}
				} else {
					this.onsavePoDetails(oEvent);
				}
			} else {
				this.onsavePoDetails(oEvent);
			}
		},

		confirmJlItemAdd: function (oEvent) {
			this.SelModel = sap.ui.getCore().byId("selectedServicesListJL").getModel("selServices");
			this.SelModel = this.SelModel.getData();

			if (this.SelModel.length > 0) {
				for (var i = 0; i < this.SelModel.length; i++) {
					delete this.SelModel[i].PoConsum;
					delete this.SelModel[i].PoPerce;
					delete this.SelModel[i].PoValue;
					delete this.SelModel[i].PoPerLimit;

					if (!this.SelModel[i].VendorComments) {
						sap.m.MessageBox.error("Service Line Item comments are mandatory for: " + this.SelModel[i].Txz01 + "'");
						return;
					}
				}
			}

			if (this._oController.getModel("JobLogModel")) {
				var jlModel = this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/");
				var cfgData = this._oController.getModel("JobLogCfgModel").getData("/");
				var results = "";
				var nodes = this._oController.getModel("JobLogModel").getObject("/JobLoggingNAV/results/0/");
				results = cfgData.filter(obj => {
					return obj.JobLog === '';
				});
				nodes.tabVisibility = results[0];
				var iNewIndex = parseFloat(jlModel[jlModel.length - 1].Zeile, 0) + 10;
				var Zeile = this.pad(iNewIndex, 4);
				this.JLObj = [];
				for (var i = 0; i < this.SelModel.length; i++) {

					if (this.SelModel[i].VendorComments === "") {
						sap.m.MessageBox.error("Service Line Item comments are mandatory for:" + this.SelModel[i].Txz01 + "'");
						return;
					}

					for (var j = 0; j < jlModel.length; j++) {
						(jlModel[j].LineNo) = parseInt(jlModel[j].LineNo).toString()
						if ((jlModel[j].PckgNo === this.SelModel[i].PckgNo) && (jlModel[j].LineNo === this.SelModel[i].LineNo) && (jlModel[j].ContractNo ===
								this.SelModel[i].ContractNo)) {
							sap.m.MessageBox.error("Service Line Item already present :" + this.SelModel[i].Txz01 + "'");
							return;
						}
					}
					var Menge = parseFloat(this.SelModel[i].Menge).toFixed(3);
					Menge = (Menge).toString();
					var JLObj = {
						Curr: this.SelModel[i].Curr,
						Docno: this.SelModel[i].Docno,
						GrPrice: this.SelModel[i].GrPrice,
						ItemVal: "0.000",
						JobLog: "",
						LineNo: this.SelModel[i].LineNo,
						Meins: this.SelModel[i].Meins,
						Menge: Menge,
						Mjahr: jlModel[0].Mjahr,
						PckgNo: this.SelModel[i].PckgNo,
						PoItem: this.SelModel[i].PoItem,
						PoNo: this.SelModel[i].PoNo,
						LineNo: this.SelModel[i].LineNo,
						Txz01: this.SelModel[i].Txz01,
						Jobid: "0001",
						//VenPropQty: Menge,
						InitialMenge: Menge,
						SrcInd: "J",
						VenDelQty: "0",
						VendorAdd: "X",
						VendorDel: "",
						VendorComments: this.SelModel[i].VendorComments,
						//Zeile: Zeile,
						ContractNo: this.SelModel[i].ContractNo,
						ContRef: this.SelModel[i].ContRef,
						ContractItem: this.SelModel[i].ContractItem,
						NonCharge: this.SelModel[i].NonCharge,
						nodes: [nodes]
					}
					this.JLObj.push(JLObj);
				}

				const temp = JSON.parse(JSON.stringify(this.JLObj));
				for (var i = 0; i < temp.length; i++) {
					delete temp[i].nodes;
				}
				//var temp = JLObj;
				this.navBack();
				var oData = this._oController.getModel("VendorService");
				var JobLoggingServiceData = {
					Docno: temp[0].Docno,
					Mjahr: temp[0].Mjahr,
					JobLoggingServiceDataNAV: temp

				}
				oData.create("/JobLoggingServiceDataSet", JobLoggingServiceData, {
					success: function (oData) {
						this._oController.byId("idIconTabBar").setSelectedKey("Services");
						this._oController.byId("filterSelectJL").setSelectedKey("Draft");
						this._oController.byId("RecallButton").setVisible(false);
						this._oController.byId("SaveButton").setVisible(true);
						this._oController.byId("SubmitButton").setVisible(true);
						for (var i = 0; i < oData.JobLoggingServiceDataNAV.results.length; i++) {
							this.JLObj[0].nodes[0].JobId = '0001';
							this.JLObj[0].nodes[0].Zeile = oData.JobLoggingServiceDataNAV.results[i].Zeile;
							oData.JobLoggingServiceDataNAV.results[i].nodes = [this.JLObj[0].nodes[0]]
							jlModel.push(oData.JobLoggingServiceDataNAV.results[i]);
						}
						//JLObj.Zeile = oData.Zeile;

						this._oController.getModel("JobLogModel").refresh(true);
						this._oController.getModel().refresh();
						this._oController.byId("LoggingType").selectAll(true);
						return;
					}.bind(this),
					error: function (error) {
						var msg = JSON.parse(error.responseText).error.innererror.errordetails[0].message;
						sap.m.MessageBox.error(msg);
						return;
					}.bind(this)
				});
			}

			/*for(var i=0;i<this.SelModel.length;i++){
	            		const SelectedPoItems = this.flatArray.filter(v => v.SHORT_TEXT === this.SelModel[i].Txz01 && v.PCKG_NO === this.SelModel[i].PckgNo);
	            		this.SelModel[i].ContractNo = SelectedPoItems[0].CONTRACT_NO
	            		this.SelModel[i].ContractItem = SelectedPoItems[0].CONTRACT_ITEM
	            		this.SelModel[i].ContRef = SelectedPoItems[0].CONT_REF
	            	}
	            	var obj = {
			                Docno   : this.Docno,
			                Zeile   : this.Zeile,
			                toESVItems  : this.SelModel
			              },
			          that = this._oController;
	            	this._oController._DispServicesDialog.close();
	            
	            	that.getView().setBusy(true);

                    
			        this._saveServices(obj).then(function(date){
			            MessageToast.show("Service line items have been successfully saved.");
			            //this.savedFlag = true;
			           // this.getRequestData();
			            this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", true);
			            var data = this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/");
                        var nActualGRPrice = "";
			            for(var i=0;i<data.length;i++){
				
				        if(this.SelModel.getData().length>0){
					        this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/")[i].PckgNo =  this.SelModel[0].PckgNo;
					        this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/")[i].LineNo =  this.SelModel[0].LineNo;
			            	this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/")[i].PoItem =  this.SelModel[0].PoItem;
			            	this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/")[i].PoNo =  this.SelModel[0].PoNo;
			            	this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/")[i].Discount =  this.SelModel[0].Discount;
			            	this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/")[i].ContractNo =  this.SelModel[0].ContractNo;
			            	this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/")[i].ContRef =  this.SelModel[0].ContRef;
			            	this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/")[i].ContractItem =  this.SelModel[0].ContractItem;
			            	this._oController.getModel("JobLogModel").getProperty("/JobLoggingServiceDataNAV/results/").Curr =  this.SelModel[0].Curr;
                          }
                         
                          
			            }
                        var oSelData = this.SelModel.getData()
                         for(var ind in oSelData){
	                      if (ind == 0){
	                         nActualGRPrice = oSelData[ind]['InitialMenge'];
                          }else {
	                          nActualGRPrice = Number(nActualGRPrice) + Number(oSelData[ind]['InitialMenge']);
                           }
                      
                         }
                            
                     if (this.SelModel.getData().length>0){
	                      
	                       if(this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).ServiceId !==""){
			            	this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).GrPrice =  Number(this.SelModel[0].GrPrice);	            	
			            	if(parseFloat(this.SelModel[0].GrPrice)){
			            		var VenGrPrice = parseFloat(this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).Menge).toFixed(3) * parseFloat(this.SelModel[0].GrPrice).toFixed(3);
			            		VenGrPrice = parseFloat(VenGrPrice).toFixed(3);
			            	}
			            	this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).VenGrPrice = Number(nActualGRPrice).toFixed(2);
			            }else{
			            	var VenGrPrice = this._oViewModel.getProperty("/TotalInitial");
			            	VenGrPrice = parseFloat(VenGrPrice).toFixed(3);
			            	this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).VenGrPrice =  Number(nActualGRPrice).toFixed(2);
			            }
                        if (this.sServiceId !== ''){
	                        this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).GrPrice =  Number(this.SelModel[0].GrPrice).toFixed(2);
                        }else {
							this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).GrPrice = '';
						}
                        

                         
                       }else {
	
	                        this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).GrPrice = '0.00';
                            this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).VenGrPrice = "0.00";
                       }
                       
                     this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).ContractNo =  this.SelModel[0].ContractNo;
                     this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).ContRef =  this.SelModel[0].ContRef;
                     this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).ContractItem =  this.SelModel[0].ContractItem;
                     this._oController.getModel("itemsModel").refresh(true);
                     this.getView().setBusy(false);
			        }.bind(this))*/

		},

		onsavePoDetails: function (oEvent) {
			this.SelModel = sap.ui.getCore().byId("selectedServicesList").getModel("selServices");
			this.SelModel = this.SelModel.getData();
			if (this.SelModel.length > 0) {
				delete this.SelModel[0].PoConsum;
				delete this.SelModel[0].PoPerce;
				delete this.SelModel[0].PoValue;
				delete this.SelModel[0].PoPerLimit;
				/*Begin of changes by Aftab - 
				 * If the Vendor Clears Quantity and it is initial then set it to 0.000 otherwise will throw Exception in Odata.*/
				if (this.SelModel[0].Menge === '') {
					this.SelModel[0].Menge = '0.000';
				}
				/*End of changes by Aftab*/

			}
			if (this._oController.getModel("JobLogModel")) {
				var jlModel = this._oController.getModel("JobLogModel").getObject("/JobLoggingServiceDataNAV/results/");
				var cfgData = this._oController.getModel("JobLogCfgModel").getData("/");
				var results = "";
				var nodes = this._oController.getModel("JobLogModel").getObject("/JobLoggingNAV/results/0/");
				results = cfgData.filter(obj => {
					return obj.JobLog === '';
				});
				nodes.tabVisibility = results[0];
				var iNewIndex = parseInt(jlModel[jlModel.length - 1].Zeile, 0) + 10;
				var Zeile = this.pad(iNewIndex, 4);
				for (var i = 0; i < this.SelModel.length; i++) {
					var totalItemPrice = 0;
					totalItemPrice = parseFloat(this.SelModel[i].InitialMenge) * parseFloat(this.SelModel[i].GrPrice);
					totalItemPrice = (totalItemPrice).toFixed(3);
					totalItemPrice = (totalItemPrice).toString();
					var JLObj = {
						Curr: this.SelModel[i].Curr,
						DelInd: "",
						Docno: this.SelModel[i].Docno,
						GrPrice: this.SelModel[i].GrPrice,
						ItemPrice: totalItemPrice,
						JobLog: "",
						LineNo: this.SelModel[i].LineNo,
						Meins: this.SelModel[i].Meins,
						Menge: this.SelModel[i].InitialMenge,
						Mjahr: jlModel[0].Mjahr,
						PckgNo: this.SelModel[i].PckgNo,
						LineNo: this.SelModel[i].LineNo,
						PoItem: this.SelModel[i].PoItem,
						PoNo: this.SelModel[i].PoNo,
						Txz01: this.SelModel[i].Txz01,
						SrcInd: "J",
						Sno: "0001",
						VenGrPrice: "0.000",
						VendorAdd: "X",
						ContractNo: this.SelModel[i].ContractNo,
						ContRef: this.SelModel[i].ContRef,
						ContractItem: this.SelModel[i].ContractItem,
						Zeile: Zeile,
						nodes: [nodes]
					}

				}

				jlModel.push(JLObj);
				this._oController.getModel("JobLogModel").refresh(true);
				return;
			}

			for (var i = 0; i < this.SelModel.length; i++) {
				const SelectedPoItems = this.flatArray.filter(v => v.SHORT_TEXT === this.SelModel[i].Txz01 && v.PCKG_NO === this.SelModel[i].PckgNo);
				if (SelectedPoItems.length > 0) {
					this.SelModel[i].ContractNo = SelectedPoItems[0].CONTRACT_NO
					this.SelModel[i].ContractItem = SelectedPoItems[0].CONTRACT_ITEM
					this.SelModel[i].ContRef = SelectedPoItems[0].CONT_REF
				}
				this.SelModel[i].SrcInd = "D";
			}
			var obj = {
					Docno: this.Docno,
					Zeile: this.Zeile,
					toESVItems: this.SelModel
				},
				that = this._oController;
			this._oController._DispServicesDialog.close();
			//	this._oConfirmFragment.close();
			that.getView().setBusy(true);

			var clearPo = "";
			this._saveServices(obj).then(function (date) {

				MessageToast.show("Service line items have been successfully saved.");
				//this.savedFlag = true;
				// this.getRequestData();
				this._oController.getOwnerComponent().getModel("appView").setProperty("/savedDispFlag", true);
				var data = this._oController.getModel("itemsModel").getObject("/HeaderToItemNav");
				var nActualGRPrice = "";
				for (var i = 0; i < data.length; i++) {

					if (this.SelModel.length > 0) {
						//this._oController.getModel("itemsModel").getData().Konnr =  this.SelModel[0].ContractNo;
						// this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].LineNo =  this.SelModel[0].LineNo;					        
						this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].PoItem = this.SelModel[0].PoItem;
						this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].PoNo = this.SelModel[0].PoNo;
						this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].Discount = this.SelModel[0].Discount;
						//this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].Konnr =  this.SelModel[0].ContractNo;
						/*this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].ContractNo =  this.SelModel[0].ContractNo;
						this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].ContRef =  this.SelModel[0].ContRef;
						this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].ContractItem =  this.SelModel[0].ContractItem;*/
						this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).Curr = this.SelModel[0].Curr;
						this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).PckgNo = this.SelModel[0].PckgNo;
					}
				}

				var oSelData = this.SelModel;
				for (var ind in oSelData) {
					if (ind == 0) {
						nActualGRPrice = oSelData[ind]['InitialMenge'];
					} else {
						nActualGRPrice = Number(nActualGRPrice) + Number(oSelData[ind]['InitialMenge']);
					}
				}

				var oMenge = 0;
				var oGRPrice = 0;
				for (var i = 0; i < this.SelModel.length; i++) {
					if (this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).ServiceId !== '' ||
						this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).ServiceId !== '') {
						oMenge = oMenge + Number(this.SelModel[i]['Menge']);
						oGRPrice = oGRPrice + Number(this.SelModel[i]['GrPrice']);
					}

				}

				oMenge = oMenge.toFixed(3); //Added by Aftab- To make Vendor Prop.Quantity 3 decimals.                                              

				if (this.SelModel.length > 0) {
					if (this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).ServiceId !== "") {
						this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).GrPrice = Number(this.SelModel[0].GrPrice);
						if (parseInt(this.SelModel[0].GrPrice)) {
							var VenGrPrice = parseFloat(this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).Menge).toFixed(
								3) * parseFloat(this.SelModel[0].GrPrice).toFixed(3);
							VenGrPrice = parseFloat(VenGrPrice).toFixed(3);
						}
						//Commented to hide Ven pro Qty for foreman line, this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).VenGrPrice = Number(nActualGRPrice).toFixed(2);
					} else {
						/*var VenGrPrice = this._oViewModel.getProperty("/TotalInitial");
						VenGrPrice = parseFloat(VenGrPrice).toFixed(3);*/
						VenGrPrice = "0.00";
						this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).VenGrPrice = VenGrPrice; //Number(nActualGRPrice).toFixed(2);
					}
					var oUnitPrice = oGRPrice;
					if (this.SelModel.length - 1 > 0) {
						var oUnitPrice = Math.round(oGRPrice / this.SelModel.length);
					}

					if (this.sServiceId !== '' || this.SelModel.length === 1) {
						this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).GrPrice = Number(this.SelModel[0].GrPrice).toFixed(
							2);
						//  this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).GrPrice = oUnitPrice.toFixed(2);
					} else {

						this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).GrPrice = '0.00';
					}

					//Commented to hide Ven pro Qty for foreman line, this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).VenPropQty = oMenge.toString();
					// this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).VenPropQty = this.SelModel[0].Menge;
					this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).LineNo = this.SelModel[0].LineNo;
					this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).PckgNo = this.SelModel[0].PckgNo;

				} else {

					this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).GrPrice = '0.00';
					this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).VenGrPrice = "0.00";
					this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).VenPropQty = '0.00';

					for (var i = 0; i < data.length; i++) {
						if (this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].VenPropQty === "0.000" ||
							this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].VenPropQty === "0.00" ||
							this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].VenPropQty === "0.0" ||
							this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].VenPropQty === "0") {
							clearPo = "X";
						} else {
							clearPo = "";
						}
					}

					if (clearPo === "X") {
						for (var i = 0; i < data.length; i++) {
							this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].PckgNo = "0000000000";
							this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].PoItem = "00000";
							this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].PoNo = "";
							this._oController.getModel("itemsModel").getObject("/HeaderToItemNav")[i].Discount = "0.000";
						}
					}
					/*else{
					       				            	this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).PckgNo =  "0000000000";
					       				            	this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).PoItem = "00000";
					       				            	this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).PoNo =  "";
					       				            	this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).Discount =  "0.000";	
					       		            	}*/
				}

				/*
				this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).ContRef =  this.SelModel[0].ContRef;
				this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).ContractItem =  this.SelModel[0].ContractItem;*/
				this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).DispFilled = "";
				this._oController.getModel("itemsModel").getData().Ebeln = "";
				if (this.SelModel.length >= 1) {
					this._oController.getModel("itemsModel").getProperty(this._oController.oItemPath).DispFilled = "X";
					this._oController.getModel("itemsModel").getData().Ebeln = this.SelModel[0].PoNo;
				}
				this._oController.getModel("itemsModel").getData().Konnr = this.contractNo;

				this._oController.getModel("itemsModel").refresh(true);
				var oModel = this._oController.getModel("itemsModel");
				this._oController.checkPoItemFun(oModel);
				//   this._oController.fillServiceText();
				this._oController.getView().setBusy(false);
			}.bind(this))

		}

	});
});