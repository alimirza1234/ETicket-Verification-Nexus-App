var controller;
sap.ui.define([
	"./BaseController",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"zdwo_nx_drss_ven/utils/ExportToExcel",
	"zdwo_nx_drss_ven/model/formatter",
	"sap/ui/core/Fragment",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	"sap/m/MessageToast",
	'sap/ui/core/Core',
	"zdwo_nx_drss_ven/model/SrvTreeConversion",
	"sap/m/MessageBox",
	"zdwo_nx_drss_ven/utils/POContractSelector",
	"zdwo_nx_drss_ven/utils/DispatchedServicesSplit",
	"jquery.sap.global",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Label",
	"sap/m/library",
	"zdwo_nx_drss_ven/model/FormatterByReference",
	"sap/m/GroupHeaderListItem",
	"sap/ui/core/format/DateFormat",
	'sap/ui/export/library',

	'sap/ui/export/Spreadsheet'
], function (
	BaseController, History, JSONModel, ExportToExcel,
	formatter, Fragment, Filter, FilterOperator, MessageToast, Core, SrvTreeConversion, MessageBox, POContractSelector,
	DispatchedServicesSplit,
	jQuery,
	Dialog, Button, Label,
	mobileLibrary, FormatterByReference,
	GroupHeaderListItem,
	DateFormat,
	exportLibrary,
	Spreadsheet) {
	"use strict";
	// shortcut for sap.m.ButtonType
	var ButtonType = mobileLibrary.ButtonType;

	var EdmType = exportLibrary.EdmType;

	// shortcut for sap.m.DialogType
	var DialogType = mobileLibrary.DialogType;
	var oPreviousComments;
	return BaseController.extend("zdwo_nx_drss_ven.controller.RigRate", {
		formatter: formatter,
		onInit: function () {
			controller = this;
			this.selectedcontxtForUOM = "";
			this.serviceCount = 0;
			this.oAttachments = [];
			this.selectedItem = "";
			this.SrvTreeConversion = SrvTreeConversion;
			this.itemDetails = '';
			this.headerColumnsData = "";
			this.AttachLevel = "";
			this.onUploadChange = "";
			this.itemsObj = "";
			this.Catog = "";
			this.itemValue = "";
			this.sSelectedReason = true;
			this.sWrkflwBtnTxt = "";
			this.oRejReasonText = "";
			this.searchField = this.getView().byId("searchfield");
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("RigRate").attachPatternMatched(this._onObjectMatched, this);

			var oPOModel = new JSONModel();
			this.getView().setModel(oPOModel, "oPOModel");

			var oRigDailyOpTotals = new JSONModel();
			this.getView().setModel(oRigDailyOpTotals, "oRigDailyOpTotals");

			var oRigLostTimeModel = new JSONModel();
			this.getView().setModel(oRigLostTimeModel, "oRigLostTimeModel");

			var oServiceModel = new JSONModel();
			this.getView().setModel(oServiceModel, "oServiceModel");

			var oETicketModel = new JSONModel();
			this.getView().setModel(oETicketModel, "oETicketModel");

			var oJobLogDetailsModel = new JSONModel();
			this.getView().setModel(oJobLogDetailsModel, "oJobLogDetailsModel");

			var oMonthlyListModel = new JSONModel();
			this.getView().setModel(oMonthlyListModel, "oMonthlyListModel");

			this.getView().setModel(new JSONModel({

			}), "SelectModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "MrDateRelModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "jobLog");

			var data = new JSONModel();
			this.getView().setModel(data, "data");
			this.busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});

			//Holds LubSum enabled table data
			this.aDisplayColumns = [{
					"label": "UoM",
					"keyName": "Unit"
				}

			];
			//if ((this.getView().getModel("UserInfoModel").getProperty("/Foreman") === '') && (this.getView().getModel("UserInfoModel").getProperty("/ForemanClerk") === '')) {
			this.aDisplayColumns.push({
				"label": "Unit Price",
				"keyName": "UnitPrice"
			});
			this.aDisplayColumns.push({
				"label": "Currency",
				"keyName": "Currency"
			});
			this.aDisplayColumns.push({
				"label": "Total Amount",
				"keyName": "Amount"
			});
			var oLSSummaryModel = new JSONModel({
				aUniqueColumns: [],
				aRows: [],
				aDisplayColumns: this.aDisplayColumns
			}); // display columns will be filled from onAfterRendering based on some conditions
			this.getView().setModel(oLSSummaryModel, "oLSSummaryModel");

			var oPDFMappingModel = new JSONModel();
			this.getView().setModel(oPDFMappingModel, "oPDFMappingModel");
		},

		_onObjectMatched: function (evt) {
			controller = this;
			navBackFlg = "X";
			this.changeMade = "";
			this.sSelectedReason = true;
			this.itemDetails = evt.getParameter('arguments');
			this.DrssNo = evt.getParameter("arguments").DrssNo;
			this.Rqtype = evt.getParameter("arguments").Rqtype;
			this.Gid = evt.getParameter("arguments").Gid;
			this.Mjahr = evt.getParameter("arguments").Mjahr;
			this.getView().getModel("oETicketModel").setData({}); // reset eticket model on navigating to service order.

			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Sos = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Tvd = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Operations = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().NonCharge = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().rigMeals = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").refresh(true);

			this.getView().getModel("DisputeVisibilityModel").getData().DisputeVisibility = false;
			this.getView().getModel("DisputeVisibilityModel").refresh(true);

			this.getRequestData(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);

			this._MessageManager = Core.getMessageManager();
			// F4 Model&
			var f4Model = new JSONModel();
			this.getView().setModel(f4Model, "F4Models");

			this.MorningReport(this.itemDetails.DrssNo, this.itemDetails.Mjahr);

			//this.getETicketInfo();
			if (eTicket === "X") {
				this.onPreviewETicketPress();
			}
			eTicket = "";
			this.joblogginAttachment = [];
			//this._loadTableGrouping();

		},

		onRowsUpdate: function (evt) {
			var oTable = this.getView().byId("rigDailyOpTable");
			var aRows = oTable.getRows()
				//[0].addStyleClass('redCss');
			$.each(aRows, function (ind, obj) {
				var oBindingContext = obj.getBindingContext("oRigDailyOpModel").getObject();
				obj.removeStyleClass('highlightRows');
				if (oBindingContext.TotalFlg === "X") {
					obj.addStyleClass('highlightRows');
				}
			}.bind(this));
			var oRows = oTable.getRows();
			if (oRows && oRows.length > 0) {
				var pRow = {};
				for (var i = 0; i < oRows.length; i++) {
					if (i > 0) {
						var pCell = pRow.getCells()[0],
							cCell = oRows[i].getCells()[0];
						if (cCell.getText() === pCell.getText()) {
							$('#' + cCell.getId()).css("visibility", "hidden");
							$("#" + pRow.getId() + "-col0").css("border-bottom-style", "hidden")
						}
					}
					pRow = oRows[i];

				}
			}
		},

		_loadTableGrouping: function () {
			var oTable = this.getView().byId("rigDailyOpTable");
			oTable.onAfterRendering = function () {
				sap.ui.table.Table.prototype.onAfterRendering.apply(this, arguments)
				var oRows = oTable.getRows();
				if (oRows && oRows.length > 0) {
					var pRow = {};
					for (var i = 0; i < oRows.length; i++) {
						if (i > 0) {
							var pCell = pRow.getCells()[0],
								cCell = oRows[i].getCells()[0];
							if (cCell.getText() === pCell.getText()) {
								$('#' + cCell.getId()).css("visibility", "hidden");
								$("#" + pRow.getId() + "-col0").css("border-bottom-style", "hidden")
							}
						}
						pRow = oRows[i];

					}
				}
			}

		},

		// Addd based on Sathya Comments
		onPageRefresh: function () {
			this.getRequestData(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);
			this._MessageManager = Core.getMessageManager();
			// F4 Model&
			var f4Model = new JSONModel();
			this.getView().setModel(f4Model, "F4Models");
			this.MorningReport(this.itemDetails.DrssNo, this.itemDetails.Mjahr);
			//this.getETicketInfo();
			if (eTicket === "X") {
				this.onPreviewETicketPress();
			}
			eTicket = "";
			this.joblogginAttachment = [];
		},

		getJoblogging: function () {
			return new Promise(function (resolve, reject) {

				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", controller.DrssNo),
					new sap.ui.model.Filter("Mjahr", "EQ", controller.Mjahr)
				];
				this.busyDialog.open();
				this.getView().getModel("VendorService").read("/JobloggingFormsSet", {
					filters: oFilter,
					success: function (oData) {
						for (var i = 0; i < oData.results.length; i++) {
							if (oData.results[i].FormCode === "F020") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().Tvd = true;
							}

							if (oData.results[i].FormCode === "F021") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().Sos = true;
							}

							if (oData.results[i].FormCode === "F038") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().Operations = true;
							}

							if (oData.results[i].FormCode === "F048") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().NonCharge = true;
							}

							if (oData.results[i].FormCode === "F046") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().rigMeals = true;
							}
						}
						var oJsonModel = new JSONModel(oData.results);
						this.getView().setModel(oJsonModel, "JobLoggingModel");
						this.busyDialog.close();
						resolve(oData);
					}.bind(this),
					error: function (oError) {
						this.busyDialog.close();
						reject();
					}.bind(this)
				});
			}.bind(this));
		},

		// //Get Request Data
		getRequestData: function (docNo, year, Rqtype) {
			if (!docNo) {
				var docNo = this.DrssNo;
			}
			if (!year) {
				var year = this.Mjahr;
			}
			if (!Rqtype) {
				var Rqtype = this.Rqtype;
			}
			// var oModel = this.getView().getModel("VendorService");
			var oModel = this.getView().getModel("oReqHeaderSetModel");
			this.busyDialog.open();
			oModel.read("/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + Rqtype + "')", {
				urlParameters: {
					"$expand": "HeaderToAttNav,HeaderToCommNav,HeaderToItemNav,HeaderToUserInfoNav,HeaderToWfLogNav,HeaderToItemNav/ItemToCommNav,HeaderToWfActionNav,HeaderToItemNav/ItemToEdrssNav"
				},
				success: function (oData) {
					this.prepareData(oData);
					this.getRigDailyOperations(oData);
					this.generateInitialDailyOpColumns();
					this.SelectPriorities();
					if (oData.Ettab) {
						this.getETicketInfo(oData.Rqstat);
						this.getView().byId("iconTabBar2").setSelectedKey("eTicket");
						this.getView().byId("iconTabBar3").setVisible(false);
					} else if (oData.Rqstat === "JOBL") {
						this.getView().byId("iconTabBar3").setVisible(true);
						this.getView().byId("iconTabBar2").setSelectedKey("JobLogging");
						this.getETicketInfo("rejectedETicket");
					} else {
						this.getView().byId("iconTabBar3").setVisible(true);
						this.getView().byId("iconTabBar2").setSelectedKey("BasicData");
					}
					if (oData.Jltab) {
						this.getJoblogging();
					}
					this.busyDialog.close();
					// this._onTableRowColor(oData);
				}.bind(this),
				error: function (oResponse) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(oResponse);
				}.bind(this)
			});
		},

		prepareData: function (oData) {
			this.removeResultProp(oData);
			/*if (this.itemDetails.DrssNo ===  "0000000000" ){
				var oData = this.checkforSelectedService(oData);
			}*/
			this.getView().setModel(new JSONModel(oData), "itemsModel");
			//this.getOwnerComponent().getModel("itemsModel").setData(null);
			this.getOwnerComponent().getModel("itemsModel").setData(oData);
			if (oData.hasOwnProperty("HeaderToAttNav") && oData.HeaderToAttNav.length) {
				this.Attachments = oData.HeaderToAttNav;
				//	oData.HeaderToAttNav = this.prepareAttachments(oData.HeaderToAttNav);	
			} else {
				oData.HeaderToAttNav = [];
			}
			var oPromis = this.getConfig(oData.Rqtype, oData.Fldvar);
			oPromis.then(this.onResolve, this.onReject);
			//this.checkPoItemFun(oData);

			var oTreeTable = this.byId("ReferenceTable1");
			oTreeTable.expandToLevel(1);

			if (controller.getModel("oLSSummaryModel")) {
				//oLSController.getModel("oLSSummaryModel").setData([]);
				var oLSSummaryModel = new JSONModel({
					aUniqueColumns: [],
					aRows: [],
					aDisplayColumns: this.aDisplayColumns
				}); // display columns will be filled from onAfterRendering based on some conditions
				this.getView().setModel(oLSSummaryModel, "oLSSummaryModel");
			}

			var btVis = this.formatter.pdfBtnVisibility(oData.Rqstat);

			if (btVis) {
				controller.onGetConsPDFData();
			}

		},

		checkPoItemFun: function (oItemsModel) {
			controller.checkpo = '';
			var itemsModelData = oItemsModel.getData();
			$.each(itemsModelData['HeaderToItemNav'], function (ind, obj) {
				if (obj['PoNo'] !== "") {
					controller.checkpo = obj['PoNo'];
					this.changeMade = "X";
					//this.changeWFActionButton();
					return;
				}
			}.bind(this));
		},

		onResolve: function (controller) {
			var model = controller.getView().getModel("itemsModel");
			if (controller.getView().getModel("itemsModel").getProperty("/Rqstat") === "INIT" || controller.getView().getModel(
					"itemsModel").getProperty("/Rqstat") === "") {
				controller.setViewMode(true);
			} else {
				controller.setViewMode(false);
			};
			//controller.ItemCommentColor();
			controller.checkPoItemFun(model);
		},

		// Adding the comments color
		/*	ItemCommentColor :function(){
				var oItemsTable = this.getView().byId("ReferenceTable").getItems();
				if (oItemsTable.length>0){
					//var aTableItems = oItemsTable[0].getCells()[8].setColor('#FF0000');
					for (var obj in oItemsTable){
						var itemContext = oItemsTable[obj].getBindingContext("itemsModel").getObject();
						var oChkValue = itemContext['ItemToCommNav'][0].Text;
						var oCell = oItemsTable[obj].getCells()[9];
						 oCell.setColor('#000000');
						if (oChkValue !== ""){
							 oCell.setColor('#59ed3f');
						}
					}
				}
			},*/

		/*	_onTableRowColor : function(oData){
				var oItemsTable = this.getView().byId("ReferenceTable");
				var oTableItems = oItemsTable.getItems();
				
				$.each(oTableItems,function(ind,obj){
					var oObj = obj.getBindingContext('itemsModel').getObject();
					if (oObj.Maktxo === ''){
						
					}
					
				}.bind(this))
			
			},*/

		SelectPriorities: function () {
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = [];
			this.busyDialog.open();
			aFilters.push(new Filter("Field", FilterOperator.EQ, "ZP_RS_PRRTY"));
			oModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					this.PriorityDetails = oData.results;
					this.getView().getModel("itemsModel").getData().RS_PRRTY = oData.results;
					this.getView().getModel("itemsModel").refresh();
					this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.busyDialog.close();
				}.bind(this)
			});
		},

		SelectHoleSize: function () {
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = [];
			this.busyDialog.open();
			aFilters.push(new Filter("Field", FilterOperator.EQ, "ZDWO_HOLE_SIZE"));
			oModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					this.PriorityDetails = oData.results;
					this.getView().getModel("itemsModel").getData().Hole_Size = oData.results;
					this.getView().getModel("itemsModel").refresh();
					this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.busyDialog.open();
				}.bind(this)
			});
		},

		SelectRadius: function () {
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = [];
			this.busyDialog.open();
			aFilters.push(new Filter("Field", FilterOperator.EQ, "ZDWO_RADIUS"));
			oModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					this.PriorityDetails = oData.results;
					this.getView().getModel("itemsModel").getData().radius = oData.results;
					this.getView().getModel("itemsModel").refresh();
					this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.busyDialog.close();
				}.bind(this)
			});
		},

		onSelectionChange: function (evt) {
			var source = evt.getSource();
			var isSelected = source.getSelected();
			var oSearchModel = this.searchHelpDialog.getModel("searchHelpModel");
			var selectedItem = source.getParent().getParent().getBindingContext("searchHelpModel").getObject();
			var index = oSearchModel.getData()['selectedItems'].indexOf(selectedItem);
			if (isSelected) {
				if (index < 0) {
					oSearchModel.getData()['selectedItems'].push(selectedItem);
				}
			} else {
				if (index > -1) {
					oSearchModel.getData()['selectedItems'].splice(index, 1);
				}
			}
			oSearchModel.refresh();
			this.checkTableItems();

		},

		checkTableItems: function () {
			var oTableItems = Core.byId("serviceSelectedTable").getItems();
			$.each(oTableItems, function (ind, obj) {
				obj.setSelected(true);
			});
			Core.byId("serviceSelectedTable").getModel("searchHelpModel").refresh();

		},

		onSelectedService: function (evt) {
			var oSource = evt.getParameter('selectedItem');

		},

		removeResultProp: function (oData) {
			for (var key in oData) {
				if (oData[key] && oData[key].hasOwnProperty("results")) {
					oData[key] = oData[key].results;
					for (var i in oData[key]) {
						this.removeResultProp(oData[key][i]);
					}
				}
			}
		},

		onSelectService: function (evt) {
			var oSource = evt.getSource();
			var isSelected = oSource.getSelected();

			if (isSelected) {
				var oObject = oSource.getParent().getParent().getBindingContext("searchHelpModel").getObject();

				this.selectedItem['Maktxo'] = oObject.ServStext;
				this.selectedItem['ServLtext'] = oObject.ServLtext;
				this.getView().getModel("itemsModel").refresh();
			}

		},
		onNavBack: function (oEvent) {
			//this.oRouter.navTo("Inbox");

			var oPgModel = this.getView().getModel("itemsModel");

			if (oPgModel['oData']['Rqstat'] === "SUBT" || oPgModel['oData']['Rqstat'] === "RSUB") {
				MessageBox.warning("Do you want to save the Service Order?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO, sap.m.MessageBox.Action.CANCEL],
					styleClass: "sapUiSizeCompact",
					onClose: function (sAction) {
						if (sAction === "YES") {
							var aPromise = [];
							aPromise.push(this.onSaveOC());
							Promise.all(aPromise).then(function (oRequest) {
								var oPageModel = this.getView().getModel("itemsModel").getData();
								/*if(this.itemDetails.DrssNo === "0000000000"){*/
								this.itemDetails.DrssNo = oPageModel.Docno;
								MessageBox.success("The Service Order has been saved with ID #" + oPageModel['Docno'], {
									actions: [MessageBox.Action.CLOSE],
									onClose: function () {
										/// var sPreviousHash = History.getInstance().getPreviousHash();
										history.go(-1);
									}.bind(this)
								});
								/*}*/
							}.bind(this));
						} else if (sAction === "CANCEL") {

						} else {
							history.go(-1);
						}
					}.bind(this)
				});
			} else {
				history.go(-1);

			}
		},

		/*	   prepareAttachments : function(attachments){
					//this.ItemsAttachmentsModel = this.getView().getModel("itemsAttachment").getData();
					
					this.attachments = attachments;
					this.headerLevelAttachments = [];
					this.itemsAttachmentsValues = [];
					this.joblogginAttachment = [];
					if (attachments.length>0){
					
						$.each(attachments,function(ind,obj){
							var attachItem = obj;
							    if (obj['Category'] === '03'){
								   this.joblogginAttachment.push(attachItem);
								  //var itemLevel = "03";
							    }else if(obj['Category'] === "01"){
								   this.itemsAttachmentsValues.push(attachItem);
							    }else {
							       this.headerLevelAttachments.push(attachItem);
							    }
								/*if(attachItem.Category === itemLevel ){
									this.headerLevelAttachments.push(attachItem);
								}
								else{
									this.itemsAttachmentsValues.push(attachItem);
									
								}*/
		/*		}.bind(this));
				}
			if (this.getView().getModel("itemsAttachment")){
				this.getView().getModel("itemsAttachment").setData(this.itemsAttachmentsValues);
				
			}else {
				this.getView().setModel(new JSONModel(this.itemsAttachmentsValues), "itemsAttachment");
			}
			
			this.getView().getModel("itemsAttachment").refresh();
			return this.headerLevelAttachments;
		},*/

		//Bind the header comments
		/*	onHeaderCommentsPress : function(oEvent){
				var commentsTxt = this.byId("commentsTxt");
				var sPath = oEvent.getParameter("item").getBindingContext("itemsModel").getPath();
				commentsTxt.bindElement({ path: sPath, model: "itemsModel" });
			},
			*/
		onHeaderCommentsPress: function (oEvent, oSelected) {
			var commentsTxt = this.byId("commentsTxt");
			var aSelectedKey = oEvent.getSource().getSelectedKey();
			if (oSelected === "Comments" || aSelectedKey === "HDR") {
				this.getView().byId("segmentedButton").setSelectedKey("HDR");
				sPath = "/HeaderToCommNav/0";
				commentsTxt.setRows(1);
				commentsTxt.setCols(100);
				commentsTxt.setMaxLength(72);
			} else {
				var sPath = oEvent.getParameter("item").getBindingContext("itemsModel").getPath();
				commentsTxt.setRows(10);
				commentsTxt.setCols(100);
				commentsTxt.setMaxLength(200);
			}
			commentsTxt.bindElement({
				path: sPath,
				model: "itemsModel"
			});

		},

		handleSelcHeader: function (evt) {
			var oSelectedTab = evt.getParameter("key");
			this.getView().byId("exportRigDailyOpBtn").setVisible(false);
			if (oSelectedTab === "Comments") {
				this.onHeaderCommentsPress(evt, oSelectedTab);
			}
			if (oSelectedTab === "eTicket" || oSelectedTab === "rigDailyOp") {
				this.getView().byId("iconTabBar3").setVisible(false);
				this.getView().byId("exportRigDailyOpBtn").setVisible(true);
			} else {
				this.getView().byId("iconTabBar3").setVisible(true);
			}
		},

		// On Drilling Program Search

		OnDrillingProgSearch: function (oEvent) {
			var sValue = oEvent.getParameter("query") + "*";
			var aFilters = [new Filter("DpPgmNum", FilterOperator.EQ, sValue)];
			var oModel = this.getOwnerComponent().getModel("VendorService");
			this.busyDialog.open();
			oModel.read("/DrillPgmSet", {
				filters: aFilters,
				success: function (oData) {
					console.log(oData);
					var model = new JSONModel(oData);
					this.getView().setModel(model, "DrillingModel");
					this.busyDialog.close();
				}.bind(this),
				error: function (Error) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(Error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}

			});
		},

		OnCpyFrOtherSearch: function (oEvent) {
			var sValue = oEvent.getParameter("query") + "*";
			var aFilters = [new Filter("Wellnm", FilterOperator.EQ, sValue),
				new Filter("Rqtype", FilterOperator.EQ, this.itemDetails.Rqtype)
			];
			var oModel = this.getOwnerComponent().getModel("VendorService");
			this.busyDialog.open();
			oModel.read("/ServiceSearchWellSet", {
				filters: aFilters,
				success: function (oData) {
					console.log(oData);
					var model = new JSONModel(oData);
					this.getView().setModel(model, "cpyfotherModel");
					this.busyDialog.close();
				}.bind(this),
				error: function (Error) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(Error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}

			});
		},

		/*onSelectServiceClose: function (evt) {
			var oSelectedItems = sap.ui.getCore().byId("checkedList").getSelectedItems();
		    this.checkforSelectedService(oSelectedItems,"service");
			this.searchHelpDialog.close();
		},
		*/
		onWFRemarks: function (evt) {
			if (!this.WFRemarksDialog) {
				this.WFRemarksDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.OC.WFRemarksDialog", this);
				this.getView().addDependent(this.WFRemarksDialog);
			}
			this.WFRemarksDialog.open();
		},
		onCloseWFRemarks: function () {
			if (this.WFRemarksDialog) {
				this.WFRemarksDialog.close();
			}
			if (this.WFRemakDialog) {
				this.WFRemakDialog.close();
			}
		},

		// Seach Help Dialog Fragment
		onValueHelp: function (evt) {
			var me = this;
			var oSource = evt.getSource();
			this.core = Core;
			this.pageModel = this.getView().getModel("itemsModel").getData();
			if (oSource.getParent().getBindingContext("itemsModel")) {
				this.selectedItem = oSource.getParent().getBindingContext("itemsModel").getObject();
				controller.oSelectedObj = oSource.getParent().getBindingContext("itemsModel").getObject();
			}
			if (me.searchHelpDialog && me.serviceCount === 1) {
				/* var oSuggestionItem = sap.ui.getCore().byId("suggestionItems");
	           if (oSuggestionItem && this.itemDetails.srvDesc !==""){
		           oSuggestionItem.setSelectedKey(this.itemDetails.serviceDesc);
	            }*/
				Core.byId("searchField").setValue("");
				me.searchHelpDialog.open();
			} else {
				var promise = new Promise(function (resolve, reject) {
					me.getSelectedServiceData(me.pageModel.SrvtypeCode).then(function (response) {
						if (me.serviceCount === 0 && !me.searchHelpDialog || me.searchHelpDialog) {
							if (me.searchHelpDialog) {
								me.searchHelpDialog.destroyContent();
							}
							me.searchHelpDialog = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.SearchHelpForService", me);
							me.serviceCount++;
						} else {
							me.serviceCount++;
						}
						var oData = [];
						oData.ServiceItemsTable = response;
						oData.selectedItems = [];
						me.service = oData;
						var model = new JSONModel(oData);
						me.searchHelpDialog.setModel(model, "searchHelpModel");
						me.searchHelpDialog.open();
						me.core.byId("searchField").setValue("");
						me.searchHelpDialog.getModel("searchHelpModel").refresh();
						if (me.pageModel.SrvtypText && me.pageModel.SrvtypText !== "") {
							var oSuggestionItem = Core.byId("selectedSrcCode");
							if (oSuggestionItem) {
								oSuggestionItem.setValue(me.pageModel.SrvtypText);
							}
						}
					});
				});
			}
		},

		// on mode select
		onListCheck: function (evt) {
			var oSelectedTableItem = evt.getParameter("listItem").getBindingContext("searchHelpModel").getObject();
			var sSelTabItemProperty = oSelectedTableItem['Serviceid'];
			var aTreeItems = sap.ui.getCore().byId("serviceSelectId");
			for (var x = 0; x < aTreeItems.getItems().length; x++) {
				var oTempItemData = aTreeItems.getItems()[x].getBindingContext("searchHelpModel").getObject();
				if (sSelTabItemProperty === oTempItemData['Serviceid']) {
					oTempItemData['selected'] = false;
				}
			}
			aTreeItems.getModel("searchHelpModel").refresh();
			var oSearchModel = this.searchHelpDialog.getModel("searchHelpModel");
			var index = oSearchModel.getData()['selectedItems'].indexOf(oSelectedTableItem);
			oSearchModel.getData()['selectedItems'].splice(index, 1);
			oSearchModel.refresh();
			this.checkTableItems();
		},

		loadServiceList: function () {
			var that = this;
			that.model = this.getOwnerComponent().getModel("VendorService");
			var promise = new Promise(function (resolve, reject) {
				//  var aFilters = [new Filter("SrvtypeCode", FilterOperator.EQ, that.servtypeItem),];
				that.model.read("/ServiceTypesSet", {
					success: function (oData) {
						//	that.prepareData(oData);
						resolve(oData);
					},
					error: function (Error) {
						reject(Error);
					}
				});
			});
			return promise;
		},

		// On service search based on each item
		selectChange: function (oEvent, serviceDesc) {
			var that = this;
			if (oEvent) {
				if (oEvent.getParameter('selectedItem') != null) {
					this.selectedKey = oEvent.getParameter('selectedItem').getKey();
				}
			} else {
				this.selectedKey = serviceDesc;
			}
			var promise = new Promise(function (resolve, reject) {
				that.getSelectedServiceData(that.selectedKey).then(function (response) {
					that.searchHelpDialog.getModel("searchHelpModel").getData().ServiceItemsTable = response;
					that.searchHelpDialog.getModel("searchHelpModel").refresh();
				});
			});
		},

		getSelectedServiceData: function (oSelcSrvKey) {
			var that = this;
			var oPageModel = this.getView().getModel("itemsModel").getData();
			that.model = this.getOwnerComponent().getModel("VendorService");
			var aFilters = [new Filter("SrvtypeCode", FilterOperator.EQ, oSelcSrvKey),
				new Filter("Location", FilterOperator.EQ, oPageModel['Location']),
				new Filter("Radius", FilterOperator.EQ, oPageModel['Radius']),
				new Filter("HoleSize", FilterOperator.EQ, oPageModel['HoleSize'])
			];
			var promise = new Promise(function (resolve, reject) {
				that.model.read("/ServiceMasterSet", {
					filters: aFilters,
					success: function (oData) {
						oData = that.SrvTreeConversion.prepareTree(oData);
						//	that.prepareData(oData);
						resolve(oData);
					}.bind(this),
					error: function (Error) {
						//	reject(Error);
					}
				});
			});
			return promise;
		},

		// Select UOM&
		selectUOM: function (evt) {
			this.selectedcontxtForUOM = evt.getSource().getParent().getBindingContext("itemsModel").getObject();
			var getData = evt.getSource().data();
			/*if (!this.uomDialog){*/
			var oDataModel = this.getView().getModel("oDataModel");
			var aFilters = [new Filter("Field", FilterOperator.EQ, getData.Field),
				new Filter("Rqtype", FilterOperator.EQ, "E5")
			];
			oDataModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oRes) {
					var oModel = new JSONModel(oRes);
					if (!this.uomDialog) {
						this.uomDialog = sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.UOMDialog", this);
					}
					this.uomDialog.setModel(oModel, "UOM");
					this.uomDialog.open();
				}.bind(this),
				error: function (error) {}
			});
			/*}
			else {
				this.uomDialog.open();
			}*/
		},

		UOMhandleClose: function (evt) {
			var getItem = evt.getParameter("selectedItem").getBindingContext("UOM").getObject();
			this.selectedcontxtForUOM.Meins = getItem.Value1;
			this.getView().getModel("itemsModel").refresh();
		},

		onSelectServiceClose: function (evt) {
			var oSelectedItems = Core.byId("serviceSelectedTable").getSelectedItems();
			this.checkforSelectedService(oSelectedItems, "service");
			this.searchHelpDialog.close();
			this.checkForDuplicates();
			this.serviceCount = 0;
		},

		checkForDuplicates: function () {

			this.UniqueData = [];
			this.sDuplicateSrvid = [];
			if (controller.aDuplicates.length > 0) {
				var sDuplicateLineItem = "";
				$.each(controller.aDuplicates, function (ind, obj) {
					if (ind === 0) {
						sDuplicateLineItem = obj['Zeile'];
					} else {
						//var iCheckMatch = this.matchString(sDuplicateLineItem, obj['Zeile'], 'ig');
						//  if (iCheckMatch.length === 0){
						sDuplicateLineItem = sDuplicateLineItem + ", " + obj['Zeile'];
						//  }
					}
				}.bind(this));

				MessageBox.information("Selected Service ID was already added at line item #" + sDuplicateLineItem);
			}
			this.sequenceOrder();
		},

		sequenceOrder: function () {
			var oModel = this.getView().getModel("itemsModel");
			this.itemData = oModel.getProperty("/HeaderToItemNav");
			var oSeq = [];
			$.each(this.itemData, function (ind, obj) {
				if (ind === 0) {
					iNewIndex = parseInt("0000") + 10;
				} else {
					var iLastItemIndex = oSeq.length - 1,
						iNewIndex = parseInt(oSeq[iLastItemIndex].Zeile) + 10;
				}
				var Zeile = this.addZeil(iNewIndex, 4);
				//  var count = (ind+1).toString();
				obj.Zeile = Zeile;
				oSeq.push(obj);

			}.bind(this));
			oModel.getData()['HeaderToItemNav'] = oSeq;
			this.getView().byId("ReferenceTable").getModel("itemsModel").refresh();
		},

		clearTableItems: function (evt) {
			var oData = Core.byId("serviceSelectedTable").getModel("searchHelpModel").getData();
			oData.selectedItems = [];
			Core.byId("serviceSelectedTable").getModel("searchHelpModel").refresh();
			this.serviceCount = 0;
			this.searchHelpDialog.close();
			this.onValueHelp(evt);
		},

		onCloseSearchDialog: function () {
			this.searchHelpDialog.close();
		},

		onFilterServiceSearchm: function () {
			var that = this;
			var promise = new Promise(function (resolve, reject) {
				that.getSelectedServiceData().then(function (response) {
					that.getView().setModel(model, "itemsDialog");
					that.getView().getModel("itemsDialog").refresh();
				});
			});
		},

		onDialogSuggest: function (event) {
			var sValue = event.getParameter("suggestValue"),
				aFilters = [];
			if (sValue) {
				aFilters = [
					new Filter([
						new Filter("Fieldtext", function (sText) {
							return (sText || "").toUpperCase().indexOf(sValue.toUpperCase()) > -1;
						})

					], false)
				];
			}
			this.oSearchField.getBinding('suggestionItems').filter(aFilters);
			this.oSearchField.suggest();
		},

		addStagePress: function () {
			// Still not implemented
			this.searchHelpDialog.close();
		},
		// Create Page Selection
		checkforSelectedService: function (oSelectedData, oValue, oModelName) {
			var oModel = this.getView().getModel("itemsModel");
			var HeaderToRefNav = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var getData = oModel.getProperty("/HeaderToItemNav");
			controller.aDuplicates = [];
			//  var pageModelData = oModel.getData()['HeaderToItemNav'];
			this.custHeaderToItemNav = [];
			$.each(oSelectedData, function (ind, obj1) {
				var obj = this.addItem();

				// this.itemsObj  = obj;
				var pageModelData = oModel.getData()['HeaderToItemNav'];
				if (oValue === "service") {
					var oObject = obj1.getBindingContext("searchHelpModel").getObject();
					var sText = "";
					if (oObject['ServStext']) {
						var sText = oObject['ServStext']
					} else {
						var sText = oObject['ServLtext']
					}
					if (oModel.getData().HeaderToItemNav.length === 1 && ind === 0 && oModel.getData().HeaderToItemNav[ind].Maktxo === "") {
						obj.Maktxo = oObject['ServStext'];
						obj.ServLtext = oObject['ServLtext'];
					} else {
						var HeaderToRefNav = oModel.getData()['HeaderToItemNav'];
						var iLastItemIndex = HeaderToRefNav.length - 1,
							iNewIndex = parseInt(HeaderToRefNav[iLastItemIndex].Zeile) + 10;
						var Zeile = this.addZeil(iNewIndex, 4);
						obj.Zeile = Zeile;
						obj.ItemToCommNav[0].Zeile = Zeile;
						obj.Maktxo = sText;
						obj.ServLtext = oObject['ServLtext'];
					}
					obj.Meins = oObject.UOM;
					if (!oObject.Serviceid) {
						oObject.Serviceid = "";
					}
					obj.ServiceId = oObject.Serviceid;

					// check deplicates
					var oCheckValues = getData.filter(item => obj['Maktxo'] === item['Maktxo']);
					if (oCheckValues.length > 0) {
						controller.aDuplicates.push(oCheckValues[0]);
						return;
					}

					if (ind === 0) {
						controller.oSelectedObj['Maktxo'] = sText;
						controller.oSelectedObj['ServLtext'] = oObject['ServLtext'];
						controller.oSelectedObj['Meins'] = obj.Meins;
						controller.oSelectedObj['ServiceId'] = obj.ServiceId;
						return;
					}

				}

				if (pageModelData[pageModelData.length - 1].Maktxo === '') {
					var lastIndexData = pageModelData[pageModelData.length - 1];
					lastIndexData.Maktxo = obj.Maktxo;
					lastIndexData.ServLtext = obj['ServLtext'];
					lastIndexData.Meins = obj.Meins;
					if (!obj.Serviceid) {
						oObject.Serviceid = "";
					}
					lastIndexData.ServiceId = obj.ServiceId;
				} else {
					if (oModel.getData().HeaderToItemNav.length === 1 && ind === 0 && oModel.getData().HeaderToItemNav[ind].Maktxo === "") {
						oModel.getData().HeaderToItemNav[0].Maktxo = obj.Maktxo;
						oModel.getData().HeaderToItemNav[0].ServLtext = obj['ServLtext'];
					} else {
						oModel.getData().HeaderToItemNav.push(obj);
					}
				}

			}.bind(this));
			oModel.refresh();
			return oSelectedData;
		},

		// Add Stage for the copy from other well
		onCpyPressforCopyfrmDrss: function (evt) {
			//this.getView().byId("copyFromOtherWellTable").getSelectedItems()[0].getBindingContext("DrillingModel").getObject()
			var oTable = this.getView().byId("copyFromOtherWellTable");
			var oSelectedItems = oTable.getSelectedItems();
			this.checkforSelectedService(oSelectedItems, "cpyfdrss");
			var removeSelections = oTable.removeSelections(true);
			if (oSelectedItems.length > 0) {
				this.getView().byId("iconTabBar3").setSelectedKey("Item Information");
			}
			//this.searchHelpDialog.close();
		},

		// Search Help Dialog ends here
		// On View Search Suggest starts here
		onViewItemSuggest: function (event) {
			var sValue = event.getParameter("suggestValue"),
				aFilters = [];
			if (sValue) {
				aFilters = [
					new Filter([
						new Filter("Fieldtext", function (sText) {
							return (sText || "").toUpperCase().indexOf(sValue.toUpperCase()) > -1;
						})

					], false)
				];
			}
			this.searchField.getBinding('suggestionItems').filter(aFilters);
			this.searchField.suggest();
		},
		// On View Suggest search ends here	

		onClose: function () {
			if (this._ItemsCommondialog) {
				this._ItemsCommondialog.close();
			}
			if (this.JobLogAttachmentsDialog) {

				this.JobLogAttachmentsDialog.close();
				this.JobLogAttachmentsDialog.destroy();
				delete this.JobLogAttachmentsDialog
			}

		},

		onCloseAttachmentPopUp: function () {
			if (this._ItemsCommondialog) {
				this._ItemsCommondialog.close();
			}
			if (this.JobLogAttachmentsDialog) {

				this.JobLogAttachmentsDialog.close();
				this.JobLogAttachmentsDialog.destroy();
				delete this.JobLogAttachmentsDialog
			}

		},

		getItemsDialogs: function () {
			var me = this;
			var promise = new Promise(function (resolve, reject) {
				me.gModel.callFunction("/SHELP_GET_FIELDS", {
					method: "GET",
					urlParameters: {
						SHLPNAME: "ZUPLG_DOCNO_SH",
						SHLPTYPE: "SH"
					},
					success: function (oData) {
						resolve(oData);
						//console.log(oData);
					},
					error: function (error) {
						reject(error);
					}
				});
			});
			return promise;
		},

		checkValidation: function () {
			var errorList = this.validationControlsByFieldGroupId();
			this.instantiateErrorMessageModel(errorList);
			this.createMessagePopoverModel();
			return errorList;
		},

		removeParams: function (items) {
			$.each(items['HeaderToItemNav'], function (ind, obj) {
				if (obj['SplArray'] || obj['EText']) {
					delete obj['SplArray'];
					delete obj['EText'];
				}
			}.bind(this))

			return items;
		},

		onSaveOC: function (evt) {
			var me = this;
			// var oModel = this.getOwnerComponent().getModel("VendorService");
			var oModel = this.getOwnerComponent().getModel("oReqHeaderSetModel");
			var itemModel = this.getView().getModel("itemsModel");
			itemModel.getData()['HeaderToItemNav'] = this._AddedByVendorsItems(itemModel.getData()['HeaderToItemNav']);
			this.reqItems = itemModel.getData();
			// Validation check

			return new Promise(function (resolve, reject) {
				var errorCheck = this.checkValidation();

				if (errorCheck.length > 0) {
					reject();
					return;

				}
				// OData Service Request
				var length = this.reqItems.HeaderToItemNav.length;
				for (var i = 0; i < length; i++) {
					if (this.reqItems.HeaderToItemNav[i].ServLtext === "") {
						sap.m.MessageBox.error("Service Name cannot be empty");
						return;
					}

					/*if(this.reqItems.HeaderToItemNav[i].Menge === ""){
						sap.m.MessageBox.error("Service Quantity cannot be empty");
						return;
					}*/

					if (this.reqItems.HeaderToItemNav[i].Meins === "") {
						sap.m.MessageBox.error("Service UoM cannot be empty");
						return;
					}
				}
				delete this.reqItems['HeaderToUserInfoNav'];
				delete this.reqItems['Hole_Size'];
				delete this.reqItems['radius'];
				delete this.reqItems['RS_PRRTY'];;
				// Remove length from a vendor name 12/02/2022
				/* if (this.reqItems['VEND_NAME'].length>30){
				 this.reqItems['VEND_NAME'] = this.reqItems['VEND_NAME'].slice(0,29);
				 }*/

				this.OnAddCmdtoField();
				this.reqItems = this.removeParams(this.reqItems);
				oModel.create("/ReqHeaderSet", this.reqItems, {
					method: "POST",
					success: function (oData) {
						if (this.itemDetails.DrssNo === "0000000000") {
							this.itemDetails.DrssNo = oData.Docno;
							sap.m.MessageToast.show("The Service Order has been created with ID #" + oData.Docno);
						} else {
							sap.m.MessageToast.show("The Service Order ID # " + oData.Docno + " has been successfully updated");
						}
						this.prepareData(oData);
						this.busyDialog.close();
						resolve();
						this.instantiateErrorMessageModel();
						this.resetFieldGroupIdValueState();
						this.busyDialog.close();
					}.bind(this),
					error: function (oResponse, error) {
						this.busyDialog.close();
						var msgs = this.getErrorMessages(oResponse);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();
					}.bind(this)
				});

			}.bind(this));
		},

		getErrorMsg: function (oResponse) {
			return JSON.parse(oResponse.responseText).error.message.value;

		},

		instantiateErrorMessageModel: function (Messages) {
			if (Messages && Messages.length > 0) {
				this.getView().setModel(new JSONModel({
					MessageCount: Messages.length,
					Messages: Messages
				}), "ErrorMessagesModel");
			} else {
				this.getView().setModel(new JSONModel({}), "ErrorMessagesModel");
			}

			if (this.oMessagePopover) {
				this.oMessagePopover.close();
			}
		},

		//Instantiate MessagePopOver
		createMessagePopoverModel: function () {
			if (this.oMessagePopover) {
				this.oMessagePopover.close();
			}
			if (!this.oMessagePopover) {
				this.oMessagePopover = new sap.m.MessagePopover({
					items: {
						path: 'ErrorMessagesModel>/Messages/',
						template: new sap.m.MessageItem({
							type: "{ErrorMessagesModel>severity}",
							title: "{ErrorMessagesModel>message}"
						})
					}
				});
			}
			this.getView().byId("MessagePopoverBtn").addDependent(this.oMessagePopover);
			if (this.getView().getModel("ErrorMessagesModel").getProperty("/Messages") && this.getView().getModel("ErrorMessagesModel").getProperty(
					"/Messages").length > 0) {
				this.oMessagePopover.openBy(this.getView().byId("MessagePopoverBtn"));
			}
		},

		// Message Handler
		handleMessagePopoverPress: function () {
			if (this.oMessagePopover) {
				this.oMessagePopover.openBy(this.getView().byId("MessagePopoverBtn"));
			} else {
				this.createMessagePopoverModel();
			}
		},

		onShowHideMaster: function () {
			var oAppView = this.getOwnerComponent().getModel("appView"),
				sMode;
			sMode = oAppView.getProperty("/mode");
			//	(sMode === "ShowHideMode") ? oAppView.setProperty("/mode", ("HideMode")): oAppView.setProperty("/mode", ("ShowHideMode"));
		},

		onCloseDialog: function () {
			this.selectFragment.close();
		},

		addZeil: function (num, size) {
			var s = num + "";
			while (s.length < size) s = "0" + s;
			return s;
		},

		onAddNewLine_ref: function (oEvent) {
			this.changeMade = "X";
			this.changeWFActionButton();
			//	var HeaderToRefNav = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");

			this.itemsObj = dataObject;

			var HeaderToRefNav = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var dataObject = this.addItem();
			var aCheckItem = [];
			/*$.each(HeaderToRefNav,function(ind,obj){
			}.bind(this));*/

			for (var ind in HeaderToRefNav) {
				if (HeaderToRefNav[ind]['Maktxo'] === "" && (HeaderToRefNav[ind]['ServLtext'] === "" || typeof HeaderToRefNav[ind]['ServLtext'] ===
						'undefined')) {
					sap.m.MessageBox.error("Please fill the added line item");
					return
				}
			}

			if (HeaderToRefNav) {
				var iLastItemIndex = HeaderToRefNav.length - 1,
					iNewIndex = parseInt(HeaderToRefNav[iLastItemIndex].Zeile) + 10;
				var Zeile = this.addZeil(iNewIndex, 4);
				dataObject.Zeile = Zeile;
				HeaderToRefNav.push(dataObject);
			} else {
				var results = [];
				dataObject.Zeile = "0010";
				results.push(dataObject);
				HeaderToRefNav = results;
			}
			this.getView().getModel("itemsModel").refresh();
		},

		addItem: function () {

			var oModel = this.getView().getModel("itemsModel");
			var HeaderToRefNav = oModel.getProperty("/HeaderToItemNav");
			var DataForPoItem = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav/0");
			var PoNo = DataForPoItem.PoNo;
			var PoItem = DataForPoItem.PoItem;
			var PckgNo = DataForPoItem.PckgNo;
			var LineNo = DataForPoItem.LineNo;
			/// var getData = oModel.getProperty("/HeaderToItemNav");
			if (oModel.getData().HeaderToItemNav.length > 0) {
				var oMoData = oModel.getData().HeaderToItemNav;
				var Zeile = oMoData[oMoData.length - 1].Zeile;
			} else {
				var Zeile = "0010";
			}

			var item = {
				Docno: this.itemDetails.DrssNo,
				Mjahr: this.itemDetails.Mjahr,
				Zeile: "",
				Eqpdesc: "",
				Eqpconttype: "",
				Itype: "",
				Matnr: "",
				Maktxo: "",
				Wgbez: "",
				ServiceId: "",
				Leadtime: "000",
				Mafd: "",
				Vendor: "",
				Meins: "",
				Menge: "0.000",
				Rmenge: "0",
				Rolegroup: "",
				FcompMenge: "0",
				Iphase: "",
				//Badgeno: "",
				PoNo: PoNo,
				PoItem: PoItem,
				PckgNo: PckgNo,
				LimitInd: "",
				LineNo: LineNo,
				CoInd: "",
				GrPrice: "0.00",
				Curr: "",
				/*VenGrPrice:"0.000",*/
				VenGrPrice: "0.00",
				/*VenPropQty:"0",*/
				VenPropQty: "0.000",
				Ename: "",
				WorkFrom: null,
				WorkTo: null,
				Wfstatus: "",
				Discount: "0.000",
				VendorAdd: "X1",
				DelInd: "",
				ItemToCommNav: [{
					Descrip: "Item Comments",
					Text: "",
					Docno: "",
					Mjahr: "0000",
					Ntdid: "ITM",
					Tdid: "ZTXT",
					Tdobject: "ZPDRSS",
					Txttype: "I",
					Zeile: Zeile
				}]
			};
			return item;
		},

		itemDeletePress: function (evt) {

			var getPath = evt.getParameter('id').split('-').reverse()[0];
			var that = this;
			that.oEvent = evt.getSource();
			that.oIconCell = evt.getSource().getParent().getParent().getCells()[8];
			that.oBindingObject = evt.getSource().getParent().getParent().getBindingContext("itemsModel").getObject();
			MessageBox.information("This service will be deleted. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {

						//if (typeof that.oBindingObject['EText'] !== "undefined" && that.oBindingObject['EText'] !== ''){
						//that.oIconCell.setColor("#000");
						var oSelecObject = this.getView().getModel("itemsModel").getObject("/HeaderToItemNav")[getPath];
						if (oSelecObject.VendorAdd === "" || oSelecObject.VendorAdd === "X") {
							oSelecObject.DelInd = "V";
							that.notificationPress(that.oEvent, true);
						} else if (oSelecObject.VendorAdd === "X1") {
							this.getView().getModel("itemsModel").getData()['HeaderToItemNav'].splice(getPath, 1);
							//oSelecObject.DelInd = "V";
							//that.notificationPress(that.oEvent,true);
						}
						/*else {
						   oSelecObject.DelInd = "V";
						}*/
						//}else {
						//MessageBox.warning("Please enter your comments before deleting this item");
						//that.oIconCell.setColor("#E9967A");
						//that.notificationPress(that.oEvent,true);
						//}

						this.getView().getModel("itemsModel").refresh();
						this.changeMade = "X";
						this.changeWFActionButton();
					}

				}.bind(this)
			});

			this.getView().byId("ReferenceTable").getModel('itemsModel').refresh();

		},

		itemDeleteUndoPress: function (evt) {
			var getPath = evt.getParameter('id').split('-').reverse()[0];
			MessageBox.information("This marked for deletion will be removed. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						if (this.getView().getModel("itemsModel").getObject("/HeaderToItemNav")[getPath].DelInd === "V") {
							this.getView().getModel("itemsModel").getObject("/HeaderToItemNav")[getPath].DelInd = "";
						}
						this.getView().getModel("itemsModel").refresh();
						this.changeMade = "X";
						this.changeWFActionButton();
					}
				}.bind(this)
			});

		},

		ChooseVendorID: function (oEvt) {
			var me = this;
			var oFilter = [];
			var promise = new Promise(function (resolve, reject) {
				me.loadDomainValues(oFilter)
					.then(function (res) {
						if (!me._vendorSelectDialog) {
							me._vendorSelectDialog = new sap.ui.xmlfragment(".fragment.HeaderFragments.Vendor", me);
						}
						var model = new JSONModel(res);
						me._vendorSelectDialog.setModel(model, "vendorModel");
						me._vendorSelectDialog.open();
						///		console.log("fdsafsaf",res);&
					});
				return promise;
			});
		},

		vendorSelect: function (oEvt) {
			var oSelectedValue = oEvt.getParameter("selectedItem").getBindingContext('vendorModel').getObject().FIELDVAL;
			this.getView().byId("vendorInput").setValue(oSelectedValue);
		},

		vendorSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilterVId = new Filter("FIELDVAL", FilterOperator.Contains, sValue);
			//	var oFilterVName = new Filter("VENDNAME", FilterOperator.Contains, sValue);
			//	var oFilter = [];
			//	oFilter.push(oFilterVId);
			//	oFilter.push(oFilterVName);
			var oBinding = oEvent.getParameter("itemsBinding");
			oBinding.filter([oFilterVId]);
		},

		ChangeMade: function (oEvt) {
			this.changeMade = "X";
			this.changeWFActionButton();
		},

		handleCloseButton: function () {
			this._pPopover.close();
		},

		closeComments: function () {
			this.getView().byId("commentsId").close();
		},

		// SearchHelp Functions

		ChooseValueFromSearchHelp: function (oEvt) {

			this.loadDomainValue(oEvt);
		},

		// Retrive searchHelp Values from back-end
		loadDomainValue: function (evt) {
			var oSource = evt.getSource();
			this.filedValue = oSource.data().Field;
			this.oDialogTitle = oSource.data().Title;
			//var fieldname = "ZZ_RIG_CD";
			var oDataModel = this.getView().getModel("VendorService");
			this.busyDialog.open();
			var aFilters = [new Filter("Field", FilterOperator.EQ, this.filedValue)];

			if (this.filedValue === "WLLCLASS") {
				aFilters.push(new Filter("Rqtype", FilterOperator.EQ, this.itemDetails.Rqtype));
			}

			oDataModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				/*	urlParameters: {
						   "$skip":0,
						   "$Top":20
						},*/
				success: function (oData) {
					if (this.filedValue === "VENDOR" || this.filedValue === "WELL_NAME" || this.filedValue === "RIG_CODE" || this.filedValue ===
						"COPY_REF") {
						this.OpenTableSelectdialog(oData, this.filedValue);
					} else {
						if (!this.HeaderSearchHelp) {

							this.HeaderSearchHelp = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Header.SearchHelp", this);
						}

						oData = this.handleColumnData(oData, this.filedValue);
						var f4Model = new JSONModel(oData);
						this.HeaderSearchHelp.setModel(f4Model, "F4Models");
						this.HeaderSearchHelp.setTitle(this.oDialogTitle);
						//	this.getView().getModel("F4Models").setData(data);
						this.HeaderSearchHelp.open();

					}
					this.busyDialog.close();
					//		this.getView().getModel("F4Models").setProperty("/" + this.field, oData);
					/*	oData = oData.results;
						this.getView().getModel("F4Models").setProperty("/" + this.field, oData);
						this.busyDialog.close();*/
				}.bind(this),
				error: function (oResponse) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(oResponse);
				}.bind(this)
			});
		},

		OpenTableSelectdialog: function (oData, fieldValue) {

			if (!this.f4SearchHelp) {
				this.f4SearchHelp = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Header.f4Help", this);
			}

			oData = this.handleColumnData(oData, fieldValue);
			var f4Model = new JSONModel(oData);
			this.f4SearchHelp.setModel(f4Model, "F4Models");
			this.f4SearchHelp.setTitle(this.oDialogTitle);
			//	this.getView().getModel("F4Models").setData(data);
			this.f4SearchHelp.open();
		},

		onExeucte: function (evt) {
			var oDataModel = this.getView().getModel("VendorService");
			if (this.HeaderSearchHelp) {
				var oSearchHelpModel = this.HeaderSearchHelp.getModel("F4Models");
			} else if (this.f4SearchHelp) {
				var oSearchHelpModel = this.f4SearchHelp.getModel("F4Models");
			}

			var oTable = oSearchHelpModel.getData()['columns'];
			var aFilter = [new Filter("Field", FilterOperator.EQ, this.filedValue)];
			$.each(oTable, function (ind, obj) {
				if (obj['oValue']) {
					aFilter.push(new Filter(obj.field, FilterOperator.EQ, obj.oValue));
				}
			}.bind(this));
			//var aFilters = [new Filter("Field", FilterOperator.EQ, this.filedValue)];
			var max_hits = 50;
			if (oSearchHelpModel.getData()["dialog"]["maxHits"]) {
				max_hits = oSearchHelpModel.getData()["dialog"]["maxHits"];
			} else {
				max_hits = 50;;
			}
			oDataModel.read("/F4SearchHelpSet", {
				filters: aFilter,
				urlParameters: {
					MAX_HITS: max_hits,

					/* "$skip":0,
					 "$Top":20*/
				},
				success: function (oData) {
					oData = this.handleColumnData(oData, this.filedValue);
					oSearchHelpModel.setData(oData);
					oSearchHelpModel.refresh();
				}.bind(this),
				error: function () {}
			});
		},

		//Set the value of the input field from search help		
		onDrssSearchSelected: function (evt) {
			var selectedItem = evt.getSource().getBindingContext("F4Models").getObject();
			var DrssNo = selectedItem.col1;
			var Mjahr = selectedItem.col2;
			this.itemDetails.DrssNo = "0000000000";

			this.isConfigRequired = false;
			this.getRequestData(DrssNo, Mjahr, this.itemDetails.Rqtype);
			//this.byId("tbl_drss").removeSelections();
		},

		notificationPress: function (oEvent, iDelete) {

			if (iDelete) {
				var oButton = oEvent;
			} else {
				var oButton = oEvent.getSource();
			}
			var oView = controller.getView();
			if (!this.itemCommentsPop) {
				this.itemCommentsPop = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.Comments", this);
				oView.addDependent(this.itemCommentsPop);
			}
			if (iDelete) {
				var data = oButton.getParent().getParent().getBindingContext("itemsModel").getObject();
				var sPath = oButton.getParent().getParent().getBindingContext("itemsModel").getPath();
			} else {
				var data = oButton.getParent().getBindingContext("itemsModel").getObject();
				var sPath = oButton.getParent().getBindingContext("itemsModel").getPath();
			}
			oPreviousComments = data.EText;
			var oPageModel = this.getView().getModel("itemsModel").getData();
			if (oPageModel['HeaderToWfActionNav'].length > 0) {
				this.itemCommentsPop.setContentWidth("50%");
			} else {
				this.itemCommentsPop.setContentWidth("25%");
			}
			//data['EText'] = true;
			this.onOpenComment(data);
			controller.oSelCommentPath = sPath;
			//  data.VendorAdd = 'X';
			var model = new JSONModel(data);
			this.itemCommentsPop.setModel(model, "itemsComments");
			this.itemCommentsPop.open();
		},

		OnAddCmdtoField: function () {

			if (typeof controller.oSelCommentPath !== "undefined") {
				var oObject = this.getView().getModel("itemsModel").getProperty(controller.oSelCommentPath);
				//   var oField = oObject["ItemToCommNav"][0]['Text'];
				var oComment = Core.byId("ItemCommentsTxt").getValue();
				//oTxtAreaIpt = inputfield +&
				var userInfoModel = controller.getModel("UserInfoModel").getData();
				var itemsNav = this.getView().getModel("itemsModel").getData()['HeaderToItemNav'];
				$.each(itemsNav, function (ind, obj) {
					var oField = obj['ItemToCommNav'][0]['Text'];
					if (typeof obj['EText'] !== "undefined" && obj['EText'] !== "") {
						if (oField === "") {
							oField = obj['EText'] + "/b1" + new Date().toLocaleString() + "/b1" + userInfoModel['VenUserId'];
						} else {
							oField = oField + " /n1" + obj['EText'] + "/b1" + new Date().toLocaleString() + "/b1" + userInfoModel['VenUserId'];
						}
						obj['ItemToCommNav'][0]['Text'] = oField;

						delete obj['EText'];
						delete obj['SplArray'];
					}
				}.bind(this));
			}
			// Remove these two fields before submit
			//	delete oObject['EText'];
			//delete oObject['SplArray'];
			//oObject["ItemToCommNav"][0]['Text'] = oField;

			this.getView().getModel("itemsModel").refresh();

		},

		onOpenComment: function (data) {

			//var oComment = Core.byId("ItemCommentsTxt").getValue();
			var oSelObject = data["ItemToCommNav"][0];
			var oField = oSelObject['Text'];
			data['SplArray'] = [];
			var oSplittedArray = [];
			if (oField.match(/n1/g) !== null) {
				var oArr = oField.split('/n1');
				for (var obj in oArr) {
					var oInnerArr = oArr[obj].split('/b');
					var nObj = {
						Text: oInnerArr[0],
						CreatedDateTime: oInnerArr[1],
						CreatedBy: oInnerArr[2]
					}
					oSplittedArray.push(nObj);
				}
				data['SplArray'] = oSplittedArray;
			} else if (oField.match(/b1/g) !== null) {
				var oInnerArr = oField.split('/b1');
				var nObj = {
					Text: oInnerArr[0],
					CreatedDateTime: oInnerArr[1],
					CreatedBy: oInnerArr[2]
				}
				oSplittedArray.push(nObj);
				data['SplArray'] = oSplittedArray;
			}
			this.getView().getModel().refresh();
		},

		/*		
				removeEmptyText :function(data, sPath){
					var oItemModel =  this.getView().getModel('itemsModel');
					if(data['ItemToCommNav'].length > 0){
						for(var i= data['ItemToCommNav'].length -1 ; i>=0;i--){
							if(data['ItemToCommNav'][i]['Text'] === ""){
								oItemModel.getProperty(sPath)['ItemToCommNav'].splice(i, 1);
							}
						}
					}
					this.getView().getModel("itemsModel").refresh();
					//return data;
				},
				*/
		/*onAddCommentPress:function(evt){
			
	       // sap.ui.getCore().byId("idTimeline").setVisible(false);
			sap.ui.getCore().byId("ItemCommentsTxt").setVisible(true);
			//this.getView().byId("ItemCommentsTxt").setVisible(true);
			var aCommentModel = this.itemCommentsPop.getModel("itemsComments");
			var aCommentsList = aCommentModel.getData()['ItemToCommNav'];
			var getYear = new Date().getFullYear();
			var obj ={ Text:sap.ui.getCore().byId("ItemCommentsTxt").getValue(),
					   Docno: aCommentModel.getData()['Docno'],
					   Mjahr: getYear.toString(),
					   Ntdid: "ITM",
					   Tdid: "ZTXT",
					   Tdobject: "ZPDRSS",
					   Txttype: "I",
					   Zeile: aCommentModel.getData()['Zeile'] };
			aCommentsList.push(obj);
			aCommentModel.refresh();
			var ItemCommentsTxt = Core.byId("ItemCommentsTxt");
			var oLen = aCommentsList.length-1;
			var sPath = "/ItemToCommNav/"+ oLen.toString();
			ItemCommentsTxt.bindElement({ path: sPath, model: "itemsComments" });
			sap.ui.getCore().byId("ItemCommentsTxt").setValue("");
			//evt.getSource().setVisible(true);
			//ItemCommentsTxt.setVisible(false);
		},*/

		// Adding the comments color
		ItemCommentColor: function () {
			var oItemsTable = this.getView().byId("ReferenceTable").getItems();
			if (oItemsTable.length > 0) {
				//var aTableItems = oItemsTable[0].getCells()[8].setColor('#FF0000');
				for (var obj in oItemsTable) {
					var itemContext = oItemsTable[obj].getBindingContext("itemsModel").getObject();
					if (itemContext['ItemToCommNav'].length > 0) {
						var oChkValue = itemContext['ItemToCommNav'][0].Text;
						var oCell = oItemsTable[obj].getCells()[9];
						oCell.setColor('#000000');
						if (oChkValue !== "" || (typeof itemContext['EText'] !== "undefined" && itemContext['EText'] !== "")) {
							oCell.setColor('#59ed3f');
						}
					}
				}
			}
		},

		onLineItemChange: function (evt) {

			var oSource = evt.getSource().getValue();
		},

		/*onClosePopUp :function(evt){
			this.ItemCommentColor();
			var oSelTblObj = this.getView().getModel("itemsModel").getProperty(controller.oSelCommentPath);
			if(oSelTblObj.VendorAdd === ""){
			   oSelTblObj.DelInd = "V";
			}
			evt.getSource().getParent().close();
		},*/

		onSavePopUp: function (evt) {
			//	this.ItemCommentColor();

			var oSelTblObj = this.getView().getModel("itemsModel").getProperty(controller.oSelCommentPath);
			if (oSelTblObj.VendorAdd === "") {
				oSelTblObj.DelInd = "V";
			}

			evt.getSource().getParent().close();
		},
		onClosePopUp: function (evt) {
			//Do not save the additional comments, restore it to previous comments.&
			evt.getSource().getParent().getModel("itemsComments").setProperty("/EText", oPreviousComments);
			evt.getSource().getParent().close();

		},

		//Fired when SegmentedButton (item comments) is clicked
		onItemCommentsPress: function (oEvent) {
			var ItemCommentsTxt = sap.ui.getCore().byId("ItemCommentsTxt");
			var sPath = oEvent.getParameter("item").getBindingContext("itemsComments").getPath();
			ItemCommentsTxt.bindElement({
				path: sPath,
				model: "itemsComments"
			});
		},

		//Item Attachment
		attachPress: function (oEvent) {
			var oButton = oEvent.getSource();
			if (!this._pPopover) {
				this._pPopover = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.Attachments", this);
				this.getView().addDependent(this._pPopover)
			}
			this.selectedContext = oButton.getParent()._getPropertiesToPropagate()['oBindingContexts']['itemsModel'].getObject();
			controller.selectedContext = this.selectedContext;
			var oItemFileUpload = sap.ui.getCore().byId("UploadCollection");
			var oItemsModel = this.getView().getModel("itemsModel")['Rqstat'];
			if (oItemsModel === "INIT") {
				oItemFileUpload.setUploadEnabled(true);
			} else {
				oItemFileUpload.setUploadEnabled(false);
			}
			this._pPopover.openBy(oButton);
			this.oFilterItemsAttach();
		},

		oFilterItemsAttach: function () {
			//this.byId("uploadCollectionJobLog").data({ItemValue:controller.FormCode}) ;
			var oBinding = Core.byId("UploadCollection").getBinding("items");
			if (oBinding) {
				//oBinding.filter(null);
				oBinding.filter([
					new sap.ui.model.Filter("Category", "EQ", "02"),
					new sap.ui.model.Filter("Zeile", "EQ", controller.selectedContext['Zeile'])
				]);
			}
			oBinding.refresh();
		},

		/*	
		SplitAttachmentItems:function(evt){
			var oSource =  evt.getSource();
			var oContexts = oSource.getParent()._getPropertiesToPropagate()['oBindingContexts'];
			 if (oContexts){
				var oSelectedContextModel = oContexts['itemsModel'].getObject();
  				var oData = [];
				 for (var obj in  this.Attachments){
					  if (oSelectedContextModel.Zeile === this.Attachments[obj].Zeile){
						oData.push(this.Attachments[obj]);
					}
				}
			}
			 return oData;
		},*/

		onCheck: function () {
			var errorList = this.validationControlsByFieldGroupId();
			this.instantiateErrorMessageModel(errorList);
			this.createMessagePopoverModel();

			/*if(errorList.length > 0){
				this.instantiateErrorMessageModel(errorList);
					this.createMessagePopoverModel();
			}
			else{
				this.createMessagePopoverModel();
			}*/
		},

		onServiceMasterFilter: function (evt) {
			var oTable = Core.byId("serviceSelectId");
			var oBinding = oTable.getBinding("items");
			oTable.expandToLevel(100);
			var aFilters = [];
			var sQuery = evt.getSource().getValue();

			const aWords = sQuery.split(" ");
			var sWord = "";
			for (var x = 0; x < aWords.length; x++) {
				sWord = aWords[x];
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord.toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord.toUpperCase()));
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord[0].toUpperCase() + sWord.substr(1).toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord));
			}
			var oFilter = [new sap.ui.model.Filter(aFilters, false)];
			oBinding.filter(oFilter);
		},

		setViewMode: function (flag) {
			var configModel = this.getView().getModel("configModel");
			var tempOb = {
				rigno: ["/Editable"],
				prrty: ["/Editable"],
				rqddt: ["/Editable"],
				prrtyreason: ["/Editable"],
				rqdtm: ["/Editable"],
				estedt: ["/Editable"],
				wellnm: ["/Editable"],
				wcposid: ["/Editable"],
				wlltype: ["/Editable"],
				lifnr: ["/Editable"],
				shoptyp: ["/Editable"],
				phone: ["/Editable"],
				aufnr: ["/Editable"],
				ovrcc: ["/Editable"],
				estimate: ["/Editable"],
				estmtyp: ["/Editable"],
				notification: ["/Editable"],
				craftno1: ["/Editable"],
				craftno2: ["/Editable"],
				certifier: ["/Editable"],
				ident: ["/Editable"],
				deliervia: ["/Editable"],
				wllclass: ["/Editable"],
				actedt: ["/Editable"],
				area: ["/Editable"],
				distancedh: ["/Editable"],
				taxireason: ["/Editable"],
				vehtype: ["/Editable"],
				taxiroute: ["/Editable"],
				taxitrip: ["/Editable"],
				driver: ["/Editable"],
				drivernumber: ["/Editable"],
				doornumber: ["/Editable"],
				platenumber: ["/Editable"],
				comments: ["/Editable"],
				badgeno: ["/Editable"],
				maktxo: ["/Editable"],
				ServLtext: ["/Editable"],
				trdrvmobile: ["/Editable"],
				pickuplocation: ["/Editable"],
				dropofflocation: ["/Editable"],
				contract: ["/Editable"],
				flightdetails: ["/Editable"],
				hdtxt: ["/Editable"],
				addpassengerbtn: ["/Visible"],
				deletepassengerbtn: ["/Visible"],
				additembtn_ref: ["/Visible"],
				deleteitembtn_ref: ["/Visible"],
				referencetab: ['/Editable'],
				commentstab: ['/Editable']
			};

			for (var key in tempOb) {
				var prop = "/" + key + tempOb[key][0];
				configModel.setProperty(prop, flag);
			}
		},

		//Validate form fields
		validationControlsByFieldGroupId: function () {
			var oControls = this.getView().getControlsByFieldGroupId("Mandatory");
			var errorList = [];
			var check = true;
			for (var i = 0; i < oControls.length; i++) {
				var control = oControls[i];
				//Validate dropdown
				if (control.constructor === sap.m.Select) {
					if (control.getSelectedKey().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						control.setValueState("None");
						check = check && true;
					}
				}
				//Validate Input field
				if (control.constructor === sap.m.Input) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						check = check && true;
						control.setValueState("None");
					}
				}
				if (control.constructor === sap.m.TextArea) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {

						check = check && true;
						control.setValueState("None");
					}
				}
				//Validate date picker control
				if (control.constructor === sap.m.DatePicker) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						this.datePickerValidation(control);
					}
					/*else{
						check = check && true;
						control.setValueState("None");
					}*/
				}
				//Validate time picker control
				if (control.constructor === sap.m.TimePicker) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						check = check && true;
						control.setValueState("None");
					}
				}
			}
			return errorList;
		},

		// Date picker validation
		datePickerValidation: function (datePicker) {
			var dateValue = datePicker.get
		},

		onBeforeUploadStarts: function (oEvent) {
			//var oUploadCollection = oEvent.getSource();
			var oDataModel = this.getView().getModel("VendorService");

			this.AttachLevel = oEvent.getSource().data().Field;
			// this.reqItems['VEND_NAME'] = this.reqItems['VEND_NAME'].slice(0,29);
			/*	var oFileTypeSpl =  oEvent.getParameter('fileName').split('.')[1];
				oEvent.getParameter('fileName') = oEvent.getParameter('fileName').slice(0,29)+"."+oFileTypeSpl; */

			if (this.AttachLevel === "ItemAttach") {
				this.Catog = "02";
				this.itemValue = "0010";

				var oItem_Header = new sap.m.UploadCollectionParameter({
					name: "item",
					value: this.itemValue
				});

			} else if (this.AttachLevel === "JobLogAttach") {
				this.Catog = "03"
				this.itemValue = this.byId("uploadCollectionJobLog").data().ItemValue;
				var oItem_Header = new sap.m.UploadCollectionParameter({
					name: "Form",
					value: this.itemValue
				});
			} else {
				this.Catog = "01"
				this.itemValue = "0000";
				var oItem_Header = new sap.m.UploadCollectionParameter({
					name: "item",
					value: this.itemValue
				});
			}

			oDataModel.refreshSecurityToken();
			var sSecurityToken = oDataModel.getSecurityToken();

			var oSlugHeader = new sap.m.UploadCollectionParameter({
				name: "SLUG",
				value: oEvent.getParameter("fileName")
			});

			var oSecurityToken = new sap.m.UploadCollectionParameter({
				name: "X-CSRF-Token",
				value: sSecurityToken
			});

			var oReqid_Header = new sap.m.UploadCollectionParameter({
				name: "REQID",
				value: this.getDocno()
			});

			var oCate_Header = new sap.m.UploadCollectionParameter({
				name: "CATE",
				value: this.Catog
			});

			var oYear_Header = new sap.m.UploadCollectionParameter({
				name: "YEAR",
				value: this.getYear()
			});

			oEvent.getParameters().addHeaderParameter(oSlugHeader);
			oEvent.getParameters().addHeaderParameter(oSecurityToken);
			oEvent.getParameters().addHeaderParameter(oReqid_Header);
			oEvent.getParameters().addHeaderParameter(oCate_Header);
			oEvent.getParameters().addHeaderParameter(oYear_Header);
			oEvent.getParameters().addHeaderParameter(oItem_Header);

			//	oUploadCollection.setBusy(true);
		},

		getReqType: function () {
			return this.itemDetails.Rqtype;
		},

		//returen the document no which is maintained in the model
		getDocno: function () {
			return this.itemDetails.DrssNo;
		},

		//returen year
		getYear: function () {
			return this.itemDetails.Mjahr;
		},

		//Event is fired when the value of the file path has been changed.
		onUploadChange: function (evt) {
			var oFileUploader = evt.getSource();
			var oDataModel = this.getView().getModel("VendorService");
			var sServiceUrl = oDataModel.sServiceUrl;
			var sUrl = sServiceUrl + "/FileSet('" + oFileUploader.getValue() + "')";
			//	    	var sUrl = sServiceUrl + "/FileSet/";
			this.busyDialog.open();
			oDataModel.refreshSecurityToken();
			var sSecurityToken = oDataModel.getSecurityToken();
			oFileUploader.removeAllHeaderParameters();
			oFileUploader.setUploadUrl(sUrl);
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: oFileUploader.getValue()
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "X-CSRF-Token",
				value: sSecurityToken
			}));
			/*oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "Content-Type",
					value: evt.getParameter("files")[0].type&
	    	  }));*/

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "CATE",
				value: this.Catog
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "REQID",
				value: this.getDocno().toString()
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "YEAR",
				value: this.getYear().toString()
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "item",
				value: oFileUploader.data().item.toString()
			}));
			oFileUploader.upload();
			oFileUploader.clear();
		},

		//Event is fired as soon as the upload request is completed (either successful or unsuccessful)
		onUploadComplete: function (evt) {

			// this._OCReqData(this.itemDetails.DrssNo,this.itemDetails.Mjahr,this.itemDetails.Rqtype,this.itemDetails.SrvtypeCode);
			// var oModel = this.getView().getModel("VendorService");
			var oModel = this.getOwnerComponent().getModel("oReqHeaderSetModel");
			var docNo = this.getDocno();
			var year = this.getYear();
			this.oSets = "HeaderToAttNav," + "HeaderToItemNav";
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			//   var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "')";
			var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + this.itemDetails.Rqtype + "')";
			oModel.read(params, {
				urlParameters: {
					"$expand": this.oSets
				},
				success: function (oData) {
					oData.HeaderToAttNav = oData.HeaderToAttNav.results;
					var oItemsModel = this.getView().getModel("itemsModel");
					oItemsModel.setData(oData);
					//Data.HeaderToAttNav = oData.HeaderToAttNav.results;
					//oData.HeaderToAttNav = this.prepareAttachments(oData.HeaderToAttNav.results);

					//if(this.AttachLevel === "ItemAttach"){
					// this.getView().getModel("itemsAttachment").refresh();

					// this.attachPress(evt);
					//}
					//	this.prepareData(oData);
					//    this.SelectPriorities();
					//    this.SelectHoleSize();
					//    this.SelectRadius();
					// busyDialog.close();

					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
		},

		// UOM Search Dialog
		UOMSearch: function (evt) {
			var oBinding = evt.getSource().getBinding("items");
			var oSearchValue = evt.getParameter("value");
			var lowerCase = oSearchValue.toLowerCase();
			var upperCase = oSearchValue.toUpperCase();
			var asIS = oSearchValue;
			var aFilters = [
				new sap.ui.model.Filter("Value1", sap.ui.model.FilterOperator.Contains, lowerCase),
				new sap.ui.model.Filter("Value1", sap.ui.model.FilterOperator.Contains, upperCase),
				new sap.ui.model.Filter("Value1", sap.ui.model.FilterOperator.Contains, asIS),
				new sap.ui.model.Filter("Descr1", sap.ui.model.FilterOperator.Contains, lowerCase),
				new sap.ui.model.Filter("Descr1", sap.ui.model.FilterOperator.Contains, upperCase),
				new sap.ui.model.Filter("Descr1", sap.ui.model.FilterOperator.Contains, asIS)
			];
			var oFilter = [new sap.ui.model.Filter(aFilters, false)];
			oBinding.filter(oFilter);
		},

		onFilePressed: function (evt) {
			var source = evt.getSource();
			var sPath = source.getParent().getBindingContextPath();
			var oModel = source.getParent().getParent().getBinding("items").getModel();

			var dataObject = oModel.getProperty(sPath);
			var sServiceUrl = this.getView().getModel("VendorService").sServiceUrl;
			var Brelguid = dataObject.Brelguid.replaceAll("-", "");
			var url = sServiceUrl + "/FileSet('" + Brelguid + "')/$value";
			sap.m.URLHelper.redirect(url, true);
		},

		oCurrentYear: function () {
			var year = new Date();
			return year.getFullYear();
		},

		onFileDeleted: function (oEvent) {
			var docId = oEvent.getParameter("documentId");
			var oModel = this.getView().getModel("VendorService");
			oModel.read("/DeleteAttachmentSet('" + docId + "')", {

				success: function (oData) {
					// this.onUploadComplete();
					this.onUploadCompleteJob();

					this.getView().setBusy(false);
				}.bind(this),
				error: function (error) {
					this.getView().setBusy(false);
					//var msgs = this.getErrorMessages(error);
					this.onMessageHandle(error)
						//this.instantiateErrorMessageModel(msgs);
						//this.createMessagePopoverModel();
				}.bind(this)
			});

			/*      var oItem = oEvent.getParameter('item');
			     if (oItem){
				      if (oItem.getBindingContext("itemsAttachment")){
					     this.AttachLevel = "ItemAttach";
				       }else{
					     this.AttachLevel  = "HeaderAttach";
			         }
			     }
				var oModel = this.getView().getModel("VendorService");
				var docId = oEvent.getParameter("documentId");
				var year = this.oCurrentYear();;
				oModel.remove("/FileSet(Brelguid='" + docId + "')", {
					success: function (oData) {
						this.onUploadComplete();
					}.bind(this),
					error: function (error) {
						this.onMessageHandle(error)
					}.bind(this)
				});*/

		},

		/*    onFileDeleted: function (oEvent) {
			      var oItem = oEvent.getParameter('item');
			     if (oItem){
				      if (oItem.getBindingContext("itemsAttachment")){
					     this.AttachLevel = "ItemAttach";
				       }else{
					     this.AttachLevel  = "HeaderAttach";
			         }
			     }
				var oModel = this.getView().getModel("VendorService");
				var docId = oEvent.getParameter("documentId");
				var year = this.oCurrentYear();;
				oModel.remove("/FileSet(Brelguid='" + docId + "')", {
					success: function (oData) {
						this.onUploadComplete();
					}.bind(this),
					error: function (error) {
						this.onMessageHandle(error)
					}.bind(this)
				});
			},*/

		onMessageHandle: function (error) {
			if (JSON.parse(error.responseText)['error']['innererror']['errordetails'].length > 0) {
				MessageBox.error(JSON.parse(error.responseText)['error']['innererror']['errordetails'][0]['message']);
			}
		},

		//Delete a passenger
		onDeleteLineItem: function (evt) {
			this.lineItemDel = evt.getSource();
			var message = evt.getSource().data().LineItem;
			MessageBox.warning("Are you sure you want to delete the " + message + "?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						var lineItem = this.lineItemDel;

						var oTable = lineItem.getParent().getParent();
						var property = oTable.getBinding("items").getPath();
						var itemsList = this.getView().getModel("taxiModel").getProperty(property);
						var item = lineItem.getParent();
						var splittedIndex = item.getBindingContextPath().split("/");
						var index = parseInt(splittedIndex[splittedIndex.length - 1]);
						itemsList.splice(index, 1);
						this.getView().getModel("taxiModel").refresh(true);
						delete this.PassenerDel;
					}
				}.bind(this)
			});
		},

		onPrintPress: function () {
			var oDataModel = this.getView().getModel("VendorService");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: this.getDocno(),
				Year: this.getYear(),
				FormType: 'AC',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		copyFromRef: function () {

			var that = this;
			if (!this._pPopoverCopyFrom) {
				that._pPopoverCopyFrom = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.CopyFromRef", that);
			}

			that._pPopoverCopyFrom.open();

		},

		populateFields: function (sId, oContext) {

			var oField = this._Dialog.getModel("field_list").getObject(oContext + "/");

			//console.log(oField.fieldType);
			if (oField.fieldType === "Input") {

				var oInput = new sap.m.Input({
					value: "",
					showValueHelp: oField.shAvail,
					valueHelpRequest: this.getF4Value
				});
				oInput.setModel(this._Dialog.getModel("field_list"));
				oInput.setModel(this.model, "oData");
				oInput.bindValue(oContext + "/value");
				oInput.addCustomData(new sap.ui.core.CustomData({
					key: "SHLPNAME",
					value: oField.shName
				}));
				oInput.addCustomData(new sap.ui.core.CustomData({
					key: "SHLPTYPE",
					value: oField.shType
				}));
				oInput.addCustomData(new sap.ui.core.CustomData({
					key: "Fieldname",
					value: oField.shField
				}));

				oInput.attachBrowserEvent("keypress", function (e) {

					if (e.which === 13) {
						//console.log("Enter Pressed");
						this.oViewModel.setProperty("/fieldsExpanded", false);
						this.onExeucte();
					}
				}.bind(this));

				return new sap.ui.layout.form.FormElement({
					label: oField.fieldLabel,
					fields: [oInput]
				});

			} else if (oField.fieldType === "Date") {
				var oInput = new sap.m.DatePicker({
					value: "",
					valueFormat: "yyyyMMdd"
				});
				oInput.setModel(this._Dialog.getModel("field_list"));
				oInput.bindValue(oContext + "/value");

				return new sap.ui.layout.form.FormElement({
					label: oField.fieldLabel,
					fields: [oInput]
				});

			} else if (oField.fieldType === "Time") {
				var oInput = new sap.m.TimePicker({
					value: "",
					valueFormat: "HHmmss"
				});
				oInput.setModel(this._Dialog.getModel("field_list"));
				oInput.bindValue(oContext + "/value");

				return new sap.ui.layout.form.FormElement({
					label: oField.fieldLabel,
					fields: [oInput]
				});
			}
		},

		onPrintPress: function () {
			var oDataModel = this.getView().getModel("VendorService");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: this.getDocno(),
				Year: this.getYear(),
				FormType: 'RQ',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		onPrintACPress: function () {
			var oDataModel = this.getView().getModel("VendorService");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: this.getDocno(),
				Year: this.getYear(),
				FormType: 'AC',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		//Show the dialog for DRSS
		onCopyOldRef: function () {
			if (!this.DRSSDialog) {
				this.DRSSDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.f4.DRSSSearchDialog", this);
				//	this.getView().addDependent(this.DRSSDialog);	
			}
			var data = {
				drss: {
					Field: 'COPY_REF',
					Maxhit: '50',
					Descr1: '',
					Descr2: '',
					Descr3: '',
					Descr4: '',
					Referance: '',
					Referance1: ''
				}
			};
			var model = new JSONModel(data);
			this.DRSSDialog.setModel(model, "SearchModel");
			this.DRSSDialog.open();
		},

		//  Copy from Drss

		onDRSSExeucte: function (evt) {
			this.getView().getModel("SearchModel").setProperty("/drss/Referance1", this.itemDetails.Rqtype);
			var searchParams = this.getView().getModel("SearchModel").getProperty("/drss");
			this.field = searchParams.Field
			this.loadDomainF4Values(searchParams);
		},

		onWFGraphOC: function () {
			//	this.getView().getModel("WFGraphModel")
			var model = new JSONModel();
			this.getView().setModel(model, "WFGraphModel");
			var oModel = this.getView().getModel("itemsModel").getProperty("/HeaderToWfLogNav");
			this.onWFGraph(oModel);
		},

		onCloseWF: function () {
			this.WFGraphDialog.close();
			this.WFGraphDialog.destroy();
			delete this.WFGraphDialog;
		},

		changeWFActionButton: function () {

			var wfButtons = this.getView().getModel("itemsModel").getProperty("/HeaderToWfActionNav");
			if (wfButtons.length > 0) {
				for (var i = wfButtons.length - 1; i >= 0; i--) {
					if (wfButtons[i].Actlabel === "Accept") {
						this.getView().getModel("itemsModel").getData()['HeaderToWfActionNav'].splice(i, 1);
					}

					if (wfButtons[i].Actlabel === "Reject") {
						this.getView().getModel("itemsModel").getData()['HeaderToWfActionNav'].splice(i, 1);
					}

					if (wfButtons[i].Actlabel === "Return") {
						this.getView().getModel("itemsModel").getData()['HeaderToWfActionNav'].splice(i, 1);
					}
				}
			}
			this.getView().getModel("itemsModel").refresh();
		},
		onRejectSelection: function (evt) {

			//var oSelectedItem = evt.getParameter("selectedItem").getBindingContext("mRejectedReason").getObject();
			var oSelectedItem = evt.getParameter('value');
			if (oSelectedItem === 'Other') {
				this.getView().byId("commentInput").setVisible(true);
				this.getView().byId("commentLabel").setVisible(true);
				this.dRejectedReason.getModel('mRejectedReason').refresh();
				return;
			} else {
				this.getView().byId("commentInput").setVisible(false);
				this.getView().byId("commentLabel").setVisible(false);
			}
			this.getView().byId("selectinput").setValueState("None");
			this.sSelectedReason = false;
		},

		onSelectLiveChange: function (evt) {
			var oSelectedKey = evt.getSource().getSelectedKey();
			if (oSelectedKey === '') {
				evt.getSource().setValueState("Error");
			} else {
				evt.getSource().setValueState("None");
			}
		},

		onSubReason: function () {

			var oControl = this.getView().byId("selectinput");
			var oCommentField = this.getView().byId("commentInput");
			if (oControl.getSelectedKey() == "" || oControl.getSelectedKey() === "Other") {
				if (oControl.getSelectedKey() == "Other") {

					if (oCommentField.getValue() === "") {
						sap.m.MessageBox.error("Please Enter reason!");
						oCommentField.setValueState("Error");
						return;
					} else {
						oCommentField.setValueState("None");
					}
				}
				if (oControl.getSelectedKey() == "") {
					sap.m.MessageBox.error("Please select a Reason");
					oControl.setValueState('Error');
					return;
				} else {
					oControl.setValueState('None');
				}

			} else {

				oCommentField.setValueState('None');
				oControl.setValueState('None');
			}

			if (oControl.getSelectedKey() == "Other") {
				this.oRejReasonText = this.getView().byId("commentInput").getValue();
			} else {
				this.oRejReasonText = oControl.getSelectedKey();
			}

			this.oSeletedReason = "";
			this.sSelectedReason = false;
			this.oSeletedReason = this.getView().byId("commentInput").getValue();
			this.onWFAction();
			this.dRejectedReason.close();

		},

		// On vendor refrence live chaneg
		onVendorRefNum: function (evt) {
			var getSource = evt.getParameter('value');
			this.changeMade = "";
			if (getSource !== "") {
				this.changeMade = "X";
				//this.changeWFActionButton();
			} else {
				//this.changeWFActionButton();
			}

		},

		// On rejection Reason
		_onRejectionReason: function (btnText) {
			var oPageModel = this.getView().getModel("itemsModel").getData();
			var oModel = this.getView().getModel("oDataModel");
			if (btnText === "Reject") {
				var oReasonType = "REJ";
			} else {
				var oReasonType = "RET";
			}
			this.busyDialog.open();
			var aFilters = [];
			//  if(!this.dRejectedReason){
			aFilters.push(new Filter("Field", FilterOperator.EQ, "REJECT_RES"));
			aFilters.push(new Filter("Referance", FilterOperator.EQ, oReasonType));
			aFilters.push(new Filter("Referance1", FilterOperator.EQ, oPageModel['Srvtyp']));
			aFilters.push(new Filter("Referance2", FilterOperator.EQ, oPageModel['Location']));
			oModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					if (!this.dRejectedReason) {
						this.dRejectedReason = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.f4.RejectionReasonDialog",
							this);
						this.getView().addDependent(this.dRejectedReason);
					}

					oData['title'] = btnText;
					oData.results.push({
						Descr1: "Other"
					})
					var model = new JSONModel(oData);
					this.dRejectedReason.setModel(model, "mRejectedReason");
					this.dRejectedReason.getModel('mRejectedReason').setSizeLimit(oData.results.length);
					this.dRejectedReason.open();
					this.getView().byId("commentInput").setVisible(false);
					this.getView().byId("commentLabel").setVisible(false);
					this.getView().byId("commentInput").setValue("");
					this.getView().byId("selectinput").setSelectedKey('');
					this.getView().byId("selectinput").setValueState('None');
					this.getView().byId("selectinput").setValueState('None');
					this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.busyDialog.open();
				}.bind(this)
			});

			//  }

			/* else {
	&&&&&&&&&&&
	           this.getView().byId("commentInput").setVisible(false);
               this.getView().byId("commentLabel").setVisible(false);
	           this.getView().byId("commentInput").setValue("");
               this.getView().byId("selectinput").setSelectedKey('');
	           this.dRejectedReason.open();
           }*/
		},
		onClose: function (evt) {
			this.sSelectedReason = true;
			evt.getSource().getParent().close();
		},

		_AddedByVendorsItems: function (items) {
			$.each(items, function (ind, obj) {
				if (obj['VendorAdd'] === "X1") {
					obj['VendorAdd'] = "X";
				}
			});
			return items;
		},

		onWFAction: function (oEvent) {
			var oPgData = this.getView().getModel("itemsModel").getData();
			var ReqItems = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var ReqItems = this._AddedByVendorsItems(ReqItems);
			var length = ReqItems.length;
			this.serviceNotAvailed = false;
			if (oEvent) {
				var oButtontext = oEvent.getSource().getText();
				this.sWrkflwBtnTxt = oButtontext;
			}

			this.serviceAvailed = false;
			for (var i = 0; i < length; i++) {
				if (ReqItems[i].DelInd === "" && ReqItems[i].DispFilled === "X") {
					this.serviceAvailed = true;
				}
			}

			if (this.serviceAvailed === false) {
				sap.m.MessageBox.error("Please fill atleast one service");
				return;
			}

			for (var i = 0; i < length; i++) {
				if (ReqItems[i].DelInd === "" && ReqItems[i].DispFilled === "") {
					this.serviceNotAvailed = true;
				}
			}
			if (this.serviceNotAvailed) {
				MessageBox.warning("Not all Service Order line items are mapped to PO line items. Do you want to continue ?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: "sapUiSizeCompact",
					onClose: function (sAction) {
						if (sAction === "YES") {
							this.onWFActionExecute();
						}
					}.bind(this)
				});
			} else {
				this.onWFActionExecute();
			}

		},

		onWFActionExecute: function (oEvent) {
			//var oActionItems = oEvent.getSource().getBindingContext("itemsModel").getProperty(oEvent.getSource().getBindingContext("itemsModel").getPath());
			var oPgData = this.getView().getModel("itemsModel").getData();
			var ReqItems = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var ReqItems = this._AddedByVendorsItems(ReqItems);
			var length = ReqItems.length;

			var oActionItems = {};
			$.each(oPgData['HeaderToWfActionNav'], function (ind, obj) {
				if (obj['Actlabel'] === this.sWrkflwBtnTxt) {
					oActionItems = obj;
				}
			}.bind(this))

			if (typeof oPgData !== "undefined") {
				var ReqItemsSet = oPgData.HeaderToItemNav;
			}

			if (this.sWrkflwBtnTxt !== "Reject") {

				if (this.changeMade === "X" && oPgData.Rqstat !== 'ACPT' && (oActionItems.Action === "03" || oActionItems.Action === "02")) {
					sap.m.MessageBox.error("Changes Made. Press Revise Button");
					return;
				}
				if (this.changeMade !== "X" && this.sWrkflwBtnTxt !== "Return" && oPgData.Rqstat !== 'ACPT') {
					sap.m.MessageBox.error("No changes Made. Please fill service");
					return;
				}

				for (var i = 0; i < length; i++) {
					if (ReqItems[i].ServLtext === "") {
						sap.m.MessageBox.error("Service Name cannot be empty");
						return;
					}

					/*if(ReqItems[i].Menge === ""){
						sap.m.MessageBox.error("Service Quantity cannot be empty");
						return;
					}*/

					if (ReqItems[i].Meins === "") {
						sap.m.MessageBox.error("Service UoM cannot be empty");
						return;
					}

					/*if (ReqItems[i]['PoNo'] ==="" && this.sWrkflwBtnTxt ==="Revise"){
						sap.m.MessageBox.error("Please select po line item!");
						return;&
					}*/
				}
				//sSelectedReason
			}

			this.sText = "";
			//Core.byId("submissionNote").setValue(sText);
			//var sAction = "Revise";

			//TODO: change sAction based on the selected button

			//only if it is revise or reject
			if (oActionItems.RemarksReq === 'X' || this.sWrkflwBtnTxt === "Reject" || this.sWrkflwBtnTxt === "Return") {

				if ((this.sWrkflwBtnTxt === "Reject" || this.sWrkflwBtnTxt === "Return") && this.sSelectedReason) {
					this._onRejectionReason(this.sWrkflwBtnTxt);
					return;
				}

				if (this.sWrkflwBtnTxt !== "Reject" && this.sWrkflwBtnTxt !== "Return") {

					/*if (!this.oSubmitDialog) {*/
					this.oSubmitDialog = new Dialog({
						type: DialogType.Message,
						title: "Confirm",
						content: [
							new Label({
								//	text: "The request will be submitted as "+sAction+". Do you want to continue ?",
								text: "Do you want to continue ?",
								labelFor: "submissionNote"
							}),
							new sap.m.TextArea({
								width: "100%",
								value: "",
								growingMaxLines: 15,
								growing: true,
								placeholder: "Remarks (required)",
								liveChange: function (oEvent) {
									this.sText = oEvent.getParameter("value");
									this.oSubmitDialog.getBeginButton().setEnabled(this.sText.length > 0);
								}.bind(this)
							})
						],
						beginButton: new Button({
							type: ButtonType.Emphasized,
							text: "Submit",
							enabled: false,
							press: function () {

								var aPromise = [];
								aPromise.push(this.onSaveOC());
								Promise.all(aPromise).then(function (results) {
									var sText = this.sText;
									var ReqItemsSet = undefined;
									this.sSelectedReason = true;
									this.WFExecuteAction(this.DrssNo, this.Mjahr, oActionItems.Action, oActionItems.Stattype, sText, this.Gid, ReqItemsSet);

								}.bind(this));

								this.oSubmitDialog.close();
							}.bind(this)
						}),
						endButton: new Button({
							text: "Cancel",
							press: function () {
								this.sSelectedReason = true;
								this.oSubmitDialog.close();
							}.bind(this)
						})
					});
					this.oSubmitDialog.open();
				} else {
					//var sText = this.sText;
					var ReqItemsSet = undefined;
					this.sSelectedReason = true;
					this.WFExecuteAction(this.DrssNo, this.Mjahr, oActionItems.Action, oActionItems.Stattype, this.oRejReasonText, this.Gid,
						ReqItemsSet);

				}
				/*}*/

			} else {
				MessageBox.information("Do you want to continue ?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: "sapUiSizeCompact",
					onClose: function (sAction) {
						if (sAction === "YES") {
							var ReqItemsSet = undefined;
							this.sSelectedReason = true;
							this.WFExecuteAction(this.DrssNo, this.Mjahr, oActionItems.Action, oActionItems.Stattype, '', this.Gid, ReqItemsSet);
						} else {
							this.sSelectedReason = true;
						}
					}.bind(this)
				});
			}
		},

		onDispItemPress: function (oEvent) {
			var ReqItems = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var length = ReqItems.length;
			for (var i = 0; i < length; i++) {
				if (ReqItems[i].ServLtext === "") {
					sap.m.MessageBox.error("Service Name cannot be empty");
					return;
				}

				/*if(ReqItems[i].Menge === ""){
					sap.m.MessageBox.error("Service Quantity cannot be empty");
					return;
				}*/

				if (ReqItems[i].Meins === "") {
					sap.m.MessageBox.error("Service UoM cannot be empty");
					return;
				}
			}
			var oItem = oEvent.getSource().getBindingContext('itemsModel').getObject();
			var oItemPath = oEvent.getSource().getBindingContext('itemsModel').sPath;
			this.oItemPath = oItemPath;

			var iPoNum = "";
			if (typeof oItem.PoNo !== "undefined" && typeof oItem.PoNo !== "") {
				var iPoNum = parseInt(oItem.PoNo);
			}
			var iPoItem = "";
			if (typeof oItem.PoItem !== "undefined" && typeof oItem.PoItem !== "") {
				var iPoItem = parseInt(oItem.PoItem);
			}
			var sLim_ind = oItem.LimitInd;
			var sCO_ind = oItem.CoInd;
			this.changeMade = "X";
			//this.changeWFActionButton();

			if ((iPoNum !== 0) && (iPoItem !== 0)) {

				if (typeof sCO_ind === "undefined" || sCO_ind === "") {
					if (typeof oItem.PoNo !== "undefined") {
						if (oItem.PoNo.substring(0, 2) === "66") {
							sCO_ind = "C";
						} else {
							sCO_ind = "PO";
						}
					} else {
						sCO_ind = "PO";
					}

				}

				if (typeof sLim_ind === "undefined" || sLim_ind === "") {
					sLim_ind = "0";
				}
				//this.getRouter().navTo("DispatchedServices", {objectId : this.getRequestId(), item: oItem.getProperty("Zeile"), EBELN: iPoNum, EBELP: iPoItem, lim_ind: sLim_ind, co_ind: sCO_ind  }, true);

				if (!this._DispServicesDialog) {
					this._DispServices = new DispatchedServicesSplit(this, "zdwo_nx_drss_ven.view.fragment.DispatchedServicesSplit");
				}
				this._DispServicesDialog = this._DispServices.createFragment(oItem.Docno, oItem.Zeile, iPoNum, iPoItem, "", sLim_ind, sCO_ind,
					oItem.ServiceId, oItem['Maktxo'], oItem);

				return;
			}
			var oModel = this.getView().getModel("VendorService");
			new POContractSelector(this.getView(), oModel, this, this.getView().getModel('itemsModel').getProperty("/Lifnr"),
				this.Rqtype,
				function (oPOItem) {

					iPoNum = oPOItem.EBELN;
					iPoItem = oPOItem.EBELP;

					// Update the selected PO/Line item of the request.
					oModel.callFunction("/SetPOForReqItm", {
						method: "GET",
						urlParameters: {
							Docno: oItem.Docno,
							Zeile: oItem.Zeile,
							PO: oPOItem.EBELN,
							PONO: oPOItem.EBELP

						},
						success: function (oData) {
							// me.hit_list.setData(oData)
							this.getView().getModel().setProperty(oItemPath + "/PoItem", oPOItem.EBELP);
							this.getView().getModel().setProperty(oItemPath + "/PoNo", oPOItem.EBELN);

							// console.log(oData);
							var Contract = oPOItem.EBELN;
							var Rqtype = oItem.Rqtype;
							var that = this;
						}.bind(this),
						error: function (error) {

						}
					});
					// Navigate to Dispatched services.
					//this.getRouter().navTo("DispatchedServices", {objectId : this.getRequestId(), item: oItem.Zeile, EBELN: oPOItem.EBELN, EBELP: oPOItem.EBELP }, true);

					if (!this._DispServicesDialog) {
						this._DispServices = new DispatchedServicesSplit(this, "zdwo_nx_drss_ven.view.fragment.DispatchedServicesSplit");
					}
					this._DispServicesDialog = this._DispServices.createFragment(oItem.Docno, oItem.Zeile, iPoNum, iPoItem, "", sLim_ind, sCO_ind,
						oItem['ServiceId'], oItem['Maktxo'], oItem);
				}.bind(this));
		},

		onDispatchSavePress: function (evt) {
			DispatchedServicesSplit.onAcceptConfirmation(evt);
			this._DispServicesDialog.close();
		},

		/*onFormTypeSelect : function(oEvent){
			var Data = oEvent.getSource().getBindingContext("JobLoggingModel").getProperty(oEvent.getSource().getBindingContext("JobLoggingModel").getPath());
			var itemModelData = this.getItemModelData();
			eTicket = "";
			FormCode = Data.FormCode;
		   	this.getRouter().navTo(Data.FormRout, {
				DrssNo: itemModelData.Docno,
				Rqtype: itemModelData.Rqtype,
				Gid:  this.Gid,
				Mjahr:  itemModelData.Mjahr,
				Srvtype : itemModelData.SrvtypeCode
			});
			
			//this.getRouter().navTo("JL");
		},*/

		onFormTypeSelecteTicket: function (oEvent) {
			var Data = oEvent.getSource().getBindingContext("JobLoggingModel").getProperty(oEvent.getSource().getBindingContext(
				"JobLoggingModel").getPath());
			var itemModelData = this.getItemModelData();
			eTicket = "X";
			FormCode = Data.FormCode;
			var makeDate = itemModelData.Reqdt;
			makeDate.setMonth(makeDate.getMonth() - 1);
			var lastmonth = makeDate.getMonth() + 1;
			var lastyear = makeDate.getFullYear();
			this.getRouter().navTo(Data.FormRout, {
				DrssNo: itemModelData.Docno,
				Rqtype: itemModelData.Rqtype,
				Gid: this.Gid,
				Mjahr: itemModelData.Mjahr,
				Srvtype: itemModelData.SrvtypeCode,
				Zmonth: lastmonth,
				Zyear: lastyear
			});

			controller.oETickVerChange = 'VersionChange';
			controller.oSelVersion = this.getView().getModel("oETicketModel").getData().Version;

			//this.getRouter().navTo("JL");
		},

		onJobLoggingListPress: function (oEvent) {
			var Data = oEvent.getSource().getBindingContext("JobLoggingModel").getProperty(oEvent.getSource().getBindingContext(
				"JobLoggingModel").getPath());
			var formType = Data.FormType;
			eTicket = "";
			FormCode = Data.FormCode;
			controller.FormCode = Data.FormCode;

			if (formType === "AF") {
				if (!this.JobLogAttachmentsDialog) {
					this.JobLogAttachmentsDialog = sap.ui.xmlfragment(this.getView().getId(),
						"zdwo_nx_drss_ven.view.fragment.OC.JobLogAttachmentsDialog", this);
					this.getView().addDependent(this.JobLogAttachmentsDialog);
				}
				//this.JobLogAttachmentsDialog.setModel("itemsModel");
				/*	this.JobLogAttachmentsDialog.open();&
					this.oFilterJobLogAttach();	
					this.JobLogAttachmentsDialog.setTitle(Data.FormName + " - Attachments");*/

				var itemsModel = this.getView().getModel("itemsModel").getData();
				this.byId("uploadCollectionJobLog").setUploadEnabled(false);

				if (typeof Data['FormCode'] !== 'undefined') {
					if (Data['FormFreq'] === "03") {
						this.onmonthlyAttachment(Data);
						//this.byId("uploadCollectionJobLog").setUploadEnabled(false);
					} else {
						this.JobLogAttachmentsDialog.open();
						this.oFilterJobLogAttach();
						this.JobLogAttachmentsDialog.setTitle(Data.FormName + " - Attachments");
						this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
					}
				}

				// SrvTreeConversion.UploadBtnVisibility(Data,controller);

				/* if (typeof Data['FormCode'] !=='undefined'){
				   if (Data['FormFreq'] === "03"){
					 this.onmonthlyAttachment(Data);&&
					 //this.byId("uploadCollectionJobLog").setUploadEnabled(false);
				   }else{
					   this.JobLogAttachmentsDialog.open();&
						this.oFilterJobLogAttach();	
						this.JobLogAttachmentsDialog.setTitle(Data.FormName + " - Attachments");					&&&
					   this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
				  }
				}*/

				/*if (typeof Data['FormCode'] !=='undefined'){
				   if (Data['FormFreq'] === "03"){
					 this.byId("uploadCollectionJobLog").setUploadEnabled(false);
				   }else if(Data['FormFreq'] === "01" && (itemsModel['Rqstat'] === "JOBL" || itemsModel['Rqstat'] === "ACPT" || itemsModel['Rqstat'] === "ETKR")){
					this.byId("uploadCollectionJobLog").setUploadEnabled(true);
				  }
				}*/
			} else if (formType === "EF") {
				var itemModelData = this.getItemModelData();
				var makeDate = itemModelData.Reqdt;
				makeDate.setMonth(makeDate.getMonth() - 1);
				var lastmonth = makeDate.getMonth() + 1;
				var lastyear = makeDate.getFullYear();
				this.getRouter().navTo(Data.FormRout, {
					DrssNo: itemModelData.Docno,
					Rqtype: itemModelData.Rqtype,
					Gid: this.Gid,
					Mjahr: itemModelData.Mjahr,
					Srvtype: itemModelData.SrvtypeCode,
					Zmonth: lastmonth,
					Zyear: lastyear,
					FormCode: FormCode,
					Version: '0'
				});
			}

		},

		onmonthlyAttachment: function (Data) {
			var monthlyData = controller.getView().getModel("itemsModel").getObject("/HeaderToAttNav");
			var results = monthlyData.filter(obj => {
				return obj.Category === '03' && obj.Formcode === Data.FormCode
			});

			if (results.length === 0) {
				sap.m.MessageBox.error('There is no document available');
				return;
			}
			this.getView().getModel("oMonthlyListModel").setData(null);
			this.getView().getModel("oMonthlyListModel").setData(results);
			this.getView().getModel("oMonthlyListModel").refresh(true);
			if (!this.onmonthlyAttachmentDialog) {
				this.onmonthlyAttachmentDialog = sap.ui.xmlfragment(this.getView().getId(),
					"zdwo_nx_drss_ven.view.fragment.JobLogging.JobLoggingMonthlyList", this);
				this.getView().addDependent(this.onmonthlyAttachmentDialog);
			}
			this.onmonthlyAttachmentDialog.open();
			this.onmonthlyAttachmentDialog.setTitle(Data.FormName + " - Attachments");

		},

		onCloseMonthly: function () {
			if (this.onmonthlyAttachmentDialog) {
				this.onmonthlyAttachmentDialog.close();
			}

		},

		oFilterJobLogAttach: function () {
			this.byId("uploadCollectionJobLog").data({
				ItemValue: controller.FormCode
			});
			var oBinding = this.byId("uploadCollectionJobLog").getBinding("items");
			if (oBinding) {
				//oBinding.filter(null);
				oBinding.filter([
					new sap.ui.model.Filter("Category", "EQ", "03"),
					new sap.ui.model.Filter("Formcode", "EQ", controller.FormCode)
				]);
			}
			oBinding.refresh();
		},

		onJobLoggingListPresseTicket: function (oEvent) {
			var Data = oEvent.getSource().getBindingContext("JobLoggingModel").getProperty(oEvent.getSource().getBindingContext(
				"JobLoggingModel").getPath());
			var formType = Data.FormType;
			eTicket = "X";
			FormCode = Data.FormCode;
			controller.FormCode = Data.FormCode;
			if (formType === "AF") {
				if (!this.JobLogAttachmentsDialog) {
					this.JobLogAttachmentsDialog = sap.ui.xmlfragment(this.getView().getId(),
						"zdwo_nx_drss_ven.view.fragment.OC.JobLogAttachmentsDialog", this);
					this.getView().addDependent(this.JobLogAttachmentsDialog);
				}
				/*	this.JobLogAttachmentsDialog.open();
					this.oFilterJobLogAttach();	*/
				//var sPath = oEvent.getSource().getBindingContextPath();
				//this.JobLogAttachmentsDialog.bindElement({model:"JobLoggingModel",path:sPath});
				//this.getView().getModel("JobLoggingModel").refresh();
				//this.byId("uploadCollectionJobLog").data({ItemValue:Data.FormCode});
				/*var oBinding = this.byId("uploadCollectionJobLog").getBinding("items");
				if(oBinding){
					oBinding.filter(null);
					oBinding.filter([
						new sap.ui.model.Filter("Category","EQ","03"),
						new sap.ui.model.Filter("Formcode","EQ",Data.FormCode)	
						]);
				}*/
				var itemsModel = this.getView().getModel("itemsModel").getData();
				if (typeof Data['FormCode'] !== 'undefined') {
					if (Data['FormFreq'] === "03") {
						this.onmonthlyAttachment(Data);
						//this.byId("uploadCollectionJobLog").setUploadEnabled(false);
					} else {
						this.JobLogAttachmentsDialog.open();
						this.oFilterJobLogAttach();
						this.JobLogAttachmentsDialog.setTitle(Data.FormName + " - Attachments");
						this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
					}
				}
				//SrvTreeConversion.UploadBtnVisibility(Data,controller);
				/* if (typeof Data['FormCode'] !=='undefined'){
				   if (Data['FormFreq'] === "03"){
					 this.onmonthlyAttachment(Data);&&
					 //this.byId("uploadCollectionJobLog").setUploadEnabled(false);
				   }else{
					   this.JobLogAttachmentsDialog.open();&
						this.oFilterJobLogAttach();	
						this.JobLogAttachmentsDialog.setTitle(Data.FormName + " - Attachments");					&&&
					   this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
				  }
				}*/

				/*if (typeof Data['FormCode'] !=='undefined'){
			   if (Data['FormFreq'] === "03"){
				 this.byId("uploadCollectionJobLog").setUploadEnabled(false);
			   }else if(Data['FormFreq'] === "01" && (itemsModel['Rqstat'] === "JOBL" || itemsModel['Rqstat'] === "ACPT" || itemsModel['Rqstat'] === "ETKR")){
				this.byId("uploadCollectionJobLog").setUploadEnabled(true);
			  }
			}	*/
			} else if (formType === "EF") {
				var itemModelData = this.getItemModelData();
				var makeDate = itemModelData.Reqdt;
				makeDate.setMonth(makeDate.getMonth() - 1);
				var lastmonth = makeDate.getMonth() + 1;
				var lastyear = makeDate.getFullYear();
				this.getRouter().navTo(Data.FormRout, {
					DrssNo: itemModelData.Docno,
					Rqtype: itemModelData.Rqtype,
					Gid: this.Gid,
					Mjahr: itemModelData.Mjahr,
					Srvtype: itemModelData.SrvtypeCode,
					Zmonth: lastmonth,
					Zyear: lastyear,
					FormCode: FormCode
				});
			} else {
				// Do Nothing
			}

		},

		onUploadCompleteJob: function (evt) {
			//controller.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getModel().setProperty(controller.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getPath()+"/FormStatus","SUBT")
			//this.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getModel().refresh();
			//var sPath = this.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getPath();
			//this.JobLogAttachmentsDialog.unbindElement("itemsModel");
			//this.JobLogAttachmentsDialog.bindElement({model:"itemsModel",path:sPath});

			// this._OCReqData(this.itemDetails.DrssNo,this.itemDetails.Mjahr,this.itemDetails.Rqtype,this.itemDetails.SrvtypeCode);

			if (typeof evt !== "undefined" && evt.mParameters.mParameters.status !== 201) {
				var responseRaw = evt.mParameters.mParameters.responseRaw;
				var start = responseRaw.indexOf("<errordetails>");
				var list = [];
				if (start > -1) {

					var end = responseRaw.indexOf("</errordetails>");
					var message = responseRaw.substr(start, end);
					var errorMessages = message.split("<message>");
					for (var i = 0; i < errorMessages.length; i++) {
						var erMsg = errorMessages[i];
						if (erMsg.indexOf("</message>") > -1) {
							var msg = {
								severity: "Error",
								message: erMsg.substr(0, erMsg.indexOf("</message>")),
								description: erMsg.substr(0, erMsg.indexOf("</message>"))
							};
							list.push(msg);
						}
					}
					if (list.length > 0) {
						this.instantiateErrorMessageModel(list);
						this.createMessagePopoverModel();

					}
				}

			} else {
				// var oModel = this.getView().getModel("VendorService");
				var oModel = this.getOwnerComponent().getModel("oReqHeaderSetModel");
				var docNo = this.getDocno();
				var year = this.getYear();
				this.oSets = "HeaderToAttNav," + "HeaderToItemNav";
				var busyDialog = new sap.m.BusyDialog({
					title: 'Loading...'
				});
				busyDialog.open();

				var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + this.itemDetails.Rqtype + "')";
				oModel.read(params, {
					urlParameters: {
						"$expand": this.oSets
					},
					success: function (oData) {
						this.getJoblogging();
						this.getView().getModel("itemsModel").getData()['HeaderToAttNav'] = oData['HeaderToAttNav']['results'];
						this.getView().getModel("itemsModel").refresh();
						this.oFilterJobLogAttach();
						busyDialog.close();
					}.bind(this),

					error: function (oResponse) {
						busyDialog.close();
						if (oResponse.responseText) {
							var parsedJson = JSON.parse(oResponse.responseText);
							sap.m.MessageBox.error(parsedJson.error.message.value);
						}

					}.bind(this)
				});

			}
			//   var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "')";
		},

		getItemModelData: function () {
			return this.getView().getModel("itemsModel").getData();
		},

		getJobLoggingModelData: function () {
			return this.getView().getModel("JobLoggingModel").getData();
		},

		onTreeSearchMaster: function (evt) {

			var oTable = Core.byId("treeMaster");
			var oBinding = oTable.getBinding("items");
			oTable.expandToLevel(100);
			var aFilters = [];
			var sQuery = evt.getSource().getValue();

			const aWords = sQuery.split(" ");
			var sWord = "";
			for (var x = 0; x < aWords.length; x++) {
				sWord = aWords[x];
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord.toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord.toUpperCase()));
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord[0].toUpperCase() + sWord.substr(1)
					.toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord));
			}
			var oFilter = [new sap.ui.model.Filter(aFilters, false)];
			oBinding.filter(oFilter);

		},
		//HeaderToSaudizationNav
		getETicketInfo: function (oEvent, oETickVerChange) {
			// var oETicketingService = this.getView().getModel("oETicketingService");
			var oETicketingService = this.getView().getModel("oETicketHdr");
			this.busyDialog.open();
			this.sStatus = oEvent;
			var oSelectedVersion = "";
			if (oETickVerChange === 'VersionChange') {
				var oSelectedVersion = oEvent.getSource().getText();

			} else if (controller.oETickVerChange === 'VersionChange') {
				var oSelectedVersion = controller.oSelVersion;
			}

			if (oEvent === "JOBL") {
				var sEntityPath = oETicketingService.createKey("/ETicketHdrSet", {
					Etkt: "",
					Version: oSelectedVersion
				});
				var aFilters = []; /**/
				aFilters.push(new sap.ui.model.Filter("Docno", sap.ui.model.FilterOperator.EQ, this.getDocno()));
				aFilters.push(new sap.ui.model.Filter("Mjahr", sap.ui.model.FilterOperator.EQ, this.Mjahr));
			} else {
				var sEntityPath = oETicketingService.createKey("/ETicketHdrSet", {
					Etkt: this.getDocno(),
					Version: oSelectedVersion
				});
			}

			if (this.eTicketDialog) {
				this.eTicketDialog.setBusy(true);
			}

			oETicketingService.read(sEntityPath, {
				filters: aFilters,
				urlParameters: {
					"$expand": "HeaderToItemNav,HeaderToRemarksNav,HeaderToWfLogNav,HeaderToOLDWfLogNav,HeaderToVrsnNav,HeaderToSaudizationNav,HeaderToFinanceDataNav"
				},
				success: function (oData) {

					if (oData.Dispute === "X") {
						this.getView().getModel("DisputeVisibilityModel").getData().DisputeVisibility = true;
					}
					this.getView().getModel("DisputeVisibilityModel").refresh(true);

					var oETicketModel = this.getView().getModel("oETicketModel");
					oData['HeaderToItemNav'] = oData['HeaderToItemNav'].results;
					oData['HeaderToEDrssNav'] = oData['HeaderToEDrssNav'].results;
					oData['HeaderToEFormsNav'] = oData['HeaderToEFormsNav'].results;
					oData['HeaderToWfLogNav'] = oData['HeaderToWfLogNav'].results;
					oData['HeaderToVrsnNav'] = oData['HeaderToVrsnNav'].results;
					oData['HeaderToSaudizationNav'] = oData['HeaderToSaudizationNav'].results;
					oData['HeaderToFinanceDataNav'] = oData['HeaderToFinanceDataNav'].results;

					oData['HeaderToRemarksNav'] = oData['HeaderToRemarksNav'].results;

					oData['eTicket'] = oData['HeaderToItemNav'];
					oData['eDrss'] = oData['HeaderToEDrssNav'];
					oData['verDetailsTaxi'] = oData['HeaderToEFormsNav'];
					oData['saudiDetails'] = oData['HeaderToSaudizationNav'];

					this.getView().getModel("data").setData(oData);
					oETicketModel.setData(oData);
					this.getOwnerComponent().setModel(oETicketModel, "oCompETicketModel");
					if (controller.byId("ProcessFlowId")) {
						controller.byId("ProcessFlowId").updateModel(true);
					}

					if (controller.byId("processFlowHeader")) {
						controller.byId("processFlowHeader").updateModel(true);
					}

					if (oETickVerChange === 'VersionChange') {
						this.onPreviewETicketPress('VersionChange');

					}

					if (this.eTicketDialog) {
						this.eTicketDialog.setBusy(false);
					}
					this.busyDialog.close();

				}.bind(this),

				error: function (oError) {
					this.busyDialog.close();
					if (oError.responseText) {
						var parsedJson = JSON.parse(oError.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}
				}.bind(this)
			});

		},

		_getInputComment: function () {
			var oETicketData = this.getView().getModel("oETicketModel").getData();
			this.eTicketingCommentsDialog = new Dialog({
				type: DialogType.Message,
				title: "Do you want to continue ?",
				content: [
					/*new Label({
						text: "Do you want to continue ?",
						labelFor: "submissionNote"
					}),*/
					new sap.m.TextArea({
						width: "100%",
						value: "",
						growingMaxLines: 15,
						growing: true,
						placeholder: "eTicket Remarks (required)",
						liveChange: function (oEvent) {
							var oComments = oEvent.getParameter("value");
							oETicketData.Comments = oComments;
							this.eTicketingCommentsDialog.getBeginButton().setEnabled(oComments.length > 0);
						}.bind(this)
					})
				],
				beginButton: new Button({
					type: ButtonType.Emphasized,
					text: "Submit",
					enabled: false,
					press: function () {
						this.onGenerateETicket();
						this.eTicketingCommentsDialog.close();
					}.bind(this)
				}),
				endButton: new Button({
					text: "Cancel",
					press: function () {
						//	this.sSelectedReason=true;
						this.eTicketingCommentsDialog.close();
					}.bind(this)
				})
			});
			this.eTicketingCommentsDialog.addStyleClass('eTicketWidthClass');
			this.eTicketingCommentsDialog.open();
		},

		/*  _getInputComment : function() {
	
				var oETicketData = this.getView().getModel("oETicketModel").getData();
				this.eTicketingCommentsDialog = new Dialog({
							type: DialogType.Message,
							title: "Confirm",
							content: [
								new Label({
								//	text: "The request will be submitted as "+sAction+". Do you want to continue ?",
									text: "Do you want to continue ?",
									labelFor: "submissionNote"
								}),
								new sap.m.TextArea({
									width: "100%",
									value:"",
									growing : true,
									growingMaxLines: 15,
									placeholder: "eTicket Remarks (required)",
									liveChange: function (oEvent) {
										
										var oComments = oEvent.getParameter("value");
										oETicketData.Comments = oComments;
										this.eTicketingCommentsDialog.getBeginButton().setEnabled(oComments.length > 0);
									}.bind(this)
								})
							],
							beginButton: new Button({
								type: ButtonType.Emphasized,
								text: "Submit",
								enabled: false,
								press: function () {
								    this.onGenerateETicket();
									this.eTicketingCommentsDialog.close();
								}.bind(this)
							}),
							endButton: new Button({
								text: "Cancel",
								press: function () {
								//	this.sSelectedReason=true;
									this.eTicketingCommentsDialog.close();
								}.bind(this)
							})
						});
						this.eTicketingCommentsDialog.open();	
			   },*/

		onSubmitTicket: function (oEvent) {
			//  var oETicketData = 	this.getView().getModel("oETicketModel").getData();
			var itemsModelData = controller.getModel("itemsModel").getData();
			this._getInputComment();
			/*if(itemsModelData['Rqstat'] === 'ETKR'){
				this._getInputComment();
				/*if (oETicketData.Comments === ""){
					return;
				}*/
			/*}
			else {
				this.onGenerateETicket(oEvent);
			}*/
		},

		onGenerateETicket: function () {

			var eTicketModel = this.getView().getModel("oETicketModel");
			if (eTicketModel.getObject("/SrvLoc") === "") {
				MessageBox.error("Please enter Work Location");
				return;
			}

			if (eTicketModel.getObject("/ExtReference") === "") {
				MessageBox.error("Please enter Supplier Invoice Number");
				return;
			}

			if (eTicketModel.getObject("/Dispute") === "") {
				MessageBox.information("Please confirm all operations and services log before submitting the eTicket. Do you want to continue ?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: "sapUiSizeCompact",
					onClose: function (sAction) {
						if (sAction === "YES") {
							this.eTicketSubmit();
						}
					}.bind(this)
				});
			} else {
				this.eTicketSubmit();
				// Dispute Message
				/*var msg = "1. You are going to submit a Disputed eTicket. Are you sure? \n \n 2. Please confirm all operations and services log completed before submission. \n \nPlease click on Yes to proceed";
				MessageBox.warning(msg, {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {												
						this.eTicketSubmit();
					}	
				}.bind(this)
			});*/
			}

			/*MessageBox.information("Please confirm all operations and services log before submitting the eTicket. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						this.eTicketSubmit();
					}
				}.bind(this)
			});*/
		},

		eTicketSubmit: function () {
			// var oETicketingService = this.getView().getModel("oETicketingService");
			var oETicketingService = this.getView().getModel("oETicketHdr");
			var oETicketModel = this.getView().getModel("oETicketModel").getObject("/");
			var busyDialog = new sap.m.BusyDialog({
				title: 'Saving...'
			});
			busyDialog.open();
			oETicketModel.Operation = "02";
			delete oETicketModel.eTicket;
			delete oETicketModel.__metadata;
			delete oETicketModel.eDrss;
			delete oETicketModel.verDetailsTaxi;
			delete oETicketModel.saudiDetails;
			delete oETicketModel.HeaderToFinanceDataNav;
			oETicketingService.create("/ETicketHdrSet", oETicketModel, {
				success: function (oData) {
					var msg = "eTicket Request updated successfully with refrence no " + oData.Docno + " ";
					MessageBox.success(msg);
					busyDialog.close();
					this.getRequestData(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);
				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		onPreviewETicketPress: function (oEvent) {
			if (oEvent !== 'VersionChange') {
				this.getETicketInfo("JOBL");
			}

			if (!this.eTicketDialog) {
				this.eTicketDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.eTicketing.fragment.ETicketPreviewPopUp", this);
				this.getView().addDependent(this.eTicketDialog);
			}
			this.eTicketDialog.open();
		},

		oncloseJLType: function (oEvent) {
			this.eTicketDialog.close();
			controller.oETickVerChange = '';
			this.getETicketInfo(this.getView().getModel("itemsModel").getData().Rqstat);
		},

		oneTicketRemarks: function (oEvent) {
			/*if(!this.eTicketRemarksDialog){*/
			this.eTicketRemarksDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.eTicketing.fragment.eTicketRemarksOC",
				this);
			this.getView().addDependent(this.eTicketRemarksDialog);
			/*}*/
			this.eTicketRemarksDialog.open();
		},

		oncloseeTicketRemarks: function (oEvent) {
			this.eTicketRemarksDialog.close();
		},

		SelectServiceForStatus: function (evt) {
			if (!this.SelectServiceDialog) {
				this.SelectServiceDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.SelectServiceList", this);
				this.getView().addDependent(this.SelectServiceDialog);
			}
			this.SelectServiceCall(evt.getSource().data().DocNo, evt.getSource().data().Mjahr, evt.getSource().data().Zeile);
		},

		SelectServiceCall: function (Docno, Mjahr, Zeile) {
			this.busyDialog.open();
			var params = "/ReqItemsSet(Docno='" + Docno + "',Mjahr='" + Mjahr + "',Zeile='" + Zeile + "')/toVendorESV";
			var oModel = this.getView().getModel("VendorService");
			oModel.read(params, {
				success: function (oData) {
					this.getView().setModel(new JSONModel(oData.results), "SelectServiceModel");
					this.SelectServiceDialog.open();
					this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
					this.busyDialog.open();
				}.bind(this)
			});
		},

		onCloseSelectServiceDialog: function (evt) {
			this.SelectServiceDialog.close();
		},
		onStatusPressed: function (oEvent) {
			//debugger;

			var oButton = oEvent.getSource();
			var sBindingPath = oEvent.getSource().getBindingContext("oETicketModel").getPath();

			// create popover
			if (!this._oPopover) {
				sap.ui.core.Fragment.load({
					name: "zdwo_nx_drss_ven.view.eTicketing.fragment.statusPopover",
					controller: this
				}).then(function (pPopover) {
					this._oPopover = pPopover;
					this.getView().addDependent(this._oPopover);
					this._oPopover.bindElement({
						path: sBindingPath,
						model: "oETicketModel"
					});
					this._oPopover.openBy(oButton);
				}.bind(this));
			} else {
				this._oPopover.bindElement({
					path: sBindingPath,
					model: "oETicketModel"
				});
				this._oPopover.openBy(oButton);
			}
		},

		onVersionClicked: function (oEvent) {
			//debugger;
			var oButton = oEvent.getSource();
			// create popover
			if (!this._oVersionPopover) {
				sap.ui.core.Fragment.load({
					name: "zdwo_nx_drss_ven.view.eTicketing.fragment.versionHistoryPopover",
					controller: this
				}).then(function (pPopover) {
					this._oVersionPopover = pPopover;
					this.getView().addDependent(this._oVersionPopover);
					//this._oVersionPopover.bindItems( { path: "/HeaderToVrsnNav/results" , model:"oETicketModel"});
					this._oVersionPopover.openBy(oButton);
				}.bind(this));
			} else {
				//this._oVersionPopover.bindElement( { path: "/HeaderToVrsnNav/results" , model:"oETicketModel"});
				this._oVersionPopover.openBy(oButton);
			}
		},
		handleLinkPress: function (oEvent) {

			this.getETicketInfo(oEvent, "VersionChange");

		},

		onFlenameLengthExceed: function () {
			MessageBox.error("File name must not exceed 50 characters");
		},

		validate3Decimal: function (evt) {
			var oLocale = new sap.ui.core.Locale("en-US");
			var oFormatOptions = {
				minFractionDigits: 3,
				maxFractionDigits: 3
			};

			var val = evt.getSource().getValue().trim();
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(oFormatOptions, oLocale);
			var newVal = oFloatFormat.parse(val);
			//debugger;
			evt.getSource().setValue(newVal);

		},

		getVersion: function (oContext) {
			return oContext.getProperty('Version');

		},

		getGroupHeader: function (oGroup) {
			return new GroupHeaderListItem({
				title: "Version: " + oGroup.key
			});
		},

		onETicktPDF: function () {

			var doc = {
				pageSize: "A3",
				pageOrientation: "landscape",
				pageMargins: [30, 5, 30, 30],
				content: [],
				styles: {
					small: {
						fontSize: 10
					},
					headerLabel: {
						fontSize: 11,
						bold: true,
						alignment: 'right',
						border: [false, false, false, false]
					},
					sectionTitle: {
						fontSize: 18,
						bold: true,
						alignment: 'center',
						margin: [0, 20, 0, 20]

					}
				}
			};

			this._oGetPdfHeader(doc, "");
			doc.content.push({
				text: 'ETicket Report',
				style: 'sectionTitle'
			});
			var oETicketModel = this.getOwnerComponent().getModel("oCompETicketModel");
			var oETKTData = oETicketModel.getData();
			doc.content.push(this._getETicketReport(oETKTData));

			var oItemsModel = this.getView().getModel("itemsModel");
			pdfMake.createPdf(doc).download(oItemsModel.getData()['Docno'] + "- ETicket.pdf");
		},

		_getETicketReport: function (oETKTModel) {
			//var oTVDModel = this.getView().getModel("oTVDModel").getData();
			var aColomns = [{
				text: "Cont. Ref No.",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			}];
			aColomns.push({
				text: "Service Description",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Quantity",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Unit of Measure",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Currency",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Unit Price",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Net Price",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});

			var oBody = [
				aColomns
			];
			var aColumnsWidth = [];
			var oTableItems = oETKTModel.HeaderToItemNav;
			for (var oItem = 0; oItem < oTableItems.length; oItem++) {
				var aRow = [];
				aRow.push({
					text: oTableItems[oItem]['ContRef'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['ServStext'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['Menge'],
					style: 'small',
					alignment: 'right'
				});
				aRow.push({
					text: oTableItems[oItem]['Meins'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['Waers'],
					style: 'small',
					alignment: 'center'
				});
				//aRow.push({ text: oTableItems[oItem]['Brtwr'], style: 'small', alignment: 'right' });
				aRow.push({
					text: oTableItems[oItem]['Tbtwr'],
					style: 'small',
					alignment: 'right'
				});
				aRow.push({
					text: oTableItems[oItem]['Netpr'],
					style: 'small',
					alignment: 'right'
				});
				oBody.push(aRow);
			}

			//var iGrandTotal = this.totalSummaryCost(oSummaryReportData);
			var aRow = [];
			for (var j = 0; j < (aColomns.length - 2); j++) {
				aRow.push({
					text: "",
					style: 'small',
					alignment: 'right',
					border: [false, false, false, false]
				});
			}
			aRow.push({
				text: "Gross Value",
				bold: true,
				style: 'small',
				fillColor: '#84bd00',
				alignment: 'right',
				border: [false, true, false, false]
			});
			aRow.push({
				text: oETKTModel.EtktGValue + " " + oTableItems[0]['Waers'],
				bold: true,
				fillColor: '#84bd00',
				style: 'small',
				alignment: 'right',
				border: [false, true, false, false]
			});
			//	aRow.push({ text: "", style: 'small', alignment: 'right', border: [false, true, false, false] });
			oBody.push(aRow);

			// Net Value
			var aRow = [];
			for (var j = 0; j < (aColomns.length - 2); j++) {
				aRow.push({
					text: "",
					style: 'small',
					alignment: 'right',
					border: [false, false, false, false]
				});
			}
			aRow.push({
				text: "Net Value",
				bold: true,
				style: 'small',
				fillColor: '#84bd00',
				alignment: 'right',
				border: [false, true, false, false]
			});
			aRow.push({
				text: oETKTModel.EtktGValue + " " + oTableItems[0]['Waers'],
				fillColor: '#84bd00',
				bold: true,
				style: 'small',
				alignment: 'right',
				border: [false, true, false, false]
			});
			//	aRow.push({ text: "", style: 'small', alignment: 'right', border: [false, true, false, false] });
			oBody.push(aRow);

			// VAT  	

			var aRow = [];
			for (var j = 0; j < (aColomns.length - 2); j++) {
				aRow.push({
					text: "",
					style: 'small',
					alignment: 'right',
					border: [false, false, false, false]
				});
			}
			aRow.push({
				text: "VAT @ 15%",
				bold: true,
				style: 'small',
				fillColor: '#84bd00',
				alignment: 'right',
				border: [false, true, false, false]
			});
			aRow.push({
				text: oETKTModel.EtktTValue + " " + oTableItems[0]['Waers'],
				fillColor: '#84bd00',
				bold: true,
				style: 'small',
				alignment: 'right',
				border: [false, true, false, false]
			});
			//	aRow.push({ text: "", style: 'small', alignment: 'right', border: [false, true, false, false] });
			oBody.push(aRow);

			//Net Value
			var aRow = [];
			for (var j = 0; j < (aColomns.length - 2); j++) {
				aRow.push({
					text: "",
					style: 'small',
					alignment: 'right',
					border: [false, false, false, false]
				});
			}
			aRow.push({
				text: "Net Value (Incl. VAT)",
				bold: true,
				style: 'small',
				fillColor: '#84bd00',
				alignment: 'right',
				border: [false, true, false, false]
			});
			aRow.push({
				text: oETKTModel.EtktValue + " " + oTableItems[0]['Waers'],
				fillColor: '#84bd00',
				bold: true,
				style: 'small',
				alignment: 'right',
				border: [false, true, false, false]
			});
			//	aRow.push({ text: "", style: 'small', alignment: 'right', border: [false, true, false, false] });
			oBody.push(aRow);

			aColumnsWidth.push(100);
			aColumnsWidth.push(300);
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);

			return {
				table: {
					headerRows: 1,
					widths: aColumnsWidth,
					body: oBody
				},
				pageBreak: 'after'
			}
		},

		_oGetPdfHeader: function (doc, oHeader, oRDetails) {
			var oItemsModel = this.getView().getModel("itemsModel").getData();
			// Service Type Text
			var oUserInfoModel = this.getView().getModel("UserInfoModel").getData();
			var oDoc = oItemsModel['Docno'];
			var oWellnm = oItemsModel['Wellnm'];
			// Rig Code
			var oRigCode = oItemsModel['Rigno'];
			var oSrvtyp = oItemsModel['SrvtypText'];
			// Header for the PDF
			var aHeaderColomns = [{
				image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAP4AAAEKCAYAAAFF5dh8AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAIPJSURBVHhe7b0HdFzXde8Nx0ncnhMnTr64xvFLYufFThzHfnnJS+zYeS6RZHXJ6r1LtmyrWr1TlVSxeqNIsYu9V3SABcBgCga9dxBgATsBkvu7vwNs6vByOmaAATD/te66/dxzzz67npYlY4xMBhLKwK0bfi61tbVy5MiR4StDOHr0qHS0tsmXP5gxfCU64srACs87J300HI4dOyYfmbV6+Cw8Ys5AQ0PD8NGH2L9/v9x4443Ht1A4sGvH8FFoxJSB3bt3Dx+djJtvvtns33jjDdm5c6ccOnRIBgYGTOZ4j33fjh2mREIhagZaW1uHj0LjzjvvNPvf/va3Zh8WB/cNH5yIiBnwBcqHj0LjySefFI/HIzk5OcNXToTP55Nf/OIXw2fOx2Z8+DOUFoirErpB8W/evNkc8yFNVBGq9NyVOGwGCss/GD76EL/5zW9k9erVsnbtWnPOsb2tW7fOXI+Ef1pUP3w0hLAZcP+Njbvvvnv4aAi/+tWvzN6+/sgjjxyvoCfi6PB+CAmR4OGHHzb77Oxss1f8+te/Hj6KDJsjQmbgyJGB4aPQKCoqGj4S6erqkgceeGD4bAgPPfSQLFiwQG699dbhKyeiv79/+ChMBlp25g0fhcaWLVtk69at8uyzzw5fGRJUyIBYQKYVITNweGD/8FFoFBQUDB+dDARSNPT29g4fWRmALvzB4OCg7Nq5Rw4ePCgHDhwwG+A6GwonVpBGKBw+fHj4KEIljFXpuPHWW2+Z/b333mv20RA2A16fZ/goPigJ7rnnHrN345NzThROYTNwLDIjhMXbb79t9uEy0NHRMXw0hLAZAB0tu8z+pZdekl/+8pfmGNa67bbbzPEtt9xynBMQxYWFheaYZ/r6+syxCimQNfPEj4OIGdAKd9999x3PAB9S/ubaHXfcYY5vv/12mTFjyBJ6/vnnJRgMmuPXX3/d7AGq2Y2IGQDdXd1G1epHyYCKWP4O/QCodFr8U6dOPc5qHAN/IGD2bkTNAGhvPbno4kG51zt8dDJiygA4dOigDOwPbdWEwy1bA7Jr11A9CoeYM6DoaOqSuu1Vw2ehcVHuWgmEKXI34s6AAsnZ1dklNYFq8ZZ5pMYfNAZIPJISxJWB888/X84880xzDPudccYZ5tjv95s9+MlPfmLYVp+LhrgycMUVV5j9eeedZzaFZgzxjaZUdT1nzhyzj4SEMnDZZZfJVVddZY4ViOBrrrnGHKsMmD17ttlHQlwZePTRR+X+++83x3wEeXDllVeac+rEmjVrzDEkufbaa81xNCRcCRWI3L1795pjMrHDcUIUqHKkn61+3RhxBkaKTAYyGYg7A1s7N0nQWyl79uwZvvIhqPUrtxZjUA5fiY6YM9C9t15qa2uGz6JjZ7dj+ztWdDTElIE3tlw0fHQibrrpJiOMMM3uuuuu4asn4rvLIrv4UTNQ5F80fHQynnjiCWNkophKS0uNUEIbQh6cWyIk+AYffbPU+BShEDEDD2yKnL8PPhhy4QlQhPIDZ86caTIGArUnuuWKiF+IxTnBFsRmxB13w/2+7RUjvqm0YTNQ4Q2dYxsaHwKdnZ3DR0Po7u4+7iUpst5rGz76EGEz4LZs0HREQdQPeOaZZ8w513UjZqSYO3euzJ8/f/gsPEJm4JmCjw0ffYj33nvP7DUWUFFRYfaY5XbRRkNnQ+3w0RBCZqDMM1RxbKjToXa+7fEoVC3jrOTn55tjNz41t2X4aAghM1BbUzd89CE0AwpqOCAs484c3LFw4UJz7MbNJSea6SEz4HYggX5QQR159dVXh8+GSKGsWFxcHNY9L+wZijcoQmagufnk+N77778/fDTkB0YCscNw3vE93g/jQ8BkAO9l3759xp+jQmVvzDeBJM63b99uJNw777wTVpqFQ6iSzHo/hvjAozkhLx93SmMNx4VCnbds+GgIob8UhqtQOmAkGXDHjUJnwEFH21CAwYYGnhPNwJ98cKK0BGEzcNSypDUIAWy1a1dGzRRNORrMQBRrpkF7e/vw0YcImwHwZuG/m73tYs2bN2/4SOTdd981eyqssiQBa80krKgZu78gAW0IdvTskxdffHH4TE44fuGFF8yeFhLCMgABpJqRDKCwPj73ZMGmiJoB0NgaOR4QCVkztg0fhUZMGQCPZv94+Ch2VPt9w0fhEXMGAOL3yjVD9SISXikujOgP2ogrAzawZhprGsTv8ZqturLquDaMB3Fl4KyzzjoeDTn77LON2NbK19TUZPbg3HPPDRuodiOuDJSUlAwfDUElI7bfBRdcYDLIx8H06dPNPhrizoBt/WgGtNUUgXXhhReaY6KrsSCuDNxwww2yYcMGc3zppZcaicffX3311eaaNsVcfPHFMbWggYQrIUCNo7JtenOuURJUOSpcGz1CYUQZSAYyGRhrZApgeD9qCPYG5Nw158kt626XpVtWSXl5uQTL/Y7eDEqFsy8s3SrP5i+Wf17ytFyX77g2cQR7EkFKC+B1722SW75WqqqqYm5UDgfE7XbHoPz6B4vlUIiWr0SR9AK4ce0nxVPqjdkYSRQYRvmBoJQ0n2xlx4OkFUCef+7xhtJYQPMi3Q9oWGHDmdZj2wWJBdSurPd9cjSOGIlixAWwsPTmiF1dImHWrFlmT/OW7chr4C8c7NqlPVnAoOOZ/Puy8N5HKCRcAEXNU4wASxRYrwSY3FbKgw8+GLPXS/M9AQs3Pgh2yN7+8B3fbCRUAA9lZ4WMesQD/UnMODxnKLlq1SpzTZv7IkHjUNo2eRKOHJQdrY3DJycCgUojGnIk7gKYWvSZmH6eHyREmJubezxqp8CIJqRAQI1Nux/wjl7j/qJFoQP0WnjqDYTFkUPS29Y8fBIacRXA4cH9jkM2FJiNBHckEdiUwlhn48ftMCZClG5wRJY1tuKGttdGkxOK64t6QnYYUcRVANOLTjHVJxrcsVyg3WqAhk3gdw2tgObmZlO1vV5vyDTsGhGK98NhekH44ERcBVDhi03CujNPAOu5554bPhviXzQHwU67gRtAYf05uxvotGnTpLKy0hhVbLEKSvDJBZ1h7ZKYC6C73y8tLSeG98PBXQBUZ/haYXemeeqpp0zhVFdXG54mTK2ww4pA+8y6e5FGw8LGPcY3DoWYC6Bztydmye8uAHiQSAJ79D3Uo0WJzp6wQ6i9CklaoxQqR+ItgGUte6XL1YymOKEAaFujmRNhhHVFdIFjwl27+w5KQ22ruc4z7N3Vl7Y60uDn0PMEgyk09qE2qrget7W1mc0+jrSRfqwE+fzizpCt6yAuGbBsa2zdMunCSyiGmDH7VGzEn2ItgIdzq8I2JcZVAB07y51aEbu9T2u+jXCqLRLcrb2xRvsUsxv3hhyLoYirAMCDm7JiUoVAm7QUySiAcK2P4VDnPbnN10bcBQAecgpBqxT8SBMI1V3BjyKw3KoKwwd7wJbuCEaoipBE+Cno5TBlyhRjJ9ghVoToihUrTCc2W03yTbdvEvA5HqKryd+NhAoATCv4gvlpxpO4f5Rzuu66Kc75K6+8csJ1CpLnkf522xOCFy2Aa2yrMCLuFBj37HAwhfthQR2T6vLIzUKKhAsAHHYszOkz3jxJX5NBqOkuAH6Uvg5uPkb/U4vcnSu4Ttr22Ad+kp93sxcFiBGVNb0xZnsFjKgAFNWNZbKrN3zwfTTwp/MrTG2MF0kpAEX/jgPyZN5/OdU6vk7EI8H3lm+Turr4giA2kloANno6dsrlq//KcUmHLyQJRd098tvcYuMXxKqNIiFlBWADQYdFWe4rl8tWny/3Fz0g3Xt6hu+GxuqWCvnGouflkbxVUu31Sbtj9CTjh90YlQJIZ6SsAOjtzrgvPD+OtQMZTaeoT3wJW0druy6R4osuGuoniveHX4HJi1WJ74G3+POf//wEu2MkSGkB2C3qjDMA/Cj9TXGD6WX/+OOPm+t4f42NjeY+8QPGpPKj+PGMT7CNHsYp2KP5RoKUFoCOZaH7wNKlS80xP6W45JJLho+GAOVraoa6J59zzjknWIDa9QBQSHafiJEgIwOG92MC5IBGh9jjF2D24rvj8sLzWIGEz9AAaBOOMYExldnUSqR9IZzLGwmZGjC8n5TI/PxkRebnJytG/eefKXtSznKcn5cL35LC0mLxe3xS5QtKpTcg3vJyWVy8SS5Z+Zp8c8lzsqk59vFZiWBUfv6qDf8pa0tWSMBXYdoHMGOj6WbV983VNfKTZXNkemVsI6HjQUp//vp1/ywBT9AYMIkYIjYwarLLyuTU9TlyLEowM1ak5OevWfNnTnUORpx+KFFgHc7dWibr6iK368eCpP78vsM7Jd+37ASvLFXod8zirPdz5YjDHokiaT8/x3+d+MuqDWViAeFp+m8T0bX3RHFj9eGJE/wyu1xkf/xd8EFSfv6RvM9JWZknLr4m5G13d9NNr8WDgqp6ObTzw4lwYsWIf/7pwi+bFpZ4BdrGjRvNOEcCHaCnp8d0sNdGE9LDk0Piu7vV4f1xXWUKXmGet0J2tDaZWGKsnS5H9PPr6253KJ5YtzedbQY3lZac1157zZyH6uYSDrQk0fND8YqnRQYOhJ4eLRQS/nnoHCivi9qGFg78PFQuc9SXgi4w8fThoVVIOz8pPrewXQ7HKDMS/vlVnntNdUsUCDy7BwfAAOJ6LJ0o169fb/bECG1AjB+viD6QGiT08y8U/YXU18f2gXDQzPOztL+z13jeypUrzT4StJBCxfoH9vVLf9fJnaCxGtEkGg1K6OcZoj4Siw3qaBiK1lwGbtkNldH67xD6InwVqUN01rttJ7Gk5ln3cf/8w9lZJ0zwlgjIPIaQdlNVMIMNKtDdSuyG3g8394PB0QHpbY5cO+P+eb+3cvgoPBYvXmz0tXZvffPNN4fvDKk4hB3N0mwIPfZUY73GfXdzuIKqix0QSyg7672WiDU0rp/f6Ki2SP1jALF7qjE8zeQITCWJUNq0aZO5j17nmk6moHv3Zk+kYENVpO4joWv3Xul17IdwiOvnXyv8x6imZzhVhfmqoLpj4Lj75vAulI8E7SQdy8+DpVs/nCbLjbh+3l8ePbigs1MoqPboYjuz9jyu1CQKQy07Bezhho5oRVhq3D8asqa3hLVFYv75vQe7pbo6+s+Ho7wtxJgPBHkAX9sdEOjXr1N62BOaKOgADaLVDhtP+4caQEIh5p+f5f0PYzdHg5vyyACqqmYYFYVwiwQ6Krl/kM6Rivi6sh2RtsbQcirmn3/MUXGxuKtuyiOVmaRD1Zo2Rj722GMnWWd0g6WG8B1bDSL86OjMhi2vBlKsqAuEngIx5p9/rfBbMdnx4QZ068/87ne/M3vF008/LS+//LKRCXYPbp1MElBQDHiA+vTwsme1jAVrt4UWejH//Lyi62Ky6tyUZ7QFwkyrui31cWM5x0eA1+1+/u75pe336NgQD57JGcHMmyDWjsvRKI9Vhn/Oud3xUEEh6FyFdGBQ2EaP9uOPFffmhBbUMf/8/KITOyGHg5vyOB4IOXgZHkeQ0TMDyR2u3z57aos9rs+mfLw//2Ru6DFHMf/8m4X/GlO1D0d5fpruJ/FCWcEWgNu2xdYdVbFsa+jvhvx5Biso9Id/MyfLDCggdKThI1QffKvzuCGl+XmeQ8rjotJXRwca2AMScGzc19m7t3DX7ZoQDZXlJ05kpDjh57Ga+FniY4CfQxhx/Zn1nzO8inlLjIyqrD0pMCL4cfa4qLzDMxRIrJZYvAjn+IRCjX+Eqq6pL/+EGhEO9K5CJWrggH0qNndH5XBY3bY/rAcY88+DuqrEh4hTE2CReOEWoLalFwuyZneaqE0oxPXzswsvHT6KDbaAhBXckw7GAvfk9bHMGWxjamF1WEEd18+/U/LtmFtkgPvnEVTxwj1EBacoHgS94busx/XzoKmue/goOpJBeTsKBOL5+ayZ7ceFdyjE/fMPbvxwXE40uH8+Fq/QDffPxzo4GQR93oh5jfvnB51a39X+YfMRNrgdqGBwMc4L1VVbYQAtMQgrjBYNUQOMl7y8vJMiM+hxLDl3MBMfgcFNtqqDnYgFUMCKP1/UHbW1OO6fB/c71Lc9PEqXzJKxZcuWDV8dmiuKnyOj2AUK4vKYr25DhR8giOHW4ZzjE7jH8nAdU9me11JR54/ecJrQzx8dFKmoGhrrxjh8jbAAjBoyREzdNmcJShK+wsy17QWepTaE+mGmIXRTnsJkmJod9kKVka4aVFkz22KySRL6eVDesFj6dw/531h6UB0Dx+4eTj98nBlieLYbSmQH/U2GbeqQBgLNXRDUEOZpdF+HVaA6jpDiTs+umOcMSfjnwSM5f2BCSu4ABdQio7aAY3o9fo4fsVkGKuK9uS02qj8eHu/YIF1qmju0zTe3d7ZLvVPdYx2uMqKf5yfu3JAl23u3m+rLpAGMnlQQqydSQ0btlRb4YSKx/LRtN/Bj3HNTmB/DZ7BZgB+EjXieQgIFvsoTZEs0jOjnwcDggNy+Pnb1lyrML6sKG6UNhxH/PBh0CuAXa7OMwzHaOHzkqGz1V8T94yApPw9ggVcKLpXDsXeMGDEuL6yUWsd8DRUOiwVJ+3lFV1ufPFN4XsrZ4OuLch1V6j9BeMaLpP88gBJzN0+TnLrFSS+EP563RGodszUZQZKU/LwC/b9s6xy5O89xhUdQBm1798iXPpglNV6f6bqSrAJN6c8rUGftTR3yZv4rcvrKU2Vd08aIhdF3YK/8snixfHfpq7LV45FgRcUJDRrJwqj8vA00AlW2palZ6ivrpIKu5mXl4nO2al+F1ASCUl9Xb8zTWPvTJYpR//l0Qsp+nmGhTMp8+eWXD18ZAmtrcV2nmAOnnHLK8NHQGFwFw1LhccB7jLK8/vrrzXkykLKfZxgp3hZTPujYWoaTaiutbZQwnbbOpcHQUfXIGJaKf8B6YLjBsAFdWtxT2CSKlP68gp+geRkvT5uXqRlaAPTOoKUW4Mho1xPWIQM62lqhI7FHilH5ebqS4+QQgsLPx/mhQGh61s6MUBfXl+c4Zg5ODVK4F2Lj3XgcmHAYlZ+nWhPeYk8NAPC98jOgJsAehKKgND+ojQ32MniAtGN1WyMh5T+P6wqvk9nrrrvOxOsAQ8btaAu8rK4sLT38vBozCDudSwuBR41JBlL28/Sdx/8m+mr3lyeYgQagWjNpvd0oocs/AyYgUlAIFAyFSMwgGVUepOznxwPG/OehqvIv1R0NgBWorb46qgIgD7AO8eS4DjhWl5Z74drlQmFMf54WHDKssT5+kp+iMPgpVYUUBlWdZ7mmsgDbgAKjDZ93eJdnYkWm2k9WZH4+g8mJDPEnMTLEn8TIEH8SY9IRf/DIoNTtbJRVTZtkqvcd+XXBk3LJxnvlnHV3y8+c7dR198rP1j4kZ6+bItfmviIPlSyQubXF4tveIvsOJdY+mK6YcMQ/euyoLKydIRev/2+5au158u7mt2SzZ7MEvUGp9AWlqrLKRMtwMHEu6UCOc4j3jCNpb1zjHrEZInBtra3SUt8ojZU1ssVTJi/mr5H/WPqm/M3C1+SR0nzp3z+KLdZJwLgn/ozgE3Lxqn+QudveMIvv+71+M2AFghH5T1YzZzhoeIawSk9Xl7TW1MrrhXnyhfmz5fKcXDlAb8EU5yFRjDvir6x/Sa5d+zdS4N0gvrKAGaZJSEfjY+kCKgUxtz6nQhR5ffKFeSvkxoISkcMnzo87lhgXxH+59AKZkn+aBH21Ztgq4jrdiB0NVAbUyM72VjlnVYH8w9IiYdKjsawIaUt8T+ciuWPjF6XSX2cIjm5OF45JBg45Kml3Z7v89QfFcm9xpRwbA2My7Yj/XPG3ZVnZM2blTVrvks3h9P+mw2y8oCNsvOM8Y4GRCPv2yvulQfn0nHI50r9z1Cp52hD/oZzPyJbAGrPIBTo8VYYalYkOBPSHZ6OFlD29JjimBZamYr1Pyyt933XQgXYxoWJqGzzGHvmlSYrmJ4xN7V7GPa5DUL2mTVXsGY+nHsWgk7fs4i2SNata+loazXVAczfv293ck4ExJ/7bpf8uOb63xFPmOV4oqQaDJHSCEtoC6RMA4ek+A5EhOHN7oaNpVGUECFNmQEg8CHUTdYMwVCo2HWkKwXEXIa42znLOdf1PKjnp8R73qViotwMHD8jSkoB89r1y2dfbbdLUvCQTY0b8jv4SeangG1JeGjAFlCpODwWG8TATFt9klAtTdrE4AxWhtrbWcDzPLF++3DzPjBY67iFZoCLQVUmHIemywTaOOJ7B6Wsb5Omi2oQ7oEfCmBD/qbxPij9QLjU11aZWjyboQQhh2WKZAI/pkFQtJFPs0rmHmcbgfiRLuE65VNCDu3dI1vQ22dfTkVQmGVXis1bUY9m/J96yKqPHRpPbFQwGZF4a9DUcDxHc81aRL6aLgCNZf44K6h5LNxJQ8ZYsWWKOUTE6w1pEDB6WLy1sl5JgddiK4oZtOPIPnGsfH45Hjfg9ewMyfcsPHIOu3OivsQL6PtwkZXA3hLE7USvoPeoe/poIqEQ6YRITJencYbEAgt22uVOeLaiOabwCBLc7ginhKX/UyKgQv3HHRlmw7SozHDfZRks8wLCC0xR0/obgjIe01xBEHCOKGVvJypSgoqLCVIyRDBKhL6b2w8bw49t2n86Y4EilNwM9ctvGKtkzQgM55cTfvjcos7aeYQaPxSquwkGnI4RYuocbGQUMB4Wb1ggQBmacOAREh9NnnHnZCCAxQDbUBsFZcU8NQDZGGUSbQDMUGJBPfhW4j6EkTExwKsBTnh55Lr/yODcngpQSH5X+XN5nxesJJMVapaM/3BgKWO3uKVkUcDH3cbkQhSPZSAOiMUNCrKDSYj8oGKlB5R0Zjsn313ZKwQjKNqXEfzQ3y0wkHk9f2lBgkgI4HLcIsal7Jjlg45hu7FwPNV4fgvEcnAsR4Doqkb6nezs9Noa8M6kBUoJ3eJc07PV6owEJQuVT4xYXM3meg2O0zWyXzvpqo9LiRcqIX9j0hOSVzZLm5pGv2wHxY502nxCsrdcViHeIaBcSI2cI2/I8FYdJYHgOo5BrcDfPKKhEEBKCxgIIzPPodwWVODs7e/hs5OjoPyD/uaRGtvfEPv2RImXEfyz7IxLwxb5ESCQwlQn6OhyIuLEaJps9V6sNJr+AqDbQ3cwYwvNUAgbPLVq0yMz4AXfiEiLqbRAajpV4zCRixxJImwqYbHxpSadUBeI3plNC/K0tL0hO6XsmYpYMRON8vkOEjGnXmIXETXxELj494VsN2LAKqU4LGQm4SUwXxTsQjkhgxPnpHWDYkgdd6xaoFEhFCLt1z0E5ZXmNdMc5f39KiD9lWNePxBK1AfEjcb4N3DTbuAL4uBAPCYI4J34fz/IWiH4ITrp4FFQgHS9ogwrKc9gTPEOFQ4ogVdTLCDUXeDKQNaNVWmviWws8NcTf9HGprKhJyAgJhWiczyRvNNNirKGn3ZxPowwSwQaNKBh5PIubaK96QXyfaxAb0e8WpxA31OzVrIHA1GDhEAwGT6qYycL/WdMlpXEG0JJO/L0Ht8v0glMdfdp43MIdKaLpfIiDYclGY4yb+BBLw6mhQKiZZ3gPDiVuYBtpbuCq6SrdNjAYdQp0bAyO2VAbqAwqB4NyU4HnArtkRqE3rqBR0onftmurLCz+tdHDySJ+LNY+uhQ1Q5zcnpEMkc+5HZmjFRHDDS6k6TbUHLeIdQhMhYBgNkch0TDm7Ni5DVSLeyk3VAAGaaqwtm2vPJIdPGGcfzQknfitO4tlUfHtCc2eGg7ROB9uh5AUOnt0q4L5u/H9Ef3co+0+FLGjAa4mMEMaVEY4ecWKFcN3TwTPYHvYILqXSuJvat8rD2ZXhrRFwiHpxN+xr0FmFpzvcH77qHK+AncN4w7RS4CGaByhVTYqCQTTc465Ful+pHPaBrAx3KI8HOenohuY4q0axyvJ948t54OpuZ+TxvqRB3cUcC3EhKhscDa6mU0JzTWOEdOco8PhQM65Z9/X9+3n9b47PTZ9n2f1nGf0nGP73P083+I+x3oeD4fGgjPzeqWgNL556MISHx1KzFi7IwE4GeMKowKxznXVhVzj/MDeI3Lfiiyprmg2hhTXSEP7o6khpfqS+/jFfAtxTDoEVvQ5vsnUzHA/z7Fp4IVnuJ8K3zlVoPywF5JN/Kw5nWYWZaVVLEgJ5+c1PiwFJcticjvCGU024HzW2JsIoJJD/GTaRIcGj8q3FzdITVVVTOWpSAnx+f7z+V+Q1pbkdDsieocYRYxjuaNTOSdgwjGilMnY9B7HiFz7XO+z6Tn37Pscu+9HO+fbmob7PkTmvl7jnKnIOI9HN0fDj7J7pdjji9uQTQnxwTzfz2SbJy8uMRQPKMhwFQuJQ6EnslhFvKAZ2b3MgQ2s/HgXvIgHlMHnFzRLZcB3UjtENKSM+Eyj+uCGLGlp7I5LFMUKOCkS8ZESo0F87JFw/QgA7mG8S73Eg/+xoFOqvGUJNRGnjvgOOnZUyLv5P5G+3vDRskQxnjg/VcSfWrlHXiuuMr2UEmGwlBIf7s+peVTWlbyYtEYeRbpwPoSPxvm61mEyUdN/WP57dZME/L6Eu8ellvjAoc8i70WSXzYvpP4nekcHh2jcQX87nqOFjFY5DLpwwKLGICSwwvN0v7Y7aLpB6JcGGZ5li9a3jrSI08PV4Rp5FLQTkG8qAWnTABVJRGMI0i7Ae+H6CvYdPCJfX9Is/vL4XDs3Uk98B3DoCv9NsqH0ZYcrw/d+5acpTNtqZX5auNiekRRQgIh2e91YQGWiYmicQEE0jut0ylQQHyDg4u7kAYjcERa2C5fwLHkpKztxuUXELmrIziP/DKGphG7OpLGHdGyLH9ePa9yLhPr+Afk/K1rEN0LCg1EhPqAwfE1L5L2i/5bdu4YCPoD5d2lc0S7SgEKBEwnsKBEJjhDihePofaMVBAt3w4YNJsRKaFd1H5WDrlk8T+dNvQ7BaZOHW3XQJSAfPEuDj93WzywfEASLXTt/oFaoTDxvX0e10VuH/Nndv2jk4h953pYq/BuVl1Y/W0UROqbiuNXWM46OvyevXvyOqHc3MyeCUSO+Yv/eAXmANYc6Gdn6oZFCwSEe3b1i+UmkgbtbNqtDwck03NiAKPjR7tg6hY+kcItcGmhI3+57QMWCY92LQhE6RVIwds8G3bnx8d2BGyor6bjFN+qCvNsSgf6BcL69CpaNT8ztkHJ/wFTMZPWTGHXig8GBYzJ9y49lU/krpqCp/XZNpoGFzhRstphmKWAqAeJXC4D3ISx2ABykTbdwOhUB6WEvKk1HDSoYOtheXozwszYg2f4yDTmIf4hir9TPd3HzmNxJpQr9CUibvJBPDTuTHjYN6duzi6sdw/P2kC0qEeqLUHdw12H56gfNUuEpScidi4QxIT5ADezdNSh3O1Kgb3u/+VEIAsFtQGS4ja7UNhDTcI9b/1Ix4EJ38ylilHTcfdz5HhIBzlOwxCJpu1sSEfc00LjzwrArvumO2tFPEG62pRP/TWQSiWO7Z1wnbSqCIuu9eqkOBozdE28AJxaMGfEVR44MSmNLldy5Pkv6+4bEIByLZQxXoM8jAU6mOxYFim6OFjOnnR1OxprmO5FAhUCnq8dgd8gMBYhMBxC8DDjXbXS6oYM3UAPoecWfL6iW5Z4q8TqSKdkuso0xJ76Cml3XWCW/cipBX0/6za41GvjDOV5ZU15p1FEsPYtHirQhvgJJ0NvV76iDL8i6wOsyeCh0IGeiIK9rl/zerC1SHRgaGziSgaDxIu2IrzA2wZ59sjmwTq5d8ympbffK0SMToyL0HTwsvz87R2aUsoJaqXHpbJtjtJC2xLeBYbRrZ78U+zfI1au/KCsr33QU8lAFGS9Y3tIhvz9rhcwtKRe/Q3C8hGT46iPBuCC+DSMRHCOovalb3it8Ri5a9TVZGHxNjiXfGB4RZtfXyWfmzpPbcnKl1us14/twD7Ft0qXSjjviu4FUoDJ0tXWLP+CTaTkPyrkr/6/cW3iLlLZvcx4YfjBFCPR1y9UFK+WL81+X6zeukC3lHgl6yo17hl+eChctWRj3xA8FKgT+/M4dO6W9pV0aqhqkrLxMFhYvkoezn5QLl18np6y8XH684go5bc1Ncln2fXJt3hNyU8FzcmPB83Jl3lS5YNOz8sPVD8v/Xnq/fHfpw/JfS56SX2yYKTOKNshmR2xX+/xS6Q8YV5PRPlTAsdDbI8GEJH40IHapIHAlIVYqClY2G0Rk45igDvd4DtdzPNkYsWDSEJ+Ay2j28qUdgKhlOmPcEf+KK64wi8cSliXqRkiUJUZZftRefBIQdmU1Tp5dsGCBaYDheaZ3cTezop9Jg8if+x7LnRLbt/U3UoDr11577fE2Ar5D3lgtlKgjLZM0GpHu6aefPuIZSpKNcUl8lmd1t+bB1awpfeWVVxqxDVh0lzWo7QYZwCqmxNZ1LIGC0CwVyZ5vj/YA1rOFgPaIG97nGhUJ0HpHvhhWFipQQ77IH4056YIJQ3xAt2gIomv0AgqdayxOzDq8bFQIOJTFjCG23djDc3AzFYMh1dyn6zjPs4w13Ev7AWnC6dqWQLrkDQMwFGgXIA3m+0sXD2BCEZ/ChSh06gBwGtdoIkYyqEWOuKbnDU29biudTiWkT6MLCzyjJmhDp4JQWZj2BUnAZlcy0qRS0SIYCjQNK/HtyjaWmDDER2RTuIzCVW6EWCxQ7e4Ro8QPN3CCadd16XJd4B7QI4hvcJ2Om3Y3KlrxuEebvd1Uq0CicD/U7J9jhXFJfAgDV1KgEJLKgH6HK+3OElQC7iO6mUMfY473IQJpYJixuXvaYMyRNgabW39jL1BxQulu+hBQ4ZA4qCA20qGy0LtozZo1ISvGWGHcER99CSfTL449IdNoHRnR34huWs3Qybh9+PAcM8Mm6bh9eOLupB0K9NiJRERUCd+jHx92A30F0zFGMO6In0HyMGmJr/3h4Er1vwnKcB1JgmTASOQenMw1JAbGIc+wR6Jo/F4DOjynwSQMOyQEaQHS0e/yLs/SaYPoIe9zzqb3tUNHquIDGc4fRqI9hxDnENgt1rlGsChRcT8aaiJD/EmMDPEnMTLEn8TIEH8SI0P8SYwM8ScxMsSfxMgQfxIjQ/xJjAzxJzEyxJ/EmHTE79m3XbZ2euS96oXy4NYX5bqch+X89XfLmevullPX3yOnrXtATl/ziFy8aZr8umi6vOhfKxtaAtLS3ydyNP2aZUeCCU38/kO7ZUn9Irkx50Y5bcUZcsmaq+WxnGdlRtFc2ViSI1s9JeIr90pFuV8qvRVS46+UKl+FBL0B8Zf7ZJunVDZsK5K38lfK3Rtnyf9bOk3+7oMp8sM1b8hLgUJp70/vrtnRMOGI37CrWu4vvkXOWvEDuT/7Tlm1baX4PD6p9DmErag0PXnpZ0dHDZpRaX7VARrapMrGOU2wNKv29faaXkGtTc3SXFsn1f6ALN2cL9etnSd/teAl+cna+ZLb2ihMOzeeMCGIv+/wHplWdqdcsPpf5ZWip8Tj9TjcHJRgRdDMmUc7PASlDX4kTaW8S9MvTbW0t9MHsL2hUSqcyvBI9hr5ywXvylkbVknrzuTPOJoKjGviN+6qkBs2/ofcl3OZbCkvkoCnwvStY+wc3DwaQ6y03R4p0uVUtBKvV85ZuUw+v2C+rHEqhvPAqLTNJ4JxSfzGXT65et3/kleK75GAN+jobZ/hcLgx0U4ZyQAVgb5/vdu3S2ttrfx24yb59NyFsqy23rmZfmP9xhXx9w/skVs3/aO8XPxrxyirNuvxo4vpLpVuBUslxF7obmqS2zfkyh/NXSkVnV3cGH5i7DFuiP9m+fVyb/Z/Ovo1aMbGQXS4LF1FqkIrQUdjg/xg2Ub595WFIgf2GSkx1kh74nftrZFr1vyR5PmWS3mpz3SbxnhLd6K7YSqBY3jm+isk6/0NsqK6ibnehu+ODdKa+HMqfiWP5X3PcdPqTJ97OCgdOGYkQFr1d3bIKSuL5YerSoakwBhV5LQl/j05X5I13jfE43A7frl72PR4BlJr7+5dsqjMkQKzNkt/X58cGYNKnXbEPzi4V25ZmyXlgRKj2/HRk8ntjLFjSlQdTsWiDQyl0nM2+z4b07OuXr16OIXkAUO1palRsmZukbKGllEfvZtWxO/ZWy23bfhDCfprJRgcmpAwmbqdaB6E1YGcsYLx+ozWTQUGHVtgX0+X/MmcUpnta5CBUZyeLW2I37SzUO7f9FnHhauX2rralMxRR8gWLmfOe6ZkZ7IF9rq5z5mnl41lUpiIOVVA5w/s7pOvLfTKc1trnAowOkO404L4jTvy5Ym8r0jAU2vGzKdSv9tr7bKpWGdCBqQCakDXx+M+15idg9m9ddgU4hmJRFAJMOSL0cEa8tUhWQC1pUO5dEg4YWakGpuu288zh3bvlG/PL5WHsr2ye/hbPKOGrqaTLIw58Xv2VsrD2Z8xhGdWSnuihFSBKVTgcojKWHwqBO6jShumSmdIN5WCxZOYRVsbgGjsgQjkkz0VAaLbS8cCbRQCPIOrp5WaZ7QikC4SibQhcH9Pp/z9PK+8XFQhA87z2AU67HxCEf/gYL/ct+kjUuGIejh+NAwePAe4GuIAZu1gbD8VgYkVmF6dCpGTk2PuoyI4h5C8A6Hgem0kgsuRCBAG4mkl4JhnIDjXIDiVizSoCBAbcM597vEeaKmqkD+fFZC13mrznEocrVjJwpgS/+71WY5xVy91jo4fLUuXGT0Q5baE4RqzbTEPP1KBQJINZtQaCUIZrRCUfCBlQmLvbsma0WjmIUimt2NjzIj/eN4nxFdRKsHKYEqMu3Bgzh0WOABMzsASLXfddZeZcgXOYukUzllNQxdg4nl7waRkACnDd1iWhRlDdFi3wqiA3h7JerdZDvR2paQCjAnxlwQvkGzf74wfr+JvtACXU+Asp8b0Kiyi5OZMdDgTJ2H4qc6PtipHPOB7TOWGJxEIBMyKIqEAwYsaO+WfljTLvl1Dy8UnE6NO/O17K+SVom9IWanfcFqyfygaWMMG0Q5Ro016wBr3qAKsfvcEjyMBriPEB6wliNQJhyOOOjx7Q6u8VFzr2ATRl6SPB6NO/Ps2ZjkGXoMxvFKlyyIBEYvPTuEXFhYOXw0NjEEqClb/SPW+DQzO7Oxsc4x0Cbdy5nEc3u/o/zbpbEresmpgVIk/x/sj2exfYiYpGotYPUYeXIxVjRin4BG5amUr6OfHdYjODFpEBKkEyQBz95EWEg9jTyVAJPBsU3ev/MWcJtnT9+FCkNGg8/2pMY1nAcOpsTtqxN93eLu8VPA34inzHfd/Rxt8F65TQHQMO9w8xDpuGytq6rkWGoEYpEUyPBJWAUOiAKRQpHV4bRw7MihnrG+TeduqTqqs4aCziaG+9B3sGSoBFWrUiD8l76NS4asy3a3GQtwDiAs3u0GMAW6EwCxzphyjwBvhflTxHAV4F1Q+bA0qEq5euIkgQwLxP71NdnfEVoYQmn8mNsGm1yA+GBXit+zMk3lbLzbuUqy1NhVYsmTJSUuk0k8AlwvisrInFYBzO0QLEM+snjES4EHows9Y+UiBeAzeY0ePyQvlnXJ3dpUhYjQg3tm0omiASu2GUSH+Q9lZEvDWH49jjxWYUVPXwcXgxOWD+5hYWUFhsTgjlYCFmFUKIBFGYvHj2WBjKAcSVKJ5OW4cPexwf6v0tdSPWIKmnPjNDtd/sO1q8fv8Y94hA/3OvPuscwshmKc3nCSickBwnsMwe++998z8vonihRdeMG4joIJRuTwejzmPB3Du28EeuWtjbNwfCSkn/pT8j0qgvCYpXI+BxDTnEAVrnD3RN65zHMkNQrxj6eOyaRyfPv6IX1a+Yk9vYPscMY+YRiXwHt8gnXhENUC/822djp2OIRA/YRwdMLq/r7VhRNyfUuLvO9QjbxX9q6Pr/UkJ4UI0wq+0wrHhNtEAwzEcGo74FDyGHnobQrKRFgTlOsfqy7vPOdZ3eJ/rbPFY/qzHSzoKPArV/QnBqXy/2twlMzePbAXOlBJ/puffpMxbbERovNwSCnBLuIWVsaJDER8/HWIhaiHYSDbS4Bt8Kx7Ln0q0du3a4bOhvI7UeDxy+KB8enaTbO84edLoWJFS4j+yKUt8nsrjrkWiICDDvPdwD0YXBYno1I17VAwIzbN20yeuJUad/Y59TJOtO71I5/joVCa3NxAOSCeeV9C2gCSiIo0Mx+TPFnZITWVFwrZUyojftCNblm67zdGr1RF1cSyAeFjebCxchOH27LPPmo1jrrNng8tY58bGpk2bjL62RTjt9lj/+j4b6ekx16lopAexeJcNGyMeQw230RbxiHxaEpOBZY275I4NlVHbKMIhZcR/detXjK6PK4gRBnStihUUNg0nbmBtQ1SadKkIVABW5wonfmlxg9A8h1tGyJfGoMWLFw8/ER0qdbS5FtVBehiUSYFj+H3k/RbpaW1KSPSnjPgPOyLfX1593K8dCeIhPhwdivhUCnuJE6J6hFZRFxAI/x+jFDeQc5Ugdiga4mtfgFhA5aLSKWjCHpGVHwJ/9EGnNAT9pmLFi5QQf/eBZplZfJZUVVaNWOQDLPlIwP2DKDTXIqJDER9iQvBQoG0fjoTo7LHOQwFpwDOxACuc/gK2ZEFlEUBKJp7398lrBYGTOoPEgpQQf2Pd7VLkWXbSwkaJIhrx6YzJ+jYYU3S8sCN2AAMQorljDQR8VJ8//fTTxs8nEIOBhqTAWLPFKVIgVuLPmTPHcL4N/kP7BiYLuw8ckm8vrJXuro7hK7EjJcR/tuBTRuQnaoi4EY/YD0V8iA7RICQcgu5H/Kp94I5BQGS4n0rAcwSEtAct59HcNCx5CM36PQr6DvBuMlxeN7KmN0t7Q23cAZ+UEP9RE8uvSVrfvGjER19DLHrEIN7dxEcqcJ3wLAQgOsi1WADReJfKQ1sAx0T5ImHRokXmOZvQ2BdPPfXU8Fly8emFjt6viF/vJ534/O5LBV+VymBNEnzZIdht8KGAywY302qGGEfk2uA6uhyiJ9r3HcudtEkHozASeMbdS4h33b2Ck4ULC/sku8Qbdzwl6cTv2l0u8zffYCJgyRJx0XS+Ddw4N+ejzzG0VL9rZ4pYgCil9Q2JQRsCPjoGphu0/sHtqBKIj/qhyZaNsDDfZp/MjqCKhQ275InswAnBrViQdOKXtb8hm0reML1HkkX8aGIfl4xWN/Q3hewmPgQgOgdw9yAOxCQyGE5P4qWQHhY7RNdFFBnDhwRxA4lCxWJYF7peN+wD9jU1NcYj0YWXk4nG/kNyzspqx7aJbwBq0om/JHihbCnNjTn8GQsiER/iETVD7ONKQXxW1rSB5LDFPZVy2bJlRo9TEWxJANFZep10qDTbtm0bvjMEgkRUHHdTMOmTXiQjF4mBPZB0HBmUL89rkNbmxrgYLunEf6fsH8Xj8Sa1n140nW8DsW/rfHe/PTdyc3MNkakEcDqERXTDwaGAXuUZd2uaupNIHQiMEYoryUZlYkPsc558HJPfn9MqLfU1cVn8SSf+C8V/IgHf0BizZAHRGwkYUmzEFYjw2WKfuD6EjQTtog1REd3RFjvmuVAxDOwKDTRh3XPOhpWPPfDaa6+ZQFEqkDXDIX5NZVxBtaQT/6n8jzhuXl1S++pFEvv8LJyNTw7hIKJNfHR9OBdLWwN5DwkA4EzOSY8170MhlGpRzJgxwxh7NmgIslv2UoGsmW3SXBWIy8NKOvEfz82SoK/hpB6wI0E0g48KgDgmrqCBGwWWOvaAAp1IR04IjBhWQ9AGBUgDDgSDkO5xenQoCdcZA8PTTXwijykn/vvt0lQZn6+fdOI/kZ8llf6mpAV4QLyunq3z4VJ1r+BkCI50IHQbC0gLXQ5BtSkXycIwq1AgBkAebGA/RFM9I0XWnC5pCvriattPCeePJvExcCAOz7BBbJvz4XDEO0RH7ybqakFUCIhNQVt/OE4ORXw8hJQT3+H8xooxJv6TeYy5b0gq8aOJfZqNsTFQNRAZa5tNx9tTAagUcC8hXq4TqmXjWLdQ53qNlj+tQKRHurTzu1XC2In9NmkMxtdDOunEf67wk1LhqxtVnW+DgodIEBu9jT/PhkW/YsWK4+dsiZyTjp7jviFt7LDqmBHfMfjibddPOvFfK/mq+L3BpFr78ep8uBPxPBogb3ZTMda+W+xjK6Rc7M9ul3qH+GNq7c/x/UhKSreMuNOmDXW92ChEtnDnKuL1HRXRuHR6zqbnbPb7eq7v85x9rvc1TU3fvm9/X99n0/vudv6R45h8dl6z1Fcnyc/XMCXDkyGkDi7UHiPUMA2ZEscHO3bslJyah2XTlrkmsoYuZmoT9BAjRrVNnHRIT9Nir+KKsDDnRMww5rAdrrvuOhNUoSmVODnHDPOm8ai+vt5sXGP+Gt2TJ/vc3tNCF+vzkdKJ5b69Z6MdgkBQMrHr0KB8f2md1NfVJSfCB3EgGkTUYUEQhA6Z7PGXEe1UDIhFZeB6Tec6mb3hNtNlCr3P8xBWI37UTK0EvMd19mSayqQViXf4NpUB4nOsG+C7WvmSqWJSDQzRZBO/uOeA3LGpxkQ5kxLbhxgQiY1CpiJQyFr4HENwiMM1OJzzPf275Y38f5OmxmbD+dyD4FQmrVBcZ09lIW3eUwLqJEgmLafSwfnMiQeoUKRBhaFi8T5IRifR0QJGIh5EMnG/b7cs3uyLu6d00nU+eDbvM9LUEH0kSawiioaXiQLiDLiIycTXVnSLv9xjGCMepIb4+R+Xuur2uIyPSMBYIi02JAIqgU3PR2tLxvdoEyBukEwwX0+dzxO3BEwJ8ef5TpHS8uKk6WIsZFwqJABWNK4cvjTXiQHQsMN9NloAOcfKZs85z+j1ZJ/zHebv1XPywH02Io+aR+7rM8kl/jH5/z5olaqK+Nw8kBLi13SvlCXFvz2uk5MN4u3vvvvu8NnJwNdONneFA4QPp96w8qkc8Vjg8aKw56Dcll1rPJ54jD2QEuLzr09lf0raWlMzEwcNK5GGOBNfD9XPLtmAqBAf4zUUmEga4icz1O3G/12/XbZ6vMcnX4oHKSE+mJL3EamraotbFMUCODsS59PPfjQ4H+IjysMRF+Jjr6SS+Fkz26XWW5ZQ55mUEX9TzQOSXTJ9xFOHhAKBEggcDtwbTc4PR1z8bmyUVBG/a/+A/HBFgwQrKhJispQR//ChwzI15/PS2THyUbpuRBP7SIVkB1JCAeJjzEXi/FSK/bPz+ySnzC9t7YlN0JAy4oMpuX8gtVUtSRf9GZ0/hKz32qTaW5qwdE0p8X2tC2Tx5jviDj5EQ7rp/EjET5XOz+k6IL/YVGfaOhJlrpQSX46IPLgxS9qaek1BJQvo/EicP9o6Pxzx0fn4+akg/h/O65Qqn2dEk1+klPiooRUVN0lu2cykxt/pphXJ4EMqjJafH03nQ/xko+fAoHxnaZP4veUj6jSTWs53MOgwxcMO93e2nTy3PuFSInUMY4o0VQnvMQiCDhoMneId9Ho4IBkQt3Sq4B0mXYoERuySJs9iKIabxEHBdOk8S/pE7CKJfYhPQ47mO1rHUcYMMBwsksH6+UVd4vUNrTSaiKGnSDnxjx49Jkt8l0ueZ3ZI7mfsG9OdYBjRNSoUEOF0zaKbNYVHIRLiDTUkjJAyBQ7n01uXqds4D9eYQiUiDEtrGyNrGfJFiDZcZSRd0iMvDAgh5MxGRXaD8X24evT/4z/5Pyolo4ZDgQmhuE9edGygG3D9PyxtEV95/LF8N1JOfDDoSMUHHO7vatsdtqbS0QEiuCc8Yvg1BeK2GZjrhh4zdMxQoP9Iw20MIpapPO7pU+lvB6Hdc+ox+ybinBk/FFQqiBhqTh6mcUUKaP8CQMcTKjT9/mzQZI20eOmll4avDAHCU6mi6fCPO7q+wuc1oeORcD0YFeKTydzqZ2XptjsjuiVYrhQAhQZnQ0iIFs5YZCgUz1I5qAgQMtxYODqMQCBNm++wMctWKDBVKunBuaTNs7wfzrKmAkBU7cLFd+gyHgqEYvkvnmdP2kiPaMu8ZjsW/vnrmsQ3Ql2vGBXig2MDjsjclCXNjZ0niEiGUjHfnd0xg0kP4Qx6vWrthht5ls2e+IDOk4ygQXXYagD1wMAKxubb0oF0+B66VfNBxUAUkzZqQFsjuU5lYoydPRUL6ZEu6et8ugAdj6Si2Vb/h8pC7x3Shru1FxNgjV7+0x4lzP+gekKphqzp7VLvKzPPjJTrwegR38ls1/ZGeTbnc7Kjb485Z4M74EQ4hX55oYBlDzdhOOl8OuEMItIkPTgQ1cBzSBCkRCigu7mPQQaReReO1B5FbqBSuE9eUCNwLcQKBbqakW82vo+twrE9qMQG8QvSYwII7AkbP8nulYWl1aaMtL/jSDFqxAdHjjhWe9kFssEz9SRjhZ+FqIh+G+vWrTPEsXsDw00QFQLYHIBuh+gYiLaqgCMhGFxpA+7nutsboMmY6+6WMogGceyKgXSgwrgrF9dRR+5vYviRtls9EbUkbWYEc8O785B8c4lj5JWVHu9GlwyMKvEBxh/iv6mx9ST9ibFHBWCyBQgAN3IeyvXiXbpAU8AQBY6kkoQL7tAxlGgc1jppY/1DhHATOcOF3H/xxRfN8wwAhWttsa2goul9JoaiInCMaggFHcSBS8fzqATyHm7hRqZXr/eXmRh+OPsnEYw68eHUnX275T6nAuzuO2T8dwY1qP6FSyE+nI0YVo6Hq7HOUQF2DyGmW6cSUJDocwXvEQXE59dKhjUOl2OcsdyKTUjEP/rermjkhXzwPETSPJIXKgT5sQM86G4qH/mxXUXSoXKi+1VSYfjyPunjRag0gbi4ejqm8I/mt0mxL2hcv2SJe8WoEx9QiP7GNTIt9+/lqSlTTa2Hw8N1SMDA4xksYyxuODjSkidqefMsVjTH4QI9EAZVgQSBcOSDc5uoNrBRcANJF27HIwi3KCKERnqRX4iMNCDtcNPAoRJ4hjz87vlpcuW2nfJ0cb2UOz69rfaShTEhPhg8fERWeO+UuaVXyjGHodD5EMk9ozXTqFPAthsEB2A8IbptnQ8obLcvDjeTBtxrg7lw+Sbj9W3AkVx3FzhEhvB2XIBGK0S4W+eTR2wBd3AJO4O8uNUNlZMKrp7MWw175Mx1DeItLUlZd7gxIz44fPCovFn0U1le9rAMHB40upsCwCXC1UF8cm67agrVs3CgukZwFVwfCoRCKXRUCs9rJA9RHAqIXTgWj4Eh2dgKPI8h5wZqBY4l5KtpUyFwP0MBwlO5+E+exYPhP3UmkHWde+WvF9VIZVlJ0ty6UBhT4oND+47K8wXfkY2+V51CPGK4kcKGqOj8aBEv9CwiFRFPfCAS4EZ8cIiEIUerWyQgnvEosCewHSJ1lUKVafsD74QL8ChQccwagirDMFSV5+k7IH82r0pqy0tNhVU7IxUYc+JTqw/uPSLP5v2jrPI+K4cOJteoGU/I7uqXP50fNH3ysEXc3lCyMebEV+zrH5AXC/6fLCi7Uw4dSF1tT1fMauyT/7nQbzh+NAgP0ob4SIB9ew7LjC03OGrgp6wcylVzb6LjV9ua5Ker/FLlKTX2zWgQHqQN8RX79x2U9d635Y4Nfy57dh1KalAjHfG3Sz3yQEFAfI5VTyAqlTrejbQjPqDFqqauUm5c+zEJNBXKkcGJVwE69x+SrJn5ku2tEE9ZmQk4jXZFT0viA0Rfb8dueSLnR/LS5kvlyIEh1TAR8NvSGvnbRYVS5/eadv9UjG2IBWlLfAAn7N65R3K8S+TqtX8igZZix6cavjkO0bJ3v/zB7PXyxpZyCTjcjqsZrgvYaCCtia9ADXS19srU3Cvktk3/Ijt29jk1Y/jmeIAjsf5jTb78v1W5Uu3zmrg/UbuxtmfGBfEBhtDuXbulqrpSbtvwfXkw7+whcZnmmuDivGL56sKVstnrE6/D7XS/CtduMNoYN8RXEKXr275DPIES+fW6H8ttOadKa2+DqQTpYhPscCTVKRvXy9cXLZFsjyPiPWWmPYC2gnTyXsYd8QFERldu7+41PVsey75JLlz9HVlUOV0OHxq7COHchmr5y4Wz5MzVy2WbF6J7DNGRUOnoso5L4iuoBEYS9PZJS12brNi6UG5Yc7Zcsu4n8n7FW7JzX2pawxT7nW+/Ve2Rby+fIf+8ZIZM31wo1V6vBIb71NMWkI5EV4xr4tvAJkCsdnV0SUNVo6zbtlruXv8rOXPlf8tVm66UN/3viK87IIcGEtO3RxwiVvS1y++C+fLf69+Vv/lgqpy7aqZ8sLVAKssdl80hOrNj0IkUqTQe3NIJQ3wbxAioCN1d3dJS3yJVgSrJLsmRV/PflJvW3C5nLr9SfrTiMvnJimvkvPW3y9W5j8j1+U/LLYUvyDX50+TSnKly+rop8m/LHpDvLL5f/n3p43LuypfkybwlsqakWAIOsau8fqkKVppwLJY7Hkk6c3koTEjiK+A+CAInUhnoKtXuWNtN9Y2OdKiXumCtVPmD4vf4xFdWLuVlHsciL3fOvRJ0iFvj3GOrrqiUmupqaWpsNJ1K6MBBVzIq2Xjg8HCY0MQPBwiGmsBewO2iJzH6mQrCxjHX4GYqDkQeb1wdCyYl8TMYwrglfjziFi5G5I9WUynSgp45di/jdMS4Ij4dMU877TQ588wz5ayzzjL7c845x4xwCQUMMe6fffbZx5+/8MILT2o2pSL96Ec/kssvv/yk6Butbddee60hqA3ycuqpp5ouZ0pkuoZfcMEF5nvnnXee+TbfDddPcKwxrohPQ8j5559vOlLSK5a+e1dddZX8/Oc/N4WMvrZx+umny8UXX2zG8tEvn9639JkLNSyMXrnnnnvuSfcYS8d1e0weYKAFhKavv9oNfI9rdAGnazmV8qKLLjIVjufTzTgcl8SnVy8dO+lJC2fS9Zrrl1566XHOhVhUCnrGEk8HFL4O5nQTgg6XEI4OnvY90uW6e3wdnA1RmagBXH311eZ7dMqkAmEskhekD/nieXtQSTpgXBKf7tlufUo3bgpfiUGEjQKHGLaYp9v0KaecYvrJ2YDgSA+6UOs4QvZwPdyLtNHrfBuRTndthnhznXOeYSiWGwR/yDdjDfAw0gUThvgM9oBDGfqk+hnCXXHFFeZYgegnjVBj9ND53KPiALprw93ofCqSjh+gTz/fYhAmbiFdxjlH/4fq1w+wNy655JIRTaCUbEwY4mPNQyAGbuhIVrgSolDwZ5xxhtl4Bk5mzzlj5NWHZ0SPXTEgPDYFgza5rrNsqJ3BaCLAaB2+w0gftzGpoCKShj3Of6wxYYiPawVBMehUr6t1zzh6RuogFRDrEAqDkXMGXCrBSBMicR3xjNXOBAwYkqgEBpKgHkj3hhtuMF2wAKNuSJPK47YlFFQWtnAjcccCE4b4FCoEYLQMoheO5pxna2pqjkfuGOULEZgciWuqxxXcw0BjvDzHjJgFSBSVClzHkNTJJeF45fxwkUCtiKHG348VJgzx4W4IwPg4LG30NUTCereDO1jtpIHrFwqIcNQC+v/KK6+Ubdu2metY8LyHVc8eD0MJjQTg27ie7ngA4PsYhNdcc81JLuNYYkIQH7GNWIbY6GFELxzLORxsi2LEfCTi4zqiPlRd2MPG+QYVAyOS9XFtYD+Qbqjp4TAMSQ8VYs8JMNYYl8RHfyvw4dHNcB4DHnVyBaxqiIilbgN/nkrBoMpwID2+wzO21ICzIT5xBrtSgNdff90Q2D3zJ2IeO4J7S5cuTasGonFHfAgHodGhbBCYa3ApQ5xtLmcYNMSi8PGxmYAB8QshIC7XWLPP7XsjWRD79jx8gIpFWhh2odoJkAikTX4Yos23OeZbjDhmrsF0wrgiPmPVsdaxtJnwGCMMbmdyI/Sum6s4JzwLIfGxcdEYbs1Yfow6rkN891x8BGWoAHzPDdKxp4Kzgb4nrEslgPCXXXaZ8RBQPeHm+xtLjCviA3Qmoh4uomMFjSnhfGvAPZ5jli+MNt7FXkAtcI4BhhfgBoGeUNxNZ0x7pk03+B6VhsqIyEdauI3TdMG4I34GyUOG+JMYk5L4KuYxDhHThINVlHNN7+s1HUiJG6eTIyHKeZZrpMF1NRxpzVOXT0W+psk5oWgCUdoOoO4f8Qk2wDXSdzdTJxOTkvhE9ShUInQQSj0ECh4i6Zx4NiF0D5EhNsfYBKSlzcjapqBRQ86pOHyL9yC8ngOew0ikEvAtrmslwZUkX5p2KjApiU8hU/BwKpseQ1QA0SAIhNJ7GIgQkE27hKlBqASC27mmlQViU8EgpHI5afN9PBGukRbXtOKxqdfCt7UCpgIZnT8M5f54oRVG9woIqByeCNzppQIZ4k9iZIg/iZEh/iRGhviTGBniT2JkiJ9BBpMQGcbPIINJiAzjZ5DBJESG8TPIYBIiw/gZZDAJkWH8DDKYhMgwfgYZTEJkGD+DDCYhMow/2XFMZGBwQPoP7ZMdB3bL9v07pWtfn3Ts3S6te3qkfc926XTOe/btlN79u2XXwb1yYOCQHDuSPkPMM4gfGcafQNg/sF8adzVKQXuhzK2ZL0+WTpWbcm6TC9dfJ2esuUx+uvwi+dGyi+S0lVfLuatvkYtW/0YuX32XXL/mIfnN+qflro3T5J6NL8r9m16Wh3PekMdy35GHc9+W+za9IXdteE1uW/+q/GLd7+Sq1VPl/JVPyc9WTpEfL39c/n3pw/JPi+6Xby16UL7rnH9v9XPys7WvyM35c2WaP1sW15dLeU+r9O3fK5IRGGmBDOOPIzD2p21Ps6xvXilTyx6X63MukzNX/VTOWnmqXLbmYrljw+3yctHLMn/LAllfskG2eLaI1+OVCk9AKn2VUuWvlOpAlVQFnH2wSmqraqSuplbqauukob5BmhqbzJwnTDGpG7MT6GbOud7cIs3Os00NjdJU1yCNtfXSVFMnjVW10lBZI7WBoFR4/bLVUyZrtxXKjIJ1MiVnqVyx6j35zyUvy98tfF6+umCq/MuKt+XKvCXyerBESjtbZQ9DWRMbLpVBnMgwfpqiY2+zLKt/Xx4ovkEuXvsDOX/V9+TWjZfJi0VPytKtC2Vz+WYJlFdIsDwoQa+z+YNSVVll5nyBMZmChFGijA7VUaaM9GQoMKNNGUXKIECECYMTE914n420SJO0Ga3KyFRGmvJtxrf3bndcBidP7S2t0uYIjBZHUNQFK2VruUfmFeXKAxtXyGnLZ8n/XPCmfOmDN+W/1nwgj5UWy+b2VjlsDU/mmxmMHBnGTwP07GuTxbWvy+15Z8mFq/9Jrlv3I5lWcK+sKV0qHq9HKsorJeCpEL/Pb5ibWcJhIoaBw1gwtA4rV0ZOR9jCgrwihMg7w9P5l27nnzododVWVy/BigpZtnWzY8Wslu8snC2fnTdDvrl0odyxuUi2trfLsUOHSdBsGWEQPzKMPwao3eGRVz23y9XrvyVXrPmWPJV/s6z1LBafYx5XlFeJz+PsAxVGe3d0dBiNyfB+GAWGmcgVnX9ToYDFwPwXPY5A6HKEXX1VlSzftk2uX7tGvjJ/vnxm7nw5dd1GWeRYD/uZxOTokSFhkEFUZBh/FNC1t1He9d8t163/ulNpvymvFN8lRb5sx0SvFn9ZhcPwPjMXuDI5ZjJmM5oxgyFQFlg1uCzGdXDKqquhQYp9Pvltdq7jIiyVT81ZKmesz5PsxhaRgweY0CRThmGQYfwUYWvHEnmw4Idy1ZrPy9MFF0uud7kEfTWONh9idKb6xFzHzMUnnuiaPNlQy+CgU3b9u3fLju5u6W5slI0er1y2Nlc+NXulfGnhenmyNCDbmUNvcMARApkyVmQYP0k4euyI5Da/K3fk/C+5cd2XZMaW+8XrL5MKT7WUl3nNXL/M88s0axlGTw1UEOzetUt2dXVKXW2NPJm/RT4/b718Ys4m+XWBV1p7tosMUP7je9HrkSLD+CPEto4FcnfO1+SX674g80ufMOsk+ssqpdxTbrQ68y3iq2K6Zxh99EBZU+aUff/27dLW2CAvFZXKF+fnyMfm5Ml9myukb0ffsBBI/RSH6YYM4yeA9n6/PLP5+3LTuk/Ke9tuFV/A4zB7lXgcZicgxwSq+KIZrZ4eUCEATfb29UqLIwQezCuTj88ukD+fv1lmBerlyJ7dcvTw4UkTE8gwfoyAf1fVPiy/XP+H8kTu/5Fi/2qpKK+TsjKPWRKTWZjRLumoPVjmg/VeWeSPpUDZuzeus/YcW6j7ei/cfU03Ly8vrYWdbQns294jJdW18tOV2yRr5mY5a71PGto7RQ4MWWgTGRnGj4JdB9vk1bKfOqZ8lswtuV0qK2ocnz1g1sqhNxs+O9HmdKzsaC9WA2M5WVYRYxEpmPPtt98+YWNF0Xfffff45r7PFuk+77OxcimriLOAVFlZ2XAu0hfQjGbD/f27ZVdnuzxbFJCPziqRL31QLmuqmuXY3n4ZcO6nsyBLFBnGD4P2/nJ5ouB/ym83/ZFs9L0jlb4GKSsd0u747TS5pbtZSK+9Z555xiwlyEpuqc4vzWwwP8sHsmzxeAJlc8BxBQ7t6JG1gRr50oJy+YNZXnm9tFYGdvXJwKFDE8oNyDC+C/U7suXBnM/IwzmflyLfEgmU14rHMedZUpHOJOmq3cOBAOO9994rt9xyi9H899xzjzln02P2v/3tb81aorpxznU2NPhdd91lrunGMpR2OlxD2/OdBx54QKqqqkKWk16LdA93iXJWc9t97gbXue+G/Q33MRvp8q5uAOam1WWgf6eU1jbItxb5HDcgII8X18qBvh455Aj8I0dO7B3JMd931w37ON2QYfxhtO8ukcfy/1wezfmcbA2slYDHYXiPxwxaUXN+PIMF/jH3b7/9drPeLEzKOevQsqo0671u2bJF1q5da9aTZznxxYsXy4oVKyQ7O9v47ixFzuK/N998s3mXdDgmDYQKAoOFi5WJ6E7MEqd6Tp8FmjRhLqwmNgUBUcYWwIy66hSg3BG4Crr2Yp4DuvvqWnVAxyUA9qSpq1xBQ9XY+PdYJ0CXNgPcJw3Nx6FDh6W7uUEKSsrk24uDkvWmR57L8ciujlbpc9JWkDZpKsgz6es30hGTnvF3Oz78C5u/Lg9s+oTk++c4Gr7OROfpD08F1Eo7nkHFfuuttwyDvvjii6aCwzTr1q0zq4zfeuutZhFqmJi1/Ddt2jTUO85hAJgO5mcBaRap5hkYnnTKy8sNo7AEPO4E91henh6IfINuxtoXnzwQVed5ypT0uQfTcF8ZEIbTezznZnzeJx3Au8q0ACZXJkSokA6BTTSvvsczXOc5wDUVNAgRvsV/s+l7AwOD0tfeItllfvn8TI/8/rs+mb3ZJ4OOVaBCCPC/mh/9Trpi0jL+0WODsiBwkdy9PktWlz8pQV+jidA3NDSYSjERGF5BXALTHOZk5XiYTKFaEAaBwZ999lnzLMyNFseER5O//PLLkpuba5jDLhsqPi0axBIQIIsWLTJp8g0qP4ys5wBG41yZl/dtDQ6zwTzK1DzLMQyoa07yjC5NiGDQ+2h49rYwIK/K8LwLyBOuCP9L8JPvkybPKMgLm30NRt7f2y2rKxrkk7Oq5SuzA1IarJZd3Z3m27bW57t2OacbJiXj+7vel3s3ZsnMrWeZKH1ZqVdqaqqPm5FUgomE0tJSY5rDxFR4GzABrRNE62F2fPaHHnpIpkyZYsx/jgnWYS089dRTplmQcflu0MyHgKDlAG2ZzsBSIQ6hLRDEKPjPlStXRtXS1I3BgcOOtt8hdxU2Sta7jXLtpgbp726Xg/vTszk3FCYV4+8/3Cuvbv07eTznk7LVv1J8ZdXi9/tNn3mks2qEiQZiFTA1EXe0M/+LD69BOQJ33MNMp+ehO56B5sPPf+ONN4wVoBYBgoDoPdoX9wDGJy2eTVcQpMW9QcDR0oGFQFxDmR8XxnYtwsHUlcMHpLGjW76xpFk+PqtZ1gQa5NCuXmMlpLvymDSM7+l4Q+5ztPwHpVdJ0N8gnrLy42b9eJHSiQCzlzZ2GNUO7KHpqOQE7eLV0AQ8YRZtt8fEJ12EAucIlXQEvSrJMy4PrgvaHdq/+uqrxqJBCOIWxYNBhOT+fplW2uZo/za5YE299LY2yT6n3NO5Xk14xh88ekhmeP6vPJb9+7I5sMhoebQamm88SOaRgiClmrW6zZkz57iPPVJUVFSYwJ8yP+mj9bmeTsDFefDBB01z4+uvv348rrBq1SojsBAGGzduNNfixVHq0MAhqevcLl/+oFX+dE6zFFTUyr4d29PWdZzQjL99X1Cm5P2hvFH8HQn4g8aXx9SbaMG7SKD5DLMW5iT6rkE4/HYqPL59PEyKiYvrQDowOekQP9Cuu2pV0DSYLsCiQcPD3JSDmvJYfMQy0PZz584110aCo4z429cvV+ai/Vvl+cJq2dvVlpZu5IRlfDXtl5b+UoK+Bikv95o2ZYgw0bW8gmYqovRUbJjS1vIwL6Y+2pn7mP4vvPCC6YrsjkbDOPPmzZNHHnnECA22+++/37T3U6YKmtB4BsZPly67BGwpAwQUeaOpERDHIP80QU6dOvV4k95IYRh84IC8V9ElWe+1yfmr66SnuUH2Oukn0/RHcRFkJf6i4N+IWZAH/hs3j41jrqHw9PkJyfgb626XBxymz/a+In5PnaPRAqa5ZSJG7COBykwADsaOFHCDsRcsWGCCW2hxGBuzGG2IVcA5mlw7+dhNXDaUyfge7xMLGEuQT/XfCTzalg2xDf4LgVdYWDh8NTkwdezIYSlp7ZU/mN0m311cL4211bLbsTQGkmRpIrigr1qvMDgxC+1LYNMIZudZ7mn/hgnH+AsDZ8qj2Vmy2bdYvGVVxrfDtJsspr0NmunQckSxMWsjgYqCluZZmB/zXc14mIbBOF6vd/jp8EAwICSI/Ef7Zqrx/vvvG+ZGeBUXFw9fFWlsbDRBPu5NmzbNMEpKcHRQ2np3yRcXtsmX5zeKN1glu/u2n9RqkgiU8QHxKpgbS41rCB7qvBmB6Gwcc417E1Ljz/P9RKbkfExK/BukvCxo+qlP9Kh9OCDoCGIRzHrzzTdPMt8BGpkefUSz8X/Z0PLLly835UblogynT59umJ/7CAKEQ0FBgdHwbhA4hdHQpGPp59PqgMtBvul4pEDA4bYg1EZFOB07Ijucsvza0nb5i7lNTt0Mys6e7uPBxbHCxGB8R5rN8f5Qnsz5lJT4NjlMPzRDLZJ8MjI90Gaqm266yXS6ATAyJv8TTzxhzF8YGe0M88Ow0QJQCAM6uTz66KOGcfR9rAHtGISf+fTTTxuBYwfSRhOMF0Cbs9GCYYPOOzA8+U+2iR8Ox44OjT/4xvJ2+azD/FsM83eNKfNPCMZfVHGePJ79UdniW+2Y90ETuaegxzKSimYh+IIAQquQp3Ab9/UZ3ROTGAloxsPMV38bLY22ZuMcjajdXhMFFgMTcPAdGAlNj4/POUwH46s5OlpAABGwJD8ENG1fl8DXc889ZwQWUfxRZbxjRx3Nv0e+sqRdvjS/QXwVQdmxfew0/7hn/HW1v5RHNmVJoXeew/TVUls3ZN6PJdMDzEmYDnOTSsgxGwyhATT7WO/zLBtmejzWCj4c2pymO8xbNDFMDjPqMRv5gTEw7zHHeZaNY9045xneDXWfe2wc0+ON+5q+foN3OWbPt+hLQN94mxGTDWIaaHPKkeY7GN0GPj+WCIKJ6cxHH0eldcce+eyCDvmHRfVSXekwf29yfP54Ma4Z39PxpjzoMP26sqni89SaXlcQOx3Me4a0apAsno4haCKamPDLY/0PNC+VGU2GGY7QofstG+m5N8xfnsEFCHefPZF+ntNz96bfCHef9/kGzWbkC4ZMlflPywRWDWVAT0V3ByVGIqqAJV9jhyOyrX2XZM1ql3NW1Uh7XZXsHIPg87hl/Pbd2+Sx3CyZv/VKM5S2wjGdIH66RO/pLEMlQ/vRdBQrYBQYH787VlCp+Q4Ve8mSJcNX0wt046U8aDLElUkmcCfQ8GhzBAwBSRsEIRGkCAU6HoUKdI4ujsjblX2SNb1NHs4OSndjrfmH0VRY45LxB48clFe3/pW8WvhN8XmZ/y5ghpWOZbCEHnBUbJiPCsgxJrtqGfZsVD5741n23FMz335W38VyINoeDgSqMKl5Vr+tG5YHggGTX10L+9uaX/uee7P/h+d10+tq4qsAsr+veaLTD4N6ktmXgjgFTE1e0PjukYPqAvFvxDZoyht7OP9/bECuLuyR35vZIiu2BaS7tdlYKcksm0gYl4yvfn2RZ4n4yiuNqTuahRYKmJdE0NnTdkqFtDdaGNjs41DX7Hf4Jx31BvNhMkcDbbrMkgPD4X+jCdXv5RoMAINghaAZ+SYC051nzY87T7QD45NiXdESQFOf+vOkTz5pEiToB6PD9Jj9qdCy5IO4Ad+mjOiN6AbWBQIRgcQsRGMd+/kQx6Rvz3753KIO+ebCOqmik9koKq9xx/htu4rlccfEX7z1V46JXy/VNdVpEcxTxqfCJxM0TRFIQ6PFwvi0CqDZYHQ6p+jkELhAMOqyZctMoE2ZFcbkfOHChWbASrjWBFoJaMqjW69qcN4nHYbrYnHYY/2hB9d5lsk/EBTJBAxCnmFoBA79CtxAaNFzEWGEMIw21n70cUyWNjr+/swOuX9TpXTWVx8fMZhqjCvGR6PP8n5fns//nJSVb5GAv9JouLE08RUwPr45E1IkArQ7A2ro+64b4+ZhNrQZjMb48WhgqS4EBe/ArJGABqe3HnmnvzqaESZiwxdnUg2ECMzLNY5/97vfGZeDvEWK0MP4WAMwHcKhqKho+E5ysH79+uOCK1TwlLqi7hcuTrK/nzQcGZBTNvXIp+c0SX6ZT7raWox1lGrrdVwxfmXPAnnU0fZrS542ffDRbmi0sTTxFWh6Khltx/GC/KOJ1VzGHNdNz9Fs7s4obiAACQ7CDJj5lE80EFSiOyv5hvE1D3wPhtU8cJ3AGAzHdFWxmO4IFtW4uCzJAm4KeSNd3IhQ4BkYnmewDNIXx6Ske498ZE6nXL22WtqqK6SvL/VB6nHD+PD2LO/35IX8L4qnvEQqApXGLE2XKL6a+olq/HCg2ytMTAWOpvEZgEFzGcwaaiYZGBGfl3TovYf7QLo8jz+OhsZiIFCqoHxpH8flgPF1IA/v0o6PCc0/I2TcFgBChXcQHLgdWGcjRTAYNHlAuKHRQ4F6wf+TR7472p2I4sbRQTkrd7v8jzktklfqk46WppTHrMYN4zfu2GCa75ZuvUf85eml7UGyfHwCVjCbCjT6mWO6w6DRfHz8aB18gsbDdUA7E+BDY5MGVgnaHJMdZk6kDHkefx4rRQOJmjZalt57+Px0kkHIICj4h5FOzoHrQgclGJpvwByhoF12CWqOhxV9wKa2ftO2f9vGSmmrCZomyFQqtXHD+Kuqr5MpzKJTtl4q/ENr1Y1Fj6dwGInGh5GITlOhYR42jtmowDATzEXPs3Ag2g4z85ya6DA7fjl99hEAdB9OFQiwoo3pCswU3TAoeSEf5B/GZ37DRIEQ06AlrQbhgpDkAUuEf0fopLKnYDKBm/YPK7vkawvqzZwIHW2tx0fSpQLjgvEPDOyWF4o+K+8W/1j83mpHk6RHt1wb+MhovUR8fADzo33t5jP8aHxjmAYmCufPArQfwThlNgQGmp0OLfRUsyfMSBXIA4Ng6G4M45MP8gMTcow1QlAwFkBfrAqEFQJDXRi0eE5OjmmPx6Jgo8cmFqAOK+abuC7ELrju7rqbrnjCt1OyZrTInEKvtNWltrVqXDB+Xe9KeTwvS1Zte1wqvPXG5xyNyGc8SIaPD5H5J90A0WiCbgiVSD4+zUBoWqwEAnBoOrQ8vi4aV60JuvZioscS+IsGmp1gSiwRzSMCh2MCkdyDTvRi5DrMqDPgRAKxCe1+i/CihYI02WuLBec6boBj9npOTESFJWmMbRfd2LG1Z79kzeuSX2yoluZKv4nZpMqqHReMv6nut/LIhiwpKF0iwUBtSgskUYzEx4eB6NtPJYVB2duaWzVnJMYn0MV7obqsAvx/GB4zmbQQAjAHwoJvE9CLpl3wOdHYPM93YEryByMSR0BDh4r2M68//8BzsUzmgRAjn7xDr7xwvnwkYCnoqEEdlpzu2HNoQL68uEP+96IaqfKVS7vj3qTK3E9/xncU3yzff8oLeV+RktKtUl1VO2qdHOIBjD+Sdnw0tLbfoxXZ8GPx/WEYGDUc48OQMAiCh3zEYh4iPOnjzzBVTHEYmA2Go11czWMCcgzUQVvDRDxDDIGxBJjSsVRMrAtMdQQTQTncmUiAvrQ68DzxCdyeeIH5T8ck0hgvGp9JO87P75U/ntssuaVeaWmoM/+eCss27Rn/8MA+eXXbX8rbRd8TnzfoSPJ6U3HSycwHaHoqWaI+fjjAXDA+TBfOx8f1YfILnkn0+zR50VkIt0AtDYSNWhswPtHyRC0tBBhpImjwXSOB+3QoUuuHjXfVwkDAIuTcG/fIL/lW14Y9gmu84H7vbsma1SaLN/ukpbbKCOBU+Plpz/g79tXJswUfk9lFF0vAWytNTUP98tMNIzH1EWL44wTE0FK0U8NoHOOvalQ/nManqy2VHNM2Wm89NxAaMDyBN74D86DR6W4Lw2DS820YCsZDExNDCBdVDwdW2iWP/E+sU3IhZNiwongX14RmQiwcvacb13Ap8PexYChPfS7dlEQkvFvjMP7MVvldnl+aq1PXrJf2jN+x2yNT8rJkQdHNJrBHsw7mZboRcySMDzDtGVJLuzhmNNNZob3p+aaaLhTjUw743Gg2zGjtmx8KPIuJT7CNFgCYGW0Ko2CK0xQXiqF5j7gB37E78MCI5Jd+8tGEMc2vaHu0NR2F4gHP8z0sn0hdb0tKSo5bRzD+eMTy5r2S9X6bTMmpkKbKQMriWWnP+K07i4YG5Wy+U4K+JuMDp2Pb7Eh9/HCI1nMPjU3vODQijO/2hwnqMSoNza2MDsMycAbNHc3sDgXiKzAyrgcCA6HERroILfzrUDRCkFFGmPHx9OJTjY82t2fLdUMZH0HG8N/xiOyOfY6p3yEPbKqUpqBfujo7UzIWJe0Zv2VnnjyRnyVLt9wjlf4moxnTkfGpnDBVoj42/4UfzAAYou9smPAEtzDBqcyhfFUEA0wHA8LEmIVoRZrxVDNzH8YnmJdIoCwWMPKPZj0VUjAqzWu0NsCE5IvoOv8RTXO7QRr8B+5PJE3OsFydSHO8avyC7v2SNbtT7s2plsagz7SiTErGb9+1TZ5wNP4HRbdK0N+Ytow/Uh+fwBkam2GvbJji7PHb1cfXnnuYflQINgQFrgB+ORoXxtIAHcIAZuA5ND97yk/fdR/bWyL3aRLEJ+VYV+MlH5of8qnHTNmF1o9luK4KVQRGLBqf9Merxl/ThqnfLo9mByc343f3B+Sp/N+TuUXXOIxf75j6HRPSxw8HgllUZjQoTXZ0jEGDw+AwEpWcYzY9Zo8gQONyrKa4vfGcdu0NdZ/ryqSR7mv8IdR9vq950DzqxjXeRaAhIGDacJhMPv6Cpj3Gx38ur0IaHFO/2xGmk9LH33ewV14s/jN5O/9HUuGvcXza9A7uJdvHh/FVcyrTYM7SNVbLgL292dfs40jXwm3hnrWv28ehrtnH9jXMf1oPEGrEKcJ1K8bSiUXjE9VXq2fbtm3DV8cXng4MRfXnFHml3mF8gq2TMqpPIGm655/l5fy/N2ZrU2NLWo3KU8DwaDoqMHO80QmGoJpu9Llns6/ZG8+77zMyDy2PZlVTXrUwPjvmNN+y33d/Vzeu67Ohtmj32aKlH+k+G/f1H9lrMyLlRmsBcQ364evzmqb2USC4h/anXPQZ3XhOuw5TPjzHCEW9T3yD+pOqnnDJwvXbdsnH5rbK+hKf1FdVmO7LqeisFjfjkwk309kZwx+h26Z2OuBZuwOC/T7X3fdsDL17TJYHr5BH131UNpdulPq6ZtOBBynIuzyDz883NW2Iy+ZOD3CfZ91+E8+Gy7PmkzR5j71KYf0mGl+1EpUYrYympi2eoBTn7BlhRns9JjDPcp9r3Oc6x1zjnI1zNt5lI202fUbT1Oe5Hu6bCA7ypM/a9/V5zY+es3Hu/p7e1/Nw99k0TT13Px/qf/Rcn9f3w6XPxjU7PY75XxWWXCf+kLY4dlT+aVW3/M0CVnf2SF1NTcoG6sTN+EgggjJUdoApQlsjDGBP/ABz0OsIprS7aBLMUSbjp+wOCqSlwR7uEyzas2tAPC3vyR0LsmRZ7jRprG0336cZSxmebynogab9xfGNSF9BV1C7vZlv8Qz5Ia/kn//imj15A8+poLC7C/Md3uM/0DDXX3+96bOu39A2dc2Pwj0xBN+kjFJB4AzEWBK4YQiMdGb8uv7D8rEPuuWStXVS4y1N6ZwTcTM+lRyGY0+l18rPNfYKmNm+zjkbzM2PwGQwFBuCg2swBExM2mykvWf3QenoC8pDqz4ib288T7YW+0y3Xf02z8M0qnlJQxkPRrIZXxldQRq8z3UVaFwjLRhc80z+lPF5jms8Q8SV59mzhDSMj+bX9/k23+Nf7O8qNC2g/5tBcgF9Fy1aZIKD6c74cxr2SNaMVnk+r0Lq/OXSkcI+K3EzvjKAMgVQjQvj0U6sDAxgAtus5kd0U3Cfc32OPe/BuIcOOceDR2WR70J5seArsnlLgTQ3tR0393mOY75JGlyDibim6cF0mh/2PMszMCaM684f5zaj8g7fAdwnXzCpraHpuEKU2h4JRlnwDOnpO6SjZaRpAp7R8swgeYB2ukgJcRF7WrF0wxn5ffLZ+a1SWOaV6oqAUUipqhNpH9xTlLW9Kc8V/g9Zv+01aarvlN396TURB11sYfz0nthx8gHGp88A8Zd09vEb9wzIJxwz/+drhsx8Xe05VXV83DD+nv198rviL8mcredKZbBOujrHduUcN+hOS7CO8e2Y/fTgo6cds9FwTLMVPdC0Hz7HRKHp687zxAiI4HNMbz3e4x3uc87GsW7c53n7vr2N9D7Xuc9zidxn4z7/EOoeG/f0H9350PQjvc99tlDvsxFvoSMUAUCaDDH1R2MmokTwgHeXmX3ng80+qWEsfoq7po8bxgc5tQ/KQxuzJLd0jqP1O4y5nC5any6rTIZJ/3VdSJIN5tc9PelolsLk5Jo+y5533df0Pc4RErxHGzVNVggO7ul9no30fqT7bHrffS3cfX1f07Pvc03fcX+PjXuMkecaPROJuLNHeOq79vv29/Qa5jtClGZOLC0Erpa//Y4ec4/BRKFiLWONnYeOyJ8t6ZYfLK+XSm+ZVFdVnhBETgXGFePv2tsp0wo/I2/mfV8qA47W70qPxTRiBcxLdBmNHy+ID9ArkDZvmqrSulkqRhATQqPfcMMNZh8vU7J0Gs11lAkCIR2ZOhY86t9tgnqziwNS7fOYFqtUB3rHFeODzY0vykObsmT91lccrd+VVlo/GujkQ3SZyD+VPh7QUsF7WAxp3x4dI6AbDE+ZoL3jNW2Ze0B7NaLVU2kapwrNewfkY/O75JzVQ759laPttWUplRh3jA9x3y75R5mW8yUpd8yijvbucUNwNPaNN95oNH6ijI92o2NKuvqq8QDGx0enTBAA8dIRjY/1gzDElB+PjH9+QZ98fE6rbCwNSKWj7dW3j7d+xItxx/iguXerGbE3u+hSqatulx19H7aHpzNgfLQb/vlIGD+eaarTGcr4NLUlwvi2xseXH2+MP7txn2Pit8vTBTVSOwqRfBvjkvFBbt1j8uBGTP7XpKWxZ9QKbCQgeKU+fiKMT+uA+vgTRePD8Krx443XKOOrjz+eGB8T/5PzO+WnqxqNXx8MpLbd3o3xyfgOzww6dWRe+eny+KY/lK3lG6SzvdcERFJtIo0EOsosER+frpu8h3ZL52apeKCMj8bHx0+U8cebjz/o/Pc3V2+XL3/QIqXlXgl4h5rv6HMwWvV33Gp8mL9/7075XdFfygu5X5WKioD0dH/Ypz4dQXBvJBp/Ivr4MDwaH5M/kag+1g9lMp58/EuKdshHZ7bKipIKCZaXGgEGfUdTaY1fxgdOOW3f1STPFvyxvJb3z1JVWeeYS+nr7yfLxyeqn/HxP1xEk74N48XHv72MjjptMmtbtVQ7TM8kpmPRMjW+GR845dXcUypP5H5U3in4kdTXtMqOHUMDbGIBDMT6aywfTXAFc2ukQHOxthvpsZE2lZRKDuOPxMcngk1lZ2op0iR9Kg/HyQDjFygPzTtp8y/JArMkkz4jz0if6cWwgkYS3EMYIkxJzy53vpMsAUm+KYuR1JOnK/pNMO/F4hqpcZielYdS3VEnHMY/4wOH+Ru7tspjOb8nbxf8UOprW2XnjqERgZFAgVNhYCb8RPZsdL1lBtp4CQIz4n/TPRRfnjTRRvQso3KSNudMM82Iv3hABWFOPt7XvLJnI33O+S5rzlHh4wGDhrBGNF39hm5cI//0HGQG3XjBGnqs0KNlQH41XTaOMdmZTCOeMocZVeMz5t5On2scUyZcpwtvqKnDIwF3ClppGqRHuuQ1XmE4Baaf3iYvFA1F8CsrK08YnTnamBiMDxzmb+oukydyPipv5P+b1FY3OQUbnfltoFWZ6ooZX6hIbMwlHy0NmBimxGTlHWaWgZlsrU7gkeWo7BVtMd3prBEJBPXox29XYLSlm0HQ1AQP+T5WBV1gowkA/pe0SRdBxexBMLY7bfLIDDbEFvhH+r4zm000MD0Ybgn5QTMzn79b4GHmMlMO+eU5JihhxpxoQNvr8l8Iav7D3amJ8kc4YE2oMGZqb6LnkQDDUxaUC0KE5cdbWloSNsfvox++w/Qvb3aY3tH0lY6mh+nHsqfhxGF84NTX7r5GmVrwZ/JC3l87BVwhO/qGxsLHa1ozWaN2DqFyTZs2zUxNxWSPbAgIKrIGl2BkVouJBVRQTFwqI2kjaNB29CUnbeaVw+Kg8qmQoCmQocTRgJBi/DkVloqOBYIg0rTZszG4hnyTB6yEWDU55i6r6fAuQgaGoyw0bWYLJojJeALSpi8912IBZjRWBfkmbQYsIRTs9Omjj+Dh+5QdblM04QmYawEGJm3yRfkzhRd5o7xJn29BZ56hzJmifKSuwkVFOyRrZpvML6lxfPoSo+nHyry3MbEY38HRI8dkd/8ueW3zN2RK9qfEE8iV3p6hsfqhmB8CoHVgKp0xxwbmIb45FZKpq9R8ZI+mwYQN5RbQuqDp6vwAblBhYRI65JC2bbKj+RjUgzAJpRmwKDRtvhPqGSacRKjAKGpes5E232TlHjSPG3babKF8b6wXtCeCjzRVQMKwfA8LiPXq3UBr2uUSKt9YNCz4QdqkCZOTPv+AaY/gQRi4YdOSjTJ30xwrBwGOsIN+Wt58AyFFmTPvn7t1iHyTHumzj8a4h48clX9Z0yOfmt0q2eWVEvQMBfLI11iZ9zYmHOODI06hH9p/TBZ7r5T7N2XJhrIXpKdjaGYeuyJAPExnzFekPMRHU8EsSGY3eBcmYAtVYWFkmpWoUKSF6UrgStOGuRlFFs5MJl2CRqGaJPk2Go/3YVxNm42KC4NgijMfgD3rkII0STuUAKRSMzU1zEba5JV0aWajbGBsGA4BGMpMphy1XEJVapiFwCT5g7nIr502bgDaONT4A02bvIcqc4Q1o/+wbNTKscud9KEnmj3UwBfKRfPuNuURgLg4CAPSJt+kjXCDicOhctdh+cS8TvnOshapCPjFW1YqDY2NMQmM0cKEZHwAEY84impL3TvywMYseb/4HGlt6pE9/XtDFj6VwufzGdORyo8mwO8k8hoLGGZKRaNyEDAkoIXpijCgQqMhqaAqFLAggsHg8NuRwWy6MDZp8z4r7OC/Y77C5ESZ0e4IBc0DY9FDaXM3WC+PSk2e2GMF8M/kGZMUX5qgJf40TET6mMnR/GRAmRI0JD+UJ64LmprAGHnDb8YqQPjyfzAV5nUs+Ybh7YAkzAlzUxbkjbKhjHChEFqaBzr6hBIgNlAQmjYbQgW3IJbZe16p2eP48+1yc3ajNPg9Js5BnCHdOpdNWMYHFPRRh8adPc3yQsFX5MmcT0t5MFd29u03kj4cIagYdAGF6DAEJifLW8EMqh2oHFgFOiYc7YXWCuUuuEH8AO0PE1Ep8cndaVOBqXxoF55DW4Yynd0gMIWfSkUn7+QJRiNfpI0WoyLiQqh2J/+cR6uY5ItYgzIbjIx/DKNq3tHuXMMNUGGFOxOt+YtvkwcVQjAyQom0VStjJiNQ8f01bYKlsbSQsNQY1hzChfxjGSHUSJO0YUyEhS4VTh4ITKIMYsFBTPu1PfLR99tkmadaqjwlRtjjKoay4MYaE5rxFZj+Bx1+XB24Q+7dkCULt90sXW07HSaIvMIrlREmpQJQ0VUQUOGUsWAaNHwic7nB3GhpKjtpK0Np2lRA0o7V6rCBIIFBYG5Nl03zD+Pghyey4gzMTeQdYUTaCCYtH90QbCzvBVPFC1waO23yq/nnGuVCcDKR3oswI1F+6OamJRu0oFziKfMPWvZJ1ntt8tM1zVId8BnTvr6hwZRTupj2bkwKxgeY/gNOHWztqJZp+X8pT+R+WkqD62Xmuwvk1l8N+eOYdJixaHvMXBtYATA3UV42GAtt4YbX6zXmKpqcSoslQMUi4IUWJAYQKgqN1tK0qdCh0kYjEdVG01L5SZsNhsB1wAdHmLgrG3436ZL/cPnGEoCZqfRqwbDxDwTCcB0IernNZNImTU2ffSjtrhFzlv2GeUmbMkezcx0h4U6b/9Ay0Q2rww20Mv+Oa0ZZaLkj3AgE4r6EKnOsIMpa06Z83VYP16AZ6SAUjI/vlE9ns2NFHRX59qoO+YNZTbKwrFpqy0ucvPhNWpRBNAtqLDFpGF9BRT24RyQn+ILc6/j+r+X/QEq2lcnmom3GnMc0psIg/WHUWDrDUBlZ9UVNScxP/HKuETRDg2FC0vQFUyEIYCRiALEAPxF3g8qMJiSegFlMExS+PQzL3PEwFd8n/7gP0cxrgOmMIOE9KjbuBWnji5N3mJ20qfgwFOWCYERQRAPlQjxChZQyIflluSuEAeVCUJEyIX3mzovFdIeO5JPyJO8IVoQiwTjKhLgEx+QVIcz3oQ//Ew0wLHlU4U3wkfgM1yqDFbK/t0tu29blaPkGuS67Qer8XvGg5R16IlRDBTjTDZOO8QGEPXzoiOzo7ZfZ2y6WOx3zf1HpbdLbtUeOOcoSTUNnGCo5hIfZqMCYbviCaAr2BKdgZioGlQ9tibSPBioQzEDaWBn0B6DCkCbMwh6Lg2+Stj4Hs0QD/jwCS01jGBk/U9PWDebQ9nCeI+gVzRdFkCB00NgIFywbWig0bcqFZ7B6EGz8I+lzTFwhEmAWOktpvhFGCAY7z3yHpj7cHzXVidjzvWigzDWugoDjHOFFnjV9zlVQkTZlTznZWNyyR7Jm1ct3l9WLJ1AhgbISCVZWGmGFW+NuGUhXTErGV8Dgh/Yfldb2Rnm58D/kzvVZstrzjOzcflAGB4bm9afyIfmp7CoI2GB0Nq6j4RkpFi/wrxEq6mfqpmlzTDQ9kW6yCCDtyUd+SQuG0ryzRwNjlUSLcrsBcxMcg/lIB21K+pSP7hEMCMVQ/RcigbwgAIhNuMuCdFUwYBmEaraMBAQ+ggp3jrTIt5aFlhH0xPVwt7gUdu+VP5pXI19cUC3ryyulxlNqXAxcBYTHeGF4xaRmfMXg4IAcdBy2mqZyeTbvm3L3ht+X9b6XZXcfbeofmm0wE6YxGoaIPhZAsoAvSWUjbQJQsTRpxQo0EfmlojIbcCymdKygwqOFKRdtwkxWFBtGJfJOuuQdtwvNnCxAP8qFMqdcQgULt/buk88vrJbPzKuSBWVVUuctNa4Xgj6d2uXjRYbxLaBt9u8ZlJoGr0zN+1f5jWMBLC1/VHY5xD90YMCp5OOTyBnEj5Xtu+XT8wLyuQUBWVJWKbXeMil3rAVcqfHix0dChvFdQMsgAPb1H5am5gZ5rfBsudURAG9vuUzaO9vksOMajFcpn0F0PB3okKz3y+TbS32S4wuaMfNYBMRzsBDGO8MrMowfARB5/96D0t2xQxaXPi6/WvcxeTT3W1JWt14O7nUEhOMGHDs2vny7DE5G675DclpOtWTN2CJXZQeMq1VRNuTDM8c9QT+EPUphoiDD+DEAoh/Yf0B29x6Q0qqN8kTOv8nNjhB4v/Q30tXTKYMHnWcGM1bAeMOr1e3yibmb5YsfbJUZJUFpCHilvHRoggxiLrQijLegXazIMH4cQOITKOvftU/aW7tlSelU+fW6L8pvNnxJVvhfcq7vNV2Ejx7JWAHpijVtvfL15VvlI7Pz5Fc55eIPVEiwrMSY8wTs6OgTqTv3REGG8RMEVgAR5l29e6WurlamF98lN639nCMEviYrK16W3bv65VhGCKQFVjhC+lsriuQj72+Qi9ZvkyKvX2q9HvF4ykxLAa0c0HIyxW4yjD9CmGDg4IDjB+6THT39UltbI7M2Pya3rPtbuXHdV+W90nukdXuDiCME6Bw0UU3HdMKegQF5sbJe/mrxJseUXys3ZG+RLf6A1JZ7pLyszPSLoHsxvjtxnImu3UMhw/hJhBECTqWjQvX17Jam+lZZUzpL7t/033L56i/IfXmnysaaedK/p98xGZwXHBkwGStdKpDT2S3n5BTJJ+Ysl28sXicvbC4Rv88nVTC7x2PGz092ZreRYfwUgYplWgUcE3Jn3y7pau0VX7Bc3i9+Vn659ntyyeq/lvvzzpN1NXOlb/f2IUFAXczIgag47Jjka9va5MK8fPnT+QvlKwuWyh25BZJX7pVan1d8jlan0w+df+jdR5Auw+wnIsP4owRMfIJG9Pbq7dkh7U3d4g14ZP7m1+TuDefKhSu/Iddt+E95ufR+KW3Ll7379hqLQDGZK62vr1ce9ZbK/161VP5k7iz5l2VL5HHm93M0eQ09HZ09jE4PQvx1ypiyzrhV4ZFh/DECldK0EPT3S+/2Puls6Za66gYpKMuRNwuekVvXnys/X/UvcunaH8iDhTfL0urZ0thb61RoggXDiUwwdOzbIwsbq+X6ovXyzWWz5PML3pHvLpkjd2SvlxUl2yTg9Uk1S045G92b0egMQMJ8H08DZNIBGcZPA6DNqbTEBzBLaVLq6eqRjuZOaahukjJfqSzdukCezX1Iblp7sZy38kdy1or/khuyL5NnSh6XxbULxdtZLn37+uTYYPpKhf7DB6ViR5fMr/fJfaUb5Gcb5sjfLnxZ/trZ/mPZdLlhwxJ5e3OeFHrKpNJh7iqzrtwQk9NVFh+dsmGQEGWVYfTEkWH8NIUKA3xTtJkJGPY6lkF7p7Q1tUtzbbNUBipls6dYlm9eJq/nvSr3bbxXrlh1pZyz8udyyooz5bSV58lFG66Rm3PukvuLn5SXyt+R+bUrZFNLkZR2+aWmr1Ha93RL7/6dsufQPjkwcFAODR6WwSOOPwxTOTLk2NFjzvkROcxApoHDsvfwAek70C8de3dI3a5OKetpkI2tAZlbv1mm+tbKbcXz5JKct+XHa1+Sby99Wv5+0RT59pLn5PtLX5TL186Ux3NXyJziHMkt2yZeT7lUO1q80tmCjqnOgBkG+TBYBt9cNflE6zWXDsgw/jgDDMAGM+DHYiHgLsAoaMT21nZpaWiRxupGqa+ql+pAlfgczbmtrERyS/Jl5da1Mrtwobye/748n/u2PJX3ujyQ/YL8Zv1TcvO6J+S6NY/JVasekUtXPiQXOdvFKx+Ry1dPkavXPO3cmyY3rXtJ7tj0pjyc+748nTdPXspfJO8WrJQlW3NkY0mxbC7dJp6yMqlAY/sCUu1sVf4KqaoISk11tWFs+r2TV/JM3vkH/oV/ymjx0UGG8ScQVCiwqesAQ2EaM2acoBemMkN+8Y1hPqbNYpIM+qTTc62pscnZGqWxYWhrqG9wtnrnuMFs3OOZ5qZmw8C8SxqkRZqkzeg1tDUtGnybPGC5kCc7jxmMHTKMn4GBzZC6waj2FuqZDMYnMoyfQQaTEBnGTyFY2IFpoJnqiemcmB+O6bSZtZZpr5hWi3n5mTSSqHWiYAovpv9iLrkbbrhBrr/+ejOtFHPqMT8dXVTR2NGAa8CMsqRFfpkYM5b3AHPxMV8diGYJYPrzHS0XJvOMZEHoLLpMlskKOdddd51ZiYdpxZhglBl6kzmr0GRAhvFTCHzmK664Qn7+85/LRRddZPbnn3++XHDBBeb4vPPOM5teP/PMM+XCCy80i1bgG0cCPjvTSf/sZz8z7/MeDAHzs9oOc8ddeumlcs4555jvsagF+YG5I4HFMMgT77BHMOG/RxrAwgo2Z599tvkHGBqBF4n5mVmX5/nGxRdfbFbSYUZfe34+GBlGP/30083/sfH8JZdcYjbe0zLk+rnnnitnnHGGWcuQWEMGkZFh/BRCGV+ZHUZlIklddRcmYzJPNB4z9MKo+iyMwWSVRLzdTETgDMaGqan8THqJsGDmWMaSMzcglR/mYbgpmhjmjFUrMksvQoi8YD0wJbXNlDYIFmJdwHg8jyZmam4EUyggFHgGhuV5JtXEsqAzjv4n02TD8JQD/8fEnUyuyQSf5IUJM5ksg956rJCDULvqqquOlx1pMx12Mufnm2jIMH4KYTM+FZjFI5giO5Q2R6NynUrP82hwGJuFMoic2xqXSk96bAgL3AkmgAxnJcBQtI3PnTvXrA1I23gkjUyU/pprrjH5gInQojTDhbIWMMHPOussY9GwIQBwZ+g+SyTfDVaxQajAoJQN79tlwjz4aG7uo9kRiAhGBtlE+j++RdoITMqOvDO1OK0Mkf51siLD+ClEKMbHpEWLRwLMDzNpBVZzW/1tGJBlvXiG+zBmOEYDMAAuAUzMtNIsJBlN+8NspA8DXnbZZebcvboQvjf32WB6zG+O2fMP7pmC6aDDP+k7lAdLjGte7PuUF4uI4BYg+GJhXoQjVhUCk3LB9cG6oq9ABiciw/gpRKKMj3a+9tprzXts+Ows7GCbrjA5AoF0YWiCXmhzNCYbpj8bWp4gH+nAUJjEBBmZc5/VdljMA3PdDdJnzn80KOnjbzMFNdYCYM8CFTAZzEqQjvUH+A7P44pgkquWRmhhvSBMyDPz2ZM3Ao9qzRCIVGtALRnMef1mLCBQqkKT7xA/wI2IFKOYjMgwfgqRKOOjKW2/GR8XLW1rUJiBlgGesbWoe+O73FdTnE3vqTBAULjdCQCjKwOxsca9ameYFpOc6wQUsQhgUvKq+WY5MtIFaF6NScDUrMJDLMDWxhpbIE9XX321CRTCtLG2LAAEpP4f38JVsAVWBkPIMH4KkSjjwyzqY7OxlBNBLTW12RMgg8Go4AgJtD1mMcxE855u+P4sR8Wz5EE1LSvoEFxkY/ltgoGhGIwAI8yIFmelGcx7Bs1g/nMNCwLLg/8C3EdYkG/uwfC4KbzL81zHemCdQrcJz+q+6t9ffvnlxwVSPD46wVK1QpTxCXCGiw9MVmQYP4VIlPFhCphNNTmMyyKQGinHRNfmMBgQc5bodrhIOia/xgMQEizoySyysQCNDNOq4GAdPAQRTMw5VgetCUTrFcQU+B7PcB/m45j84sIgTBBIbi3MIpcqzEhb1/aPx0zXYKOWDQE/gqH0HcjgQ2QYP4VIhPFpjtM2amVUmqaYFFIZQBmLZ6688kqz4CX95sNpRkxmZXw0fjyMD2gKhCFVi+oeP54gHhF3mzlhMrQ6mhcGZFMXg0AkVkCode9oMmRdPL5FXumMxLfDCTQ3KCNaArTsyB8xDMYhZCL7JyLD+ClEPIxPxXznnXeON0fxPG3omPBoc9ruFfQBsM1ZetpRucNpRgQH6fIskW788XgYH6C1ER7KwPwXwTfbErGBMMCX55u8QxnA1AiKUGv4Kwj2KfNiJSD4MNWjaX0sCL7De/qfBAsp70x7/snIMH4KYTM+zEJTGqYoTVhoPTqu0G0Vfx6mUtOeCkxzHT4ubdw20ytIh04uylQwCF1X8acxoYnK8x7BMYJmMBHp8yymupraBOs4DtcUqMDXJuCm/0KEfu3atUaAhNOmdFZSsxshEM0lUdCPAMsEYcX/YQFgQRQUFJhYBJYBe0x4mJu0eYZn+U+CjQQiiXGE63g02ZFh/BSCtnW0j5rZ7k21EwwJ89M8hl9Lv3eCbjBlJE0Hw+J/o/2p8KQFA8AwfJNNI+n4u2hS9bXZ6zPkBSEULsCnwFI49dRTjZDBvcAtiSQwyDsC4rTTTjNt8rgY9CqMxezmXRhd4wvkl3xyzD+x1zJkz79Rfvj0CEAsjkwkPzwyjJ9iEBxD8+Brwly6cU4Qj4BWbm6uMUnxUWG+eCos/jQakmg+ZjQaEGuASDtaDzOf72Bh0K6OxqXrK24FzxBoI8oPU0YLpHEPYUMXYJrNYtGmPIOfTvq0BsQTZENAUBb8H2VIvvm3l156yQhImJzuugQ7saL4PyyeTCAvOjKMPwqgAofakg3ShDnp2ceGNubc/S3OuWc/E2tbuX6D52P9B54NlY94od+GsREI7PmHWPOewYfIMH4GGUxCZBg/gwwmITKMP4mAv203+9GsqP3YiUWwYTbTy412do7tgTn06dcWBiLztj/Nc4wxUHOeb2nfAp01V0HQkg4/fNceJ4D5rt/lWJ/Re8Q/1DXhnvbGY44/Whf0WfKi5j/54D754P/0mI00NF88TyxBOyLxn7xLU6DdqkJ+7V6A5ItvuwckpTsyjD+JQAWmIsMAML0yAhXZZnCgFRxG4DmYAEbnPfxqmJC0uAYTKZOw5xn2pAmjstd75EGZShmY9NVnt/NB3rTPg6ah4Hne4xrMS3rkCcCEvMs1hAx7oN8FPMMx7/KvMD7vkCfukTbCje+7mx9VIGp+KCdbgI0HZBh/EoEKCnNRubWiUvk512swIpVaNTn3YWwAA1DZYRAFQgAmgUFIg/f0vqatzAbj8RyMQzrsYTKYj3cQEqqFyQtp823NK+/r82hZzm2GU4FD2nxXrynj8v8IDPY2M+s7yshABRvPs/G8vqfCivwD/pm8jCdkGD+DDCYhMoyfQQaTEBnGzyCDSYgM42eQwSREhvEzyGASIsP4GWQw6SDy/wNBk+cuc8ukvgAAAABJRU5ErkJggg==',
				width: 60,
				opacity: 1,
				border: [false, false, false, false]
			}];

			aHeaderColomns.push({
				border: [false, false, false, false],
				columns: [{
					width: '*',
					text: ''
				}, {
					width: 'auto',
					table: {
						body: [
							[{
								text: "D&WO Integrated Logistics & Invoice Processing Platform",
								fontSize: 14,
								bold: true,
								alignment: "center",
								border: [false, false, false, false]
							}],
							[{
								text: oHeader,
								fontSize: 14,
								bold: true,
								alignment: "center",
								border: [false, false, false, false]
							}],
							[{
								text: oSrvtyp,
								fontSize: 14,
								bold: true,
								alignment: "center",
								border: [false, false, false, false]
							}],
						],
						alignment: "center"
					}
				}, {
					width: '*',
					text: ''
				}, ]
			});
			aHeaderColomns.push({
				image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWwAAABuCAYAAAADICkGAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAIjfSURBVHhe7Z0FeBTn9v9nQ/VWbv329ta9t0Zb3KKb3SRoEhLiuLtLgUIFKe6aECUhuLtLS7FSqhSHCoUK7W2Lfv/f874zKxEILRV+/z3Pc57ZHdvZ2ZnPfue85z2vAZ/5zGc+89lVYT5g+8xnPvPZVWI+YPvMZz7z2VViPmD7zGc+89lVYj5g+8xnPvPZVWI+YPvMZz7z2VViPmD7zGc+89lVYj5g+8xnPvPZ38Yu0E/rl0WYD9g+85nPXGbU6wWj5iAY4SNhhE6B4T8NRuBUGME59EwYIVmc0sOmw3Bkc5qrX4fTZVqd7yPoNfNh1JgBo84sGLVnwoiczSlfx8yBEc3XMfPoc2HEzdeetAhGwgIYKZwmL4TRYAmM+nzdcBVfL4fRbDWMJnzdbK1+3YrTlvQ26/ma3m4DjLacdtwEowO9yzswOtG7vwujG6c9tvP1ezB674bx6i4Yr3Hal97vA/oeGAM+hvHmRzAGfcrXn8AYspf+OYwR+2CM3A9jlOmjD9MPwRhzhM7X447CGOvh8t41j+tM/gLGxGMe/hX9SxiTTJ/M9y7/mvv+CsM+OW7+GoXNB2yf+cxnLjP69iDUXofRawhsXSYQgmkEZB6MRnPhV59AbUSYNiZ0GxG4Tfi+Kb0Z59FtLQjYlvRWhG3rxYQpp204bbuMQF0Koz2n7ZfD1nEFocrXnVZq70wQd+O0O0HcbR2nBG8Pei9CuOd62HpthK33Rvj13Qyjz0bClkB+7V3Y+m2F0Z/+OkH81jY6oTxgO/wG7IDt7V3wG0Iwv70HpYZ8SPB+CNtIAplTv5GE8+hPYBvzGaH6KWzjOJ3wOfwmEM5T9sE2hWCeegBG6kEYafR0AjqL8M06Clv2MZSaTtDmEL7ifC/zjDzOyyWcTbfN+Aq2PEJY5ovn87XL5f039OMwZp7w9pyvkXbgrPlrFDYfsH3mM5+5zBgWReg1g21gZ/j1702AU213HwG/DuMJZCrrhoR3A8I6ZR78GnLaeD5sCtxUyQLu5nSBtgI4Yd1qMfxaE9wK4oR2Ow1tBe8OnAq8XeCmd11DaFM5dye4BdrihLbxqkCboBZg9xWnaia0jde2EtwE9hsE95uEtrjAe9BO2AbvhDH4A06poodRRQ8nuMVHENyjNLSNMVTUAu7xe2EjtI1J9MkEt/iUA/CjK3CnH4YtXaBNQNONHIKZwLZxqoCdK8A2fTrnEdYK2AS3l+dTRStoE9gzigB29nGk7feFRHzmM5+VwGxjAvhI74AxshYhlwJjYCuCuzvB2I/wHAq/jmMI30wCehaMZAK7wVxCnLBuyGkjTpuIa+Vta05wC8AVuEV5c6qUtwnudgQ2p7b2hHZHvjbBbRPFLfDm9PZXqbJbUXn3WAdbjw2w9aTS7rUJNgK8lAD8tc0ENpW3UtsCboE2lTbBbXtrB8FNtU03Br0PPwVuN7z9BNyjP+Z3FmhTaY8luMcR3OM/h23SPvhNMpX2FFNpT6PSJriNjCMK2qUKQFuB3APaLnDnCqw5T5S2C9yisE1oe4I7mwp7/xnz1yhsPmD7zGc+c5ltdBjVZhDVpp3wcvJ1KOEWA2NIUyrXjoTia1S8g+HXaRhsbTOorqebiptK+3IUN9W2rY1AW0IloriXw9bBVNsWsKm+a4/fjiOnfiT0uUxCJEpxc9rbVNwSJiG0jX5U22Z4xCbQpsq2SYhkoIa2MXi3VtpDd2toDyesxUVpjzKVtgK2hrYxUUPbUtritqmEdoYGtpH5e5W2CeyCStsHbJ/5zGclNWNcIIwJhPREcUJ7PNX2pGCqT4J8VB0CrwGMAR0IyL4wXn2byroXjPiBBGoubPXnqFCJUZ/uUtyEdyHFzamltF2K21LdWnHbCG6/TgS3qO9mXNZ5LffJbbtvwDVU2QJuG8EtStuvt8S2N6kYt+21rfCTEIkV2zaVtm3AdrrAW4P7WoH2W4S3xLZH87XEtQXeYz6Dn4RISqK0s0uotGW5QNpTYYviFi+otCWG7QO2z3zms5KYMS5Iq+qJBLVAewJBrTxEAdxvohN+oyMIuhSq4ShzK+DunsNhtJ1ItZ0NI2EmjOS5Zox7nltxN3UrblHbfi0ltl1AcbcnsCVUQnUt0Da6iNJeiRu6rFGf81g/KmxpoLSUtiu2LWpbQiQFGiNVTJtKm64UN5W28TYB3fs97PiKoBzEeRIaGfkhgS0hEjOmXVBpT6EraGul7TfNW2kLrFUDZDFK2w3qAu6ltOnTfcD2mc98VkIzJgRTURPWEhJxKW0L4PTxnD+R8BaAjw+HMbAeAtIHEJadYXR9HbUm5WHYovdwS7Ncqm2CWMIl9WerzBK/plTdl1LcbbmNqbZt7SS2vQIP91uDiWsJS9muHUHdmU6l7SdZJWZcW8IlorYlVKLA3Zfgpgu0/VQWiVbYorTl9SNjPkT0zP24e/guAnsPjGEfwk+FSMwwSQGlrbJIJprQlkZICY9I9ogZ07Zg7Qnt36S0079E2gEfsH3mM5+VwIzxGtg2KmlxBW3lAnET2nSbwFrWnUhFPpyvR8bB6NcYA7ZsNPfEfcUPgVE3Ff9oQhgHZ1B156sYt2qYlPi2pbgJbFtzKu0WorS12lbhkfbLcb0AvOkyzNpxGPWm7OT8BYhO3aEbMHvo0IhS2pJJ0ovvrSySPu8oaHsrbXpfmXL7t7Zi1rtf8w9nJ659m/sdtgc2QrtIpT2eSnuCOME91QyPiE8zY9qSPaJAXRjal620M77yAdtnPvNZyUyp54kE8WSCWTmhLT6J0BblLQpbqWwP1T1J1LbMjyAIIwnVelTKLai4B2DsynfMPQNBfdfAiJ0Fo450mKGL4ia0bc2osFtIqIQQVrncnKpQiShuglu8OcEtjZcRs7Bh71cYuYrwbMv3kv4nroBtZpH0lBCJh9J+bStK9d8Mo9smzN9DuHZ/B3HzD+G7C+f4mgpcNUYS2EMJ6+KUtpX2ZyltaYikylYNkVTaNlHamQWUdjan0wltgtwCdrFZI5bSTvcB22c+81kJTcFaoG0Be5LA2nQBt8S3LbXtUtyh8FOKOwQ2wttvdHWq7mQq26ZU04l4a9k67Dh2HFUGLEbZ7gtx8PhJTFj0Ea6Jp+KWMIeobQVsa0pgt14Mm3S8saDdZjkhvlQdY+8FVL/1uazDahhd+CfQfT1s3dbBTzrcSEOkhEi88rXFt+Pewe+gRvqnqDhmN9YdPYLQqe/zqYDqetBuGEM0tI3hBLfkal9UaUtoxIK2VtpuYOvONS6FLapaoG2q7GKzRiz3KWyf+cxnJTVjMoE8hcCeSjiLu5S2h0+hi8IuSnGr19x+bAASFw/Dwe+/gzNzPCHcmTAeiIixueYnaTPCM2FEzaRLhxyCuukC+BWKbS+h2l4FI34mnu2+Ctnr9sNoOA9Vx27HbR25njROdpXONmaHGxPaVr62X+8tKoPk+s7L9WdyefCE9zF5zwncJZkjor4H79ZK+20T3hdT2p7ZI55KexqVdgaBLbFrgbYo6stV2j6F7TOf+aykZkwicAXYAuWpdIGyp1vQvqjipo8LQOm85jh39mecxXkYvZx4YmQ/tJqxGE+9mYpWU5chYiAVsT0Hh05+i3f3H8cjBKpKBfSIbevONlTTdbLNIzwLVZuk8VKU7qszR/7T01Tarh6SbmhLl3altJutwbdnz2DI6kMw2m9W2w1bewS3vLYNu06e4vrbYFMZJGYWCVV2sUrbM3vEytO2lLbKHDnq6saulLaESDyVtgXsopS2T2H7zGc+K6kpUE8mtFPDtAu0LbV9ScUt8DZdqe0gGANfoHp9DsagSjjw7VfmpwARU6ioG78Nw38Q2k7dqeYdoho36kg+txSHEsW9wN0o2XoZFfZsBI6gGq4/D+2mb8fX//sJ1yabQO8sPSQlDXAt/Lq6oa0aJbuuR2TmB+i9kIq43Sq8umYvMnedwKPD3kGXFYdQazoVtHRxl0wSUdoC7EspbTN7xEtpS5625GhnHIafh9K24tmFskaKUtoK2L6u6T7zmc9KYCok4gnsKYS05QLsEiluT3BLDnc4SkmYZNDL6LZiFHI+exf/eftV1JmoVXPeDirW4DEwHHNgBKWreWJBb1Axq6wSQrvZPMKbcBbVXZ/va+bj4xOiRH/SXeTrEvKSjSKhERUeEWgT1j0kg4SeuADLPv4C8Vkf4omhu7Dl0ElM3fGNAny3+QRtn3d1Fsmg9wso7YtkjxRS2gS3WSzKpbQlDGIpbYG3BewilbYP2D7zmc8uw4yphHUa4ZpG2IqnFnBPtX0RxW0jwMV1bFuc82U6uiKVaxWCMQIvTelrfiqoln+AETkB9UbtpMrORM/UbajUj4o5ZT6CB2/E3a0J5QaEdaOlGDR3h9qmwlsrYEQR1PUWqferPifwGlGNd1lFEK+CresalOq+nIDXjZUrPj2hyrz+cOpn9d7WYR3e3HgEZ/ELjE6bYHtDcrR1l3altEuSPWIqbQG2qvKnXMIjWmlLTFsaIt1Km16s0ub7aV8idf+v6viKMh+wfeYzn7nMmEJgC7QFzmkCX4G0OF/LvBIqbtuEgnnc4nadTTLWH4/nJKHNsmEwutlRZupIGK27Ys5H+82jAFpOfo/gnqHqby/54LCaV/X1ZQQ41XWTBfjlglahRmw+XnlzAx7puhLjFhGUTQl11UOS0O5K77QFLw/bgHv7bMdrc3aj9PD3MHrzQQxa9inKDtuMgauohJsT/K7CUWa+tqW0PbNHLqa0var8uZW2ytGW0qwWsC+ltNMF2D6F7TOf+awE5jc1mLAJgi0tDLZUgnsaoSuuFDdh7Km2xS+puGWeVtsuxT2yIrI+WWZ+IiHU9TkCM4Uwro2tX7qL9z9MRb3ww29Q9zWq5DhpaFxANT0HGSs+xvUNF8MIy4CRtMBcGwgauVmnCUq8u9NqXNtpjeqAU37wJrW8zWzCNnYpvvyfVrBG53cQnf6xft1mne5gQ2gXUtqDLq60VZU/qmy/8RrYup72QZ7Lg7BJF3ZC25ZJSAuYJZZtQruw0uZ76enoA7bPfOazktg1VNPXpNlhSw8joAlYcQG2wFugfTmKW4BtxrZdPSetOiVvv4DAWe1QY0EPGCNeQZ/NOnY9eq1kirSCUeM1ZGz7TM0TO3byWxgOGe1mCiau0vONmjPxUOdlqDZ0HT7+6kcc/fE4ob4cXXOpiBvkw2i/Ev/uuxHZ7x3Bv3uvxDWd12Hbl99gwZ4v0HwmIdxiEX668Atul67ukq9t9YosoLQL5Wl7Km1XPW2CW0IjltJWjZB0yc8WpW3Gs1XGiAC7KKUtgx/4gO0zn/mspGakBeOaDDuuJbCvmeaAX7qDKpEATw0ngAjxK6S4ldIeF6DytY0x1RC1oLd5BMCkDRLKaId7+ozH6DW7zblAcO9l+OKHnzB0/icwyqZTYVupfsDcnQdhVEzHQ93dyv06aaCMXYwfL/yo3hutV+DGdhLv1iO6GPELUHb4Ozj000kq8bXwkzKtHtAWpe1V5a+A0laDIcjINRIeocq2jd2rlLaNSltUtp/VhT1VlLaER6RzjcSxvaHtVto+YPvMZz67DLuW0L2RgL4hPRzXp4bhek6vmxbGR3o7/Ahyb8VNAIvinliV02ANbIGxUtxc5qm4LWCLyhbwe8a2Bd5jpDEyEFVmUV2/9gp2HD9mHhFwW6txBPQwdMj4xJwDfHb8Bxi1stA8W1ICz6t5Axa8j0lbjuCtlZ9g5Jp9KNViBTYe+hIpaTtR9q1NMJqvVuutPfQjItM+wv1vrFfv7++9Rdfalq7sVl1tC9yqaNR2D6VNN5W2GghBwiLWyDVmPW2b9Ih0hUboqYS2AFs1RFJpU20rpV0opu0Dts985rPLsOsyAnBjhgP/SDfBnenA9Rmh8FM9IP1xDZV3KYLaJuCeKso7BH23jMcDuYmwTQyBn0BbhU4cKCWAdiltE9SjXoYx4DHYJofDz4xr69g215UKgGP5RzCuGv41Kdo8Im0PdxuJQQt2Y/LGLzB3x2FMWa0zRcT2fvUdnu+xAvVG6A4xYnuOnoBRIR357+qGzJUfE4Z1crF+3zfq/a8XfoLhWISak9/HJ999DxnVxq8PFbZZV9sFbLrtdaptD6XtlT0iY0SqkWsKKO2JBLa4KO0p5uAHrnQ/3QjpgrYnsKd94csS8ZnPfFYy+0d6EG5Kd+KfmWG4ldObqLCvJZSfntMA/d+dSLXsj1LTwnWMe0oQSuc3Uttt/2ofIVVOq+/RpQl7QnvIswrcKt4tsB74mFpXzBhRhvviPAmLjKFCH0dYi9Iez+3HBKDt6sGE5tN4Jf1VGF0a4OvTluo8h2ELqGj/MwprP7M64pzFp9/8jMB+qyi2fwEu6Lknz5zG5gNfYdSmY7i++Qp8/dMpNf/ChdP4V6+NGLd6r3p/72sbVd62q662uAVsT6VNd41cIzFtcQmLFBwjUpS2FIqSIlGW0lYq26w5osqxFqg5YsWxFbB9CttnPvNZCeyWjEDclunErRlhuCXdgVuzBbblMf7D+ThDEgbM60CoBKFUOgE7qRpBW5nQepyQIoBFSY9+wdyTNmNCFSppgnicP2FcFTdQSXfZNJLrVeD7aoif3x8jtmXCT8AtnWzGByFodgdza8A2LpiQDME1PeviFzP0IZaxaR+O/vATX13AjiMnsOPoF3qBac631mHN++6wSoucd/F4vw3mu/NYcZiqumouZrx3kO/PwGi6whydnQrbVNpq+DGv0Ig5cs3AHbhm0E4CW0IjH8ImwKYrpS3AptIWlV1qHKFNcIvS1t3XCew0XdnPs+aIpbIVuNOO+YDtM5/5rGR2R4Y/3Y47s5y4MyMUtxPet2cQ2pMFsKUJmwDcRPUt6tkyNazYNM5L5XojnsGj2clK5P7464+4UUIko1/BW1smYsj2VK4bRIhJzJtwH/a83oFpxkAq8tH8E+h9F6rmNcKUXYupXKsgapFukBy5eTkeHzEURlI39V5L6XN498AJGDe9ie9+/Z+erewsRqz+1HzttgsXzuH7X35G6NAd2PnNKXzDfdzSZCmMbuvo69UINsq70yWu/TqB3Znw7vEODIll9yW8OxPkA3fT3+W6O2CMJKhlOkyATZXtGRqxqvvJiDVU2u4iUe7QiBUekXraRppPYfvMZz4rod2W7Y97COm7c+y4K5vAzgrDbQT2rZnhVN10Ku5bMkNxfRYV9hR/3J1ZmwCqQgAF42ZCe8+3xzDvAEE36BHCqzRVZTAeyogz967NGPg04V+FACSge92GZhveRkB+G65fDh03T1HrDKeiN/o9RsBXRfCcdmqe2Lx9BGXLWISPzeI7M/ahTNT3OZw+fwEnfpasEHnvBt9LXddi95cnzHfAQ32X4+nX1+L0WYkXX4DRZjUeGUBot1wOo8s6jF69F/e+sUWlBi777CTm7v2ay9ah3owP1fZGn/fQZLaEVLhtC63cbxtNYEuetowPqTrWUGmb3dddoRHlEh6RdD8qbc/8bMkemXbQB2yf+cxnJbO7MgNwH8F8b44T/yKw7+H0bk7vzHTgjnS7VtzpobiF69ySEYIbpvF1enWUoiq/iar5zBldae7e9EiCSfK5ZfzHpxAwtyM2ff85xn8wm+r8vxi0TYAriAXuVpkiBPj4akhY/oaaL1ZvZX+u+zICZrTDfZMjMfGzhXhmYhJ2f231iDyHPos3o1RSBs6fkz0R4BfO4+D3P8GoqsFv2Xn8igPfSgjF0y5g28HvYMTNRueZH6g54zdTCacsQ+4HX6r3t/cntFuvxA/nfkLbRVTEbbfg5TFbcd/I96m+t+mwicS0+3yAa4dTgQ//SIdIZCR2U2krlV2oJ6Sk+RXIzxa1TfU91Temo898dnXbOQUkbRcueCrLK2v/zqmGf0234/7pofgPVba8vic7mIrbQcVtxx3Z4Qra/yTAb6XyvoUK/GZOb0534posOwH1PAH9KIwMQpiAN8ZXxpzPNyN8WVeC7RnCqyLXKY/pn680PxH4/vx5gu5lOhV5v/9wHTuarBsIo/9DOPDjSXMtoFxuK6ryR9B07WBzjjYj7lW8Oec99fqX0zrHWuxskefpAnJ3HcMdbdw9JHd99T3qjtqKcdtP4t1Dx3Bd+40YsXE/qk0giJuvwc84g4zNVMTN16LKFJ2dctdbu3HbAF1l0Oj/ji4UNUTnZmtg00d794QsmJ+te0Lq/GyJZ6vR16ccQ9o+z9COt/mA7TOf+cxlD2T74/5sBx6c7sSDWaH493QH/p0dgnuzw+gOF7jvzAyn4nbg9owI3D4tTDVS/iPDiRszw3ADp5K7fY3kaU+oYu6ZsBlKYKuMEYL8rYdQb+mrGLJtGv6bmwRj0H9x6hfdwSV+cV8Yw14h2AMQttCKV2v7b1p9DNg5A7+cOY2tJ/Yhe9d2fPOrLuZ0+pxulCzdfiH+d1pUqhvelp09557385mfuMZZvP+lVtNiLXMJ15TF5jvg5r4b8MCbuu72RFHfLdYiJvNDNFhIGL9GRd2eCn/wDg3soqr7efWEpNIuGBoRlS3QJrBtWVTbU77wAdtnPrtq7fw5nD59Gs3bdkGlQAfsEXVQvmoIho0ca65wZe2BHH88kOfAAwT2AzmhWmnTvRR3TjA9lMrbUtwOl+KWBsmbCPIb+PpazitFkBsjnibInoR0uvEjsG/LqIFd336OynM6EMplVZzbGFywAfJBgq4SoVcR104IweD3MvBEaqy5VNuBk9/AaPMAMt9ba84RO4M5u77EYpUh4s4quZjd3HQxlu4/wscYrcjLjNiM1tP38M/gGALHbcPAlQcQmP4+FfYqPDJkq9qrFJUy3niXin+HWXNkJ/zoBXtC+o10p/oVys+myvYeE5LATj1AYPvysH3ms6vWnDXrIL5+E9SJSUJIWG3Yq0ehXSdv5Xml7LGcQDxEWD+eVx2PTQ/HIzlOPJwdSsUdRsVNtU1w35cVgnv4XtS2S3FnheFOaZyUhsl0J25JF6VNcE8Lxw2p4SiVGYFS6eEElaTuBeDzU18i7/N1hBmBLdklEirpeyearx6MgLltCPnnsfNLnSctZgyrQAX7GJqtfFvPMKMdcz5YipWHdQEnb6N29lDTxdnP5624to4bT3tvPyZu2KdeH/n2FIzYVWg0Z5d6n5xLxdx+I5rO/AyhaTIeJJX1W5LyJzVHZGxISfWjyvboCWkbUSA/WxogrfzsyVTZXvnZ9LSDPmD7zGdXqx0+cgSOiGhE1k3GuvXr1Lxvjh/H8KGj1esrbY/nBuCR/CA8PiMUj+WF4JEZDjycZ1eK+34q7Ps5/Y+ESai0/01w/4sAF8V9V5YTd2fY8c/s6qrTjcS2b8mQjjcOXJdlx7WE9zXpIfDjPBXbHvMKjHHlCSsCfHIVvPVuLg7++CXnVybQA1V2SI1l/cyjAkZ9mI/KMztg4eGt+PXsWew79RUO/3gc275yF4gSKzNiDOInzzbfXdpOnf4Vr5sNjrhwAf878xOMgOn46LCOnY9dT6DWmwtbh1X4Z18CWgb37UXvS3UtKX/SC7JAzREVGinQE1L3gvwUpcborJGCY0JKvRGV5jeJCvvzX9RnF2U+YPvMZ39j++bEN6heqx5q1InH119/bc794+zp3CA8kWvHU3lOPJkbiieopB+nin4sJwyPUm0/wunDhPP9hPZ/qLzv4/Q+Kuy7JURCiAu478oMVbHt2zxi2zdkOnGjwJvzrpOu7VTeakQb6Rk5NRivzG2C73/5iX8KcQQ4FfekKngxOw43jAvBgPemUc0+bB4huXr2An76+VfC8z48NCHSnOu29/gndznWNW07cO4XnPMKoZzFhHcPwUiah6kbZH9nYTRfws/crPO0+71DF2AX6AkpNUcGmzVHPHpC2iRrxIpnFzVSjShtUdmE+NS9OiZflPmA7TNl588XH++72DKxC+f/uKyF32oXPeY/4XDPn7/043hJrHGrDohPaYyUxi1QIzoB3Xr2QY9efdC4ZXscOXbUXOvK2dO5/ngiPwTP5IfiaarsJ2fY8WReYcWtGiUJaVHb91F5C7j/bYLbnU3ijm3fKo2RWQ5Vp0TUtsS2/SSTRAZLmFCWTmU9ujThFQJj2NPm0WiT+tnGyBew8MA76v0F87ed+eFy7Ph2L86o3/Mcjn77Jb77sXh1WrR5XydNMz/EpM2fm++AiLEEc/JitEnfCb9ea/CP3hvx9BDO67wFtv4boAY+kHojUkN74A74mUrbZiltyRpR9bM/Vu43+jPYZNADyRqZsE9DW4BNlS1ZI8ZEKmwfsH1WEvvx1CksX7kK6zduUr52w0Zs36bTpSz74KOPsY7z12/gOps2YSXX//Gn4lu1/0r76MM9WLOex2p+Hzne+fMW4sTJ78w1/lhbvnQZP3ez6/PXrLe6RpfcXixfFbGJjRCT2BB1E+ojKr4RasWmoFpwGPYd0LHWK2nPTw8kqEPw3IwwuoPgduBpAro4xf0gpw8QxBIquZ+K+16+98omyQrDHQT07ZK3LaESKmyB9vV8L4WiHsypjXl7t6DGwh6EdiUqTUJ8TFnMPqAr6YmN3ZlDmFdF0+X9zTnath0/pKZnJDuE/4/zP10HI9YoYVOjto4zP0SdwVvMd2K/ouGEdznV/+onzuhOLFuPnCK4l+Ga7vq46mVRSfckuHvRX6NLDW3pCWkpbVHZ4lLRT1x6Q44SpW3GslVVP4lnm/nZEhqRQXwn7sPUz34XsAt//eLUi2euqM+uPtt/4AAqBThRJyYRtesmoHqdWLRq28Vcqm3w2yPgqBWrlst6Fas51XZ/F7OuwU8/3YcKVYNd30WmQY6a6EKF+mfZc2UqIzI2CbVjElAzKp4KOdFcUnIbOXoCMrNzkZll+XQ1nTh5Co5/e+X/eP47IwClqaZfnBWKF2aG4NmZDvw33+5W3PkEd14oHqXafiw3BA8S6g9y+h8q6/skk0QaJbPdse27s8JxD1W29I5UeduitPn+xnSCOa0aum8YZ34y8Oj0WAI7GMbQ52H0uA7h89pgqMB66HN451t3N/M9xw/D6HQt/1zqqffnCvKIb88R4q4HqQvFd0QR23FEg//chfNU6+51931zEsbL6fj1tN7TnA++xhMDt+PR/utRdigB3XElpm48gJt6v0to67KstjcJa1VzRFL9OB0swKbSHqaVts3MGlHjQU7Yq1S2leqn8rPH7UXap78jre/bb79F9ci6KFcpCI2bt8NpM+fx0KGDcNaKQvmKAWjTrrua57Or2w4fPozw2rGo36QlH8FbIqF+U3Tv6R4oVWz02Imol9xULZf1wmvG4tDhK/9o/nvs5InjqOhvR2Kz9qjfuIU61rrx9dG5u4b1hSsUrriUVQ0JR4OmrdTnJzVshoSGzc0lf197cUYgyhDIrxDML3P6wkwnnieUn5vhpIfimbwwPE01/WSuuB2P8fVjVNMqtk2F/QDV9QNZHrFtiWsT4Cpvm8C+zVTat6ZLDDuAgHoOzVcNxrDtaQRZearPQPNIgAmfLCH0HoUxvhJSP5in5p0/r/+QW60ZhFYbx+KXn34tpCkVX81OM0bwk9h89GKxf72x3u9pGJUnYslH7vXbUIG3znkXM3Z+g7b50i1df358zocwGq3Eu0d1uVbptq5qjrwqqX5mA6TkZ4vKHiqhEcnPtrJGPtaNkON1aMQwY9k2UdrjPv9twLaUSgX/UF5szVGfF15ccmM0btlGzX+FALfm101owBv7NTXfZ1evKWBTPXsBu0dhYMcmN+HyFmq9sBoC7Mtr5PkjzHrqO/HNCVQLcfLYBJQC6xb8Hk3QqEUrtfzPtKohYeZx/D5gz50/H+kZOcii0hYfO34yeUQF+Qf0eCw9Kwhl8x14aXYIXsoPRmkq7NIzQ/E8wS3Afpav/5sfotT2U1TZTxDmTxTIJpH8bSu2/W++vjfTI287Kwz/zHRSXb6IxuveQr1VfXXPyCmEd7odD+VaqtkE49I3CPHSqqNNn12Zap5YzIoB5itth7//Dka/f6nXp818ak87c+60Utwnv/8BZ03oihm18jB50fvmO2Dnka/Raa6Emk7jxKmfMW2He2Dgf3RcjvBJ7vCJ0XMz/tN/I8LGEsqtVuMg9504kwq6J8H9+nZcM9gcYuztD+BnVvZTudlW1giVtsrNnvQ5/CSeLWERzk/75Dcq7PPnzqq8zwbqBm6h1ELVQCc+/fhT1IiM43t9Yyc3ao7omGRzK59drXY1A1vsAq/XMD711WtI9W/CWkRF9ah4c3nxRXX+CLtSwO7QqTtq1UtCNIVR3cSGqBDgMJdceSs7sxoq5NtRnoAux2lZKu0yhHPpmWEoTZUtivsFpbgdeJYKXNT2U9ND8URuwdg2wU3FLZkk/7HytrnuvRl2PvqXw/iP5pqfCPxAcWiMfQHXpIURYs+hxdoh5hIoJZ645i3zHeCc1QZGn5upTKuac9xmDCuLGvO7mu887PwFnLtwFr/+7xSMJ9oS3t4hkjP887Ps82/dOdCZmwjVatPx9Y9WrvZ5GA3WYPyGj5D30ZeoNlbnZ3/90/cwmq1CYq5uU3hl3Hsw3qC67rSRwN5FlS2ZIzrVr1DWiMrNltCIqbTHfPbbgG39e1eoZkdS0w5oSFgnNmiGmIT6an75aiFo0LgDUpo0R3xKUzRp6a6o5bOr065GYHu2m0TUqquf+kxYJzdqAUdEbXPpn29XCtjd+BvIbyH7kXMeEv7Hfadyc/xRcVYwKsxxovzsUJSdFYYyhPQrVNwvzwx2xbYF3KK4/5tP5/QJlU0SjEepslVsOy8MD1JlW3nbEt+WLu53Eer/SK+KtuuHm5+o7fo0qf5XBn23TkXKil4wel9PwD1GiL2MnI9113CBrtiDOcmE80N4aFqMem9Z3mfuHo/Dds1D9dntcfTHE1IPqgg7h7WffY1j38go7efIO9n3GRgPjMSUDe4sEVur5Wg97V30XPgB+qw+gHFbdd3txXuOwqg5G5sPfqvep23h+96r8ah0oukoo7TrrvFGD8J70Falsm3DCG6JZQuwpaLfGDNrRHpBSu1sKRA1ggr7t4RErEfMdes2omylAITXjkHFACdOntAlCjOn56NclUCE1oiCPSIS33//PecWeWZ8dpXY1QhsS1jUiaqH+AYa1HLs4sFhdcwGqb/murxSwJbf4M8CduVZgahCZV15Tihf21Fxth0VCOpyMx1U23a8nO/Ay4SypbifJ5hfyHW6skncse0IpbYfFld52/QsydUOw81ZAVSWjyFxWT8sOPoOIT0BxshH8PFxd/jh+A8/wBhVGkZaBKSetmcq5k2TQzHjU53il/P5JoTMaYNrxjkRv9K7QdnofitGbM0z3xW089iyj5C9caB6p6F+Hid/PU3I/4QfT32L/jM/witvu4cdM+rOxHUEuGXPDNyMykO3IGX6XjzSX0Il+jqTUMkzI3WYZfuRL2D0orrutYUq22qA5JTQ9swaUal+kjEy4hMq7IJVBd12yUZHyz7f692jyLID+698apHP/hq7moDtqaybNGuNOI9jkhCdvz0c33/356TvFWdXI7Arzq6CanPtqEKvPCcYleY4UInQLjfbgfIEeJlZ4SiTH4YXZwq0JbZtp9IOcmWTSGz7ackg4VTyth/Nc+DR3FAV176P0xtTyyF+eR8M2DENVRamENQPwS9NRpsph7WHdfW7s2e0kq44txVh/SzuyI2G0f8efmYSbp9ch+D7t1p+xux6nvfZKhjDy1CRP45+W3PUvM++OoaMvW7Yit59aGQ0fvr1nGQAethZ9V9wxlTvp09LSES/Xv35cRhVM7DkfRmVBnh1PoHaeBnu7LgaA+bthpGyRM0XM9qsxJNv6/j27m++UV3Ynxv7AZzpH2DkGp1FdccAwlrys1Wqn45nW6ERlTUixaF+L7BFwVyqceOPaPzw2Z9vV6PC7tLtVUTFN1THI8csYZCqweE4cuSvz1y5GoHtP9sfQbNDEUCF7U9AV5vrRDXCutLsEFSSUMmsUJSfGeKKbb88QxS3ziZRsW0qbYltP0X1/RQB/SgV+CPTCW0q7X9nBaHMPO+2rnore+PmtKq4TTrRjH0R277Q9UP+9/MZwvwJTPvQXQb1qelNYUypQriH4MX8xuZcAvL7A4T44+izZRo6bByuBkUw3rgfcz/3zK8Gkpa8BqPvSwWATV2s5PUFDF1KkFZKV68tixr7DgYs+QwP9lwLI2kWus76SM2vOvZ9NdjBy8O3qfcT1x2B0YJ/HJ1W4M43tqHTIp2GGDCZkO7GdS6cgfxVGD138Pi261KsEh6R0Aih7coaGf4Rpn6sqxYWZRcNiRQE8ceffIK169Zj3YYN2PX++zj1k/ufQNa9aO8y2uf7D2LNunXYsHGjcnkt84qyJUuXYcOmTXpd6aCxajU+/WwvHzo8jumCW2Vd2tzHdvSLY3jnnXfVfletWaPee1pJ8snPnfduuPjy66+wfv16ZOfMUHmy03Nzeeyb8FWB7sRynkqy/7/C/ipgS/frLZ6/R4EefMWdr+69eiMyNhn1eawaZq0UJPd8om+WS12PRdm5Ag2Tn3z6KVatXoN1/G137d6NHz2veY9sg6LsagR24NxqCJpjR8B8O/znBdMdhHYIqsxxojJBXnG2ExUlPOKKbdtVbPsFM7atgc1pnpNKOwiPTafq5utHcx14ODsED2SFmJ+kbfnBd2GkPY97Mmug07tDYYx7Ccbbd1N1Pgdjcnlkf6brZv9iUtYY9hQMGQB4XGnV8Nhp3Ri+rqpGsbFs8ZF3qFTLcd5zOE1FzQtBzZ/w4SI1Fdt8dD/u6zkAX54iHD040jLrY6z54DB+Ovs/fP3TGcxZ71GAqukiVVdk6/5jOPrD9zCaLIfRYR0MKm6j22p0maejEPf03wSj1Soc/0GnQButCfK2m/D0OMK682o174GRhPZwQl/1gnRnjRjDPkbq71HYM2cvQDRvCv/g6qheOw61o5OU16gdjxBnHdSOjMP0GXPMtS9uk6amwhFR17UPeS3zirIXXqmGOnWT9bpRSep1RM1YBDqqIyquPmbNdLcyl8SOffUlXu3zOvx5E4XXjFK1GepEJ6v9htWIQdUgJ7r3eQNffVFyZbZqxUq069ITVQJDFbgi66YgKiGZii8FsfGN1XGH8bMks6Z9565YyvX/zvZnAvvYl1+i3xuDeF2Fq3Pk+XuEc5+VqgXz3PbCgX3uG8bTxk6cjOpR9VzHKh5ZLxkbN+vY5u+x9WvWol5yYx5bGK+5euqYpPiSvuZrIqJ2DM/DBHPt4u1qBHbIHH/YCWf7XAdfhyJ4bhgBLoo7DAGEdVUCuiqVd4UCsW0rb1vi2i9SaT8+IwgPZwbBvigON057Do/lhSto355VhfBPwYff7cWWb/bgzkx/lJpU1vx0bRXmNMONaXY1CLAx/mXs/lpfA+mfEZATK9CrYML22XggM5KvK8E2SdIEq6Dm4lfVehtPEnxvPYrsvStx8IevcfDbLzBs1wLC8BW13GqEtL3eDWMXbNVvXOYWhNcnz6SqdrNtzCKqYRn/MZn7qjubkF6DUt1XoRSnRnd6s1X4+KsTWH+AMO9MkLdei+fHEcrNdKNpYOonMHrvxmvrpKPOrzD67eZx6swRq0ONMfRDKuzLALY1xI/chIF2gWOKignKhaJuDtP1e90SL+vYq9eiOtF/g8Upm8ysPMQm8vHV3Ie8lnlFmX9odd3pwFzXuljlBlBphIS2v6MGvvzSGure20SVWU8Iffu9icDQGuqit76H67t47FeWVw5yYFr2dLXd+WLSwD78+BME86apGR2PxAayz1Z0d2OXdr53fRb3zfVqxyTCWSMKn3+uG1fOnfOse3ABx7/+Bm8MfBujCIORYyZg2IjRWLDU3cjhab37veFaT6Z9+3vnpVqWmZ2DESPHqPUEMn3fHMRnjaKV4R8J7KJ+j/iUJub50V7w95CsJAlvTJ4mj6nev0dUfANCsLl5rt3bSY9CSUWtQtjWjknG6NFj8dVXkgkgVrziPndW77tZ284IrxOLZO5b/67e+5d58t2lu7gc24LFS9V2RVlJgT1q7BSMGD3O9Vv2e0Mawi640PGnAnuuPxwLg+CYH4TQeYEIWhCC4HkhpuIOotoORTUq8Ipese1QvEKovzIrBC/ODMWLBPijOZXNPQIrDm3Av9LL4pbUsngk247rpzwPY8pTuH7SSyp75JrJL6n1zppfeM2XVKITZRT2Kng+P5mK+y4q5kdhTCqDa6Ro1KRKekWaMeQJKnQpFhUIY+SLMAbeTzBTpXsobrFKeS2V6n54eoo5h38Au93d38UebDYT096RePMFyQSknYMRkAojZjZey9uG5/uvQdMcXcq181zCu/Vy2KiYbd3XwiYD+PbcAKMN1XQbKu6+m2F7TUZf36o8KG0Pjp/+juvwff9tnMfv+NY2TNp5GKXHE9bSoWYsp2/vQdrlAFvs0IF9VI0OJDRt5+opZt1MciFrgPNiNpfJI2m9hi0Q5Kxu7qFok1BBTGIDvT+6vJZ5RZkUa5cbVi5U6fggF7y1nYKh+VrU7YEDumupp1nRHGmQioxrqC50a1s5dvkO8l2898dljdoTqpGYNatoBb9q7XpUkRvRtZ3eh9on37uOmYCWPzPPG17WT+Q5rcRjXr3Ss+i6tkMHDiIgLBKxSU0QQ68Vk4Lho4suo1mumoPgbKrWq5fSDOUqBJlLvK19l+6oW6+h2qf0UKwSEGYuKWx/hsK+3N+jQaN2CK1eG3Nm655ulgn8vK8J7bJfz33XoygIcdREu86Xrh/dom0n1SNSQ9a8trkv+V3l+PSx6v2q35ZTe/VIjJ0wydyDt5UU2HXrpaBuYmP1W8pvWinI+z76M4EdPjcA4YR0+Fw7wuYGwTnfAQeBLYrbTigHUX0HEdSese3Ks6i0ZzlRnmpbwiRlqLDvySht7hHY+dWHMFIfwqwDy8w5QO0FbXFvTlU8MD0Yd+QEIHiO+9w45nfAdelV8cLMBuYcgmrMc7g+IwzXpUr6XyAez01CwIIOBLU/4V4NNZf2woKD7+GG8cG6e/uo8sj7TIcfxJYckPoejyJwJsH9+sMoNS4EL01rYS4VO48hiz8ioNNwQsIkpnUdpePgkWO2UFkvVIr7rJnHbUTlw2hHSCfM0iOu96CqlpHWpZpfn02ENl0q+vU3u653fkfXG5GBDoZwOvBDVM6RP4jzXJdKXIYUo8JO+/gy0vrOnT2LKv4hrotWpkmNmqFmnWQ4q9dBAi/Uerx4gkLDEduAFxDXURcSPTapEQYNGWnuqbBdDrCT6jdT3aK79eiDnq/2R8NmbRAaUQe1qWoTGrdVx6ZuBN5I1UJ4gStCW5pE29DhY9RjsvV54vH1WyA4xKm+g3wXJ2+4qNhG5o2ob0b5znKzedt5nPj2O1SsFurqbizrJjZsg9qxiTwf1dWxtWrTWR135669ER2ThGq8+aIIXgG5dU5l+2ohDnx9XHdrtUwDM8Y8Fp5nnk9RXEWZvz3CtV6DIo9XW/cevRHfwA2bkLBa5pLC9kcDe+Dg4eppzPotZB8JjXhM6vcQoLXg/iJRpy7VM6851/fj+ZK6IJ6WyN/OJRyKdL2tfI68lnMpaX5neX3DzAjwtI2bNsFZK9Jru0RCVnK7I/k7xvP3q8knpLAavAeatPbYdysKlVr49FN3rQvLSgps9eeu/qzM36gAkP9MYDsXBKEWIV19YQgiCG7nIjscC4IRuiAU9vnBCOY0aH6IV2y7yuxQVKDiLjc7GBXya+DZ3Cp4Iq88bkp7ETErU3BT6ou4Zeoz+gNMJfXjmR9xzcSn8Wiek1Oq6TH/hjH8ARjjHsPNWVVwRxZV8+TyhP2n+Pz7Y1SfpXG9jNaeEQE/6Sk5leCeSlUt9bTHlMbRU+6MIOPt0gR5NUL0H+i8biS++N+3eD63IZ7NcP8BXDPWTng+ibl7N5pzgIV73DVx3j3wA4y4WQgY6Ib+Ta1XwkiZDSN8DhqkEe715uPo/wjXCwRuw0VU2RthE5Xdm9NXN8GvN4FNUNteM0uwvvmerjUyaAf8Bu4itAnugZLyR7U98iP4icoe+D6mfnTK/MTCVgjYbTt04Q3ZTF0c+kJrrka42LylcGxQwgACIs8bwz8w3Fxa2C4H2MXZ1q3b1TBJ+sbSN0xsUkP07v+muYa2n3/9FRWp0q0bRv5QRD116tLTXMNtS5YsUyEOa5/yfWLimiIjM9tcQ1vX7r3VzWUdv9yEkdEJWFxM2MIyKTwvj+fWTSf7j0tsitf6eR9zQWBeHNjV3d+N05IBuxXsfxGwT373PaoEh7v2LdtLSKxV247mGm5btWoNnDWlE4x1HerfIy09w1xDYFgdVYLC4B8SUcgDHDUQxu3jpCyp+jx9fUoIJjZRd/wqaK2orusl6/Mk6yY1bIoaUYk4cMidGyy2f/8B1K4bp4SC9XQlbo8ofF5LDGyeZyu8I+fnrwR2jQX+iJyvoV2LyjpiYSgi5lNt871zHuFNQIcS0MFU2O7YtgOVFbideCjrWfR45y1M2JVB1VwLT2RXQ5lZDjyZbUfk8ibmp5AzG9/CfVlVceO00tj5pR5AwLG0E+7JCsK92aGq8p8M9mtMfIXwfRn/zAjHTRnS6SYC16eH6dFrpPExLZSK2o6HUiOUXDv2wzdUqU+hzhJ93WbtXUzFeyeM8QT0sGdhDiyDCe/mEJj/Rb+tuYT2NgzcvhYPddCFqHTWCJ98RlEph+SgbJ8V+OXcr7C1WIQOeRIS+RF+TRbAaLMUZV/Xg0q8vmgvjA4EuoRDelFtU2nbRGn3paqWwQ76m9CWqn4Dt8E2gLB+eydsgwlsGZ3G7AFpDNyJ1I9LCOyfT58xQaAvQpkKrA8cKhxysCzISaXXuA3X54XO9WvWScDOXe6++Z52JYAtduTwQVV5zdqP1DOpXM0bWIOGj0a8+uMhWOixVNaNW7Y2lxa28eMnITbO/ecjNYilFrGnSSch6zPlBpM46uVYdKy0B+j9y+fUjk0yl2j7vwzswSPcv4d4Ap/OGvBcFGdjx45HvUQLoC0UIBs2L3lv2uMnT2DQ28MRxj/3RPOJTI63Vt0UZE+fYa4FV1y9cqBTPano89kSoeHR+NJjcNaCFhYRxWMy98ttqkfHUaXrx2fLrkZg11xYFXWosusstqPOomDUXOBADQH2AjuBHQIHlbfEt0Vlq9g23X9uEJW2A6/MqIZ+73mPaP7cTGmIDMG/s0pTST9MAN8Fv3FP4L7sSng6Nxg3ZVXE7P0r1Lppexfi5vSKajQbgfbd06XaH8Gd5cTthPXNmXbXCDY3pIbhmnQ7rkurTmgHUYGXI5AfgzHqBXppHPje/fSa/xkBOro8FTvhPuQZtF43moCsiuSlb5hr8Olv/RwYrdogYKz72pi29Sg6Td6MOXu+guGfSRU9Hw2mSOlVCpCff4GRSLWduBTXtF2Bm3osgdFiGeZ/dBL/6inhkQ3wo8q2UW2r0Iipsm0yQg1Vtp8qwepRN1uNTkNgD/iAwPZ+8vY0L2DPnD1bqVC5MMRFTbbrWHTsz2pYHJ86japFF1gXj41vhMxsb2Vq2ZUAtnWD9ej7FuKSG7n2JWGHOXPccWd7RE3Ub+T+Iwnn4+6JE3rYn+LSxIIdFgTlMbw1/xS84SaNnHLDyOdJY2On7hpmUsqxJCahHevGS+KTSXgdXejGsv/LwPa3O11/7Gq7OpHYd0CndBb3e4Q45Xy7ISqFyC5lOh1VXunrZNbc+agZG6+gKn/c8kdRJ8p7MNevjh1FmCsUpf+MExu61aCnWdd97oxZiExwh9tieS0OHurd3fpqBHadhf6oOz8Y0VTWUfNDNbznByCC4K4uinsBFfdcgbYDoXz/Uu4reCX3ZfhTaZcnsAfuGGbuSVvNBbG4N/1FbDisQdd2WR88MqMinsp34qk8qf7nxC1TXsbDM0Jx3ZQX8HB2uOrK/p8ca0AEB26XwRBkuLEsGQwhTCltGSvyGipsW1oI7s6MRPbe9XhmZiP+IfiruHb1BT3U51lmvP0EbhlfEw9nxvP1M4R3AOHtnZ1iNAxE2+xFGLqainveh7iv1UKs2afhKVnURvV0GDFzMWDxPuw5fgJGnTxkbt2LebsJ9OSlBP4iTNp4DFLTxmixAjYZSkyAraBtqWz6GxIekdCIFIcisKXWiFT0kw41lwPstwaNUBX5rItQ4o3LVuh/v+JsOZdHxmjIyw0RndAI4ycXnap3pRS22JKlSxBdT/al/yhikpti3ISp5lJR/rVcN6B4OB+RL2U1YxLM/ekbQ1S8mPkfgSbNW6m4piyXG0wyHZSVMB9c/yHI8RAcDVuidRvvcMD/TWCfw+lff/UKY4nL08qlzF4j0rW+bGsPr4MLZhW3y7EahLE0HFr7CeZ+fvjB/di5as061IlNdH2W3APDR7nrNBdl333/PcKquyGvQoNNvJ/grkZgRy2qgpjFIYheQmAvDkbkolC6ncrbqdR29YXBOrZNaPvProJtX2/D+sMb8FxOWQQQ4s9kPo/xu9Pw0YmDeItq++HsCrh5ymPm3gm+sz/j5mnP4oV8rjtTBkYIxVNU2o/nhOLxXKcqHKVHa3fgXirt/xDaUlf7Tk7/6am0pQEyk4qZgB79/jRz7wTaOBmFnYp74H2oMKMJ1n25B1FLexPOj+O7X/Rv3n3DRBhjqkLGjrw3NQo/nzmLr349if8MddcrT1tLxRuajdsbzjTnSAx7OcE8D9c0pbKuMxdGg0VYvVf34Zi/6wiM5itgNFqgc7PNrBFbb4llb6bC3gxbP3ECm+AuZY1Qo2LZu9zV/Ajy1D0lDIlIQ5l1YYjXqpuAd7Z6jzhS0KRzSJ3oJHMbgjOpCUaNmWgu9bYrCezde/ao8IsVo4xLaY6OXfS/6r7PP1epWZ43U6v2RVTxKmDSEKmzAYq+MTJ4rFJK1oKVjAAyupjvWtAkHl43ToNOPDKhIfLyvQcL/b+qsA/s2+dVZ1sa2KTR8FKW2EivW9zvUVIbNmKclxCpFZOIDevdjU3SYUcGOLCWS5vIpClp5tLiLcTh/hOS68ZR4E/oagR2LBV2PAEdt8iBOKrsGII6hqCOJKhFbavYNmEdsKAyZn46y9yKYmZNfZTNrYKXZlbGvWn/wtM5z+Jlqfw3246XZvBPYFFLbDm5Ffa5cXwfiBepsJ8ntJ+kS5nWp/LC8VhemKo/IiVaH84K00qbLmNF3ktY35klw46F4eZsB/5JhX0TFfZ1EiKZ4s6QEmBfP8mBfae+RtaBZVSvD8MYS9U9rgp6b5psrsX1Bv+XSjwMxltP0B8nPCUVsIxeaD4wX9c8D0biPBj2dNQYuoGvZ8BI0T0vgwdL3vUSXNd0sXovZtTMw6RV+3FDZ35uF0K7B6H9qhXLJrTF+1Fp021qhJoCsWyp5vfmjpIDu2uPPl7Alov4Uh0RpHXdE9hyM8tNXZRdSWAfOXKMsHBnVAiUuvP4xQoCQlRxswLx6KLsYjeOpbIDgiJUZogFwCBHuBrkQazoR/tz+IUKs1pIhNefQbXACHO52/6vAvvgoUNev4ec46Qmlwb2pUBWUhszfpI6l7IfcbmuZbgwywoCW67LrOziiga5ze60skrEJfPHu8H9agR2vSXVEL/YjvhlwYhbEoTYpSFU3IGI5LzIhTq2XWtRMKrPD4QjPwSrD65A7qfZVNZPo9u77oFMyudXRKVZkkXiQIW5dpTOD8JjWRUJ6gC8nB9MsIfiOS5Xw5AppU1oywDAhLXUH3lEikVN10pbYtr3ZQXjnuxg3JEVQqUdqsaIvDnTiRsIbJso7REE8LBHqLgDMGaHOyS794eTMEY/D78pXGfYi3DMb4sH06MJ8GCCXOdzV8htz9cyUnsg7hsdreaJGbHusq5PdVpI9byIqnohgt5cjaC3Cd6WhHkzwrlqBh7qvRRGkjsaIfFsW7e1uKbrJiptiWXrND9b362w9ZcxIIuIZcugva9vQ+qHUkivaPMCdt9+g8wBP/VFKJ1TFix0d+csyuRil96IepuLA1tugsLAvvSNUZQJJAQW+obxBvaZ06cRGiE3k75ZZLkMd3Upu9iNY410MS09C5FxVuyyBRIatybkLv54L1kFOq2P++V2EmpKn1Y4zv9XA/vIHwLsC+oPzVkz2rVfmUpWzqXsSgF72IixXgpb4LzWY3zFooB9KSHx1fHjHiERPjXxzziufjNzqbarEdiJi/yRsigUSUtDkUg4Jwi8F4UglvNiOI1e6EDUfDvC5wUieF4lVM5/BVVnVUDA/EoYss1dx7rJiiYoPydA9Y6sIp1r5oWgwiwHXuFr6WBTZoZTFY8qTaUt3dmfEpcSrbnheJjLHs8Ow8Om0hZo35cTirtyQnBvhjRChuHO9Aj8k9C+hVNj1JMwRhLYfG9MkRKv3m1DxkAun+iPZ6YnUcU+DzUquzRAmj0f5c42Br3IZWVQaWYbGB1Kw+jVlcDup5ZbZtjTYDQkpEV1N1msFHbFt3SWiFFf3s9Hu7w96n2Dae/BaLeC+1pOta1T/Yw+G2HrIwrbHcvWaX7iEsumK2CXUGGPmzTZS4nIRdKpSy9zadFWMCRyMWBPTctUqVzW/uV16rRMc+nlmQJ2zYLA7m0uhRoiysrIkHUkf/awOfx9cY1cJQVEdFyiWlffjIQ2Xyc30I1U0igqbvWcq9+0jQsWEuOPa9QKEbU14E3R7rKSANtq9Kp2CWBb37HLq/2QkCKA1etdDNgHjxzlsRUAdhFDhF0OsK1G4kr+oV6/hzQCHzQ7PP3e3+NSJvnwrs+m14iKw4cf6BtL7HKAbZ3/rJxcRCdYOeW6TaJNu05qmWVXJbCXVkHK0kB6CFKosBOWhSJhCVU2PdaMbddZGIh6SyMw45NMOObqBsnwBYRv7rPo9V5P9HinK5V0WYRI78jZIYS2XUN7bjDKE9rlZkYoaL9Cpf2KKhxlx3O5dBnsVxWNslNpO/AwpzI6+31c5z8y7Fi2XdXTvic7FLfx/S0EtzFe95IUM8ZVxnVpTs4rjbAF+rfI+IzQHPwoNnwhw3sBr2/JILwrENhcT6A9ojyMCVTXY/yRvMxdnvW6/nEE7Ov4d0d3W4ZRJxMV+29Am0wq4cgclGpDdR2fh1V7v0A5gttoRzjHL8a/eq6G0WYFmmXpdMWnBxDWPTfCr4+ERURpW7FsE9hvuWPZRr9dSP3A6plb2LyAvWv3B6ge6a7PIFN7jWjs+fgTc43CphR2FBWn2kYa/wjsMUWrwp69CY/6Gh7ikfWSsHxF4R5/JbGiFbYb2M3bdVWZHPqzWqhRSKQzxsUsvkSAOI9ffvmFCreGa13rezdprodPs6x9p66I9si6kZu3fNUg/GQWECoIqqKB7f3nZwEw0FHTtZ6ko1UMsKv5Bc0pDW4uUAqwdUNqUbZk2TL+Gbk7tggkOnfR9Rksu1xgW4Br0a6L1+8Rzz+uuOSGallxVrLf4+K2jtdnzWj5Tu5zUDHAyjbR5/+yFfaF83CE1UFiozbqT1j9/gmNMTnV3fgldlUCe7EAOwj1CepkQrv+EodS3Il8rxV3GCrkPGKuDcz5NBf2uRVQfb5O/wuaHYTgWQFwznXCMTsUAZz6E9gBKk9bK22BtqW0pQaJFI56TmLaUk87PwxPE9pP5DrxUJ4Dj00Pw0MqPCKhkVDckysj13CaEYbbMqsTzmbcmfbq9vGE78u4e1od3JBOIL/5b0K5IkFeDV22uO8jYxAV9xQBtgO2qU7YJoYQ2CF4Jtvd6LhwP0HaLRlGpzeprAfBiJ6hOtL0nb5dLW+WTjVcfwFsrRdxupCAJqxbLELX/N14Y+XnuuZIc1224MiPp2C0Wqm7rr9KYEsvSAG2xLMlN/utbbAN3Mk/Fnr/95G6pyTAtkAQHIHkxu3URSgXiMBA4DBixGicLKK+8M5du1E9mpDnurJNrFy4GYUf9yW9qgYfiy2wy4UcVjtGdYP/LfbDDz8grJbV6FMY2PMXLFI95qzvodQtlWZ8QkO8u1WXRCxo9QkU3SFC3xjBF1GjP//8P9SIjlXratf7j6qboDpXJDXSN77nclGv357UA0AUZadOfeuVXibAnpLq7ixi2aAhI1SvUmvfEhtPTCkcE5Y85BjVSKrXk/1KT8JTpwp3ff3iiy9U6MaCu7g8GQwd6d01/vJDItpmz1tAKLrLoKbwcyRtNKpuIjZt0SlfBe1yfo+CdvLb7zBx0lQEOt1/bNZ3GjBslLmWtvd37lINkdY6MXzymznLu0HYsrkLF8EufQDUPs1ri6/liUd6wnra1QjspGXV0GhxEBouDUbDZcEEtwN1l1ZAcPZ/ETb/ZcQtkc4zL2LL4XX46cyPiJ9TGzWWBLqySHS+djDsnIbMD0bo3FCEzileaZfN1yPZvEJYP0/F/UJuKJ6RmtqEtIRIpGDUowT0w1TUMiK7DIIgo7LfLXnaWUG4MT0Yj0yPw5idWTCmViTc3aPQdNw8hgCvBL9phPPwF9Fg1VsImdmBoCagVVjEw6WA1JDSGL09S2279tD7hKk7s+xfrQjs5Dkwaubj259/weI9hHL8fPi1WKI60NjoRutleLG/jmNLnRGj4xoYbVcgOo3KueNqlB6xEw9SoRt9NxYdyx5EYHN+6p4f1D6KMhewLbW3eNlyqjKJN+rHfesiiSMgwqpHoVJQKOomNVSP2UotN2hGpWF1Fac3as35DVWesawTm9IYlahopIu4ez3uk1NRqZbFEfRJKU1VbzS174s5PzehfmMkNLaOsTCwxRx8OtAA0p8pU2kwrBkTD//QCARRbUoWgipCRDjEN3DfhOJyE6mMBt4snp+vhkRr1goNmrf3Wl/tn99R/sB0D1Brvt6XnNMmLdvqY/fYn95nE3WsVsOkuJz3mnWTERuXxG00vBzhNVA3oZH5B2muR49r0hjVAsNRT+qucLvgYCfqJvJ7ea3H89S4rapWKPVMkjkvifOq2iNQvXYU4ng+tWLU69cmTAtWGPytwBaTMgA6vc7j9+D5qhWTQFFQQxVsEpBf7u9hucyPiKqnar2EUxzEuOqC6O3F5fzKcHbqGuI2SQ3p/BzPPyp5ncAngKTkRlxHg7ICr+Gg8FqIikvm+XULGpnKn2f3Xt6hI7GrUmET2A0J7PrLQtCAHrekLMZv0R1M1h5YiFrzyiNpsROh819AcP4LqLWkGqIXhCJqUbBqlJTwSA2qaOkZGTZXoC2V/4pW2uVUbW0HXuZ8qav9vBSOypPRa/To7BIeUfW0Ce2HcsJwP6cyco0UjLo7x6mgfQf9H9JxJq0qrp1sR/hS3W/k7GkdkjRGPUuQB1NBv0x4VyWc/VFqchgBLZD2APZEAlv87RdhDKtGwL+Cf06yYuHCxgswQlJh1OYfQ0AajLr58Gu2mCqaCrv1YiptArud5GKvgNF0gfl6OQYv+YTQXgWj83JEZ+pa2kbzZQrYnrFslZc9cBuM194rGbA9rWfv11RaXIIHYK2LRS5AuaAFHuL6QndDRq/vuVyDyr1M70NSoBbxz8GyOAE8L0pZ39r2Yq4/1zq2ooH9HdVsVYJLClPJsVvrCsTkGGSe5z7d+3O753IvVzdY4fXlXHhC0tv1oLDKC+xPvrcnrC2XY3Sdb/lM1/cosB4Vvf5tuB+u5z7nBdaT72/+jrI/va7+HE9YS82VsOp11Hm0wjBivwfY3317ApX5hx8vx+o6Jn2+9O+hj8k6J5f1e5iuj8uqJVK0e16/6hyo7S6+jjxpus+pXl8+Iyq+EZ8S9CC/Be2KAbvnnwfs+kuroinVdaMlAWhMj11UAfmf6uJW0z4cjdiFFVF/SRDilvF35HoxiyVPOxjR8wltquraC0NRnWpb8rVVr0jOC6LSds7mH948b6Ut2SNSf6ScFIzKt6P0rGA97BgVtowXqUavoeKWUdmfzKHKnh6shhtTY0RKfjaVdqlJUm61LG7IDMKtXGaMeV4NL2aZZIg8PiMZn536Gv/NrKsaJY3UUEKc64qbwL5WFPbYKmi5diiV9kswxnP+gOfw/jF3L28jLhWb953ErG1HCO482JoSyi0J7BaLYGullbbRnsq6/Qr4dVqpQiYSEPz4yx+5Dt+3WoXm+XuotteqvGx3LFvnZdsG7oDxquRhlzCGLXbmtC75mZEzHYFB4eqRWtLirAtWLpjf5npbufCCnLUx4G13i7JYgnljFN6uZC7j+XXv6Qa2FTs9deoUYhNTIEWVRLnpi968oQvso0gAN7EA99e5HIMCtbg6fnEpP9pU5YWrDBQZwd5zPdNlPYGPFPqXEIvAqbjvL138ZV/yNBRBFW49dXnG2gXYUh3QWj+8ZsmArYou0X795Req7OaqVkjB30Nq03gdj+fvYPnf4PeQcyRhkypBTvR73V3WtmCbRNWQCFW4SraRa1uu8aLsksDu8ZoKH8ky2Z90QvqjrP5yfzRdZkfDpYFotIy+NBRxC8vAnvsUoheV4XId205aEorEJSGIX+hQ0I4mpKOprqMXBaLWQjvqSI9IKSA116GgHUqFHUyoF1TaZQnwsjPD6A68xNcvzQyn0pbMESeepuJ+RsaIpPp+gor6YSrsR5TSFmgTsJPcJVTvzaqBGzOCcEt6IBXyE2ixaQjuyooijCthyHYzREvdYQx/hsAmjCWG7QFsY4I/Kufp0gdTP5gLYwT/CMZyfpe7MWDDbOTsJEwD3L2+s7YeUGVXjRYLtbei2qbSVsq6HRV0B8kQWYF7uy3Hir3HuQ5BLjWyGy/EtRLDVr7RFcu28rI1sEvY07Eoy8qZgca8UMr72xEYVhPh1WOovOpepsfAzsfJQD56d+neW41cU9BCI2JU4Xpnkdtf3GUbB9Vg4xbF15rYsWsX+r35FkIiIhHgqI6wiLqoXivO/Dx+ds1IxLtCLBoOcoPIIAQycMJvOa4r4jVieAyJXgM5yEASUly/dYduWLBwCVq17YCKVR1qfq2oBK4r6yfydSKCnTVUg9qGzVswbvwERCc2QpUQp9q35/eXkrIVqgahdduOyJ813zxrhe3NQUMQwH3KNnJsZSr6Y98+7wJJJTFp4H5z4GAEEz6B3J8jLBoRteqp43HK71ErUj8Zmb/FX/17OCOiERJah2KjBlq07YzM7Ok4XQDQBe3pF15yXdMylWu8KLtUB6EmrdoixBmpjiOc5/y5lyoTPlqQXGlrRGA3J5CbLgtGM3qTZUGEdgCnIcpFXTegW1kk8ZwXuzQIsYR3FAEv3dmjCehaBLZU/Ku5IBhh0jOS6lpi2oWUtsrTDnEr7Ty7qqktSvuF/FA93JjqWOPA45xKx5oHcxx4MJswnfQsTki1PFqf9yag1FQp11oP9db1JbSfw/VpwSiVFkbwlseJX37C/lNfwhhZ2hvYMlUNkPShz2D1wV0YuiOXwK6Eh6fFkvHnUXfmQKrnOEJ3CLLfc1/rRmiaConYlAuwl8DWdpmpsiWGLdCmspY4d5cNCJqgOyEazZbDJr0f+26CX4FYtvHqFqS+f5khETFLoRa0z3lzHjp8+LJ8/4ED+EUNblm87T94kOseKrRtSf3AoQM4crTwaDEFVY9l3373HQ6ozzyMg1SI0oiZ3FjXsLYAUSs6Ae9te0/tt+Dn/Rl+kC4FiDa/8w7Wq2HVNmHtunXFFtf6guvKOrKu8g0bcerHoseH8/z+Bw4eUt/f04QHRV0D3xz/mr+V+3fat28fVfPFf9uS2M9U3nKdWN/71Kkf0LC5DvF4/h7btm/7038PKX72zTfFNxYXZ5/t/ZzbHzH3c0hd40WZvUYd1x9TUcA+evSY6nxkHc/ez3VDfXHX9u+xhiawmyhYB6PpihA0Xh6EhgRzY7pAuv6SQJfSlgyShKU6X1ugLUo7irCWqUC7JhV4GMEdRvUtDZHFKe1yorRl2LH8MJSeFUqlHaaU9rMqP1vCI048zunj08PxYK7uDXkfFfd1E8uix3tjcO208oTsU+a3AHI/JTDTKuA6GStymp2gfgky+roxlbCeynkuhW25CfERXGdMZXoVvLHBnfUTkNqfiph/BLEDMGHlh9h+4BiMyDwCeyFszbRLLRHV+EiFbbTXbhNod1qJ66XXY33pJXkBt0qmyKu6F6TR5x1dGMqq5tf7HaR+UMKOM/+/W0hYlLphrBtHGi1/PFX8yfPZH2tOPgVZsJbfI6xmDI5/XXwFvavVAkPcRcXEgxy6Md4KI/2Z1mR5FTQnlFsQ0uISzxa13ZQquslifwVtcYG2l9ImtEVpxxPadblMQVti2ouCqLR1yp+TCjvMVNp2GTdSxowUaNMrS9YIpxVmBhHaDqW0pWONDDf2HJX1c1TaMhr7kzlOPCaZI5w+KCOxZ9txa3pl3MP3xlidbmi1uRjDniaUq+IGGZFmYkVcOyWc8OZ64gLtImLZLoCPD8Y1o51qP2ILDu6kgo5Hr/mrEDV0NYxyU+DXeD5sjRfAaEpYq1j2Yncsuy3/MCQsIrHszvQua2Hrvk6PA0l4l+rxLl4YRUB33IjrJJ5tlV7ttR6pu4of7d8HbNP27NmjxhVUsV8TEJUC9A9W3NOGz/44++ijj1CzwO8hWSRi/5d+j5WrVyPaLJ6mvqcA26kV9l/xPZuuqIYWhG9zBWytspXSXk7VTSBfTGkLtJOptOtJBxtXTDuYStuJ6nwtsWyttEPVCDYBptIWYFeb5VTQLk+lLaPWlFVK26FCI9ITUsW0qbB1zRFCOycM92YH4/bMaqoXpORn35oZiIoLdXprxoFVBPh/0fMd3Sekz/Z0GBMqFAa2pbStjBFpfOTUNoFwH18JL07X+2u7chyB6s7T7jeHAI+ZCYPQNprQqbS9YtmW0u5ohkYIbAVtGZWmJ73zeoxf/ynm7/kGRjcqbqWwJYYtwP4TFbY8pnlmFWg7z/lFXXx/3Y13/ry3elFphw11S7zEsaURs2Xr9uZSn/2Rpi8X78f7OvJ7NHD/HtKTsMElOj79/c37epcxUKWjlGe7Sb36jdH7tf7mGn++NVlWDW1W+KP5skDlAm1R2s0JbXGBdkmUtiumbSrtOgsCUIPq2q209Qg2WmkHUWk71KjslefojjVl+LrMrBA1sK/0hHw+145nZthd+dn35/ijxqIWeHPHFNgml8H9WXb8OysEd2RIr8VnCOeyuHZaIIIX6AqKX/5IME54UcNaBj2Q0IgnsAsobZsAfGIYjJHlCVIq9bGEfe8qal+nzT9So+YsGEl0yc+W0EjzRe68bDOWrRofLZXdlX8i3dfTBdoblQLvv/gDvqbClk40/amyu23BlD1fq/0XZX+Ywh45eiLiEhujXZfu+J/Zs09s8NDRqBOVgDcHDMbpP+GRT46hS7c+yM2fiQ8+/NgrxPHVF18gZ/oMhIZHecFB1FyN6CQsXOIeg85nV8YS6zdD+449kJ2bx9/jQ6/f4/jXXxf9e3BaOzYFs+YU3xj6d7XMnBw1wO6nn7iHEDt/7gxWr16nYC1tJrrdRF93kke+Zp2uT/FXmAC7NYHdYkUwWq4MUg2PzQltNS2h0vaKaS9yoi5VtVT6q7HQUazS9p8bRlg7UGWuHeXnOFGGXpYQt3pCviBFovIJbZWfHYZr0/6Ln8xyqR02vYU7MwOojp8jZJ9TtUbukOJQWQTy5MpwLm6PR2fEw2+aQJpQniagFmibwPaEtgVsyckeXRltVg03u6/bYQz3R4+V7tpHFfovR4Wey9F0ItV25AwYzRaYjY+LdSy7LV1qiYjCVsCmSyyb0L5GRqWRno/0a3pRYb/2joZ2dwH2ZaT1XQmTsfukNGuipDKlNFVDQ4l17NFLdX2WhiRJi6oRpfNXCyvyK2eS6lc3qTFiEuqjOm8Gyf8ODqutXHoV6t6IlsKRm0antoXXdlft8tmVM/k9pBt/TIL8/nEev0ct1Y2+uN9DasFcjZaRmYuadeNVyQcpeBUQWgP2iEhzrFENaut7Snpfreg4c8u/xlosp8Je5o/WBHPrFSFouTRQuUtpKy+50pYSrVGLguicqnQ/T6UdAuccqux5wQghrAOorqvNpNKeaQ3sa0dZqmnpCemdn23HfVTY7dfoanoB8xpRVT+J/T9o0N2Z6Y/bqbSldrYMeOCXGojrpobgunQ7StGNVCpnKzQiKttTaZvANqRzzVs6Jr7t+D4YQ2WoMq7X7WVEzk3Fgg/3wKgxEvN26hS8RmMI3foLdFjEM5YtaX4CblHZHend1iq3idImrG2itPsQ3DL2o6T4ddmI1N1/MrClzoK+4ehNzC7Z351ElQCHyiO1bsaQ8Dr44mjJOl38VpPONNKpRt0U/FxRMZ7uOk5zmdw0VYIjcPKklEz960I2/1fN8/ewzvnFf49mapBlq4Tt1WaZZoVK97Vn5sAX+p5a2PyosnqufPZHSa25KOzl/mhJYLeit1wWxPdU2HSltE1ol0hpc369RQ5zMAQnIqmwIxcEU2k7UYMK2ylKe54o7RAC20mV7YA/p6K0JTRSbrYT5VRPyBCUduVnh+Fpqu5nZNix7Coqte9ewvvxGe6R5red3Mv5L+Haaf5Uxq/gH5lO3JTuxPUE+DV0W1oEYU0oC7BFabuAzXmesexRFTFqh64pYwx6XnWoGb19Jh4c0ZkQFp+Iaq/pethffPctVfYcE9gesWxJ7/OMZQuwu6/TDZA9OVW1RQTaki1Chd11M1I/+JNDIkmNmypVlNykORo27YjKQQ4131k9SnUQaCCdPBq1Q5VAPf+PtI5deqKuOYSZu4OGp+vc63opjVVtk6h6SfjZzO302ZW3Ev8eyY3hrF0XUXGJ+P77qzdTJ5MKOza54SW/Z3Tc3+O6a7GiMtoSxG1WBCsXlS3eiuBuuSTAI6ZtNkpeQmknEtZxS4IRT3WtRrDhNJKArjk/GBHzQxE+T4YbC1SFoiQ/O3AWVfZsO6rOdqDSHDsqUGlLI6Q7a4QqW7JGckPx1IxgPDU9DI9SfRujnwHO6Cf1D775iKB+Ek1WD8SXP5zANVMrqrEgb6C6vt4cC9KW5oRN8rElg0QN5EtFLa7S/kylLRAfWQHGgKdUt/Wb+d6y+4b3oBoeCqNeOhqO3YFe+dthJM6FISl+nrFsqehXRCxbKWwBdw9R2VJfZBNski3SdQ2m7ChenPwhwN63fz/KVeWPUjeBqsGBoSPHqPnvvLsVFaqFqlCIVJfLys1X8/+IfFLLpkxLR4NWbRHKP4uA0Oqql5gU05eejzKythS2kuHEXnv9TWzh8Wn76xTO/3Ur0e8RVhuv9u2HDZs2m1v9cSGzP9pyc2fjpUoBCOF3uvT3/OuvOwF2aw9gW0rbgrZLaauY9qWVdtISB+Kkt6SptCM5FWjXlF6Q83VZVgcBLvnZQQR4EBV2tbl2upPAdqgRayQ/u7isEamf/cgMQjsvFNekVUC/7SNxhyjpqS9jzgF9XoftyiOU/XFDZiihbY4FOS1cQVup6zQ7IW0Ce4oHsOkqlj3RgVLjud7A59X+xHI/ohru1pWQJrQjMjmlum5EZd10vq4lQmiLyra1JrjbEtxmPrbyris1sHsIsDfCTwF7M4G9hcvWEth/UVrfmjXri6xOt2z5Kpw7a443/yfb2TNnsH/fPhw6dAjHjn1hzr36rGCWizQDXI3pbv9Xfo+S2NXwPVutqIIOK/3RZmUI2tItcLfyUNqtVFikZNkjyXydzG0SF4UgbnGIGgShzqIgRM/Xo7LXosKuPp8qu2B+9iw7Ks8JNkMjUtkvVJdjLSZr5PFsBx6aHow70v1Vup9U9Lt+ajVsOLIDpefWx82pdtyS4cQ/qKivLyqWPVXe0wvFsuU1ndCWocaezWmqztOyvbsJ5iR8/+tPWLjzIAx7Fq5tMhNGEwmJLEIps+ejnxSFEmC3o8omtBW4RWVLSERi2VTYRu8N8JMRaURhd9yEKbuL72vwxwHbQxR5NipeOO9+fe5PBIwFswtFDJj7dwTd3s8/x9PPv4SqIeGoGhyOF16uiKXLvAdE3rh+AwYNGYnJU9P1jD+w8fZK29X2e/xWs54er5bv2YoKu93KAAVngbaX0uY8iWkXVtrFZI8sDkTyilAk8b2ERqRTTcwiqmxJ+Vvo0MONUWVLzRFnwawRiWNTaVeZG6qyRsrPcuKV2YR2gayR/0rWCNX3rVPL4JZp5QjtCPxnuh33TA/DvzODCN+yuI3K+vaMCDXgwW+KZauONFw2gT66KoyhFXVFv3bukab6z34fRvxsApvqutkC+DWjwm7pURRK0vw6LIOt8yoYXUxgdyewRV3LaDQy7qNMO2/8i4Dts99lhw4f5eNzPdVIKx5ZN0WNn2nZ3PmLEOCsreo7S+ZNnZgkc4nPfPbbre1yKuxlAWi/MpAeUEhpu2LahHWrpYGXUNrBaLA8FPU5TVbpfiFIoMquS4UtSjuSU0n3k+7rkjUS5soaCUHI7BD4zw1CAEFdhaCWWLbuuh7iqur3gmSMzJTY8n+x7esPMO/ASpSa8gweyCG0s0Px7xwZcd2OOzNCVZjkVvrNBPaNGZcZy5bQiIB7Qgj+NTVSl2AVxd23Jlbt+9w8c+dgOLNgSM9HgXZzcWl8tLJFdKOjXwdTaUsnGs9skV4EtzQ+dtyAKbu+MvdZ2HzA/pua1KBwj6jTUhV/kpFRLIuOiUdyk9auxjsZ+ssaAs1nPvut1m5FNXRYEYi29PYrg9BaYF1QadNFaUu6nyhtaXy0lHYzLpNu7A0JZxUakVi2TJc4CGxR2XY93Jik+VFhRxLcMvhBdaprlTVCxa0GP5hDlT0vGAFzw1BVYtlU2mVnh+uqfnN0Vb8XCOvHqKajl7g7VDVY8yr+lVVVjwMpdbPFMx1qxPV/ZjlwS2YYbuT7G6Zdbiyb897QaX5H//cDjIGPUm3Xoip2DxxiRGTDaDSP0Karno+6u7rKGFGNj8vg13GlBnZXgbWo7ALZIp0I7Pd9wL7qrCCwZdxMKexkWd16DRDfQGcayDohzjpFFr/ymc8uxzqsrIzOVNadCOuOK/wvqbRbrhB17c4eUXVH6FIwqvFSfzQguGXkmhSBNl9L1/X4xUF0GR8yCJGSp73QjloLJZbtmTXicGeNzLGjysxQVJwdjPIzg1FmhkP1gHx+ph3P5AfhrvTy5tEDyat74t6sang406ybnWXH3dky4noobqPCvn1a2G+PZQ97Afu/Pak+xzaO88YFweifSEg3gdF0LIwGc2BrOF93VxdXHWmk8XGRHuBAskYKZIv4dTWzRVRONlV2x/VI3VF8G4cP2H9Tu5TC3rZ9J8r5B6sa1zWj49G4ZVtzic989tutw8oqhDWBvToYnVaJ0g66uNLmPIF2M6pqleZHOFtV/poQ2gLpBkuD0WCFQ0E7ZbGuOSJKO5rvJT87itCuRcUt+dnhVNeFs0ZClcquRNWtao1IPDvfoWLZL86MwON51fBSbg0029wHN6c+h8dznXh4eriqm30foX2PxLRznLg9O+zSseyCNUYsYEtIZKId/5xcHQsPvkt1XQ3GyMroujYdfVZRTTfqhVLN82HUp7puOFcXhGpu9Xw0q/i1dVfvs7JFFLAlW6SXmS1ytQFbGmJK2vOxJOmAan+F0sJ0Y88fmU5YUlO1V4pIW5MY9sUUttixI4cwcfI0zMifq95fmR6jhRvCfk/j2OVuq86H+hre28k5upzfSz73cta/2Lm7nP3o4y+8L5l/uefC2s2V+V1LZh1XVkJXKusuhHBXglqgfVGlTWiLt1wpIRF3j0ip8idhksZmaESgrZQ236v8bLNIVLwobFHbCwNRh7CuQVh71s+2ao0EzJJaI/SiekDmh+Kp3GA8nFMNT+Y68FhuiKrm90COHfdRWUtFv7v5+i6JZWfqWPYtmXbcmO7AdWlhKCUlWCUsUlSNEZmKW+CWLuojyukY9gB3OdfGuQR1iwkEtqjrubqKX7OF8FNlVxfD1lLCIkt0JxrJGum0qshsEaP9Vaqwd76/G9k50zFs5FiMGjNBjR4+aco0zJozF9t27sRZc2Scktqxo8dUStX+ffvN3mR/L5O60pK/btnXXx+/qMIuyn4PWD1N0s9kBPd9Zt3lK2GHDh3Bgf0HXCMaXcpkZHn5rVQa3NHfngZ39MgxbN+2A2s3bMTa9RuxY/sOfFdMR5wvjh7G5ne28o9xM9asW48vvio+lngpO378G7y/azc2bt6C/fwOv8nO//mCQoDdZXkAuhDW4sUp7daEslLaZmikhQqNSMEoHdNWKptuZY2oMSIJbSs/W3eoIbCtnpDSACmNj/SwRVb9bJ01EkilLbHsyqoXpHcPSIllP5pbTQ1yIF3WZaCDx/LseqCD6Xq0danmJ7Hsu8xYtgwldmuWAzdmOHFdRjiuyZS4NaFcsMaIUtiWa2BLXrZtAl8LsIeXRd6na9V5+/70j1TWbxLYuZwS2o3oTebrbBEBtjQ+Shd1s+djkdkiEsO+WoB97qweNHPilFRU9Q9F9ag4VW9CHvnFZaDT2KSGiI6rr0IA5SrZsdRjTEjLzp792XwFpKamo57UMglyIqxWXdVpIbx2DEIjIlE1OAx93hyCY1+4U2g8lZQUn3/qufLwD60O/5AIlKvmQJ/X3jSXFjZZJuvIuv72CLz4SjUsWVq4eNSF8zr//KNPPkX/NwYg0FkLQc6aulMFXTqT1KybiBmz56Bugnsk74IKe8HCRUjPyEZWdq7y8eMnCrHNpZc2rQT16x/4BzZ4xGjYw3UnIquDh0yr8ftUj4zHyLHj9Mq080WApKAKlWNq3rItKvo7VKcRdf7Ncy9dsNt06KzW8/yTkSyYtp17qTTG0OqRan3V0YTbVg50okGztli4eKm5doHPNNPmVq9dh35vDkBEnTh1LmXbmlHxqB2TqFxeS0mE2lGxmDNvIZ9O5qiBpKsEhanaMrV4bdWum6DWlQ4ulYPseHuE9yjrnuZ5DF8fP47XBw3hvuxqCDSplSI1deR7SHpmdHwDZOfOUOuKai5KOUuBq2Yt2qASv68cp5w7GSQ5LjEF09LNoa7+QOu0qjK6UUl3XemvvEilvSIA7VbZtdJW4CbITXBLwagWLnAHFZ2fvTSwUNZIXapqycuusyDQVWtEskYc80IQTKUdNIf31twQrx6QMrTYfzJfwbidqQiaG4tHZgTiGUL6SelQQ1A/kmvHg9lOBez7qbL/ReV9V2YIbsuw45Z0CYuEEtoSFglVGSPesWxCW5S2QFuBWwNbw5vzBdqitt8ua545wrRhJzzQYwaMMEK78Wz4NddxbGmA9DMbH/UAB0vh10HnZOtskXXKVWGoduswdcdVktZXOyYedWKTkNykvWsEjqJc0tyqBkSYWxW2tavWqm7vdeNkJHIZf7BgF2g9komkxAk8Ro7WNXM9zTOtTraJS2mGMeP0YKRFmSyTdWRd2aZO3eRiFXG3Xn0I6ppqhPOCXbTl+0n1tpiExkhuqBsVZV5Bhd22c3dExaQgKrEBovlHVpl/cpdnGhZSqEvGHoxLaoqURm1cx+F2OVfN+OfRDJWr2XHk0AG1XXE2c+ZcVOIfV0xSE8TVtwav9d6n/MYyZJllp3/5GbVjE1CDkJXRzAuub7lU8NOjyDcwt/S2lCbNVXmBuPrS9V2fS9nOeu05L7FRa0Tyzz+S+0rkefb8HGsbmTZo0gaxCU1QLdiBEyeKH3Xm7WGjUIXnMT5ZroGizmNrJPH4I+s1wktlq6ptPGH/wQd7EGB3ok69BkWeNykvKwP+VvZ3YskS73z8K2mdVlUioAXY2juvDC6ktNsR2m0JbE+lbXWsEaUtwC7UE9IMjUg4pAGhnVIgayRmkR2R0nXdVWsklCrbDgfVdTBhHjzPiYB5Dq8ekC/mU8mv7mIeOXDTpKfxzIwwPJnvxBO5YQS4gyqbUM8jtCUskh2Cu3McBLYT/8wMx01U1jfwtQJ2SWPZAmwpAmWp7DEBMAaWg/FGfarqruo4/kfxaQRnwdZIl12VbBG/llTYUsVPlV0lsAtki6j0Pknta78OU/7OwLYU1qChIxDDC1LfVDrzQQri1E1qgKiE+ogmmOS1VP+TAUlbtemgtrPszBk9TNXYCVMQElGL27thJ/uSqdQxcZeztG7KVqqS2rgJU9X2lnk3+rVQI4XLALTFmedo4rLfgor4/Hn9BCHqWf4orGPSx6CPTYCkj1t/prWvovbnVdSK24SE1TKXlNyaNGuNqLgU13cs2q3jlM9pjYrVgtXjvlhBVf3W4GFKlbvPvd5e9i/zxBvxM0W1WyYQrBLk0L9JgXPiWWLVmi+v5fevyc8paN17vqaumYLbyL5lXzJ1n3fvfcqxWetJHRz9Haz19DVjp+oXO28+JVnWo3dfqvJEcxu9vrU/fTx6cGnZXz0C/Y0Bg80ttU2aOk092Xj/Dnp9t3DR82Qd+VPq0+91c+sra51XVkZ3Kuiuq/zRjV5QaXckxDsu91fQlpi2qGwNbW+lrQdA0PnZLeiSNdKEyroBoS2xbCs/O5HArkeIq6p+VNtR0gNyoe4BGSHxbKmbrar5mXWzVSw7FJWosF+ZGYQqs91VHP+R+ryuMSIj01BNe8ay71d52aG4N8uOO7J0xsjNmXbcnObEjYT0NYS0TVS2xLIvBWxxAfZ4iaGnoNQo6UyTQHXcxjwSIGEM4Zsyl0qbwG42/yLZIpy6Gh/XEuprkPq3BrY5mGilgGBenG3VhSkXZQQvyjadeqn6yFnZM5BNn8wLu3XHHqpOyTiCuaC9s2kLgsNqqsJS1gUuN408FjtrRKF+0zaqxGXN6AQFh/qum6CVGl3mJ4/iO78X2EXFnBs3b6MUpLWOeDxvaAmJSPgnhUCsykfzeLWOdaNqL7i/gsCWPOzLsc5de6JuovUHqUEgoadq9up8UqA6pstrGdncExrxVKa1YuqZe3Hbzt27ERRWxzxfel1rnxIGEUiLBzpqUCk2NLcCf48a3Kf3n2tUvRT+Hg71e9WmGpeBk5MaNnOtI9Oo+MYYM977yah7j74ewNZPOhIWiaKSbtSiPUHcXNXw8PxjEJfPrBkdh/A6sWjSqoP6HYO4nlw77vVaqBDHhrXetaqzcvPUdu7vzT8aHquzZjQiKASSGrbgkyO/Q3gdnkv+1nY9ao5lElsPCq+lFLX1OTLV5YfjlJiISWhgHov7HEVExiIzR1eSu5LWeWUlFRLp4gK1p9IORge+7kBg65h2oIppSyeagkrbyhqx8rMbcXljAtuKZWtgm7FsTl2x7AI9IMOpqkOpsouMZc9y4tm8yohb3BzPUG3/N9+u6ozokWmsWHY4HpJR1qmw7yW47yW078x24vaMMNxCiN8yLUyFRa7ltBTVtupAI8C2ej4KpAXYBXs+Sq/Hwc/j+7O6Tcbo/wKMPm3RKHueej905scwEmforuoXyxbpsgpGNzO9T0ajabP27w1ssc/37aMyq+e66OtSUc+ee/Fi9acKDBorJqOh633oC1tuEKn29kWB2g3btm6FgxCIb8xHV7UuQUTlM8gjVnmlFfbGzZvgrM0/DS6T5eJR9ZLRqVsPcw23dZMa3vGedaEvrbAvB9i79+xRatE63zJ11IzC0JGjzTXc1r1XXxU2sI5D1pXfavuuXWq59YQktc/lKUGvR0XauB3CIuqoBuOCkXVpfBQbOmK0apvw/OP0D43AgsXesf/Tv/6MRk0J/xRvaFcJtIYM03VVunkAW45TCkwVtAsUCDXqJPD4PM5tbNHhq1hC03MQYPnzmTA5zVyqQ0oSW/cEezT/eBs3b43vTuqnEMt+PXMGnbr0xPTpuuDZBbPQk2xv/Q7isbwOnRQV6VnZeP+DPfjok08wY9Yc1KhdFzEStjLXk+Py5x/qDz/K4CAFz/Bvt66rqqDHqmrovjrQ5d343qW0qbLFO6wOQTvVuUa7jmcHuoBdMGvE6lDjFcumsla1Rjhf8rJlwIOCPSCrXzSWHYIKs0PwQl4QXiKcX5gVosaAfHamrjHyJF8/QZX9IGEtsez/TNcZI/fkBOGuLKeKY/8zMwz/yAjFDWlhhLYDpQhum+Rhmz0fbanhhLcJbXFTaauej6Mr482tuizES9ObwhiURBXdBe2y1+PlHoRxSr7Ox27q0fhoZovY2kqPx+Ua2gJvM1tEKeydf3NgHzhwwHyU1hejhAwG8fG6KPNspPJ8vXDBYkTGUKWaN6I81oqyKmjW4+yHH32McCpv/ZmEHuHtb3eXT7zSCrtV2058HNaAleXxKY3Rscur5lJ3aEFGIxGTfbmHLLuyCrtTt15eoQMppm+pNWkIk/NquVgjngNRjdaxCLhGj3Ofi/NnTyPAXkMpWnU8XEdGTpnL30Sbu1CVZ02NatXcsJKpKPGPP9NdfaU9zvMYxCL4lGSBViAZQWW75/3d5lJvhS37c48+7g20nJw8BWPr+9SNr48ZM2eZS922k39KMlK7tV4cf7M33nKHMyRrScoCWNeInKPmLd3DynmGjC5ccJ+Dc2d1+G78hMnqycpSz7L/pnwKK8669+iDaB6r9f3kz+7VPld2OLEuBLaEQrqvCtBOYHddWc2ttKmsJTzSfpUAO0hDm67j2QQ2wSzunTUShCYqlh1YbK2RhKUOxC4t3AOyuFh2VTOWXXFOqOqy/hLhLB1pVI0R6VAjsewZhDZB/vB0B+7P1j0f/01VfXdOMO7ODsOtWeG4LSsCN2U6cL2k9xHYfi5gi8K2m8AWWJvQtoCtqvhxnWEVMGV7HuFdiYo7lgBuTgU9irDOg19DAlqyRZoVzhaxikEZki0i0BZgWyGRvzuw5YaSVnTrhpcLUi5MZ80Y5Obl4n8/uzM/xDxvYstaduiuIGjdXJF1k7GpCNXkaXUJKksd6Ru8DoGpbyzvPOjfprA3brTKZmolZT32yj4DPOK4Rdns2bMRy8d+z/1dKYVdSYFSn2tpfKsTXTjE4WmbN29B7Vh3xorEeVu11VkeYmvWbVJZFdZy1VZQ/+LjLy5Zthy1uI31xBFXvwm6v9rHXFq0ZU3PVeEB63MEuqnTMs2lhRW2G9jetp7nUWqvWPuRAQakbnVRJiPh6GtAt6l06e4+Rrl29FNFC3XtBobWwFmzLaUkFhDifiJMbNQWUXUvXQ+maYs2/N31NrKtf7AeYf1KmSjsXqsroceaIPSkW9BWSnsFwc33XQh0aYDsRIh3WBWsvA1VdaH8bKW0NbhbrrArtd1UGiKprrXSdodGkgnoOEK8noplB6tYdm2PWLZjbqgrL9tf8rJn64EOKs0MQvlZdpTJt7trjMykylax7GA8nuPEI3kOPCKxbEnxI7DvyQnB3SqOHYrb08NVd3XJGLkhQ4BNWBfq+UgwFxnL5nxVEKoyjLEhCMnvgp/PnCage8BokQubysmWruqetUUkW4TwbkN13aFAtkhXAfZqpG7/G6f1WSqkGQEgylouRE8XaIU4I1EvvoFqGLQUaEELcHgoPMKoir93rLAoGzxktPmZ+gYXlb9/v849/r3A9lTEBz7fp9Sg68Yn8Np16aWWFWfv796N6rXjXNtcKYX90Scfe+y3BeomNsGU1GlqWcFGRMukmUHqVlvHksTH8fjERuZSYFpGtrdiTRDFqmN5xdm4iZNVmqa1jfwhLC4iDdLTPtu3H9XruENnovRHjh5vLr2Ywva2DZu2ENjuPxgF7KyigS37sD5P9i2fYVnVIAeX6T9hibHXb6Z7mxZ3Hj1NGludNXVYSv60asbEY9OWd9Syora35u07cBBhdaL0dvTqteKwywxPXQnrRmD3XF25SGB3JbA7K2ALqKXruqT3aWALnD17Qqoa2kppm6ERAlsaIhsvpdomsBuZwJa8bHcPSEK7mFi2U9UY8YhlC7ClIw0BXp5Tq8bIiwT2c1TZVixb6mXLAAcPE9j35zqosHW2yD3TzZ6PBPbNAuyMMNxApV3qt2aLjKqCFquGq3M4ZM0WGE3HwKYaHSUf24S11BYRhS3QbivALlBbRFL7RGH/nYHtaTWjZcSXhiqVygKfBpKGRL3kRlSqYXj19QHqkdnTpJHIurFUyh5vrktZWkaWCzSyrQyKKh1GxK5EDHujqYhXr1vvBQgBzfhJ3lkpBe3o0WP8/BjXd7pSCnutHEu0jCeo9xtdLwnz5y8ylxY2K1dY0hDdcGqu/nQsmzA51Ru+/K6b333XXFq0deXx10uxjr+l+q5ffVX80Eg8Epz85gQcNa0wlj6Po8a6Gx5LDmxR2L8N2KLixeSs2MM0ONX1kdIMbw8bqZaVxDZs4FNJFI+B28t5lfNbUpMRnKzfIjIuGbNmX7nBibusroI+9B5r/AlsCY24Y9nag9DNjGVb+dmitNt7ZI14xrJbEcqeVf2sWiMK2BIWoatYNuF+sVi2Do0EI1TFskMQSFWtRqbhtBLhXX6mHS8RzK8Q1i/MDMELuU7VCPkk1fWjkjFCVf1AlgP35+hsEQmN3Mn3d2dJHDtUxbNvIKBd2SIC66J6PnopbLoo7ImhKDU+HMbAV9Q5PPbTNzDqD1Dd1G0NCG0pCCWDGkhHGiu9z8zHLpgtYrRYjSlXQ8cZSzmPnjAZVYP5D1svRd0gckPom8INJ8lcqOgfhO++0yMzXKD6sHvcWOqRvGlLtexilmWOtyfbyLZXEtieinjdho2FgD2W3/Ni5v35V05hSzhA9mUdi4SF5s4rHthW+EkyRryA7fGHOIrfXb6TtU/5rp7HWpR16d7L1Yiozj2B/cWXF+tZqBWmdCSxzslfCeyPP/kUETUttd9C5Z2Pn1g4c6k4W7thA2p5ALtysLv95FIW7coa4R9uYn2kTbtyHWoE2K/SuxPWAu1uXsAO0MCmwrbys5XSFlCbDZCSNSIZI1Ys21XVj5CWkEhjCYkoYNvRaElwyWPZVNXO+cGuWHagWWOkyqwQVCSwK8xx4OVZYS5gP09gq1HW88PxWK6d7sADVNVWtsh9fH0XVfedVNfSVf3WzHDcSJWts0UE0oSx6vkor01IC7CLqpMtCls60YzzR7XsLjx3VNDtCexm0wlsglqALV3UCW1bgXzsgtkiRsurBNgFbcGipejQpTv8g6ujBh/hJYsjpZEuJ6pdMgrc8buqQeHqwlc3a1PeANUuPV6k3KR/FLA9Ffb77+9Gjeh4V7xW/nB69x+glhVnBYF9pRT2Zj5214rUaY2ybVRCoxL1oJOMhOKBPeGygT1g0DCeL4Erj5/b1IxNwJoCKXNFmSdA/wpge4ZEglW+v14Wn9wY3Xrr3OiShER27NiBmubvIPuQP6xTJSyZIPeE9VvI09KaNbp79JWwHmsqoe8qQntNAHrTRWV7Zo1IpkjB/Gzxglkjrli2qbStWHbr5XZVFKq4WHYi1bU7L9uOKKvGCN+HLySwPWLZgQS3GmWd0C4/S8Z+dKBMXihK54fixXwH/iuNjwS3ZIs8SWg/TGX9YLZDZYsIuP813er5GIp/UmHfnOkws0UI7Uw7bFJqVaA9VepmF58tYqPK1o2QITBGE9yvtYSt5wCq6Ryq7NmwUVmr0Ehzc2CDVovg18pM71Mpfsths1R2yxVI3XHM/DUK298O2KLoCoY7dr3/PobzxrRH1HBdqCpLoHYsdmx/T60jXZE1ELViq147HvvMeHRxdjFgHzx0CGE13cCOIVzGjS9eFY8dN0mtI+vK/jwV8bfffo9QyQNX+9IeEnbxR+A/SmF/c/IEnNXd2THSg65RE3dN3+LsSgNbwih1qUqt8yUZD8NGFU4rLGh/J2BXDCBkzHMi30MarcVKWqwpMMQK4/H6im+MKVMvrdAXLVqE6Fj3NeusHoNjF30yuTzrsbYKXlsjDY/+Cto9OO1OYFtK2w1qz6wRQtrMGpF6I57Alqp+rlj2cgKbylqArbqsW7Fss8aIAraM/8hpwRoj1QnsMALbqjEi9bID5ofAn+q6ymzd87HMzDDVXV3GfpTBDSRb5GkC+wkC+yn6w7lhrmwRGeDg7pwQ3MP3t2c6cWu6UwFbZ4uEwS+D4BUwq7DIxbNFNLD5fjzXm8D13k6B0asPVfUIGClU1QJsc1ADv2a60VENHSY1Rayhw6zaIn93YHuPTXjxC/3r49+ojgTWjSYpVbPm6MatAYOHmF299TLJZEggWLQVvd+LAfv7H35AqCtGKamGjdBv4FC1zFNBWSGDN98eiQQqZwUgbiOAXeuhGB0EdBKfCixARcUlYVKazuEs2HNO7I9S2GLB9ghTYfN706VBdOu2nWqZldZX0K40sD/6+CNEuNIq9T6Dw2rjh+91fr1U5yvqOP5OwG7VtqNKH7X2ExmbjPketU48rahrJqW+O3dd2mikU4/nCPEFlbrkkMvAvboTkXxmC15XhXPNf4/1WFkJ/VZXQe+1QehNWPdUKruw0haX/GzpTKO6rpux7HYmsAv2gLRi2XrAA49YttllvdFi6QWpa4xI46OuMRKImIVOQtuOmlTT1ec7VL1s5wIq7dmhCJ5nRwBBXXluMKrKqDRzqLBnSEEod7bIc3nS+BiCJ3KcKizyyHRdEErFsrOosDn/9iy6mS3yj2mENmEtXdWNaYSvq/Gx6GwRS2GrsIgJbaNbiDqX1cfmwkiWbBGqbMkUaToftgL52Hpgg6VewJ6y7W+usLv1ek3lt37zbfHDu4upzAKPbASpSbHKfBx8Z+t7quCOvrk0FOslNUaDZi3x1ddFN2bNmDGnWGCLBdrd3YUVFEVBmT0zve2CyqKwjku2kfimjMtomYRMJCNDH1sLNGzcgccbhbeHjjDX8LbvvvseTo9GxyulsMXeHjJG5fxa50m2D3TWQE6e7tRRlEkvxSsJbLEgfqa1jXxPgVZQaHVs2VJ8g6Vnmt1fAWwrhi2WP3uBEg3u89iS0K2Od7frP7+CtnH9OkLYLVBWrl6LGlHxrm2lsTyQ338rr+WC9umnexHK609lo/B3kM5Gkfzs3BmzzTWujPVY5Q3sHqKyPZS2F7BXVvOIZUtxKO9YtqsHJL0l4Vwwli2vpcaIqOxGi4OQQmDXX+L0rjFCdR1FiFv1ssMIbIc0Ps51IphK25+gFmBXJrg9q/i9QGA/n+/As6Ku80Lo4Xg8z4mHsgXYWmFbwL4tiyrbzBaRburXZYSaJVc9gc33RQHbVNgWsNXrPhXVudz/3QkYdcfDZqnsIvKxdXqfR/W+liv//sAeRZjVqZdM6EUiNi4Z4yelYvny5erGkkayaRlZiIqvrxoirZtMLtrKgd5x6pjEZHVTabDom0gucEfNaFX9r+urr/OG6628e5/X0LpDJ5fCkRumILBrRca5GncsMAaFVcfwcRNUl3npgDGGxyodbiyYWccmNTcKWmWvR2hdX0LSCgWGyY2boRuPSY6tR88+6NCttws+4ldSYePCOVSoGoyEJroUgD5mgiuhgcoXb9auC3r26us6V337van+/KxjuVLAnjVzrqq8aG0nLschdTmC+H1adeiO7jwX0vOza49X0fPV11SXeWvdvxLYVtSjWnA4Epu6SyHIbyFd1SXMlJ6Rg2xeI1K5sGGztrqLvUd2jVg8Pzu+gWzr/h3knETUjsZbbw/FgGEjEJ2QDKn4Zx2vrBvXqBXC+IcvVsSDyG+2XmuqoP+aaui71h99OX11dYCX0i6YNeIKkRDa3URdFxPLdveANGPZZmjEimXrGiMhOsVvSZCrxkg9KmvJFpGiULXMbBGn5GWrsR+tno+SMaKr+FWcFYoy+dL4KKOrW9kioaoTzWMzpPHRrsuuEtjSTV0aIO/KDMUdWWZX9YwI3JAWSpUdCjV0WEnS+6zqfQrYEsfmn0z2WHU+jbojYJMBDaQDTbH52Mtc+dhG8+UEdvFD/f1tgC03n1ysSY3bIDqxMSJjUlTnl1oxCaoTjUBCw1Nf2KK0Jb1P7Lwaif08p+dUOU+pz+GuzaBvAtlOOtbE1efFzkdRacRMNIfYstYpCOzpeXNUL0BrP7JucsPWqJfYVLXUS1GquCQ+nroaQ7kfTuXG7tC1t7kXt7333g5UDgozj0fvz/rsxAb87jy2evWbqWOUfbj/LK6cwrbiq1s2byVs5Fjc58By+ZOrx3Mk50lcXlsNpnr57wf2mTO6M1Tztp35pORZOEnvQ94nmL9XvBxHCn8zvvZc568AthUSscIan3zyGaoGOb06fcm5sqrrRfMakaJlAmpZpxav62EjxqhtLQuVcBnVtc6E0seeItdZUhNep025ra7cp49Xf0bVECe+NZ9Iiwod/VazgN1nbQD6rK5mxrK10hZgdyOElbo2gW3FsrsQyl0lhl1MLNsrL1v1iHTHsgXYEr/WQ4nZkbI4GElmLFt3pLGbVfykq7oAO1gVhQqV9D4qben5KAP1VlTAdqiR1V8msJ93ZYuYwJbaItPtXtki4jKowR1U1wrY6RG4nsC+LkMaGksAbMkWceVjE/LjwwntYBivJ1Ex94Ct/XgYKdJ5xopjSz62ALuIfOxOGthTtxc/1N/fAtjDR41VjU7JjawL0n1TerpctEmN2iqIx6e4O2542tmzZ5HQoJFSOdJ7TkGP+7UueLmZPOHjuW/pOGMB2wJb7ah6qJug/0z0ugWPT0PT2kdswxaoGuzAz//70S3DPOzjjz/mY3111I6tz+PU21gu+ynq+GSZZANYWSdiojw1sGX5ZSps0z7a84GCdlSMnPtmVIGt9bHIPgu45/HIo7tnHrYCdrIGtjrWEipsy0aNm4hK/kGIS2ym9m3txzoW9d6cerp8phewe3oCu9UlgS37l3Xlzz8zK89c6m0a2PrPXwGbn1HQNq3fpOpm1/O4zgpfJ3pZHK+PZ14sgy+OuW/KC+fOIpxPgXUT5E/aW5hY+5FtVZlbQjw4NALffVt8qdffYwLs101g9xVoq9CIqGztKpZNkHuqbNUDksukwp/EsjsT1DqWHeTKy7ayRVqr0EgQWi2Vin7moL1U2TpbxFTZXD9lsQOJ5lBidam0owjq2gtDUGe+jErjUI2PoaK051JhU2kHzjYH650dgrKzJDTixEszdbaI1BaRbJGnCO2nckNVV3WpLSKhEamV/a+cYFVb5NaMcJWTLQMbqGyRdAE2XeqKSGqfuMBaXMAtLtCWqdWBRgbrlWyREckw+vWDrfM42BrM1vnYapzHhapyX9H52ALsFZj8dwf2itVrVJF8uTmk/ocoJ6lYJ5Xt5CaRBj+pXhZeJwbB9hqYnj9TbXf+nC5Z6m26oWbjps3o/mpvBITWUIWOpBC+KmIvxemLcLmBpWLf/gO6MJFng48UQJKwhRRkch9bU5fLvLpU3FJsKDou0TWizfkigG3ZrDkL0IA3oBTOl9i7ZLxId+mijk2OO8BeC6vWrDG3Blq36YiISL1cjr1MpUBzScnsnMe5mzt3voK/hEOkaL80Ql7sXEmR/+qRcebWwMAhI1RFRLWc20njmdW2cCmzamz8/PMvGDlqDMJ4HoIcNVQIwDXwQIHPt1w+Uz7bslZtu6C6HDuX6XMSxLmFfwM5NjlGa9+OGtGYPEX39vS2C2ofsi9ZT/Ytn+Fp587pJ4Uff/xJPdXJftV1wmvWuj7k+pV5wc5a6unFUxl7qmNpo5Ha5BISkmvKvX1jdaxSvuGtgUPMta+ssras/fJn0W35c+i4/Hl0UtPSaL/0ObRf9oLy1sueR+slz6HVkhfpLxC+L6LFoufQjK+b05ssLo0mi15Ag0Wl0ZCesvhlJC8sjaSFL2tf8DIS5r+IpHkvI27BS6jH97HzXkTd+S8pr0OvtfBF1J5TFhHzyiBizisImfsSgmeXQ+CcMvDPfwWV88uiAv3l/JdRNq8cns97CS9ML49nppfFEzkv45Hs8ng0sxzuzyqD/3B6T9YruGtaOdyWUQ53TCuDf6SWxY2p5XBtahlcO7UMAfwSwVueoK1AtVyW03IwxvH9BPp4eU0fw/lj6aPlNX0kfZSHD+My8eHcx3Duc2AQjG6tqKLfghEzDUZkPoy6M2DEzaLPhpFAgCfTpfu6GriXqrvJIs5fhBFbih+h6G8BbMtOnjiO2fPmY+ykyejKR89uPV9Dh869MGTYWKRlZOLTve5GvMuxH099j8NHj6phnyQmXpwvX7mK654yt/K2X86cQd6MfIwcO1EBXGKZ3ai25PjGjJuC6bl5OHi4+NjTxezkN8exd/8BBZIN/KMpdGxUhKtWrVFZMpZt3b4Da9dvMNfZjOVLlxUl6C/bvvzyKzU0mPTOLHQcpq+jb1jvBvLHH+3hubWOZRP/gNfieDENvSW1fQcPqIGGpdOR52d7unymfLZl27e9p8qVWsuXLteF/gum2cmxyTFa661eux7793lfW9Y2sg9rPdm3fMbF7Ief/qcKSQ0dPhaduvZW18fgIWPUPFlWElu+fCUmTklHJz5Syz7eHj4GC+YvNJf+sbbti0XYeWwxtn+xTPmOL5bSl2HbsSXYLv6F+FK8x+k2cc7bdmwpth3llP4u58myd7mPreKcJ77l6GK8Q7emm75YjM1cvvnIUk6XYtPh5dh0ZBk20jcdWY61R5diPZet4rZr6CsPL9Z+hK+PLMaKQ8uxir7o8FIsPbwMCw+uxOJDK7HwwDIsos+jy+s5B5bz9XLM3r8Mc+l5fJ1Pz/t8GfI/X47s/UsxnfOzP+d031Jk7V2OHC5L27sM0/h62mdLOV2K1E+XIPUz+qfLTF+ONHrqJ/r9VE6nyvyPuc4nSzDtw1WY+v4WpG37AFO3HEDq+kPK0zbQOZ2y5TCmbqK/cxRTNx/BlK1HMeXdoxi74QgOHi+aQWJ/G2CXVC3IjVSSjgmW/RYV8kcol+LsSn6WZ0W4yzU5p5fLe/ktLnb8f9a5l20KQtmygsdY0uO92D4vto/fbao9phi73B/IZ1epFc+3v5XC9pnPfOYznxVvPmD7zGc+89lVYj5g+8xnPvPZVWHA/wNXMHMxVFmXKwAAAABJRU5ErkJggg==',
				width: 130,
				opacity: 1,
				border: [false, false, false, false]
			});

			var oHeaderBody = [
				aHeaderColomns
			];

			doc.content.push({
				table: {
					headerRows: 1,
					widths: [100, "*", 130],
					body: oHeaderBody
				}
			});

			var oSimpleForm = {
				table: {
					widths: [70, 100, 90, 100, 90, 100],
					heigths: 10,
					body: [
						[{
								text: 'eTicket No:',
								style: 'headerLabel',
								border: [false, false, false, false]
							}, {
								text: oDoc,
								style: 'headerLabel',
								alignment: 'left',
								border: [false, false, false, false]
							}, {
								text: 'Well Name:',
								style: 'headerLabel',
								border: [false, false, false, false]
							}, {
								text: oWellnm,
								style: 'headerLabel',
								alignment: 'left',
								border: [false, false, false, false]
							},
							/*{text:  'Vendor Name:' , style: 'headerLabel', border:[false,false,false,false]},
							{text: oVendName, style: 'small', alignment: 'left', border:[false,false,false,false]},*/
							{
								text: 'Vendor ID:',
								style: 'headerLabel',
								border: [false, false, false, false]
							}, {
								text: oItemsModel['Lifnr'],
								style: 'headerLabel',
								alignment: 'left',
								border: [false, false, false, false]
							},
						],

						[{
								text: "",
								style: 'headerLabel',
								border: [false, false, false, false]
							}, {
								text: "",
								style: 'headerLabel',
								alignment: 'left',
								border: [false, false, false, false]
							}, {
								text: 'Rig Code:',
								style: 'headerLabel',
								border: [false, false, false, false]
							}, {
								text: oRigCode,
								style: 'headerLabel',
								alignment: 'left',
								border: [false, false, false, false]
							},
							// Priority
							/*{text:  'Priority:', style: 'headerLabel', border:[false,false,false,false]},
							{text: oPriority, style: 'small', alignment: 'left', border:[false,false,false,false]},*/
							{
								text: 'Vendor Name:',
								style: 'headerLabel',
								border: [false, false, false, false]
							}, {
								text: oItemsModel['VEND_NAME'],
								style: 'headerLabel',
								alignment: 'left',
								border: [false, false, false, false]
							},

						],

						[{
								text: '',
								style: 'headerLabel',
								border: [false, false, false, false]
							}, {
								text: '',
								style: 'headerLabel',
								alignment: 'left',
								border: [false, false, false, false]
							}, {
								text: 'Rig Short Name:',
								style: 'headerLabel',
								border: [false, false, false, false]
							}, {
								text: oItemsModel['RigShrtName'],
								style: 'headerLabel',
								alignment: 'left',
								border: [false, false, false, false]
							},
							// Priority
							/*{text:  '', style: 'headerLabel', border:[false,false,false,false]},
							{text: '', style: 'small', alignment: 'left', border:[false,false,false,false]},*/
							{
								text: 'Vendor Ref. No.:',
								style: 'headerLabel',
								border: [false, false, false, false]
							}, {
								text: oItemsModel['VendRefNo'],
								style: 'headerLabel',
								alignment: 'left',
								border: [false, false, false, false]
							},
						],
					]
				}
			};

			doc.content.push(oSimpleForm);
			var oBorderTable = {
				table: {
					margin: [0, 0, 0, 0],
					widths: ["*"],
					body: [
						[{
							text: "",
							style: 'headerLabel',
							border: [false, false, false, true]
						}]
					]
				}
			};
			doc.content.push(oBorderTable);
			doc.footer = function (page, pages) {
				return {
					margin: [5, 0, 10, 0],
					height: 30,
					columns: [{
						alignment: "left",
						fontSize: 9,
						text: oUserInfoModel['VenUserId'],
					}, {
						alignment: "right",
						text: [{
								text: page.toString(),
								italics: true
							},
							" of ", {
								text: pages.toString(),
								italics: true
							}
						]
					}]
				}
			}

		},

		onRecalleTicket: function (evt) {
			MessageBox.information("eTicket will be recalled and respective agents will be notified. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						this.eTicketRecallFunction();
					}
				}.bind(this)
			});

		},

		eTicketRecallFunction: function () {
			var oModel = this.getView().getModel("oETicketingService");
			oModel.callFunction("/eTicketRecall", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr
				},
				success: function (oData) {
					MessageBox.success("eTicket Request recalled successfully");
					this.getRequestData();
				}.bind(this),
				error: function (error) {
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},
		generateInitialDailyOpColumns: function () {
			var oTable = this.getView().byId("rigDailyOpTable");
			oTable.destroyColumns();
			var oColumn;
			oColumn = new sap.ui.table.Column({
				width: '6em',

				sortProperty: "WGnrName",
				filterProperty: "WGnrName",
				label: new sap.m.Label({
					text: "Well Name",
					tooltip: "Well Name"
				}),
				//template: new sap.ui.core.HTML().bindProperty("content", "WGnrName"),
				template: new sap.m.Text({
					text: "{oRigDailyOpModel>WGnrName}"
				})
			});
			oTable.addColumn(oColumn);

			/*oColumn = new sap.ui.table.Column({
				width: '6em',
				sortProperty: "",
				filterProperty: "",
				label: new sap.m.Label({
					text: "",
					tooltip: ""
				}),
				//template: new sap.ui.core.HTML().bindProperty("content", "WGnrName"),
				template: new sap.m.Text({text: "{oRigDailyOpModel>WGnrName}"})
			});*/

			oColumn = new sap.ui.table.Column({
				width: '9em',
				sortProperty: "WActDt",
				filterProperty: "WActDt",
				label: new sap.m.Label({
					text: "Operation Date",
					tooltip: "Operation Date"
				}),
				template: new sap.m.Text({
					text: "{path: 'oRigDailyOpModel>WActDt' ,type: 'sap.ui.model.type.DateTime', formatOptions: { style: 'long', pattern: 'MM/dd/yyyy', UTC:true }}"
				}).addStyleClass("font-bold")
			});
			oTable.addColumn(oColumn);
			oColumn = new sap.ui.table.Column({
				width: '5em',
				sortProperty: "Version",
				filterProperty: "Version",
				label: new sap.m.Label({
					text: "Version",
					tooltip: "Version"
				}),
				template: new sap.m.Text({
					text: "{oRigDailyOpModel>Version}"
				})
			});
			oTable.addColumn(oColumn);
			oColumn = new sap.ui.table.Column({

				width: '6em',
				sortProperty: "WGnrName",
				filterProperty: "WGnrName",
				label: new sap.m.Label({
					text: "Well Name",
					tooltip: "Well Name"
				}),
				//template: new sap.ui.core.HTML().bindProperty("content", "WGnrName"),
				template: new sap.m.Text({
					text: "{oRigDailyOpModel>WGnrName}"
				})
			});
			oTable.addColumn(oColumn);
			oColumn = new sap.ui.table.Column({
				width: '10em',
				sortProperty: "EpChrAcNum",
				filterProperty: "EpChrAcNum",
				label: new sap.m.Label({
					text: "Charge Account No.",
					tooltip: "Charge Account No."
				}),
				template: new sap.m.Text({
					text: "{oRigDailyOpModel>EpChrAcNum}"
				})
			});
			oTable.addColumn(oColumn);
			oColumn = new sap.ui.table.Column({
				width: '11.5em',
				sortProperty: "DrlgReqNum",
				filterProperty: "DrlgReqNum",
				label: new sap.m.Label({
					text: "Drilling Requirement No.",
					tooltip: "Drilling Requirement Number"
				}),
				template: new sap.m.Text({
					text: "{oRigDailyOpModel>DrlgReqNum}"
				})
			});
			oTable.addColumn(oColumn);
			//			oColumn = new sap.ui.table.Column({
			//				width: '7em',
			//				sortProperty: "RigLocName",
			//				filterProperty: "RigLocName",
			//				label: new sap.m.Label({
			//					text: "Shore Type",
			//					tooltip: "Shore Type"
			//				}),
			//				template: new sap.m.Text({text: "{oRigDailyOpModel>RigLocName}"})
			//			});
			//			oTable.addColumn(oColumn);
			oColumn = new sap.ui.table.Column({
				width: '9em',
				sortProperty: "RigStnbyHrs",
				filterProperty: "RigStnbyHrs",
				label: new sap.m.Label({
					text: "Rig Standby Hours",
					tooltip: "Rig Standby Hours"
				}),
				template: new sap.m.Text({
					text: {
						path: 'oRigDailyOpModel>RigStnbyHrs',
						formatter: this.formatDailyOpHrs
					}
				})
			});
			oTable.addColumn(oColumn);
			//			oColumn = new sap.ui.table.Column({
			//				width: '10em',
			//				sortProperty: "RigMobileHrs",
			//				filterProperty: "RigMobileHrs",
			//				label: new sap.m.Label({
			//					text: "Rig Moblization Hours",
			//					tooltip: "Rig Moblization Hours"
			//				}),
			//				template: new sap.m.Text({text: "{oRigDailyOpModel>RigMobileHrs}"})
			//			});
			//			oTable.addColumn(oColumn);
			//			oColumn = new sap.ui.table.Column({
			//				width: '10em',
			//				sortProperty: "RigDemHrs",
			//				filterProperty: "RigDemHrs",
			//				label: new sap.m.Label({
			//					text: "Rig Demoblization Hours",
			//					tooltip: "Rig Demoblization Hours"
			//				}),
			//				template: new sap.m.Text({text: "{oRigDailyOpModel>RigDemHrs}"})
			//			});
			//			oTable.addColumn(oColumn);
			oColumn = new sap.ui.table.Column({
				width: '8em',
				sortOrder: "Descending",
				sortProperty: "RigMovHrs",
				filterProperty: "RigMovHrs",
				label: new sap.m.Label({
					text: "Rig Move Hours",
					tooltip: "Rig Move Hours"
				}),
				template: new sap.m.Text({
					text: {
						path: 'oRigDailyOpModel>RigMovHrs',
						formatter: this.formatDailyOpHrs
					}
				})
			});
			oTable.addColumn(oColumn);
			oColumn = new sap.ui.table.Column({
				width: '11.5em',
				sortProperty: "RigMaintHrs",
				filterProperty: "RigMaintHrs",
				label: new sap.m.Label({
					text: "Rig Maintenance Hours",
					tooltip: "Rig Maintenance Hours"
				}),
				template: new sap.m.Text({
					text: {
						path: 'oRigDailyOpModel>RigMaintHrs',
						formatter: this.formatDailyOpHrs
					}
				})
			});
			oTable.addColumn(oColumn);

			oColumn = new sap.ui.table.Column({
				width: '11.5em',
				sortProperty: "RigRepairHrs ",
				filterProperty: "RigRepairHrs ",
				label: new sap.m.Label({
					text: "Rig Repair Hours",
					tooltip: "Rig Repair Hours"
				}),
				template: new sap.m.Text({
					text: {
						path: 'oRigDailyOpModel>RigRepairHrs',
						formatter: this.formatDailyOpHrs
					}
				})
			});
			oTable.addColumn(oColumn);

			oColumn = new sap.ui.table.Column({
				width: '11em',
				sortProperty: "RigSuspHrs",
				filterProperty: "RigSuspHrs",
				label: new sap.m.Label({
					text: "Rig Suspended Hours",
					tooltip: "Rig Suspended Hours"
				}),
				template: new sap.m.Text({
					text: {
						path: 'oRigDailyOpModel>RigSuspHrs',
						formatter: this.formatDailyOpHrs
					}
				})
			});
			oTable.addColumn(oColumn);

			oColumn = new sap.ui.table.Column({
				width: '11.5em',
				sortProperty: "RigWaitOnHrs",
				filterProperty: "RigWaitOnHrs",
				label: new sap.m.Label({
					text: "Rig Waiting Hours",
					tooltip: "Rig Waiting Hours"
				}),
				template: new sap.m.Text({
					text: {
						path: 'oRigDailyOpModel>RigWaitOnHrs',
						formatter: this.formatDailyOpHrs
					}
				})
			});
			oTable.addColumn(oColumn);

			oColumn = new sap.ui.table.Column({
				width: '10em',
				sortProperty: "RigOprHrs",
				filterProperty: "RigOprHrs",
				label: new sap.m.Label({
					text: "Rig Operating Hours",
					tooltip: "Rig Operating Hours"
				}),
				template: new sap.m.Text({
					text: {
						path: 'oRigDailyOpModel>RigOprHrs',
						formatter: this.formatDailyOpHrs
					}
				})
			});
			oTable.addColumn(oColumn);
			oColumn = new sap.ui.table.Column({
				width: '10.5em',
				sortProperty: "RigLstmHrs",
				filterProperty: "RigLstmHrs",
				label: new sap.m.Label({
					text: "Rig lost Time Hours",
					tooltip: "Rig lost Time Hours"
				}),
				template: new sap.m.Text({
					text: {
						path: 'oRigDailyOpModel>RigLstmHrs',
						formatter: this.formatDailyOpHrs
					}
				})
			});
			oTable.addColumn(oColumn);
			oColumn = new sap.ui.table.Column({
				width: '8.7em',
				sortProperty: "RigTotHrs",
				filterProperty: "RigTotHrs",
				label: new sap.m.Label({
					text: "Rig Total Hours",
					tooltip: "Rig Total Hours"
				}),
				template: new sap.m.Text({
					text: {
						path: 'oRigDailyOpModel>RigTotHrs',
						formatter: this.formatDailyOpHrs
					}
				})
			});
			oTable.addColumn(oColumn);
			oColumn = new sap.ui.table.Column({
				width: '10em',
				sortProperty: "RigMoveDis",
				filterProperty: "RigMoveDis",
				label: new sap.m.Label({
					text: "Rig Moved Distance",
					tooltip: "Rig Moved Distance"
				}),
				template: new sap.m.Text({
					text: '{oRigDailyOpModel>RigMoveDis}'
				})
			});
			oTable.addColumn(oColumn);

			//debugger;
		},
		getRigDailyOperations: async function (oReqHdrData) {
			var that = this;
			var oTable = this.getView().byId("rigDailyOpTable");
			var aFilters = [
				new sap.ui.model.Filter("WRigCd", "EQ", oReqHdrData.Rigno),
				new sap.ui.model.Filter("WGnrName", "EQ", oReqHdrData.Wellnm),
				new sap.ui.model.Filter("WActDt", "BT", oReqHdrData.EstSdt, oReqHdrData.EstEdt)
			];
			//this.busyDialog.open();
			var aJobLogDetails;
			var aColumns = [];
			try {
				aJobLogDetails = await this.getJobLogDetails();
				if (aJobLogDetails && aJobLogDetails.length > 0) {
					aJobLogDetails.forEach(e => {
						var sColumn = aColumns.find(x => x === e.JobId + "_" + e.Zeile);
						if (!sColumn) {
							var oColumn = new sap.ui.table.Column({
								width: '13em',
								hAlign: 'Center',
								label: new sap.m.Label({
									text: e.ServiceDesc,
									tooltip: e.ServiceDesc
								}).addStyleClass("detail-column"),
								template: new sap.m.Text({
									text: {
										parts: [`oRigDailyOpModel>${e.JobId + "_" + e.Zeile}`, `oRigDailyOpModel>${e.JobId + "_" + e.Zeile + "_Unit"}`],
										formatter: this.formatDetailColumns
									}
								}).addStyleClass("detail-column-text")
							});
							//oColumn.addStyleClass("detail-column");
							oTable.addColumn(oColumn);
							aColumns.push(e.JobId + "_" + e.Zeile);
						}

					});
				}
			} catch (ex) {
				aJobLogDetails = [];
			}
			var oDateFormat = DateFormat.getDateInstance({
				format: "yyyyMMdd"
			});
			this.getView().byId("rigDailyOpTable").setBusy(true);
			this.getView().getModel("VendorService").read("/RigDailyOperationSet", {
				filters: aFilters,
				success: function (oData) {
					that.calculateRigDailyOperationTotals(oData);
					if (aJobLogDetails && aJobLogDetails.length > 0) {
						var oTotal = [];
						var oTotalObject = {};
						oData.results.forEach(e => {
							if (e.TotalFlg !== "X") {
								aJobLogDetails.forEach(detailItem => {
									if (oDateFormat.format(e.WActDt) === oDateFormat.format(detailItem.Mrdate) && e.WGnrName === detailItem.WGnrName) {
										e[detailItem.JobId + "_" + detailItem.Zeile] = detailItem.QtyVol;
										e[detailItem.JobId + "_" + detailItem.Zeile + "_" + "Unit"] = detailItem.Unit;

										if (!oTotal[detailItem.WGnrName + "_" + detailItem.JobId + "_" + detailItem.Zeile]) {
											oTotal[detailItem.WGnrName + "_" + detailItem.JobId + "_" + detailItem.Zeile] = 0;
										}
										oTotal[detailItem.WGnrName + "_" + detailItem.JobId + "_" + detailItem.Zeile] += parseFloat(detailItem.QtyVol);

										oTotalObject[detailItem.WGnrName + "_" + detailItem.JobId + "_" + detailItem.Zeile] = {
											wellName: detailItem.WGnrName,
											propertyName: detailItem.JobId + "_" + detailItem.Zeile,
											propertyUnit: detailItem.Unit,
											total: oTotal[detailItem.WGnrName + "_" + +
												detailItem.JobId + "_" + detailItem.Zeile]
										}
									}
								});
							}

						});
					}

					for (var x = 0; x < oData.results.length; x++) {
						if (oData.results[x].TotalFlg === "X") {
							for (const property in oTotalObject) {

								if (oTotalObject[property].wellName === oData.results[x].WGnrName) {
									oData.results[x][oTotalObject[property].propertyName] = oTotalObject[property].total;
									oData.results[x][oTotalObject[property].propertyName + "_" + "Unit"] = "";
									///oData.results[x][oTotalObject[property].propertyName + "_" + "Unit"] = "";	
								}

							}
						}

					}
					//that.populateJobLogData(oData);
					that.getView().setModel(new JSONModel(oData), "oRigDailyOpModel");
					that.getView().byId("rigDailyOpTable").setBusy(false);
				},
				error: function (oError) {
					that.getView().byId("rigDailyOpTable").setBusy(false);
					//this.busyDialog.close();	
				}
			});
		},

		getGroup: function (oContext) {
			return oContext.getProperty('WGnrName');
		},

		/*&&&
    getGroupHeader: function (oGroup) {
&&&&&&&
        return new sap.m.GroupHeaderListItem({
            title : 'WGnrName'
        });
    },
		*/
		/*populateJobLogData: function (oData) {
			var aJoblogDetails = this.getView().getModel("oJobLogDetailsModel").getData(oData);
			
			var oTempDOData;
			
			var aUniqueJoblogItems = this.getUniqueJoblogItems(aJoblogDetails);
			
			
			for(var x=0; x<oData.length; x++){
				oTempDOData = oData[x];
			}
		
		},
		getUniqueJoblogItems: function (oData) {
			for (const property in oData) {
				debugger;
			  console.log(property = oData[property]);
			}
		},*/
		calculateRigDailyOperationTotals: function (oData) {
			var iRigStandByHours = 0;
			var iRigMobileHours = 0;
			var iRigDemobHours = 0;
			var iRigMaintHours = 0;
			var iRigSuspHours = 0;
			var iRigOperHours = 0;
			var iRigLostTimeHours = 0;
			var iRigTotalHours = 0;
			var iRigMoveHours = 0;
			oData.results.forEach(e => {
				if (e.TotalFlg !== "X") {
					iRigStandByHours += parseFloat(e.RigStnbyHrs);
					iRigMobileHours += parseFloat(e.RigMobileHrs);
					iRigDemobHours += parseFloat(e.RigDemHrs);
					iRigMaintHours += parseFloat(e.RigMaintHrs);
					iRigSuspHours += parseFloat(e.RigSuspHrs);
					iRigOperHours += parseFloat(e.RigOprHrs);
					iRigLostTimeHours += parseFloat(e.RigLstmHrs);
					iRigTotalHours += parseFloat(e.RigTotHrs);
					iRigMoveHours += parseFloat(e.RigMovHrs);
				}

			});

			this.getView().getModel("oRigDailyOpTotals").setData({
				RigStandByHours: iRigStandByHours.toFixed(2),
				RigMaintHours: iRigMaintHours.toFixed(2),
				RigSuspHours: iRigSuspHours.toFixed(2),
				RigOperHours: iRigOperHours.toFixed(2),
				RigLostTimeHours: iRigLostTimeHours.toFixed(2),
				RigTotalHours: iRigTotalHours.toFixed(2),
				RigMoveHours: iRigMoveHours.toFixed(2)
			});
		},
		getJobLogDetails: function () {
			var that = this;
			return new Promise((resolve, reject) => {
				this.summarySheet = false;
				var aFilter = [];
				var oReportsOdataModel = that.getView().getModel("oReportsOdataModel");
				if (that.DrssNo !== "") {
					var oDocFilter = new sap.ui.model.Filter("Docno", "EQ", that.DrssNo);
					aFilter.push(oDocFilter);
				} else {
					return sap.m.MessageBox.error("Service Order Number was not found to get the job log details");
				}
				oReportsOdataModel.read("/JobLogDetailsSet", {
					filters: aFilter,
					success: function (oData) {
						that.getView().getModel("oJobLogDetailsModel").setData(oData);
						resolve(oData.results);
					},
					error: function (oResponse) {
						this.getView().setBusy(false);
						if (oResponse.responseText) {
							var parsedJson = JSON.parse(oResponse.responseText);
							sap.m.MessageBox.error(parsedJson.error.message.value);
						}
						reject(oResponse);
					}
				});
			});
		},
		formatDailyOpHrs: function (sValue) {
			return parseFloat(sValue) === 0 ? '' : sValue + " (H) ";

		},
		formatDetailColumns: function (sValue, sUnit) {
			if (sUnit !== "") {
				return sValue ? sValue + " (" + sUnit + ")" : "";
			} else {
				return sValue ? sValue + "" : "";
			}

		},
		createRigDailyOpColumnConfig: function () {
			var aCols = [

				{
					label: 'Well Name',
					property: 'WGnrName',
					type: EdmType.String,
					scale: 0
				}, {
					label: 'Operation Date',
					property: 'WActDt',
					type: EdmType.Date,
					scale: 0
				}, {
					label: 'Version',
					property: 'Version',
					type: EdmType.String
				}, {
					label: 'Well Charge No.',
					property: 'EpChrAcNum',
					type: EdmType.String
				}, {
					label: 'Shore Type',
					property: 'RigLocName',
					type: EdmType.String
				}, {
					label: 'Rig Standby Hours',
					property: 'RigStnbyHrs',
					type: EdmType.String
				}, {
					label: 'Rig Move Hours',
					property: 'RigMovHrs',
					type: EdmType.String
				}, {
					label: 'Rig Maintenance Hours',
					property: 'RigMaintHrs',
					type: EdmType.String
				}, {
					label: 'Rig Suspended Hours',
					property: 'RigSuspHrs',
					type: EdmType.String
				}, {
					label: 'Rig Operating Hours',
					property: 'RigOprHrs',
					type: EdmType.String
				}, {
					label: 'Rig lost Time Hours',
					property: 'RigLstmHrs',
					type: EdmType.String
				}, {
					label: 'Rig Total Hours',
					property: 'RigTotHrs',
					type: EdmType.String
				}, {
					label: 'Rig Moved Distance',
					property: 'RigMoveDis',
					type: EdmType.String
				},
			];
			var aDetailCols = [];
			var oJobLogDetailsModel = this.getView().getModel("oJobLogDetailsModel");
			if (oJobLogDetailsModel.getData().results) {
				oJobLogDetailsModel.getData().results.forEach(e => {
					var sColumn = aDetailCols.find(x => x === e.JobId + "_" + e.Zeile);
					if (!sColumn) {
						aCols.push({
							label: e.ServiceDesc,
							property: e.JobId + "_" + e.Zeile,
							type: EdmType.String
						});
						aDetailCols.push(e.JobId + "_" + e.Zeile);
					};
				});
			}

			return aCols;
		},

		onExportRigDailyOp: function (evt) {
			/*	var oTable = this.byId('rigDailyOpTable');
				var oBinding = this.getModel("oRigDailyOpModel").getData().results;*/

			var tbl = this.byId("rigDailyOpTable");
			var cols = tbl.getColumns();
			var selectedIndices = tbl.getBinding("rows").aIndices;
			var oModelList = tbl.getBinding('rows')['oList'];
			var selectedEntries = [];
			var tableData = oModelList
			for (var index = 0; index < selectedIndices.length; index++) {
				var tableIndex = selectedIndices[index];
				var tableRow = tableData[tableIndex];
				selectedEntries.push(tableRow);
			}
			this.onExportRigOperationTable(selectedEntries, cols, tbl);

		},

		onExportRigOperationTable: function (aItems, oCols, tbl) {
			var html = "<table style='border: 1px solid black; border-collapse: collapse;font-family:Calibri'>" +
				"<tbody>";
			for (var i = 0; i < oCols.length; i++) {
				var col = oCols[i];
				//var header = col.getHeader().getText();
				var header = col.getLabel().getText();
				html += "<th style='border: 1px solid black;background: mediumaquamarine;'>" + header + "</th>";
			}
			html += "</tr>";
			var cells = tbl.getRows()[0].getCells();
			if (tbl.getBinding("rows").oList.length > 0) {

				for (var i = 0; i < aItems.length; i++) {
					//	if (typeof tbl.getRows()[i] !== "undefined"){
					//	var cells = tbl.getBinding("rows").oList[i].getCells();
					html += "<tr>";
					var oItem = aItems[i];
					for (var j = 0; j < cells.length; j++) {
						var cell = cells[j];
						if (cell.mProperties.hasOwnProperty("text")) {
							//var oValue = cell.mProperties.text;
							var oValue = oItem[cell.getBinding("text").getPath()]
						}

						if (cell.getBinding("text").getPath() === "WActDt") {
							var oValue = oItem[cell.getBinding("text").getPath()].toLocaleString().split(',')[0];
						}

						if (typeof oValue === "undefined") {
							oValue = '';
						}

						/*if(cell.mProperties.hasOwnProperty("value")){
							var oValue = cell.getValue();
						}
						if(cell.mProperties.hasOwnProperty("selectedKey")){
							var oValue = cell.getSelectedItem().getBinding("text").getValue();
						}	
						if(cell.mProperties.hasOwnProperty("src")){
							var oValue = oItem.Remarks;
						}	
						*/

						if (oItem.TotalFlg === "X") {
							html += "<td style='border: 1px solid black;background: #e3ffa0 ;' style='border: 1px solid black;'>" + oValue + "</td>";
						} else {
							html += "<td style='border: 1px solid black;'>" + oValue + "</td>";
						}

					}
					html += "</tr>";
					//}
				}
			}

			html += "</tbody></table>";
			var excel = new ExportToExcel();
			var SrvtypText = "Venor " + this.getView().getModel("itemsModel").getData().SrvtypText;
			var Docno = "Venor " + this.getView().getModel("itemsModel").getData().Docno;

			var fileName = SrvtypText + "_" + Docno;
			excel.exportHTMLFormat(html, fileName);
		},

		/*onExportRigDailyOp: function() {
			var aCols, oBinding, oSettings, oSheet, oTable;

			oTable = this.byId('rigDailyOpTable');
			oBinding = this.getView().getModel("oRigDailyOpModel").getData().results;
			
			oBinding = oBinding.filter(items => items.TotalFlg !=="X");
			
			aCols = this.createRigDailyOpColumnConfig();

			oSettings = {
				workbook: {
					title: 'DILIP - Rig Daily Operations Export',
					sheetName: 'Rig Daily Operations',
					 columns: aCols
				 },
				dataSource: oBinding,
				fileName: "DILIP - Rig Daily Operations Export.xlsx"
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build()
				.then(function() {
					MessageToast.show('Spreadsheet export has finished');
				}).finally(function() {
					oSheet.destroy();
				});
		},*/
		MorningReport: function () {
			var oFilter = [new sap.ui.model.Filter("Docno", "EQ", this.itemDetails.DrssNo),
				new sap.ui.model.Filter("Mjahr", "EQ", this.itemDetails.Mjahr)
			];
			this.getView().setBusy(true);
			this.getView().getModel("VendorService").read("/MorningReportSet", {
				filters: oFilter,
				success: function (oData) {
					var MorningReportModel = new JSONModel(oData.results);
					this.getView().setModel(MorningReportModel, "MorningReportModel");
					this.getView().setBusy(false);
				}.bind(this),
				error: function (oError) {
					this.getView().setBusy(false);
				}.bind(this)
			});
		},
		onPressLostTimeHrs: function (oEvent) {
			var oView = this.getView();
			var oButton = oEvent.getSource();
			var that = this;
			// create popover
			if (!this._pLostTimePopover) {
				this._pLostTimePopover = Fragment.load({
					id: oView.getId(),
					name: "zdwo_nx_drss_ven.view.fragment.LostTimeHrs",
					controller: this
				}).then(function (oPopover) {
					oView.addDependent(oPopover);
					//oPopover.bindElement("/ProductCollection/0");
					return oPopover;
				});
			}
			this._pLostTimePopover.then(function (oPopover) {
				oPopover.openBy(oButton);
				that.getRigLostTimeData(oPopover);
			});
		},
		formatDate: function (oDate) {
			var oDateFormat = DateFormat.getDateInstance({
				format: "yyyyMMdd"
			});
			return oDateFormat.format(oDate);
		},
		formatNumber: function (sValue) {
			var iNumber = "";
			if (sValue) {
				var iNumber = sValue.replace(/^0+/, '');
			}
			return iNumber;
		},
		getRigLostTimeData: function (oPopover) {
			var oRigLostTimeModel = this.getView().getModel("oRigLostTimeModel");
			oRigLostTimeModel.setData([]);
			var oModel = this.getView().getModel("oReportsOdataModel");
			var oItemsModel = this.getView().getModel("itemsModel");
			var aFilters = [
				new sap.ui.model.Filter("WRigCd", "EQ", oItemsModel.getProperty("/Rigno")),
				new sap.ui.model.Filter("RspnsblSvcoCd", "EQ", "RIG"),
				new sap.ui.model.Filter("WDrlgOpDttm", "BT", oItemsModel.getProperty("/EstSdt"), oItemsModel.getProperty("/EstEdt"))
			];
			if (oPopover) {
				oPopover.setBusy(true);
			}
			oModel.read("/RigLostTimeSet", {
				filters: aFilters,
				success: function (data) {
					oPopover.setBusy(false);
					oRigLostTimeModel.setData(data);
				},
				error: function (oError) {
					if (oPopover) {
						oPopover.setBusy(false);
					}
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
				}
			});
		},

		emptyobject: function (oEvent) {
			var oLSSummaryModel = this.getView().getModel("oLSSummaryModel");
			var total1 = this.totalSummaryCost(oEvent);
			var summaryArray = [];
			const finalSummaryArray = [];
			var months = ["Jan'", "Feb'", "Mar'", "Apr'", "May'", "Jun'", "Jul'", "Aug'", "Sept'", "Oct'", "Nov'", "Dec'"];
			for (var i = 0; i < oEvent.length; i++) {
				var chartObject = {
					"ContRef": "",
					"Month": "",
					"Currency": "",
					"Discounts": "0.000",
					"Docno": "",
					"GrandTotal": "0.000",
					"Jlstatus": "",
					"JobLog": "",
					"JobLogDesc": "",
					"Sdate": null,
					"ServiceDesc": "",
					"Surcharge": "0.000",
					"TotNetValue": "0.000",
					"TotalAmount": "0.000",
					"TotalQty": "0.000",
					"Unit": "",
					"UnitPrice": "0.000",
					"ColTotalQty": "0.000",
					"ColTotalAmount": "0.000",
					"ColName": ""
				}

				if (oEvent[i].Mrdate) {
					var Day = months[oEvent[i].Mrdate.getMonth()] + oEvent[i].Mrdate.getDate();
					chartObject[Day] = oEvent[i].TotalQty;
					chartObject.Month = months[oEvent[i].Mrdate.getMonth()];
					chartObject.ColName = months[oEvent[i].Mrdate.getMonth()] + oEvent[i].Mrdate.getDate();
				}

				//chartObjectHdr[Day] = true;
				chartObject.ContRef = oEvent[i].ContRef;
				chartObject.Discounts = oEvent[i].Discounts;
				chartObject.Docno = oEvent[i].Docno;
				chartObject.GrandTotal = oEvent[i].GrandTotal;
				chartObject.Jlstatus = oEvent[i].Jlstatus;
				chartObject.JobLog = oEvent[i].JobLog;
				chartObject.JobLogDesc = oEvent[i].JobLogDesc;
				chartObject.Sdate = oEvent[i].Sdate;
				chartObject.ServiceDesc = oEvent[i].ServiceDesc;
				chartObject.Surcharge = oEvent[i].Surcharge;
				chartObject.TotNetValue = oEvent[i].TotNetValue;
				chartObject.TotalAmount = oEvent[i].TotalAmount;
				chartObject.TotalQty = oEvent[i].TotalQty;
				chartObject.Unit = oEvent[i].Unit;
				chartObject.UnitPrice = oEvent[i].UnitPrice;
				chartObject.Currency = oEvent[i].Currency;

				chartObject.Qty = oEvent[i].TotalQty;
				chartObject.Amount = oEvent[i].TotalAmount;
				chartObject.StartDate = oEvent[i].StartDate;
				chartObject.StartTime = oEvent[i].StartTime;
				chartObject.EndDate = oEvent[i].EndDate;
				chartObject.EndTime = oEvent[i].EndTime;
				chartObject.MrDate = oEvent[i].Mrdate;
				chartObject.MrEndDate = oEvent[i].MrEndDate;

				chartObject.Zeile = oEvent[i].Zeile;
				chartObject.JobId = oEvent[i].JobId;
				summaryArray.push(chartObject);

				finalSummaryArray.push(chartObject);

			}

			oLSSummaryModel.setProperty("/aUniqueColumns", finalSummaryArray);
			oLSSummaryModel.setProperty("/aRows", finalSummaryArray);

			//			if(!this.oLumpSumTableFragment) {
			//				this.oLumpSumTableFragment = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.OC.LumpSumTable", this);
			//				this.getView().addDependent(this.oLumpSumTableFragment);	
			//			}
			//			this.oLumpSumTableFragment.open();
			//			this.oLumpSumTableFragment.close();

			var uniqueArray = summaryArray.reduce((filter, current) => {
				var dk = filter.find(item => (item.Zeile === current.Zeile && item.JobId === current.JobId));
				if (!dk) {
					return filter.concat([current]);
				} else {

					var TotalQty = parseFloat(dk.TotalQty);
					var Qty = parseFloat(dk.Qty);
					TotalQty += parseFloat(current.TotalQty);
					var TotalAmount = parseFloat(dk.TotalAmount);
					TotalAmount += parseFloat(current.TotalAmount);
					/*var Day = 0;
					for(var j=1;j<=31;j++){
					&&&
					}*/
					var value = current.ColName;
					Day = this.numberfunction(dk[value]);
					Day += this.numberfunction(current[value]);
					dk[value] = (Day).toFixed(2);
					/*if(this.formatStringDateAramco(current.MrDate) === this.formatStringDateAramco(current.EndDate)){
						dk.Qty = (Day).toFixed(2);
					}*/
					dk.Qty = (Qty).toFixed(2);
					/*dk.TotalQty = (TotalQty).toFixed(2);*/
					dk.TotalQty = (TotalQty).toFixed(3);
					dk.TotalAmount = (TotalAmount).toFixed(2);
					return filter;
				}
			}, []);

			var ColoumnUniqueArray = summaryArray.reduce((filter, current) => {
				var cdk = filter.find(item => (item.Zeile === current.Zeile && item.JobId === current.JobId && item.ColName === current.ColName));
				if (!cdk) {
					return filter.concat([current]);
				} else {
					return filter;
				}
			}, []);

			//oLSSummaryModel.setProperty("/aUniqueColumns", ColoumnUniqueArray);
			//oLSSummaryModel.setProperty("/aRows", ColoumnUniqueArray);

			this.aUniqueSummaryColomns = ColoumnUniqueArray;
			// console.log(ColoumnUniqueArray)
			//// console.log(chartObjectHdr);
			//chartObjectHdr.TableData = uniqueArray;
			/*			this.getView().getModel("oSummaryReportModelPerDay").setData(null);
						this.getView().getModel("oSummaryReportModelPerDay").setData(uniqueArray);
						this.getView().getModel("oSummaryReportModelPerDay").refresh(true);*/

			//oLSSummaryModel.setProperty("/aRows",uniqueArray);
			/*
						var total = this.totalSummaryCost(uniqueArray);

						var userInfoModel = this.getView().getModel("UserInfoModel");*/

		},

		_getFinalDataModel: function () {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			this.summarySheet = false;
			var aFilter = [];
			var oReportsOdataModel = this.getView().getModel("oReportsOdataModel");
			//if (this.DrssNo !== "") {
			var oItemsModel = this.getView().getModel("itemsModel").getData();
			var oDocFilter = new sap.ui.model.Filter("Docno", "EQ", oItemsModel['Docno']);
			aFilter.push(oDocFilter);
			//	}
			var selectModel = this.getModel("SelectModel").getProperty("/JLSTATUS");
			for (var i = 0; i < selectModel.length; i++) {
				aFilter.push(new sap.ui.model.Filter("Jlstatus", "EQ", selectModel[i].Value1));
			}
			var JobLogType = controller.aJLConfigTypes;
			for (var i = 0; i < controller.aJLConfigTypes.length; i++) {
				aFilter.push(new sap.ui.model.Filter("JobLog", "EQ", JobLogType[i].id));
			}
			oReportsOdataModel.read("/JobLogDetailsSet", {
				filters: aFilter,
				success: function (oData) {
					var aSummaryDetailsData = oData.results;
					var aTransprtations = aSummaryDetailsData.filter(x => x.JobLog === "JL0002");
					var aOthers = aSummaryDetailsData.filter(x => x.JobLog !== "JL0002");
					var sortedSDData = $.merge(aTransprtations, aOthers);
					var aJobLogTypesBasedStructure = [];
					sortedSDData.forEach(e => {
						if (!aJobLogTypesBasedStructure.find(x => x.JobLog === e.JobLog)) {
							aJobLogTypesBasedStructure.push({
								JobLog: e.JobLog,
								JobLogDesc: e.JobLogDesc,
								content: [],
								bIsGrouping: true,
								Jlstatus: "empty"
							});
						}
					});
					for (var i = 0; i < aJobLogTypesBasedStructure.length; i++) {
						sortedSDData.forEach(e => {
							if (aJobLogTypesBasedStructure[i].JobLog === e.JobLog) {
								aJobLogTypesBasedStructure[i].content.push(e);
							}
						});
					}
					this.getView().getModel("oSummaryReportModelDetail").setData(aSummaryDetailsData);
					var JL0001 = 0;
					var JL0002 = 0;
					var JL0003 = 0;
					var JL0004 = 0;
					var JL0005 = 0;
					var APRV = 0;
					var SUBT = 0;
					var REJC = 0;
					if (oData.results.length > 0) {
						for (var i = 0; i < oData.results.length; i++) {
							switch (oData.results[i].JobLog) {
							case "JL0001":
								JL0001 += parseInt(1)
								break;
							case "JL0002":
								JL0002 += parseInt(1)
								break;
							case "JL0003":
								JL0003 += parseInt(1)
								break;
							case "JL0004":
								JL0004 += parseInt(1)
								break;
							case "JL0005":
								JL0005 += parseInt(1)
								break;
							default:
								break;
							}
							switch (oData.results[i].Jlstatus) {
							case "APRV":
								APRV += parseInt(1)
								break;
							case "SUBT":
								SUBT += parseInt(1)
								break;
							case "REJC":
								REJC += parseInt(1)
								break;
							default:
								break;
							}
						}
					}
					busyDialog.close();

				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			})

			//// for summary Report
			//	var aFilter = [];
			oReportsOdataModel.read("/JobLogSmrySet", {
				filters: aFilter,
				success: function (oData) {
					var JL0001 = 0;
					var JL0002 = 0;
					var JL0003 = 0;
					var JL0004 = 0;
					var JL0005 = 0;
					var APRV = 0;
					var SUBT = 0;
					var REJC = 0;
					if (oData.results.length > 0) {
						for (var i = 0; i < oData.results.length; i++) {
							switch (oData.results[i].JobLog) {
							case "JL0001":
								JL0001 += parseInt(1)
								break;
							case "JL0002":
								JL0002 += parseInt(1)
								break;
							case "JL0003":
								JL0003 += parseInt(1)
								break;
							case "JL0004":
								JL0004 += parseInt(1)
								break;
							case "JL0005":
								JL0005 += parseInt(1)
								break;
							default:
								break;
							}

							switch (oData.results[i].Jlstatus) {
							case "APRV":
								APRV += parseInt(1)
								break;
							case "SUBT":
								SUBT += parseInt(1)
								break;
							case "REJC":
								REJC += parseInt(1)
								break;
							default:
								break;
							}

						}
					}
					this.emptyobject(oData.results);
				}.bind(this),
				error: function (oResponse) {
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}
				}.bind(this),
			});
		},

		_getJobLoggingServiceConfig: function () {
			var itemsModel = this.getModel("itemsModel");
			if (itemsModel) {
				var oDocNo = itemsModel.getProperty("/Docno");
				var oSrvtyp = itemsModel.getProperty("/SrvtypeCode");
			}

			if (!oSrvtyp) {
				oSrvtyp = this.Srvtype;
			}
			var oModel = this.getView().getModel("VendorService");
			var getJLcfg = new Promise(function (resolve, reject) {
				oModel.read("/JobLoggingServiceSet(ServiceType='" + oSrvtyp + "')", {
					urlParameters: {
						"$expand": "ServiceToJobLogNav"
					},
					success: function (oData) {
						// Get the JL configuration
						if (oData.ServiceToJobLogNav.results.length > 0) {
							controller.aJLConfigTypes = [];
							var getData = oData.ServiceToJobLogNav.results;
							$.each(getData, function (ind, obj) {
								if (obj.JobLogDesc !== "")
									var oJLObj = {
										id: obj.JobLog,
										desc: obj.JobLogDesc
									};
								controller.aJLConfigTypes.push(oJLObj);
							}.bind(this))
						}
						var JobLogCfgModel = new JSONModel(oData.ServiceToJobLogNav.results);
						this.getView().setModel(JobLogCfgModel, "JobLogCfgModel");

						resolve();
					}.bind(this),
					error: function (error) {
						var msgs = this.getErrorMessages(error);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();
						reject();
					}.bind(this)
				});
			}.bind(this));
			return getJLcfg;
		},

		_getJobLoggingData: function () {
			var oItemsModel = this.getView().getModel("itemsModel");
			if (oItemsModel) {
				var oDocNo = oItemsModel.getProperty("/Docno");
				//var oMjahr = oItemsModel.getProperty("/Mjahr");
			}
			var busyDialog = new sap.m.BusyDialog({
				title: 'Processing...'
			});
			busyDialog.open();
			this.Version = '0';
			var getJobLogging = new Promise(function (resolve, reject) {
				if (this.Version !== '' && this.Version !== '0') {
					var oFilter = [new sap.ui.model.Filter("Version", "EQ", this.Version)];
				} else {
					var oFilter = [];
				}
				this.Mjahr
				var oModel = this.getView().getModel("VendorService");
				oModel.read("/JobLoggingSet(Docno='" + oDocNo + "',Mjahr='" + this.Mjahr + "')", {
					urlParameters: {
						"$expand": "DRSSJobLoggingNAV,JobLoggingServiceDataNAV,JobLoggingNAV,TimesheetNAV"
					},
					filters: oFilter,
					success: function (oData) {
						var Inbox = 0;
						var Rejected = 0;
						var Approved = 0;
						var All = 0;
						//Begin of Addition for CAD Deductions
						var data = this.getView().getModel("JobLogCfgModel").getData();
						var results = "";
						var obj = oData.JobLoggingNAV.results[0];
						for (var i = 0; i < oData.JobLoggingServiceDataNAV.results.length; i++) {
							obj.Docno = oData.Docno;
							obj.Mjahr = oData.Mjahr;
							obj.Zeile = oData.Zeile;
							oData.JobLoggingServiceDataNAV.results[i].nodes = [obj];
						}
						var oTableItems = this.getView().getModel("JobLogFinalDataModel").getData();
						oTableItems.sort(function (a, b) {
							return a.Sno - b.Sno
						});
						//End of Addition for CAD Deductions		
						let limit = oData.JobLoggingNAV.results.length + oData.JobLoggingServiceDataNAV.results.length + oData.DRSSJobLoggingNAV.results
							.length;
						var oJsonModel = new JSONModel(oData);
						oJsonModel.setSizeLimit(limit);
						this.getView().setModel(oJsonModel, "JobLogModelPDF");
						this.getView().getModel("JobLogFinalDataModel").setData(null);
						this.getView().getModel("JobLogFinalDataModel").setData(oData.DRSSJobLoggingNAV.results);
						this.getView().getModel("oTSModel").setData(oData.TimesheetNAV.results);
						this.getView().getModel("JobLogFinalDataModel").setSizeLimit(limit);
						this.getView().getModel("JobLogFinalDataModel").refresh(true);
						busyDialog.close();
						resolve();
					}.bind(this),
					error: function (error) {
						busyDialog.close();
						reject();
						var msgs = this.getErrorMessages(error);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();

					}.bind(this)
				});
			}.bind(this));
			return getJobLogging;
		},

		onGetConsPDFData: function () {
			var oItemsModel = this.getView().getModel("itemsModel");
			if (oItemsModel) {
				var oDocNo = oItemsModel.getProperty("/Docno");
				var oMjahr = oItemsModel.getProperty("/Mjahr");
				var oSrvtyp = oItemsModel.getProperty("/Srvtyp");
			}

			this._loadPDFConfig();
			this._getOperationalReport();
			this._MrDateRel(oDocNo, oMjahr, oSrvtyp);

		},

		_loadPDFConfig: function (oEvent) {
			var oReportsOdataModel = this.getView().getModel("oReportsOdataModel");
			oReportsOdataModel.read("/PDFJoblogSummarySet", {
				success: function (oData) {
					oData = oData.results;
					this.getView().getModel("oPDFMappingModel").setData(oData);
				}.bind(this),
				error: function (oResponse) {
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}
				}.bind(this)
			});
		},

		_MrDateRel: function (Docno, Mjahr, SrvtypeCode) {

			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			var SrvtypeCode = this.getOwnerComponent().getModel("itemsModel").getObject("/SrvtypeCode");
			var oDataModel = this.getView().getModel("VendorService");
			oDataModel.read("/JobLoggingMrRelSet(Docno='" + Docno + "',Mjahr='" + Mjahr + "',SrvtypeCode='" + SrvtypeCode + "')", {
				success: function (oData) {
					this.getView().getModel("MrDateRelModel").setData(oData);
					//   this._checkConsPdfBtnVisibility();
					busyDialog.close();
				}.bind(this),
				error: function (oError) {
					busyDialog.close();
				}.bind(this)
			});
		},
		// F4 Model
		_getOperationalReport: function () {
			this.setModel(new JSONModel([]), "F4Models");
			//Holds LubSum enabled table data
			var oDataModel = this.getView().getModel("oDataModel");
			oDataModel.read("/F4SearchHelpSet", {
				filters: [new sap.ui.model.Filter("Field", "EQ", 'JOB_LOG_OPE')],
				success: function (oData) {
					oData = oData.results;
					this.getModel("F4Models").setData(oData);
					this.getModel("F4Models").refresh();
				}.bind(this),
				error: function (oError) {}.bind(this)
			});

		},

		onPressRequestForCancellation: function (oEvent) {
			var oTextArea = new sap.m.TextArea({
				width: "100%",
				placeholder: "Remarks (required)",
				liveChange: function (oEvent) {
					this.sText = oEvent.getParameter("value");
					this.oSubmitDialog.getBeginButton().setEnabled(this.sText.length > 0);
				}.bind(this)
			});
			this.oSubmitDialog = new sap.m.Dialog({
				type: sap.m.DialogType.Message,
				title: "Confirm",
				content: [
					new sap.m.Label({
						text: "Do you want to continue ?",
						labelFor: "submissionNote"
					}),
					oTextArea
				],
				beginButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: "Submit",
					enabled: false,
					press: function (evt) {
						this.applyRequestForCancellation(oTextArea.getProperty("value"));
					}.bind(this)
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function () {
						this.oSubmitDialog.close();
					}.bind(this)
				})
			});
			this.oSubmitDialog.open();
		},

		applyRequestForCancellation: function (sComments) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Updating...'
			});
			busyDialog.open();
			var oModel = this.getView().getModel("VendorService");
			oModel.callFunction("/VendorRequest", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr,
					Flag: 'C',
					Comments: sComments
				},
				success: function (oData) {
					busyDialog.close();
					MessageBox.success("Request submitted for cancellation successfully", {
						actions: [MessageBox.Action.CLOSE],
						onClose: function () {
							this.oSubmitDialog.close();
							this.onPageRefresh();
						}.bind(this)
					});

				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		onPressRecallCancellation: function (oEvent) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Updating...'
			});
			busyDialog.open();
			var oModel = this.getView().getModel("VendorService");
			oModel.callFunction("/VendorRequest", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr,
					Flag: 'R',
					Comments: ''
				},
				success: function (oData) {
					busyDialog.close();
					MessageBox.success("Request for cancellation recalled successfully", {
						actions: [MessageBox.Action.CLOSE],
						onClose: function () {
							this.onPageRefresh();
						}.bind(this)
					});

				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		formateReqForCancellationBtn: function (bReqReject, sCancel) {
			return (bReqReject !== 'X' && sCancel === true);
		},
		formateRecallCancellationBtn: function (bReqReject, sCancel) {
			return (bReqReject === 'X' && sCancel === true);
		}
	});
});