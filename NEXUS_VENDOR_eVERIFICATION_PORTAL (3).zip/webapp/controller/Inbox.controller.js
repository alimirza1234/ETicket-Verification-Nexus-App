var controller;
sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/m/library",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/ui/Device',
	'sap/ui/model/Sorter',
	'sap/m/Menu',
	'sap/m/MenuItem',
	'sap/ui/core/Fragment',
	'sap/ui/core/util/Export',
	'sap/ui/core/util/ExportTypeCSV',
	'sap/ui/export/library',
	'sap/ui/export/Spreadsheet',
	"zdwo_nx_drss_ven/utils/ExportToExcel",
	"sap/m/MessageBox",
], function (BaseController, JSONModel, formatter, mobileLibrary, Filter, FilterOperator, Device, Sorter, Menu, MenuItem, Fragment,
	Export, ExportTypeCSV, exportLibrary, Spreadsheet, ExportToExcel, MessageBox) {

	// shortcut for sap.m.URLHelper
	var URLHelper = mobileLibrary.URLHelper;
	var EdmType = exportLibrary.EdmType;
	return BaseController.extend("zdwo_nx_drss_ven.controller.Inbox", {

		formatter: formatter,
		onInit: function () {
			controller = this;
			this.aSelectedTabFilters = [];
			this.aToFilter = [];

			var vendorReportModel = new JSONModel();
			this.getView().setModel(vendorReportModel, "vendorReportModel");
			var vendorFilterModel = new JSONModel();
			this.getView().setModel(vendorFilterModel, "vendorFilterModel");
			this._mViewSettingsDialogs = {};
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.getRouter().getRoute("Inbox").attachPatternMatched(this._onObjectMatched, this);
			var countModel = new JSONModel({
				Inbox: 0,
				Revised: 0,
				Accepted: 0,
				JobLogging: 0,
				Rejected: 0,
				eTicket: 0,

			});
			this.getView().setModel(countModel, "countModel");
		},
		Service: function (oEvent) {

			// Get the selected key from the ComboBox
			var sSelectedKey = oEvent.mParameters.value;

			// Get the Table and its binding
			var oTable = this.byId("drssRequestTable");
			var oBinding = oTable.getBinding("rows");

			// Create a new filter for the selected key
			var aFilters = [];
			if (sSelectedKey) {
				aFilters.push(new Filter("Etkt", FilterOperator.EQ, sSelectedKey));
			}

			// Apply the filter to the binding
			oBinding.filter(aFilters);

		},
		Rig: function (oEvent) {

			var sSelectedKey = oEvent.mParameters.value;
			var oTable = this.byId("drssRequestTable");
			var oBinding = oTable.getBinding("rows");
			var aFilters = [];
			if (sSelectedKey) {
				aFilters.push(new Filter("Rigno", FilterOperator.EQ, sSelectedKey));
			}
			oBinding.filter(aFilters);
		},
		Well: function (oEvent) {

			var sSelectedKey = oEvent.mParameters.value;
			var oTable = this.byId("drssRequestTable");
			var oBinding = oTable.getBinding("rows");
			var aFilters = [];
			if (sSelectedKey) {
				aFilters.push(new Filter("Wellnm", FilterOperator.EQ, sSelectedKey));
			}
			oBinding.filter(aFilters);
		},
		Contract: function (oEvent) {

			var sSelectedKey = oEvent.mParameters.value;
			var oTable = this.byId("drssRequestTable");
			var oBinding = oTable.getBinding("rows");
			var aFilters = [];
			if (sSelectedKey) {
				aFilters.push(new Filter("Konnr", FilterOperator.Contains, sSelectedKey));
			}
			oBinding.filter(aFilters);
		},
		onSearch: function (oEvent) {
			var sQuery = oEvent.getParameter("newValue");
			var aFilters = [];

			if (sQuery && sQuery.length > 0) {
				aFilters.push(new Filter({
					filters: [
						new Filter("Docno", FilterOperator.Contains, sQuery),
						new Filter("SrvtypText", FilterOperator.Contains, sQuery),
						new Filter("Rigno", FilterOperator.Contains, sQuery),
						new Filter("RigShrtName", FilterOperator.Contains, sQuery),
						new Filter("Wellnm", FilterOperator.Contains, sQuery),
						// Add more filters for other columns if needed
					],
					and: false
				}));
			}

			var oTable = this.byId("drssRequestTable");
			var oBinding = oTable.getBinding("rows");
			oBinding.filter(aFilters, "Application");
		},

		_onObjectMatched: function (oEvent) {

			controller = this;
			var oThis = this;

			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Sos = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Tvd = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Operations = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().NonCharge = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().rigMeals = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").refresh(true);
			this.selectJobType();
			//this.selectOrghCode();
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading Inbox Items...'
			});
			busyDialog.open();
			this.getView().getModel("oInboxModel").read("/InboxSet", {
				success: function (oData) {
			
					// oData.count = oData.results.length;
					// var Inbox = 0;
					// var Revised = 0;
					// var Accepted = 0;
					// var JobLogging = 0;
					// var Rejected = 0;
					// var Completed = 0;
					// var eTicket = 0;
					// for(var i=0;i<oData.count; i++){
					// 	oData.results[i].fontClass = "";
					// 	if((oData.results[i].NewItem === "VENDOR") && (oData.results[i].Rqstat !== 'INIT')){
					// 		oData.results[i].fontClass = "newItemFontClass";
					// 	}		

					// 	switch (oData.results[i].Tab) {
					// 	case "INBX":
					// 		Inbox += parseInt(1)	
					// 		break;
					// 	case "REVI":
					// 		Revised += parseInt(1)	
					// 		break;	
					// 	case "ACPT":
					// 		Accepted += parseInt(1)	
					// 		break;	
					// 	case "JOBL":
					// 		JobLogging += parseInt(1)	
					// 		break;	
					// 	case "ETKT":
					// 		eTicket += parseInt(1)	
					// 		break;
					// 	case "REJC":
					// 		Rejected += parseInt(1)	
					// 		break;		
					// 	case "COMP":
					// 		Completed += parseInt(1)	
					// 		break;		
					// 	default:
					// 		break;
					// 	}

					// 	oData.results[i].Reqdt = this.dateTimeJoiner(oData.results[i].Reqdt, oData.results[i].Reqtm);
					// 	oData.results[i].Actdate = this.dateTimeJoiner(oData.results[i].Actdate, oData.results[i].Acttime);
					// 	oData.results[i].Rqddt = this.dateTimeJoiner(oData.results[i].Rqddt, oData.results[i].Rqdtm);
					// }
					// this.getView().getModel("countModel").getData().Inbox = Inbox;
					// this.getView().getModel("countModel").getData().Revised = Revised;
					// this.getView().getModel("countModel").getData().Accepted = Accepted;
					// this.getView().getModel("countModel").getData().JobLogging = JobLogging;
					// this.getView().getModel("countModel").getData().Rejected = Rejected;
					// this.getView().getModel("countModel").getData().eTicket = eTicket;
					// this.getView().getModel("countModel").getData().Completed = Completed;
					// this.getView().getModel("countModel").refresh(true);
					var oJsonModel = new JSONModel(oData.results);
					var oCountModel = new JSONModel(oData);
					this.getView().setModel(oJsonModel, "InboxModel");
					this.getView().setModel(oCountModel, "InboxCountModel");
					//this.getView().getModel("InboxModel").setSizeLimit(oData.results.length);
					// if(navBackFlg === "X"){
					// 	this.onInboxModelSearch();
					// 	if(InboxSelectedTab){
					// 		this.getView().byId("idIconTabBar").setSelectedKey(InboxSelectedTab);
					// 		this.onFilterSelect();
					// 	}						
					// }else{
					// 	this.onFilterSelect();
					// }
					// navBackFlg = "";
					busyDialog.close();

				}.bind(this),
				error: function (oError) {
					busyDialog.close();
					MessageBox.success("Data Load Error");
					// this.getView().byId("inboxSearch").setValue("");
					// this.getRouter().navTo("notFound", {}, true);
				}.bind(this)
			});

			this.populateRadinessTable();
			this.populateVendorReportTable();
		},

		selectJobType: function () {
			var aFilters = [];
			aFilters.push(new Filter("Field", FilterOperator.EQ, "ZDWO_RDD_JOB_TYPE"));
			this.getView().getModel("VendorService").read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					this.getView().getModel("JobTypeeTicketModel").setData(null);
					this.getView().getModel("JobTypeeTicketModel").setData(oData.results);
					this.getView().getModel("JobTypeeTicketModel").refresh();
				}.bind(this),
				error: function (oResponse) {

				}.bind(this)
			});
		},

		dateTimeJoiner: function (oDate, oTime) {
			if (oDate === null || typeof oDate === "undefined" || oTime === null || typeof oTime === "undefined") {
				return;
			}
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			if (!isNaN(oTime)) {
				oDate.setMilliseconds(oTime + TZOffsetMs);
			}
			oDate.setMilliseconds(oTime.ms + TZOffsetMs);
			return oDate;
		},

		populateRadinessTable: function () {
			var that = this;

			this.getView().getModel("VendorService").read("/JobReqReadySet", {
				success: function (oData) {
					//oData.count = oData.results.length;
					//var oJsonModel = new JSONModel(oData.results);	
					//var oCountModel = new JSONModel(oData);	
					var oOpportunityModel = new JSONModel(oData.results);
					this.getView().setModel(oOpportunityModel, "oOpportunityModel");

					/*	that.getView().getModel("oOpportunityModel").setData(oData.results);
						that.getView().getModel("oOpportunityModel").refresh();*/

					/*	//this.getView().setModel(oCountModel, "InboxCountModel");
						if(navBackFlg === "X"){
							this.onInboxModelSearch();
							if(InboxSelectedTab){
								//this.getView().byId("idIconTabBar").setSelectedKey(InboxSelectedTab)
							}						
						}else{
							this.onFilterSelect();
						}*/
					//	navBackFlg = "";
					//busyDialog.close();
				}.bind(this),
				error: function (oError) {
					//	busyDialog.close();
					this.getView().byId("inboxSearch").setValue("");
					this.getRouter().navTo("notFound", {}, true);
				}.bind(this)
			});
		},

		populateVendorReportTable: function () {
			var that = this;

			this.getView().getModel("VendorService").read("/DRSSReportSet", {
				success: function (oData) {
					//oData.count = oData.results.length;
					//var oJsonModel = new JSONModel(oData.results);	
					//var oCountModel = new JSONModel(oData);	

					that.getView().getModel("vendorReportModel").setData(oData.results);

					var jsonData = {};
					/*var space = " ";
					jsonData[space] = "";*/

					oData.results.forEach(function (item) {
						jsonData[item.SrvtypText] = item.SrvtypText;

					});

					that.getView().getModel("vendorFilterModel").setData(jsonData);

					/*	//this.getView().setModel(oCountModel, "InboxCountModel");
						if(navBackFlg === "X"){
							this.onInboxModelSearch();
							if(InboxSelectedTab){
								//this.getView().byId("idIconTabBar").setSelectedKey(InboxSelectedTab)
							}						
						}else{
							this.onFilterSelect();
						}*/
					//	navBackFlg = "";
					//busyDialog.close();
				}.bind(this),
				error: function (oError) {
					//	busyDialog.close();
					// this.getView().byId("inboxSearch").setValue("");
					this.getRouter().navTo("notFound", {}, true);
				}.bind(this)
			});
		},
		onDetailNav: function (oEvent) {


			// this.getView().byId("inboxSearch").setValue("");
			var table = this.getView().byId("drssRequestTable");
			var iColCounter = 0;
			table.clearSelection();
			var iTotalCols = table.getColumns().length;
			var oListBinding = table.getBinding();
			if (oListBinding) {
				oListBinding.aSorters = null;
				oListBinding.aFilters = null;
			}
			table.getModel().refresh(true);

			for (iColCounter = 0; iColCounter < iTotalCols; iColCounter++) {
				table.getColumns()[iColCounter].setSorted(false);
				table.getColumns()[iColCounter].setFilterValue("");
				table.getColumns()[iColCounter].setFiltered(false);
			}

			if (oEvent.getParameter("rowContext")) {
				var Data = oEvent.getParameter("rowContext").getObject();
				if (Data.Gid === "") {
					Data.Gid = "0000";
				}
				if ((Data.Rqtype === "URWC") || (Data.Rqtype === "EOC") || (Data.Rqtype === "OC" || Data.Rqtype === "ELS" || Data.Rqtype === "ELO")) {
					this.oRouter.navTo("OC", {
						DrssNo: Data.Docno,
						Rqtype: Data.Rqtype,
						Etkt: Data.Etkt,
						Mjahr: Data.Mjahr,
						SrvtypeCode: Data.SrvtypeCode
						// RqstatColor: Data.RqstatColor,
						// RqstatDesc: Data.RqstatDesc,
						// SrvtypText: Data.SrvtypText

					});
				} else if (Data.Rqtype === "EW1" || Data.Rqtype === "EW2" || Data.Rqtype === "EW3" || Data.Rqtype === "EW4" || Data.Rqtype ===
					"EW5" || Data.Rqtype === "EW6" || Data.Rqtype === "EW7" || Data.Rqtype === "EW8" || Data.Rqtype === "EW9" || Data.Rqtype ===
					"EW12" || Data.Rqtype === "EWAN") {
					this.oRouter.navTo("WSView", {
						DrssNo: Data.Docno,
						Rqtype: Data.Rqtype,
						Gid: Data.Gid,
						Mjahr: Data.Mjahr,

					});
				} else if ((Data.Rqtype === "ELSN")) {
					this.oRouter.navTo("LSTK", {
						DrssNo: Data.Docno,
						Rqtype: Data.Rqtype,
						Gid: Data.Gid,
						Mjahr: Data.Mjahr

					});
				} else if ((Data.Rqtype === "EMAN")) {
					this.oRouter.navTo("ManPower", {
						DrssNo: Data.Docno,
						Rqtype: Data.Rqtype,
						Gid: Data.Gid,
						Mjahr: Data.Mjahr

					});
				} else if ((Data.Rqtype === "XD") || (Data.Rqtype === "XM") || (Data.Rqtype === "XE" || Data.Rqtype === "EXD") || (Data.Rqtype ===
						"EXM") || (Data.Rqtype === "EXE")) {
					this.oRouter.navTo("Taxi", {
						DrssNo: Data.Docno,
						Rqtype: Data.Rqtype,
						Gid: Data.Gid,
						Mjahr: Data.Mjahr

					});
				} else if ((Data.Rqtype === "TAN") || (Data.Rqtype === "NTAN") || (Data.Rqtype === "WMAN")) {
					var sSeletedTabFilter = this.getView().byId("idIconTabBar").getSelectedKey();
					this.oRouter.navTo("Tan", {
						DrssNo: Data.Docno,
						Rqtype: Data.Rqtype,
						Gid: Data.Gid,
						Mjahr: Data.Mjahr,
						Src: sSeletedTabFilter

					});
				} else if ((Data.Rqtype === "ERIG") || (Data.Rqtype === "EROC")) {
					this.oRouter.navTo("RigRate", {
						DrssNo: Data.Docno,
						Rqtype: Data.Rqtype,
						Gid: Data.Gid,
						Mjahr: Data.Mjahr,
						SrvtypeCode: Data.SrvtypeCode
					});
				} else if (Data.Rqtype === "HUAR" || Data.Rqtype === "HUCR") {
					this.oRouter.navTo("Hauling", {
						DrssNo: Data.Docno,
						Rqtype: Data.Rqtype,
						Gid: Data.Gid,
						Mjahr: Data.Mjahr,
						SrvtypeCode: Data.SrvtypeCode
					});
				} else if (Data.Rqtype === "EWW") {
					this.oRouter.navTo("WWView", {
						DrssNo: Data.Docno,
						Rqtype: Data.Rqtype,
						Gid: Data.Gid,
						Mjahr: Data.Mjahr,
						SrvtypeCode: Data.SrvtypeCode
					});
				} else {
					this.oRouter.navTo("InboxDetail", {
						DrssNo: Data.Docno,
						Rqtype: Data.Rqtype,
						Gid: Data.Gid,
						Mjahr: Data.Mjahr

					});
				}

			}

		},
		onOpportunityNav: function (oEvent) {
			if (oEvent.getParameter("rowContext")) {
				var Data = oEvent.getParameter("rowContext").getObject();
				this.oRouter.navTo("displayOpportunity", {
					DrssNo: Data.Docno,
					Rqtype: Data.Rqtype,
					Gid: Data.Gid,
					Mjahr: Data.Mjahr
				});

			}
		},

		onInboxModelSearch: function (oEvent) {
			var aFilter = [],
				aToFilter = [];
			if (oEvent) {
				this.sQuery = oEvent.getSource().getValue().trim();
			} else {
				this.sQuery = InboxFilter;
			}
			InboxFilter = this.sQuery;
			if (this.sQuery && this.sQuery.length > 0) {
				if (parseInt(this.sQuery, 0)) {
					aToFilter.push(new Filter({
						path: "Docno",
						operator: FilterOperator.Contains,
						value1: this.sQuery,
						caseSensitive: false
					}));
				} else {
					aToFilter.push(new Filter({
						path: "Descrip",
						operator: FilterOperator.Contains,
						value1: this.sQuery,
						caseSensitive: false
					}));

					aToFilter.push(new Filter({
						path: "Rigno",
						operator: FilterOperator.Contains,
						value1: this.sQuery,
						caseSensitive: false
					}));

					aToFilter.push(new Filter({
						path: "Wellnm",
						operator: FilterOperator.Contains,
						value1: this.sQuery,
						caseSensitive: false
					}));

					aToFilter.push(new Filter({
						path: "Lifnr",
						operator: FilterOperator.Contains,
						value1: this.sQuery,
						caseSensitive: false
					}));

					aToFilter.push(new Filter({
						path: "Name1",
						operator: FilterOperator.Contains,
						value1: this.sQuery,
						caseSensitive: false
					}));

					aToFilter.push(new Filter({
						path: "Reqid",
						operator: FilterOperator.Contains,
						value1: this.sQuery,
						caseSensitive: false
					}));

					aToFilter.push(new Filter({
						path: "Rqstat",
						operator: FilterOperator.Contains,
						value1: this.sQuery,
						caseSensitive: false
					}));
				}
			}
			aFilter.push(aToFilter);
			var oTable = this.getView().byId("drssRequestTable"),
				oBinding = oTable.getBinding("rows");
			var oTableReject = this.getView().byId("vendorReportTable"),
				oBindingTable = oTableReject.getBinding("rows");
			if (aToFilter.length > 0) {
				aFilter.push(new Filter({
					filters: aToFilter
				}));
				if (oBinding) {
					oBinding.filter(aFilter);
					oBindingTable.filter(aFilter);
				}
			} else {
				if (oBinding) {
					oBinding.filter(this.aSelectedTabFilters);
					oBindingTable.filter(this.aSelectedTabFilters);
				}
			}
			this.updateHeaderTags(oBinding);
			this.updateHeaderCount();
		},

		updateHeaderCount: function (oEvent) {
			/*var oTable = this.getView().byId("drssRequestTable"),
				oBindingInfo = oTable.getBindingInfo("rows");
			var aIndices = [],
				iCount;
			if (oBindingInfo) {
				aIndices = oBindingInfo.binding.aIndices;
			}
			if (aIndices) {
				iCount = aIndices.length;
			}
			var listtext = iCount + " of " + this.getView().getModel("InboxCountModel").getProperty("/count");
			this.getView().byId("TitleInboxPaperHeader").setText(listtext);*/
		},

		onFilterSelect: function (oEvent) {
			var aFilter = [],
				aToFilter = [],
				sStatus;
			if (InboxSelectedTab) {
				sStatus = InboxSelectedTab;
				this.onInboxModelSearch();
			}
			if (oEvent) {
				sStatus = oEvent.getParameter("selectedKey");
			} else {
				if (sStatus === "" || (!sStatus)) {
					sStatus = "INBX";
				}
			}
			InboxSelectedTab = sStatus;

			if (sStatus === "Rejected") {
				aToFilter.push(new Filter({
					path: "Rqstat",
					operator: FilterOperator.EQ,
					value1: 'CLSD',
					caseSensitive: false
				}));

				aToFilter.push(new Filter({
					path: "Rqstat",
					operator: FilterOperator.EQ,
					value1: 'RQRJ',
					caseSensitive: false
				}));

				aToFilter.push(new Filter({
					path: "Rqstat",
					operator: FilterOperator.EQ,
					value1: 'ARJC',
					caseSensitive: false
				}));
			} else {
				aToFilter.push(new Filter({
					path: "Tab",
					operator: FilterOperator.EQ,
					value1: sStatus,
					caseSensitive: false
				}));
			}

			var UserInfoModel = this.getView().getModel("UserInfoModel");
			this.getView().byId("eTicketGrossValue").setVisible(false);
			this.getView().byId("eTicketGrossNetValue").setVisible(false);

			this.getView().byId("Rqddt").setVisible(true);
			this.getView().byId("Reqdt").setVisible(true);
			this.getView().byId("Reqid").setVisible(true);
			this.getView().byId("Actdate").setVisible(true);
			this.getView().byId("Actuname").setVisible(true);

			if (sStatus === "ETKT") {
				//this.getView().byId("eTicketStatus").setVisible(true);
				//this.getView().byId("WorkflowStatus").setVisible(true);
				//this.getView().byId("Status").setVisible(false);
				this.getView().byId("JobloggingStatus").setVisible(false);
				this.getView().byId("PendingLogsInbox").setVisible(false);

				this.getView().byId("Rqddt").setVisible(false);
				this.getView().byId("Reqdt").setVisible(false);
				this.getView().byId("Reqid").setVisible(false);
				this.getView().byId("Actdate").setVisible(false);
				this.getView().byId("Actuname").setVisible(false);

				this.getView().byId("StatusJlog").setVisible(false);

				if (UserInfoModel.getProperty("/PriceVisible")) {
					this.getView().byId("eTicketGrossValue").setVisible(true);
					this.getView().byId("eTicketGrossNetValue").setVisible(true);
				}

			} else if (sStatus === "COMP") {
				if (UserInfoModel.getProperty("/PriceVisible")) {
					this.getView().byId("eTicketGrossValue").setVisible(true);
					this.getView().byId("eTicketGrossNetValue").setVisible(true);
				}

			} else if (sStatus === "JOBL") {
				this.getView().byId("Status").setVisible(true);
				//this.getView().byId("WorkflowStatus").setVisible(false);
				//this.getView().byId("eTicketStatus").setVisible(false);
				this.getView().byId("JobloggingStatus").setVisible(true);
				this.getView().byId("PendingLogsInbox").setVisible(false);
				this.getView().byId("StatusJlog").setVisible(false);

				//				if(UserInfoModel.getProperty("/PriceVisible")) {
				//					this.getView().byId("eTicketGrossValue").setVisible(true);
				//					this.getView().byId("eTicketGrossNetValue").setVisible(true);
				//				}
			} else if (sStatus === "INBX") {
				//this.getView().byId("eTicketStatus").setVisible(false);
				//this.getView().byId("WorkflowStatus").setVisible(false);
				this.getView().byId("Status").setVisible(true);
				this.getView().byId("JobloggingStatus").setVisible(false);
				this.getView().byId("PendingLogsInbox").setVisible(true);
				this.getView().byId("StatusJlog").setVisible(false);
			} else {
				this.getView().byId("Status").setVisible(true);
				//this.getView().byId("WorkflowStatus").setVisible(false);
				//this.getView().byId("eTicketStatus").setVisible(false);
				this.getView().byId("JobloggingStatus").setVisible(false);
				this.getView().byId("PendingLogsInbox").setVisible(false);
				this.getView().byId("StatusJlog").setVisible(false);
			}

			// this.getView().byId("inboxTagContainer").setVisible(true);
			if (sStatus === "RFR") {
				//this.getView().byId("drssRequestTable").setVisible(false);
				// this.getView().byId("drssRequestTable_cont").setVisible(false);
				//			this.getView().byId("redinessTable").setVisible(true);
				// this.getView().byId("redinessTable_cont").setVisible(true);
				// this.getView().byId("vendorReportTable_cont").setVisible(false);
				// this.getView().byId("filterbar").setVisible(false);
				// this.getView().byId("inboxTagContainer").setVisible(false);
			} else if (sStatus === "Rejected") {
				// this.getView().byId("drssRequestTable_cont").setVisible(false);
				// this.getView().byId("redinessTable_cont").setVisible(false);
				this.getView().byId("vendorReportTable_cont").setVisible(true);
				// this.getView().byId("filterbar").setVisible(false);
				var oTable = this.getView().byId("vendorReportTable");
				var oBinding = oTable.getBinding("rows");
				var oFilters = [new Filter(aToFilter, false)];
				this.aSelectedTabFilters = oFilters;
				if (oBinding) {
					oBinding.filter(oFilters);
				}
				controller.aToFilter = [];
				// this.updateHeaderTags(oBinding);
			} else {
				var oTable = this.getView().byId("drssRequestTable");
				var oBinding = oTable.getBinding("rows");
				if (sStatus === "ACPT" || sStatus === "JOBL") {
					var oFilters = [new Filter(aToFilter, true)];
				} else {
					var oFilters = [new Filter(aToFilter, false)];
				}
				this.aSelectedTabFilters = oFilters;
				if (oBinding) {
					oBinding.filter(oFilters);
				}
				controller.aToFilter = [];
				// this.updateHeaderTags(oBinding);
				this.updateHeaderCount();
				// this.getView().byId("drssRequestTable_cont").setVisible(true);
				// this.getView().byId("redinessTable_cont").setVisible(false);
				// this.getView().byId("vendorReportTable_cont").setVisible(false);
				// this.getView().byId("filterbar").setVisible(false);
			}
		},

		getViewSettingsDialog: function (sDialogFragmentName) {
			var pDialog = this._mViewSettingsDialogs[sDialogFragmentName];

			if (!pDialog) {
				pDialog = Fragment.load({
					id: this.getView().getId(),
					name: sDialogFragmentName,
					controller: this
				}).then(function (oDialog) {
					if (Device.system.desktop) {
						oDialog.addStyleClass("sapUiSizeCompact");
					}
					return oDialog;
				});
				this._mViewSettingsDialogs[sDialogFragmentName] = pDialog;
			}
			return pDialog;
		},

		handleSortButtonPressed: function () {
			this.getViewSettingsDialog("zdwo_nx_drss_ven.view.fragment.SortDialog")
				.then(function (oViewSettingsDialog) {
					oViewSettingsDialog.open();
				});
		},

		handleSortDialogConfirm: function (oEvent) {
			var oTable = this.byId("drssRequestTable"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));

			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		},

		handleGroupButtonPressed: function () {
			this.getViewSettingsDialog("zdwo_nx_drss_ven.view.fragment.GroupDialog")
				.then(function (oViewSettingsDialog) {
					oViewSettingsDialog.open();
				});
		},

		handleGroupDialogConfirm: function (oEvent) {
			var oTable = this.byId("drssRequestTable"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				vGroup,
				aGroups = [];

			if (mParams.groupItem) {
				sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				vGroup = this.mGroupFunctions[sPath];
				aGroups.push(new Sorter(sPath, bDescending, vGroup));
				// apply the selected group settings
				oBinding.sort(aGroups);
			} else if (this.groupReset) {
				oBinding.sort();
				this.groupReset = false;
			}
		},

		resetGroupDialog: function (oEvent) {
			this.groupReset = true;
		},
		// updateHeaderTags: function(oBinding){
		// 	var aIndices = null,
		// 		iCount;
		// 	var aServiceTypeInfo = [];
		// 	var aStatusInfo = [];
		// 	var aVendorInfo = [];
		// 	var aTags = [];
		// 	if (oBinding) {
		// 		aIndices = oBinding.aIndices;
		// 	}
		// 	if (aIndices) {
		// 		//iCount = aIndices.length;
		// 		var oTempItem;
		// 		for(var x=0; x<aIndices.length; x++ ){
		// 			oTempItem = oBinding.oList[aIndices[x]];

		// 			//Service Type
		// 			if(! aServiceTypeInfo[oTempItem.SrvtypeCode])
		// 			{
		// 				aServiceTypeInfo[oTempItem.SrvtypeCode] = {text: oTempItem.SrvtypText,code:oTempItem.SrvtypeCode ,  count: 0, selected: false};	
		// 			}					
		// 			aServiceTypeInfo[oTempItem.SrvtypeCode].count++;

		// 			//vendors
		// 			/*if(! aVendorInfo[oTempItem.Lifnr])
		// 			{
		// 				aVendorInfo[oTempItem.Lifnr] = {text: oTempItem.Name1, code:oTempItem.Lifnr , count: 0, selected: false};	
		// 			}					
		// 			aVendorInfo[oTempItem.Lifnr].count++;
		// 			*/

		// 			//status
		// 			if(! aStatusInfo[oTempItem.Rqstat])
		// 			{
		// 				//aStatusInfo[oTempItem.Rqstat] = {text: formatter.RequsetStatusTxt(oTempItem.Rqstat), code:oTempItem.Rqstat , count: 0, selected: false};	
		// 				aStatusInfo[oTempItem.Rqstat] = {text: oTempItem.RqstatDesc, code:oTempItem.Rqstat , count: 0, selected: false};	
		// 			}					
		// 			aStatusInfo[oTempItem.Rqstat].count++;

		// 		}

		// 		//destroy the existing tags
		// 		var oServiceTypeTagContainer= this.byId("serviceTypeTagContainer");
		// 		oServiceTypeTagContainer.destroyContent();

		// 		var oStatusTagContainer= this.byId("statusTagContainer");
		// 		oStatusTagContainer.destroyContent();

		// 		var oTempTag;

		// 		//construct Service type tags
		// 		for (let key in aServiceTypeInfo) {
		// 		 	oTempTag = new sap.m.GenericTag(
		// 				{
		// 					id: key,
		// 					text:aServiceTypeInfo[key].text,
		// 					design:"StatusIconHidden",
		// 					press:this.onTagPressed,
		// 					status:"Success" ,
		// 					value: new sap.m.ObjectNumber({state:"Success", emphasized:false, number:aServiceTypeInfo[key].count}),
		// 					customData: [
		// 						new sap.ui.core.CustomData( {key:"filterName",  value: "SrvtypeCode"}),
		// 						new sap.ui.core.CustomData( {key:"filterValue",  value: aServiceTypeInfo[key].code })
		// 					]

		// 				});

		// 			oTempTag.addStyleClass("serviceTypeTag");

		// 			if(this.isSelectedTag("SrvtypeCode", aServiceTypeInfo[key].code)){
		// 				oTempTag.addStyleClass("obg");
		// 			}

		// 			oServiceTypeTagContainer.insertContent(oTempTag);
		// 		}

		// 		//construct Status tags
		// 		for (let key in aStatusInfo) {
		// 		 	oTempTag = new sap.m.GenericTag(
		// 				{
		// 					id: key,
		// 					text: aStatusInfo[key].text,
		// 					design:"StatusIconHidden",
		// 					press:this.onTagPressed,
		// 					status:"Success" ,
		// 					value: new sap.m.ObjectNumber({state:"Success", emphasized:false, number:aStatusInfo[key].count}),
		// 					customData: [
		// 						new sap.ui.core.CustomData( {key:"filterName",  value: "Rqstat"}),
		// 						new sap.ui.core.CustomData( {key:"filterValue",  value: aStatusInfo[key].code })
		// 					]

		// 				});

		// 			oTempTag.addStyleClass("statusTag");
		// 			if(this.isSelectedTag("Rqstat",aStatusInfo[key].code)){
		// 				oTempTag.addStyleClass("obg");
		// 			}

		// 			oStatusTagContainer.insertContent(oTempTag);
		// 		}

		// 	}
		// },
		onTagPressed: function (oEvent) {
			//debugger;
			var sClickedTagName = oEvent.getSource().data("filterName");
			var sClickedTagValue = oEvent.getSource().data("filterValue")

			if (controller.getView().byId("drssRequestTable_cont").getVisible()) {
				var oTable = controller.getView().byId("drssRequestTable");
			}
			if (controller.getView().byId("vendorReportTable_cont").getVisible()) {
				var oTable = controller.getView().byId("vendorReportTable");
			}
			if (controller.getView().byId("redinessTable_cont").getVisible()) {
				var oTable = controller.getView().byId("redinessTable");
			}
			var oBinding = oTable.getBinding("rows");

			/*	var oQueryFilters = new Filter({ filters: [ new Filter({
				path: oEvent.getSource().data("filterName"),
				operator: FilterOperator.EQ,
				value1: oEvent.getSource().data("filterValue"),
				caseSensitive: false})] ,   and: false });	
*/

			if (oEvent.getSource().hasStyleClass("obg")) { //The tag is already selected
				var oTempFilter;

				for (var x = 0; x < controller.aToFilter.length; x++) {
					oTempFilter = controller.aToFilter[x];

					if (oTempFilter.sPath === sClickedTagName && oTempFilter.oValue1 === sClickedTagValue) {
						//remove the filter

						//sPath: "Rqstat"

						//oValue1: "CLSD"
						//debugger;

						controller.aToFilter.splice(x, 1);
						break;
					}
				}

				if (controller.aToFilter.length > 0) {
					var oQueryFilters = new Filter({
						filters: controller.aToFilter,
						and: true
					});
					oBinding.filter(new Filter({
						filters: [oQueryFilters, controller.aSelectedTabFilters],
						and: true
					}), sap.ui.model.FilterType.Application);
				} else {
					oBinding.filter(controller.aSelectedTabFilters);
				}

			} else {
				//the tas is not already selected
				controller.aToFilter.push(new Filter({
					path: oEvent.getSource().data("filterName"),
					operator: FilterOperator.EQ,
					value1: oEvent.getSource().data("filterValue"),
					caseSensitive: false
				}));

				var oQueryFilters = new Filter({
					filters: controller.aToFilter,
					and: true
				});
				oBinding.filter(new Filter({
					filters: [oQueryFilters, controller.aSelectedTabFilters],
					and: true
				}), sap.ui.model.FilterType.Application);
			}
			oEvent.getSource().toggleStyleClass("obg");
			controller.updateHeaderTags(oBinding);
		},
		isSelectedTag: function (sFilterName, sFilterValue) {
			var bIsSelected = false;
			var oTempFilter;
			for (var x = 0; x < controller.aToFilter.length; x++) {
				oTempFilter = controller.aToFilter[x];

				if (oTempFilter.sPath === sFilterName && oTempFilter.oValue1 === sFilterValue) {
					bIsSelected = true;
					break;
				}
			}

			return bIsSelected;

		},

		onFilterChange: function () {
			var aCurrentFilterValues = [];
			if (this.getView().byId("idRequestFilter").getValue() !== "") {
				aCurrentFilterValues.push(new Filter({
					path: "Docno",
					operator: FilterOperator.Contains,
					value1: this.getView().byId("idRequestFilter").getValue(),
					caseSensitive: false
				}));
			}
			if (this.getView().byId("idServiceFilter").getValue() !== "") {
				aCurrentFilterValues.push(new Filter({
					path: "SrvtypText",
					operator: FilterOperator.Contains,
					value1: this.getView().byId("idServiceFilter").getValue(),
					caseSensitive: false
				}));
			}
			this.getView().byId("vendorReportTable").getBinding("rows").filter(aCurrentFilterValues);

		},

		createColumnConfig: function () {
			var aCols = [];

			aCols.push({
				label: 'Docno',
				type: EdmType.String
			});

			aCols.push({
				label: 'Service Type Description',
				type: EdmType.String
			});

			aCols.push({
				label: 'Rig Number',
				type: EdmType.String
			});

			aCols.push({
				property: 'Well Name',
				type: EdmType.String
			});

			aCols.push({
				property: 'Status',
				type: EdmType.String
			});

			/*	aCols.push({
					property: 'Readiness Status',
					type: EdmType.String
				});
				*/

			aCols.push({
				property: 'Required On',
				type: EdmType.String
			});

			aCols.push({
				property: 'Created On',
				type: EdmType.String
			});

			aCols.push({
				property: 'Created By',
				type: EdmType.String
			});

			aCols.push({
				property: 'Changed On',
				type: EdmType.String
			});

			aCols.push({
				property: 'Changed By',
				type: EdmType.String
			});

			return aCols;
		},

		onExcelExport: function (oEvent) {
			var UserInfoModel = this.getView().getModel("UserInfoModel").getData();
			//  if (UserInfoModel['Foreman'] === 'X'){
			var aCols = [{
					label: 'Docno',
					property: ['Docno'],
					type: EdmType.String,
					template: '{0}'
				},

				{
					label: 'Service Type Description',
					property: ['SrvtypText'],
					type: EdmType.String,
					template: '{0}'
				},

				{
					label: 'Rig Number',
					property: ['Rigno'],
					type: EdmType.String,
					template: '{0}'
				}, {
					label: 'Well Name',
					property: ['Wellnm'],
					type: EdmType.String,
					template: '{0}'
				}, {
					label: 'Status',
					property: ['Rqstat'],
					type: EdmType.String,
					template: '{0}'
				},
				/*{
					label: 'Readiness Status',
					property: ['MsStatus'],
					type: this.getType('S'),
					template: '{0}'
				},*/

				{
					label: 'Required On',
					property: ['Rqddt'],
					type: EdmType.Date,
					template: '{0}'
				}, {
					label: 'Created On',
					property: ['Reqdt'],
					type: EdmType.Date,
					template: '{0}'
				}, {
					label: 'Created By',
					property: ['Reqid'],
					type: EdmType.String,
					template: '{0}'
				}, {
					label: 'Changed On',
					property: ['Actdate'],
					type: EdmType.Date,
					template: '{0}'
				}, {
					label: 'Changed By',
					property: ['Actuname'],
					type: EdmType.String,
					template: '{0}'
				}
			];
			this.foremanExportInbox(aCols)
				//}
		},

		foremanExportInbox: function (aCols) {
			var oTable = this.getView().byId('drssRequestTable');
			var oBinding = oTable.getBinding('rows');
			var filters = '?' + oBinding['sFilterParams'];
			var oModel = this.getView().getModel("oDataModel");
			var downloadUrl = oModel.sServiceUrl + '/InboxSet';
			var oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: 'Level'
				},
				dataSource: {
					type: 'odata',
					dataUrl: downloadUrl,
					serviceUrl: oModel.sServiceUrl, // odata url
					headers: oModel.getHeaders ? oModel.getHeaders() : null,
					count: this.getView().getModel("InboxModel").getData().length,
					useBatch: true // Default for ODataModel V2
				},
				fileName: 'Foreman Inbox.xlsx',
				worker: true
			};

			var oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function () {
				oSheet.destroy();
			});

		},

		/*		onDataExport : function(oEvent) {
				var oExport = new Export({

					// Type that will be used to generate the content. Own ExportType's can be created to support other formats
					exportType : new ExportTypeCSV({
						separatorChar : ";"
					}),

					// Pass in the model created above
					models : this.getView().getModel("InboxModel"),

					// binding information for the rows aggregation
					rows : {
						path : "/"
					},

					// column definitions with column name and binding info for the content

					columns : [{
						name : "Docno",
						 template: {
					            content: {
					                path: "Docno"
					            },
					            customData: [
					                {
					                    "key": "color",
					                    "value":'red'				                }
					            ]
					        }
					}, {
						name : "Service Type Description",
						template : {
							content : "{SrvtypText}"}
					},{
						name : "Rig Number",
						template : {
							content : "{Rigno}"}
					},{
						name : "Well Name",
						template : {
							content : "{Wellnm}"}
					},{
						name : "Status",
						template : {
							content : "{Rqstat}"}
					},{
						name : "Required On",
						template : {
							content : "{Rqddt}"}
					},{
						name : "Created On",
						template : {
							content : "{Reqdt}"}
					},{
						name : "Created By",
						template : {
							content : "{Reqid}"}
					},{
						name : "Changed On",
						template : {
							content : "{Actdate}"}
					},{
						name : "Changed By",
						template : {
							content : "{Actuname}"}
					}
					]
				});

				// download exported file
				oExport.saveFile().catch(function(oError) {
					MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			}*/

		onExportToExcel: function () {
			var sSeletedTabFilter = this.getView().byId("idIconTabBar").getSelectedKey();

			if (sSeletedTabFilter === "RFR") {
				var tbl = this.byId("redinessTable");
			} else {
				var tbl = this.byId("drssRequestTable");
			}

			var cols = tbl.getColumns();
			//  var aIndices = tbl.getBinding("").aIndices;
			var selectedIndices = tbl.getBinding('rows').aIndices;
			var oModelList = tbl.getBinding('rows')['oList'];
			var selectedEntries = [];
			var tableData = oModelList
			for (var index = 0; index < selectedIndices.length; index++) {

				var tableIndex = selectedIndices[index];
				var tableRow = tableData[tableIndex];
				selectedEntries.push(tableRow);

			}
			this.onDataExport(selectedEntries, cols, sSeletedTabFilter, tbl)

		},

		onDataExport: function (aItems, oCols, sSeletedTabFilter, tbl) {
			var html = "<table style='border: 1px solid black; border-collapse: collapse;font-family:Calibri'>" +
				"<tbody>"

			html += "<tr> <th> Foreman's Portal  </th>  </tr> <br> <tr> <th> " + sSeletedTabFilter + " </th>  </tr>  ";
			var cells = tbl.getRows()[0].getCells();
			var oArr = [];
			//Table Header
			for (var i = 0; i < oCols.length; i++) {
				var col = oCols[i];
				if (col.getVisible()) {
					//var header = col.getHeader().getText();
					var header = col.getLabel().getText();
					html += "<th style='border: 1px solid black;background: mediumaquamarine;'>" + header + "</th>";
				}

			}
			html += "</tr>";
			for (var i = 0; i < aItems.length; i++) {
				html += "<tr>";
				var oItem = aItems[i];
				for (var j = 0; j < cells.length; j++) {
					var cell = cells[j];
					var path = cell.getBinding("text");

					var oValue = oItem[cell.getBinding("text").getPath()];
					//var date = new Date(oValue);
					//date.constructor === Date

					if (path['sPath'] === '') {
						if (oItem.JlitmLogCount === "0000" && oItem.JlopeLogCount === "0000") {
							oValue = "";
						} else {
							oValue = 'Services :' + this.formatter.removeLeadingZeros(oItem.JlitmLogCount) + ' , Operations :' + this.formatter.removeLeadingZeros(
								oItem.JlopeLogCount) + '';
						}

					}

					if (path['sPath'] === 'Rqstat' || path['sPath'] === 'MsStatus') {
						oValue = this.formatter.RequsetStatusTxt(oValue);
					}

					if (path['sPath'] === 'Rqddt' || path['sPath'] === 'Reqdt' || path['sPath'] === 'Actdate') {
						if (typeof oItem[cell.getBinding("text").getPath()] !== 'undefined' && oItem[cell.getBinding("text").getPath()] !== null) {
							var oValue = oItem[cell.getBinding("text").getPath()].toLocaleString().split(',')[0];
						} else {
							oValue = "";
						}
					}

					html += "<td style='border: 1px solid black;'>" + oValue + "</td>";

				}
				html += "</tr>";
			}

			html += "</tbody></table>";

			var excel = new ExportToExcel();
			//var month = (this.byId("dp").getDateValue().getMonth()+1).toString();
			//var year = this.byId("dp").getDateValue().getFullYear().toString();
			var vendor = "Venor " + this.getView().getModel("UserInfoModel").getData().VendorName + " " + this.getView().getModel(
				"UserInfoModel").getData().Vendor;
			//	var fileName = "Vehicle Taxi Sheet "+vendor+" Month "+month+" Year "+year

			var fileName = "Vendor Inbox";
			excel.exportHTMLFormat(html, fileName);
		},
		getFontClass: function (sFontClass) {
			if (sFontClass && sFontClass.length > 0) {
				return sFontClass;
			} else {
				return "normal";
			}
		},

		onNavToJoblog: function (oEvent) {
			var Data = oEvent.getSource().getParent().getBindingContext("InboxModel").getObject();
			this._OCReqData(Data.Docno, Data.Mjahr, Data.Rqtype, Data.SrvtypeCode);
		},

		_OCReqData: function (docNo, year, Rqtype, SrvtypeCode) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			var oModel = this.getView().getModel("VendorService");
			var oFilter = [new sap.ui.model.Filter("SrvtypeCode", "EQ", SrvtypeCode)];

			oModel.read("/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + Rqtype + "')", {
				urlParameters: {
					"$expand": "HeaderToAttNav,HeaderToCommNav,HeaderToItemNav,HeaderToUserInfoNav,HeaderToWfLogNav,HeaderToItemNav/ItemToCommNav,HeaderToWfActionNav,HeaderToItemNav/ItemToEdrssNav"
				},
				filters: oFilter,
				success: function (oData) {
					this.getView().setModel(new JSONModel(oData), "itemsModel");
					this.getOwnerComponent().getModel("itemsModel").setData(null);
					this.getOwnerComponent().getModel("itemsModel").setData(oData);
					this.getView().getModel("itemsModel").refresh();
					//this.oRouter.navTo("JL",{DrssNo: oData.Docno, Rqtype : oData.Rqtype,Gid : "00",Mjahr : oData.Mjahr,Srvtype : oData.SrvtypeCode, FormCode : "F019"});	
					this.getJoblogging(oData.Docno, oData.Rqtype, oData.Mjahr, oData.SrvtypeCode)
					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
				}.bind(this)
			});
		},

		getJoblogging: function (docNo, Rqtype, Mjahr, SrvtypeCode) {
			this.Docno = docNo;
			this.Rqtype = Rqtype;
			this.Mjahr = Mjahr;
			this.SrvtypeCode = SrvtypeCode;
			var oFilter = [new sap.ui.model.Filter("Docno", "EQ", docNo),
				new sap.ui.model.Filter("Mjahr", "EQ", Mjahr)
			];
			this.getView().setBusy(true);
			this.getView().getModel("VendorService").read("/JobloggingFormsSet", {
				filters: oFilter,
				success: function (oData) {
					for (var i = 0; i < oData.results.length; i++) {
						if (oData.results[i].FormCode === "F020") {
							this.getOwnerComponent().getModel("JoblogFormsModel").getData().Tvd = true;
						}

						if (oData.results[i].FormCode === "F021") {
							this.getOwnerComponent().getModel("JoblogFormsModel").getData().Sos = true;
						}

						if (oData.results[i].FormCode === "F038") {
							this.getOwnerComponent().getModel("JoblogFormsModel").getData().Operations = true;
						}

						if (oData.results[i].FormCode === "F048") {
							this.getOwnerComponent().getModel("JoblogFormsModel").getData().NonCharge = true;
						}

						if (oData.results[i].FormCode === "F046") {
							this.getOwnerComponent().getModel("JoblogFormsModel").getData().rigMeals = true;
						}
					}
					this.getView().setBusy(false);
					//debugger;
					this.getOwnerComponent().getModel("JoblogFormsModel").refresh(true);
					this.oRouter.navTo("JL", {
						DrssNo: this.Docno,
						Rqtype: this.Rqtype,
						Gid: "00",
						Mjahr: this.Mjahr,
						Srvtype: this.SrvtypeCode,
						FormCode: "F019",
						Version: '0'
					});
				}.bind(this),
				error: function (oError) {
					this.getView().setBusy(false);
				}.bind(this)
			});
		},

	});

});