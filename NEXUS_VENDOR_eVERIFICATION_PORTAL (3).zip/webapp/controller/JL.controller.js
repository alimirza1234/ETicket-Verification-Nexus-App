var controller;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/Popover",
	"sap/m/Button",
	"sap/m/Label",
	'sap/ui/core/Fragment',
	"sap/m/Dialog",
	"sap/ui/core/format/DateFormat",
	'sap/m/MessageToast',
	'zdwo_nx_drss_ven/model/formatter',
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
], function (Controller, JSONModel, Popover, Button, Label, Fragment, Dialog, DateFormat, MessageToast, formatter, MessageBox, Filter) {
	"use strict";

	return Controller.extend("zdwo_nx_drss_ven.controller.JL", {
		formatter: formatter,
		tableList: [],
		Joblog: [],
		oModel: {},
		comnt: [],
		HeaderToWbsNav: [],
		HeaderToItemsNav: [],
		HeaderToRigNav: [],
		JoblogToPOConsupNav: [],
		vendorObj: {},
		DetailObj: {},
		Files: [],
		FilesJb: [],
		nIndexJB: {},
		detObj: {},
		selectedObj: {},
		jobLoggingitem: [],
		SrvHdrToItemsNav: [],
		JoblogToSerListNav: [],
		jbitempress: "",
		jbtype: "",
		jbselitem: "",
		HeaderToPoNav: [],
		nIndexHdrAtt: {},
		HeaderToCountNav: [],

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zdwo_nx_drss_ven.view.JL
		 */
		onInit: function () {
			;
			controller = this;
			this.itemDetails = '';
			// this.getOwnerComponent().getRouter().getRoute("JL").attachMatched(this.onNavToCurrentPage, this);
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("JL").attachPatternMatched(this._onObjectMatched, this);
		},

		onNavBack: function (oEvent) {
			

			this.oRouter.navTo("OC", {
				DrssNo: this.itemDetails.DrssNo,
				Rqtype: this.itemDetails.Rqtype,
				// Gid: Data.Gid,
				Etkt: this.itemDetails.Etkt,
				Mjahr: this.itemDetails.Mjahr,
				SrvtypeCode: this.itemDetails.SrvtypeCode
				// RqstatColor: this.itemDetails.RqstatColor,
				// RqstatDesc: this.itemDetails.RqstatDesc,
				// SrvtypText: this.itemDetails.SrvtypText

			});
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf zdwo_nx_drss_ven.view.JL
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zdwo_nx_drss_ven.view.JL
		 */
		_onObjectMatched: function (oEvent) {
			

			var that = this;
			this.itemDetails = oEvent.getParameters('arguments').arguments;
			var oModel = this.getView().getModel("oReqHeaderSetModel");
			var Docno = this.itemDetails.DrssNo;
			// var Docno = "4000000196";
			var Mjahr = this.itemDetails.Mjahr;
			var flag = "V"
			var filter1 = new sap.ui.model.Filter('Docno', 'EQ', Docno);
			var filter2 = new sap.ui.model.Filter('Mjahr', 'EQ', Mjahr);
			var filter3 = new sap.ui.model.Filter('LogType', 'EQ', "OPE");
			sap.ui.core.BusyIndicator.show();

			oModel.read("/JobOpelistSet", {
				filters: [filter1, filter2, filter3],

				success: function (oData, oResponse) {

					that.jobLoggingitem = oData.results;
					var OprsubtItem = [];
					var OpraprItem = [];
					var OprallItem = [];
					var Opractlog = [];
					var OprREJC = [];

					that.jobLoggingitem.forEach((element) => {
						if (element.Status === "SUBT") {
							// var servieitem = {};
							OprsubtItem.push(element);

						} else if (element.Status === "INIT") {
							Opractlog.push(element);

						} else if (element.Status === "APRV") {
							OpraprItem.push(element);

						}
					});

					var OPRsubtItemModel = new JSONModel();
					OPRsubtItemModel.setData(OprsubtItem);
					that.getView().setModel(OPRsubtItemModel, 'OPRsubtItemModel');

					var OPRactlogModel = new JSONModel();
					OPRactlogModel.setData(Opractlog);
					that.getView().setModel(OPRactlogModel, 'OPRactlogModel');

					var OPRaprItemModel = new JSONModel();
					OPRaprItemModel.setData(OpraprItem);
					that.getView().setModel(OPRaprItemModel, 'OPRaprItemModel');

					var Jboperation = new JSONModel();
					Jboperation.setData(that.jobLoggingitem)
					that.getView().setModel(Jboperation, "Jboperation");

					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oData, response) {
					var data = oData.results;
					MessageBox.success("Data Load Error");
					sap.ui.core.BusyIndicator.hide();

				}

			});

			// oModel.read("/JobLoggingSet(Docno='" + this.itemDetails.Docno + "',Mjahr='" + this.itemDetails.Mjahr + "')", {
			oModel.read("/JobLoggingSet(Docno='" + Docno + "',Mjahr='" + Mjahr + "')", {
				urlParameters: {
					// "$expand": "JoblogToDRSSNav,JoblogToOpeListNav,JoblogToPOConsupNav,JoblogToSerListNav"
					// "$expand": "JoblogOpeListNav,JoblogToDRSSNav,JoblogToAttachNav,JoblogToSerListNav,JoblogToPOConsupNav,,JoblogToTimesheetNav,JoblogToPumpsheetNav"

					"$expand": "JoblogOpeListNav,JoblogToAttachNav,JoblogToDRSSNav,JoblogToPOConsupNav,JoblogToSerListNav,JoblogToTimesheetNav,JoblogToPumpsheetNav"

				},
				success: function (oData, oResponse) {

					that.JoblogToSerListNav = oData.JoblogToSerListNav.results;
					var JoblogToSerListNav = new JSONModel();
					JoblogToSerListNav.setData(that.JoblogToSerListNav);
					that.getView().setModel(JoblogToSerListNav, 'JoblogToSerListNav');
					// that.JobLogging.setModel(JoblogToSerListNav, 'JoblogToSerListNav')

					var obj = {
						itemselect: ""
					};
					var DropJB = new JSONModel();
					DropJB.setData(obj);
					that.getView().setModel(DropJB, 'DropJB');

					that.JoblogToPOConsupNav = oData.JoblogToPOConsupNav.results;
					var JoblogToPOConsupNav = new JSONModel();
					JoblogToPOConsupNav.setData(that.JoblogToPOConsupNav);
					that.getView().setModel(JoblogToPOConsupNav, 'JoblogToPOConsupNav');

					that.JoblogToDRSSNav = oData.JoblogToDRSSNav.results;
					var subtItem = [];
					var aprItem = [];
					var allItem = [];
					var actlog = [];
					var REJC = [];

					that.JoblogToDRSSNav.forEach((element) => {
						if (element.Jlstatus === "SUBT") {
							// var servieitem = {};
							subtItem.push(element);

						} else if (element.Jlstatus === "INIT") {
							actlog.push(element);

						} else if (element.Jlstatus === "APRV") {
							aprItem.push(element);

						}
						// else if (element.Jlstatus === "REJC") {
						// 	aprItem.push(element);

						// }
					});
					var subtItemModel = new JSONModel();
					subtItemModel.setData(subtItem);
					that.getView().setModel(subtItemModel, 'subtItemModel');

					var actlogModel = new JSONModel();
					actlogModel.setData(actlog);
					that.getView().setModel(actlogModel, 'actlogModel');

					var aprItemModel = new JSONModel();
					aprItemModel.setData(aprItem);
					that.getView().setModel(aprItemModel, 'aprItemModel');

					var Jbservice = new JSONModel();
					Jbservice.setData(that.JoblogToDRSSNav);
					that.getView().setModel(Jbservice, 'Jbservice');

					that.JoblogOpeListNav = oData.JoblogOpeListNav.results;
					var obj = {
							length: that.JoblogOpeListNav.length
						}
						// that.JoblogOpeListNav.push(obj);
						// var Jboperation = new JSONModel();
						// Jboperation.setData(that.JoblogOpeListNav);
						// that.oView.setModel(Jboperation, 'Jboperation');
						// that.getView().setModel(Jboperation, 'Jboperation')

					that.DetailObj.Docno = oData.Docno;
					that.DetailObj.Ebeln = oData.Ebeln;
					that.DetailObj.Mjahr = oData.Mjahr;
					that.DetailObj.PoConperc = oData.PoConperc;

					that.DetailObj.PoTitle = oData.PoTitle;
					that.DetailObj.PoTrgtval = oData.PoTrgtval;
					that.DetailObj.ServiceDesc = oData.ServiceDesc;
					that.DetailObj.ServiceId = oData.ServiceId;

					that.DetailObj.SesConsv = oData.SesConsv;
					that.DetailObj.TotalCommit = oData.TotalCommit;
					that.DetailObj.TotalValue = oData.TotalValue;
					that.DetailObj.WsiteDhaGateDis = oData.WsiteDhaGateDis;

					var DetailObj = new JSONModel();
					DetailObj.setData(that.DetailObj);
					that.oView.setModel(DetailObj, 'DetailObj')

				},
				error: function (oData, response) {

					var data = oData.results;
					console.log(data);
					MessageBox.success(oData.statusText);

				}
			});

		},

		NavBack: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("OC");
		}

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zdwo_nx_drss_ven.view.JL
		 */
		//	onExit: function() {
		//
		//	}

	});

});