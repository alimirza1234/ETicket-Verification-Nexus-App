var controller ;
sap.ui.define([
	"zdwo_nx_drss_ven/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"zdwo_nx_drss_ven/model/formatter",
	"sap/m/MessageBox",
	'sap/m/MessageToast',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"zdwo_nx_drss_ven/utils/POContractSelector",
	"zdwo_nx_drss_ven/utils/DispatchedServicesSplit",
    "jquery.sap.global",
    "sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Label",
	"sap/m/library",
	
], function (BaseController,JSONModel,formatter, MessageBox, MessageToast, Filter, FilterOperator, POContractSelector, DispatchedServicesSplit,jQuery, Dialog, Button, Label, mobileLibrary) {
	"use strict";
	
	// shortcut for sap.m.ButtonType
	var ButtonType = mobileLibrary.ButtonType;

	// shortcut for sap.m.DialogType
	var DialogType = mobileLibrary.DialogType;

	return BaseController.extend("zdwo_nx_drss_ven.controller.InboxDetail", {
		formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zdwo_nx_drss_ven.view.InboxDetail
		 */
		onInit: function () {
			controller = this;
			this.getView().setModel(new JSONModel([]), "ItemsAttachmentsModel");
			this.getView().setModel(new JSONModel({}), "DescriptionModel");
			this.params = {};
			this.instantiateErrorMessageModel([]);

			this.getView().setModel(new JSONModel({}), "F4Models");

			this.createMessagePopoverModel();
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("InboxDetail").attachPatternMatched(this._onObjectMatched, this);
		},
		
		_onObjectMatched: function (oEvent) {
			controller = this;
			this.DrssNo = oEvent.getParameter("arguments").DrssNo;
			this.Rqtype = oEvent.getParameter("arguments").Rqtype;
			this.Gid = oEvent.getParameter("arguments").Gid;
			this.Mjahr = oEvent.getParameter("arguments").Mjahr;
			this.getRequestData();
			this.getJoblogging();
		},
		
		getJoblogging : function(){
			var oFilter = [new sap.ui.model.Filter("Docno","EQ",this.DrssNo),
							  new sap.ui.model.Filter("Mjahr","EQ",this.Mjahr)];
			this.getView().getModel("VendorService").read("/JobloggingFormsSet", {
				filters : oFilter,
				success: function (oData) {
					var oJsonModel = new JSONModel(oData.results);
					this.getView().setModel(oJsonModel, "JobLoggingModel");
				}.bind(this),
				error: function (oError) {
				}.bind(this)
			});
		},
		
		getRequestData: function () {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			var oModel = this.getView().getModel("VendorService");
			var docNo = this.DrssNo;
			var year = this.Mjahr;
			var Rqtype = this.Rqtype;
			oModel.read("/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + Rqtype + "')", {
				urlParameters: {
					"$expand": "HeaderToAttNav,HeaderToCommNav,HeaderToItemNav,HeaderToUserInfoNav,HeaderToWfLogNav,HeaderToItemNav/ItemToCommNav,HeaderToWfActionNav,HeaderToItemNav/ItemToEdrssNav"
				},
				success: function (oData) {
					this.getView().setModel(new JSONModel(oData), "RequestModel");
					 var commentsTxt = this.byId("commentsTxtGeneral");
				        var sPath = "/HeaderToCommNav/results/0";
				        commentsTxt.bindElement({ path: sPath, model: "RequestModel" });
					console.log(oData);
					this.getConfig(oData.Rqtype, oData.Fldvar);
					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
					busyDialog.close();
				}.bind(this)
			});

		},
		
		jobAttachmentsPressed : function(oEvent){
			var Data = oEvent.getSource().getBindingContext("JobLoggingModel").getProperty(oEvent.getSource().getBindingContext("JobLoggingModel").getPath());
			//if(Data.FormRout === ""){
		    if(Data.FormType === "AF"){
				if(!this.JobLogAttachmentsDialog){
					this.JobLogAttachmentsDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.OC.JobLogAttachmentsDialog", this);
					this.getView().addDependent(this.JobLogAttachmentsDialog);	
				}
				this.JobLogAttachmentsDialog.open();
			}
			/*if(Data.FormRout === ""){
			
				this.getRouter().navTo("AttachmentSheet", {
					AttachType : Data.FormCode,
					DrssNo: this.DrssNo,
					Rqtype: this.Rqtype,
					Gid:  this.Gid,
					Mjahr:  this.Mjahr
				}, true);
			}*/
			/*else{
				this.getRouter().navTo(Data.FormRout, {
					DrssNo: this.DrssNo,
					Rqtype: this.Rqtype,
					Gid:  this.Gid,
					Mjahr:  this.Mjahr
				}, true);
			}*/
			
		},
		
		onNavBackInbox : function(oEvent){
			this.getRouter().navTo("Inbox");			
		},
		
		onHeaderCommentsPress: function (oEvent) {
			var commentsTxt = this.byId("commentsTxtGeneral");
			var sPath = oEvent.getParameter("item").getBindingContext("RequestModel").getPath();
			commentsTxt.bindElement({
				path: sPath,
				model: "RequestModel"
			});
		},

		onItemCommentsPress: function (oEvent) {
			var ItemCommentsTxt = this.byId("ItemCommentsTxt");
			var sPath = oEvent.getParameter("item").getBindingContext("RequestModel").getPath();
			ItemCommentsTxt.bindElement({
				path: sPath,
				model: "RequestModel"
			});
		},

		onRecall: function (oEvent) {
			MessageBox.warning("This request will be recalled. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						this._recallReq();
					}
				}.bind(this)
			});
		},

		_recallReq: function () {
			var oModel = this.getView().getModel("VendorService");
			oModel.callFunction("/RecallRequest", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr
				},
				success: function (oData) {
					sap.m.MessageBox.success("Recall of Service Order " + oData.Docno + " was successful", {
						title: "Recall"
					});
					this.getRouter().navTo("Inbox");
				}.bind(this),
				error: function (error) {
					sap.m.MessageBox.error("An error occured while Recalling - Either the Service Order has been dispatched or you are not authorized", {
						title: "Error"
					});

				}.bind(this)
			});

		},

		onReqcancel: function (oEvent) {
			MessageBox.warning("This Service Order will be cancelled. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						this._cancelReq();
					}
				}.bind(this)
			});
		},

		_cancelReq: function () {
			var that = this;
			var oModel = this.getView().getModel("VendorService");
			oModel.callFunction("/CancelRequest", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr
				},
				success: function (oData) {
					sap.m.MessageBox.success("Cancelation of Service Order " + oData.Docno + " was successful", {
						title: "Cancelation"
					});
					that.getRouter().navTo("Inbox");
				}.bind(this),
				error: function (error) {
					sap.m.MessageBox.error("An error occured while canceling ", {
						title: "Error"
					});
				}.bind(this)
			});
		},

		onSavePress: function (oEvent) {
			MessageBox.information("This Service Order will be saved. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						this._onSubmitRequest();
					}
				}.bind(this)
			});
		},

		// Submit a new request from a JSON model
		_onSubmitRequest: function () {
			var oData = this.getView().getModel("VendorService"),
				reqModel = this.getView().getModel("RequestModel").getObject("/");
			delete reqModel.HeaderToUserInfoNav;
			delete reqModel.__metadata;
			oData.create("/ReqHeaderSet", reqModel, {
				success: function (data) {
					this.getRouter().navTo("Home");
				}.bind(this),
				error: function (error) {
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		pad: function (num, size) {
			var s = num + "";
			while (s.length < size) s = "0" + s;
			return s;
		},

		onAddNewLine: function (oEvent) {
			var HeaderToRefNav = this.getView().getModel("RequestModel").getProperty("/HeaderToItemNav");
			var dataObject = {
				Docno: this.DrssNo,
				Mjahr: this.Mjahr,
				Zeile: "",
				Eqpdesc: "",
				Eqpconttype: "",
				Itype: "",
				Matnr: "",
				Maktxo: "",
				Wgbez: "",
				Leadtime: "",
				Mafd: "",
				Vendor: "",
				Meins: "",
				Menge: "",
				Rmenge: "",
				Rolegroup: "",
				Compmenge: "",
				Invmenge: "",
				Iphase: "",
				Badgeno: "",
				Ename: "",
				Workfrom: null,
				Workto: null,
				Wfstatus: "",
				Idiscount: "",
				ItemToCommNav: []
			};
			if (HeaderToRefNav.results.length > 0) {
				var iLastItemIndex = HeaderToRefNav.results.length - 1,
					iNewIndex = parseInt(HeaderToRefNav.results[iLastItemIndex].Zeile, 0) + 10;
				var Zeile = this.pad(iNewIndex, 4);
				dataObject.Zeile = Zeile;
				HeaderToRefNav.results.push(dataObject);
			} else {
				var results = [];
				dataObject.Zeile = "0010";
				results.push(dataObject);
				var object = {
					results: results
				};
				HeaderToRefNav.push(object);
			}
			this.getView().getModel("RequestModel").refresh();
		},

		onDeleteLine: function (oEvent) {
			var oItemsTable = this.getView().byId("lineItemsListGeneral"),
				oItemsModel = this.getView().getModel("RequestModel");
			var oItems = oItemsModel.getProperty("/HeaderToItemNav/results/"),
				index = oItemsTable.indexOfItem(oItemsTable.getSelectedItem());
			if (oItems.length > 0) {
				oItems.splice(index, 1);
				this.getView().getModel("RequestModel").refresh();
			} else {
				MessageBox.error("Please select atleast one line item to delete");
			}

		},

		//Open Dialog
		onValueHelp: function (evt) {
			var functions = [this.onSelectF4Value, this.onTaxiRouter, this.onSelectF4ValueByDescription];

			var tempData = evt.getSource().data();
			var params = {};
			var field;
			for (var property in tempData) {
				if (property === "Field") {
					field = tempData[property];
				}
				params[property] = tempData[property];
			}

			if (!this.F4Dialog) {
				this.F4Dialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.F4.F4Dialog", this);
				this.getView().addDependent(this.F4Dialog);
			}

			for (var i in functions) {
				this.F4Dialog.detachConfirm(functions[i], this);
			}

			var title = "Search for ";
			if (field === "ZZ_RIG_CD") {
				title += "RIG";
				this.F4Dialog.attachConfirm(evt.getSource(), this.onSelectF4ValueByValue, this);
			}
			if (field === "ZP_RS_PRRTY") {
				title += "Priority";
				this.F4Dialog.attachConfirm(evt.getSource(), this.onSelectF4ValueByValue, this);
			}
			if (field === "ZP_RS_XDOCTY") {
				title += "Reference";
				this.F4Dialog.attachConfirm(evt.getSource(), this.onSelectF4ValueByValue, this);
			}
			if (field === "TAXIREASON") {
				title += "Reason";
			}
			if (field === "ZP_RS_TVEH_TYPE") {
				title += "Vehicle Type";
				this.F4Dialog.attachConfirm(evt.getSource(), this.onSelectF4ValueByValue, this);
			}
			if (field === "ZP_RS_TROUTED") {
				title += "Route";
				this.F4Dialog.attachConfirm(evt.getSource(), this.onSelectF4ValueByValue, this);

			}
			if (field === "TAXITRIP") {
				title += "Trip";
				this.F4Dialog.attachConfirm(evt.getSource(), this.onSelectF4ValueByValue, this);
			}
			this.F4Dialog.setTitle(title);
			this.F4Dialog.open();
			this.loadDomainValues(params);
		},

		onSelectF4ValueByValue: function (dialogItem, oSource) {
			if (dialogItem.getParameters().hasOwnProperty("selectedItem")) {
				var sPath = dialogItem.getParameter("selectedItem").getBindingContextPath();
				var oModel = dialogItem.getParameter("selectedItem").getModel("F4Models");
				var dataObject = oModel.getProperty(sPath);
				oSource.setValue(dataObject.Value1);
			}
		},

		onSelectF4ValueByDescription: function (dialogItem, oSource) {
			if (dialogItem.getParameters().hasOwnProperty("selectedItem")) {
				var sPath = dialogItem.getParameter("selectedItem").getBindingContextPath();
				var oModel = dialogItem.getParameter("selectedItem").getModel("F4Models");
				var dataObject = oModel.getProperty(sPath);
				oSource.setValue(dataObject.Descr1);
			}
		},

		//Used to search a value within the dialog
		onDialogSearch: function (evt) {
			var sValue = evt.getParameter("value");
			var oList = evt.getSource();
			var aFilter = [];
			var oFilter = null;
			var oBinding = oList.getBinding("items");
			if (sValue && sValue.length > 0) {

				aFilter.push(new Filter("Descr1", FilterOperator.Contains, sValue));
				aFilter.push(new Filter("Value1", FilterOperator.Contains, sValue));
				oFilter = [new sap.ui.model.Filter(aFilter, false)];
			}
			oBinding.filter(oFilter);
		},

		onSelectF4Value: function (dialogItem, oSource) {
			if (dialogItem.getParameters().hasOwnProperty("selectedItem")) {
				var sPath = dialogItem.getParameter("selectedItem").getBindingContextPath();
				var oModel = dialogItem.getParameter("selectedItem").getModel("F4Models");
				var dataObject = oModel.getProperty(sPath);
				oSource.setValue(dataObject.Descr1);
			}
		},

		//Close the F4 Help
		onClose: function (evt) {
			evt.getSource().getParent().close();
		},

		loadDomainValues: function (fields) {
			var aFilters = [];
			for (var property in fields) {
				if (property === "Field") {
					this.field = fields[property];
				}
				aFilters.push(new Filter(property, FilterOperator.EQ, fields[property]));
			}
			var oDataModel = this.getView().getModel("VendorService");
			this.getView().setBusy(true);
			oDataModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					oData = oData.results;
					this.getView().getModel("F4Models").setProperty("/" + this.field, oData);
					this.bindF4DialogItems(this.field);
					this.getView().setBusy(false);
				}.bind(this),
				error: function (oResponse) {
					this.getView().setBusy(false);
					var msgs = this.getErrorMessages(oResponse);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		bindF4DialogItems: function (field) {
			this.F4Dialog.bindItems({
				path: "F4Models>/" + field + "/",
				template: this.F4Dialog.getBindingInfo("items").template
			});
		},

		instantiateErrorMessageModel: function (Messages) {
			if (Messages && Messages.length > 0) {
				this.getView().setModel(new JSONModel({
					MessageCount: Messages.length,
					Messages: Messages
				}), "ErrorMessagesModel");
			} else {
				this.getView().setModel(new JSONModel({}), "ErrorMessagesModel");
			}

			if (this.oMessagePopover) {
				this.oMessagePopover.close();
			}
		},

		//Instantiate MessagePopOver
		createMessagePopoverModel: function () {
			if (this.oMessagePopover) {
				this.oMessagePopover.close();
			}
			if (!this.oMessagePopover) {
				this.oMessagePopover = new sap.m.MessagePopover({
					items: {
						path: 'ErrorMessagesModel>/Messages/',
						template: new sap.m.MessageItem({
							type: "{ErrorMessagesModel>severity}",
							title: "{ErrorMessagesModel>message}"
						})
					}
				});
			}
			this.getView().byId("MessagePopoverBtn").addDependent(this.oMessagePopover);
			if (this.getView().getModel("ErrorMessagesModel").getProperty("/Messages") && this.getView().getModel("ErrorMessagesModel").getProperty(
					"/Messages").length > 0) {
				this.oMessagePopover.openBy(this.getView().byId("MessagePopoverBtn"));
			}
		},

		handleMessagePopoverPress: function () {
			if (this.oMessagePopover) {
				this.oMessagePopover.openBy(this.getView().byId("MessagePopoverBtn"));
			} else {
				this.createMessagePopoverModel();
			}
		},

		onWFTrigger: function (oEvent) {
			var oDataModel = this.getView().getModel("VendorService"),
				reqModel = this.getView().getModel("RequestModel").getObject("/");
			if (reqModel.Zeile === undefined) {
				var Zeile = "";
			}
			if (reqModel.Rolegroup === undefined) {
				var Rolegroup = "";
			}
			if (reqModel.Matnr === undefined) {
				var Matnr = "";
			}
			oDataModel.callFunction("/TriggerWF", {
				method: "GET",
				urlParameters: {
					Rqtype: reqModel.Rqtype,
					Docno: reqModel.Docno,
					Mjahr: reqModel.Mjahr,
					Initiator: reqModel.Reqid,
					Zeile: Zeile,
					Rolegroup: Rolegroup,
					Matnr: Matnr
				},
				success: function (oData) {
					sap.m.MessageToast.show("Workflow triggered successfully");
					this.getRouter().navTo("Inbox");
				}.bind(this),
				error: function (error) {
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});

		},

		onPrintSoW: function (oEvent) {
			var oDataModel = this.getView().getModel("VendorService"),
				reqModel = this.getView().getModel("RequestModel").getObject("/");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: reqModel.Docno,
				Year: reqModel.Mjahr,
				FormType: 'SW',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		onPrintPress: function (oEvent) {
			var oDataModel = this.getView().getModel("VendorService"),
				reqModel = this.getView().getModel("RequestModel").getObject("/");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: reqModel.Docno,
				Year: reqModel.Mjahr,
				FormType: 'RQ',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		onPrintACPress: function (oEvent) {
			var oDataModel = this.getView().getModel("VendorService"),
				reqModel = this.getView().getModel("RequestModel").getObject("/");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: reqModel.Docno,
				Year: reqModel.Mjahr,
				FormType: 'AC',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		onBeforeUploadStarts: function (oEvent) {
			var oUploadCollection = oEvent.getSource();
			var reqModel = this.getView().getModel("RequestModel").getObject("/");
			var sReqId = reqModel.Docno;
			var sYear = reqModel.Mjahr;
			var item = "";
			// Pass the info for uploading the file in the headers.
			this.AttachLevel = oEvent.getSource().data().Field;

			if (this.AttachLevel === "ItemAttach") {
				this.Catog = "02";
				item = this.attachData.Zeile;
			} else {
				this.Catog = "01"
				item = "0000";
			}

			var oSlugHeader = new sap.m.UploadCollectionParameter({
				name: "SLUG",
				value: oEvent.getParameter("fileName")
			});

			var oReqid_Header = new sap.m.UploadCollectionParameter({
				name: "REQID",
				value: sReqId
			});

			var oCate_Header = new sap.m.UploadCollectionParameter({
				name: "CATE",
				value: this.Catog
			});

			var oYear_Header = new sap.m.UploadCollectionParameter({
				name: "YEAR",
				value: sYear
			});

			var oItem_Header = new sap.m.UploadCollectionParameter({
				name: "ITEM",
				value: item
			});

			oEvent.getParameters().addHeaderParameter(oSlugHeader);
			oEvent.getParameters().addHeaderParameter(oReqid_Header);
			oEvent.getParameters().addHeaderParameter(oCate_Header);
			oEvent.getParameters().addHeaderParameter(oYear_Header);
			oEvent.getParameters().addHeaderParameter(oItem_Header);
		},

		onUploadComplete: function (oEvent) {
			var oModel = this.getView().getModel("VendorService");
			var docNo = this.DrssNo;
			var year = this.Mjahr;
			oModel.read("/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "')", {
				urlParameters: {
					"$expand": "HeaderToAttNav"
				},
				success: function (oData) {
					var Data = this.getView().getModel("RequestModel").getData();
					delete Data.HeaderToAttNav;
					Data.HeaderToAttNav = oData.HeaderToAttNav;
					this.getView().getModel("RequestModel").setData(null);
					this.getView().getModel("RequestModel").setData(Data);
					this.getView().getModel("RequestModel").refresh(true);
				}.bind(this),
				error: function (oResponse) {
					sap.m.MessageBox.error(JSON.parse(oResponse.responseText).oResponse.message.value);
				}.bind(this)
			});

		},

		onChange: function (oEvent) {
			/*var sServiceUrl = "/sap/opu/odata/sap/ZDWO_EDRSS_SRV";
			var headers = {
				"X-Requested-With": "XMLHttpRequest",
				"X-CSRF-Token": "Fetch"
			};
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, "false", "", "", headers, true);*/
			var oModel = this.getView().getModel("VendorService");
			sap.ui.getCore().setModel(oModel, "XCRFTokenModel");
			sap.ui.getCore().getModel("XCRFTokenModel").refreshSecurityToken();
			var sCsrfToken = sap.ui.getCore().getModel("XCRFTokenModel").getHeaders()["x-csrf-token"];
			var oUploadCollection = oEvent.getSource();
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: oModel.getSecurityToken()

			});
			oUploadCollection.addHeaderParameter(oCustomerHeaderToken);

		},

		/**
		 * When the Delete button is clicked, this function will be called.
		 * @private
		 */

		onFileDeleted: function (oEvent) {
			var oModel = this.getView().getModel("VendorService");
			var docId = oEvent.getParameter("documentId");
			var year = this.Mjahr;
			oModel.remove("/FileSet(Brelguid='" + docId + "')", {
				success: function (oData) {
					this.onUploadComplete();
				}.bind(this),
				error: function (oResponse) {
					sap.m.MessageBox.error(JSON.parse(oResponse.responseText).oResponse.message.value);
				}.bind(this)
			});
		},

		notificationPress: function (oEvent) {
			if(!this.ItemCommentsDialog){
				this.ItemCommentsDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.General.Items.Comments", this);	
				this.getView().addDependent(this.ItemCommentsDialog);	
			}
			this.ItemCommentsDialog.open();
			var sPath = evt.getSource().getParent().getParent().getBindingContextPath();
			this.ItemCommentsDialog.bindElement({ path: sPath, model: "RequestModel" });
			this.setSegmentedButtonItemSelection();
		},
		
		//Header Comments
		setSegmentedButtonItemSelection : function(){
			var segmentedButtonItemLevel = this.byId("segmentedButtonItemLevel");
			var key = segmentedButtonItemLevel.getSelectedKey();
			var buttons = segmentedButtonItemLevel.getItems();
			if(key !== ""){
				for(var i in buttons){
					var button = buttons[i];
					if(button.getKey() === key){
						segmentedButtonItemLevel.setSelectedKey(button.getKey());
						segmentedButtonItemLevel.fireSelectionChange({item:button});	
					}
				}	
			}
			else{
				segmentedButtonItemLevel.setSelectedKey(buttons[0].getKey());
				segmentedButtonItemLevel.fireSelectionChange({item:buttons[0]});
			}
		},

		//Fired when SegmentedButton (item comments) is clicked
		onItemCommentsPress: function (oEvent) {
			var ItemCommentsTxt = this.byId("ItemCommentsTxt");
			var sPath = oEvent.getParameter("item").getBindingContext("RequestModel").getPath();
			
			ItemCommentsTxt.unbindElement("requestModel");
			ItemCommentsTxt.bindElement({ path: sPath, model: "RequestModel" });
		},

		//Item Attachment
		attachPress: function (oEvent) {
			var oButton = oEvent.getSource(),
			oView = this.getView();
			var me = this;
		if (!me._pPopover) {
			 me._pPopover = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.General.Items.Attachments", me);
		}
		var data = oEvent.getSource().getParent().getBindingContext("RequestModel").getProperty(oEvent.getSource().getParent().getBindingContext(
		"RequestModel").getPath());
		me._pPopover.setModel(this.getView().getModel("RequestModel"), "RequestModel");
		me._pPopover.openBy(oButton);
		var oList = sap.ui.getCore().byId("UploadCollectionItem");
		var aFilter = [];
		var oFilter = null;
		var oBinding = oList.getBinding("items");
			//aFilter.push(new Filter("Category", FilterOperator.EQ, '02'));
			aFilter.push(new Filter("Zeile", FilterOperator.EQ, data.Zeile));
			oFilter = [new sap.ui.model.Filter(aFilter, false)];
		oBinding.filter(oFilter);
		
		},
		
		onWFAction: function(oEvent){
			var Data = oEvent.getSource().getBindingContext("RequestModel").getProperty(oEvent.getSource().getBindingContext("RequestModel").getPath());
			if(Data.RemarksReq === 'X'){				
				if (!this.oSubmitDialog) {
					this.oSubmitDialog = new Dialog({
						type: DialogType.Message,
						title: "Confirm",
						content: [
							new Label({
								text: "This request will be submitted for workflow. Do you want to continue ?",
								labelFor: "submissionNote"
							}),
							new sap.m.TextArea("submissionNote", {
								width: "100%",
								placeholder: "Remarks (required)",
								liveChange: function (oEvent) {
									var sText = oEvent.getParameter("value");
									this.oSubmitDialog.getBeginButton().setEnabled(sText.length > 0);
								}.bind(this)
							})
						],
						beginButton: new Button({
							type: ButtonType.Emphasized,
							text: "Submit",
							enabled: false,
							press: function () {
								var sText = Core.byId("submissionNote").getValue();
								this.WFExecuteAction(this.DrssNo,this.Mjahr,Data.Action,Data.Stattype,sText,this.Gid);
								this.oSubmitDialog.close();
							}.bind(this)
						}),
						endButton: new Button({
							text: "Cancel",
							press: function () {
								this.oSubmitDialog.close();
							}.bind(this)
						})
					});
				}
				this.oSubmitDialog.open();				
			}else{
				MessageBox.information("This Service Order will be submitted for workflow. Do you want to continue ?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: "sapUiSizeCompact",
					onClose: function (sAction) {
						if (sAction === "YES") {
							this.WFExecuteAction(this.DrssNo,this.Mjahr,Data.Action,Data.Stattype,'',this.Gid);
						}
					}.bind(this)
				});				
			}
		},
		
		onDispItemPress: function(oEvent) {
		
            var oItem     =  oEvent.getSource().getBindingContext('RequestModel').getObject();
            var oItemPath   =  oEvent.getSource().getBindingContext('RequestModel').sPath;
            var iPoNum    =   parseInt(oItem.PoNo);
            var iPoItem   =   parseInt(oItem.PoItem);
            var sLim_ind  = oItem.LimitInd;
            var sCO_ind   = oItem.CoInd;


            if((iPoNum !== 0) && (iPoItem !== 0)) {

              if(typeof sCO_ind === "undefined" || sCO_ind ==="") {

                if(oItem.PoNo.substring(0,2) === "66") {
                  sCO_ind = "C";
                } else {
                  sCO_ind = "PO";
                }

              }

              if(typeof sLim_ind === "undefined" || sLim_ind ==="") {
                sLim_ind = "0";
              }


               //this.getRouter().navTo("DispatchedServices", {objectId : this.getRequestId(), item: oItem.getProperty("Zeile"), EBELN: iPoNum, EBELP: iPoItem, lim_ind: sLim_ind, co_ind: sCO_ind  }, true);

              if (!this._DispServicesDialog) {
                this._DispServices = new DispatchedServicesSplit(this, "zdwo_nx_drss_ven.view.fragment.DispatchedServicesSplit");
           }
             	
             	 this._DispServicesDialog = this._DispServices.createFragment(this.DrssNo, oItem.Zeile, iPoNum, iPoItem, "", sLim_ind, sCO_ind);

             	return;
            }
            var oModel = this.getView().getModel("VendorService");
            //var oItem = this.getView().byId("lineItemsList").getSelectedItem().getBindingContext().getObject();
            //var oItemPath = this.getView().byId("lineItemsList").getSelectedItem().getBindingContext().sPath;

            new POContractSelector(this.getView(), oModel, this,this.getView().getModel('RequestModel').getProperty("/Lifnr"),
            		this.Rqtype,
                function(oPOItem){

                iPoNum  = oPOItem.EBELN;
                iPoItem = oPOItem.EBELP;

                  // Update the selected PO/Line item of the request.
                  oModel.callFunction("/SetPOForReqItm" , { method   : "GET",
                       urlParameters : {
                         Docno:   oItem.Docno,
                         Zeile:   oItem.Zeile,
                         PO:    oPOItem.EBELN,
                         PONO :   oPOItem.EBELP

                       },
                       success  : function(oData) {
                        // me.hit_list.setData(oData)
                         this.getView().getModel().setProperty(oItemPath + "/PoItem",oPOItem.EBELP);
                         this.getView().getModel().setProperty(oItemPath + "/PoNo",oPOItem.EBELN);

                        // console.log(oData);
                        var Contract = oPOItem.EBELN;
                        var Rqtype = this.Rqtype;
                        var that = this;
                       }.bind(this),
                       error    : function(error) {

                       }
                  });
                  // Navigate to Dispatched services.
                  //this.getRouter().navTo("DispatchedServices", {objectId : this.getRequestId(), item: oItem.Zeile, EBELN: oPOItem.EBELN, EBELP: oPOItem.EBELP }, true);

                  if (!this._DispServicesDialog) {
                    this._DispServices = new DispatchedServicesSplit(this, "zdwo_nx_drss_ven.view.fragment.DispatchedServicesSplit");
                  }

                  this._DispServicesDialog = this._DispServices.createFragment(this.DrssNo, oItem.Zeile, iPoNum, iPoItem, "", sLim_ind, sCO_ind);
            }.bind(this));
      },

		getJobLoggingModelData : function(){
			return this.getView().getModel("JobLoggingModel").getData();
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf zdwo_nx_drss_ven.view.InboxDetail
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zdwo_nx_drss_ven.view.InboxDetail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zdwo_nx_drss_ven.view.InboxDetail
		 */
		//	onExit: function() {
		//
		//	}

	});

});