var controller;
sap.ui.define([
	"./BaseController",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"zdwo_nx_drss_ven/model/formatter",
	"sap/ui/core/Fragment",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	"sap/m/MessageToast",
	'sap/ui/core/Core',
	"zdwo_nx_drss_ven/model/SrvTreeConversion",
	"sap/m/MessageBox",
	"zdwo_nx_drss_ven/utils/POContractSelector",
	"zdwo_nx_drss_ven/utils/DispatchedServicesSplit",
	"jquery.sap.global",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Label",
	"sap/m/library",
	"zdwo_nx_drss_ven/model/FormatterByReference",
	"sap/m/GroupHeaderListItem"
], function (
	BaseController,
	History,
	JSONModel,
	formatter,
	Fragment,
	Filter,
	FilterOperator,
	MessageToast,
	Core,
	SrvTreeConversion,
	MessageBox,
	POContractSelector,
	DispatchedServicesSplit,
	jQuery,
	Dialog,
	Button,
	Label,
	mobileLibrary,
	FormatterByReference, GroupHeaderListItem) {
	"use strict";
	// shortcut for sap.m.ButtonType
	var ButtonType = mobileLibrary.ButtonType;

	// shortcut for sap.m.DialogType
	var DialogType = mobileLibrary.DialogType;
	var oPreviousComments;
	return BaseController.extend("zdwo_nx_drss_ven.controller.WSView", {
		formatter: formatter,
		onInit: function () {
			controller = this;
			this.selectedcontxtForUOM = "";
			this.serviceCount = 0;
			this.oAttachments = [];
			this.selectedItem = "";
			this.SrvTreeConversion = SrvTreeConversion;
			this.itemDetails = '';
			this.headerColumnsData = "";
			this.AttachLevel = "";
			this.onUploadChange = "";
			this.itemsObj = "";
			this.Catog = "";
			this.itemValue = "";
			this.sSelectedReason = true;
			this.sWrkflwBtnTxt = "";
			this.oRejReasonText = "";
			this.searchField = this.getView().byId("searchfield");
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("WSView").attachPatternMatched(this._onObjectMatched, this);

			var oPOModel = new JSONModel();
			this.getView().setModel(oPOModel, "oPOModel");

			var oServiceModel = new JSONModel();
			this.getView().setModel(oServiceModel, "oServiceModel");

			var oETicketModel = new JSONModel();
			this.getView().setModel(oETicketModel, "oETicketModel");

			var oMonthlyListModel = new JSONModel();
			this.getView().setModel(oMonthlyListModel, "oMonthlyListModel");

			var oMonthlyListModel = new JSONModel();
			this.getView().setModel(oMonthlyListModel, "oMonthlyListModel");

			// Added for consolidated pdf
			//Store Timesheet Data
			var oTSModel = new JSONModel([]);
			this.getView().setModel(oTSModel, "oTSModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "JobLogModelPDF");

			var oSummaryReportModelDetail = new JSONModel([]);
			this.getView().setModel(oSummaryReportModelDetail, "oSummaryReportModelDetail");

			this.getView().setModel(new sap.ui.model.json.JSONModel([]), "JobLogFinalDataModel");
			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "MrDateRelModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "oTVDModel");
			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "oSensorOffsetModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "jobLog");

			var oFlagsModel = new JSONModel({
				"ItemsEditable": true,
				"ButtonsVisible": true
			});
			this.getView().setModel(oFlagsModel, "oFlagsModel");
			this.getView().setModel(new JSONModel({

			}), "SelectModel");

			//Holds LubSum enabled table data
			var aDisplayColumns = [{
					"label": "UoM",
					"keyName": "Unit"
				}

			];
			//if ((this.getView().getModel("UserInfoModel").getProperty("/Foreman") === '') && (this.getView().getModel("UserInfoModel").getProperty("/ForemanClerk") === '')) {
			aDisplayColumns.push({
				"label": "Unit Price",
				"keyName": "UnitPrice"
			});
			aDisplayColumns.push({
				"label": "Currency",
				"keyName": "Currency"
			});
			aDisplayColumns.push({
				"label": "Total Amount",
				"keyName": "Amount"
			});
			var oLSSummaryModel = new JSONModel({
				aUniqueColumns: [],
				aRows: [],
				aDisplayColumns: aDisplayColumns
			}); // display columns will be filled from onAfterRendering based on some conditions
			this.getView().setModel(oLSSummaryModel, "oLSSummaryModel");
			//	this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "oSaudizationModel");
			//PDF report configuration mapping
			var oPDFMappingModel = new JSONModel();
			this.getView().setModel(oPDFMappingModel, "oPDFMappingModel");

			var data = new JSONModel();
			this.getView().setModel(data, "data");
			this.busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
		},

		_onObjectMatched: function (evt) {
			controller = this;
			controller.ConsPdf = "";
			navBackFlg = "X";
			this.changeMade = "";
			this.sSelectedReason = true;
			this.itemDetails = evt.getParameter('arguments');
			this.DrssNo = evt.getParameter("arguments").DrssNo;
			this.Rqtype = evt.getParameter("arguments").Rqtype;
			this.Gid = evt.getParameter("arguments").Gid;
			this.Mjahr = evt.getParameter("arguments").Mjahr;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Sos = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Tvd = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Operations = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").refresh(true);
			this.getRequestData(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);
			this._MessageManager = Core.getMessageManager();
			//this.getServiceForms();
			// F4 Model 
			var f4Model = new JSONModel([]);
			this.getView().setModel(f4Model, "F4Models");
			//this.getETicketInfo();
			if (eTicket === "X") {
				this.onPreviewETicketPress();
			}
			eTicket = "";
			this.joblogginAttachment = [];

			controller.oForemanPdf = "";
			this.onConsolidatedPdfAll();
			controller.oForemanPdf = "X"
			this.onConsolidatedPdfAll();
		},

		// Addd based on Sathya Comments
		onPageRefresh: function () {
			this.getRequestData(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);
			this._MessageManager = Core.getMessageManager();
			// F4 Model 
			var f4Model = new JSONModel();
			this.getView().setModel(f4Model, "F4Models");
			//this.getETicketInfo();
			if (eTicket === "X") {
				this.onPreviewETicketPress();
			}
			eTicket = "";
			this.joblogginAttachment = [];
		},

		getJoblogging: function () {
			return new Promise(function (resolve, reject) {
				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", controller.DrssNo),
					new sap.ui.model.Filter("Mjahr", "EQ", controller.Mjahr)
				]
				this.busyDialog.open();
				this.getView().getModel("VendorService").read("/JobloggingFormsSet", {
					filters: oFilter,
					success: function (oData) {
						for (var i = 0; i < oData.results.length; i++) {
							if (oData.results[i].FormCode === "F020") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().Tvd = true;
							}

							if (oData.results[i].FormCode === "F021") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().Sos = true;
							}

							if (oData.results[i].FormCode === "F038") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().Operations = true;
							}
						}
						var oJsonModel = new JSONModel(oData.results);
						this.getView().setModel(oJsonModel, "JobLoggingModel");
						this.busyDialog.close();
						resolve(oData);
					}.bind(this),
					error: function (oError) {
						this.busyDialog.close();
						reject();
					}.bind(this)
				});
			}.bind(this));
		},

		_getAttachFormFiles: function () {
			var formLevel = "H";
			var oFilter = [new sap.ui.model.Filter("Docno", "EQ", this.itemDetails.DrssNo),
				new sap.ui.model.Filter("Mjahr", "EQ", this.itemDetails.Mjahr),
				new sap.ui.model.Filter("SrvtypeCode", "EQ", this.itemDetails.Rqtype),
				new Filter("FormLevel", FilterOperator.EQ, formLevel),
			];
			this.getView().setBusy(true);
			this.getView().getModel("VendorService").read("/ServiceFormsSet", {
				filters: oFilter,
				success: function (oData) {
					for (var i = 0; i < oData.results.length; i++) {
						if (oData.results[i].FormCode === "F020") {
							this.getOwnerComponent().getModel("JoblogFormsModel").getData().Tvd = true;
						}

						if (oData.results[i].FormCode === "F021") {
							this.getOwnerComponent().getModel("JoblogFormsModel").getData().Sos = true;
						}
					}
					this.getOwnerComponent().getModel("JoblogFormsModel").refresh(true);
					var oJsonModel = new JSONModel(oData.results);
					this.getView().setModel(oJsonModel, "AttServiceFormModel");
					this.getView().setBusy(false);
				}.bind(this),
				error: function (oError) {
					this.getView().setBusy(false);
				}.bind(this)
			});
		},

		// //Get Request Data
		getRequestData: function (docNo, year, Rqtype) {
			if (!docNo) {
				var docNo = this.DrssNo;
			}
			if (!year) {
				var year = this.Mjahr;
			}
			if (!Rqtype) {
				var Rqtype = this.Rqtype;
			}
			var oModel = this.getView().getModel("VendorService");
			this.busyDialog.open();
			oModel.read("/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + Rqtype + "')", {
				urlParameters: {
					"$expand": "HeaderToAttNav,HeaderToCommNav,HeaderToItemNav,HeaderToUserInfoNav,HeaderToWfLogNav,HeaderToItemNav/ItemToCommNav,HeaderToItemNav/ItemToEdrssNav,HeaderToWfActionNav"
				},
				success: function (oData) {
					this.prepareData(oData);
					//	this.SelectPriorities();
					this._getSelectModelFields(oData);
					this._getAttachFormFiles();

					if (oData.Jltab) {
						this.getJoblogging();
					}
					if (oData.Ettab) {
						this.getETicketInfo(oData.Rqstat);
						if (this.byId("iconTabBar2") && this.byId("iconTabBar3")) {
							this.getView().byId("iconTabBar2").setSelectedKey("eTicket");
							this.getView().byId("iconTabBar3").setVisible(false);
						}
					} else if (oData.Rqstat === "JOBL") {
						if (this.byId("iconTabBar2") && this.byId("iconTabBar3")) {
							this.getView().byId("iconTabBar3").setVisible(true);
							this.getView().byId("iconTabBar2").setSelectedKey("JobLogging");
						}
						this.getETicketInfo("rejectedETicket");
					} else {
						if (this.byId("iconTabBar2") && this.byId("iconTabBar3")) {
							this.getView().byId("iconTabBar3").setVisible(true);
							this.getView().byId("iconTabBar2").setSelectedKey("BasicData");
						}
					}

					this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(oResponse);
					var itemsModel = new JSONModel(null);
					itemsModel.setSizeLimit(5000);
					this.getView().setModel(itemsModel, "itemsModel");
					this.getView().getModel("itemsModel").refresh(true);
				}.bind(this)
			});
		},

		prepareData: function (oData) {
			this.removeResultProp(oData);
			var itemsModel = new JSONModel(oData);
			itemsModel.setSizeLimit(5000);
			this.getView().setModel(itemsModel, "itemsModel");
			//this.getView().setModel(new JSONModel(oData), "itemsModel");
			this.getView().getModel("itemsModel").setSizeLimit(5000);
			this.getOwnerComponent().getModel("itemsModel").setSizeLimit(5000);
			this.getOwnerComponent().getModel("itemsModel").setData(oData);
			if (oData.hasOwnProperty("HeaderToAttNav") && oData.HeaderToAttNav.length) {
				this.Attachments = oData.HeaderToAttNav;
			} else {
				oData.HeaderToAttNav = [];
			}
			var oPromis = this.getConfig(oData.Rqtype, oData.Fldvar);
			oPromis.then(this.onResolve, this.onReject);
			if (oData.Jledit) {
				controller.onGetConsPDFData();
			}
			//controller.onGetModelData();

		},
		checkPoItemFun: function (oitemsModel) {
			controller.checkpo = '';
			var itemsModelData = oitemsModel.getData();
			$.each(itemsModelData['HeaderToItemNav'], function (ind, obj) {
				if (obj['PoNo'] !== "") {
					controller.checkpo = obj['PoNo'];
					this.changeMade = "X";
					return;
				}
			}.bind(this));
		},

		onResolve: function (controller) {
			var model = controller.getView().getModel("itemsModel");
			if (controller.getView().getModel("itemsModel").getProperty("/Rqstat") === "INIT" ||
				controller.getView().getModel("itemsModel").getProperty("/Rqstat") === "") {
				controller.setViewMode(true);
			} else {
				controller.setViewMode(false);
			};
			controller.ItemCommentColor();
			controller.checkPoItemFun(model);
		},

		_getSelectModelFields: function (oData) {
			var oPromise = new Promise(function (resolve, reject) {
				var oModel = this.getView().getModel("oDataModel");
				var oSelectModel = this.getView().getModel("SelectModel");
				var oSelcData = oSelectModel.getData();
				var objData = {
					WellTyp: "",
					WellSiteTyp: "",
					Shoptyp: "",
					//	   Resrvpr: "",
					WellService: "",
					MtrlSource: "",
					JLSTATUS: ""
						// Itmstat: ""
				};

				for (var prop in objData) {
					//if (func.hasOwnProperty(prop)) {
					var aFilters = [];
					aFilters.push(new Filter("Field", FilterOperator.EQ, prop));
					aFilters.push(new Filter("Descr4", FilterOperator.EQ, oData.Rqtype));
					oModel.read("/F4SearchHelpSet", {
						filters: aFilters,
						success: function (oData) {
							if (oData.results.length > 0) {
								var odataField = oData.results[0].Descr2;
								if (odataField !== "") {
									if (odataField === "Resrvpr") {
										var obj = {
											Descr1: "",
											Value1: "00"
										}
										oData.results.unshift(obj)
									} else if (odataField === "Itmstat") {
										var obj = {
											Descr1: "",
											Value1: ""
										}
										oData.results.unshift(obj)
									}
									oSelcData[odataField] = oData.results;
									oSelectModel.refresh();
									console.log(oData);
								}
							}
							resolve();
						}.bind(this),
						error: function (oResponse) {
							var msgs = this.getErrorMessages(oResponse);
							reject();
						}.bind(this)
					});
					//  }
				}
			}.bind(this))
			return oPromise;
		},
		onSelectionChange: function (evt) {
			var source = evt.getSource();
			var isSelected = source.getSelected();
			var oSearchModel = this.searchHelpDialog.getModel("searchHelpModel");
			var selectedItem = source.getParent().getParent().getBindingContext("searchHelpModel").getObject();
			var index = oSearchModel.getData()['selectedItems'].indexOf(selectedItem);
			if (isSelected) {
				if (index < 0) {
					oSearchModel.getData()['selectedItems'].push(selectedItem);
				}
			} else {
				if (index > -1) {
					oSearchModel.getData()['selectedItems'].splice(index, 1);
				}
			}
			oSearchModel.refresh();
			this.checkTableItems();

		},

		checkTableItems: function () {
			var oTableItems = Core.byId("serviceSelectedTable").getItems();
			$.each(oTableItems, function (ind, obj) {
				obj.setSelected(true);
			});
			Core.byId("serviceSelectedTable").getModel("searchHelpModel").refresh();

		},

		onSelectedService: function (evt) {
			var oSource = evt.getParameter('selectedItem');

		},

		removeResultProp: function (oData) {
			for (var key in oData) {
				if (oData[key] && oData[key].hasOwnProperty("results")) {
					oData[key] = oData[key].results;
					for (var i in oData[key]) {
						this.removeResultProp(oData[key][i]);
					}
				}
			}
		},

		onSelectService: function (evt) {
			var oSource = evt.getSource();
			var isSelected = oSource.getSelected();

			if (isSelected) {
				var oObject = oSource.getParent().getParent().getBindingContext("searchHelpModel").getObject();

				this.selectedItem['Maktxo'] = oObject.ServStext;
				this.selectedItem['ServLtext'] = oObject.ServLtext;
				this.getView().getModel("itemsModel").refresh();
			}

		},

		onCloseAttachmentPopUp: function (evt) {
			this.sSelectedReason = true;
			evt.getSource().getParent().close();
		},

		onNavBack: function (oEvent) {
			//this.oRouter.navTo("Inbox");

			var oPgModel = this.getView().getModel("itemsModel");

			if (oPgModel['oData']['Rqstat'] === "SUBT" || oPgModel['oData']['Rqstat'] === "RSUB") {
				MessageBox.warning("Do you want to save the Service Order?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO, sap.m.MessageBox.Action.CANCEL],
					styleClass: "sapUiSizeCompact",
					onClose: function (sAction) {
						if (sAction === "YES") {
							var aPromise = [];
							aPromise.push(this.onSaveOC());
							Promise.all(aPromise).then(function (oRequest) {
								var oPageModel = this.getView().getModel("itemsModel").getData();
								/*if(this.itemDetails.DrssNo === "0000000000"){*/
								this.itemDetails.DrssNo = oPageModel.Docno;
								MessageBox.success("The Service Order has been saved with ID #" + oPageModel['Docno'], {
									actions: [MessageBox.Action.CLOSE],
									onClose: function () {
										/// var sPreviousHash = History.getInstance().getPreviousHash();
										history.go(-1);
									}.bind(this)
								});
								/*}*/
							}.bind(this));
						} else if (sAction === "CANCEL") {

						} else {
							history.go(-1);
						}
					}.bind(this)
				});
			} else {
				//history.go(-1);
				this.getRouter().navTo(history['state']['sap'].history[history['state']['sap'].history.length - 2]);
			}
		},

		/*	   prepareAttachments : function(attachments){
					//this.ItemsAttachmentsModel = this.getView().getModel("itemsAttachment").getData();
					
					this.attachments = attachments;
					this.headerLevelAttachments = [];
					this.itemsAttachmentsValues = [];
					this.joblogginAttachment = [];
					if (attachments.length>0){
					
						$.each(attachments,function(ind,obj){
							var attachItem = obj;
							    if (obj['Category'] === '03'){
								   this.joblogginAttachment.push(attachItem);
								  //var itemLevel = "03";
							    }else if(obj['Category'] === "01"){
								   this.itemsAttachmentsValues.push(attachItem);
							    }else {
							       this.headerLevelAttachments.push(attachItem);
							    }
								/*if(attachItem.Category === itemLevel ){
									this.headerLevelAttachments.push(attachItem);
								}
								else{
									this.itemsAttachmentsValues.push(attachItem);
									
								}*/
		/*		}.bind(this));
				}
			if (this.getView().getModel("itemsAttachment")){
				this.getView().getModel("itemsAttachment").setData(this.itemsAttachmentsValues);
				
			}else {
				this.getView().setModel(new JSONModel(this.itemsAttachmentsValues), "itemsAttachment");
			}
			
			this.getView().getModel("itemsAttachment").refresh();
			return this.headerLevelAttachments;
		},*/

		//Bind the header comments
		/*	onHeaderCommentsPress : function(oEvent){
				var commentsTxt = this.byId("commentsTxt");
				var sPath = oEvent.getParameter("item").getBindingContext("itemsModel").getPath();
				commentsTxt.bindElement({ path: sPath, model: "itemsModel" });
			},
			*/
		onHeaderCommentsPress: function (oEvent, oSelected) {
			var commentsTxt = this.byId("commentsTxt");
			var aSelectedKey = oEvent.getSource().getSelectedKey();
			if (oSelected === "Comments" || aSelectedKey === "HDR") {
				this.getView().byId("segmentedButton").setSelectedKey("HDR");
				sPath = "/HeaderToCommNav/0";
				commentsTxt.setRows(1);
				commentsTxt.setCols(100);
				commentsTxt.setMaxLength(72);
			} else {
				var sPath = oEvent.getParameter("item").getBindingContext("itemsModel").getPath();
				commentsTxt.setRows(10);
				commentsTxt.setCols(100);
				commentsTxt.setMaxLength(200);
			}
			commentsTxt.bindElement({
				path: sPath,
				model: "itemsModel"
			});

		},

		handleSelcHeader: function (evt) {
			var oSelectedTab = evt.getParameter("key");
			if (oSelectedTab === "Comments") {
				this.onHeaderCommentsPress(evt, oSelectedTab);
			}
			if (oSelectedTab === "eTicket") {
				this.getView().byId("iconTabBar3").setVisible(false);
			} else {
				this.getView().byId("iconTabBar3").setVisible(true);
			}
		},

		// On Drilling Program Search

		OnDrillingProgSearch: function (oEvent) {
			var sValue = oEvent.getParameter("query") + "*";
			var aFilters = [new Filter("DpPgmNum", FilterOperator.EQ, sValue)];
			var oModel = this.getOwnerComponent().getModel("VendorService");
			this.busyDialog.open();
			oModel.read("/DrillPgmSet", {
				filters: aFilters,
				success: function (oData) {
					console.log(oData);
					var model = new JSONModel(oData);
					this.getView().setModel(model, "DrillingModel");
					this.busyDialog.close();
				}.bind(this),
				error: function (Error) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(Error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}

			});
		},

		OnCpyFrOtherSearch: function (oEvent) {
			var sValue = oEvent.getParameter("query") + "*";
			var aFilters = [new Filter("Wellnm", FilterOperator.EQ, sValue),
				new Filter("Rqtype", FilterOperator.EQ, this.itemDetails.Rqtype)
			];
			var oModel = this.getOwnerComponent().getModel("VendorService");
			this.busyDialog.open();
			oModel.read("/ServiceSearchWellSet", {
				filters: aFilters,
				success: function (oData) {
					console.log(oData);
					var model = new JSONModel(oData);
					this.getView().setModel(model, "cpyfotherModel");
					this.busyDialog.close();
				}.bind(this),
				error: function (Error) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(Error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}

			});
		},

		/*onSelectServiceClose: function (evt) {
			var oSelectedItems = sap.ui.getCore().byId("checkedList").getSelectedItems();
		    this.checkforSelectedService(oSelectedItems,"service");
			this.searchHelpDialog.close();
		},
		*/
		onWFRemarks: function (evt) {
			if (!this.WFRemarksDialog) {
				this.WFRemarksDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.OC.WFRemarksDialog", this);
				this.getView().addDependent(this.WFRemarksDialog);
			}
			this.WFRemarksDialog.open();
		},
		onCloseWFRemarks: function () {
			if (this.WFRemarksDialog) {
				this.WFRemarksDialog.close();
			}
			if (this.WFRemakDialog) {
				this.WFRemakDialog.close();
			}
		},

		// Seach Help Dialog Fragment
		onValueHelp: function (evt) {
			var me = this;
			var oSource = evt.getSource();
			this.core = Core;
			this.pageModel = this.getView().getModel("itemsModel").getData();
			if (oSource.getParent().getBindingContext("itemsModel")) {
				this.selectedItem = oSource.getParent().getBindingContext("itemsModel").getObject();
				controller.oSelectedObj = oSource.getParent().getBindingContext("itemsModel").getObject();
				controller.oSelLocConstVal = controller.oSelectedObj.WellService;
			}
			if (me.searchHelpDialog && me.serviceCount === 1) {
				/* var oSuggestionItem = sap.ui.getCore().byId("suggestionItems");
	           if (oSuggestionItem && this.itemDetails.srvDesc !==""){
		           oSuggestionItem.setSelectedKey(this.itemDetails.serviceDesc);
	            }*/
				Core.byId("searchField").setValue("");
				me.searchHelpDialog.open();
			} else {
				var promise = new Promise(function (resolve, reject) {
					me.getSelectedServiceData(me.pageModel.SrvtypeCode).then(function (response) {
						if (me.serviceCount === 0 && !me.searchHelpDialog || me.searchHelpDialog) {
							if (me.searchHelpDialog) {
								me.searchHelpDialog.destroyContent();
							}
							me.searchHelpDialog = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.SearchHelpForService", me);
							me.serviceCount++;
						} else {
							me.serviceCount++;
						}
						var oData = [];
						oData.ServiceItemsTable = response;
						oData.selectedItems = [];
						me.service = oData;
						var model = new JSONModel(oData);
						me.searchHelpDialog.setModel(model, "searchHelpModel");
						me.searchHelpDialog.open();
						me.core.byId("searchField").setValue("");
						me.searchHelpDialog.getModel("searchHelpModel").refresh();
						if (me.pageModel.SrvtypText && me.pageModel.SrvtypText !== "") {
							var oSuggestionItem = Core.byId("selectedSrcCode");
							if (oSuggestionItem) {
								oSuggestionItem.setValue(me.pageModel.SrvtypText);
							}
						}
					});
				});
			}
		},

		// on mode select
		onListCheck: function (evt) {
			var oSelectedTableItem = evt.getParameter("listItem").getBindingContext("searchHelpModel").getObject();
			var sSelTabItemProperty = oSelectedTableItem['Serviceid'];
			var aTreeItems = sap.ui.getCore().byId("serviceSelectId");
			for (var x = 0; x < aTreeItems.getItems().length; x++) {
				var oTempItemData = aTreeItems.getItems()[x].getBindingContext("searchHelpModel").getObject();
				if (sSelTabItemProperty === oTempItemData['Serviceid']) {
					oTempItemData['selected'] = false;
				}
			}
			aTreeItems.getModel("searchHelpModel").refresh();
			var oSearchModel = this.searchHelpDialog.getModel("searchHelpModel");
			var index = oSearchModel.getData()['selectedItems'].indexOf(oSelectedTableItem);
			oSearchModel.getData()['selectedItems'].splice(index, 1);
			oSearchModel.refresh();
			this.checkTableItems();
		},

		loadServiceList: function () {
			var that = this;
			that.model = this.getOwnerComponent().getModel("VendorService");
			var promise = new Promise(function (resolve, reject) {
				//  var aFilters = [new Filter("SrvtypeCode", FilterOperator.EQ, that.servtypeItem),];
				that.model.read("/ServiceTypesSet", {
					success: function (oData) {
						//	that.prepareData(oData);
						resolve(oData);
					},
					error: function (Error) {
						reject(Error);
					}
				});
			});
			return promise;
		},

		// On service search based on each item
		selectChange: function (oEvent, serviceDesc) {
			var that = this;
			if (oEvent) {
				if (oEvent.getParameter('selectedItem') != null) {
					this.selectedKey = oEvent.getParameter('selectedItem').getKey();
				}

			} else {
				this.selectedKey = serviceDesc;
			}
			var promise = new Promise(function (resolve, reject) {
				that.getSelectedServiceData(that.selectedKey).then(function (response) {
					that.searchHelpDialog.getModel("searchHelpModel").getData().ServiceItemsTable = response;
					that.searchHelpDialog.getModel("searchHelpModel").refresh();
				});
			});
		},

		getSelectedServiceData: function (oSelcSrvKey) {
			var that = this;
			var oPageModel = this.getView().getModel("itemsModel").getData();
			that.model = this.getOwnerComponent().getModel("VendorService");
			var aFilters = [new Filter("SrvtypeCode", FilterOperator.EQ, oSelcSrvKey),
				new Filter("Location", FilterOperator.EQ, oPageModel['Location']),
				new Filter("Radius", FilterOperator.EQ, oPageModel['Radius']),
				new Filter("HoleSize", FilterOperator.EQ, oPageModel['HoleSize'])
			];
			var promise = new Promise(function (resolve, reject) {
				that.model.read("/ServiceMasterSet", {
					filters: aFilters,
					success: function (oData) {
						oData = that.SrvTreeConversion.prepareTree(oData);
						//	that.prepareData(oData);
						resolve(oData);
					}.bind(this),
					error: function (Error) {
						//	reject(Error);
					}
				});
			});
			return promise;
		},

		// Select UOM 
		selectUOM: function (evt) {
			this.selectedcontxtForUOM = evt.getSource().getParent().getBindingContext("itemsModel").getObject();
			var getData = evt.getSource().data();
			/*if (!this.uomDialog){*/
			var oDataModel = this.getView().getModel("oDataModel");
			var aFilters = [new Filter("Field", FilterOperator.EQ, getData.Field),
				new Filter("Rqtype", FilterOperator.EQ, "E5")
			];
			oDataModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oRes) {
					var oModel = new JSONModel(oRes);
					if (!this.uomDialog) {
						this.uomDialog = sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.UOMDialog", this);
					}
					this.uomDialog.setModel(oModel, "UOM");
					this.uomDialog.open();
				}.bind(this),
				error: function (error) {}
			});
			/*}
			else {
				this.uomDialog.open();
			}*/
		},

		UOMhandleClose: function (evt) {
			var getItem = evt.getParameter("selectedItem").getBindingContext("UOM").getObject();
			this.selectedcontxtForUOM.Meins = getItem.Value1;
			this.getView().getModel("itemsModel").refresh();
		},

		onSelectServiceClose: function (evt) {
			//var oSelectedItems = Core.byId("serviceSelectedTable").getSelectedItems();

			//this.checkforSelectedService(oSelectedItems,"service");
			if (this.itemDetails.Rqtype === "EW3" || this.itemDetails.Rqtype === "EW4") {
				var oSelectedItems = this.searchHelpDialog.getModel("searchHelpModel").getData()['selectedItems'];
				this._WScheckforSelectedService(oSelectedItems, "service");
			} else {
				var oSelectedItems = Core.byId("serviceSelectedTable").getSelectedItems();
				this.checkforSelectedService(oSelectedItems, "service");
			}
			this.searchHelpDialog.close();
			this.checkForDuplicates();
			this.serviceCount = 0;
		},

		checkForDuplicates: function () {

			this.UniqueData = [];
			this.sDuplicateSrvid = [];
			if (controller.aDuplicates.length > 0) {
				var sDuplicateLineItem = "";
				$.each(controller.aDuplicates, function (ind, obj) {
					if (ind === 0) {
						sDuplicateLineItem = obj['Zeile'];
					} else {
						//var iCheckMatch = this.matchString(sDuplicateLineItem, obj['Zeile'], 'ig');
						//  if (iCheckMatch.length === 0){
						sDuplicateLineItem = sDuplicateLineItem + ", " + obj['Zeile'];
						//  }
					}
				}.bind(this));

				MessageBox.information("Selected Service ID was already added at line item #" + sDuplicateLineItem);
			}
			this.sequenceOrder();
		},

		sequenceOrder: function () {
			var oModel = this.getView().getModel("itemsModel");
			this.itemData = oModel.getProperty("/HeaderToItemNav");
			var oSeq = [];
			$.each(this.itemData, function (ind, obj) {
				if (ind === 0) {
					iNewIndex = parseInt("0000") + 10;
				} else {
					var iLastItemIndex = oSeq.length - 1,
						iNewIndex = parseInt(oSeq[iLastItemIndex].Zeile) + 10;
				}
				var Zeile = this.addZeil(iNewIndex, 4);
				//  var count = (ind+1).toString();
				obj.Zeile = Zeile;
				oSeq.push(obj);

			}.bind(this));
			oModel.getData()['HeaderToItemNav'] = oSeq;
			this.getView().byId("ReferenceTable").getModel("itemsModel").refresh();
		},

		clearTableItems: function (evt) {
			var oData = Core.byId("serviceSelectedTable").getModel("searchHelpModel").getData();
			oData.selectedItems = [];
			Core.byId("serviceSelectedTable").getModel("searchHelpModel").refresh();
			this.serviceCount = 0;
			this.searchHelpDialog.close();
			this.onValueHelp(evt);
		},

		onCloseSearchDialog: function () {
			this.searchHelpDialog.close();
		},

		onFilterServiceSearchm: function () {
			var that = this;
			var promise = new Promise(function (resolve, reject) {
				that.getSelectedServiceData().then(function (response) {
					that.getView().setModel(model, "itemsDialog");
					that.getView().getModel("itemsDialog").refresh();
				});
			});
		},

		onDialogSuggest: function (event) {
			var sValue = event.getParameter("suggestValue"),
				aFilters = [];
			if (sValue) {
				aFilters = [
					new Filter([
						new Filter("Fieldtext", function (sText) {
							return (sText || "").toUpperCase().indexOf(sValue.toUpperCase()) > -1;
						})

					], false)
				];
			}
			this.oSearchField.getBinding('suggestionItems').filter(aFilters);
			this.oSearchField.suggest();
		},

		addStagePress: function () {
			// Still not implemented
			this.searchHelpDialog.close();
		},

		_WScheckforSelectedService: function (oSelectedData, oValue, oModelName) {
			var oModel = this.getView().getModel("itemsModel");
			var HeaderToRefNav = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var aItems = oModel.getProperty("/HeaderToItemNav");
			controller.aDuplicates = [];
			this.custHeaderToItemNav = [];

			$.each(oSelectedData, function (ind, obj1) {
				var lineItem = '';
				for (var i in aItems) {
					if (aItems[i]['ServLtext'] === "") {
						var obj = aItems[i];
						var lineItem = aItems[i]['Zeile'];
						break;
					}
				}
				if (lineItem === '') {
					var obj = this.addItem();
				}

				// check deplicates
				var oCheckValues = aItems.filter(item => obj1['ServLtext'] === item['Maktxo'] && item['WellService'] === controller.oSelLocConstVal);
				if (oCheckValues.length > 0) {
					controller.aDuplicates.push(oCheckValues[0]);
					return;
				}
				var itmFilled = "";
				console.log("location Cons Value    " + controller.oSelLocConstVal);
				if (lineItem !== '') {
					obj.Maktxo = obj1['ServStext'];
					obj.ServLtext = obj1['ServLtext'];

				} else {

					for (var xy in aItems) {
						if (aItems[xy].ServLtext === "" && aItems[xy].Maktxo === "" && (aItems[xy].WellService === controller.oSelLocConstVal)) {
							aItems[xy].Maktxo = obj1['ServStext'];
							aItems[xy].ServLtext = obj1['ServLtext'];
							itmFilled = "X";
							break;
						}
					}
					if (itmFilled == '') {
						var obj = this.addItem();
						var iLastItemIndex = HeaderToRefNav.length - 1,
							iNewIndex = parseInt(HeaderToRefNav[iLastItemIndex].Zeile) + 10;
						var Zeile = this.addZeil(iNewIndex, 4);
						obj.Zeile = Zeile;
						obj.ItemToCommNav[0].Zeile = Zeile;
						obj.Maktxo = controller.oSelLocConstVal;
						obj.ServLtext = obj1['ServLtext'];
						obj.WellService = controller.oSelLocConstVal;

						obj.Wellnm = controller.oSelectedObj.Wellnm;
						obj.CoordLat = controller.oSelectedObj.CoordLat;
						obj.CoordLon = controller.oSelectedObj.CoordLon
						obj.CoordZn = controller.oSelectedObj.CoordZn

						if (itmFilled === '') {
							oModel.getData().HeaderToItemNav.push(obj);
						}
					}
				}

			}.bind(this));
			oModel.refresh();
			console.log(controller.aDuplicates);
			controller.oSelectedObj = "";
			//	controller.duplicates = aDuplicates;
			return oSelectedData;
		},

		// Create Page Selection
		checkforSelectedService: function (oSelectedData, oValue, oModelName) {
			var oModel = this.getView().getModel("itemsModel");
			var HeaderToRefNav = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var getData = oModel.getProperty("/HeaderToItemNav");
			controller.aDuplicates = [];
			//  var pageModelData = oModel.getData()['HeaderToItemNav'];
			this.custHeaderToItemNav = [];
			$.each(oSelectedData, function (ind, obj1) {
				var obj = this.addItem();

				// this.itemsObj  = obj;
				var pageModelData = oModel.getData()['HeaderToItemNav'];
				if (oValue === "service") {
					var oObject = obj1.getBindingContext("searchHelpModel").getObject();

					var sText = "";
					if (oObject['ServStext']) {
						var sText = oObject['ServStext']
					} else {
						var sText = oObject['ServLtext']
					}
					if (oModel.getData().HeaderToItemNav.length === 1 && ind === 0 && oModel.getData().HeaderToItemNav[ind].Maktxo === "") {
						obj.Maktxo = oObject['ServStext'];
						obj.ServLtext = oObject['ServLtext'];
					} else {
						var HeaderToRefNav = oModel.getData()['HeaderToItemNav'];
						var iLastItemIndex = HeaderToRefNav.length - 1,
							iNewIndex = parseInt(HeaderToRefNav[iLastItemIndex].Zeile) + 10;
						var Zeile = this.addZeil(iNewIndex, 4);
						obj.Zeile = Zeile;
						obj.ItemToCommNav[0].Zeile = Zeile;
						obj.Maktxo = sText;
						obj.ServLtext = oObject['ServLtext'];
					}
					obj.Meins = oObject.UOM;
					if (!oObject.Serviceid) {
						oObject.Serviceid = "";
					}
					obj.ServiceId = oObject.Serviceid;

					// check deplicates
					var oCheckValues = getData.filter(item => obj['Maktxo'] === item['Maktxo']);
					if (oCheckValues.length > 0) {
						controller.aDuplicates.push(oCheckValues[0]);
						return;
					}

					if (ind === 0) {
						controller.oSelectedObj['Maktxo'] = sText;
						controller.oSelectedObj['ServLtext'] = oObject['ServLtext'];
						controller.oSelectedObj['Meins'] = obj.Meins;
						controller.oSelectedObj['ServiceId'] = obj.ServiceId;
						return;
					}

				}

				if (pageModelData[pageModelData.length - 1].Maktxo === '') {
					var lastIndexData = pageModelData[pageModelData.length - 1];
					lastIndexData.Maktxo = obj.Maktxo;
					lastIndexData.ServLtext = obj['ServLtext'];
					lastIndexData.Meins = obj.Meins;
					if (!obj.Serviceid) {
						oObject.Serviceid = "";
					}
					lastIndexData.ServiceId = obj.ServiceId;
				} else {
					if (oModel.getData().HeaderToItemNav.length === 1 && ind === 0 &&
						oModel.getData().HeaderToItemNav[ind].Maktxo === "") {
						oModel.getData().HeaderToItemNav[0].Maktxo = obj.Maktxo;
						oModel.getData().HeaderToItemNav[0].ServLtext = obj['ServLtext'];
					} else {
						oModel.getData().HeaderToItemNav.push(obj);
					}
				}

			}.bind(this));
			oModel.refresh();
			return oSelectedData;
		},

		// Add Stage for the copy from other well
		onCpyPressforCopyfrmDrss: function (evt) {
			//this.getView().byId("copyFromOtherWellTable").getSelectedItems()[0].getBindingContext("DrillingModel").getObject()
			var oTable = this.getView().byId("copyFromOtherWellTable");
			var oSelectedItems = oTable.getSelectedItems();
			this.checkforSelectedService(oSelectedItems, "cpyfdrss");
			var removeSelections = oTable.removeSelections(true);
			if (oSelectedItems.length > 0) {
				this.getView().byId("iconTabBar3").setSelectedKey("Item Information");
			}

			//this.searchHelpDialog.close();
		},

		// Search Help Dialog ends here
		// On View Search Suggest starts here
		onViewItemSuggest: function (event) {
			var sValue = event.getParameter("suggestValue"),
				aFilters = [];
			if (sValue) {
				aFilters = [
					new Filter([
						new Filter("Fieldtext", function (sText) {
							return (sText || "").toUpperCase().indexOf(sValue.toUpperCase()) > -1;
						})

					], false)
				];
			}
			this.searchField.getBinding('suggestionItems').filter(aFilters);
			this.searchField.suggest();
		},
		// On View Suggest search ends here	

		onClose: function () {
			if (this._ItemsCommondialog) {
				this._ItemsCommondialog.close();
			}
			if (this.JobLogAttachmentsDialog) {

				this.JobLogAttachmentsDialog.close();
				this.JobLogAttachmentsDialog.destroy();
				delete this.JobLogAttachmentsDialog
			}

		},

		getItemsDialogs: function () {
			var me = this;
			var promise = new Promise(function (resolve, reject) {
				me.gModel.callFunction("/SHELP_GET_FIELDS", {
					method: "GET",
					urlParameters: {
						SHLPNAME: "ZUPLG_DOCNO_SH",
						SHLPTYPE: "SH"
					},
					success: function (oData) {
						resolve(oData);
						//console.log(oData);
					},
					error: function (error) {
						reject(error);
					}
				});
			});
			return promise;
		},

		checkValidation: function () {
			var errorList = this.validationControlsByFieldGroupId();
			this.instantiateErrorMessageModel(errorList);
			this.createMessagePopoverModel();
			return errorList;
		},

		removeParams: function (items) {
			$.each(items['HeaderToItemNav'], function (ind, obj) {
				if (obj['SplArray'] || obj['EText']) {
					delete obj['SplArray'];
					delete obj['EText'];
				}
			}.bind(this))

			return items;
		},

		onSaveOC: function (evt) {
			var me = this;
			var oModel = this.getOwnerComponent().getModel("VendorService");
			var itemModel = this.getView().getModel("itemsModel");
			itemModel.getData()['HeaderToItemNav'] = this._AddedByVendorsItems(itemModel.getData()['HeaderToItemNav']);
			this.reqItems = itemModel.getData();
			// Validation check
			var configModel = this.getView().getModel("configModel");
			var configData = configModel.getData();
			return new Promise(function (resolve, reject) {
				var errorCheck = this.checkValidation();

				if (errorCheck.length > 0) {
					reject();
					return;

				}
				// OData Service Request
				var length = this.reqItems.HeaderToItemNav.length;
				for (var i = 0; i < length; i++) {
					if (configData['maktxowc'].Visible && this.reqItems.HeaderToItemNav[i].ServLtext === "" && configData['maktxowc'].Editable) {
						sap.m.MessageBox.error("Service Name cannot be empty");
						return;
					}

					/*if(this.reqItems.HeaderToItemNav[i].Menge === ""){
						sap.m.MessageBox.error("Service Quantity cannot be empty");
						return;
					}*/
					if (configData['meins'].Visible) {
						if (this.reqItems.HeaderToItemNav[i].Meins === "" && configData['meins'].Editable) {
							sap.m.MessageBox.error("Service UoM cannot be empty");
							return;
						}
					}
				}
				delete this.reqItems['HeaderToUserInfoNav'];
				delete this.reqItems['Hole_Size'];
				delete this.reqItems['radius'];
				delete this.reqItems['RS_PRRTY'];

				// Remove length from a vendor name 12/02/2022
				/* if (this.reqItems['VEND_NAME'].length>30){
				 this.reqItems['VEND_NAME'] = this.reqItems['VEND_NAME'].slice(0,29);
				 }*/

				this.OnAddCmdtoField();
				this.reqItems = this.removeParams(this.reqItems);
				oModel.create("/ReqHeaderSet", this.reqItems, {
					method: "POST",
					success: function (oData) {
						if (this.itemDetails.DrssNo === "0000000000") {
							this.itemDetails.DrssNo = oData.Docno;
							sap.m.MessageToast.show("The Service Order has been created with ID #" + oData.Docno);
						} else {
							sap.m.MessageToast.show("The Service Order ID # " + oData.Docno + " has been successfully updated");
						}
						this.prepareData(oData);
						this.busyDialog.close();
						resolve();
						this.instantiateErrorMessageModel();
						this.resetFieldGroupIdValueState();
						this.busyDialog.close();
					}.bind(this),
					error: function (oResponse, error) {
						this.busyDialog.close();
						var msgs = this.getErrorMessages(oResponse);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();
					}.bind(this)
				});

			}.bind(this));
		},

		getErrorMsg: function (oResponse) {
			return JSON.parse(oResponse.responseText).error.message.value;

		},

		instantiateErrorMessageModel: function (Messages) {
			if (Messages && Messages.length > 0) {
				this.getView().setModel(new JSONModel({
					MessageCount: Messages.length,
					Messages: Messages
				}), "ErrorMessagesModel");
			} else {
				this.getView().setModel(new JSONModel({}), "ErrorMessagesModel");
			}

			if (this.oMessagePopover) {
				this.oMessagePopover.close();
			}
		},

		//Instantiate MessagePopOver
		createMessagePopoverModel: function () {
			if (this.oMessagePopover) {
				this.oMessagePopover.close();
			}
			if (!this.oMessagePopover) {
				this.oMessagePopover = new sap.m.MessagePopover({
					items: {
						path: 'ErrorMessagesModel>/Messages/',
						template: new sap.m.MessageItem({
							type: "{ErrorMessagesModel>severity}",
							title: "{ErrorMessagesModel>message}"
						})
					}
				});
			}
			this.getView().byId("MessagePopoverBtn").addDependent(this.oMessagePopover);
			if (this.getView().getModel("ErrorMessagesModel").getProperty("/Messages") && this.getView().getModel("ErrorMessagesModel").getProperty(
					"/Messages").length > 0) {
				this.oMessagePopover.openBy(this.getView().byId("MessagePopoverBtn"));
			}
		},

		// Message Handler
		handleMessagePopoverPress: function () {
			if (this.oMessagePopover) {
				this.oMessagePopover.openBy(this.getView().byId("MessagePopoverBtn"));
			} else {
				this.createMessagePopoverModel();
			}
		},

		onShowHideMaster: function () {
			var oAppView = this.getOwnerComponent().getModel("appView"),
				sMode;
			sMode = oAppView.getProperty("/mode");
			//	(sMode === "ShowHideMode") ? oAppView.setProperty("/mode", ("HideMode")): oAppView.setProperty("/mode", ("ShowHideMode"));
		},

		onCloseDialog: function () {
			this.selectFragment.close();
		},

		addZeil: function (num, size) {
			var s = num + "";
			while (s.length < size) s = "0" + s;
			return s;
		},

		onAddNewLine_ref: function (oEvent) {
			this.changeMade = "X";
			this.changeWFActionButton();
			//	var HeaderToRefNav = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");

			this.itemsObj = dataObject;

			var HeaderToRefNav = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var dataObject = this.addItem();
			var aCheckItem = [];
			/*$.each(HeaderToRefNav,function(ind,obj){
			}.bind(this));*/

			for (var ind in HeaderToRefNav) {
				if (HeaderToRefNav[ind]['Maktxo'] === "" && (HeaderToRefNav[ind]['ServLtext'] === "" || typeof HeaderToRefNav[ind]['ServLtext'] ===
						'undefined')) {
					sap.m.MessageBox.error("Please fill the added line item");
					return
				}
			}

			if (HeaderToRefNav) {
				var iLastItemIndex = HeaderToRefNav.length - 1,
					iNewIndex = parseInt(HeaderToRefNav[iLastItemIndex].Zeile) + 10;
				var Zeile = this.addZeil(iNewIndex, 4);
				dataObject.Zeile = Zeile;
				HeaderToRefNav.push(dataObject);
			} else {
				var results = [];
				dataObject.Zeile = "0010";
				results.push(dataObject);
				HeaderToRefNav = results;
			}
			this.getView().getModel("itemsModel").refresh();
		},

		addItem: function () {

			var oModel = this.getView().getModel("itemsModel");
			var HeaderToRefNav = oModel.getProperty("/HeaderToItemNav");
			var DataForPoItem = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav/0");
			var PoNo = DataForPoItem.PoNo;
			var PoItem = DataForPoItem.PoItem;
			var PckgNo = DataForPoItem.PckgNo;
			var LineNo = DataForPoItem.LineNo;
			/// var getData = oModel.getProperty("/HeaderToItemNav");
			if (oModel.getData().HeaderToItemNav.length > 0) {
				var iLastItemIndex = HeaderToRefNav.length - 1;
				var iNewIndex = parseInt(HeaderToRefNav[iLastItemIndex].Zeile) + 10;
				var Zeile = this.addZeil(iNewIndex, 4);
			} else {

				var Zeile = "0010";
			}

			var item = {
				Docno: this.itemDetails.DrssNo,
				Mjahr: this.itemDetails.Mjahr,
				Zeile: "",
				Eqpdesc: "",
				Eqpconttype: "",
				Itype: "",
				Matnr: "",
				Maktxo: "",
				ServLtext: "",
				Wgbez: "",
				ServiceId: "",
				Leadtime: "000",
				Mafd: "",
				Vendor: "",
				Meins: "",
				Menge: "0.000",
				Rmenge: "0",
				Rolegroup: "",
				FcompMenge: "0",
				Iphase: "",
				//Badgeno: "",
				PoNo: PoNo,
				PoItem: PoItem,
				PckgNo: PckgNo,
				LimitInd: "",
				LineNo: LineNo,
				CoInd: "",
				GrPrice: "0.00",
				Curr: "",
				/*VenGrPrice:"0.000",*/
				VenGrPrice: "0.00",
				/*VenPropQty:"0",*/
				VenPropQty: "0.000",
				Ename: "",
				WorkFrom: null,
				WorkTo: null,
				Wfstatus: "",
				Discount: "0.000",
				VendorAdd: "X1",
				DelInd: "",
				ItemToCommNav: [{
					Descrip: HeaderToRefNav[0].ItemToCommNav[0].Descrip,
					Text: "",
					Docno: HeaderToRefNav[0].ItemToCommNav[0].Docno,
					Mjahr: HeaderToRefNav[0].ItemToCommNav[0].Mjahr,
					Ntdid: HeaderToRefNav[0].ItemToCommNav[0].Ntdid,
					Tdid: HeaderToRefNav[0].ItemToCommNav[0].Tdid,
					Tdobject: HeaderToRefNav[0].ItemToCommNav[0].Tdobject,
					Txttype: HeaderToRefNav[0].ItemToCommNav[0].Txttype,
					Zeile: Zeile
				}]
			};

			// Add item Based on Configuration Visibility
			var configModel = this.getView().getModel("configModel");
			if (configModel) {
				var configData = configModel.getData();
				// Location coordinates
				if (configData['coordn_item'].Visible) {
					item.CoordLat = "";
					item.CoordLon = "";
					item.CoordZn = "";
				}

				// Cons Selection
				if (configData['const_sel'].Visible) {
					item.WellService = "1";
				}

				//Trail Number 
				/*if (configData['trailnm_item'].Visible){
				   item.Trailnm = "0000";
				}*/

				//Water Table
				/*if (configData['watrtbl'].Visible){
				   item.Watrtbl = "";
				}
				*/
				//Well Number
				if (configData['wellnm_item'].Visible) {
					item.Wellnm = '';
				}

				//Well Classification
				/*if (configData['wllclass_item'].Visible){
				   item.Wllclas1 = '';
				}*/

				//Reservioyor
				/*if (configData['resrvpr'].Visible){
				   item.Resrvpr ='';
				}*/

				// Preliminary
				/*	if (configData['prelel'].Visible){
					   item.Prelel = "000000";
					}*/

				/*if (oModel.getData().Rqtype == "EW1"){
					item.Itmstat = "";
					
				}*/
			}

			return item;
		},

		itemDeletePress: function (evt) {

			var getPath = evt.getParameter('id').split('-').reverse()[0];
			var that = this;
			that.oEvent = evt.getSource();
			that.oIconCell = evt.getSource().getParent().getParent().getCells()[8];
			that.oBindingObject = evt.getSource().getParent().getParent().getBindingContext("itemsModel").getObject();
			MessageBox.information("This service will be deleted. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {

						//if (typeof that.oBindingObject['EText'] !== "undefined" && that.oBindingObject['EText'] !== ''){
						//that.oIconCell.setColor("#000");
						var oSelecObject = this.getView().getModel("itemsModel").getObject("/HeaderToItemNav")[getPath];
						if (oSelecObject.VendorAdd === "" || oSelecObject.VendorAdd === "X") {
							oSelecObject.DelInd = "V";
							that.notificationPress(that.oEvent, true);
						} else if (oSelecObject.VendorAdd === "X1") {
							this.getView().getModel("itemsModel").getData()['HeaderToItemNav'].splice(getPath, 1);
							//oSelecObject.DelInd = "V";
							//that.notificationPress(that.oEvent,true);
						}
						/*else {
						   oSelecObject.DelInd = "V";
						}*/
						//}else {
						//MessageBox.warning("Please enter your comments before deleting this item");
						//that.oIconCell.setColor("#E9967A");
						//that.notificationPress(that.oEvent,true);
						//}

						this.getView().getModel("itemsModel").refresh();
						this.changeMade = "X";
						this.changeWFActionButton();
					}

				}.bind(this)
			});

			this.getView().byId("ReferenceTable").getModel('itemsModel').refresh();

		},

		itemDeleteUndoPress: function (evt) {
			var getPath = evt.getParameter('id').split('-').reverse()[0];
			MessageBox.information("This marked for deletion will be removed. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						if (this.getView().getModel("itemsModel").getObject("/HeaderToItemNav")[getPath].DelInd === "V") {
							this.getView().getModel("itemsModel").getObject("/HeaderToItemNav")[getPath].DelInd = "";
						}
						this.getView().getModel("itemsModel").refresh();
						this.changeMade = "X";
						this.changeWFActionButton();
					}
				}.bind(this)
			});

		},

		ChooseVendorID: function (oEvt) {
			var me = this;
			var oFilter = [];
			var promise = new Promise(function (resolve, reject) {
				me.loadDomainValues(oFilter)
					.then(function (res) {
						if (!me._vendorSelectDialog) {
							me._vendorSelectDialog = new sap.ui.xmlfragment(".fragment.HeaderFragments.Vendor", me);
						}
						var model = new JSONModel(res);
						me._vendorSelectDialog.setModel(model, "vendorModel");
						me._vendorSelectDialog.open();
						///		console.log("fdsafsaf",res); 
					});
				return promise;
			});
		},

		vendorSelect: function (oEvt) {
			var oSelectedValue = oEvt.getParameter("selectedItem").getBindingContext('vendorModel').getObject().FIELDVAL;
			this.getView().byId("vendorInput").setValue(oSelectedValue);
		},

		vendorSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilterVId = new Filter("FIELDVAL", FilterOperator.Contains, sValue);
			//	var oFilterVName = new Filter("VENDNAME", FilterOperator.Contains, sValue);
			//	var oFilter = [];
			//	oFilter.push(oFilterVId);
			//	oFilter.push(oFilterVName);
			var oBinding = oEvent.getParameter("itemsBinding");
			oBinding.filter([oFilterVId]);
		},

		ChangeMade: function (oEvt) {
			this.changeMade = "X";
			this.changeWFActionButton();
		},

		handleCloseButton: function () {
			this._pPopover.close();
		},

		closeComments: function () {
			this.getView().byId("commentsId").close();
		},

		// SearchHelp Functions

		ChooseValueFromSearchHelp: function (oEvt) {

			this.loadDomainValue(oEvt);
		},

		// Retrive searchHelp Values from back-end
		loadDomainValue: function (evt) {
			var oSource = evt.getSource();
			this.filedValue = oSource.data().Field;
			this.oDialogTitle = oSource.data().Title;
			//var fieldname = "ZZ_RIG_CD";
			var oDataModel = this.getView().getModel("VendorService");
			this.busyDialog.open();
			var aFilters = [new Filter("Field", FilterOperator.EQ, this.filedValue)];

			if (this.filedValue === "WLLCLASS") {
				aFilters.push(new Filter("Rqtype", FilterOperator.EQ, this.itemDetails.Rqtype));
			}

			oDataModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				/*	urlParameters: {
						   "$skip":0,
						   "$Top":20
						},*/
				success: function (oData) {
					if (this.filedValue === "VENDOR" || this.filedValue === "WELL_NAME" || this.filedValue === "RIG_CODE" || this.filedValue ===
						"COPY_REF") {
						this.OpenTableSelectdialog(oData, this.filedValue);
					} else {
						if (!this.HeaderSearchHelp) {

							this.HeaderSearchHelp = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Header.SearchHelp", this);
						}

						oData = this.handleColumnData(oData, this.filedValue);
						var f4Model = new JSONModel(oData);
						this.HeaderSearchHelp.setModel(f4Model, "F4Models");
						this.HeaderSearchHelp.setTitle(this.oDialogTitle);
						//	this.getView().getModel("F4Models").setData(data);
						this.HeaderSearchHelp.open();

					}
					this.busyDialog.close();
					//		this.getView().getModel("F4Models").setProperty("/" + this.field, oData);
					/*	oData = oData.results;
						this.getView().getModel("F4Models").setProperty("/" + this.field, oData);
						this.busyDialog.close();*/
				}.bind(this),
				error: function (oResponse) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(oResponse);
				}.bind(this)
			});
		},

		OpenTableSelectdialog: function (oData, fieldValue) {

			if (!this.f4SearchHelp) {
				this.f4SearchHelp = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Header.f4Help", this);
			}

			oData = this.handleColumnData(oData, fieldValue);
			var f4Model = new JSONModel(oData);
			this.f4SearchHelp.setModel(f4Model, "F4Models");
			this.f4SearchHelp.setTitle(this.oDialogTitle);
			//	this.getView().getModel("F4Models").setData(data);
			this.f4SearchHelp.open();
		},

		onExeucte: function (evt) {
			var oDataModel = this.getView().getModel("VendorService");
			if (this.HeaderSearchHelp) {
				var oSearchHelpModel = this.HeaderSearchHelp.getModel("F4Models");
			} else if (this.f4SearchHelp) {
				var oSearchHelpModel = this.f4SearchHelp.getModel("F4Models");
			}

			var oTable = oSearchHelpModel.getData()['columns'];
			var aFilter = [new Filter("Field", FilterOperator.EQ, this.filedValue)];
			$.each(oTable, function (ind, obj) {
				if (obj['oValue']) {
					aFilter.push(new Filter(obj.field, FilterOperator.EQ, obj.oValue));
				}
			}.bind(this));
			//var aFilters = [new Filter("Field", FilterOperator.EQ, this.filedValue)];
			var max_hits = 50;
			if (oSearchHelpModel.getData()["dialog"]["maxHits"]) {
				max_hits = oSearchHelpModel.getData()["dialog"]["maxHits"];
			} else {
				max_hits = 50;;
			}
			oDataModel.read("/F4SearchHelpSet", {
				filters: aFilter,
				urlParameters: {
					MAX_HITS: max_hits,

					/* "$skip":0,
					 "$Top":20*/
				},
				success: function (oData) {
					oData = this.handleColumnData(oData, this.filedValue);
					oSearchHelpModel.setData(oData);
					oSearchHelpModel.refresh();
				}.bind(this),
				error: function () {}
			});
		},

		//Set the value of the input field from search help		
		onDrssSearchSelected: function (evt) {
			var selectedItem = evt.getSource().getBindingContext("F4Models").getObject();
			var DrssNo = selectedItem.col1;
			var Mjahr = selectedItem.col2;
			this.itemDetails.DrssNo = "0000000000";

			this.isConfigRequired = false;
			this.getRequestData(DrssNo, Mjahr, this.itemDetails.Rqtype);
			//this.byId("tbl_drss").removeSelections();
		},

		notificationPress: function (oEvent, iDelete) {

			if (iDelete) {
				var oButton = oEvent;
			} else {
				var oButton = oEvent.getSource();
			}
			var oView = controller.getView();
			if (!this.itemCommentsPop) {
				this.itemCommentsPop = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.Comments", this);
				oView.addDependent(this.itemCommentsPop);
			}
			if (iDelete) {
				var data = oButton.getParent().getParent().getBindingContext("itemsModel").getObject();
				var sPath = oButton.getParent().getParent().getBindingContext("itemsModel").getPath();
			} else {
				var data = oButton.getParent().getBindingContext("itemsModel").getObject();
				var sPath = oButton.getParent().getBindingContext("itemsModel").getPath();
			}

			oPreviousComments = data.EText;

			var oPageModel = this.getView().getModel("itemsModel").getData();
			if (oPageModel['HeaderToWfActionNav'].length > 0) {
				this.itemCommentsPop.setContentWidth("50%");
			} else {
				this.itemCommentsPop.setContentWidth("25%");
			}
			//data['EText'] = true;
			this.onOpenComment(data);
			controller.oSelCommentPath = sPath;
			//  data.VendorAdd = 'X';
			var model = new JSONModel(data);
			this.itemCommentsPop.setModel(model, "itemsComments");
			this.itemCommentsPop.open();
		},

		OnAddCmdtoField: function () {

			if (typeof controller.oSelCommentPath !== "undefined") {
				var oObject = this.getView().getModel("itemsModel").getProperty(controller.oSelCommentPath);
				//   var oField = oObject["ItemToCommNav"][0]['Text'];
				var oComment = Core.byId("ItemCommentsTxt").getValue();
				//oTxtAreaIpt = inputfield + 
				var userInfoModel = controller.getModel("UserInfoModel").getData();
				var itemsNav = this.getView().getModel("itemsModel").getData()['HeaderToItemNav'];
				$.each(itemsNav, function (ind, obj) {
					var oField = obj['ItemToCommNav'][0]['Text'];
					if (typeof obj['EText'] !== "undefined" && obj['EText'] !== "") {
						if (oField === "") {
							oField = obj['EText'] + "/b1" + new Date().toLocaleString() + "/b1" + userInfoModel['VenUserId'];
						} else {
							oField = oField + " /n1" + obj['EText'] + "/b1" + new Date().toLocaleString() + "/b1" + userInfoModel['VenUserId'];
						}
						obj['ItemToCommNav'][0]['Text'] = oField;

						delete obj['EText'];
						delete obj['SplArray'];
					}
				}.bind(this));
			}
			// Remove these two fields before submit
			//	delete oObject['EText'];
			//delete oObject['SplArray'];
			//oObject["ItemToCommNav"][0]['Text'] = oField;

			this.getView().getModel("itemsModel").refresh();

		},

		onOpenComment: function (data) {

			//var oComment = Core.byId("ItemCommentsTxt").getValue();
			var oSelObject = data["ItemToCommNav"][0];
			var oField = oSelObject['Text'];
			data['SplArray'] = [];
			var oSplittedArray = [];
			if (oField.match(/n1/g) !== null) {
				var oArr = oField.split('/n1');
				for (var obj in oArr) {
					var oInnerArr = oArr[obj].split('/b');
					var nObj = {
						Text: oInnerArr[0],
						CreatedDateTime: oInnerArr[1],
						CreatedBy: oInnerArr[2]
					}
					oSplittedArray.push(nObj);
				}
				data['SplArray'] = oSplittedArray;
			} else if (oField.match(/b1/g) !== null) {
				var oInnerArr = oField.split('/b1');
				var nObj = {
					Text: oInnerArr[0],
					CreatedDateTime: oInnerArr[1],
					CreatedBy: oInnerArr[2]
				}
				oSplittedArray.push(nObj);
				data['SplArray'] = oSplittedArray;
			}
			this.getView().getModel().refresh();
		},

		/*		
				removeEmptyText :function(data, sPath){
					var oItemModel =  this.getView().getModel('itemsModel');
					if(data['ItemToCommNav'].length > 0){
						for(var i= data['ItemToCommNav'].length -1 ; i>=0;i--){
							if(data['ItemToCommNav'][i]['Text'] === ""){
								oItemModel.getProperty(sPath)['ItemToCommNav'].splice(i, 1);
							}
						}
					}
					this.getView().getModel("itemsModel").refresh();
					//return data;
				},
				*/
		/*onAddCommentPress:function(evt){
			
	       // sap.ui.getCore().byId("idTimeline").setVisible(false);
			sap.ui.getCore().byId("ItemCommentsTxt").setVisible(true);
			//this.getView().byId("ItemCommentsTxt").setVisible(true);
			var aCommentModel = this.itemCommentsPop.getModel("itemsComments");
			var aCommentsList = aCommentModel.getData()['ItemToCommNav'];
			var getYear = new Date().getFullYear();
			var obj ={ Text:sap.ui.getCore().byId("ItemCommentsTxt").getValue(),
					   Docno: aCommentModel.getData()['Docno'],
					   Mjahr: getYear.toString(),
					   Ntdid: "ITM",
					   Tdid: "ZTXT",
					   Tdobject: "ZPDRSS",
					   Txttype: "I",
					   Zeile: aCommentModel.getData()['Zeile'] };
			aCommentsList.push(obj);
			aCommentModel.refresh();
			var ItemCommentsTxt = Core.byId("ItemCommentsTxt");
			var oLen = aCommentsList.length-1;
			var sPath = "/ItemToCommNav/"+ oLen.toString();
			ItemCommentsTxt.bindElement({ path: sPath, model: "itemsComments" });
			sap.ui.getCore().byId("ItemCommentsTxt").setValue("");
			//evt.getSource().setVisible(true);
			//ItemCommentsTxt.setVisible(false);
		},*/

		// Adding the comments color
		ItemCommentColor: function () {

			var oRefTable = this.getView().byId("ReferenceTable");

			if (!oRefTable) {
				return;
			}

			var oItemsTable = this.getView().byId("ReferenceTable").getItems();
			if (oItemsTable.length > 0) {
				//var aTableItems = oItemsTable[0].getCells()[8].setColor('#FF0000');
				for (var obj in oItemsTable) {
					var itemContext = oItemsTable[obj].getBindingContext("itemsModel").getObject();
					if (itemContext['ItemToCommNav'].length > 0) {
						var oChkValue = itemContext['ItemToCommNav'][0].Text;
						var aCells = oItemsTable[obj].getCells();
						var iconInd = 0;
						for (var ind in aCells) {
							if (aCells[ind].getTooltip() === "Add Line Item Comments") {
								var oIconName = aCells[ind].getSrc();
								if (oIconName === "sap-icon://notification-2") {
									iconInd = ind;
									break;
								}
							}
						}
						var oCell = oItemsTable[obj].getCells()[iconInd];
						oCell.setColor('#000000');
						if (oChkValue !== "" || (typeof itemContext['EText'] !== "undefined" && itemContext['EText'] !== "")) {
							oCell.setColor('#59ed3f');
						}
					}
				}
			}
		},

		onLineItemChange: function (evt) {

			var oSource = evt.getSource().getValue();
		},

		/*onClosePopUp :function(evt){
			this.ItemCommentColor();
			var oSelTblObj = this.getView().getModel("itemsModel").getProperty(controller.oSelCommentPath);
			if(oSelTblObj.VendorAdd === ""){
			   oSelTblObj.DelInd = "V";
			}
			evt.getSource().getParent().close();
		},*/

		onSavePopUp: function (evt) {
			this.ItemCommentColor();

			var oSelTblObj = this.getView().getModel("itemsModel").getProperty(controller.oSelCommentPath);
			/*if(oSelTblObj.VendorAdd === ""){
			   oSelTblObj.DelInd = "V";
			}*/

			evt.getSource().getParent().close();
		},
		onClosePopUp: function (evt) {
			//Do not save the additional comments, restore it to previous comments. 
			evt.getSource().getParent().getModel("itemsComments").setProperty("/EText", oPreviousComments);
			evt.getSource().getParent().close();

		},

		//Fired when SegmentedButton (item comments) is clicked
		onItemCommentsPress: function (oEvent) {
			var ItemCommentsTxt = sap.ui.getCore().byId("ItemCommentsTxt");
			var sPath = oEvent.getParameter("item").getBindingContext("itemsComments").getPath();
			ItemCommentsTxt.bindElement({
				path: sPath,
				model: "itemsComments"
			});
		},

		//Item Attachment
		attachPress: function (oEvent) {
			var oButton = oEvent.getSource();
			if (!this._pPopover) {
				this._pPopover = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.Attachments", this);
				this.getView().addDependent(this._pPopover)
			}
			this.selectedContext = oButton.getParent()._getPropertiesToPropagate()['oBindingContexts']['itemsModel'].getObject();
			controller.selectedContext = this.selectedContext;
			var oItemFileUpload = sap.ui.getCore().byId("UploadCollection");
			var oitemsModel = this.getView().getModel("itemsModel")['Rqstat'];
			if (oitemsModel === "INIT") {
				oItemFileUpload.setUploadEnabled(true);
			} else {
				oItemFileUpload.setUploadEnabled(false);
			}
			this._pPopover.openBy(oButton);
			this.oFilterItemsAttach();
		},

		oFilterItemsAttach: function () {
			//this.byId("uploadCollectionJobLog").data({ItemValue:controller.FormCode}) ;
			var oBinding = Core.byId("UploadCollection").getBinding("items");
			if (oBinding) {
				//oBinding.filter(null);
				oBinding.filter([
					new sap.ui.model.Filter("Category", "EQ", "02"),
					new sap.ui.model.Filter("Zeile", "EQ", controller.selectedContext['Zeile'])
				]);
			}
			oBinding.refresh();
		},

		/*	
		SplitAttachmentItems:function(evt){
			var oSource =  evt.getSource();
			var oContexts = oSource.getParent()._getPropertiesToPropagate()['oBindingContexts'];
			 if (oContexts){
				var oSelectedContextModel = oContexts['itemsModel'].getObject();
  				var oData = [];
				 for (var obj in  this.Attachments){
					  if (oSelectedContextModel.Zeile === this.Attachments[obj].Zeile){
						oData.push(this.Attachments[obj]);
					}
				}
			}
			 return oData;
		},*/

		onCheck: function () {
			var errorList = this.validationControlsByFieldGroupId();
			this.instantiateErrorMessageModel(errorList);
			this.createMessagePopoverModel();

			/*if(errorList.length > 0){
				this.instantiateErrorMessageModel(errorList);
					this.createMessagePopoverModel();
			}
			else{
				this.createMessagePopoverModel();
			}*/
		},

		onServiceMasterFilter: function (evt) {
			var oTable = Core.byId("serviceSelectId");
			var oBinding = oTable.getBinding("items");
			oTable.expandToLevel(100);
			var aFilters = [];
			var sQuery = evt.getSource().getValue();

			/*const aWords = sQuery.split(" ");
			var sWord = "";*/
			/*for(var x = 0 ; x < aWords.length ; x++){
				sWord = aWords[x];
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord.toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord.toUpperCase()));
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord[0].toUpperCase() + sWord.substr(1).toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord));
			}*/
			aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sQuery, false));
			var oFilter = [new sap.ui.model.Filter(aFilters, false)];
			oBinding.filter(oFilter);
		},

		setViewMode: function (flag) {
			var configModel = this.getView().getModel("configModel");
			var tempOb = {
				rigno: ["/Editable"],
				prrty: ["/Editable"],
				rqddt: ["/Editable"],
				prrtyreason: ["/Editable"],
				rqdtm: ["/Editable"],
				estedt: ["/Editable"],
				wellnm: ["/Editable"],
				wcposid: ["/Editable"],
				wlltype: ["/Editable"],
				lifnr: ["/Editable"],
				shoptyp: ["/Editable"],
				phone: ["/Editable"],
				aufnr: ["/Editable"],
				ovrcc: ["/Editable"],
				estimate: ["/Editable"],
				estmtyp: ["/Editable"],
				notification: ["/Editable"],
				craftno1: ["/Editable"],
				craftno2: ["/Editable"],
				certifier: ["/Editable"],
				ident: ["/Editable"],
				deliervia: ["/Editable"],
				wllclass: ["/Editable"],
				actedt: ["/Editable"],
				area: ["/Editable"],
				distancedh: ["/Editable"],
				taxireason: ["/Editable"],
				vehtype: ["/Editable"],
				taxiroute: ["/Editable"],
				taxitrip: ["/Editable"],
				driver: ["/Editable"],
				drivernumber: ["/Editable"],
				doornumber: ["/Editable"],
				platenumber: ["/Editable"],
				comments: ["/Editable"],
				badgeno: ["/Editable"],
				maktxo: ["/Editable"],
				ServLtext: ["/Editable"],
				trdrvmobile: ["/Editable"],
				pickuplocation: ["/Editable"],
				dropofflocation: ["/Editable"],
				contract: ["/Editable"],
				flightdetails: ["/Editable"],
				hdtxt: ["/Editable"],
				addpassengerbtn: ["/Visible"],
				deletepassengerbtn: ["/Visible"],
				additembtn_ref: ["/Visible"],
				deleteitembtn_ref: ["/Visible"],
				referencetab: ['/Editable'],
				commentstab: ['/Editable']
			};

			for (var key in tempOb) {
				var prop = "/" + key + tempOb[key][0];
				configModel.setProperty(prop, flag);
			}
		},

		//Validate form fields
		validationControlsByFieldGroupId: function () {
			var oControls = this.getView().getControlsByFieldGroupId("Mandatory");
			var errorList = [];

			var check = true;
			for (var i = 0; i < oControls.length; i++) {
				var control = oControls[i];
				//Validate dropdown
				if (control.constructor === sap.m.Select) {
					if (control.getSelectedKey().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						control.setValueState("None");
						check = check && true;
					}
				}
				//Validate Input field
				if (control.constructor === sap.m.Input) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						check = check && true;
						control.setValueState("None");
					}
				}
				if (control.constructor === sap.m.TextArea) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {

						check = check && true;
						control.setValueState("None");
					}
				}
				//Validate date picker control
				if (control.constructor === sap.m.DatePicker) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						this.datePickerValidation(control);
					}
					/*else{
						check = check && true;
						control.setValueState("None");
					}*/
				}
				//Validate time picker control
				if (control.constructor === sap.m.TimePicker) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						check = check && true;
						control.setValueState("None");
					}
				}
			}
			return errorList;
		},

		// Date picker validation
		datePickerValidation: function (datePicker) {
			var dateValue = datePicker.get
		},

		onBeforeUploadStarts: function (oEvent) {
			//var oUploadCollection = oEvent.getSource();
			var oDataModel = this.getView().getModel("VendorService");

			this.AttachLevel = oEvent.getSource().data().Field;
			// this.reqItems['VEND_NAME'] = this.reqItems['VEND_NAME'].slice(0,29);
			/*	var oFileTypeSpl =  oEvent.getParameter('fileName').split('.')[1];
				oEvent.getParameter('fileName') = oEvent.getParameter('fileName').slice(0,29)+"."+oFileTypeSpl; */

			if (this.AttachLevel === "ItemAttach") {
				this.Catog = "02";
				this.itemValue = "0010";

				var oItem_Header = new sap.m.UploadCollectionParameter({
					name: "item",
					value: this.itemValue
				});

			} else if (this.AttachLevel === "JobLogAttach") {
				this.Catog = "03"
				this.itemValue = this.byId("uploadCollectionJobLog").data().ItemValue;
				var oItem_Header = new sap.m.UploadCollectionParameter({
					name: "Form",
					value: this.itemValue
				});
			} else {
				this.Catog = "01"
				this.itemValue = "0000";
				var oItem_Header = new sap.m.UploadCollectionParameter({
					name: "item",
					value: this.itemValue
				});
			}

			oDataModel.refreshSecurityToken();
			var sSecurityToken = oDataModel.getSecurityToken();

			var oSlugHeader = new sap.m.UploadCollectionParameter({
				name: "SLUG",
				value: oEvent.getParameter("fileName")
			});

			var oSecurityToken = new sap.m.UploadCollectionParameter({
				name: "X-CSRF-Token",
				value: sSecurityToken
			});

			var oReqid_Header = new sap.m.UploadCollectionParameter({
				name: "REQID",
				value: this.getDocno()
			});

			var oCate_Header = new sap.m.UploadCollectionParameter({
				name: "CATE",
				value: this.Catog
			});

			var oYear_Header = new sap.m.UploadCollectionParameter({
				name: "YEAR",
				value: this.getYear()
			});

			oEvent.getParameters().addHeaderParameter(oSlugHeader);
			oEvent.getParameters().addHeaderParameter(oSecurityToken);
			oEvent.getParameters().addHeaderParameter(oReqid_Header);
			oEvent.getParameters().addHeaderParameter(oCate_Header);
			oEvent.getParameters().addHeaderParameter(oYear_Header);
			oEvent.getParameters().addHeaderParameter(oItem_Header);

			//	oUploadCollection.setBusy(true);
		},

		getReqType: function () {
			return this.itemDetails.Rqtype;
		},

		//returen the document no which is maintained in the model
		getDocno: function () {
			return this.itemDetails.DrssNo;
		},

		//returen year
		getYear: function () {
			return this.itemDetails.Mjahr;
		},

		//Event is fired when the value of the file path has been changed.
		onUploadChange: function (evt) {
			var oFileUploader = evt.getSource();
			var oDataModel = this.getView().getModel("VendorService");
			var sServiceUrl = oDataModel.sServiceUrl;
			var sUrl = sServiceUrl + "/FileSet('" + oFileUploader.getValue() + "')";
			//	    	var sUrl = sServiceUrl + "/FileSet/";
			this.busyDialog.open();
			oDataModel.refreshSecurityToken();
			var sSecurityToken = oDataModel.getSecurityToken();
			oFileUploader.removeAllHeaderParameters();
			oFileUploader.setUploadUrl(sUrl);
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: oFileUploader.getValue()
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "X-CSRF-Token",
				value: sSecurityToken
			}));

			/*oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "Content-Type",
					value: evt.getParameter("files")[0].type 
	    	  }));*/

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "CATE",
				value: this.Catog
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "REQID",
				value: this.getDocno().toString()
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "YEAR",
				value: this.getYear().toString()
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "item",
				value: oFileUploader.data().item.toString()
			}));
			oFileUploader.upload();
			oFileUploader.clear();
		},

		//Event is fired as soon as the upload request is completed (either successful or unsuccessful)
		onUploadComplete: function (evt) {

			// this._OCReqData(this.itemDetails.DrssNo,this.itemDetails.Mjahr,this.itemDetails.Rqtype,this.itemDetails.SrvtypeCode);
			var oModel = this.getView().getModel("VendorService");
			var docNo = this.getDocno();
			var year = this.getYear();
			this.oSets = "HeaderToAttNav," + "HeaderToItemNav";
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			//   var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "')";
			var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + this.itemDetails.Rqtype + "')";
			oModel.read(params, {
				urlParameters: {
					"$expand": this.oSets
				},
				success: function (oData) {
					oData.HeaderToAttNav = oData.HeaderToAttNav.results;
					var oitemsModel = this.getView().getModel("itemsModel");
					oitemsModel.setData(oData);
					//Data.HeaderToAttNav = oData.HeaderToAttNav.results;
					//oData.HeaderToAttNav = this.prepareAttachments(oData.HeaderToAttNav.results);

					//if(this.AttachLevel === "ItemAttach"){
					// this.getView().getModel("itemsAttachment").refresh();

					// this.attachPress(evt);
					//}
					//	this.prepareData(oData);
					//    this.SelectPriorities();
					//    this.SelectHoleSize();
					//    this.SelectRadius();
					// busyDialog.close();

					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
		},

		// UOM Search Dialog
		UOMSearch: function (evt) {
			var oBinding = evt.getSource().getBinding("items");
			var oSearchValue = evt.getParameter("value");
			var lowerCase = oSearchValue.toLowerCase();
			var upperCase = oSearchValue.toUpperCase();
			var asIS = oSearchValue;
			var aFilters = [
				new sap.ui.model.Filter("Value1", sap.ui.model.FilterOperator.Contains, lowerCase),
				new sap.ui.model.Filter("Value1", sap.ui.model.FilterOperator.Contains, upperCase),
				new sap.ui.model.Filter("Value1", sap.ui.model.FilterOperator.Contains, asIS),
				new sap.ui.model.Filter("Descr1", sap.ui.model.FilterOperator.Contains, lowerCase),
				new sap.ui.model.Filter("Descr1", sap.ui.model.FilterOperator.Contains, upperCase),
				new sap.ui.model.Filter("Descr1", sap.ui.model.FilterOperator.Contains, asIS)
			];
			var oFilter = [new sap.ui.model.Filter(aFilters, false)];
			oBinding.filter(oFilter);
		},

		onFilePressed: function (evt) {
			var source = evt.getSource();
			var sPath = source.getParent().getBindingContextPath();
			var oModel = source.getParent().getParent().getBinding("items").getModel();

			var dataObject = oModel.getProperty(sPath);
			var sServiceUrl = this.getView().getModel("VendorService").sServiceUrl;
			var Brelguid = dataObject.Brelguid.replaceAll("-", "");
			var url = sServiceUrl + "/FileSet('" + Brelguid + "')/$value";
			sap.m.URLHelper.redirect(url, true);
		},

		oCurrentYear: function () {
			var year = new Date();
			return year.getFullYear();
		},

		onFileDeleted: function (oEvent) {
			var docId = oEvent.getParameter("documentId");
			var oModel = this.getView().getModel("VendorService");
			oModel.read("/DeleteAttachmentSet('" + docId + "')", {

				success: function (oData) {
					// this.onUploadComplete();
					this.onUploadCompleteJob();

					this.getView().setBusy(false);
				}.bind(this),
				error: function (error) {
					this.getView().setBusy(false);
					//var msgs = this.getErrorMessages(error);
					this.onMessageHandle(error)
						//this.instantiateErrorMessageModel(msgs);
						//this.createMessagePopoverModel();
				}.bind(this)
			});

			/*      var oItem = oEvent.getParameter('item');
			     if (oItem){
				      if (oItem.getBindingContext("itemsAttachment")){
					     this.AttachLevel = "ItemAttach";
				       }else{
					     this.AttachLevel  = "HeaderAttach";
			         }
			     }
				var oModel = this.getView().getModel("VendorService");
				var docId = oEvent.getParameter("documentId");
				var year = this.oCurrentYear();;
				oModel.remove("/FileSet(Brelguid='" + docId + "')", {
					success: function (oData) {
						this.onUploadComplete();
					}.bind(this),
					error: function (error) {
						this.onMessageHandle(error)
					}.bind(this)
				});*/

		},

		/*    onFileDeleted: function (oEvent) {
			      var oItem = oEvent.getParameter('item');
			     if (oItem){
				      if (oItem.getBindingContext("itemsAttachment")){
					     this.AttachLevel = "ItemAttach";
				       }else{
					     this.AttachLevel  = "HeaderAttach";
			         }
			     }
				var oModel = this.getView().getModel("VendorService");
				var docId = oEvent.getParameter("documentId");
				var year = this.oCurrentYear();;
				oModel.remove("/FileSet(Brelguid='" + docId + "')", {
					success: function (oData) {
						this.onUploadComplete();
					}.bind(this),
					error: function (error) {
						this.onMessageHandle(error)
					}.bind(this)
				});
			},*/

		onMessageHandle: function (error) {
			if (JSON.parse(error.responseText)['error']['innererror']['errordetails'].length > 0) {
				MessageBox.error(JSON.parse(error.responseText)['error']['innererror']['errordetails'][0]['message']);
			}
		},

		//Delete a passenger
		onDeleteLineItem: function (evt) {
			this.lineItemDel = evt.getSource();
			var message = evt.getSource().data().LineItem;
			MessageBox.warning("Are you sure you want to delete the " + message + "?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						var lineItem = this.lineItemDel;

						var oTable = lineItem.getParent().getParent();
						var property = oTable.getBinding("items").getPath();
						var itemsList = this.getView().getModel("taxiModel").getProperty(property);
						var item = lineItem.getParent();
						var splittedIndex = item.getBindingContextPath().split("/");
						var index = parseInt(splittedIndex[splittedIndex.length - 1]);
						itemsList.splice(index, 1);
						this.getView().getModel("taxiModel").refresh(true);
						delete this.PassenerDel;
					}
				}.bind(this)
			});
		},

		onPrintPress: function () {
			var oDataModel = this.getView().getModel("VendorService");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: this.getDocno(),
				Year: this.getYear(),
				FormType: 'AC',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		copyFromRef: function () {

			var that = this;
			if (!this._pPopoverCopyFrom) {
				that._pPopoverCopyFrom = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.CopyFromRef", that);
			}

			that._pPopoverCopyFrom.open();

		},

		populateFields: function (sId, oContext) {

			var oField = this._Dialog.getModel("field_list").getObject(oContext + "/");

			//console.log(oField.fieldType);
			if (oField.fieldType === "Input") {

				var oInput = new sap.m.Input({
					value: "",
					showValueHelp: oField.shAvail,
					valueHelpRequest: this.getF4Value
				});
				oInput.setModel(this._Dialog.getModel("field_list"));
				oInput.setModel(this.model, "oData");
				oInput.bindValue(oContext + "/value");
				oInput.addCustomData(new sap.ui.core.CustomData({
					key: "SHLPNAME",
					value: oField.shName
				}));
				oInput.addCustomData(new sap.ui.core.CustomData({
					key: "SHLPTYPE",
					value: oField.shType
				}));
				oInput.addCustomData(new sap.ui.core.CustomData({
					key: "Fieldname",
					value: oField.shField
				}));

				oInput.attachBrowserEvent("keypress", function (e) {

					if (e.which === 13) {
						//console.log("Enter Pressed");
						this.oViewModel.setProperty("/fieldsExpanded", false);
						this.onExeucte();
					}
				}.bind(this));

				return new sap.ui.layout.form.FormElement({
					label: oField.fieldLabel,
					fields: [oInput]
				});

			} else if (oField.fieldType === "Date") {
				var oInput = new sap.m.DatePicker({
					value: "",
					valueFormat: "yyyyMMdd"
				});
				oInput.setModel(this._Dialog.getModel("field_list"));
				oInput.bindValue(oContext + "/value");

				return new sap.ui.layout.form.FormElement({
					label: oField.fieldLabel,
					fields: [oInput]
				});

			} else if (oField.fieldType === "Time") {
				var oInput = new sap.m.TimePicker({
					value: "",
					valueFormat: "HHmmss"
				});
				oInput.setModel(this._Dialog.getModel("field_list"));
				oInput.bindValue(oContext + "/value");

				return new sap.ui.layout.form.FormElement({
					label: oField.fieldLabel,
					fields: [oInput]
				});
			}
		},

		onPrintPress: function () {
			var oDataModel = this.getView().getModel("VendorService");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: this.getDocno(),
				Year: this.getYear(),
				FormType: 'RQ',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		onPrintACPress: function () {
			var oDataModel = this.getView().getModel("VendorService");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: this.getDocno(),
				Year: this.getYear(),
				FormType: 'AC',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		//Show the dialog for DRSS
		onCopyOldRef: function () {
			if (!this.DRSSDialog) {
				this.DRSSDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.f4.DRSSSearchDialog", this);
				//	this.getView().addDependent(this.DRSSDialog);	
			}
			var data = {
				drss: {
					Field: 'COPY_REF',
					Maxhit: '50',
					Descr1: '',
					Descr2: '',
					Descr3: '',
					Descr4: '',
					Referance: '',
					Referance1: ''
				}
			};
			var model = new JSONModel(data);
			this.DRSSDialog.setModel(model, "SearchModel");
			this.DRSSDialog.open();
		},

		//  Copy from Drss

		onDRSSExeucte: function (evt) {
			this.getView().getModel("SearchModel").setProperty("/drss/Referance1", this.itemDetails.Rqtype);
			var searchParams = this.getView().getModel("SearchModel").getProperty("/drss");
			this.field = searchParams.Field
			this.loadDomainF4Values(searchParams);
		},

		onWFGraphOC: function () {
			//	this.getView().getModel("WFGraphModel")
			var model = new JSONModel();
			this.getView().setModel(model, "WFGraphModel");
			var oModel = this.getView().getModel("itemsModel").getProperty("/HeaderToWfLogNav");
			this.onWFGraph(oModel);
		},

		onCloseWF: function () {
			this.WFGraphDialog.close();
			this.WFGraphDialog.destroy();
			delete this.WFGraphDialog;
		},

		changeWFActionButton: function () {

			var wfButtons = this.getView().getModel("itemsModel").getProperty("/HeaderToWfActionNav");
			if (wfButtons.length > 0) {
				for (var i = wfButtons.length - 1; i >= 0; i--) {
					if (wfButtons[i].Actlabel === "Accept") {
						this.getView().getModel("itemsModel").getData()['HeaderToWfActionNav'].splice(i, 1);
					}

					if (wfButtons[i]) {
						if (wfButtons[i].Actlabel === "Reject") {
							this.getView().getModel("itemsModel").getData()['HeaderToWfActionNav'].splice(i, 1);
						}
					}
					if (wfButtons[i]) {
						if (wfButtons[i].Actlabel === "Return") {
							this.getView().getModel("itemsModel").getData()['HeaderToWfActionNav'].splice(i, 1);
						}
					}

				}
			}
			this.getView().getModel("itemsModel").refresh();
		},
		onRejectSelection: function (evt) {

			//var oSelectedItem = evt.getParameter("selectedItem").getBindingContext("mRejectedReason").getObject();
			var oSelectedItem = evt.getParameter('value');
			if (oSelectedItem === 'Other') {
				this.getView().byId("commentInput").setVisible(true);
				this.getView().byId("commentLabel").setVisible(true);
				this.dRejectedReason.getModel('mRejectedReason').refresh();
				return;
			} else {
				this.getView().byId("commentInput").setVisible(false);
				this.getView().byId("commentLabel").setVisible(false);
			}
			this.getView().byId("selectinput").setValueState("None");
			this.sSelectedReason = false;
		},

		onSelectLiveChange: function (evt) {
			var oSelectedKey = evt.getSource().getSelectedKey();
			if (oSelectedKey === '') {
				evt.getSource().setValueState("Error");
			} else {
				evt.getSource().setValueState("None");
			}
		},

		onSubReason: function () {

			var oControl = this.getView().byId("selectinput");
			var oCommentField = this.getView().byId("commentInput");
			if (oControl.getSelectedKey() == "" || oControl.getSelectedKey() === "Other") {
				if (oControl.getSelectedKey() == "Other") {

					if (oCommentField.getValue() === "") {
						sap.m.MessageBox.error("Please Enter reason!");
						oCommentField.setValueState("Error");
						return;
					} else {
						oCommentField.setValueState("None");
					}
				}
				if (oControl.getSelectedKey() == "") {
					sap.m.MessageBox.error("Please select a Reason");
					oControl.setValueState('Error');
					return;
				} else {
					oControl.setValueState('None');
				}

			} else {

				oCommentField.setValueState('None');
				oControl.setValueState('None');
			}

			if (oControl.getSelectedKey() == "Other") {
				this.oRejReasonText = this.getView().byId("commentInput").getValue();
			} else {
				this.oRejReasonText = oControl.getSelectedKey();
			}

			this.oSeletedReason = "";
			this.sSelectedReason = false;
			this.oSeletedReason = this.getView().byId("commentInput").getValue();
			this.onWFAction();
			this.dRejectedReason.close();

		},

		// On vendor refrence live chaneg
		onVendorRefNum: function (evt) {
			var getSource = evt.getParameter('value');
			this.changeMade = "";
			if (getSource !== "") {
				this.changeMade = "X";
				//this.changeWFActionButton();
			} else {
				//this.changeWFActionButton();
			}

		},

		// On rejection Reason
		_onRejectionReason: function (btnText) {
			var oPageModel = this.getView().getModel("itemsModel").getData();
			var oModel = this.getView().getModel("oDataModel");
			if (btnText === "Reject") {
				var oReasonType = "REJ";
			} else {
				var oReasonType = "RET";
			}
			this.busyDialog.open();
			var aFilters = [];
			//  if(!this.dRejectedReason){
			aFilters.push(new Filter("Field", FilterOperator.EQ, "REJECT_RES"));
			aFilters.push(new Filter("Referance", FilterOperator.EQ, oReasonType));
			aFilters.push(new Filter("Referance1", FilterOperator.EQ, oPageModel['Srvtyp']));
			aFilters.push(new Filter("Referance2", FilterOperator.EQ, oPageModel['Location']));
			oModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					if (!this.dRejectedReason) {
						this.dRejectedReason = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.f4.RejectionReasonDialog",
							this);
						this.getView().addDependent(this.dRejectedReason);
					}

					oData['title'] = btnText;
					oData.results.push({
						Descr1: "Other"
					})
					var model = new JSONModel(oData);
					this.dRejectedReason.setModel(model, "mRejectedReason");
					this.dRejectedReason.getModel('mRejectedReason').setSizeLimit(oData.results.length);
					this.dRejectedReason.open();
					this.getView().byId("commentInput").setVisible(false);
					this.getView().byId("commentLabel").setVisible(false);
					this.getView().byId("commentInput").setValue("");
					this.getView().byId("selectinput").setSelectedKey('');
					this.getView().byId("selectinput").setValueState('None');
					this.getView().byId("selectinput").setValueState('None');
					this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.busyDialog.open();
				}.bind(this)
			});
		},
		onClose: function (evt) {
			this.sSelectedReason = true;
			evt.getSource().getParent().close();
		},

		_AddedByVendorsItems: function (items) {
			$.each(items, function (ind, obj) {
				if (obj['VendorAdd'] === "X1") {
					obj['VendorAdd'] = "X";
				}
			});
			return items;
		},

		// Vendor well select
		onWellSearchValueHelp: function (evt) {
			var oCustomValue = '';
			var oSelRowModel = evt.getSource().getParent().getBindingContext("itemsModel");
			if (oSelRowModel) {
				controller.getWellSelTblRow = oSelRowModel.getObject();
			}
			this.WlChNM = this.field;
			controller.SelWelPath = evt.getSource();
			if (!this.WellSearchHelpDialog) {
				this.WellSearchHelpDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.WS.WellSearchHelpDialog", this);
				this.getView().addDependent(this.WellSearchHelpDialog);
				var data = [];
				var oModel = new sap.ui.model.json.JSONModel(data);
				this.WellSearchHelpDialog.setModel(oModel, "WellData");
			}

			this.WellSearchHelpDialog.data({
				control: evt.getSource()
			});
			this.WellSearchHelpDialog.open();
		},

		onWellExeucte: function () {
			this.loadDomainF4Values();
		},

		//Load Domain Values
		loadDomainF4Values: function () {
			var aFilters = [];
			aFilters.push(new Filter("Field", FilterOperator.EQ, 'WELL_NAME'));
			aFilters.push(new Filter("Maxhit", FilterOperator.EQ, '200'));
			aFilters.push(new Filter("Descr4", FilterOperator.EQ, this.Rqtype));
			var oModel = this.getOwnerComponent().getModel("VendorService");
			this.getView().setBusy(true);
			if (this.WellSearchHelpDialog) {
				this.WellSearchHelpDialog.setBusy(true);
			}
			oModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					oData = oData.results;
					this.getView().getModel("F4Models").setSizeLimit(oData.length);
					this.WellSearchHelpDialog.getModel("WellData").setData(oData);
					this.WellSearchHelpDialog.getModel("WellData").refresh(true);
					this.getView().setBusy(false);
					if (this.WellSearchHelpDialog) {
						this.WellSearchHelpDialog.setBusy(false);
					}
				}.bind(this),
				error: function (oResponse) {
					this.getView().setBusy(false);
					if (this.WellSearchHelpDialog) {
						this.WellSearchHelpDialog.setBusy(false);
					}
					var msgs = this.getErrorMessages(oResponse);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		onWellSearchSelected: function (evt) {
			var selectedItem = evt.getParameter("listItem").getBindingContext("WellData").getObject();
			// Inactive Rig Validation
			if (selectedItem.Inactive === "X") {
				sap.m.MessageBox.error("This Rig is not enabled for DILIP system. Please contact DRSD communication for support.");
				return;
			}
			var oTableBindingContext = controller.SelWelPath.getParent().getBindingContext("itemsModel");
			controller.configModel = this.getView().getModel("configModel").getData();
			/*if (controller.configModel['const_sel'].Visible && oTableBindingContext){
			/*	var checkValid = this._CheckLocationDupl(selectedItem);
				if(checkValid){
					return;
				}
			}*/
			var mWSModel = this.getView().getModel("itemsModel");
			if (controller.futurWell === "WELL_FUTUR") {
				oTableBindingContext.getObject()["Wellnm"] = selectedItem.Descr3;
				//oTableBindingContext.getObject()["WllType"] = selectedItem.Value6;
				oTableBindingContext.getObject()["CoordLat"] = selectedItem.Descr4;
				oTableBindingContext.getObject()["CoordLon"] = selectedItem.Descr5;
				oTableBindingContext.getObject()["CoordZn"] = selectedItem.Descr6;

			} else if (oTableBindingContext) {
				oTableBindingContext.getObject()["Wellnm"] = selectedItem.Descr3;
				//oTableBindingContext.getObject()["WllType"] = selectedItem.Value6;
				oTableBindingContext.getObject()["CoordLat"] = selectedItem.SvXutmCord;
				oTableBindingContext.getObject()["CoordLon"] = selectedItem.SvYutmCord;
				oTableBindingContext.getObject()["CoordZn"] = selectedItem.SvUtmZn;
				oTableBindingContext.getObject()["Wcposid"] = selectedItem.Descr1;
			} else {
				mWSModel.setProperty("/Rigno", selectedItem.Value1);
			}
			mWSModel.refresh(true);
			evt.getSource().removeSelections();
			this.WellSearchHelpDialog.close();
		},

		_CheckLocationDupl: function (oSelItem) {
			var oTableItemsModel = this.getView().byId("ReferenceTable").getModel("itemsModel");
			var oSelectedTableObject = controller.SelWelPath.getParent().getBindingContext("itemsModel").getObject();
			if (oTableItemsModel) {
				var oItemData = oTableItemsModel.getData().HeaderToItemNav;
				var oRtrnParams = false;
				for (var x in oItemData) {
					if (oItemData[x].Wellnm === oSelItem.Descr3 && oItemData[x].LocCons === oSelectedTableObject.LocCons) {
						sap.m.MessageBox.error("Well Name is already selected for the same type. Please select another Well!");
						oRtrnParams = true;
						break;

					}
				}
			}

			return oRtrnParams;

		},

		onWFAction: function (oEvent) {
			//var oActionItems = oEvent.getSource().getBindingContext("itemsModel").getProperty(oEvent.getSource().getBindingContext("itemsModel").getPath());
			var oPgData = this.getView().getModel("itemsModel").getData();
			var ReqItems = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var ReqItems = this._AddedByVendorsItems(ReqItems);
			var configModel = this.getView().getModel("configModel");
			var configData = configModel.getData();
			var length = ReqItems.length;
			this.serviceAvailed = false;
			for (var i = 0; i < length; i++) {
				if (ReqItems[i].DelInd === "" && ReqItems[i].DispFilled === "X") {
					this.serviceAvailed = true;
				}
			}

			if (oEvent) {
				var oButtontext = oEvent.getSource().getText();
				this.sWrkflwBtnTxt = oButtontext;
			}

			if ((this.serviceAvailed === false) && (this.sWrkflwBtnTxt === "Revise")) {
				sap.m.MessageBox.error("Please fill atleast one service");
				return;
			}

			var oActionItems = {};
			$.each(oPgData['HeaderToWfActionNav'], function (ind, obj) {
				if (obj['Actlabel'] === this.sWrkflwBtnTxt) {
					oActionItems = obj;
				}

			}.bind(this))

			if (typeof oPgData !== "undefined") {
				var ReqItemsSet = oPgData.HeaderToItemNav;
			}

			if (this.sWrkflwBtnTxt !== "Reject") {

				//if(this.changeMade === "X" && oPgData.Rqstat !=='ACPT' && (oActionItems.Actlabel !== "Revise" || oActionItems.Action ==="03" || oActionItems.Action ==="02")){
				if (this.changeMade === "X" && oPgData.Rqstat !== 'ACPT' && (oActionItems.Actlabel !== "Revise")) {
					sap.m.MessageBox.error("Changes Made. Press Revise Button");
					return;
				}
				if (this.changeMade !== "X" && this.sWrkflwBtnTxt !== "Return" && oPgData.Rqstat !== 'ACPT') {
					sap.m.MessageBox.error("No changes Made. Please fill service");
					return;
				}

				for (var i = 0; i < length; i++) {
					if (configData['maktxowc'].Visible && ReqItems[i].ServLtext === "" && configData['maktxowc'].Editable) {
						sap.m.MessageBox.error("Service Name cannot be empty");
						return;
					}

					/*	//Well Number
						if (configData['wellnm_item'].Editable){
							if(ReqItems[i].Wellnm === ""){
								sap.m.MessageBox.error("Well Name cannot be empty");
								return;
							}
						}
					*/
					if (configData['meins'].Visible && configData['meins'].Editable) {
						if (ReqItems[i].Meins === "") {
							sap.m.MessageBox.error("Service UoM cannot be empty");
							return;
						}
					}
					/*if (ReqItems[i]['PoNo'] ==="" && this.sWrkflwBtnTxt ==="Revise"){
						sap.m.MessageBox.error("Please select po line item!");
						return; 
					}*/
				}
				//sSelectedReason
			}

			this.sText = "";
			//Core.byId("submissionNote").setValue(sText);
			//var sAction = "Revise";
			this.OnAddCmdtoField();
			//TODO: change sAction based on the selected button

			//only if it is revise or reject
			if (oActionItems.RemarksReq === 'X' || this.sWrkflwBtnTxt === "Reject" || this.sWrkflwBtnTxt === "Return") {

				if ((this.sWrkflwBtnTxt === "Reject" || this.sWrkflwBtnTxt === "Return") && this.sSelectedReason) {
					this._onRejectionReason(this.sWrkflwBtnTxt);
					return;
				}

				if (this.sWrkflwBtnTxt !== "Reject" && this.sWrkflwBtnTxt !== "Return") {

					/*if (!this.oSubmitDialog) {*/
					this.oSubmitDialog = new Dialog({
						type: DialogType.Message,
						title: "Confirm",
						content: [
							new Label({
								//	text: "The request will be submitted as "+sAction+". Do you want to continue ?",
								text: "Do you want to continue ?",
								labelFor: "submissionNote"
							}),
							new sap.m.TextArea({
								width: "100%",
								value: "",
								growingMaxLines: 15,
								growing: true,
								placeholder: "Remarks (required)",
								liveChange: function (oEvent) {
									this.sText = oEvent.getParameter("value");
									this.oSubmitDialog.getBeginButton().setEnabled(this.sText.length > 0);
								}.bind(this)
							})
						],
						beginButton: new Button({
							type: ButtonType.Emphasized,
							text: "Submit",
							enabled: false,
							press: function () {

								var aPromise = [];
								aPromise.push(this.onSaveOC());
								Promise.all(aPromise).then(function (results) {
									var sText = this.sText;
									var ReqItemsSet = undefined;
									this.sSelectedReason = true;
									this.WFExecuteAction(this.DrssNo, this.Mjahr, oActionItems.Action, oActionItems.Stattype, sText, this.Gid, ReqItemsSet);

								}.bind(this));

								this.oSubmitDialog.close();
							}.bind(this)
						}),
						endButton: new Button({
							text: "Cancel",
							press: function () {
								this.sSelectedReason = true;
								this.oSubmitDialog.close();
							}.bind(this)
						})
					});
					this.oSubmitDialog.open();
				} else {
					//var sText = this.sText;
					var ReqItemsSet = undefined;
					this.sSelectedReason = true;
					this.WFExecuteAction(this.DrssNo, this.Mjahr, oActionItems.Action, oActionItems.Stattype, this.oRejReasonText, this.Gid,
						ReqItemsSet);

				}
				/*}*/

			} else {
				MessageBox.information("Do you want to continue ?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: "sapUiSizeCompact",
					onClose: function (sAction) {
						if (sAction === "YES") {
							var ReqItemsSet = undefined;
							this.sSelectedReason = true;
							this.WFExecuteAction(this.DrssNo, this.Mjahr, oActionItems.Action, oActionItems.Stattype, '', this.Gid, ReqItemsSet);
						} else {
							this.sSelectedReason = true;
						}
					}.bind(this)
				});
			}
		},

		onDispItemPress: function (oEvent) {
			var ReqItems = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var configModel = this.getView().getModel("configModel");
			var configData = configModel.getData();
			var length = ReqItems.length;
			for (var i = 0; i < length; i++) {
				if (configData['maktxowc'].Visible && ReqItems[i].ServLtext === "" && configData['maktxowc'].Editable) {
					sap.m.MessageBox.error("Service Name cannot be empty");
					return;
				}

				/*if(ReqItems[i].Menge === ""){
					sap.m.MessageBox.error("Service Quantity cannot be empty");
					return;
				}*/
				if (configData['meins'].Visible && configData['meins'].Editable) {
					if (ReqItems[i].Meins === "") {
						sap.m.MessageBox.error("Service UoM cannot be empty");
						return;
					}
				}
			}
			var oItem = oEvent.getSource().getBindingContext('itemsModel').getObject();
			var oItemPath = oEvent.getSource().getBindingContext('itemsModel').sPath;
			this.oItemPath = oItemPath;

			var iPoNum = "";
			if (typeof oItem.PoNo !== "undefined" && typeof oItem.PoNo !== "") {
				var iPoNum = parseInt(oItem.PoNo);
			}
			var iPoItem = "";
			if (typeof oItem.PoItem !== "undefined" && typeof oItem.PoItem !== "") {
				var iPoItem = parseInt(oItem.PoItem);
			}

			var sLim_ind = oItem.LimitInd;
			var sCO_ind = oItem.CoInd;
			this.changeMade = "X";
			//this.changeWFActionButton();

			if ((iPoNum !== 0) && (iPoItem !== 0)) {

				if (typeof sCO_ind === "undefined" || sCO_ind === "") {
					if (typeof oItem.PoNo !== "undefined") {
						if (oItem.PoNo.substring(0, 2) === "66") {
							sCO_ind = "C";
						} else {
							sCO_ind = "PO";
						}
					} else {
						sCO_ind = "PO";
					}

				}

				if (typeof sLim_ind === "undefined" || sLim_ind === "") {
					sLim_ind = "0";
				}
				//this.getRouter().navTo("DispatchedServices", {objectId : this.getRequestId(), item: oItem.getProperty("Zeile"), EBELN: iPoNum, EBELP: iPoItem, lim_ind: sLim_ind, co_ind: sCO_ind  }, true);

				if (!this._DispServicesDialog) {
					this._DispServices = new DispatchedServicesSplit(this, "zdwo_nx_drss_ven.view.fragment.DispatchedServicesSplit");
				}

				this._DispServicesDialog = this._DispServices.createFragment(oItem.Docno, oItem.Zeile, iPoNum, iPoItem, "", sLim_ind, sCO_ind,
					oItem.ServiceId, oItem['Maktxo'], oItem);

				return;
			}
			var oModel = this.getView().getModel("VendorService");
			new POContractSelector(this.getView(), oModel, this, this.getView().getModel('itemsModel').getProperty("/Lifnr"),
				this.Rqtype,
				function (oPOItem) {

					iPoNum = oPOItem.EBELN;
					iPoItem = oPOItem.EBELP;

					// Update the selected PO/Line item of the request.
					oModel.callFunction("/SetPOForReqItm", {
						method: "GET",
						urlParameters: {
							Docno: oItem.Docno,
							Zeile: oItem.Zeile,
							PO: oPOItem.EBELN,
							PONO: oPOItem.EBELP

						},
						success: function (oData) {
							// me.hit_list.setData(oData)
							this.getView().getModel().setProperty(oItemPath + "/PoItem", oPOItem.EBELP);
							this.getView().getModel().setProperty(oItemPath + "/PoNo", oPOItem.EBELN);

							// console.log(oData);
							var Contract = oPOItem.EBELN;
							var Rqtype = oItem.Rqtype;
							var that = this;
						}.bind(this),
						error: function (error) {

						}
					});
					// Navigate to Dispatched services.
					//this.getRouter().navTo("DispatchedServices", {objectId : this.getRequestId(), item: oItem.Zeile, EBELN: oPOItem.EBELN, EBELP: oPOItem.EBELP }, true);

					if (!this._DispServicesDialog) {
						this._DispServices = new DispatchedServicesSplit(this, "zdwo_nx_drss_ven.view.fragment.DispatchedServicesSplit");
					}

					this._DispServicesDialog = this._DispServices.createFragment(oItem.Docno, oItem.Zeile, iPoNum, iPoItem, "", sLim_ind, sCO_ind,
						oItem['ServiceId'], oItem['Maktxo'], oItem);
				}.bind(this));
		},

		onDispatchSavePress: function (evt) {
			DispatchedServicesSplit.onAcceptConfirmation(evt);
			this._DispServicesDialog.close();
		},

		onFormTypeSelecteTicket: function (oEvent) {
			var Data = oEvent.getSource().getBindingContext("JobLoggingModel").getProperty(oEvent.getSource().getBindingContext(
				"JobLoggingModel").getPath());
			var itemModelData = this.getItemModelData();
			eTicket = "X";
			FormCode = Data.FormCode;

			var version = "0";

			if (this.getView().getModel("oETicketModel").getData()) {
				version = this.getView().getModel("oETicketModel").getData().Version;
			}
			var makeDate = itemModelData.Reqdt;
			makeDate.setMonth(makeDate.getMonth() - 1);
			var lastmonth = makeDate.getMonth() + 1;
			var lastyear = makeDate.getFullYear();
			this.getRouter().navTo(Data.FormRout, {
				DrssNo: itemModelData.Docno,
				Rqtype: itemModelData.Rqtype,
				Gid: this.Gid,
				Mjahr: itemModelData.Mjahr,
				Srvtype: itemModelData.SrvtypeCode,
				Zmonth: lastmonth,
				Zyear: lastyear,
				FormCode: FormCode,
				Version: version
			});

			controller.oETickVerChange = 'VersionChange';
			controller.oSelVersion = this.getView().getModel("oETicketModel").getData().Version;

			//this.getRouter().navTo("JL");
		},

		onJobLoggingListPress: function (oEvent) {
			var Data = oEvent.getSource().getBindingContext("JobLoggingModel").getProperty(oEvent.getSource().getBindingContext(
				"JobLoggingModel").getPath());
			var formType = Data.FormType;
			eTicket = "";
			FormCode = Data.FormCode;
			controller.FormCode = Data.FormCode;

			if (formType === "AF") {
				if (!this.JobLogAttachmentsDialog) {
					this.JobLogAttachmentsDialog = sap.ui.xmlfragment(this.getView().getId(),
						"zdwo_nx_drss_ven.view.fragment.OC.JobLogAttachmentsDialog", this);
					this.getView().addDependent(this.JobLogAttachmentsDialog);
				}

				var itemsModel = this.getView().getModel("itemsModel").getData();
				// this.byId("uploadCollectionJobLog").setUploadEnabled(false);

				// this.onmonthlyAttachment(Data);  

				if (typeof Data['FormCode'] !== 'undefined') {
					if (Data['FormFreq'] === "03") {
						this.onmonthlyAttachment(Data);
						//this.byId("uploadCollectionJobLog").setUploadEnabled(false);
					} else {
						this.JobLogAttachmentsDialog.open();
						this.oFilterJobLogAttach();
						this.JobLogAttachmentsDialog.setTitle(Data.FormName + " - Attachments");
						this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
					}
				}
			} else if (formType === "EF") {
				var itemModelData = this.getItemModelData();
				var makeDate = itemModelData.Reqdt;
				makeDate.setMonth(makeDate.getMonth() - 1);
				var lastmonth = makeDate.getMonth() + 1;
				var lastyear = makeDate.getFullYear();
				this.getRouter().navTo(Data.FormRout, {
					DrssNo: itemModelData.Docno,
					Rqtype: itemModelData.Rqtype,
					Gid: this.Gid,
					Mjahr: itemModelData.Mjahr,
					Srvtype: itemModelData.SrvtypeCode,
					Zmonth: lastmonth,
					Zyear: lastyear,
					FormCode: FormCode,
					Version: '0'
				});
			}

		},

		onmonthlyAttachment: function (Data) {
			var monthlyData = controller.getView().getModel("itemsModel").getObject("/HeaderToAttNav");
			var results = monthlyData.filter(obj => {
				return obj.Category === '03' && obj.Formcode === Data.FormCode;
			});

			if (results.length === 0) {
				sap.m.MessageBox.error('There is no document available');
				return;
			}
			this.getView().getModel("oMonthlyListModel").setData(null);
			this.getView().getModel("oMonthlyListModel").setData(results);
			this.getView().getModel("oMonthlyListModel").refresh(true);
			if (!this.onmonthlyAttachmentDialog) {
				this.onmonthlyAttachmentDialog = sap.ui.xmlfragment(this.getView().getId(),
					"zdwo_nx_drss_ven.view.fragment.JobLogging.JobLoggingMonthlyList", this);
				this.getView().addDependent(this.onmonthlyAttachmentDialog);
			}
			this.onmonthlyAttachmentDialog.open();
			this.onmonthlyAttachmentDialog.setTitle(Data.FormName + " - Attachments");

		},

		onCloseMonthly: function () {
			if (this.onmonthlyAttachmentDialog) {
				this.onmonthlyAttachmentDialog.close();
			}

		},

		onConsolidatedPdf: function () {
			var itemModelData = this.getItemModelData();
			var makeDate = itemModelData.Reqdt;
			makeDate.setMonth(makeDate.getMonth() - 1);
			var lastmonth = makeDate.getMonth() + 1;
			var lastyear = makeDate.getFullYear();
			this.getRouter().navTo("JL", {
				DrssNo: itemModelData.Docno,
				Rqtype: itemModelData.Rqtype,
				Gid: this.Gid,
				Mjahr: itemModelData.Mjahr,
				Srvtype: itemModelData.SrvtypeCode,
				Zmonth: lastmonth,
				Zyear: lastyear,
				FormCode: FormCode,
				PdfRoute: 'X'
			});
		},

		oFilterJobLogAttach: function () {
			this.byId("uploadCollectionJobLog").data({
				ItemValue: controller.FormCode
			});
			var oBinding = this.byId("uploadCollectionJobLog").getBinding("items");
			if (oBinding) {
				//oBinding.filter(null);
				oBinding.filter([
					new sap.ui.model.Filter("Category", "EQ", "03"),
					new sap.ui.model.Filter("Formcode", "EQ", controller.FormCode)
				]);
			}
			oBinding.refresh();
		},

		onJobLoggingListPresseTicket: function (oEvent) {
			if (oEvent.getSource().getType() === "Active") {
				var Data = oEvent.getSource().getBindingContext("AttServiceFormModel").getProperty(oEvent.getSource().getBindingContext(
					"AttServiceFormModel").getPath());
			} else {
				var Data = oEvent.getSource().getBindingContext("JobLoggingModel").getProperty(oEvent.getSource().getBindingContext(
					"JobLoggingModel").getPath());
			}

			var formType = Data.FormType;
			eTicket = "X";
			FormCode = Data.FormCode;
			controller.FormCode = Data.FormCode;
			if (formType === "AF") {
				if (!this.JobLogAttachmentsDialog) {
					this.JobLogAttachmentsDialog = sap.ui.xmlfragment(this.getView().getId(),
						"zdwo_nx_drss_ven.view.fragment.OC.JobLogAttachmentsDialog", this);
					this.getView().addDependent(this.JobLogAttachmentsDialog);
				}

				if (typeof Data['FormCode'] !== 'undefined') {
					if (Data['FormFreq'] === "03") {
						this.onmonthlyAttachment(Data);
					} else {
						this.JobLogAttachmentsDialog.open();
						this.oFilterJobLogAttach();
						this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
					}
				}
			} else if (formType === "EF") {
				var itemModelData = this.getItemModelData();
				var makeDate = itemModelData.Reqdt;
				makeDate.setMonth(makeDate.getMonth() - 1);
				var lastmonth = makeDate.getMonth() + 1;
				var lastyear = makeDate.getFullYear();
				this.getRouter().navTo(Data.FormRout, {
					DrssNo: itemModelData.Docno,
					Rqtype: itemModelData.Rqtype,
					Gid: this.Gid,
					Mjahr: itemModelData.Mjahr,
					Srvtype: itemModelData.SrvtypeCode,
					Zmonth: lastmonth,
					Zyear: lastyear,
					FormCode: FormCode
				});
			} else {
				// Do Nothing
			}

		},

		onUploadCompleteJob: function (evt) {
			//controller.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getModel().setProperty(controller.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getPath()+"/FormStatus","SUBT")
			//this.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getModel().refresh();
			//var sPath = this.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getPath();
			//this.JobLogAttachmentsDialog.unbindElement("itemsModel");
			//this.JobLogAttachmentsDialog.bindElement({model:"itemsModel",path:sPath});

			// this._OCReqData(this.itemDetails.DrssNo,this.itemDetails.Mjahr,this.itemDetails.Rqtype,this.itemDetails.SrvtypeCode);

			if (typeof evt !== "undefined" && evt.mParameters.mParameters.status !== 201) {
				var responseRaw = evt.mParameters.mParameters.responseRaw;
				var start = responseRaw.indexOf("<errordetails>");
				var list = [];
				if (start > -1) {

					var end = responseRaw.indexOf("</errordetails>");
					var message = responseRaw.substr(start, end);
					var errorMessages = message.split("<message>");
					for (var i = 0; i < errorMessages.length; i++) {
						var erMsg = errorMessages[i];
						if (erMsg.indexOf("</message>") > -1) {
							var msg = {
								severity: "Error",
								message: erMsg.substr(0, erMsg.indexOf("</message>")),
								description: erMsg.substr(0, erMsg.indexOf("</message>"))
							};
							list.push(msg);
						}
					}
					if (list.length > 0) {
						this.instantiateErrorMessageModel(list);
						this.createMessagePopoverModel();

					}
				}

			} else {
				var oModel = this.getView().getModel("VendorService");
				var docNo = this.getDocno();
				var year = this.getYear();
				this.oSets = "HeaderToAttNav," + "HeaderToItemNav";
				var busyDialog = new sap.m.BusyDialog({
					title: 'Loading...'
				});
				busyDialog.open();

				var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + this.itemDetails.Rqtype + "')";
				oModel.read(params, {
					urlParameters: {
						"$expand": this.oSets
					},
					success: function (oData) {
						this.getJoblogging();
						this._getAttachFormFiles();
						this.getView().getModel("itemsModel").getData()['HeaderToAttNav'] = oData['HeaderToAttNav']['results'];
						this.getView().getModel("itemsModel").refresh();
						this.oFilterJobLogAttach();
						busyDialog.close();
					}.bind(this),

					error: function (oResponse) {
						busyDialog.close();
						if (oResponse.responseText) {
							var parsedJson = JSON.parse(oResponse.responseText);
							sap.m.MessageBox.error(parsedJson.error.message.value);
						}

					}.bind(this)
				});

			}
			//   var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "')";
		},

		getItemModelData: function () {
			return this.getView().getModel("itemsModel").getData();
		},

		getJobLoggingModelData: function () {
			return this.getView().getModel("JobLoggingModel").getData();
		},

		onTreeSearchMaster: function (evt) {

			var oTable = Core.byId("treeMaster");
			var oBinding = oTable.getBinding("items");
			oTable.expandToLevel(100);
			var aFilters = [];
			var sQuery = evt.getSource().getValue();

			const aWords = sQuery.split(" ");
			var sWord = "";
			for (var x = 0; x < aWords.length; x++) {
				sWord = aWords[x];
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord.toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord.toUpperCase()));
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord[0].toUpperCase() + sWord.substr(1)
					.toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord));
			}
			var oFilter = [new sap.ui.model.Filter(aFilters, false)];
			oBinding.filter(oFilter);

		},
		//HeaderToSaudizationNav
		getETicketInfo: function (oEvent, oETickVerChange) {
			var oETicketingService = this.getView().getModel("oETicketingService");
			this.busyDialog.open();
			this.sStatus = oEvent;
			var oSelectedVersion = "";
			if (oETickVerChange === 'VersionChange') {
				var oSelectedVersion = oEvent.getSource().getText();

			} else if (controller.oETickVerChange === 'VersionChange') {
				var oSelectedVersion = controller.oSelVersion;
			}

			if (oEvent === "JOBL") {
				var sEntityPath = oETicketingService.createKey("/ETicketHdrSet", {
					Etkt: "",
					Version: oSelectedVersion
				});
				var aFilters = []; /**/
				aFilters.push(new sap.ui.model.Filter("Docno", sap.ui.model.FilterOperator.EQ, this.getDocno()));
				aFilters.push(new sap.ui.model.Filter("Mjahr", sap.ui.model.FilterOperator.EQ, this.Mjahr));
			} else {
				var sEntityPath = oETicketingService.createKey("/ETicketHdrSet", {
					Etkt: this.getDocno(),
					Version: oSelectedVersion
				});
			}

			if (this.eTicketDialog) {
				this.eTicketDialog.setBusy(true);
			}

			oETicketingService.read(sEntityPath, {
				filters: aFilters,
				urlParameters: {
					"$expand": "HeaderToItemNav,HeaderToRemarksNav,HeaderToWfLogNav,HeaderToOLDWfLogNav,HeaderToVrsnNav,HeaderToSaudizationNav,HeaderToFinanceDataNav"
				},
				success: function (oData) {
					var oETicketModel = this.getView().getModel("oETicketModel");
					oData['HeaderToItemNav'] = oData['HeaderToItemNav'].results;
					oData['HeaderToEDrssNav'] = oData['HeaderToEDrssNav'].results;
					oData['HeaderToEFormsNav'] = oData['HeaderToEFormsNav'].results;
					oData['HeaderToWfLogNav'] = oData['HeaderToWfLogNav'].results;
					oData['HeaderToOLDWfLogNav'] = oData['HeaderToOLDWfLogNav'].results;
					oData['HeaderToVrsnNav'] = oData['HeaderToVrsnNav'].results;
					oData['HeaderToSaudizationNav'] = oData['HeaderToSaudizationNav'].results;
					oData['HeaderToFinanceDataNav'] = oData['HeaderToFinanceDataNav'].results;
					oData['HeaderToRemarksNav'] = oData['HeaderToRemarksNav'].results;
					oData['eTicket'] = oData['HeaderToItemNav'];
					oData['eDrss'] = oData['HeaderToEDrssNav'];
					oData['verDetailsTaxi'] = oData['HeaderToEFormsNav'];
					oData['saudiDetails'] = oData['HeaderToSaudizationNav'];
					this.getView().getModel("data").setData(oData);
					oETicketModel.setData(oData);
					this.getOwnerComponent().setModel(oETicketModel, "oCompETicketModel");
					if (controller.byId("ProcessFlowId")) {
						controller.byId("ProcessFlowId").updateModel(true);
					}

					if (controller.byId("OldProcessHeader")) {
						controller.byId("OldProcessHeader").updateModel(true);
					}
					if (controller.byId("processFlowHeader")) {
						controller.byId("processFlowHeader").updateModel(true);
					}

					if (oETickVerChange === 'VersionChange') {
						this.onPreviewETicketPress('VersionChange');
					}

					if (this.eTicketDialog) {
						this.eTicketDialog.setBusy(false);
					}
					this.getOwnerComponent().setModel(oETicketModel, "oETicketModel");
					var oETicketModel = this.getView().getModel("oETicketModel").getData();
					var oitemsModel = this.getView().getModel("itemsModel").getData();
					var docNo = oETicketModel.Docno;
					if (docNo === "") {
						docNo = oitemsModel.Docno;
					}

					if (controller.ConsPdf == "X") {
						this._postForemanConSubmit(oData.Version, docNo);
						console.log("Foreman PDF");
						console.log(controller.ForemanBase64);
						this._postVendorConSubmit(oData.Version, docNo);
						console.log("Vendor PDF");
						console.log(controller.VendorBase64);
					}
					controller.ConsPdf = "";
					controller.oForemanPdf = "";
					this.onConsolidatedPdfAll();
					controller.oForemanPdf = "X"
					this.onConsolidatedPdfAll();
					this.busyDialog.close();

				}.bind(this),
				error: function (oError) {
					this.busyDialog.close();
					if (oError.responseText) {
						var parsedJson = JSON.parse(oError.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}
				}.bind(this)
			});
		},

		_getInputComment: function () {
			var oETicketData = this.getView().getModel("oETicketModel").getData();
			this.eTicketingCommentsDialog = new Dialog({
				type: DialogType.Message,
				title: "Do you want to continue ?",
				content: [
					/*new Label({
						text: "Do you want to continue ?",
						labelFor: "submissionNote"
					}),*/
					new sap.m.TextArea({
						width: "100%",
						value: "",
						growingMaxLines: 15,
						growing: true,
						placeholder: "eTicket Remarks (required)",
						liveChange: function (oEvent) {
							var oComments = oEvent.getParameter("value");
							oETicketData.Comments = oComments;
							this.eTicketingCommentsDialog.getBeginButton().setEnabled(oComments.length > 0);
						}.bind(this)
					})
				],
				beginButton: new Button({
					type: ButtonType.Emphasized,
					text: "Submit",
					enabled: false,
					press: function () {
						this.onGenerateETicket();
						this.eTicketingCommentsDialog.close();
					}.bind(this)
				}),
				endButton: new Button({
					text: "Cancel",
					press: function () {
						//	this.sSelectedReason=true;
						this.eTicketingCommentsDialog.close();
					}.bind(this)
				})
			});
			this.eTicketingCommentsDialog.addStyleClass('eTicketWidthClass');
			this.eTicketingCommentsDialog.open();
		},

		onSubmitTicket: function (oEvent) {
			//  var oETicketData = 	this.getView().getModel("oETicketModel").getData();
			// Commented as per Vijay comment on 06/07/2023
			/*var itemsModelData= controller.getModel("itemsModel").getData();
			if(itemsModelData['Rqstat'] === 'ETKR' || itemsModelData['Rqstat'] === 'ETRE'){
				this._getInputComment();
			}else {
				this.onGenerateETicket(oEvent);
			}*/
			this._getInputComment();
		},

		onGenerateETicket: function () {

			var eTicketModel = this.getView().getModel("oETicketModel");
			if (eTicketModel.getObject("/SrvLoc") === "") {
				MessageBox.error("Please enter Work Location");
				return;
			}
			if (eTicketModel.getObject("/ExtReference") === "") {
				MessageBox.error("Please enter Supplier Invoice Number");
				return;
			}
			MessageBox.information("Please confirm all operations and services log before submitting the eTicket. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {

						this.eTicketSubmit();
					}
				}.bind(this)
			});
		},

		_postForemanConSubmit: function (pVrsn, docNo) {
			var oVendorModel = controller.getOwnerComponent().getModel("oETicketingService");
			oVendorModel.create('/eTicketAttachSet', controller.ForemanBase64, {
				headers: {
					slug: "ForemanConsolidated.pdf",
					FormCode: "F040",
					version: pVrsn,
					etkt: docNo
				},
				success: function (oFrRes) {

				}.bind(this),
				error: function (err) {}
			})
		},

		_postVendorConSubmit: function (pVrsn, docNo) {
			var oVendorModel = controller.getOwnerComponent().getModel("oETicketingService");
			oVendorModel.create('/eTicketAttachSet', controller.VendorBase64, {
				headers: {
					slug: "VendorConsolidated.pdf",
					FormCode: "F039",
					version: pVrsn,
					etkt: docNo
				},

				success: function (oVenRes) {

				}.bind(this),
				error: function (err) {

				}
			})
		},
		eTicketSubmit: function () {
			var oETicketingService = this.getView().getModel("oETicketingService");
			var oETicketModel = this.getView().getModel("oETicketModel").getObject("/");
			var busyDialog = new sap.m.BusyDialog({
				title: 'Saving...'
			});
			busyDialog.open();
			oETicketModel.Operation = "02";
			delete oETicketModel.eTicket;
			delete oETicketModel.__metadata;
			delete oETicketModel.eDrss;
			delete oETicketModel.verDetailsTaxi;
			delete oETicketModel.saudiDetails;
			delete oETicketModel.HeaderToFinanceDataNav;
			//oETicketModel.JoblogForm = controller.base64;
			oETicketingService.create("/ETicketHdrSet", oETicketModel, {
				success: function (oData) {
					var msg = "eTicket Request updated successfully with refrence no " + oData.Docno + " ";
					MessageBox.success(msg);
					busyDialog.close();
					this.getRequestData(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);
					controller.ConsPdf = "X";
				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		onPreviewETicketPress: function (oEvent) {
			if (oEvent !== 'VersionChange') {
				this.getETicketInfo("JOBL");
			} else {
				controller.oForemanPdf = "";
				this.onConsolidatedPdfAll();
				controller.oForemanPdf = "X"
				this.onConsolidatedPdfAll();
			}

			if (!this.eTicketDialog) {
				this.eTicketDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.eTicketing.fragment.ETicketPreviewPopUp", this);
				this.getView().addDependent(this.eTicketDialog);
			}
			this.eTicketDialog.open();
		},

		oncloseJLType: function (oEvent) {
			this.eTicketDialog.close();
			controller.oETickVerChange = '';
			this.getETicketInfo(this.getView().getModel("itemsModel").getData().Rqstat);
		},

		oneTicketRemarks: function (oEvent) {
			/*if(!this.eTicketRemarksDialog){*/
			this.eTicketRemarksDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.eTicketing.fragment.eTicketRemarksOC",
				this);
			this.getView().addDependent(this.eTicketRemarksDialog);
			/*}*/
			this.eTicketRemarksDialog.open();
		},

		oncloseeTicketRemarks: function (oEvent) {
			this.eTicketRemarksDialog.close();
		},

		SelectServiceForStatus: function (evt) {
			if (!this.SelectServiceDialog) {
				this.SelectServiceDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.SelectServiceList", this);
				this.getView().addDependent(this.SelectServiceDialog);
			}
			this.SelectServiceCall(evt.getSource().data().DocNo, evt.getSource().data().Mjahr, evt.getSource().data().Zeile);
		},

		SelectServiceCall: function (Docno, Mjahr, Zeile) {
			this.busyDialog.open();
			var params = "/ReqItemsSet(Docno='" + Docno + "',Mjahr='" + Mjahr + "',Zeile='" + Zeile + "')/toVendorESV";
			var oModel = this.getView().getModel("VendorService");
			oModel.read(params, {
				success: function (oData) {
					this.getView().setModel(new JSONModel(oData.results), "SelectServiceModel");
					this.SelectServiceDialog.open();
					this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
					this.busyDialog.open();
				}.bind(this)
			});
		},

		onCloseSelectServiceDialog: function (evt) {
			this.SelectServiceDialog.close();
		},
		onStatusPressed: function (oEvent) {
			//debugger;

			var oButton = oEvent.getSource();
			var sBindingPath = oEvent.getSource().getBindingContext("oETicketModel").getPath();

			// create popover
			if (!this._oPopover) {
				sap.ui.core.Fragment.load({
					name: "zdwo_nx_drss_ven.view.eTicketing.fragment.statusPopover",
					controller: this
				}).then(function (pPopover) {
					this._oPopover = pPopover;
					this.getView().addDependent(this._oPopover);
					this._oPopover.bindElement({
						path: sBindingPath,
						model: "oETicketModel"
					});
					this._oPopover.openBy(oButton);
				}.bind(this));
			} else {
				this._oPopover.bindElement({
					path: sBindingPath,
					model: "oETicketModel"
				});
				this._oPopover.openBy(oButton);
			}
		},

		onVersionClicked: function (oEvent) {
			//debugger;
			var oButton = oEvent.getSource();
			// create popover
			if (!this._oVersionPopover) {
				sap.ui.core.Fragment.load({
					name: "zdwo_nx_drss_ven.view.eTicketing.fragment.versionHistoryPopover",
					controller: this
				}).then(function (pPopover) {
					this._oVersionPopover = pPopover;
					this.getView().addDependent(this._oVersionPopover);
					//this._oVersionPopover.bindItems( { path: "/HeaderToVrsnNav/results" , model:"oETicketModel"});
					this._oVersionPopover.openBy(oButton);
				}.bind(this));
			} else {
				//this._oVersionPopover.bindElement( { path: "/HeaderToVrsnNav/results" , model:"oETicketModel"});
				this._oVersionPopover.openBy(oButton);
			}
		},
		handleLinkPress: function (oEvent) {

			this.getETicketInfo(oEvent, "VersionChange");

		},

		onFlenameLengthExceed: function () {
			MessageBox.error("File name must not exceed 50 characters");
		},

		validate3Decimal: function (evt) {
			var oLocale = new sap.ui.core.Locale("en-US");
			var oFormatOptions = {
				minFractionDigits: 3,
				maxFractionDigits: 3
			};

			var val = evt.getSource().getValue().trim();
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(oFormatOptions, oLocale);
			var newVal = oFloatFormat.parse(val);
			debugger;
			evt.getSource().setValue(newVal);

		},

		getVersion: function (oContext) {
			return oContext.getProperty('Version');

		},

		getGroupHeader: function (oGroup) {
			return new GroupHeaderListItem({
				title: "Version: " + oGroup.key
			});
		},

		onETicktPDF: function () {

			var doc = {
				pageSize: "A3",
				pageOrientation: "landscape",
				pageMargins: [30, 5, 30, 30],
				content: [],
				styles: {
					small: {
						fontSize: 10
					},
					headerLabel: {
						fontSize: 11,
						bold: true,
						alignment: 'right',
						border: [false, false, false, false]
					},
					sectionTitle: {
						fontSize: 18,
						bold: true,
						alignment: 'center',
						margin: [0, 20, 0, 20]

					},
					pageTitle: {
						fontSize: 16,
						bold: true,
						color: '#0033a0',
						alignment: 'center',
						margin: [0, 0, 0, 5]
					},

					subheader: {
						fontSize: 13,
						bold: true,
						margin: [0, 5, 0, 5]
					},
				}
			};

			//this._oGetPdfHeader(doc, "");
			this._pdfHeaderLogo(doc, "");
			var oETicketModel = this.getOwnerComponent().getModel("oCompETicketModel");
			var oETKTData = oETicketModel.getData();
			doc.content.push({
				text: 'eTicket Report - Version : ' + oETKTData.Version,
				style: 'pageTitle'
			});
			//doc.content.push({ text: 'Version : ' + oETKTData.Version , style: 'subheader' });
			doc.content.push(this._getETicketReportHeader("Ven_ETicket_header"));

			var border = {
				table: {
					margin: [0, 0, 0, 50],
					widths: ["*"],
					body: [
						[{
							text: "",
							style: 'headerLabel',
							border: [false, false, false, true]
						}]
					]
				}
			}
			doc.content.push(border);
			doc.content.push({
				text: "",
				style: 'pageTitle'
			});
			doc.content.push(this._getETicketReport(oETKTData));
			var oitemsModel = this.getView().getModel("itemsModel");
			pdfMake.createPdf(doc).download(oitemsModel.getData()['Docno'] + "- ETicket.pdf");
		},

		onRecalleTicket: function (evt) {
			MessageBox.information("eTicket will be recalled and respective agents will be notified. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						this.eTicketRecallFunction();
					}
				}.bind(this)
			});
		},

		eTicketRecallFunction: function () {
			var oModel = this.getView().getModel("oETicketingService");
			oModel.callFunction("/eTicketRecall", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr
				},
				success: function (oData) {
					MessageBox.success("eTicket Request recalled successfully");
					this.getRequestData();
				}.bind(this),
				error: function (error) {
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		fnComparator: function (a, b) {
			return parseInt(a) - parseInt(b);
		},

		_loadPDFConfig: function (oEvent) {
			var oReportsOdataModel = this.getView().getModel("oReportsOdataModel");
			oReportsOdataModel.read("/PDFJoblogSummarySet", {
				success: function (oData) {
					oData = oData.results;
					this.getView().getModel("oPDFMappingModel").setData(oData);
				}.bind(this),
				error: function (oResponse) {
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}
				}.bind(this)
			});
		},

		onGetConsPDFData: function () {
			var oItemsModel = this.getView().getModel("itemsModel");
			if (oItemsModel) {
				var oDocNo = oItemsModel.getProperty("/Docno");
				var oMjahr = oItemsModel.getProperty("/Mjahr");
				var oSrvtyp = oItemsModel.getProperty("/Srvtyp");
			}
			this._loadPDFConfig();
			this._getOperationalReport();
			this._getData();
			//this._getJobLogOpeSet();
			this._jobloggingServiceData();
			this._getDataTvd(oDocNo, oMjahr);
			this._getDataSos(oDocNo, oMjahr);
			this._MrDateRel(oDocNo, oMjahr, oSrvtyp);
		},

		_getFinalDataModel: function () {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			this.summarySheet = false;
			var aFilter = [];
			var oReportsOdataModel = this.getView().getModel("oReportsOdataModel");
			//if (this.DrssNo !== "") {
			var oItemsModel = this.getView().getModel("itemsModel").getData();
			var oDocFilter = new sap.ui.model.Filter("Docno", "EQ", oItemsModel['Docno']);
			aFilter.push(oDocFilter);
			//	}
			var selectModel = this.getModel("SelectModel").getProperty("/JLSTATUS");
			for (var i = 0; i < selectModel.length; i++) {
				aFilter.push(new sap.ui.model.Filter("Jlstatus", "EQ", selectModel[i].Value1));
			}
			var JobLogType = controller.aJLConfigTypes;
			for (var i = 0; i < controller.aJLConfigTypes.length; i++) {
				aFilter.push(new sap.ui.model.Filter("JobLog", "EQ", JobLogType[i].id));
			}
			oReportsOdataModel.read("/JobLogDetailsSet", {
				filters: aFilter,
				success: function (oData) {
					var aSummaryDetailsData = oData.results;
					var aTransprtations = aSummaryDetailsData.filter(x => x.JobLog === "JL0002");
					var aOthers = aSummaryDetailsData.filter(x => x.JobLog !== "JL0002");
					var sortedSDData = $.merge(aTransprtations, aOthers);
					var aJobLogTypesBasedStructure = [];
					sortedSDData.forEach(e => {
						if (!aJobLogTypesBasedStructure.find(x => x.JobLog === e.JobLog)) {
							aJobLogTypesBasedStructure.push({
								JobLog: e.JobLog,
								JobLogDesc: e.JobLogDesc,
								content: [],
								bIsGrouping: true,
								Jlstatus: "empty"
							});
						}
					});
					for (var i = 0; i < aJobLogTypesBasedStructure.length; i++) {
						sortedSDData.forEach(e => {
							if (aJobLogTypesBasedStructure[i].JobLog === e.JobLog) {
								aJobLogTypesBasedStructure[i].content.push(e);
							}
						});
					}
					this.getView().getModel("oSummaryReportModelDetail").setData(aSummaryDetailsData);
					var JL0001 = 0;
					var JL0002 = 0;
					var JL0003 = 0;
					var JL0004 = 0;
					var JL0005 = 0;
					var APRV = 0;
					var SUBT = 0;
					var REJC = 0;
					if (oData.results.length > 0) {
						for (var i = 0; i < oData.results.length; i++) {
							switch (oData.results[i].JobLog) {
							case "JL0001":
								JL0001 += parseInt(1)
								break;
							case "JL0002":
								JL0002 += parseInt(1)
								break;
							case "JL0003":
								JL0003 += parseInt(1)
								break;
							case "JL0004":
								JL0004 += parseInt(1)
								break;
							case "JL0005":
								JL0005 += parseInt(1)
								break;
							default:
								break;
							}
							switch (oData.results[i].Jlstatus) {
							case "APRV":
								APRV += parseInt(1)
								break;
							case "SUBT":
								SUBT += parseInt(1)
								break;
							case "REJC":
								REJC += parseInt(1)
								break;
							default:
								break;
							}
						}
					}
					busyDialog.close();

				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			})

			//// for summary Report
			//	var aFilter = [];
			oReportsOdataModel.read("/JobLogSmrySet", {
				filters: aFilter,
				success: function (oData) {
					var JL0001 = 0;
					var JL0002 = 0;
					var JL0003 = 0;
					var JL0004 = 0;
					var JL0005 = 0;
					var APRV = 0;
					var SUBT = 0;
					var REJC = 0;
					if (oData.results.length > 0) {
						for (var i = 0; i < oData.results.length; i++) {
							switch (oData.results[i].JobLog) {
							case "JL0001":
								JL0001 += parseInt(1)
								break;
							case "JL0002":
								JL0002 += parseInt(1)
								break;
							case "JL0003":
								JL0003 += parseInt(1)
								break;
							case "JL0004":
								JL0004 += parseInt(1)
								break;
							case "JL0005":
								JL0005 += parseInt(1)
								break;
							default:
								break;
							}

							switch (oData.results[i].Jlstatus) {
							case "APRV":
								APRV += parseInt(1)
								break;
							case "SUBT":
								SUBT += parseInt(1)
								break;
							case "REJC":
								REJC += parseInt(1)
								break;
							default:
								break;
							}

						}
					}
					this.emptyobject(oData.results);
				}.bind(this),
				error: function (oResponse) {
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}
				}.bind(this),
			});
		},

		_jobloggingServiceData: function () {
			var itemsModel = this.getModel("itemsModel");
			if (itemsModel) {
				var oDocNo = itemsModel.getProperty("/Docno");
				var oSrvtyp = itemsModel.getProperty("/Srvtyp");
			}

			if (!oSrvtyp) {
				oSrvtyp = this.Srvtype;
			}
			var oModel = this.getView().getModel("VendorService");
			const getJLcfg = new Promise(function (resolve, reject) {
				oModel.read("/JobLoggingServiceSet(ServiceType='" + oSrvtyp + "')", {
					urlParameters: {
						"$expand": "ServiceToJobLogNav"
					},
					success: function (oData) {
						// Get the JL configuration
						if (oData.ServiceToJobLogNav.results.length > 0) {
							controller.aJLConfigTypes = [];
							var getData = oData.ServiceToJobLogNav.results;
							$.each(getData, function (ind, obj) {
								if (obj.JobLogDesc !== "")
									var oJLObj = {
										id: obj.JobLog,
										desc: obj.JobLogDesc
									};
								controller.aJLConfigTypes.push(oJLObj);
							}.bind(this))
						}

						var JobLogCfgModel = new JSONModel(oData.ServiceToJobLogNav.results);
						this.getView().setModel(JobLogCfgModel, "JobLogCfgModel");

						resolve();
					}.bind(this),
					error: function (error) {
						var msgs = this.getErrorMessages(error);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();
						reject();
					}.bind(this)
				});
			}.bind(this));

			var oItemsModel = this.getView().getModel("itemsModel");
			if (oItemsModel) {
				var oDocNo = oItemsModel.getProperty("/Docno");
				//var oMjahr = oItemsModel.getProperty("/Mjahr");
			}
			var busyDialog = new sap.m.BusyDialog({
				title: 'Processing...'
			});
			busyDialog.open();
			this.Version = '0';
			const getJobLogging = new Promise(function (resolve, reject) {
				if (this.Version !== '' && this.Version !== '0') {
					var oFilter = [new sap.ui.model.Filter("Version", "EQ", this.Version)];
				} else {
					var oFilter = [];
				}
				this.Mjahr
				var oModel = this.getView().getModel("VendorService");
				oModel.read("/JobLoggingSet(Docno='" + oDocNo + "',Mjahr='" + this.Mjahr + "')", {
					urlParameters: {
						"$expand": "DRSSJobLoggingNAV,JobLoggingServiceDataNAV,JobLoggingNAV,TimesheetNAV"
					},
					filters: oFilter,
					success: function (oData) {
						var Inbox = 0;
						var Rejected = 0;
						var Approved = 0;
						var All = 0;
						//Begin of Addition for CAD Deductions
						var data = this.getView().getModel("JobLogCfgModel").getData();
						var results = "";
						var obj = oData.JobLoggingNAV.results[0];
						for (var i = 0; i < oData.JobLoggingServiceDataNAV.results.length; i++) {
							obj.Docno = oData.Docno;
							obj.Mjahr = oData.Mjahr;
							obj.Zeile = oData.Zeile;
							oData.JobLoggingServiceDataNAV.results[i].nodes = [obj];
						}
						var oTableItems = this.getView().getModel("JobLogFinalDataModel").getData();
						oTableItems.sort(function (a, b) {
							return a.Sno - b.Sno
						});
						//End of Addition for CAD Deductions		
						let limit = oData.JobLoggingNAV.results.length + oData.JobLoggingServiceDataNAV.results.length + oData.DRSSJobLoggingNAV.results
							.length;
						var oJsonModel = new JSONModel(oData);
						oJsonModel.setSizeLimit(limit);
						this.getView().setModel(oJsonModel, "JobLogModelPDF");
						this.getView().getModel("JobLogFinalDataModel").setData(null);
						this.getView().getModel("JobLogFinalDataModel").setData(oData.DRSSJobLoggingNAV.results);
						this.getView().getModel("oTSModel").setData(oData.TimesheetNAV.results);
						this.getView().getModel("JobLogFinalDataModel").setSizeLimit(limit);
						this.getView().getModel("JobLogFinalDataModel").refresh(true);
						busyDialog.close();
						resolve();
					}.bind(this),
					error: function (error) {
						busyDialog.close();
						reject();
						var msgs = this.getErrorMessages(error);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();

					}.bind(this)
				});
			}.bind(this));

			const getSelectModel = new Promise(function (resolve, reject) {
				var oModel = this.getView().getModel("oDataModel");
				var itemsModel = this.getModel("itemsModel").getData();
				var oSelectModel = this.getView().getModel("SelectModel");
				var oSelcData = oSelectModel.getData();
				var objData = {
					JLSTATUS: "",
					//  ZDWO_RADIUS:"",
					//  ZP_RS_PRRTY:"",
					//  ZDWO_HOLE_SIZE:""
				};
				for (var prop in objData) {
					//if (func.hasOwnProperty(prop)) {
					var aFilters = [];
					aFilters.push(new Filter("Field", FilterOperator.EQ, prop));
					// aFilters.push(new Filter("Descr4", FilterOperator.EQ, oData.Rqtype));
					oModel.read("/F4SearchHelpSet", {
						filters: aFilters,
						success: function (oData) {
							if (oData.results.length > 0) {
								var odataField = oData.results[0].Descr2;
								if (odataField !== "" && (odataField === "ZDWO_RADIUS" || odataField === "ZP_RS_PRRTY" ||
										odataField === "ZDWO_HOLE_SIZE")) {
									itemsModel[odataField] = oData.results;
								} else if (odataField !== "") {
									oSelcData[odataField] = oData.results;
									oSelectModel.refresh();
									console.log(oData);
								}
							}
							resolve();
						}.bind(this),
						error: function (oResponse) {
							var msgs = this.getErrorMessages(oResponse);
							reject();
						}.bind(this)
					});
					//  }
				}

			}.bind(this));

			Promise.all([getJLcfg, getJobLogging, getSelectModel]).then((values) => {
				this._getFinalDataModel();
			});

			// On Promise
			/*var aPromise = [];
			aPromise.push(this._getJobLoggingServiceConfig());
			aPromise.push(this._getJobLoggingData());
			aPromise.push(this._getSelectModelFields());
			Promise.all([this._getJobLoggingServiceConfig(),this._getJobLoggingData(),this._getSelectModelFields()]).then(function(oRequest) {
	           
				console.log("Got it")
        	}.bind(this));*/
		},

		_MrDateRel: function (Docno, Mjahr, SrvtypeCode) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			var SrvtypeCode = this.getOwnerComponent().getModel("itemsModel").getObject("/SrvtypeCode");
			var oDataModel = this.getView().getModel("VendorService");
			oDataModel.read("/JobLoggingMrRelSet(Docno='" + Docno + "',Mjahr='" + Mjahr + "',SrvtypeCode='" + SrvtypeCode + "')", {
				success: function (oData) {
					this.getView().getModel("MrDateRelModel").setData(oData);
					busyDialog.close();
				}.bind(this),
				error: function (oError) {
					busyDialog.close();
				}.bind(this)
			});
		},

		// F4 Model
		_getOperationalReport: function () {
			this.getView().setModel(new JSONModel({}), "F4Models");
			//Holds LubSum enabled table data
			var oDataModel = this.getView().getModel("oDataModel");
			oDataModel.read("/F4SearchHelpSet", {
				filters: [new sap.ui.model.Filter("Field", "EQ", 'JOB_LOG_OPE')],
				success: function (oData) {
					oData = oData.results;
					this.getView().getModel("F4Models").setData(oData);
					this.getView().getModel("F4Models").refresh();
				}.bind(this),
				error: function (oError) {}.bind(this)
			});

		},

		emptyobject: function (oEvent) {
			var oLSSummaryModel = this.getView().getModel("oLSSummaryModel");
			var total1 = this.totalSummaryCost(oEvent);
			var summaryArray = [];
			const finalSummaryArray = [];
			var months = ["Jan'", "Feb'", "Mar'", "Apr'", "May'", "Jun'", "Jul'", "Aug'", "Sept'", "Oct'", "Nov'", "Dec'"];
			for (var i = 0; i < oEvent.length; i++) {
				var chartObject = {
					"ContRef": "",
					"Month": "",
					"Currency": "",
					"Discounts": "0.000",
					"Docno": "",
					"GrandTotal": "0.000",
					"Jlstatus": "",
					"JobLog": "",
					"JobLogDesc": "",
					"Sdate": null,
					"ServiceDesc": "",
					"Surcharge": "0.000",
					"TotNetValue": "0.000",
					"TotalAmount": "0.000",
					"TotalQty": "0.000",
					"Unit": "",
					"UnitPrice": "0.000",
					"ColTotalQty": "0.000",
					"ColTotalAmount": "0.000",
					"ColName": ""
				}

				if (oEvent[i].Mrdate) {
					var Day = months[oEvent[i].Mrdate.getMonth()] + oEvent[i].Mrdate.getDate();
					chartObject[Day] = oEvent[i].TotalQty;
					chartObject.Month = months[oEvent[i].Mrdate.getMonth()];
					chartObject.ColName = months[oEvent[i].Mrdate.getMonth()] + oEvent[i].Mrdate.getDate();
				}

				//chartObjectHdr[Day] = true;
				chartObject.ContRef = oEvent[i].ContRef;
				chartObject.Discounts = oEvent[i].Discounts;
				chartObject.Docno = oEvent[i].Docno;
				chartObject.GrandTotal = oEvent[i].GrandTotal;
				chartObject.Jlstatus = oEvent[i].Jlstatus;
				chartObject.JobLog = oEvent[i].JobLog;
				chartObject.JobLogDesc = oEvent[i].JobLogDesc;
				chartObject.Sdate = oEvent[i].Sdate;
				chartObject.ServiceDesc = oEvent[i].ServiceDesc;
				chartObject.Surcharge = oEvent[i].Surcharge;
				chartObject.TotNetValue = oEvent[i].TotNetValue;
				chartObject.TotalAmount = oEvent[i].TotalAmount;
				chartObject.TotalQty = oEvent[i].TotalQty;
				chartObject.Unit = oEvent[i].Unit;
				chartObject.UnitPrice = oEvent[i].UnitPrice;
				chartObject.Currency = oEvent[i].Currency;

				chartObject.Qty = oEvent[i].TotalQty;
				chartObject.Amount = oEvent[i].TotalAmount;
				chartObject.StartDate = oEvent[i].StartDate;
				chartObject.StartTime = oEvent[i].StartTime;
				chartObject.EndDate = oEvent[i].EndDate;
				chartObject.EndTime = oEvent[i].EndTime;
				chartObject.MrDate = oEvent[i].Mrdate;
				chartObject.MrEndDate = oEvent[i].MrEndDate;

				chartObject.Zeile = oEvent[i].Zeile;
				chartObject.JobId = oEvent[i].JobId;
				summaryArray.push(chartObject);

				finalSummaryArray.push(chartObject);

			}

			oLSSummaryModel.setProperty("/aUniqueColumns", finalSummaryArray);
			oLSSummaryModel.setProperty("/aRows", finalSummaryArray);

			var uniqueArray = summaryArray.reduce((filter, current) => {
				var dk = filter.find(item => (item.Zeile === current.Zeile && item.JobId === current.JobId));
				if (!dk) {
					return filter.concat([current]);
				} else {

					var TotalQty = parseFloat(dk.TotalQty);
					var Qty = parseFloat(dk.Qty);
					TotalQty += parseFloat(current.TotalQty);
					var TotalAmount = parseFloat(dk.TotalAmount);
					TotalAmount += parseFloat(current.TotalAmount);
					/*var Day = 0;
					for(var j=1;j<=31;j++){
					   
					}*/
					var value = current.ColName;
					Day = this.numberfunction(dk[value]);
					Day += this.numberfunction(current[value]);
					dk[value] = (Day).toFixed(2);
					/*if(this.formatStringDateAramco(current.MrDate) === this.formatStringDateAramco(current.EndDate)){
						dk.Qty = (Day).toFixed(2);
					}*/
					dk.Qty = (Qty).toFixed(2);
					/*dk.TotalQty = (TotalQty).toFixed(2);*/
					dk.TotalQty = (TotalQty).toFixed(3);
					dk.TotalAmount = (TotalAmount).toFixed(2);
					return filter;
				}
			}, []);

			var ColoumnUniqueArray = summaryArray.reduce((filter, current) => {
				var cdk = filter.find(item => (item.Zeile === current.Zeile && item.JobId === current.JobId && item.ColName === current.ColName));
				if (!cdk) {
					return filter.concat([current]);
				} else {
					return filter;
				}
			}, []);

			//oLSSummaryModel.setProperty("/aUniqueColumns", ColoumnUniqueArray);
			//oLSSummaryModel.setProperty("/aRows", ColoumnUniqueArray);

			this.aUniqueSummaryColomns = ColoumnUniqueArray;
			console.log(ColoumnUniqueArray)
				//console.log(chartObjectHdr);
				//chartObjectHdr.TableData = uniqueArray;
				/*			this.getView().getModel("oSummaryReportModelPerDay").setData(null);
							this.getView().getModel("oSummaryReportModelPerDay").setData(uniqueArray);
							this.getView().getModel("oSummaryReportModelPerDay").refresh(true);*/

			//oLSSummaryModel.setProperty("/aRows",uniqueArray);
			/*
						var total = this.totalSummaryCost(uniqueArray);

						var userInfoModel = this.getView().getModel("UserInfoModel");*/

		},

		totalSummaryCost: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						total += parseFloat(cost[i].TotalAmount)
					}
					total = (total).toFixed(2);
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		numberfunction: function (sValue) {
			if (parseFloat(sValue)) {
				return parseFloat(sValue);
			} else {
				return 0;
			}
		},

		// JobLog Model 
		_getData: function () {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			var oItemsModel = this.getView().getModel("itemsModel").getData();
			var oFilter = [new sap.ui.model.Filter("Docno", "EQ", oItemsModel.Docno),
				new sap.ui.model.Filter("Mjahr", "EQ", oItemsModel.Mjahr),
				new sap.ui.model.Filter("LogType", "EQ", 'OPE')
			];

			var oModel = this.getView().getModel("oDataModel");
			var params = "/JobLogOpeSet";
			oModel.read(params, {
				filters: oFilter,
				success: function (oData) {
					oData = oData.results;
					var Inbox = 0;
					var Submitted = 0;
					var Approved = 0;
					var Rejected = 0;
					var All = 0;

					for (var i = 0; i < oData.length; i++) {
						if (oData[i].VendorDel === "") {
							switch (oData[i].Status) {
							case "SUBT":
								Inbox += parseInt(1)
								break;
							case "APRV":
								Approved += parseInt(1)
								break;
							case "REJC":
								Rejected += parseInt(1)
								break;
							default:
								break;
							}
						}
					}
					this.getView().getModel("JobLogModelPDF").setProperty("/JobLogOpeSet", oData);
					this.getView().getModel("JobLogModelPDF").setSizeLimit(oData.length);
					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
			return oFilter;
		},

		//Load  TVD Data
		_getDataTvd: function (Docno, Mjahr) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			if (this.Version !== '' && this.Version !== '0' && typeof this.Version !== "undefined") {
				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", Docno),
					new sap.ui.model.Filter("Mjahr", "EQ", Mjahr),
					new sap.ui.model.Filter("LogType", "EQ", 'TVD'),
					new sap.ui.model.Filter("Version", "EQ", this.Version)
				];
			} else {
				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", Docno),
					new sap.ui.model.Filter("Mjahr", "EQ", Mjahr),
					new sap.ui.model.Filter("LogType", "EQ", 'TVD')
				];
			}
			var oModel = this.getView().getModel("oDataModel");
			var params = "/JobLogOpeSet";
			oModel.read(params, {
				filters: oFilter,
				success: function (oData) {
					oData = oData.results;
					var Inbox = 0;
					var Submitted = 0;
					var Approved = 0;

					for (var i = 0; i < oData.length; i++) {
						if (oData[i].VendorDel === "") {
							switch (oData[i].Status) {
							case "SUBT":
								Inbox += parseInt(1)
								break;
							case "APRV":
								Approved += parseInt(1)
								break;
							default:
								break;
							}
						}
					}

					this.getView().getModel("oTVDModel").setData(null);
					this.getView().getModel("oTVDModel").setData(oData);
					this.getView().getModel("oTVDModel").setSizeLimit(oData.length);

					/*this.getView().getModel("countModelTvd").getData().Inbox = Inbox;
					this.getView().getModel("countModelTvd").getData().Submitted = Submitted;
					this.getView().getModel("countModelTvd").getData().Approved = Approved;
					this.getView().getModel("countModelTvd").getData().All = oData.length;
					this.getView().getModel("countModelTvd").refresh(true);*/
					this.getView().getModel("oTVDModel").refresh(true);
					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
		},

		_getJobLogOpeSet: function () {
			var oItemsModel = this.getView().getModel("itemsModel").getData();
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			var oFilter = [new sap.ui.model.Filter("Docno", "EQ", oItemsModel.Docno),
				new sap.ui.model.Filter("Mjahr", "EQ", oItemsModel.Mjahr),
				new sap.ui.model.Filter("LogType", "EQ", 'OPE')
			];

			var oModel = this.getView().getModel("VendorService");
			var params = "/JobLogOpeSet";
			oModel.read(params, {
				filters: oFilter,
				success: function (oData) {
					oData = oData.results;
					var Inbox = 0;
					var Submitted = 0;
					var Approved = 0;

					for (var i = 0; i < oData.length; i++) {
						if (oData[i].VendorDel === "") {
							switch (oData[i].Status) {
							case "INIT":
								Inbox += parseInt(1)
								break;
							case "REJC":
								Inbox += parseInt(1)
								break;
							case "REVS":
								Inbox += parseInt(1)
								break;
							case "RECL":
								Inbox += parseInt(1)
								break;
							case "APRV":
								Approved += parseInt(1)
								break;
							case "SUBT":
								Submitted += parseInt(1)
								break;
							default:
								break;
							}
						}
					}

					this.getView().getModel("jobLog").setData(null);
					this.getView().getModel("jobLog").setData(oData);
					this.getView().getModel("jobLog").setSizeLimit(oData.length);
					this.getView().getModel("jobLog").refresh(true);
					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
		},

		//Load Sensor Offset Data
		_getDataSos: function (Docno, Mjahr) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			if (this.Version !== '' && this.Version !== '0' && typeof this.Version !== "undefined") {
				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", Docno),
					new sap.ui.model.Filter("Mjahr", "EQ", Mjahr),
					new sap.ui.model.Filter("LogType", "EQ", 'SOS'),
					new sap.ui.model.Filter("Version", "EQ", this.Version)
				];
			} else {
				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", Docno),
					new sap.ui.model.Filter("Mjahr", "EQ", Mjahr),
					new sap.ui.model.Filter("LogType", "EQ", 'SOS')
				];
			}
			var oModel = this.getView().getModel("oDataModel");
			var params = "/JobLogOpeSet";
			oModel.read(params, {
				filters: oFilter,
				success: function (oData) {
					oData = oData.results;
					var Inbox = 0;
					var Submitted = 0;
					var Approved = 0;

					for (var i = 0; i < oData.length; i++) {
						if (oData[i].VendorDel === "") {
							switch (oData[i].Status) {
							case "SUBT":
								Inbox += parseInt(1)
								break;
							case "APRV":
								Approved += parseInt(1)
								break;
							default:
								break;
							}
						}
					}
					this.getView().getModel("oSensorOffsetModel").setData(null);
					this.getView().getModel("oSensorOffsetModel").setData(oData);
					this.getView().getModel("oSensorOffsetModel").setSizeLimit(oData.length);
					/*this.getView().getModel("countModelSos").getData().Inbox = Inbox;
					this.getView().getModel("countModelSos").getData().Submitted = Submitted;
					this.getView().getModel("countModelSos").getData().Approved = Approved;
					this.getView().getModel("countModelSos").getData().All = oData.length;
					this.getView().getModel("countModelSos").refresh(true);*/
					this.getView().getModel("oSensorOffsetModel").refresh(true);

					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
		},

		_onFilterPress: function () {
			if (DrssNo !== "") {
				var oDocFilter = new sap.ui.model.Filter("Docno", "EQ", DrssNo);
				aFilter.push(oDocFilter);
			}

			for (var i = 0; i < JobLogStatus.length; i++) {
				aFilter.push(new sap.ui.model.Filter("Jlstatus", "EQ", JobLogStatus[i]));
			}

			for (var i = 0; i < JobLogType.length; i++) {
				aFilter.push(new sap.ui.model.Filter("JobLog", "EQ", JobLogType[i]));
			}
			return oFilter;
		},

		onConsolidatedPdfAll: function (oEvent) {
			var doc = {
				pageSize: "A3",
				pageOrientation: "landscape",
				pageMargins: [30, 5, 30, 30],
				content: [],
				border: [false, false, false, true],

				styles: {
					tiny: {
						fontSize: 8
					},
					small: {
						fontSize: 8
					},
					medium: {
						fontSize: 8
					},
					headerLabel: {
						fontSize: 11,
						bold: true,
						alignment: 'right',
						border: [false, false, false, false]
					},
					sectionTitle: {
						fontSize: 18,
						bold: true,
						alignment: 'center',
						margin: [0, 10, 0, 10]

					},
					subheader: {
						fontSize: 16,
						bold: true,
						margin: [0, 5, 0, 5]
					},
					pageTitle: {
						fontSize: 18,
						bold: true,
						color: '#0033a0',
						alignment: 'center',
						margin: [0, 10, 0, 10]
					}
				}
			};

			var oETicketModel = this.getOwnerComponent().getModel("oCompETicketModel");
			var itemsModel = this.getView().getModel("itemsModel").getData();
			if (itemsModel.Rqstat !== "ETKT" && itemsModel.Rqstat !== "ETRE" && itemsModel.Rqstat !== "ETKR" || oETicketModel.getData().Version ==
				'0') {
				if (typeof oETicketModel !== "undefined") {
					var oETKTData = oETicketModel.getData();
					if (oETKTData.HeaderToItemNav.length > 0) {
						this._oGetPdfHeader(doc, "");
						//  this._pdfHeaderLogo(doc,"");
						doc.content.push({
							text: 'eTicket Report - Version : ' + oETKTData.Version,
							style: 'pageTitle'
						});
						// doc.content.push(this._getETicketReportHeader("Ven_ETicket_header"));
						doc.content.push(this._getETicketReport(oETKTData, "after"));
					}
				}
			}

			var oJobLogModel = this.getView().getModel("oSummaryReportModelDetail").getData();
			var filteredData = this._getFilteredTypeData(oJobLogModel);
			if (typeof filteredData !== "undefined") {
				this.getTimeSheetPDF('JL0001', doc, "Equipment", filteredData);
				this.getTimeSheetPDF('JL0003', doc, "Personnel", filteredData);
				this.getTimeSheetPDF('JL0007', doc, "Crew", filteredData);
				this.getTimeSheetPDF('JL0004', doc, "Services", filteredData);
			}
			//-------------------------------------------------------------

			var oJobLogData = this.getView().getModel("jobLog").getData();
			var f4Model = this.getView().getModel("F4Models").getData();
			var oJobLogData = oJobLogData.filter((element, index) => {
				return element.VendorDel !== 'X'
			});
			var oJobLogData = oJobLogData.sort(function (a, b) {
				return a.FrDate - b.FrDate
			});
			if (oJobLogData.length > 0) {
				console.log(oJobLogData.length);
				this._oGetPdfHeader(doc, "");
				doc.content.push({
					text: 'Operational Report',
					style: 'pageTitle'
				});
				doc.content.push(this._onOperationsReport(doc, "pageTitle"));
			}
			// Add Header 
			this._onSummaryReportGeneratePdf(doc);

			this._onOCDetailReportGenerate(doc);

			var oTVDModel = this.getView().getModel("oTVDModel").getData();
			if (oTVDModel.length > 0) {
				console.log(oTVDModel.length);
				this._oGetPdfHeader(doc, "");
				doc.content.push({
					text: 'TVD',
					style: 'pageTitle'
				});
				doc.content.push(this.getTVDReport(oTVDModel, 'Tvd'));
			}
			var oSOSModel = this.getView().getModel("oSensorOffsetModel").getData();
			if (oSOSModel.length > 0) {
				this._oGetPdfHeader(doc, "");
				doc.content.push({
					text: 'Sensor Offset',
					style: 'pageTitle'
				});
				doc.content.push(this.getTVDReport(oSOSModel, 'Sos'));
			}
			var oSaudizationModel = this.getOwnerComponent().getModel("oSaudizationModel");
			if (oSaudizationModel) {
				if (oSaudizationModel.getData().length > 0) {
					this._oGetPdfHeader(doc, "");
					doc.content.push({
						text: 'Saudization Details',
						style: 'sectionTitle'
					});
					doc.content.push(this.getSaudizationReport(oSaudizationModel));
				}
			}
			var oJobLogModel = this.getView().getModel("JobLogModelPDF");
			var oDocNo = oJobLogModel.getData()['Docno'];
			if (doc.content.length == 0) {
				return;
			}
			var oDocNo = this.getView().getModel("itemsModel").getProperty("/Docno");
			if (doc.content[doc.content.length - 1]) {
				delete doc.content[doc.content.length - 1].pageBreak;
			}

			if (oEvent) {
				pdfMake.createPdf(doc).download(oDocNo + " - Consolidated.pdf");
			}
			/*	  var oETicketModel = this.getView().getModel("oETicketModel").getData();
				  var oContent = pdfMake.createPdf(doc);
				  var oBase = oContent.getBase64((data)=>{ this.pdfBase = data });
			      oETicketModel.JoblogForm = this.pdfBase;*/
			//   var oETicketModel = this.getView().getModel("oETicketModel").getData();
			if (controller.oForemanPdf === "X") {
				controller.base64 = "";
				pdfMake.createPdf(doc).getBase64(
					function (encodedString) {
						controller.ForemanBase64 = encodedString;
						/*    oETicketModel.JoblogForm =this.base64;
						    this.getView().getModel("oETicketModel").refresh(true);*/
						//  console.log(this.base64); // this.base64 refers to var on the top
					}.bind(this) // To bind the callback with the actual context
				);
			} else {
				controller.base64 = "";
				pdfMake.createPdf(doc).getBase64(
					function (encodedString) {
						controller.VendorBase64 = encodedString;
					}.bind(this)
				);
			}
			controller.oForemanPdf = "";
		},

		_getFilteredTypeData: function (aSummaryDetailsData) {
			if (aSummaryDetailsData.length && aSummaryDetailsData.length > 0) {
				var aTransprtations = aSummaryDetailsData.filter(x => x.JobLog === "JL0002");
				var aOthers = aSummaryDetailsData.filter(x => x.JobLog !== "JL0002");
				var sortedSDData = $.merge(aTransprtations, aOthers);
				var aJobLogTypesBasedStructure = [];
				sortedSDData.forEach(e => {
					if (!aJobLogTypesBasedStructure.find(x => x.JobLog === e.JobLog)) {
						aJobLogTypesBasedStructure.push({
							JobLog: e.JobLog,
							JobLogDesc: e.JobLogDesc,
							content: [],
							bIsGrouping: true,
							Jlstatus: "empty"
						});
					}
				});
				for (var i = 0; i < aJobLogTypesBasedStructure.length; i++) {
					sortedSDData.forEach(e => {
						if (aJobLogTypesBasedStructure[i].JobLog === e.JobLog) {
							aJobLogTypesBasedStructure[i].content.push(e);
						}
					});
				}
				return aJobLogTypesBasedStructure;
			}

		},

		_onOCDetailReportGenerate: function (doc) {
			var aJobLogModel = this.getView().getModel("oSummaryReportModelDetail").getData();
			if (aJobLogModel.length == 0) {
				return;
			}
			var oJobLogModel = aJobLogModel.sort(function (a, b) {
				return a.Mrdate - b.Mrdate
			});
			var arr = oJobLogModel;
			var res = [];
			var map = {};
			arr.forEach(item => {
				var temp = {};
				if (!map[item.Mrdate]) {
					map[item.Mrdate] = [];
					temp[item.Mrdate] = map[item.Mrdate];
					res.push(temp);
				};
				map[item.Mrdate].push(item);
			});
			var aHier = [];
			for (var ind in res) {
				for (var InnerInd in res[ind]) {
					aHier.push(res[ind][InnerInd]);
				}
			}
			$.each(aHier, function (ind, obj) {
				var oPersonalFilter = obj.filter(item => {
					return item
				});
				if (oPersonalFilter.length > 0) {
					var cDate = this.formatStringDateAramco(obj[0].Mrdate);
					if (typeof cDate == "undefined") {
						cDate = "";
					}
					var oSelectedStatus = ['JL0001', 'JL0002', 'JL0003', 'JL0004', 'JL0005', 'JL0006', 'JL0007', 'OT0001', 'OT0002', 'OT0003',
						'OT0004'
					];
					this.oFilteredStatusData = [];
					for (var ind in oSelectedStatus) {
						var aRecords = oPersonalFilter.filter(oItem => oItem.JobLog === oSelectedStatus[ind])
						this.oFilteredStatusData = this.oFilteredStatusData.concat(aRecords);
					}
					console.log(this.oFilteredStatusData);
					this.oFilteredStatusData = this.oFilteredStatusData.filter(oItem => oItem.Jlstatus === "APRV");
					var oSummaryReportData = this.oFilteredStatusData;
					if (oSummaryReportData.length > 0) {
						if (ind === 0) {
							this._oGetPdfHeader(doc, "");
						}
						doc.content.push({
							text: 'Service Logging - Daily Detail' + " - " + cDate,
							style: 'pageTitle'
						});
						this.getDetailedReport(doc, oSummaryReportData);
					}
				}

			}.bind(this))
		},

		convertoPdf: function () {
			var oBase64 = controller.pdfBase
			const linkSource = `data:application/pdf;base64,${oBase64}`;
			//const linkSource =  "data:application/pdf;base64" +oBase64;
			const downloadLink = document.createElement("a");
			const fileName = "Consolidated.pdf";
			downloadLink.href = linkSource;
			downloadLink.download = fileName;
			downloadLink.click();
		},

		_getTimesheetRData: function (aJobLogModel) {
			var aTSData = this.getView().getModel("oTSModel").getData();
			var oJobLogModel = [];
			if (aTSData.length > 0) {
				$.each(aJobLogModel, function (ind, obj) {
					var aFilteredTS = aTSData.filter(oLineItemsData => {
						return obj.Docno === oLineItemsData.Docno &&
							obj.Mjahr === oLineItemsData.Mjahr &&
							obj.Zeile === oLineItemsData.Zeile &&
							obj.JobId === oLineItemsData.JobId &&
							obj.Sno === oLineItemsData.Sno;
					});
					if (aFilteredTS.length == 0) {
						oJobLogModel.push(obj);
					}
				}.bind(this))

			}

			return oJobLogModel;
		},

		formatStringDateAramco: function (oStrDate) {
			if (oStrDate instanceof Date) {
				//var sDate = oStrDate.toJSON();
				//var sDate = oStrDate.toString();
				var sFinalDate = (oStrDate.getMonth() + 1) + "/" + oStrDate.getDate() + "/" + oStrDate.getFullYear();

				return sFinalDate;
			} else if ((oStrDate === null) || (oStrDate === 'undefined') || (oStrDate === undefined)) {
				// Do Nothing
			} else {
				var st = oStrDate.split("T");
				var oVal = st[0];
				return oVal.substr(5, 2) + "/" + oVal.substr(8, 2) + "/" + oVal.substr(0, 4);
			}
		},
		_getFixedFields: function () {
			var aFixedFields = [];
			aFixedFields.push({
				"Fieldname": "ContRef",
				"FieldDesc": "Contract Ref No",
				"Source": "ContRef",
				"Width": 10,
				"Seqno": "000"
			});
			aFixedFields.push({
				"Fieldname": "AppBy",
				"FieldDesc": "App/Rej By",
				"Source": "ApprBy",
				"Width": 10,
				"Seqno": "999"
			});
			aFixedFields.push({
				"Fieldname": "AppDate",
				"FieldDesc": "App/Rej Date",
				"Source": "ApprDat",
				"Width": 10,
				"Seqno": "999"
			});
			aFixedFields.push({
				"Fieldname": "AppTime",
				"FieldDesc": "App/Rej Time",
				"Source": "ApprTim",
				"Width": 10,
				"Seqno": "999"
			});
			aFixedFields.push({
				"Fieldname": "Jlstatus",
				"FieldDesc": "Status",
				"Source": "Jlstatus",
				"Width": 6,
				"Seqno": "999"
			});
			/*	// Added  for Morning Report
            aFixedFields.push({ "Fieldname": "MrDate", "FieldDesc": "MR Date","Source": "MrDate","Width": 10,"Seqno": "999"});
			aFixedFields.push({ "Fieldname": "MrEndDate", "FieldDesc": "MR End Date","Source": "MrEndDate","Width": 10,"Seqno": "999"});*/
			//	aFixedFields.push({ "Fieldname": "Currency", "FieldDesc": "Currency","Source": "ApprDat","Width": 10,"Seqno": "999"});

			return aFixedFields;

		},

		_populateTimesheet: function (oBody, oLineItemsData, iRowLength) {

			var aTSData = this.getView().getModel("oTSModel").getData();
			var aFilteredTS = aTSData.filter(obj => {
				return obj.Docno === oLineItemsData.Docno &&
					obj.Mjahr === oLineItemsData.Mjahr &&
					obj.Zeile === oLineItemsData.Zeile &&
					obj.JobId === oLineItemsData.JobId &&
					obj.Sno === oLineItemsData.Sno;
			});
			// this.TimeSheetData = oData;
			//	var oTSTable = this.timesheetDataObjectDisplay(aFilteredTS);
			if (aFilteredTS.length > 0) {

				oBody.push(this.getPDFCrewTimeSheet(oLineItemsData, aFilteredTS, iRowLength));
			}

		},

		getPDFCrewTimeSheet: function (oLineItemData, aTimesheetRecords, iRowLength) {

			var months = ["Jan'", "Feb'", "Mar'", "Apr'", "May'", "Jun'", "Jul'", "Aug'", "Sept'", "Oct'", "Nov'", "Dec'"];
			//var months = [ "01/", "02/", "03/", "04/", "05/", "06/","07/", "08/", "09/", "10/", "11/", "12/" ];
			var oTempRecord;
			var aColoumnUniqueArray = [];
			var aColumnsWidth = [];
			var aRowUniqueArray = [];
			var aColumnObjectArray = [];
			var aRowUniqueObjectArray = [];
			var iColumnCount;
			var sTempColName;
			var oTempCol;
			var sDay, sMonth, sYear, sID, sDate;
			for (var x = 0; x < aTimesheetRecords.length; x++) {
				oTempRecord = aTimesheetRecords[x];
				sTempColName = "";

				if (oTempRecord.TsDate) {
					sDay = oTempRecord.TsDate.getDate();
					sMonth = oTempRecord.TsDate.getMonth();
					sYear = oTempRecord.TsDate.getFullYear();
					sDate = this.formatStringDateAramco(oTempRecord.TsDate);

					sID = oTempRecord.Id;
					oTempCol = {
						day: sDay,
						month: sMonth,
						year: sYear,
						date: sDate,
						colName: months[oTempRecord.TsDate.getMonth()] + oTempRecord.TsDate.getDate()
					};
				}

				//chartObjectHdr[Day] = true;
				if (!aColoumnUniqueArray.includes(oTempCol.colName)) {
					aColoumnUniqueArray.push(oTempCol.colName);
					aColumnObjectArray.push(oTempCol);
				}

				if (!aRowUniqueArray.includes(oTempRecord.Id)) {
					aRowUniqueArray.push(oTempRecord.Id);
					aRowUniqueObjectArray.push(oTempRecord);
				}

			}
			var oSummaryReportData = aTimesheetRecords;
			var aColomns = [];
			var sHeaderBGColor = "#84bd00";

			if (oLineItemData.JobLog === "JL0001") {
				aColomns.push({
					text: "Equipment No",
					bold: true,
					fillColor: sHeaderBGColor,
					alignment: 'center',
					style: 'small'
				});
			} else {
				aColomns.push({
					text: "ID",
					bold: true,
					fillColor: sHeaderBGColor,
					alignment: 'center',
					style: 'small'
				});
				aColomns.push({
					text: "Name",
					bold: true,
					fillColor: sHeaderBGColor,
					alignment: 'center',
					style: 'small'
				});
				aColomns.push({
					text: "Job Title",
					bold: true,
					fillColor: sHeaderBGColor,
					alignment: 'center',
					style: 'small'
				});
			}
			// aColomns.push({ text: "UOM", bold: true ,fillColor: '#0040ff',color:"#ffffff" , alignment: 'center'});
			//var aColoumnUniqueArray = this.aUniqueSummaryColomns ;
			for (var j = 0; j < aColumnObjectArray.length; j++) {
				aColomns.push({
					text: aColumnObjectArray[j].colName,
					bold: true,
					fillColor: sHeaderBGColor,
					alignment: 'center',
					style: 'small'
				});
			}

			aColomns.push({
				text: "Reference ID",
				bold: true,
				fillColor: sHeaderBGColor,
				alignment: 'center',
				style: 'small'
			});

			var oBody = [aColomns];
			var aColumnsWidth = [];
			var iColumnCount = aColoumnUniqueArray.length;

			var oType = new sap.ui.model.odata.type.DateTime({
				pattern: "MM/dd/yyyy"
			});

			//var oParentTableRow =  this.getView().getModel("JobLogPopUpModel").getData()['nodes'][0];
			/*var oList = this.getView().getModel("TimesheetModels").getBindings()[0]['oList'];
			var oReportData = oList;*/

			var oReportData = aTimesheetRecords;

			// IDs
			for (var x = 0; x < aRowUniqueObjectArray.length; x++) {
				var aRow = [];

				if (oLineItemData.JobLog === "JL0001") {
					aRow.push({
						text: aRowUniqueObjectArray[x].Id,
						style: 'small'
					});
				} else {
					aRow.push({
						text: aRowUniqueObjectArray[x].Id,
						style: 'small'
					});
					aRow.push({
						text: aRowUniqueObjectArray[x].Name,
						style: 'small'
					});
					aRow.push({
						text: aRowUniqueObjectArray[x].JobTitle,
						style: 'small'
					});
				}
				//loop through all the unique colomns (Dates)
				for (var y = 0; y < aColumnObjectArray.length; y++) {
					//look for data that matches date and value
					for (var z = 0; z < oReportData.length; z++) {
						if (oReportData[z].Id === aRowUniqueObjectArray[x].Id && this.formatStringDateAramco(oReportData[z].TsDate) ===
							aColumnObjectArray[y].date) {
							aRow.push({
								text: oReportData[z].Duration,
								style: 'small'
							});
						}
					}
				}

				var oIdGrp = aRowUniqueObjectArray[x].IdGroup;
				if (oIdGrp == '9999999999' || oIdGrp == aRowUniqueObjectArray[x].Id) {
					oIdGrp = '';
				}
				aRow.push({
					text: oIdGrp,
					style: 'small'
				});
				oBody.push(aRow);

			}

			aColumnsWidth.push("*");
			aColumnsWidth.push("*");
			aColumnsWidth.push("*");

			for (var j = 0; j < (iColumnCount); j++) {
				aColumnsWidth.push(22);
			}
			aColumnsWidth.push(100);
			/*return [
				
				{
				colSpan : iRowLength,
				margin: [5, 10, 5, 5],
				table: {
					headerRows: 1,
					widths: aColumnsWidth,
					body: oBody
				}
			}]*/
			return [{
				stack: [{
					text: "Timesheet",
					bold: true,
					alignment: 'center',
					fontSize: 11
				}, {
					table: {
						headerRows: 1,
						widths: aColumnsWidth,
						body: oBody
					}
				}],
				colSpan: iRowLength,
				margin: [0, 10, 0, 0]
			}];

		},
		////////////////////// end of detail pdf   /////////////

		getTVDReport: function (oTVDModel, oTabSelKey) {
			//var oTVDModel = this.getView().getModel("oTVDModel").getData();
			var aColomns = [{
				text: "SNo",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			}];
			aColomns.push({
				text: "Status",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Start Date",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Section/Lateral",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Run Number",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});

			if (oTabSelKey === "Tvd") {
				aColomns.push({
					text: "MD",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
				aColomns.push({
					text: "TVD",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
				aColomns.push({
					text: "Drilled Footage",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});

			} else {
				aColomns.push({
					text: "Sensor",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
				aColomns.push({
					text: "Offset From Bit",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
			}

			aColomns.push({
				text: "Classification",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "BHA#",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			if (oTabSelKey === "Tvd") {
				aColomns.push({
					text: "Previous Section MD",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
				aColomns.push({
					text: "Previous Section TVD",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
			}
			aColomns.push({
				text: "Action By",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Foreman Comments",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			var oBody = [
				aColomns
			];
			var aColumnsWidth = [];
			var oTableItems = oTVDModel;
			for (var oItem = 0; oItem < oTableItems.length; oItem++) {
				var aRow = [];
				aRow.push({
					text: oTableItems[oItem]['Seqno'],
					style: 'small',
					alignment: 'left'
				});
				aRow.push({
					text: oTableItems[oItem]['StatusText'],
					style: 'small',
					alignment: 'center'
				});
				//	aRow.push({ text: oTableItems[oItem]['FrDate'], style: 'small', alignment: 'left' });
				if (oTableItems[oItem].FrDate !== null && typeof oTableItems[oItem].FrDate !== "undefined") {
					var sSDateSplit = oTableItems[oItem].FrDate.toLocaleString('fr', {
						hour12: false
					}).split(' ');
					aRow.push({
						text: this.dateMonthFormat(sSDateSplit[0]),
						style: 'small',
						alignment: 'left'
					});

				} else {
					aRow.push({
						text: oTableItems[oItem].FrDate,
						style: 'small',
						alignment: 'left'
					});
				}
				aRow.push({
					text: oTableItems[oItem]['HoleSize'],
					style: 'small',
					alignment: 'left'
				});
				aRow.push({
					text: oTableItems[oItem]['RunNo'],
					style: 'small',
					alignment: 'left'
				});

				if (oTabSelKey === "Tvd") {
					aRow.push({
						text: oTableItems[oItem]['Md'],
						style: 'small',
						alignment: 'left'
					});
					aRow.push({
						text: oTableItems[oItem]['Tvd'],
						style: 'small',
						alignment: 'left'
					});
					aRow.push({
						text: oTableItems[oItem]['DrillFtg'],
						style: 'small',
						alignment: 'left'
					});
				} else {
					aRow.push({
						text: oTableItems[oItem]['Sensor'],
						style: 'small',
						alignment: 'left'
					});
					aRow.push({
						text: oTableItems[oItem]['Soffset'],
						style: 'small',
						alignment: 'left'
					});
				}

				aRow.push({
					text: oTableItems[oItem]['Classification'],
					style: 'small',
					alignment: 'left'
				});
				aRow.push({
					text: oTableItems[oItem]['Bha'],
					style: 'small',
					alignment: 'left'
				});
				if (oTabSelKey === "Tvd") {
					aRow.push({
						text: oTableItems[oItem]['PrevMd'],
						style: 'small',
						alignment: 'left'
					});
					aRow.push({
						text: oTableItems[oItem]['PrevTvd'],
						style: 'small',
						alignment: 'left'
					});
				}
				aRow.push({
					text: oTableItems[oItem]['ActionBy'],
					style: 'small',
					alignment: 'left'
				});
				aRow.push({
					text: oTableItems[oItem]['RejCmnt'],
					style: 'small',
					alignment: 'left'
				});
				// comments
				oBody.push(aRow);
			}

			aColumnsWidth.push(30);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(150);

			if (oTabSelKey === "Tvd") {
				return {
					table: {
						headerRows: 1,
						body: oBody,
						widths: aColumnsWidth,
					},
					pageBreak: 'after'
				}
			} else {
				return {
					table: {
						headerRows: 1,
						body: oBody

					},
					pageBreak: 'after'

				}
			}

		},

		getSaudizationReport: function (oSaudizationModel) {
			oSaudizationModel = oSaudizationModel.getData();
			//var oTVDModel = this.getView().getModel("oTVDModel").getData();
			var aColomns = [{
				text: "Year",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			}];
			aColomns.push({
				text: "Month",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Saudi Employees",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Total Employees",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Saudi%",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});

			var oBody = [
				aColomns
			];
			var aColumnsWidth = [];
			var oTableItems = oSaudizationModel;
			for (var oItem = 0; oItem < oTableItems.length; oItem++) {
				var aRow = [];
				aRow.push({
					text: oTableItems[oItem]['Zyear'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['Zmonth'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['SaudiTot'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['ManpowerTot'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['SaudizationPer'],
					style: 'small',
					alignment: 'center'
				});
				oBody.push(aRow);
			}
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			return {
				table: {
					headerRows: 1,
					widths: aColumnsWidth,
					body: oBody
				},
				pageBreak: 'after'
			}
		},

		onPressRequestForCancellation: function (oEvent) {
			var oTextArea = new sap.m.TextArea({
				width: "100%",
				placeholder: "Remarks (required)",
				liveChange: function (oEvent) {
					this.sText = oEvent.getParameter("value");
					this.oSubmitDialog.getBeginButton().setEnabled(this.sText.length > 0);
				}.bind(this)
			});
			this.oSubmitDialog = new sap.m.Dialog({
				type: sap.m.DialogType.Message,
				title: "Confirm",
				content: [
					new sap.m.Label({
						text: "Do you want to continue ?",
						labelFor: "submissionNote"
					}),
					oTextArea
				],
				beginButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: "Submit",
					enabled: false,
					press: function (evt) {
						this.applyRequestForCancellation(oTextArea.getProperty("value"));
					}.bind(this)
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function () {
						this.oSubmitDialog.close();
					}.bind(this)
				})
			});
			this.oSubmitDialog.open();
		},

		applyRequestForCancellation: function (sComments) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Updating...'
			});
			busyDialog.open();
			var oModel = this.getView().getModel("VendorService");
			oModel.callFunction("/VendorRequest", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr,
					Flag: 'C',
					Comments: sComments
				},
				success: function (oData) {
					busyDialog.close();
					MessageBox.success("Request submitted for cancellation successfully", {
						actions: [MessageBox.Action.CLOSE],
						onClose: function () {
							this.oSubmitDialog.close();
							this.onPageRefresh();
						}.bind(this)
					});

				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		onPressRecallCancellation: function (oEvent) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Updating...'
			});
			busyDialog.open();
			var oModel = this.getView().getModel("VendorService");
			oModel.callFunction("/VendorRequest", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr,
					Flag: 'R',
					Comments: ''
				},
				success: function (oData) {
					busyDialog.close();
					MessageBox.success("Request for cancellation recalled successfully", {
						actions: [MessageBox.Action.CLOSE],
						onClose: function () {
							this.onPageRefresh();
						}.bind(this)
					});

				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		/*	formateReqForCancellationBtn: function (bReqReject, sCancel) {
				return ( bReqReject !== 'X' && sCancel === true);
			},
			formateRecallCancellationBtn: function (bReqReject, sCancel) {
				return ( bReqReject === 'X' && sCancel === true);
			}*/

	});
});