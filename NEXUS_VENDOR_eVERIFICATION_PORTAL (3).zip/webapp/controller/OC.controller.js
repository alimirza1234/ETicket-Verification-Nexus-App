var controller;
sap.ui.define([
	"./BaseController",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"zdwo_nx_drss_ven/model/formatter",
	"sap/ui/core/Fragment",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	"sap/m/MessageToast",
	'sap/ui/core/Core',
	"zdwo_nx_drss_ven/model/SrvTreeConversion",
	"sap/m/MessageBox",
	"zdwo_nx_drss_ven/utils/POContractSelector",
	"zdwo_nx_drss_ven/utils/DispatchedServicesSplit",
	"jquery.sap.global",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Label",
	"sap/m/library",
	"zdwo_nx_drss_ven/model/FormatterByReference",
	"sap/m/GroupHeaderListItem",
	"zdwo_nx_drss_ven/lib/cdnjs/vfs_fonts",

], function (
	BaseController,
	History,
	JSONModel,
	formatter,
	Fragment,
	Filter,
	FilterOperator,
	MessageToast,
	Core,
	SrvTreeConversion,
	MessageBox,
	POContractSelector,
	DispatchedServicesSplit,
	jQuery,
	Dialog,
	Button,
	Label,
	mobileLibrary,
	FormatterByReference, GroupHeaderListItem) {
	"use strict";
	// shortcut for sap.m.ButtonType
	var ButtonType = mobileLibrary.ButtonType;

	// shortcut for sap.m.DialogType
	var DialogType = mobileLibrary.DialogType;
	var oPreviousComments;
	return BaseController.extend("zdwo_nx_drss_ven.controller.OC", {
		formatter: formatter,
		jobLoggingitem: [],
		SrvHdrToItemsNav: [],
		JoblogToSerListNav: [],
		DetailObj: {},

		onInit: function () {

			controller = this;
			this.selectedcontxtForUOM = "";
			this.serviceCount = 0;
			this.oAttachments = [];
			this.selectedItem = "";
			this.SrvTreeConversion = SrvTreeConversion;
			this.itemDetails = '';
			this.headerColumnsData = "";
			this.AttachLevel = "";
			this.onUploadChange = "";
			this.itemsObj = "";
			this.Catog = "";
			this.itemValue = "";
			this.sSelectedReason = true;
			controller.oETicktClose = true;
			this.sWrkflwBtnTxt = "";
			this.oRejReasonText = "";
			this.searchField = this.getView().byId("searchfield");
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("OC").attachPatternMatched(this._onObjectMatched, this);

			var EmployeeData = [{
				"Name": "Ali",
				"Role": "SapUI5",
				"Skills": "JavaScript"
			}, {
				"Name": "SM",
				"Role": "SapUI5",
				"Skills": "JavaScript!!"
			}];

			var EmployeeDataModel = new JSONModel();
			this.getView().setModel(EmployeeDataModel, "EmployeeDataModel");
			this.getView().getModel("EmployeeDataModel").setData(EmployeeData);

			var oPOModel = new JSONModel();
			this.getView().setModel(oPOModel, "oPOModel");

			var oServiceModel = new JSONModel();
			this.getView().setModel(oServiceModel, "oServiceModel");

			var oETicketModel = new JSONModel();
			// this.getView().setModel(oETicketModel, "oETicketModel");
			sap.ui.getCore().setModel(oETicketModel, "oETicketModel");

			var oMonthlyListModel = new JSONModel();
			this.getView().setModel(oMonthlyListModel, "oMonthlyListModel");

			var oMonthlyListModel = new JSONModel();
			this.getView().setModel(oMonthlyListModel, "oMonthlyListModel");

			// Added for consolidated pdf
			//Store Timesheet Data
			var oTSModel = new JSONModel([]);
			this.getView().setModel(oTSModel, "oTSModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "JobLogModelPDF");

			var oSummaryReportModelDetail = new JSONModel([]);
			this.getView().setModel(oSummaryReportModelDetail, "oSummaryReportModelDetail");

			this.getView().setModel(new sap.ui.model.json.JSONModel([]), "JobLogFinalDataModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "MrDateRelModel");
			this.getView().setModel(new sap.ui.model.json.JSONModel([]), "oTVDModel");
			this.getView().setModel(new sap.ui.model.json.JSONModel([]), "oSensorOffsetModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "TimesheetModels");

			this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "jobLog");

			this.getView().setModel(new JSONModel({

			}), "SelectModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel({
				Editable: true
			}), "JobLogAttachmentEditModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel({
				NetworkId: "",
				Uname: "",
				Mail: "",
				Maxhit: "100"
			}), "SearchModel");

			// this.getView().setModel(new sap.ui.model.json.JSONModel({
			// 	bServicesBusy: true
			// }), "oFlagsModel");

			//Holds LubSum enabled table data
			var aDisplayColumns = [{
					"label": "UoM",
					"keyName": "Unit"
				}

			];
			//if ((this.getView().getModel("UserInfoModel").getProperty("/Foreman") === '') && (this.getView().getModel("UserInfoModel").getProperty("/ForemanClerk") === '')) {
			aDisplayColumns.push({
				"label": "Unit Price",
				"keyName": "UnitPrice"
			});
			aDisplayColumns.push({
				"label": "Currency",
				"keyName": "Currency"
			});
			aDisplayColumns.push({
				"label": "Total Amount",
				"keyName": "Amount"
			});
			var oLSSummaryModel = new JSONModel({
				aUniqueColumns: [],
				aRows: [],
				aDisplayColumns: aDisplayColumns
			}); // display columns will be filled from onAfterRendering based on some conditions
			this.getView().setModel(oLSSummaryModel, "oLSSummaryModel");
			//	this.getView().setModel(new sap.ui.model.json.JSONModel([{}]), "oSaudizationModel");
			//PDF report configuration mapping
			var oPDFMappingModel = new JSONModel();
			this.getView().setModel(oPDFMappingModel, "oPDFMappingModel");

			var data = new JSONModel();
			this.getView().setModel(data, "data");
			this.busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
		},

		downloadpdf: function () {

			var oModel = this.getView().getModel('data'); // adjust this to your actual model
			var aData = oModel.getProperty("/eTicket");

			// Convert the data to a format suitable for PDFMake
			var aTableBody = [];
			aTableBody.push(["Cont. Ref No.", "Run No.", "Service Description", "Quantity", "Unit of Measure", "Currency", "Unit Price",
				"Gross Price"
			]);
			aData.forEach(function (item) {
				aTableBody.push([
					item.ContRef,
					item.RunNo,
					item.ServStext,
					item.Menge,
					item.Meins,
					item.Waers,
					item.Netpr,
					item.Tbtwr
				]);
			});

			return aTableBody;

			var docDefinition = {
				content: [{
					table: {
						headerRows: 1,
						widths: Array(firstTableData[0].length).fill('*'),
						body: firstTableData
					}
				}, {
					text: '',
					pageBreak: 'after'
				}, {
					table: {
						headerRows: 1,
						widths: Array(secondTableData[0].length).fill('*'),
						body: secondTableData
					}
				}]
			};

			pdfMake.createPdf(docDefinition).download('Tables.pdf');

		},
		getFirstTableData: function () {
			debugger;
			var ETicket = {
				title : "E-Ticket Report"
				
			};
			// Assuming the model is set to your table
			var oModel = this.getView().getModel("data"); // adjust this to your actual model
			var aData = oModel.getProperty("/eTicket");

			// Convert the data to a format suitable for PDFMake
			var aTableBody = [];
			// aTableBody.push(ETicket);
			aTableBody.push([{
				text: "Cont. Ref No.",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'

			}, {
				text: "Run No.",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}, {
				text: "Service Description",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}, {
				text: "Quantity",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}, {
				text: "Unit of Measure",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}, {
				text: "Currency",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}, {
				text: "Unit Price",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}, {
				text: "Gross Price",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}]);
			aData.forEach(function (item) {
				aTableBody.push([
					item.ContRef,
					item.RunNo,
					item.ServStext,
					item.Menge,
					item.Meins,
					item.Waers,
					item.Netpr,
					item.Tbtwr
				]);
			});

			return aTableBody;
		},
		getSecondTableData: function () {

			// Assuming the model is set to your table
			var bData = this.getView().getModel("OPRaprItemModel").getData(); // adjust this to your actual model
			// var bData = oModel.getProperty("/");
			// Convert the data to a format suitable for PDFMake
			var bTableBody = [];
			bTableBody.push([{
				text: "Sl.No",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}, {
				text: "Status",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'

			}, {
				text: "CAT",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'

			}, {
				text: "StartDate",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'

			}, {
				text: "StartTime",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}, {
				text: "HoleDepth(Start)",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}, {
				text: "HoleDepth(end)",
				bold: true,
				fillColor: '#0040ff',
				alignment: 'center',
				color: "#ffffff",
				style: 'small'
			}]);
			bData.forEach(function (item) {
				bTableBody.push([
					item.Seqno,
					// Assuming there's a button here, leave empty or put some placeholder text
					item.Status,
					item.CatCodeDesc,
					item.FrDate,
					item.FrTime,
					item.HoleStart,
					item.HoleEnd
				]);
			});
			return bTableBody;

			// var bData = this.getView().getModel("OPRaprItemModel").getData(); // adjust this to your actual model
			// // var bData = oModel.getProperty("/");

			// // Convert the data to a format suitable for PDFMake
			// var bTableBody = [];
			// // bTableBody.push(["Sl.No", "Status", "CAT", "StartDate", "StartTime",
			// // 	"HoleDepth(Start)", "HoleDepth(end)"
			// // ]);
			// var aColomns = [{
			// 	text: "Sl.No",
			// 	bold: true,
			// 	fillColor: '#0040ff',
			// 	alignment: 'center',
			// 	color: "#ffffff",
			// 	style: 'small'
			// }];
			// aColomns.push({
			// 	text: "Status",
			// 	bold: true,
			// 	fillColor: '#0040ff',
			// 	alignment: 'center',
			// 	color: "#ffffff",
			// 	style: 'small'
			// });
			// aColomns.push({
			// 	text: "CAT",
			// 	bold: true,
			// 	fillColor: '#0040ff',
			// 	alignment: 'center',
			// 	color: "#ffffff",
			// 	style: 'small'
			// });
			// aColomns.push({
			// 	text: "StartDate",
			// 	bold: true,
			// 	fillColor: '#0040ff',
			// 	alignment: 'center',
			// 	color: "#ffffff",
			// 	style: 'small'
			// });
			// aColomns.push({
			// 	text: "StartTime",
			// 	bold: true,
			// 	fillColor: '#0040ff',
			// 	alignment: 'center',
			// 	color: "#ffffff",
			// 	style: 'small'
			// });

			// bData.forEach(function (item) {
			// 	aColomns.push([
			// 		item.Seqno,
			// 		// Assuming there's a button here, leave empty or put some placeholder text
			// 		item.Status,
			// 		item.CatCodeDesc,
			// 		item.FrDate,
			// 		item.FrTime,
			// 		item.HoleStart,
			// 		item.HoleEnd
			// 	]);
			// });
			// var oBody = [aColomns];
			// var aColumnsWidth = [];
			// var oTableItems = bData;
			// //	var oTableItems = oTableItems.sort(function(a, b){return a.FrDate- b.ToDate});
			// for (var oItem = 0; oItem < oTableItems.length; oItem++) {
			// 	var aRow = [];
			// 	//Service desc
			// 	aRow.push({
			// 		text: this._getCADACode(oTableItems[oItem].CatCode, "DWCATCD"),
			// 		fillColor: '#eeeeee',
			// 		style: 'small',
			// 		alignment: 'left'
			// 	});
			// 	if (oTableItems[oItem].MajorOp === "" && aMajOperCode.length > 0) {
			// 		// oTableItems[oItem].MajorOp = aMajOperCode[0].Value1;
			// 	}

			// 	aRow.push({
			// 		text: this._getCADACode(oTableItems[oItem].MajorOp, "DWMAJOC"),
			// 		fillColor: '#eeeeee',
			// 		style: 'small',
			// 		alignment: 'left'
			// 	});
			// 	if (oTableItems[oItem].Action === "" && aActionCode.length > 0) {
			// 		//oTableItems[oItem].Action = aActionCode[0].Value1;
			// 	}
			// 	aRow.push({
			// 		text: this._getCADACode(oTableItems[oItem].Action, "DWACODE"),
			// 		fillColor: '#eeeeee',
			// 		style: 'small',
			// 		alignment: 'left'
			// 	});

			// 	if (oTableItems[oItem].Object === "" && aObjectCode.length > 0) {
			// 		// oTableItems[oItem].Object = aObjectCode[0].Value1;
			// 	}
			// 	aRow.push({
			// 		text: this._getCADACode(oTableItems[oItem].Object, "DWOCODE"),
			// 		fillColor: '#eeeeee',
			// 		style: 'small',
			// 		alignment: 'left'
			// 	});

			// 	if (oTableItems[oItem].FrDate !== null) {
			// 		var sSDateSplit = oTableItems[oItem].FrDate.toLocaleString('fr', {
			// 			hour12: false
			// 		}).split(' ');
			// 		aRow.push({
			// 			text: this.dateMonthFormat(sSDateSplit[0]),
			// 			fillColor: '#eeeeee',
			// 			style: 'small',
			// 			alignment: 'left'
			// 		});
			// 	} else {
			// 		aRow.push({
			// 			text: oTableItems[oItem].FrDate,
			// 			fillColor: '#eeeeee',
			// 			style: 'small',
			// 			alignment: 'left'
			// 		});
			// 	}
			// 	aRow.push({
			// 		text: this.timeFormatter(oTableItems[oItem]['FrTime']),
			// 		fillColor: '#eeeeee',
			// 		style: 'small',
			// 		alignment: 'left'
			// 	});
			// 	if (oTableItems[oItem].ToDate !== null) {
			// 		var sEDateSplit = oTableItems[oItem].ToDate.toLocaleString('fr', {
			// 			hour12: false
			// 		}).split(' ');
			// 		aRow.push({
			// 			text: this.dateMonthFormat(sEDateSplit[0]),
			// 			fillColor: '#eeeeee',
			// 			style: 'small',
			// 			alignment: 'left'
			// 		});
			// 	} else {
			// 		aRow.push({
			// 			text: oTableItems[oItem].ToDate,
			// 			fillColor: '#eeeeee',
			// 			style: 'small',
			// 			alignment: 'left'
			// 		});
			// 	}
			// 	aRow.push({
			// 		text: this.timeFormatter(oTableItems[oItem]['ToTime']),
			// 		fillColor: '#eeeeee',
			// 		style: 'small',
			// 		alignment: 'left'
			// 	});
			// 	aRow.push({
			// 		text: oTableItems[oItem]['Duration'],
			// 		fillColor: '#eeeeee',
			// 		style: 'small',
			// 		alignment: 'left'
			// 	});
			// 	aRow.push({
			// 		text: oTableItems[oItem]['Remarks'],
			// 		fillColor: '#eeeeee',
			// 		style: 'small',
			// 		alignment: 'left'
			// 	});
			// 	aRow.push({
			// 		text: this.formatter.JLStatus(oTableItems[oItem]['Status']),
			// 		fillColor: '#eeeeee',
			// 		style: 'small',
			// 		alignment: 'left'
			// 	});
			// 	aRow.push({
			// 		text: oTableItems[oItem]['ActionBy'],
			// 		fillColor: '#eeeeee',
			// 		style: 'small',
			// 		alignment: 'left'
			// 	});
			// 	// comments
			// 	/*if(oTableItems[oItem].VendorDel === ""){
			// 		oBody.push(aRow);
			// 	}*/
			// 	oBody.push(aRow);
			// }

			// aColumnsWidth.push(150);
			// aColumnsWidth.push(60);
			// aColumnsWidth.push(60);
			// aColumnsWidth.push(60);
			// aColumnsWidth.push(60);
			// aColumnsWidth.push(60);
			// aColumnsWidth.push(60);
			// aColumnsWidth.push(60);
			// aColumnsWidth.push(60);
			// aColumnsWidth.push(200);
			// aColumnsWidth.push(60);
			// aColumnsWidth.push(60);
			// return {
			// 	table: {
			// 		headerRows: 1,
			// 		widths: aColumnsWidth,
			// 		body: oBody
			// 	},
			// 	pageBreak: 'after'
			// };

		},

		createPDF: function () {
			debugger;
			// var getData = this.getView().getModel('oETicketModel').getData();
			var oHeader = "";
			// var oSrvtyp = getData.ContractTxt;
			var doc = {
				pageSize: "A2",
				pageOrientation: "landscape",
				pageMargins: [30, 5, 30, 30],
				content: [],
				border: [false, false, false, true],

				styles: {
					tiny: {
						fontSize: 8
					},
					small: {
						fontSize: 8
					},
					medium: {
						fontSize: 8
					},
					smallTitle: {
						fontSize: 8.5,
						border: [false, false, false, false]
					},
					headerLabel: {
						fontSize: 11,
						bold: true,
						alignment: 'right',
						border: [false, false, false, false]
					},
					sectionTitle: {
						fontSize: 18,
						bold: true,
						alignment: 'center',
						margin: [0, 10, 0, 10]

					},
					subheader: {
						fontSize: 16,
						bold: true,
						margin: [0, 5, 0, 5]
					},
					pageTitle: {
						fontSize: 18,
						bold: true,
						color: '#0033a0',
						alignment: 'center',
						margin: [0, 10, 0, 10]
					}
				}
			};
			this._oGetPdfHeader(doc, "");
			// Header for the PDF
			// var aHeaderColomns = [{
			// 	image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAENUAAAeDCAYAAABxxqQsAAAACXBIWXMAAC4jAAAuIwF4pT92AAAgAElEQVR4nOzBAQ0AAADCoPdPbQ8HBAAAAAAAAAAAAAAAAAAAAABXqgEAAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zUgQnAIAwEwHQuEVzGPbqHywjiXt2hpbbC3QTJJ/yxcqM6ZomI4o1u6y2nvunssC3d9Yje4jN1zFP6/9ZyciMAAAAAAAAAAAAAAAAA4B0RcQEAAP//7NwxCsAwCAVQh1y15+jZQum9QuYiFAyBwHurm+LftG1u7TxKv42zxHE67Ce7auQWSyRPMuzmwa7n/Tu/mSM9K3rOAQAAAAAAAAAAAAAAAAB8RMQAAAD//+zcsQnAMAxFQW1mLeNBMlvIXiHgIhiiMo3uKqH61+/vqAYAwKd5XrlCNo/xuuktqy0UcY5jfwhwAAAAAAAAAAAAAAAAAEATEXEDAAD//+zcsQkAIBAEsFvWScW9rCzkbUWQZJBINQCAJ1ofKzeQZ3BLyTYOAccWb0g3AAAAAAAAAAAAAAAAAOATSSYAAAD//+zcoQ0AIBRDwe4/FWyGIoGPh5DcufrqJ6oBAFyxRDSO0AE8tP2xRDdakj6H4AYAAAAAAAAAAAAAAAAAfCTJAAAA///s3MEJACAQA8GUZmt2fiD68S8cMgOBVLGiGgDAEyIafGDsLVdwY54jtgEAAAAAAAAAAAAAAAAADSUpAAAA///s3FEJACAQBbDXzOrazB+RC3AgyBZkUg0AoM2JNEaNCOBTN9go2cZMsiLaAAAAAAAAAAAAAAAAAID3kmwAAAD//+zcsQkAIBRDwewlgnu6zB/NSis7wepuhEDaJ6oBADwR0oBj7B9cQhs1eytTAQAAAAAAAAAAAAAAAMAnSRYAAAD//+zcoQ0AIRAEwOuLfDnUwX8dlEPoiyBAkrzAzYhTpzZZu0Y1AIDfcutrPKBID452V3Lr6++bpz7pFR0AAAAAAAAAAAAAAAAAXBIRAwAA///s3LEJACAMALB+5jVeWvqXKLqLOCaHRKoBAFzrWTMBaDsJAN6sjKZnnZRGsgEAAAAAAAAAAAAAAAAAv0XEAAAA///s3LEJACEABMHrS6zNQr4Z7UwEg88EwWwmufwKWFENAOBoxzSap+CJf2SjJxlrv1q6uwEAAAAAAAAAAAAAAADgUpIJAAD//+zcsQkAIAADwYzmMs4hzibuJYKtjYXVHaTOBi+qAQBciWnAd+Ws1TH3dxfYAAAAAAAAAAAAAAAAAIAHSRYAAAD//+zcsQ0AEABFwb+XmI09TGMz0UkUWsXdCq9/phoAwMVMA77RjsHGHmvMUUuXBwAAAAAAAAAAAAAAAAAekiwAAAD//+zcsQkAIAwEwIyWZZzD4UL2EkFsbS3uRnj48t+pBgBwjeo8I/6UCnxn9zJH9XSwAQAAAAAAAAAAAAAAAAAPEbEAAAD//+zcQQkAIRRAwd9LjGMQcxhGQewlioetsDBT4d2fqQYAcJW5upkG/MZ3sFHPZKPlNOQDAAAAAAAAAAAAAAAAgCciNgAAAP//7NxBDQAgEAOwBa/4wBkPgi7IySC0ErbsuyYLAPhbX3v0tY9DDXhWHWvM2nHtWY0AAAAAAAAAAAAAAAAAkCTJBQAA///s3EEJwDAQBMB9xFUpxEx0lOiomUCIr1KoimZGwh773CtyAIA9tbnqN8b3TAP+42pzvb0eSfp9HsNtAQAAAAAAAAAAAAAAANhSkgcAAP//7NzBCQAgDATBYK/pw858SOpSEKvQmRaW+15THgD+cw81hkMNeNbZeM5aOavLDAAAAAAAAAAAAAAAAMB3ImIDAAD//+zcQQ3AIBQFwXfAVYMcdJDqwMxPCL7qo8xY2Ps21QHgLmMfMw24yxz7zCRvklr9Kf0BAAAAAAAAAAAAAAAA+L0kHwAAAP//7NzBDQAgDAOxiF2ZkwdiL9Q1WnuFSHnesjIAzCGoAaNVWOPUD+z7/AAAAAAAAAAAAAAAAAAAvSX5AAAA///s3EENwCAAA8A+5ooswQxC0IGYkZD54oMKciehfbePigHgfmdA/6kaOMc6ta1/JunjLVMoAAAAAAAAAAAAAAAAAFwnyQYAAP//7NzBCQAgEAPBYK/W6UPsSzj82sAx00JgnxlWBYDeHGoAH9WGuc96nQAAAAAAAAAAAAAAAACAPpJcAAAA///s3DERAAAMA6H3r7oWOudACFINABgm1AAe5BoAAAAAAAAAAAAAAAAA7KkOAAD//+zcMREAAAgDsfpXzcbeES6R8ALeVAMAnjLUAEo71xAOAAAAAAAAAAAAAAAAgPOSDAAAAP//7NxBEQAgCABBolmGHnZjyCUhfOnsRrgAZ6oBAB8y1AAurKw+Wb1FBAAAAAAAAAAAAAAAAOBZETEAAAD//+zcMREAQAjEwJOGs7dOgwSaZ3YlREBMNQDgGEMNYMmbuUYJCgAAAAAAAAAAAAAAAMB3kjQAAAD//+zcMREAMAgEsDeLToZefVVFB7hESKQaALCIUAP4oOvclmsAAAAAAAAAAAAAAAAAMEqSBwAA///s3DERAEAIxMCThrSXToMFimd2JURATDUA4AhDDWBRzVzjiQwAAAAAAAAAAAAAAADAF5I0AAAA///s3EENACAMBLAziw6k7UHwxQcLJAtphVSqAQD/EGoAr82xdt3EBwAAAAAAAAAAAAAAAAD6SnIAAAD//+zcwQ0AMAgDsYzO6FWWQKiyR4B3TlQDAD7Qkbs/Aksa1GhYYxwcAAAAAAAAAAAAAAAAgLOSPAAAAP//7NxRCQAgEETBjWYZcxhO7CUHZhCFmQoL+/lENQDgcyeo0ewIXDbqf/pc/gcAAAAAAAAAAAAAAACA9yTZAAAA///s3MEJAAAIA7HuP7UI7qBCMkR/PVENAHhszuwO7cCW3h9hDQAAAAAAAAAAAAAAAADuSVIAAAD//+zcQQkAAAgDwPUvZTURDKFwV2Gw3+ZUAwCe2hF7yQ84YI419BEAAAAAAAAAAAAAAAAAdyRpAAAA///s3EEJADAMBMGTFme1Xgrx0ARmLOx/TTUAYK+jHTBIvbFGD38AAAAAAAAAAAAAAAAA4K8kFwAA///s3EEJADAMA8CYnY95K/M1qmIr3FkI5Jc41QCAgVad3QN22QGf6V5yrAEAAAAAAAAAAAAAAADAe0kuAAAA///s3DERADAIBMF3jrRYo8EDYWbXwvVnqgEAN5VuwMfezH8AAAAAAAAAAAAAAAAAYEeSBgAA///s3EEJADAMBMEzGx2V1keJr8oIgRkLC/c8pxoAsEy9vpoBCxx7BQAAAAAAAAAAAAAAAMCYJB8AAP//7NxBDQAwDAOxQAuZIa3GazCmSjaF+5+pBgAscuY2STUDlqixBgAAAAAAAAAAAAAAAABfJHkAAAD//+zcwQkAAAjEsNvc1QVxBkFIVui/phoA8IDgAc4AACAASURBVEvpBTwzY42dAgEAAAAAAAAAAAAAAADAjSTNzh2UAADDMACM2fqYt1FfoyYGhTsLgfwSpxoAsETdPjNOlxew0HSXYw0AAAAAAAAAAAAAAAAA/knyAAAA///s3EEJAAAMA7E6n/W5KBQSC/c/Uw0A2HFaAeOMNQAAAAAAAAAAAAAAAADoSPIAAAD//+zcMQ0AMAwEsScbHuVWlVdQdEhkU7j9TDUAYIC67+gELGGsAQAAAAAAAAAAAAAAAMB/SRoAAP//7NwxEQAACAOxOsc6KjrAJRZ+f1MNALhhdAIeMdYAAAAAAAAAAAAAAAAAoCvJAgAA///s3EEJADAMBMEzGx/1VuorKgohzFjY/5pqAMBwdd/RCFjIWAMAAAAAAAAAAAAAAACAf5I0AAAA///s3MEJAAAIA7Fu7upOURBJVrj/mWoAwH2jEfCUsQYAAAAAAAAAAAAAAAAAHUkWAAD//+zcMQ0AMAwEsScbHuVWlVdIdIgim8LtZ6oBAIPVfUcfYDljDQAAAAAAAAAAAAAAAAD+S9IAAAD//+zcMQ0AAAgEsXeGNKxjgoGE1sLtZ6oBALeVPsADLTIAAAAAAAAAAAAAAAAAq5IMAAAA///s3EENACAMBMGTVjPo5NHUFyZ4kDBjYf9rqgEAj1o9laT0AT5Qq2cLDQAAAAAAAAAAAAAAAMA1SQ4AAAD//+zcQQ0AAAgAoeuf2hI+3IQgSDUA4C6hBvCJWAMAAAAAAAAAAAAAAACAPdUAAAD//+zcsQ0AMAgEsd+cjI6YgSYS9grXn6kGAPyrtAGOmbHGEx0AAAAAAAAAAAAAAACAtSQNAAD//+zcQREAIAwDwUirGXQgjsEXIvrpDLsa7ps41QCAgYzKgY/tdW4JAAAAAAAAAAAAAAAAAICWJA8AAP//7NwxDQAACASxd4Z0rCGChYTWwu1nqgEAN5UuwGNtrAEAAAAAAAAAAAAAAADASpIBAAD//+zcMREAAAwCMZzXekV06R2JhN/BqQYA/GRMDrSb9gAAAAAAAAAAAAAAAAAAHCRZAAAA///s3DEVACAMQ8FIw0x94Iyhr77wwMRwJ+Fnj1MNAPhM9WybAGRVz5EBAAAAAAAAAAAAAAAAgCdJLgAAAP//7NwxEQBACAPBOOP9q2LAwXcUuxKS/kQ1AOCe8gnAmrDGMwUAAAAAAAAAAAAAAAAA35I0AAAA///s3KEBAAAIw7D9/xSvIadxiOSP1lQDAP4RkAPUGGsAAAAAAAAAAAAAAAAAcJZkAQAA///s3DEVACAMQ8GYrQ7wxsMXAjp1Y7iT8LPHqQYAfKTO3fYAaJYkAAAAAAAAAAAAAAAAAIwkeQAAAP//7NwxAQAACMCgRbN/KjP4eUAQpBoAAMB3Ix0CAAAAAAAAAAAAAAAA4KRaAAAA///s3DEVACAMQ8FIqxl0VFwfvjDAwMhwJ+Fnj1MNAPhL2wPgqtfskgYAAAAAAAAAAAAAAACAJ0kOAAAA///s3DEBAAAIgDD6pzaCnh5bDzDVAIAnxOIAK+MhAAAAAAAAAAAAAAAAAG6qAQAA///s3EERACAMBLGTVjP4wBuDLxy0Xx6JhBWwphoA8A9TDYBerXO3RgAAAAAAAAAAAAAAAACMkjwAAAD//+zcMREAIAwEwXcWNehAHIMvHCQtxa6F689UAwD+UVoAjPY614QIAAAAAAAAAAAAAAAAgF6SBwAA///s3DERAAAMAjGc13odcB07JBJ+B6caAPCHkTjAzegEAAAAAAAAAAAAAAAAQJVkAQAA///s3DENADAMBLGHFjJFWpVXGFQZM9ggbjxTDQBY4NxnqAEwV7oJAAAAAAAAAAAAAAAAwFeSBgAA///s3CEBAAAIA8H1L0U1EkzgEHcR3m9ONQDgB+NwgJvRCwAAAAAAAAAAAAAAAIAqyQIAAP//7NxBDQBACASxNYuP80bwhYEzQNJamP+YagAAACdVz1MOAAAAAAAAAAAAAAAAgK8kCwAA///s3DERAAAIA7E6xzoGurAxJBb+rmOdagDAD6MDwJntBAAAAAAAAAAAAAAAAKBLsgAAAP//7NxBDQBACASxNYuP80bwhYBTQNJamP+YagAAAGdVz1MPAAAAAAAAAAAAAAAAgE+SBQAA///s3DENADAMA0FDC5niKLiqvAogW5YudxRe8minGgDw2Tq3NAAY23YUAAAAAAAAAAAAAAAAgCbJAwAA///s3KEBAAAIAkE2d3Uz2WC5G+E7ONUAgH/G4AA3ox8AAAAAAAAAAAAAAAAAJckCAAD//+zcQQ0AMAgEsJOGmSkl+OI5DSStkEo1AACA6+r1CIoAAAAAAAAAAAAAAAAA+JIsAAAA///s3CEBAAAIA8E1IxrVcRRAYO4i/PycagDAv7IBwFlLCAAAAAAAAAAAAAAAAMBKMgAAAP//7NwxDQAwDANBQwuZIq3KK0MhZMhyR+Elj3aqAQD7SgOAsTr32VMAAAAAAAAAAAAAAAAAviQNAAD//+zcsQ2AMAwEwC/YCiFlMwZhGbNZGteUKcjdBm+92z+cAgDYTCV5O3I911kKsFYPH3yNH9x/zM0So38cAAAAAAAAAAAAAAAAgN0lmQAAAP//7NyhDQAgEAPAX5Y5gNkIe2FQH4Im4U7WtrpONQCAH3QHGu/YPdy6aDkoY+bM8QYn9bQfAAAAAAAAAAAAAAAAAD4UEQsAAP//7NzBCYAwDAXQv5eIXcZBnKPjSPcqgoiHHgVB3zvlXxOSYzzVAIAXDR4F8KytzpMef8Bgjlde91aSlDMut5ofOu6qvQcAAAAAAAAAAAAAAAAgSToAAAD//+zcQQ0AIBDEwPVF0IYQzCCN7wUJ3IyDGqipBgDwIzONRvYcJ8l5i8tsw2ijl1WnKwAAAAAAAAAAAAAAAAA0leQCAAD//+zcQQ0AIAwEwVpDDDoQR/BFSOCHgnZGwt1/RTUAgGzajSxQ3C+20ed6sYVRfZ/Mzs/COgAAAAAAAAAAAAAAAADFRcQGAAD//+zcsQ0AIAwDQW8W9p8KCVFQMUBy17j3AC+qAQB0IqjB1xNaOHsjG5Vkea6Vmn4AAAAAAAAAAAAAAAAAwHhJNgAAAP//7NyxCQAgDEXBjJZlnMPhxL2sBFtBEPRuhEB++UQ1AOCu6v7HCGqwbYlszMBG+MsnZGk9bQIAAAAAAAAAAAAAAADAxyJiAAAA///s3LENACAMA0FvxmqMjiJR0KcC7kZw4fJFNQCAFwhq0HYENuYObIyKM1j2WhVH8QsAAAAAAAAAAAAAAAAAv0qyAAAA///s3DERADAMxLBnHmqFliVDAXTJVYJgADbVAAC2O4YavHYNNjKDjRJ5HUMUAAAAAAAAAAAAAAAAgJ8laQAAAP//7NzBDQAQEETRoS1xUKdmRaIFB/FeCbtz/vX3AwAAb5u9DS/kph3YmL2VJHtrAi4POUEUAAAAAAAAAAAAAAAAAH6UZAEAAP//7NxBDQAgDATB+iIEbejADNL6QQNJ0xkJd/8V1QAAKtve45czx30RF3GNOlb3AQAAAAAAAAAAAAAAAADaiogEAAD//+zcQQ0AIBADwUo7Mygl+EIEyRHCjIQ++lxRDQC4ZMxVtj8mbEA7cY2nlK8FAAAAAAAAAAAAAAAA+FSSDQAA///s3EENAAAIA7H5V03QwIMQWhH77UQ1AGCPo/dMhw0EDVgjrnGGrQUAAAAAAAAAAAAAAAD4KEkBAAD//+zcMREAMAwDMTPPFVqZZS2E9CJBsPcX1QAAfnU9xwRPXOM4ZKTaPgAAAAAAAAAAAAAAAADASkkaAAD//+zcUQkAIBQDwGcuESxjD3tYRhB7WUPxLsK27znVAABeNTXHTUbJfZScbPM+be36ewYAAAAAAAAAAAAAAAAA34mIAwAA///s3DENADAMBLHnFWUIzpAtjVa1Kdx+phoAwJO2y7iAK23XJBl1rmKqAQAAAAAAAAAAAAAAAPCbJAcAAP//7NxBDQAgEAPBoougDSGYJbg4cjMSmr5XVAMA+JGgBqW96MtZc/hqGbv7AAAAAAAAAAAAAAAAAADtJLkAAAD//+zcUQ3AIABDwfoiJEwMQtAxNQuZL2QQwp2Evv861QAATvSpxgneWp4kQ6z9+vzb7RsAAAAAAAAAAAAAAAAAXCXJAgAA///s3DENACEAwMD6Ij/gDB+YfRWEgTsJFVBTDQAAOGh/Y1VT4+tMNQAAAAAAAAAAAAAAAABeUv0AAAD//+zcQREAIAwEsfPFoK1CagZpqGB4NHGwBtZUAwAAHuu9jrHGdzW8HwAAAAAAAAAAAAAAAGCWJBcAAP//7NyxCQAwDAMw/39VTuvauRBKiHSBB6+2Uw0A+MfA+11NDc5e17GG/gIAAAAAAAAAAAAAAABAtyQHAAD//+zcQQ0AIAwEwfoiyMEHPpBD8MUHD6TpjINL7r2iGgBAOi9OACm/u3oT1vhk7DNLDgcAAAAAAAAAAAAAAACoKCIuAAAA///s3DEBAAAIw7A5w78rXMCxxEEN1FQDAACOGWu8mdJuAAAAAAAAAAAAAAAAgD5JFgAA///s3DEBAAAIw7BJw78qHjTAQSKhAmqqAQAAB2aswa7SGwAAAAAAAAAAAAAAAOCJJA0AAP//7NwxEQAwCASwN4vSHr5wQQcSIZFqAADAP2KNZfVarAEAAAAAAAAAAAAAAABwQZIBAAD//+zcQRUAIAgFsN+LZ1LLGI0WcmALMqkGAAAMuaeeWOM7qQYAAAAAAAAAAAAAAADABkkaAAD//+zcMQEAAAjDsDnHOi7gWOKgBmqqAQAAj4w1zk1ZLwAAAAAAAAAAAAAAAECnJAsAAP//7NwxDQAADMOw8kc1aHsKYdIem0L+mGoAAMCzjjVGBwAAAAAAAAAAAAAAAAA4kmQBAAD//+zcQQ0AIAwAsfkiPBCDD3wgZ8EXLgjJWgdn4Ew1AADgA7u3YazxxsyzKnQCAAAAAAAAAAAAAAAAlBYRFwAA///s3CEBAAAIwLBXpzklEIitwv1NNQAA4I/RAgAAAAAAAAAAAAAAAAAOVAsAAP//7NwBDQAgDASx90XQNiEzgzRcEJK1Ds7AmWoAAMAneq9jrPFEDWgEAAAAAAAAAAAAAAAAmC3JBQAA///s3DENACAAwLD5InjDB2aQhggejtbC/plqAADAR/YcqzqaAAAAAAAAAAAAAAAAAMCD6gIAAP//7NxBDQAgEAPBSsMMQk4bwRcqSMgx42DTf51qAADAe8omd821R+c+AAAAAAAAAAAAAAAAgO8lOQAAAP//7NxBCQAgAMDA9RKTWsZophBE7irsP1MNAAB4zJpjV1uXq0w1AAAAAAAAAAAAAAAAAH5WHQAAAP//7NxBDQBACAPBOkPbOUcFCTlmHGz6r1MNAADY6dllVH3cBgAAAAAAAAAAAAAAAHBekjQAAAD//+zcAQkAIBAEweslwve0jNFMIcg702ALrKkGAAA8aM2xjTWuqsZtAAAAAAAAAAAAAAAAAN9LkgMAAP//7NwxEQBACASx88W8N3xgFg9fUSQWtl9TDQAAOGpetTYAAAAAAAAAAAAAAAAA8CHJAgAA///s3EEJADAMBMEzGyHVVuorKgohzFjY/5pqAADAbEefP+o+0xIAAAAAAAAAAAAAAACArZI0AAAA///s3DERAAAIBKDv5ZnUsmZwc4AgSDUAAOCx6RI/AAAAAAAAAAAAAAAAAMBVkgUAAP//7NwhAQAACMCwV6c5GXCIrcL9TTUAAOC/0QgAAAAAAAAAAAAAAAAADqoFAAD//+zcQQkAQAwDwTivtZNWKqJwlBkHS/5xqgEAAP97NlpRB5sAAAAAAAAAAAAAAAAAGEkaAAD//+zcMREAMAgEsPfFVSlmkIaGbgyJkEg1AADguH41Yg0AAAAAAAAAAAAAAAAA+JBkAQAA///s3EENACEAA8GVhpkTSgi+zgQfyIyDTf91qgEAAHeYdjrvW3u81gQAAAAAAAAAAAAAAABAVf0AAAD//+zcMQ0AMAwEsecVlVt5lGxQdEhkU7j9TDUAAGCAd+rq9IWpBgAAAAAAAAAAAAAAAMBGSRoAAP//7NwxDQAACMCwWcc5FnhJWgv7Z6oBAAB/jFYAAAAAAAAAAAAAAAAAcFAtAAAA///s3EENAEAIA8E6w/pJI3jgc2TGwab/OtUAAIB/PFutq2M9AAAAAAAAAAAAAAAAAIwkDQAA///s3EEJACAAwMD1EsGelrWEH+WuwQrMVAMAAB6x5zDVuG/9FgQAAAAAAAAAAAAAAABAVR0AAAD//+zcMQ0AAAjAsFnHORK4SVoL+2eqAQAAv4xeAAAAAAAAAAAAAAAAAHCoFgAA///s3DENAAAIwLD5V4U0JHCTtBb2z1QDAAB+Gb0AAAAAAAAAAAAAAAAA4FAtAAAA///s3EENACAQBLH1RZCDD3wgh5wvTPCBtA7GwJhqAADAQ1ZvphqXjV3zqyAAAAAAAAAAAAAAAAAAkiQHAAD//+zcQQ0AAAwDofOveg72bwJCkGoAAMAesQYAAAAAAAAAAAAAAAAAfKoDAAD//+zcMQ0AAAjAsPl3hTMc8JO0FvbPVAMAAP4ZzQAAAAAAAAAAAAAAAADgUC0AAAD//+zcQQ0AQAgEsfVFzhs+MIuD+5O0FuY/phoAAHDMvGrNAAAAAAAAAAAAAAAAAOAjyQIAAP//7NwBAQAACMIwmlvdHrBFeICbagAAAOtuPQAAAAAAAAAAAAAAAABAnSQPAAD//+zcMQ0AAAjAsFnHOQoQQNJa2D9TDQAA+Gl0AwAAAAAAAAAAAAAAAIBDtQAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3DENAAAIwLD5V4U0FCCApLWwf6YaAADw0+gGAAAAAAAAAAAAAAAAAIdqAQAA///s3EENACAQBLH1RZCDD3wgh5wvTPCBtA7GwJhqAADAg1ZvphoXjV3zmxgAAAAAAAAAAAAAAAAAkiQHAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwxDQAACMCwWcc5BjBA0lrYP1MNAAD4a7QDAAAAAAAAAAAAAAAAgEO1AAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcMQ0AAAjAsPlXhTQMYICktbB/phoAAPDXaAcAAAAAAAAAAAAAAAAAh2oBAAD//+zcMQ0AIADAsPkiaEMIZjHBA2kdzMBMNQAA4FF7DlONe9YvIQAAAAAAAAAAAAAAAABU1QEAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3DENAAAIwLD5V4U0fhyQtBb2z1QDAAB+G/0AAAAAAAAAAAAAAAAA4KgWAAD//+zcMQ0AAAjAsPl3hTN+HJC0FvbPVAMAAH4b/QAAAAAAAAAAAAAAAADgqBYAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcQQ0AIQADwZWGmfNJQvB1JvhAZhxs+q9TDQAAuNu03xnf2uOFDgAAAAAAAAAAAAAAAACq6gcAAP//7NxBDQAwCASw80WmFLOY4DPSCqlUAwAAPtavpBp7pBoAAAAAAAAAAAAAAAAAVyQZAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3DENAAAIwLBZxzkvFkhaC/tnqgEAAP+NhgAAAAAAAAAAAAAAAABwVAsAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NxBEQAACIAwmtm/lQ9beFsEAmCqAQAAcEYHAAAAAAAAAAAAAAAAgCeqBQAA///s3EERAAAIgDCi2T+VD1t4WwQCYKoBAABwRgcAAAAAAAAAAAAAAACAJ6oFAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NxBDQBACASx9UXOGz4wy/cskLQW5j+mGgAAcNy8ag0BAAAAAAAAAAAAAAAA4JNkAQAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NxBDQBACASxNYuP80bwxfcskLQW5j+mGgAAcFz1PA0BAAAAAAAAAAAAAAAA4JNkAQAA///s3EERAAAIgDD6pzKaD1t4WwQCYKoBAABwRgcAAAAAAAAAAAAAAACAJ6oFAAD//+zcQREAAAiAMPq3spkPW3hbBAJgqgEAAHBGBwAAAAAAAAAAAAAAAIAnqgUAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwxDQAACMCwOcO/K14skLQW9s9UAwAA/hsNAQAAAAAAAAAAAAAAAOCoFgAA///s3DENAAAIwLBJw78qXiyQtBb2z1QDAAD+Gw0BAAAAAAAAAAAAAAAA4KgWAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3EERAAAIgDD6pzKaD1t4WwQCYKoBAABwRgcAAAAAAAAAAAAAAACAJ6oFAAD//+zcQQ0AIBAEsfVFkIMPfCCHnC9M8IG0FuY/phoAAPCwsWvqd8fqzVQDAAAAAAAAAAAAAAAA4BdJDgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcMQ0AAAjAsDnDvyt+HJC0FvbPVAMAAH4b/QAAAAAAAAAAAAAAAADgqBYAAP//7NwxDQAACMCwScO/Kn4ckLQW9s9UAwAAfhv9AAAAAAAAAAAAAAAAAOCoFgAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcQQ0AIBADwUrDDEJOG8EXwQOfIzMONv3XqQYAADQ11x62e6Y+6QAAAAAAAAAAAAAAbEneFgAAIABJREFUAADgSnLYuQMaAAAYhkH1r/oGbmAJCEGqAQAAu6QaAAAAAAAAAAAAAAAAAPCpDgAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcMQ0AAAjAsDnDvysMYICktbB/phoAAPDXaAcAAAAAAAAAAAAAAAAAh2oBAAD//+zcMQ0AAAjAsEnDvyoMYICktbB/phoAAPDXaAcAAAAAAAAAAAAAAAAAh2oBAAD//+zcQQ0AIBAEsfVFkIMPfCCHnC9M8IG0DsbAmGoAAMCDxi5DjYtWb/ObGAAAAAAAAAAAAAAAAACSJAcAAP//7NwBDQAADMOg+ld9BRewBIQg1QAAgE1SDQAAAAAAAAAAAAAAAAD4VAcAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3DENAAAIwLA5xzoKEEDSWtg/Uw0AAPhpdAMAAAAAAAAAAAAAAACAQ7UAAAD//+zcQQ0AIBADwUrDDEJOG8EXwQOfIzMONv3XqQYAADQz1x42e6o+agEAAAAAAAAAAAAAAADgSnIAAAD//+zcQQ0AAAwDofOveg72bwJCkGoAAMAeqQYAAAAAAAAAAAAAAAAAfKoDAAD//+zcMQ0AAAjAsDnDvysc8JO0FvbPVAMAAP4ZzQAAAAAAAAAAAAAAAADgUC0AAAD//+zcQQ0AQAgDwUpD+kkjeOBzZMbBpv861QAAgP+UzVa9Qy0AAAAAAAAAAAAAAAAAjCQNAAD//+zcQQ0AIBAEsfVFkIMPfCCHnC9M8IG0FuY/phoAAPCQsWvqddfqzVQDAAAAAAAAAAAAAAAA4DdJDgAAAP//7NwxDQAACMCwOcO/KyRwk7QW9s9UAwAAfhm9AAAAAAAAAAAAAAAAAOBQLQAAAP//7NwxDQAACMCwScO/KiRwk7QW9s9UAwAAfhm9AAAAAAAAAAAAAAAAAOBQLQAAAP//7NxBDQAgEAPBmsUHp43gi+CBz5EZB5v+61QDAACaGGtPWz1Xn/UAAAAAAAAAAAAAAAAAcCU5AAAA///s3DENAAAIwLA5w78rLPCStBb2z1QDAAD+GK0AAAAAAAAAAAAAAAAA4KBaAAAA///s3DENAAAIwLBJw78qLPCStBb2z1QDAAD+GK0AAAAAAAAAAAAAAAAA4KBaAAAA///s3EENACAQA8H6IsjBBz6QQ84XJvhAZiRs/3WqAQAADxi7pp3uW73pCgAAAAAAAAAAAAAAAPCjJAcAAP//7NwxDQAACMCwOcc6FnhJWgv7Z6oBAAA/jE4AAAAAAAAAAAAAAAAAcFQtAAAA///s3DERAEAIBLEzi4/3xuALDd9RJBa2X1MNAAA4rnqeRgAAAAAAAAAAAAAAAADwIckCAAD//+zcQQkAQAwDwTirtnNeKqJwlBkHS/5xqgEAAP8rG614B5sAAAAAAAAAAAAAAAAAGEkaAAD//+zcMREAIBDAsEp7Myjl8IUGNobEQveaagAAwMfWPlONRgAAAAAAAAAAAAAAAADwoLoAAAD//+zcQQ0AQAgDwTrH2klDBQk5Zhxs+q9TDQAA2K3sM+Z92gUAAAAAAAAAAAAAAABwXpI0AAAA///s3FEJACAUBMHrJcIrYyrjiL1MIYjMVNj/NdUAAIBHjbUrSelzx+zNVAMAAAAAAAAAAAAAAADgV0kOAAAA///s3CEBAAAIwLD3L0U1OqAQW4X7m2oAAMBfow0AAAAAAAAAAAAAAAAAHFQLAAD//+zcQQ0AIBADwZrFB6eN4AsVJOSYcbDpv041AADgQWPtaZerqnEbAAAAAAAAAAAAAAAAwPeS5AAAAP//7NwhAQAACMCwN6c6HVCIrcL9TTUAAOCn0QUAAAAAAAAAAAAAAAAAjqoFAAD//+zcUQkAIBBEweslxrGHPQzjx2EvUwiiMw0e+79ONQAA4DIt17TJWaOW/nIfAAAAAAAAAAAAAAAAwPciYgMAAP//7NwxEQAgEMCwSnszKOXwhQgWhsRC95pqAADAR9Y+U40mAAAAAAAAAAAAAAAAAPCgugAAAP//7NxBDQBACAPB+jfFSUMFCTlmHGz6r1MNAADYpewx7n3eBwAAAAAAAAAAAAAAAHBekjQAAAD//+zcAQkAMAwEsTdboWPMV12MQhMHZ+BMNQAAYIi6z1Djj7MhEgAAAAAAAAAAAAAAAGC1JA0AAP//7NxRCQAgEETBjWYZexhNEHtdCxFupsFj/9epBgAAfGCeu5IMWzyxGzQCAAAAAAAAAAAAAAAA9JakAAAA///s3EEJACAABMHrJcYxh0GMI/YSSyjITIX9r6kGAAA81uY6M42uwx2jFlMNAAAAAAAAAAAAAAAAgN8l2QAAAP//7NwxAQAACMOw+TeFNR40wEFioX9NNQAA4NAMNUqDNYYaAAAAAAAAAAAAAAAAAB8kaQAAAP//7NwxAQAADMIw/Luas8ngIHFQAzXVAACAEkONihtsBgAAAAAAAAAAAAAAANiT5AEAAP//7NxBAQAACAIxmlvNaLbQh1uDIwBONQAA4E7Zfl0/6wUAAAAAAAAAAAAAAAD4KckAAAD//+zcQREAEABFwd/LmFFGKmEcjF5acLAb4QV4phoAAPBAX3smadrfNWox1QAAAAAAAAAAAAAAAAD4QZIDAAD//+zcMQEAAAjDsFnHOS7gWOKgBmqqAQAAxww13kxpNwAAAAAAAAAAAAAAAECfJAsAAP//7NwxDQAgEAPADlhFJyQEXwQTMPydg7Z7m9kBAOCNvvY90hjq/mYWzQ0AAAAAAAAAAAAAAABQT5IDAAD//+zcMQ0AMAwEsVdoVUVaskFRZYhN4fYr2QEA4D9DjXnvHlMNAAAAAAAAAAAAAAAAgC2SNAAAAP//7NwBCQAACMCw909tCkFwCzKpBgAALBNqnCDUAAAAAAAAAAAAAAAAAPikGgAAAP//7NwxDQAgEAPADgjDDEIJwRdBBGH4Owdt9zaDAwDAO2Pte6bRVfzdLJ4fAAAAAAAAAAAAAAAAoJYkBwAA///s3AEJACAMAMH1EuOYQ3sYR+wlhhCE3UX4AG+qAQAAD7S170ijG2r8YdYysjcAAAAAAAAAAAAAAAAASCUiDgAAAP//7NwxDQAgEATBM4sPpH1C8EWDBIpPmLGw/ZpqAADAY2PteYca9FA6AAAAAAAAAAAAAAAAAHwmyQEAAP//7NxBDQAgEASxlXZmEEoIvvgggQfJtRJGwJhqAADAI2PtujON0vQrs3sAAAAAAAAAAAAAAAAAgHaSHAAAAP//7NxBDQAgDACx+SLIwQc+EMNjwRcmeJCslXACzlQDAAAeGHm2mcafVm+zegMAAAAAAAAAAAAAAACAciLiAgAA///s3FEJACAQBcFX1hxWE8Rechn8EW4mwgZYUw0AAHgw9qlhw9TwW6t7AAAAAAAAAAAAAAAAAICWklwAAAD//+zcQREAAAjDsPl3hTM88OOWSKiAmmoAAMCBmcYb0x4AAAAAAAAAAAAAAAAAoFKSBQAA///s3FENABAARdHXy2zK6KGHOKaXCn7NORFugGuqAQAAl/raLUkz03jHrGX83gAAAAAAAAAAAAAAAADgS0kOAAAA///s3LENADAIBLHfHGVzGnrqCHuF689UAwAAFjPTqBlq8I+nFQAAAAAAAAAAAAAAAMBRSRoAAP//7NwxEQBACASx868Kad9Ah4EfEgvbr6kGAAAseqQxMw3+VLoBAAAAAAAAAAAAAAAAHJXkAQAA///s3EENwCAABLDzRRbU4GM+ZoaE4IsPj1kgtEIq1QAAgJ825puk7lCDc/XvKVINAAAAAAAAAAAAAAAAgFslWQAAAP//7NxBDQAgEMTAk4YZdKCNEHzdBxXsjIQKqKkGAADR5rnjDTRWeovP7PQAAAAAAAAAAAAAAAAAANGqqgEAAP//7NwxEQAgEAPB+GIYrOEDszRfoIHfbSIg/YlqAADQyhPRWLV86Myx/QoAAAAAAAAAAAAAAADQWJILAAD//+zcAQEAAAjCMKrb3B6wRXiAm2oAAFDNRGPSrQcAAAAAAAAAAAAAAAAAmJfkAQAA///s3EENACAMA8CaRQdIIyH42hcN7M5B23+dagAA8I1x7nqyTMu2tbsXAAAAAAAAAAAAAAAAANBekgIAAP//7NxBDQAwCASw80WmdGYmbX8cEFohlWoAADBKizMiz6B595RUAwAAAAAAAAAAAAAAAGC7JB8AAP//7NyhEQAgAAOx3wxWY3MOj8EhkhFa/6IaAAB84RLLOEY1PcSDZSwAAAAAAAAAAAAAAAAAqjYAAAD//+zcQQ0AIBADwfoiaEMIZk4aCu5LIJmR0P5XVAMA+E4TX+Btyz9cUHuOMjQAAAAAAAAAAAAAAAAASXIAAAD//+zcQQ0AAAgDsVnHOcneGCBpJZyAM9UAAD4yaAAuowoAAAAAAAAAAAAAAAAAlWQBAAD//+zRAQkAMAwEsae2xpTOTKUNKqMkEu5KCQAAYIF+97SRAAAAAAAAAAAAAAAAAIwkHwAA///s3DENAAAIwLBZxzkfIkhrYf9MNQAAgA9GRQAAAAAAAAAAAAAAAABOtQAAAP//7NxBDQBACASx9UVOKWaQxu88kLQW5j+mGgAAwHXTr0ZFAAAAAAAAAAAAAAAAAL4kCwAA///s3DENAAAIwLBZxzk3EkhaC/tnqgEAAHw3CgIAAAAAAAAAAAAAAABwVAsAAP//7NxBDQBACASx9UVOKWaQxvskkLQW5j+mGgAAwGXTr0ZBAAAAAAAAAAAAAAAAAD5JFgAA///s3DENAAAIwLBZxzkCUEDSWtg/Uw0AAOCzUQ8AAAAAAAAAAAAAAACAo1oAAAD//+zcQQ0AQAgEsfVFTilmkIaAU0DSWpj/mGoAAABXTb8a9QAAAAAAAAAAAAAAAAD4JFkAAAD//+zcQQ0AQAgEsfVF7oFOzGLgDJC0FuY/phoAAMBJ86qVAwAAAAAAAAAAAAAAAOAryQIAAP//7NwxDQAACMCwWcc5ChBA0lrYP1MNAADgo1ENAAAAAAAAAAAAAAAAgFO1AAAA///s3EENAEAIBLH1Rc4bPjCLghNA0lqY/5hqAAAA58yrVg0AAAAAAAAAAAAAAACAryQLAAD//+zcMQ0AAAjAsFnDvykc8JO0FvbPVAMAAPhmFAMAAAAAAAAAAAAAAADgVC0AAAD//+zcQQ0AQAgEsfVFTilmkIaD+5O0FuY/phoAAMAl069GMQAAAAAAAAAAAAAAAAC+kiwAAAD//+zcMQ0AQAgEwfNFvkAnZpHwNcmMhe3XVAMAADhjXrVaAAAAAAAAAAAAAAAAAHwlWQAAAP//7NxBDQAADAOh8696FvZtAkKQagAAACuEGgAAAAAAAAAAAAAAAAD8VAcAAP//7NxBDQBACASx9UVOKWaQhoX7krQW5j+mGgAAwAXTr0YpAAAAAAAAAAAAAAAAAL4kWQAAAP//7NwxEQBACASx88V8gU7MYuFLisTC9muqAQAAnDevWiUAAAAAAAAAAAAAAAAAviVZAAAA///s3DEBAAAMw6D4Vz0N+3qAEKQaAADAOqEGAAAAAAAAAAAAAAAAAD/VAQAA///s3DERAEAIBLHzxbxSzCANDd9RJBa2X1MNAADgsulXoxAAAAAAAAAAAAAAAAAAX5IsAAAA///s3DERAAAIA7Faw78prhLYGBILv7+pBgAA8FWHGqMOAAAAAAAAAAAAAAAAAGdJFgAA///s3CEBAAAIwLBXpzkdUIitwv1NNQAAgK9GGQAAAAAAAAAAAAAAAABOqgUAAP//7NwxEQAwDMSw55XrUJwlE2jlkCmDRMG7TTUAAICN7jvVygAAAAAAAAAAAAAAAAAwkuQDAAD//+zcMQEAAAjAoFW3uSF8PCAIUg0AAOCbEWoAAAAAAAAAAAAAAAAAcFItAAAA///s3DERADAMxLDnlSu38iiZQCuILBkkCt5tqgEAAGzS79RVBAAAAAAAAAAAAAAAAICRJB8AAP//7NwxEQAACAOxWsO/Ka4aWBgSC7+/qQYAAPBFhxqjBgAAAAAAAAAAAAAAAABnSRYAAP//7NwxAQAADMOg+Fc9Ezt6gBCkGgAAwAShBgAAAAAAAAAAAAAAAABvqgMAAP//7NwxAQAADMOg+Fc9Ezt6gBCkGgAAwAKhBgAAAAAAAAAAAAAAAAB/qgMAAP//7NwxDQAwDASx5xV1KM6SCbSSiJTFpnD7mWoAAADb7jvVKgAAAAAAAAAAAAAAAAAwJskHAAD//+zcQQ0AAAwDofOveiaW9ANCkGoAAABLQg0AAAAAAAAAAAAAAAAA/lUHAAD//+zcMREAAAwDofevuip6WUAIUg0AAGBFqAEAAAAAAAAAAAAAAADAj+oAAAD//+zcMREAAAwDofevuip6WUAIUg0AAGBBqAEAAAAAAAAAAAAAAADAn+oAAAD//+zcMQEAAAzDoPhXPRXrBUKQagAAAGtCDQAAAAAAAAAAAAAAAAB+VQcAAP//7NwxAQAADMOg+Fc9FesFQpBqAAAAS0INAAAAAAAAAAAAAAAAAP5VBwAA///s3DEBAAAAwqD1T20LLwiCVAMAAHgRagAAAAAAAAAAAAAAAADwUQ0AAP//7NwxAQAAAMKg9U9tCy8IglQDAAB4EGoAAAAAAAAAAAAAAAAA8FMNAAD//+zcMQEAAAjAoPVPZTRT6AVBkGoAAACXRqgBAAAAAAAAAAAAAAAAwLtqAQAA///s0DERACAMBLAf6opjQCdmkFYVZUokpKwDAABD3t3ryAUAAAAAAAAAAAAAAADguyQNAAD//+zcMQ0AAAjAsAX/olFBeFoJE7BRHQAAOGCoAQAAAAAAAAAAAAAAAMCfagEAAP//7NAxEQAgDASwH+qKY0AnZpBWE71jSSSk9AMAAMPO3etJBQAAAAAAAAAAAAAAAOCbJA0AAP//7NwxDQAACMCwBf+iMUHC00qYgI36AADAIUMNAAAAAAAAAAAAAAAAAP5VCwAA///s0TERACAMBMEv4oqhQCdmkBYTKSh2JdyVDQAAwIB39zpCAgAAAAAAAAAAAAAAAPCFJA0AAP//7NwxEQAACAOxHs5xXhEsDImF33+UAAAAjtZQAwAAAAAAAAAAAAAAAIBXkhQAAP//7NwhAQAACAPBCfpnIhqGBCjEXYSfX1kEAAA46j3UaAEBAAAAAAAAAAAAAAAAeCXJAAAA///s3DERAAAIA7FKRzpXC0wMiYQX8KYaAADARWcaoxwAAAAAAAAAAAAAAAAALyVZAAAA///s3DEBAAAIw7D5VzVpPBjg40gkVEBNNQAAgIvuUKOqAQAAAAAAAAAAAAAAAPBWkgEAAP//7NwxEQAACAOxSkc6VweMDImEF/CmGgAAwFVnGqMWAAAAAAAAAAAAAAAAAO8lWQAAAP//7NwxDQAADMOw8kdVaHv2755kQwiAmGoAAACX7lCjSgEAAAAAAAAAAAAAAADwQpIBAAD//+zcQQ0AAAgAoatm/1I28O8GQZBqAAAAl5FpAAAAAAAAAAAAAAAAAPBOtQAAAP//7NwBDQAwCASx90XmbdOB2RnAAEkr4QScqQYAADB5feoqAwAAAAAAAAAAAAAAAMBKST4AAAD//+zcMQ0AAAzDsPJHVWh7dozCJBtCAMRUAwAAuLpDjaoCAAAAAAAAAAAAAAAAwFtJBgAA///s3AENAAAAwqD3T20PB0GQagAAAMk0AAAAAAAAAAAAAAAAALhSDQAA///s3AEBAAAIw6D1T20PD0GQagAAwDaZBgAAAAAAAAAAAAAAAAD/VAcAAP//7NwBAQAACMOg9U9tDw9BkGoAAMAmmQYAAAAAAAAAAAAAAAAAf1UHAAD//+zcAQEAAAjDoPVPbQ8PQZBqAADAFpkGAAAAAAAAAAAAAAAAAP9VBwAA///s3EERAAAMwjCkT/oOHSQW+q+pBgAAbOhI47QGAAAAAAAAAAAAAAAAYEKSBwAA///s3AEBAAAIw6D1T20PD0GQagAAwG8yDQAAAAAAAAAAAAAAAAD2VAcAAP//7NwxAQAACMOw+Vc1aTyogMRC/5pqAADAPd2ZRrUFAAAAAAAAAAAAAAAA4KUkAwAA///s3EERAAAIw7BJRzo3G5BY6L+mGgAAcEdHGqMnAAAAAAAAAAAAAAAAAO8lWQAAAP//7NwxDQAgAMCw+SKIQwdmkMaDCZLWwv6ZagAAwN9WdfYcR0cAAAAAAAAAAAAAAAAAeKoLAAD//+zcQQ0AAAwDofOveg72bwJCkGoAAMAekQYAAAAAAAAAAAAAAAAAfKoDAAD//+zcQQ0AAAwDofOvehb2bQJCkGoAAMAGkQYAAAAAAAAAAAAAAAAAfFUHAAD//+zcMQEAAAjAoFWzfykz+HlAEKQaAADw24g0AAAAAAAAAAAAAAAAAOCoWgAAAP//7NExEQAACAOxHsrwr6oa2BgSCf+jGQAAvLb2AAAAAAAAAAAAAAAAAMBRkgIAAP//7NwxEQAwCASwN4uOiuPwhYZuDImQSDUAAOC2Vz1iDQAAAAAAAAAAAAAAAAD4kWQBAAD//+zcIQEAAAjAsDenOhlwiK3C/U01AADgv9EIAAAAAAAAAAAAAAAAAA6qBQAA///s3DERAEAIBLGThplXyuALC19SJBa2X1MNAAC4r15P6QQAAAAAAAAAAAAAAAAAn5IsAAAA///s3DENAAAIwLA5xzoWeElaC/tnqgEAAD+MTgAAAAAAAAAAAAAAAABwVC0AAAD//+zcMQ0AMAwEsYcWMuVRblV4lULWSDaF289UAwAAdqjz+moFAAAAAAAAAAAAAAAAAANJPgAAAP//7NwxDQAACMCwOcc6FnhJWgv7Z6oBAAB/jFYAAAAAAAAAAAAAAAAAcFAtAAAA///s3EENAEAIBLE1i4/zRvCFhHuTtBbmP6YaAABwSPU8vQAAAAAAAAAAAAAAAADgI8kCAAD//+zcMQ0AMAwEsYcWMsVRcFV4lUH2SDaF289UAwAAdrnndWkGAAAAAAAAAAAAAAAAAIMkHwAA///s3DENAAAIwLA5xzoO+ElaC/tnqgEAAP+MZgAAAAAAAAAAAAAAAABwqBYAAP//7NxBCQAgFAPQf7CVCJYxiDksI4i9LOFFea/BtvuSfgCAB3WjPcUBxH21rV1HyfO3YAAAAAAAAAAAAAAAAABwRUQcAAAA///s3EENwCAABMGrLoKc+sAHYngQfCGi6QMy4+By/xXVAACO02tpXjvHO1eENX4xkjwX7gIAAAAAAAAAAAAAAACA75JsAAAA///s3DERADAIBMEfvEYpgy8MpKXblXACrmQEAOCSCcqd16MtAAAAAAAAAAAAAAAAAPwkWQAAAP//7NxBEQBACAOxWkPZWUcEwz2YxMFWQJ1qAADwQ1l5xTvYBAAAAAAAAAAAAAAAAABzSRoAAP//7NxBDcAgFETB9UWQgyrE9CdNfSECeiEzDt4KWKcaAAD8bvZWScrS5433e25rAgAAAAAAAAAAAAAAAIBtSRYAAAD//+zcsQ3AIAwEQO+FIrEMeyRzMA5iL1rqSFDA3Qbvr9+7n2oYUgJcpD7p1Tcw+RxjiVxazwfmAgAAAAAAAAAAAAAAAID/ImIAAAD//+zdsQ0AMAwCMD7P611yQaV0SO0P2Jjg6ahGP5QDAPCh7oL64IzaGAoAAAAAAAAAAAAAAAAAriU5AAAA///s3FEJACEUBMDXSwQNYyrjiL3sICrcMdNg93/36akGwEcZKgMc0nOquryitDHLD3MBAAAAAAAAAAAAAAAAwJ6IWAAAAP//7NxBDQBACAPBWkfZWcMDCfcgMw62AupUAwCA38riK97BJgAAAAAAAAAAAAAAAACYSdIAAAD//+zcQQ0AIBADwfNFkIMO8IEcgi+CCB4XZiRs/3WqkUv/PQAAkN+sZZjxjba2tgAAAAAAAAAAAAAAAABwRcQBAAD//+zcQREAAAjDsFnDvyluIjg+iYQKqKkGAAAfRvUTJmwAAAAAAAAAAAAAAAAAUEkWAAD//+zcUQkAIRRE0eklxjGVYfbBsr3MIMh+yDkN7gQYpxoAAPxu9lZJyvLnjfd7bmsCAAAAAAAAAAAAAAAAgG1JFgAAAP//7NxBDQAgEAPBSjszCEEbwRcW7kNIyIyDrYA61QAA4JVp+StqrF0fdgEAAAAAAAAAAAAAAABAX5IDAAD//+zcQQ0AIBADwfoiaEMIZk4aFu5DSMiMg62AOtUAAOCJPUclKetfsT5sAgAAAAAAAAAAAAAAAIC+JAcAAP//7NxRCQAgEETB6yWChrGHPYwj9rKCPyLITIO3AdapBgAAz4ycqvWvKG2u/mEXAAAAAAAAAAAAAAAAAJyJiA0AAP//7NzBCQBACAPBdC7XuS34kQOZ6WDJP041AAD47VlgRR1sAgAAAAAAAAAAAAAAAICZJA0AAP//7NwxDQAgEAPA90WQgw98YIaE4AsLLITh7yS0Scf+ONWY6gFIwd4DV0YtXVJvtLVlCwAAAAAAAAAAAAAAAEBOEXEAAAD//+zcwQkAIQwEwJSmxViHtYnYlx0IIiJ3zHSwIeS3efFUo1k34CuUkY+498CObFpX1NJH+mEuAAAAAAAAAAAAAAAAAFiLiAkAAP//7NxRCQAgFAPA9RKzGcQyRrOBPyLC467B2Pf241SDC0aRAEBFs7eVZCn3iVEwEwAAAAAAAAAAAAAAAACcJdkAAAD//+zcMQEAMAjEwJeGtTpHBQPlzkL2mGrsY6oBAPzqKTuijNkAAAAAAAAAAAAAAAAAOCdJAwAA///s3EENACAQA8H6ImhDCGZOGgruSULIjINN/3WqAQDAE/YclaSsccX6sAkAAAAAAAAAAAAAAAAAekkOAACv444nAAAgAElEQVQA///s3EEJACAURMHfSwQNYw97GEfsZQGvgshMg8fe16kGAADPGDlVa1xR2lz9wy4AAAAAAAAAAAAAAAAAOIuIDQAA///s3MEJAEAIA8F0Lte5DfgVDpnpYMk/TjUAAPjNs8iKOtgEAAAAAAAAAAAAAAAAALMkDQAA///s3DENACEURMHvixDU4AMfiKEg+EIACR1XXGYc7BOwTjUA7oo+AN/qOTXJ36hzjT/uAgAAAAAAAAAAAAAAAIBDRGwAAAD//+zcsQ0AIAgEQEbDYZzUuJc7SKQwdyN8wVdP+1MNI8kyA3/olfK+494DRUOAT+RcW7cBAAAAAAAAAAAAAAAA8L+IOAAAAP//7NwxDQAgEAPA+iJoQwhmkMbMTGD43DloOrffTzW4ZgQJAJQ3e1tJlqafGAUzAQAAAAAAAAAAAAAAAMApyQYAAP//7NxBDQAgDATBk1YzCEEbwRcqmjRkxsL+11QDAICptjItap1r1AYAAAAAAAAAAAAAAADA35I8AAAA///s3MEJACAQA8H0JVZqMV5pPq8CQWSmgyX/ONUAAOBJa45KUta5Yn/YBAAAAAAAAAAAAAAAAAAtyQEAAP//7N2xCQAgEAPA30ssHMY93MNxxL0Ee0sR5G6DkD4xqgFw4MUf4L2eU1HDHXXM9mMuAAAAAAAAAAAAAAAAANgiYgEAAP//7NzBDQAgCAPAbk7c3IczaMDcbdCQPounGgMZ+sMzugbQw3KHK+rDTAAAAAAAAAAAAAAAAABwJNkAAAD//+zcQQ0AIQwEwPoiyMEHPhDDg+ALEUC4XGYcbB/72756qmEYucfQH/g6PQ8c03KqrnlHGbP/MRcAAAAAAAAAAAAAAAAAREQsAAAA///s3FEJACAQBcEXTcNcUrGXGfyQA5mJsAG2a6oBAAA3plpPjFrbsA0AAAAAAAAAAAAAAACA/yQ5AAAA///s3EENACAQA8H6ImhDCGZOGiouITDjYNN/nWoAAHC9PUclKUu1WA82AQAAAAAAAAAAAAAAAPC7JAcAAP//7NxJEQAgDAPAOqNmEII2Bl+ogOHYdZDmnXqqcafy+wFgEyNjgLM0fSyRtY98MBcAAAAAAAAAAAAAAAAAP4uICQAA///s3UENACAMA8D5IihFDEhDxCAQuHPQT39bTz3VsDKe4+gRuJ2eB5ZrtQz9sk1/NBcAAAAAAAAAAAAAAAAAv4qICQAA///s3DENACAMBMD6IgyIwQc+kEPwxYIFQgJ3Dr7Db98rTzX2IBKAR+l54JSeU3HcM+qY7cVcAAAAAAAAAAAAAAAAAHwqIhYAAAD//+zcQQ0AIBADwUrDDDoI2gi+UEG4kBkL++ivT041AKrrazeRAMqa0lwx7B8AAAAAAAAAAAAAAAAA30hyAAAA///s3UENACAMA8D6ImhDCGZRsWTAnYP+9mlnVONSPolDOaVigKb2HO6gOuvVYAAAAAAAAAAAAAAAAAB8JskBAAD//+zcMQ0AMAwEsYeWginSKryKIkMkm8LtZ6oBAMBGR7URdV8bSwEAAAAAAAAAAAAAAACwX5IPAAD//+zcMQ0AIAADsPkiaCPowAzSuBFASKB1sB07d/NUo79SIgAb+w4cN2qZSaamj2gPZgIAAAAAAAAAAAAAAADgN0kWAAAA///s3EENACAMA8A5AzP4wBvBFyLIAoE7B+2/PXmqwZ6iP0hlUAxwPyc+OWobs78YDAAAAAAAAAAAAAAAAICPRMQCAAD//+zcQQ0AIAwEwfNFSPCJmUpDBY+mMxJWwJpq9HWmBwAAZrt7VZKa3uETcykAAAAAAAAAAAAAAAAAekvyAAAA///s3DENACAQBMH3RSgQgw98IOeDL1RQADMONtefUw0AAK41a2nWO6PnGi92AQAAAAAAAAAAAAAAAPCJiNgAAAD//+zcwQkAIQwEwPQlgs1Yx2EdliP2ZREinjDTQfJY8tlce6rRc1LS21THLE8PAD+lRLxHvgMXNEs/4nNvAgAAAAAAAAAAAAAAAPCsiFgAAAD//+zcAQ0AMAwCQZzP+ky0WcLuHCCAfxbVYISTIwDwPTGfVad4GwAAAAAAAAAAAAAAAADNklwAAAD//+zcQQ0AIBADwToDxKCU4OsE8OZxyYyE9r+iGgCvYROAdpbLvpj7XCE3AAAAAAAAAAAAAAAAAPpJUgAAAP//7N3BCQAwCAQw9yqd1GUcrTsURIRkAX/HfdTpoxo1PH87n8Ohh+Xhf3IdGJH3lAxqo3MCAAAAAAAAAAAAAAAAsE9EPAAAAP//7NxBDQAgDAPAScMMPkAaIfjCBGTJcmegWR99LvupxkrOB+Atuw5kmtr/ovV9RsG7AAAAAAAAAAAAAAAAAKgsIi4AAAD//+zcUQnAMBAD0Pgag5mpjgqZmcKYr4pYS1l5z0Eu37nVTzX4qDzv5YYwjtEwwH/d59GSNBVOUTfMBAAAAAAAAAAAAAAAAMDOknQAAAD//+zcsQkAIBADwN9LLBzGqRzGQtzLxg1EBLnbIOmT16caRo/nnGoAAGwtp6KLO+qY/cdcAAAAAAAAAAAAAAAAAHwqIhYAAAD//+zd0QnAIAwFwOxVil3GPdo5Oo50L3/cQIsodxOEPPL7MrVUo30Tp0+yPxjKTXV4z+NednhgJ480f3Hl8il0AwAAAAAAAAAAAAAAAGANEVEBAAD//+zcwQ0AMAgCQDZ39S6hMTV3G/DgCaunGrQwbIReOgXwOQc/o+pwNgAAAAAAAAAAAAAAAAAuSfIAAAD//+zdwQkAMAgDwIxmN+9onaKgcjdBwEd+scOoxm2QASC+7wOscpzzi9KXAAAAAAAAAAAAAAAAAIyQ5AEAAP//7N0BDcAgDATA+lomZ0LQgZhtWfA1EUACzZ2Cr4D/rjCq8S6QYWvX13xjhzGUhPuUncMDudTzeIy3TXMnvQsAAAAAAAAAAAAAAACATCLiBwAA///s3EENAAAIA7E5w78rVJAspLVw/2uYagC0GCUAXjH7OWLqBgAAAAAAAAAAAAAAAEC9JAsAAP//7N3BCQAgDAPA7iWCmzmIyzhahxChyt0GoZ+80gqjGj6In5uvB4AihkMA/GP1tnXNa/RPAAAAAAAAAAAAAAAAAGqLiAQAAP//7NyxDcAgEAPA3wtRZBj2yB4MkwKxVxo2QBHK624Dy7V9/FRjjR0BjmpjOtTY1Gu5fx0ASKnXcmn2G23MJ2MuAAAAAAAAAAAAAAAAAJKIiBcAAP//7NzRDQAQAEPBjmYZg5hN7GUIhMjdCv3uux7VYI/ahzM7rBHVAPhXs+0RRZQKAAAAAAAAAAAAAAAAgGclmQAAAP//7NxBDQAgDAPA+SIEaQjBDNIQQQiM3ClYH32ur4xqeHTc17IHgMt0aM/MfDzwt1GL8bFz+q/BAAAAAAAAAAAAAAAAAEguIhYAAAD//+zd0QkAIAgFQEerYRo0or0aQgKjuwkeiPj3rFKqQZ4v4ZBjh3Lmy+GBL3RjvqKNtd1QAAAAAAAAAAAAAAAAAOqJiAMAAP//7NxBDcAwDANA85oKpzzGY2BaqSqvcpi0x6I7Bo7fjqcahRg0wjt97dvpAGp72jWTTDV/YhTMBAAAAAAAAAAAAAAAAMDfJTkAAAD//+zc0QkAIAhAQfeKaLbmaNl2sAKDuxEU/POViGqs3jy03yGqATnD3M6448AnpkW9IVAFAAAAAAAAAAAAAAAAQDkRsQEAAP//7NzBCcAgAAPA7CWO0zkcpMsI0r3cQSwI3o2QPPLLEacabNNECUsc0gBc4K2lJ+m6/kV7xmdPAQAAAAAAAAAAAAAAADhHkgkAAP//7N3BCQAgDAPA7CU+nNNlnUGoUOFuhdBn0k6jGj6HF1BmhDtupoSCOvCNPceS1jMG3gAAAAAAAAAAAAAAAADoI8kBAAD//+zcQQ0AIBADwUrDOs7QQOCSI8w46KPf7RTV4A6BANjjM+fm6wOA74i51RhiVQAAAAAAAAAAAAAAAAC0kWQBAAD//+zdwQkAIAwDwOwl7uYeLuNozuBDKHo3QaCU/tJKpRqrQIYX+BAOZ+wMwGdmb8PMr3FXAQAAAAAAAAAAAAAAAKghyQYAAP//7N1BCQAgEATA6yWChjGVccReVvChoDBTYR/32r1nRjV6TkY1DvEhHPa0MZWqD1BOBz5VBXdFcV8BAAAAAAAAAAAAAAAAeEJELAAAAP//7Nw7EQAgDETBc4Y0rNNEAAXM8Nl1kFRXvWOiGkVYYw1RDZjT/AngTxV0sz336C8eBQAAAAAAAAAAAAAAAMBlkgwAAAD//+zcyQkAIAwEwDRrH1qaiH3ZgiCCx0wF2c/+sqeNatQDbniBR0aYY4BmXbk9APA1HbZJaj0/GQwAAAAAAAAAAAAAAACAe0TEAAAA///s3MEJwCAAA8DsVRyncziIywile3UDXxUF70YI5JnsdqrBTwwZYUxHAGjl6kn68UHMUe/ndV4FAAAAAAAAAAAAAAAAwDpJPgAAAP//7NzbCQAgCAVQ94qIJmuQlm2Iih6cs4Fe0C+96qlGz8mR+zrll0Jgk6ax88xt4HU9pyrEbexaAAAAAAAAAAAAAAAAAM6JiAEAAP//7N2xCQAwDAMwn5bX+nn30rEhHaQTDAFPzlejGjxVvoPDndsA4LAE0kIfBQAAAAAAAAAAAAAAAGBOkg0AAP//7N1BDQAgDASw+SJ4wwdiQBoGeI6EQOvgltxz241HNSw15vEdHPZ0I8d8IQRAr6V9P4RzxqvBAAAAAAAAAAAAAAAAALhcRCwAAAD//+zdsQkAIAwEwKzmMA4q4l42qaxVRO42SODb/xdLNdjHMjgscjFfNvZoPxwBkIpHnFH7UFoCAAAAAAAAAAAAAAAAwH0RMQEAAP//7N3BCQAgDAPA7CXO5iAu42gO4LeCyN0GpZBf0+dKNXwKr+WIEQ4KNYrIa+Ans7eVZFnqFePDmQAAAAAAAAAAAAAAAAB4XZINAAD//+zcsQkAIAwEwCzrIE5mIe5lncJOIcjdBh/48lPuqQbXGTFCphMAnHSXeaPNNX7MBQAAAAAAAAAAAAAAAEBhEbEBAAD//+zc0QnAIAwE0NurFFzGPbpHlxHEvRyiFkTe2+AIl79k16caDhoXqn08x4SBD3RhKXsaOM57Xy1JM9lflNpHOTAXAAAAAAAAAAAAAAAAALtKMgEAAP//7NzJCQAgDATA9CU+rMxCbNYO8vFAZKaDDYS8Nq8+1VBm3Kv/FAYW2AUAUqOWZkLHuMMAAAAAAAAAAAAAAAAA3BMREwAA///s3UENACEMBMD6upBgBh+g4+QQfN3nJEBCYMZBd9Nvu+VRjf9LOBOVPqo8uZkdmOtNjzyBkzXtLpFLH/nAuQAAAAAAAAAAAAAAAADYUUR8AAAA///s3bENACAMA0Hvv1RWo2EACpCicLeBi7SfllGNTVjjLp/B+Z0bAOCIcNBTNXgbAAAAAAAAAAAAAAAAAJ0kWQAAAP//7NzRCQAgCAVAV2uYBmm0iPZqgT4rou4m0Ifgl978VKNeUMNTcusORPmS2V+uPNYPwEySyh72MgAAAAAAAAAAAAAAAABHRMQAAAD//+zdwQnAMAgFUPcKhS6TOTJIlwmU7JVLj+2tQgjvbfBF9KbLHtXwITxFq/c4N8wFn56ebyr0q75RFoBX11G6eZfGXgYAAAAAAAAAAAAAAAAgX0RMAAAA///s3DENACAMBMCaRQjKGAi+WJBAkwbuHHz667fsUw3SGDHyG52/7AzNAX7QXTlHm2u8mAsAAAAAAAAAAAAAAACAQiJiAwAA///s3LEJACAMBMCMlmWcVNzLJqWlgujdBoEnpMnfXqrhkXG/bH3ka0PBSmVd3veyl4FvVImQIqEz3KQAAAAAAAAAAAAAAAAAnBUREwAA///s3cENACAIBDD2Mj6czEFc1iEICdF2gyN8ObqXajhirOEzOL+w6wCknDmWCZbZj+YCAAAAAAAAAAAAAAAAoIOIuAAAAP//7N3BCQAhDATA9CUHNmMfd3VYjtiXH1sIHDpTQgJLXptfl2rs7+AkaGO+5srJ2pgKNRL0p8gO4EafraeoblIAAAAAAAAAAAAAAAAA0kTEAgAA///s3EENACAMA8BJwww6EEfwxWcSIBC4c9Ck3/bqU41kxLhHq32UF4NBdlu/13N0BHzJodBW7eFsAAAAAAAAAAAAAAAAAJwUERMAAP//7NwxDQAgDATAWkMMOgkh+MICAx2AOwff/Nq/YVTDE3ee9mowvqfbOfqLoQA2FYfKUcc0WgIAAAAAAAAAAAAAAADAeRGxAAAA///s3MEJACEMBMD0JcI1Yx1XiOWIfd3HFoKHznQQyGM/u78f1ei1GNVI1MY0PsBR/HSeXovSM3CtlUnl0hxvG/M58TAAAAAAAAAAAAAAAAAANoqIDwAA///s3LEJADAIBEBHy2Yhm6dxBVHkbgKFL2ze8U810hsxxU5HiZEtMsvyXEORHMBNWunuXQ0AAAAAAAAAAAAAAACAFhHxAQAA///s3LENACAIBED2Mk7qMOpmNg5gIYXmbgPCFzT8K6UanrlzdcUavG5nuFtkmvnpXADHWi3DXZpG0RsAAAAAAAAAAAAAAAAAd0XEAgAA///s3bENACAIBED2MhZu5h4ua+MCJlJg7jaAfEIFlDiqcRYYyeU7ONXJcKLV2/y2OIALq7ehX2nMcgAAAAAAAAAAAAAAAADeiYgNAAD//+zdsQ0AIAgEQFZ3MlczJjT2mojeTUAIxVdPiVKN1K6Y4l3zO3j/fQnUlLfru/05io0AVnLpGTOPKnECAAAAAAAAAAAAAAAAYI+IGAAAAP//7NxBDQAgDATB+iJoQwhqcIYFPm0CzDg4Abc3RTWcuvMJa3AdQY0S64ONAMdmb8IPecarwwAAAAAAAAAAAAAAAAAoFhEbAAD//+zdwQnAIAxA0exVBDtMp3IZQdzLBTxqIfDeCDnlkp80UY1Wni6s8QsfwknjG7MKatzneBxg6zWWO+yiAAAAAAAAAAAAAAAAABwREQsAAP//7NyxDQAgCARANjdOZtzMhgk0JGruJoA8BdU/U6qR5hVT/K9lWQFcK290SKhc/3w/gC0K30r5RQEAAAAAAAAAAAAAAAA4FxELAAD//+zdQQ0AIAwEwfoiaEMIYrCGgj5pgMw4qIDbPhXVmL35Wl1nGTNyK0GNUgbjADnhoXPGr4cBAAAAAAAAAAAAAAAAUCQiNgAAAP//7NyxCQAgDEXB7CWCe7qsTVorMSjcDfFJk/dVVCN58K4jrMFzBDVqzd5sLsBGbqSdvGO4QwEAAAAAAAAAAAAAAAA4EhELAAD//+zdsQkAIAxFwb+XWDinyzqCIBgU7kZIkXQvP0Y1fASvJazBMwQ1ytm3ABuzt2FG17j5AAAAAAAAAAAAAAAAAJxLsgAAAP//7N0xDQAhEEXB9XVBDj7wgRyCLxoUkByEMOPgV9u9vS6qMT+Cs5ewBscJauxX01de2wywSIToJ7l1twgAAAAAAAAAAAAAAACANRExAAAA///s3MEJADAIBEE7T+shYAH5qCTMdCDc130uqpE8LvY7YQ1BA0bk9uyvl4ARwCURolLr49sAAAAAAAAAAAAAAAAAqBQRGwAA///s3MEJACAMA8CMVvdfyo8LKFgR7kYIfeTTfDmq4XHxmTKsQbd1cyX4dsaLAPYMed2hfwIAAAAAAAAAAAAAAABwJMkEAAD//+zc0QnAIAwFwOxVhC7jVF1GEPcqFheoIFJ6t0EgPPKT98lSjcHD9x5PsUauTckBS/UdU6ixTbnSUX46O8CUkZuyc43T7QkAAAAAAAAAAAAAAADAaxFxAwAA///s3NEJACAIRVE3b7Y2k6ANQqQ6ZwPB33dvjmoYLfZZo0ZhDcrs3xLU6DN/PRzgkOhbnfHqYQAAAAAAAAAAAAAAAAAUiYgEAAD//+zd0QmAMAwFwOxVhI7mHh3G1UqhC0gVLbnbIOF95Otl21IN38B/YRRrXNmXwLNmpuTqQ+0oZ9rhARa4T19VFboBAAAAAAAAAAAAAAAAcEtEdAAAAP//7N3BCQAgDASw7iU+nNNhXE0KDiCIiJCMUEp/d/22VGPxDfy9DDgOIUdO5Q6tQg279Ja7CnCg19LM7xqlWwAAAAAAAAAAAAAAAADsi4gJAAD//+zd4QkAEBCA0dtLdrOHZaUMIBLqvRXO1f36fB3VGL+Bc1+PIPSwRjELVoy3I6jxgJqTPQbYJ1B0iHsTAAAAAAAAAAAAAAAAgGkR0QAAAP//7NzBCcAwCEBRl3WODCfOlRLoADk0kMJ7I4gHL/5fRzVenhbvMbJ6ZrUwAlvWrmT1imkME7uCUBHABwSKjnIzAAAAAAAAAAAAAAAAALAnIh4AAAD//+zcsQkAIAwAwazm5K4mAQsbrRQi3EEWkBRp/O+jGj4tltQzlCCuwc4S08ixJ3WIFAHc07zlG/OGAAAAAAAAAAAAAAAAAICziBgAAAD//+zcsQ2AIBCG0duLmLAMe7CHy5AY97KBwspGEwzvjfAX1933+6hG5xF8PnnENVYfgrtynFVMY0pt31JbfQSAt/Sb6q5+I4u3AQAAAAAAAAAAAAAAAPAoIi4AAAD//+zcQQqAMAwEwP1X8W32Hz5WCXgUTxaKnXlBDkvIJfuLUo1ja32CMXhWT4/nXaTAwioDlYUkuxxMSTkRwPfs1nHcEwAAAAAAAAAAAAAAAAC8S3IBAAD//+zdsQ2AMAwAQe+FIrFZBmGZjJbGtKlAIvhuBBfu/P5FVCM5Wvy2fsc1fBavRUxjC+Nqx6g+BICn5W61X99xirYBAAAAAAAAAAAAAAAAsBQREwAA///s3M0JwCAMBtA4VxHsaJ3DZUXw6qVQiuG9EQL5uXwpmSq0gvucYQZMH0H+nNbjlOaRxjFuvfgPe+u9Xq9UNwy56fXvmAUAAAAAAAAAAAAAAAAAbEXEAAAA///s3cEJACEMBMBgrxZylSmIfR0pQPAj3MlMBSH7yWtTLtvO84EZ2JOFC62O2XwZv0dmmZlmtgo1fqMr1AA4zo16iDsSAAAAAAAAAAAAAAAAgKWIeAEAAP//7N3BCYBADATA9HUIWoyFWIfliH3JgT9/wnEkzPQQNp9syn129gk8tX7Yfzjwz2W/7vUtSVGikdNm5uaRWf+dSyu3w1CbeR9KlgEAAAAAAAAAAAAAAADwFREPAAAA///s3MEJgDAQBMB92JjFWEewMgWxr4AEUkFEw0wJe9xzd5kwll25/7eecYbtutPueCpIfpMhjWn4MYD3rEkOeQ9R2jgbAAAAAAAAAAAAAAAAAHRJKgAAAP//7N2xCYBAEATA6+v5cuzDPr4YA7EvEUxMRXhYZ0q4ZC/ajVx5twQe5yrYqNHb+vdDzKRII5Jl/8nk1Xujt8gfhmzLfmx3lvI9mQYAAAAAAAAAAAAAAADAU1WdAAAA///s3cEJwCAMBdAc3KvTdBBHk+JeUovgAvYQ3rvkrkhy+bEkPZIq+J/KvMv76esX8vZWwcmztiUalwBwSt4QwP+qnnrMmhMBAAAAAAAAAAAAAAAA4BMRAwAA///s3UENgDAQBMDz1VQOPkBH5TToghcIgJCQuxkJ+9rXbtqXd0/gZVwjGzF6W6uH8YYRjXI8+v/AMvejegZPjd7Sdhhy01E/temDAAAAAAAAAAAAAAAAANwi4gQAAP//7NyxCcAwDARALZs5MloKk72CG5POEJBRzN0Ej0Dq9DuXavRnxatAFNZTtDFxtPs9l7NkSDJ5Oi5CqcZ3SjX4M7ufx20AAAAAAAAAAAAAAAAAYIiIBwAA///s3bEJwDAMBEDtFTxc5sgyGs2QuDApDYFY3HVqhcDVv0uHzvwEzss5jXm1IysvaBTLzPevPIObwPF/CNavc8fsbJRbeZe/oTgKAAAAAAAAAAAAAAAAgEdEdAAAAP//7NyxCQAhEEXB7UyuNCuztePASAxEOFhlpoJNNvzv9qjGFxRoCU7hDHVyZcr4Rh/jjoqIDAuMjRMR1dgnqsHp/P+vntvjaQAAAAAAAAAAAAAAAAAsiIgXAAD//+zdsQnAIBBA0SuyWIZxjuBmAXGvYC8YCIKY9/prxMLmvsfO59SW6VKp2U/gvNS7J1cqdTTdi3F8IY7BLLegBsAyTvG3adqbTlQDAAAAAAAAAAAAAAAA4O8i4gEAAP//7N3BCQAhDEXB9CWWY1UWswexL8ESBEE2M038nPJSVN6VwAE25f7H2KdzvZYUNwz/1sb8PNK6xuYBAAAAAAAAAAAAAAAAZBcRCwAA///s20ENACAMA8AFZ0hDGUjDwj6EBe4UdO177ZMOeoEMADctz8UA5QyTHDMfvQsAAAAAAAAAAAAAAACArIjYAAAA///s3DENACAQA8D3RZCDD3wgh+CLhZ2JhMCdg25d2i9ONdaQ3Jgc+FbLybkQwGV01LNKH/XlfAAAAAAAAAAAAAAAAABsRMQEAAD//+zcsQ0AIAwDsHyO+JwTmJBQY3+QTlnSiqcaMSgHuu32AwD8Skd9ag3OBgAAAAAAAAAAAAAAAMBNkgMAAP//7N2xCQAhEATA60ssx6osRuH5vkzMjQTRmQ42u2T3nhnVmBTLgdf0mpNP/QBnc6NuUr6/XRkMAAAAAAAAAAAAAAAAgLWIGAAAAP//7NwxDQAgEAPAl/Zm8ElC8MXCygghcKegFdB+daoxh+X1gigApxhqA1zO+dFWWVrPh/sBAAAAAAAAAAAAAAAAsBIRAwAA///s3KENACAQA8DfiyCYjDAHy2LQOAT83QZNdZvqVGMzMAeyGLMWR0IAb2h6uqZ/mgsAAAAAAAAAAAAAAACAk4hYAAAA///s3LENgDAMAEHvhZC8TPZgD5aJhNgrjWs6iiR3G1hu3Pi3i2rUg7mwBrC6fp/HZcsAc4oWKxIAACAASURBVKgbVQjpH9meN1ccDAAAAAAAAAAAAAAAAIAPETHYuUMDAEAYBmA9fZ/xGmIaiWAkH9TUtd+daqRHi2W0CAznPAjgPbr7njU1GAAAAAAAAAAAAAAAAAAHSTYAAAD//+zcsRGAIBBFwevLIbAY+5A6KMehLwIMSZlB2a3gLvnh2zKqET2scS5wBsAMuaRDOAjgY97ttt+TXE+9f/kYAAAAAAAAAAAAAAAAAGMR0QAAAP//7NxBDcAgFETB74s0wQw6EFIzJARfXHqoAQ7AjIMVsO/aqMZHWAM4TXuf5DQMsCnht6Vq6SMfvA8AAAAAAAAAAAAAAACAv4iYAAAA///s3bENADAMAjA+j/p59+5diP0BygxZParhGzjQRhkboMJxxm+mNBcAAAAAAAAAAAAAAAAAryQXAAD//+zcQQ0AIQxFwfoiJJjBx/pADsEXRzDApTvjoOn5v19HNeIM0IU1gAwENQASGLV8/vhM63O1pLcBAAAAAAAAAAAAAAAAcIuIDQAA///s3TERACAMBMH4YtDGoAOzNCkwQEHYdfAG7r+PaiRv4MDr5upNIAigDqGke0bVYQAAAAAAAAAAAAAAAAAcImIDAAD//+zdQQ0AIQwEwPoil2AGH/g4MyQEXzzAAg/IjIU+up9ulWqsb+DN4SJwsfZ/qRogwDt2PlWWdEYufdibAAAAAAAAAAAAAAAAAK+LiAkAAP//7NwxDQAgEAPA+iJoI+jALAtIYOBz56Dp3DrVOAwXgV+t3pwCAdQ09frMKJoLAAAAAAAAAAAAAAAAgCvJBgAA///s3DERACAQA8GYxQfeGHzRUGCAgmfXQQTkRDUO+5gurAG8RFADoCjRt7vamL3yPgAAAAAAAAAAAAAAAIDvJVkAAAD//+zcMREAIAwDwEoDMehAHIcvlk7sDPT+JWTKkjjVuDjWAD7Sc3ANQFHZTXljjrWbbAEAAAAAAAAAAAAAAACKiogDAAD//+zcsQ0AIBACQDY3buZotha2nxj/bgLoqHCqcTdfDAVwWA41ANqwTeuMX4sBAAAAAAAAAAAAAAAAtJdkAwAA///s3cEJgDAMBdDsJYUs4x7u0XFK9xLBo9dCMe9tEAL/lh+lGh/eQ3VfwYFdPYUaMgqgiN6Oy66XyXPM/OlsAAAAAAAAAAAAAAAAALVFxA0AAP//7NyxDQBACAOxbM7qPwElEnrsDdKkPFGNhrAGsJSgBsBNvn9O/ToMAAAAAAAAAAAAAAAA4LQkDwAA///s3LEJQCEMQMGM5jLuoZt9EPeysbYT5OdugoQ0qZ6oxsEOa/RnBwTSEdQAyGn/pZ/zX1HqmO2HewEAAAAAAAAAAAAAAADkFhELAAD//+zcQQ0AIBADwfoiaAMfmEUCLxLCzTiogK6oxsHqbTowAo8Q1ACoTeztnvHrMAAAAAAAAAAAAAAAAICykmwAAAD//+zcMQ1AIRQDwOeLMCAGVYj5A8EXCwJYCMnnzkGXdqtTjQ0tp+JYA7istJz0EMDD1g7YgkNqH98vgwEAAAAAAAAAAAAAAAC8KiImAAAA///s3LEJACAUQ8GM9pdxUnEvQRzARgS5GyFVqieqcUhYA3hIUAOAZX9S7qjWR9kWAAAAAAAAAAAAAAAA4BNJJgAAAP//7NyxDQAgDANBbx6xOT0dBYoU7jawB3hRjQvCGkADQQ0ATssjz9TQXQAAAAAAAAAAAAAAAAD/SbIBAAD//+zcMQ0AIRREwe+LkGAGH/hADsEXAqgooLibcbAr4IlqHBLWAB4S1ABg03NqXrmm1DHLR7cBAAAAAAAAAAAAAAAA/EtELAAAAP//7NxBEQAgDAPBWK8yrOGABzP0UXYdJAJOVOOCsAbQQFADgJPyzjNr6C4AAAAAAAAAAAAAAACAvyTZAAAA///s3DENACAQBMH3RZCDj/eBHIIvHFCQ0MCMg+uuWlGNQ8IawEWCGgBs9VrSF72njZmvbgMAAAAAAAAAAAAAAAD4RkQsAAAA///s3EENADAMA7Ewr8Z8FCZN/bQ2gwTAiWp8ENYAGghqAPDqeKpNDd0FAAAAAAAAAAAAAAAAsEeSCwAA///s3LERABAABMFvVp0Coy+JAswgYbeDjz47UY1NwhrAQYIaACybn+E3Limt1yeHAQAAAAAAAAAAAAAAAPwiyQAAAP//7NxBDQAgDATBSqsZhKCN4AsPTfk0Mw7uBKyoRgNhDaCBoAYAFdtr3+Q6N4duAwAAAAAAAAAAAAAAAJgvIh4AAAD//+zcoREAMAwDMW+e1Us6QdOQnLSBkdmLanwirAE0CGoA8OT+h7DGnNo6DAAAAAAAAAAAAAAAAGC9JAcAAP//7NxBDYAwEETR9dWQbMXgAx/IIfjiUgdtOWzeczAj4ItqLDTCGr3MIOAPghoATLmPdnlwmzyfN4tuAwAAAAAAAAAAAAAAAKgtIj4AAAD//+zcMREAIAwEwaCLQRw6EAPSaOhpQsPsOkj6P1GNZGccL6wB3KzRahHUACBJ98hn5qd3AQAAAAAAAAAAAAAAAPwtIjYAAAD//+zcMQ0AIAwAwfoiyMEHPpBD8EWqgAUWcuegHdrtRTUeENYADjKo4UYAcM2oped/sdE32lz9x7kAAAAAAAAAAAAAAAAAvhYRGwAA///s3LENgDAMRUEzF0JimcyBPAfjRNkL0aZ3Y91tYPf/iWoU+cMa73Uexo3AJgU1ACiSHlvmGXPdTW8DAAAAAAAAAAAAAAAA6CkiPgAAAP//7N0xDQAwCABBfDUdqqxCarYhwQILuXPAxsIjqtGsjueFNYB03l4+3QPQIqNu9s5Wd/BsAAAAAAAAAAAAAAAAAPNExAcAAP//7NwxDQAgDEXBSgMxCMEZCcEXCysjDM2dg9+9T1TjgxPWqOmHAjfjBDU8OgPwWnfhZ0qbqyTdBgAAAAAAAAAAAAAAAJBPRGwAAAD//+zdMQ0AMAgAQaxVWa1VWtMECzDQOwdMTDyiGk3ymH75Hg7fOS+sI6gBQIfcN8IadfbUwQAAAAAAAAAAAAAAAADGiYgLAAD//+zcUQnAMBAD0PNVCjUzH6uOyRn1NQ5qYQdj70kI5DNxqlEoR445rnesAb8xd+cBoMzV2ynt14zjXvIFAAAAAAAAAAAAAAAA+IKIeAAAAP//7NzBCQAgDATBtGZlYuci2EIIHDMdJP89oxoDfmQvtIdcbzhniZoBGHQ8v80OvQsAAAAAAAAAAAAAAAAgS1VdAAAA///s3FEJwDAMRdH4KpNTVTUTGPM1CrFQWrZzJATC+7uiGpuMq2WFNfKXB4DvyhnOqR8HgC0q7GSLFun3I5wFAAAAAAAAAAAAAAAAcLqIeAEAAP//7N1RCQAgDAXARdMw5jCc2EsEK4gy7hrsY/B+3uaoxkO7dL/L9z6JQxr17DQA/EDGvKe3MUvW4QAAAAAAAAAAAAAAAABSiIgFAAD//+zdwQkAMAgDQDtaJ+vqRXCFgpW7DcRHfolSjQZqSXxbE4dvZUHOyqIcLwSgi8ol2fTOmXoYAAAAAAAAAAAAAAAAwAgRcQEAAP//7N3BCYBADATA9CUHSTFWdeUc9iWCLQg5melgH4F8slGq0cRz9DjHUT6Kw3bqnV0A6Mhu+Z0815V/DQcAAAAAAAAAAAAAAACwvYi4AQAA///s3cEJACEMAMFYl1ib14fNSsAWhHjMdBB85JVVVKOYNfqXR/p+FYfyMoTTMojjqQCo6uwpYY175l8HAwAAAAAAAAAAAAAAAHheRGwAAAD//+zc0QnAIAwFwOxVBB2me7iH44h7ieAQabmbIAQC+XlPqUZCJ/w4ytNuuQaQywknt3ujAPCF37InGOOv6juX/QIAAAAAAAAAAAAAAABkFBEbAAD//+zdwQkAMAgEQVN5SOchYAuChpkO/PnaE9VoLOMay7o4tHFeTCNX/wFgEv9knf3rYQAAAAAAAAAAAAAAAACjRcQFAAD//+zdsQnAMAwEwF8tw3hOF8F7GYxWCEHmbgNVUqN/oRoNVLv4k8QjP/zjBNxo+gegq9phbsmPjHfNKwcDAAAAAAAAAAAAAAAA6CzJBgAA///s3NEJwCAMBNDsJQUdpoN0jo5T3EsEV6gQeW+DEO7zzqhGEu9VZqm/GdeArWbW2soeAGT3+OBv6v31euhtAAAAAAAAAAAAAAAAADlFxAAAAP//7NzBCQAwCAPAbN7VS6GULuBDudtAQfIySjWa+co1PEVCnVemcW7OngGY4GaaXKuzpg4GAAAAAAAAAAAAAAAA0FKSDQAA///s3EENwCAQRNGtLrIJZvABOpDT1FdNwAHynoO5zemLahxqZukzyyOuAcsNMQ0ALuY77lPb+9VbxwEAAAAAAAAAAAAAAAAcJyJ+AAAA///s3MEJADAIBMFL/0WltSCkhOShzHSgIPhaUY3mxDXgmYpprLopKwVgqhuN8jf+s6cOBgAAAAAAAAAAAAAAANBOkgMAAP//7NzBCcAgEATAs1jrCKlNrMsg2EAEMZiZEvZgudcmVztLLrUPAlx/zwFeuA1psEsutQl/zhiUAibpn6X8FgAAAAAAAAAAAAAAAABfEBEPAAAA///s3bEJACAMRcGv+w/laCKktRRE71ZIk+Yl3SDesgK+Co19IIe9UcFrE70C8Cm74jkO3AEAAAAAAAAAAAAAAADcIMkEAAD//+zdwQmAMAwF0OwlQh2mUzmMhdK59NKDZ0XQ+t4GSS655MeX98Hl2lI/7Et/7wWcwjSKZvAGubbdIK7pAVLADbm2zY74mLLO0zJobQAAAAAAAAAAAAAAAADfEBEHAAAA///s3NEJACAIQEFpshqtzUOQNoig7kYw/ew1T/W2jAfUh75RQQH4Ue7+yFsQ1ACAbRrFMb3idgAAAAAAAAAAAAAAAADcEhELAAD//+zdwQ2AIBAEwOuLUA51iHVQjA9CXRofNmA0mjBTwu7nXnu+vE+o9FEjYpk9B6awtpyqqvmr0seunHtaTm4YeEDpYzsHIGT5imvcDgAAAAAAAAAAAAAAAIAvRMQBAAD//+zcsQkAIBADwMfJdDQ3czR5sLcSQe9GCGmTIvj/5MnAGiPnyG/8ngfPyU637LhDDQDY6iI6pq4zOwAAAAAAAAAAAAAAAABuiIgJAAD//+zd0QnAIAwFwGzmNM4hnU2cS6FkArEU4W6EBEJ+8uLLO688+Cs+lXOxR4gGt6l9TE3bk+FQwAG5Bza1/IZ5BQAAAAAAAAAAAAAAAPCTiFgAAAD//+zdwQmAMBAEwOtLAjZjVTYTCPYVAvn4lQQ5mGlh4X67p+DFy9Wecw5rKFaSwfiuX+9yVGmRkVGN75TUYS33aCvDXwAAAAAAAAAAAAAAAAB/iIgOAAD//+zcQQ0AIBADwbOGGHzgjeALBfchQAiZUdFP1yGVlMAGjxLS4BtO7OtENWCv2kez+Y4qtgsAAAAAAAAAAAAAAADAZRExAQAA///s3LEJACAMRcGs5jDOaSHuJYIDiIiC3I2Q6jd5HlJZIrDBY0IafElUY5+oBpyXaytz73He2DHJXQEAAAAAAAAAAAAAAAAuiogOAAD//+zcsQkAIAxFwWwmTi5uJoKFraIWcjdCqjT/GaSybApsJMNLLunxjCqkwe9ENfaJasB548crTntN9tcAAAAAAAAAAAAAAAAAPBQRDQAA///s3MEJwCAQBMBrLcVYR0xlPsS+QjAVKEIwMwUc3P53FVKZlmrL741Tmky4ohflsxD5C6Ma44xqwBqptmI0bZlnLOzY9DcAAAAAAAAAAAAAAACA74mIGwAA///s3bEJwDAMBEBt5mk8SCYzwXivIFAfCHGa3I2gSs3/C6TyuirZaAKZ3Mil9rMCplbb+SWlGs8p1YA9+lz5vw3n3eZQIAYAAAAAAAAAAAAAAADwkYi4AAAA///s3KENADAIRUE27+o11FQ2+ZjejYAgGJ6HVKL6MfPENZZpf01EAy6iGu9ENSCnA2nuthD7CwAAAAAAAAAAAAAAAGBIVW0AAAD//+zdsQ0AIAgAQTZzNjc3RgsbGxMozN0QhOZB0EW5HWpO7Ti4wX96rHDUN3a4cFTjnSgdcplPqbr9CAAAAAAAAAAAAAAAAKBARAwAAAD//+zcQREAIBACQHo5hjOHZS6aHzuo424D+INBKldwtPG8sQPU7K1+LwMAAAAAAAAAAAAAAAAAAIDDkiwAAAD//+zdsQ0AQAwCMTb/1aMUL2UECnsF+kNUg1ontLGepSr8eEY8rAMAAAAAAAAAAAAAAAAAAFAryQAAAP//7NxBCcAwAATBlRYz9dkQ6iuvQgX0E5gRcJyCFdXgONd6RjU+vwU3/nVX810UzwAAAAAAAAAAAAAAAAAAAOA41QYAAP//7NxRCQAgEETB6yViGoOYwzKC2Mv/i6AzDXYDPFENntP3yRGIliIcvxtp/5q1rN9PAQAAAAAAAAAAAAAAAAAA4CERcQEAAP//7NwxDQAwDASx588qzKoO3VIAUez1OJypBms1841n0oTjzjDq18wyAAAAAAAAAAAAAAAAAAAAWCnJAQAA///s3DEBAAAMAiD7p16DHfpCEKQaMHpyjpYMAwAAAAAAAAAAAAAAAAAAABZJDgAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDZPHNhQAAIABJREFUAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Uo19OCABAABgGLT+qd/jKCgAAAAAAAAAAAAAAAAAAAAAX6oBAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///s0gENwCAUQ8Hi7FuAGcLQhkVckIXcKXhJ20wKAAAAAAAAAAAAAAAAAAD8SX9GJanTSev9piMAXCLJBgAA///s3EEBABAABMFrJgMK00wEfPjMFNgGa6oBAAAAAAAAAAAAAAAAAABcqb2dzCfKjzHGJyPJ3KVNOwAeSrIAAAD//+zcMQ0AAAgDsPlXjQI4uEhohVSqAQAAAAAAAAAAAAAAAAAATw05xqcQ44o25pBxACwkKQAAAP//7NwxEQAwCASwl1YLBf9eunREAZcIiVQDAAAAAAAAAAAAAAAAAAAWuV1nCDEkGfuMCYeAA+BL8gAAAP//7NyxDQAwCASx35zVMwCCPsJe4foz1QAAAAAAAAAAAAAAAAAAgE8Mw4zSj0WbbxhvACckeQAAAP//7NxBDQAgEASxtQinCOd8CX+SC2kFjIQx1QAAAAAAAAAAAAAAAAAAgEZGzXt4YJrBa+vsm24AX0iyAQAA///s3LENwCAAA8HfjIwOm1GlyQARSHcTWHL/ohoAAAAAAAAAAAAAAAAAAPCzTzhjVI8PONSs1jtNcAO4RrUBAAD//+zcsQkAAAgEsd/c1e3tBZFkhBvgTDUAAAAAAAAAAAAAAAAAAGDJmGeUzjxjuAHclaQBAAD//+zcoQEAAAjDsL3O5ygUEoFJZI+oqQYAAAAAAAAAAAAAAAAAAByZZ8BSE8w2gBdJGgAA///s3DEBwCAAA8FIwwKgs2ABaV3KXga2uzlTBLyoBgAAAAAAAAAAAAAAAAAA/FR7K0nKtxbPgHM7trHmM5b/gGuSvAAAAP//7NxBDQAgEAPBSscQoAFn5P73JLxmDDSpgBXVAAAAAAAAAAAAAAAAAACAhoAGfFNxjVNje67hduCJJBcAAP//7NxBDQAACACh65/aEH7chCBINQAAAAAAAAAAAAAAAAAAeE+gAeeINoCdagAAAP//7NyxEcIwDABAb8YxgpIMBPsEPAJsFppUaYDzBZzTf+3KLiRLtv46VCPG4SKpoNFVEAQA9hDjsNhYfkxuC3AQm4bZO6cv1gJAt+rtnnpQe0yhTkA25zrXp1MHgP3EFA91I7Koc819p9R7pkPZaz0A0MI/GHojtwNot8b34r0fHIpBG8DnSikvAAAA///s3MEJgDAQBMA8bPDUfkIKUluwND9G9CP4EAzOlHAhEMjedsZF43IM/bpMs1AfAAAA8NhNQYYADABwVrwP+Jm8B1AAgBfEGE9KW6F1xQkCAAAA8CWnEg05AGjX8dcSQ1/vci3asHMMXKWUNgAAAP//7N3dCYAgFAZQR2uFoIEayLoj1GhhINhrEIGes4GK4O93hWrQg1K5Q7ImAAAA8NBcfFVS5AGAVyLHOi+ztQQjmcpn38jhkQkAfOPQrwziLPspgw0AAADAX5rCW+78oX91vpdi/rWxd/BzbLuzahhZSukCAAD//+zdwQ2AIBAEQFqzBMCGKAgtwdiZkYTE+MeHzLSwz9vsGdXgF2JOx163RZoAAAAwj8exq7MaDwCMVBRsmIxhewAYIK5RaZOZFGkDAAAA8CUjGsBL6xbHnHrH+H4ucrZR6Lp5NAKzCCFcAAAA///s3bENgCAQBdAbzRUA93EhE1ZgNENBY2OjMYH3VqDg4I6PUA1msfWC1yYGAAAA87mFZ2h0AQC/qGdtaU9NLcJK+qNfP4sDwOsEw7KK1s9RVhsAAACAr6WSR0/T/SvwZMwkH6nkELIBi4iICwAA///s3bENACAIAEFWZ3NDZ68mKncjaEOieUQ1+IltWQAAAPC46XFLPAMAuFGaUWimPp2JagDAJhWscpY0ki4bAAAAgBOmRV0iGsAqkQ3oICIGAAAA///s3VENgDAMBcBZQ0JhhuYHmASskSU4ABLY7iz0q8nrq1INuhLLfNRtn0wVAAAAvk+BBgDwN+3LcuQogjmMpB3/1rU6AAaAmyKHgDcjKW1/MnEAAAAAnnLlDWUNgbcp2YAepZROAAAA///s3LENwCAMAEGPlhUssU9WYzTkjp6CBO6WABn8ohqc5qnSnMMJAAAAvmUqw3vUAgB+reIC2dIyJDd5s2W3FAkAy9whuYYoGwAAAACrpj+HZqvATiIbcIKIGAAAAP//7NzBEUAwFEXRrzNKCPoxCkIJWjNm2FhmI5Oc08LfJW+uqAY1OiOic1kAAAD4j4gGAFC51XCHxizPMAQAyJDm1HsjoyGDYwMAAACQI03jG2v1Hw+U6hvZuDdEcWy72DSULCIuAAAA///s3dERQDAQBcCUpoWIMklKQGdGhgL4MMhuFTf3kndKNfilmPq5TFlACwAAAA9RogEAtGS/uhyHaO6hJd3+GbiMRbEGANzjATitWMyMAAAAAFxxFGnI34GvqhlQTP15rGStu/Ip25XDm4QQNgAAAP//7Ny7DYBACABQRnMFdSC9gdQVzRXUxsKYHO+tQAHh56kGo5r6MY/EAwAAAN8xzAIAimvqIIrJBRAA4IX+mErdSCFNsAEAAAB4YvcQGFTOhLZ5XSJ75tdx7gIOP4uIGwAA///s3UEKgCAQBdDpZl3B6r7azcLAZQshCJr3jjBuRMb/hWrwZzUiFicMAAAA7+gBluOx10gBgOx6+3I5SrPkQyJr/xSseRwAplUjI4nmrggAAADAE0EaQEL3vnXZt1FicgrYgI9ExAUAAP//7NzBDUBAFEXRaU0JHw3pB1OC0ogJYiMRCwvOKWH+apKXK6rBp0VTT3kYK1cGAACAZ4Q0AACu5T5X0cbsifiRfegBANwQbRhG8hvr/8i1AQAAADgT0gA4lD32FthYdSVWPYw2GPCGlNICAAD//+zcsQ3AMAgEQEbzCokHiryPJa8YsQFuUsR3K1DwEuKVavB3uWSaxQIAAAB1ijQAALYMuYmDtHwOXnN5EAaAGjmRUwyTBgAAACAUaQBU5Q3pufodCjbgAxHxAgAA///s3LEJgEAQRcFviYJtqiWonclmJiKo2c6UsHfBsRxPVIMOtiSDkwYAAIB7QhoAAO9UXGCcRm8oOqn7LqoBAA8qRGVGNLGLrgEAAAD05v8hwCfXwEaFNY51Xuzd4U9JTgAAAP//7Ny5DYAwEARAt+YSzqYfoCCgBFpDICQiMmc308Jm96xSDVKI3s5j26u0AQAA4GORBQAwTH1LviGF+0nY4yQA/IspzNzIZJU2AAAAQE7R22IWCjDUc9sdvc0KNmCgUsoFAAD//+zcwQ2AMAgFUDbTFZo4ptoVGM006dWTphfeW4FDgf7gqAZVjEdk79edKg4AAEB18yNrm4tXAAA+6mfPdrTUX1HICG8IbQDAOyFyqsgxD6k2AAAAQB3yhwDLOLABf4mIBwAA///s3cEJgDAQBMCzMy3hIA2lHyEl2JoE/PgWEbyZFvYTjmVjVINK5g9xi8QBAACoaI5NXsdVhX4AgHd0pSEqyZbH2McmdAC4y5ardyGFdGEDAAAA/J/+IcDnDGzAExFxAgAA///s3csNgCAMAFDiZK4ALKSTMZpG04snTibGvjcCTUj6gS4OkExqb0PAAQAAyORqZkU+PDS0AADeE9uZbWgmkzUeDQMAT2pwZLFHHgQAAADAT9XeNvOHAJ9zf3JUezvinja7ATOllBMAAP//7N3BCYAwDAXQHhxMRyi4j7hPNSMqhYIXz4LtexOUHJvkZ1IkBlMXieY4Tg1dAAAAulY/STWxAAC+FSWWvOZL2RnIJkwGAB4tcMrgIkOIEi7gAQAAAHSoLWfP5g8BfmFrARv1rXud4bA/DS9SSjcAAAD//+zdgQmAMAwEwOBkrqBO5GQZTQnGGcT2boQUCm0/6aIuTCgtOgAAAKPqicOXBy0AgM+cSs9E1m4eBgAeMinMwrkHAAAAYDA1TGM79ux7TvlDgP+pvTsrR96fMwKviLgBAAD//+zdWw2AMAwAwH3giyChgB8UbVgAZ2QJaCBZ7ySsP+3Sx+QxyKgn+Gdti+ADAAAwgncz/OEKJgDA//q15thjlpuRSK9FXDkBIL3YQ3MiWVy97hFtAAAAgDG8g9eWaACM5Yht/fo57rM2//rkVkp5AAAA///s3dENgDAIBUDSyVjBuv8sNRq+nEDL3Qh8kNDA62hfAbrKOjgCAACA33olw5tzAQC+w6/NdJKOiAHgYemcLsw7AAAAABu4wzSOcy5vmwBbywrYWNX37ZvTU0RcAAAA///s3NEJwCAMBUALXVDoPtJ92rqCo5WAQyi5G8H4YYy+U+lJLD4cHTYAAAAAu5kXmk2QBgDAmvrTR73qcF4jkehPBGsAkJaAKRIZ0e8oOAAAAMCevD0ESK3NgI1Yg7u/n/kWeZRSfgAAAP//7N3RCcAgDAXA4Gbdt+AIHa0SyEdH0OZuhXxIUN8bxk1n1eYLAAAAx6hd9nGpBQCwPe3NtOIzMQDNaXKkhXnPy6QBAAAAzpNhGt4eAvCR4Rpvng0VuAT/FhELAAD//+zdWxGAMAwEwEjDQgBBOKs1pjP5RUDIroh2+sidUA2mOyz4AAAAdJDX+ezLSw9aAAA9VHuzYA0mMUwMwEh5p0IXpnC+AQAAAGim/h0K0wDgy94bVgVsKFPhvyLiBQAA///s3LENwCAMBECPxgpI7MNCkVgxRShQqpQB3w2BZON/pRrwPPiGAgAAAH5pKdMQUAMA2My4hs9mUhEqBiCb2mpxiE4W5hsAAACAfbzuDu0wAfiiz3INmWvOExE3AAAA///s3cENACAIBDBG08ldzRgZwYdKuwIvCBxCNWBzmAQAAMBV1jAyE+L1rAAAb/PNmUpaHhcDQBVmd1TRVRoAAADgfp54AXDA2vsYGbAhcJs/RMQEAAD//+zd0QnAIAxAwYzmZl2o4Ah1NCnmowsUlNytIAhReYpqwNJs7gAAAOzgE9N4FOIBAM6XvzkPS0khHugBUEKGpJzfUcHodzfTAAAAAGxMTAOAn1wZ13gjG+7FOFdETAAAAP//7NyBCcAgDADBjNbNbCfralIIuIFtk7sRFAJCfFENWIahDgAAwJsy+CimAQBQz+VOaeTIT8YAUJ3ldLrwngEAAAD4KDENADZ59kDujGucDp3fiYgJAAD//+zd0QnAIAwFwKwodB8dzdFKwB8XsFXvlggvgRelGjATIAAAAFguSx5zySiXAgCcaXx19tmZm8g2ABytPKUpxuUSfeQZAAAAAH5EmQYAH8n7WM0ZpFyDrUTECwAA///s3dEJwCAMBcCMZkcQOmbBEVxNBPvRBUrQuxUCgQfhRakGfBWLHAAAgD+tMo3uCB8AYG/taZcRc5BS7yrjALAzh+ocQY4BAAAAyEWZBgCJvOUafT6YNBhSi4gBAAD//+zdwQkAIQwEwLQoXD9ylaW1Q/DnWwiXmRYCwmLYKNWA0/SAAwAAcNvKnvtzSwYFAOjjNWsaScMG4I/GMxxroQv5BQAAAKCIvW+YyjQAKGjtwqdyDUqLiA8AAP//7N2xDYAwDARArwhZM1JGIJuFBiQKWpQI321h2f9WqgHvDBgAAAB85lpuCZgBACTTahPAJBWhYwB+yk0JGXTzCwAAAMB8jzKNwwMvABZ3l2uMrex2DKwlIk4AAAD//+zcsQ3AIAwEQI9GRkBinyib01JQIhHw3QovuXn5jWrAXHG0AQAAWG0ouJRbAAB5PbInEU/HAFyltmoolyw+SQMAAADsY0wDgMO9xjX4lYjoAAAA///s3csJwCAMANCM1hUCjllwBUcrgvTWW0Ew743gIZCvjmrAtxm0JR0AAAD8YhUFNbgAAIrrdx/z1+fq70Ad2dKABABHyJaX2h5FjJW3AAAAALCBWUMADvIe17CvzVYR8QAAAP//7N2xDQAgCARANnc0R9OYYGtjYdS7JQgEHqEasOZ7FgAAANsyMV6PCQDA5OszPyl5hAwAtzPf4xf6FQAAAIAD8uC4mUUC8KBR2+rYqReuwRER0QEAAP//7N3BCcAgEATAK83W7FwCi0/BT0K4mS5cj12lGnA20u4HAAAA157QL59cwj8AALasPlt+phOHfwD8WgqiZHx0MPNeAQAAAOAluTM03AVAB0O5Bp+oqgUAAP//7N2xCcAwDABBjZZMloUMGsGrpVFpMGkMQXcjqFBlv0Q1YO+xnAEAAPiqIo3T4AAAWMmRt8HQyFWfkQHgrzxmp4Uc6fgQAAAAwEEV05iivgA0I67BWRHxAgAA///s3cENwDAIBDBWJOlAzeSJugGvSBX2CPxAp0OpBtQIRwAAAFCmNR4AgKJlUDRiRwLgl/LJV6CdJhT/AQAAAFzyPe3KObbbIwDNKdfgjog4AAAA///s3cEJwCAMBdCM5gpCxyy4gqNJITeh7cWD+N4IuSWQ/4VqwD8lG4YBAADgVQZqOOoBAPApW6C7SXGIUq9qVwJgR4KhOEFvd7ObAAAAACz2PAwr7QKAiXAN1oqIAQAA///s3cEJACAIBVBXDNonmqzVungN6tAhem8EBUGEr1AN2NcMYwAAAFby2CU5HgCAU13F+MjQbABeUmrxgIVf2EsAAAAALsswDU+7AGBNuAZ3RMQEAAD//+zdsQ0AIAgEQPafytFsvrMi0cJwtwUE/oVqQI8UQAAAAA5Z2nkOAwCgLW3QGqEZw3MyAJ9xJ8IEK3MJAAAAAA8o7AKANuEa3FVVGwAA///s3bEJACAMAMGs5r6CI7iaCGKvpBHvVkglJK+oBpyZjxiLfgAAAGyCGgAAJPArND9xnAzAE4Sg+EWrrRg2AAAAQL4V0+j2CwHgmrgGOSJiAAAA///s3cEJACEMBMCUZguC/VjatXYP04AEQXCmiEBYslGqAfum4QsAAECs0EvgBQBAWX6FVqzBMxwpA3C7PnpTBMUj7CEAAAAAB+RT5y+PgQGAGuUa1ETEDwAA///s3MEJADAIA0A370KFrlgKTiA+Ct5toSQxqgE1ghMAAADD5aCGpxwAAC3OPkYGmGRlWRkAfiUXwgjuEAAAAIBer+ib2UI/RgDoZ1yDmoi4AAAA///s3bEJACAMAMGMpvsvZROsRQwIuRtBuxBfUQ24M7IYCAAAQEOCGgAAFPFLNJ1YJATgSxl+Mvujg+mWAQAAAN7Jt2Z2CwGg3o5rOGuORMQCAAD//+zdwQnAIAxA0YzmZl2o4ApuVhFy7UXaUsh7I3gRxXxFNWDfoWQEAABQj6AGAABvyV+ihwWmiJZDywDwN8JPVDD62Z09AAAAAB6w5svyXaG7RQD41tqDrwxbwb2ImAAAAP//7Ny7DQAgCAVANjdubkNtI1ET7kag4/eEasAZzQ4AAEAjAjUAALhgKjKN2LUB8JUMfDL/owN9BwAAAECBfOJ1VwgAbw3hGmxFxAIAAP//7N3BCQAgCAVQR2u1Jmu1LnboLETgeysIgqBfoRpQMzRZAACAHgRqAADwQn6L9jGaLkYeLwPAL5ZK0MDMuQMAAACAgtwpFCIPAP844Rp2UbhFxAYAAP//7N3RCcAwCAVAV8sIge6ThQKO0NWKP10gUEJzN4KIXz51VAPWDQMWAADg3xzUAADgSzmzKTgHEV4GYAv96p6qcIScqdcBAAAAFlSOrAK7dgoBYFt37f/LfvOKiAcAAP//7NzRCQAgCEBBR2u1Nu8nWiAhybsR/BP0iWpADlVBAACATwlqAADwyDR4uvDEDEARbj/owJ4BAAAAcGHfE4rGA0B9Q1yDIyIWAAAA///s3YEJACAIBEBHa/RGi6AWiEDKuy0e9VWqAXe0FYoAAAD4iEINAACy+B5NMY6YAUil4IkiupwBAAAAcGYe49onBIAn7XINM5LKImIAAAD//+zcyQ2AMAwEQJcWSjDQT0TlyYcGkJA4PNPCPu1doxpwn2atCAAA4D8cwAAAeIFFCFShzAzAU3LPZuCJIg5BAwAAAFx3lnD9EwLAt/Xc1mFco6iImAAAAP//7N3RCcAgDAXArNh2TcERdLQiuECh0GruRogfIWKeQjXgXU09AQAA1idQAwCAP6il9vGbtMMgCcvMAHxFDyKDPucLAAAAAB6YbwndIQLAPka4Rjuu065AJhFxAwAA///s3dEJgDAMBcCs5giBjil0BFeTQAfwQ0TN3Qr9KH1pEkM14GbrsQQAAMBHrYBMSAYAwFvYJk0bOVKdDYBH5UhZIC3MfW5OGgAAAOC6+kdY2+zlhwDwS3W/H/rBG4mIEwAA///s3dEJwCAMBcCM5gq2C3V0oWQBQUo1dyv4lWDeE6oB6zUJRQAAAHvKec5yDACA38g2aY3SVNHyuBkAvqJhkgoE9QEAAABM8I8QAMp4Q7T6fT2e/HARMQAAAP//7N3bCQAgCAVQN2+hoBUjcIB+ih7nTKGoV6EasIbGCQAA4DIGYQAAnMpXaT7juBmALTLISZgTz2u1WQQFAAAAmJQf6+0RAsBfyqgB8p6AF0VEBwAA///s3cENACAIBDBGc/+pjIYB/JCotFsc5MBRDSiSIQoAAIB3yHEAANzH14WgAAAgAElEQVTMd2m6GFlyBoBq5oF04EAfAAAAwIFVos0umD0VAPS0H3Tqhn8qIiZ7d3ADIAhDAbSjuQLqPjKQCSuwmV5690Si8t4I9FSa/grVgHEWqUQAAADf4PMLAIC3y+vSXaGYxKHQAIxU9lI9MBPo7Wx6CAAAAIAHuf8lUAMAiNwNv8q2mif+SUTcAAAA///s3LEJACAMRcGM5mbi5iKksrESlNytkCrF+0Y14C5RFgAAwOOsywMA8JHhWBTRxM4AXGbAiQr8DwAAAAAHGczqvwCAXV+dQY5v8buImAAAAP//7N3BDQAgCAQw9l9KRzMmfH2SqLRbADnOUw0opu0YAADgXnkQs+gCAOAJ2TKtaZouhJ0BKOFxE03MnB8AAAAAOMjMl5sUAHCycwZDTvwDEbEAAAD//+zdwQnAIBAAwStNSxAsM2CJCYLfQB4RFGda8OXJnpZqwHzJJiIAAID1jLuaBzEAAHbjt2mOIXoG4G+lFjNBjtCulp00AAAAwLsRx+q9AIAveid+a8U3FhEPAAAA///s3bEJACAMRcHsv5SrSSCtjYgYvFtCUvynqAbcoUIEAADwHrcaAADt1G/Twhr8wugZgNO8LfzAvQAAAACwkGPYHMUKagAAG0aFuegmIiYAAAD//+zd0QmAMAwFwIzmCtEO5EBCV+hogvjpn1IsvVshEHgkJI5qQCcaJQAAwH/IaAAAjKwedVdAZpEl5TcAPpElF4vyTKDJCwAAAADP7u/yZk8AwBvXga7cVvOYkUTECQAA///s3bEJACAMBMCM5mauLkJKO0UJ3o2Q7gOfOKoB97QMXwAAADyUCyz5DACA6nyf5hctS9AAsKubIB+QEwAAAAAWHNQAAA7r89Gn3ngRETEAAAD//+zdsQ3AIAwEQO8/CxIrMBoicpU2gpBwtwLVI/utVAPWEr4AAABelJ9WhucBAPi8vD7dvCSHkOMAeCQLmgy08XetliojAAAAANyMhVc7XQDABFdpVx79ZGcR0QEAAP//7N3JCQAgDATAlGZnti5CXj4FD3Smihxs4qgGbJaNGAAAAGcIYgEA8BJfqPlFyTA0AMwyF+QH+gMAAACAQea47JkAgJVqrznyASg3iogGAAD//+zdyQkAIQwAwJRmC4IFuZ0vQirwEURnSvAR1FyGakC9JjACAADUkxwDAOA2uYXaJmpeoRkagC199OlfkAd8+T4AAAAAIKkZBAAKrTvHGqwxHfqBIuIHAAD//+zcsQnAMAwEQI3mTJaFDBohq5mACrdp4uDcjSA1D0KvVAPWuMwdAADgPVVu6DgGAMB2sudhq/xEq6doAHhKMRPby55yEgAAAMBEoQYAsMh555D6X+ArImIAAAD//+zc0Q3AIAhAQVa0ncjJ25C4QH/ElLsV/JEQnqgGFFnDGQAAAHuYwQAA+LPpdWnCUTQAnwgy0YTQHgAAAMCSB6zjvh5BDQCgUP5DMqxhV3mKiHgBAAD//+zdMQ0AIAxFwUrDGYZIsIA0BhQwEBq4s9C574tqwD1FaQgAAOA8UUMAAF5nlZqfeI4GYJMgE68bvfXhygAAAAArqGGACwBIpPplSCIiJgAAAP//7N3RCcAgDAXAjOYKURfq5O2PA/gjFnK3QkACSZ5CNeAujyEAAMBBa0gm0BAAgAr8Tk0VjqMB2JIz7WRQwaPKAAAAAAI1AIDfajn6u3oVbomIDwAA///s3bENACAMA7C+WImD+AxOY2FmQwjVfqFThyRKNeAxLUMAAABXCVsBAFDCXqe2UE0J2bK7NAAn2VLZLhXM/QcAAAAAlKZQAwD4wJAnfygiFgAAAP//7N3BDYAgEEXBLQ1LUAuSgkgoUWLi1ZsJ0Z1pYa/8h6gGzFcUhgAAAN637lv1cB4AgGT8Uk0Wxz2WBoAnYrv8Xm99cWUAAAAgO0ENAOBDrj35aVM+QUQMAAAA///s3bENACAMA7D+/xSvsWRkRAio/UWrKFGqAXdwvAEAAGyUR5PgPAAArWSl2lI1Xbj5AFhK8ZIgGr9TqAcAAAC0p1ADAHjUyIAop1TVBAAA///s3dENwCAIBUBGc4XWgVyoiSs2Tfzqtya23E0BhAeOasAmjnpq4gAAAOYRrgIAICXfqkmkjNA0ALyZDfJ7/eoWLQEAAIDUHNQAAD6uPbnyUdOwWkTcAAAA///s3dEJACAIBUBHa4WggRo9iH76DiLybghRwadQDXhHUfwAAADOrdnKfAUAQGa+VpOFo2kANrXVbjdIAoL0AAAAgNQEagAAn5g9jdvyCyJiAAAA///s3cEJwCAMBdCM1hUExyy4gqOJ4KH3Ioh5b4QcQiDkR6gGnEXzAwAA+M+yDACA1NbX6p69DqTwlFrs1gD4ErjE7Xp7m1kfAAAASEugBgBwoXlbbr7ZKSIGAAAA///s3MENgDAMA8CM1hVSGIhuXlF1AsQDkbsR/Ioiy0Y14HsUPAAAAB7Ko1+yAwCAZYiBIpQKAFjyTL9BKnDnAwAAAGUZ1AAAfqzdwxr73uFtETEBAAD//+zdgQkAIAwDsJ7ma34uyC4QBHHJFWXQzqgGvGcogQEAABwzVAgAAEnqe7UP1rSgRA1AcRvkd7NyPgAAAEA7BjUAgAZ23tExvyDJAgAA///s3bEJACAMBMCsKLiPCwmuKNZWgoWYuylCyH+UasCbmjYhAACAM5ZHAACw8cWaLISoAZIrtTim53ujDztwAAAAICWFGgBAMitjbva5KSImAAAA///s3bENwDAIBEBG8wrE3n+VuKFIaSlNFO6mAAGPUA34Lst/AAAAh2popo8CAICH+mItWIMWcqUjU4CmcuWor03wZ+p6AAAAoCWBGgBAUyPndVctxFsRsQEAAP//7N2xDQAhDATBK43OvjQojeRDAgIChGeqsCx5LaoB92q+LAMAAGwT1AAAgAXfrCnk+4+qAajHbpDXDXM9AAAAUJGgBgBAurDGAUkmAAAA///s3UEKACAIBEB/3tcjkG556RI58whRwVWoBrxtKHYAAAC1nJvMTgAAcOarNV04qgZoJgOV7Ab5nX4eAAAAaEegBgDAtoI19EU3ImICAAD//+zdwQnAMAgFUEfLwAVXyGih4C0Q6K3E90bwZIJ+hWrA/xn+AwAAOPNuAgCAg7pqPdWIBkYtVwPQh79BbjfzSb08AAAA0IpADQCAzXiDNapP4quIWAAAAP//7N3BCQAhDATAtGZnFnRgi+KRnw/hXoeZaSGQx0pWpRrwf2vRdXMCAADYZSgkGAIAgDO/W1OF42qAIrJISTbI1cYzmgkDAAAABXnvAQDYvcVjijU+iIgJAAD//+zdsQ0AIAgEQEZzMx3dkFgao6V6NwIFDeFfqAbcoVpyAAAAU45nAACwYbRba7jmB2U8WQPwPk2VvE4wHgAAAPCdbGAXpgsAsJTBGs2IDkREBwAA///s3bENACAIBEBWNHEfFzJxRRsKS1r1bgYKEuARqgH3cCgGAABwyPBBwzMAACjy5ZqPOLIGeFzrzZIYz1tzqXMAAADgKwI1AADKRvZOVETEBgAA///s3bEJACAMRcGM5uauJoKNjZDS5G6MQN4X1YB/DOUgAACAi/ggAADkWbumBc/WAOW5DVKdIB4AAADQiqAGAEDa/jufZ6yUl4hYAAAA///s3dEJwCAMBcCM1s26kJAVHK0o/hc/NXcrBCSQ+CJUA87yetwAAADmAO0xQAMAgH2uXVOIz9YAlxKcRAE9W3aFBgAAAKpYR4jtAwIA7Bs9lGCNPxHxAQAA///s3TEVACAIBUCiWcH3LGQyq7kwujkpdxXY4AOOasB7BAABAAAM0AAA4Iav15Rg6RrgP330JjdBAVORAQAAgCpyAVTPDwDgzspDZZxExAYAAP//7N3BDcAgCABARnMF60COZkfrh2dfTT/i3QokhEAARzVgP01iAwAAMEQDAICv8uu1z9ecYObyNQB16AtS3Z31OgAAAEB5eVBjiTQAwC9mH5fa6k1EPAAAAP//7N2xDcAwCABBRosny0KRWNGK5Mq1UwTuVnCFZB5RDfinew2OAAAA7QgNAgDAEa5f04Xla4AiVijJXwlKyyeHFwYAAAA6ENQAAPjE9YY17KBvImICAAD//+zdsQ0AIAgEQEZz/6lMDIW9oUDutoDAv1AN6MsBIAAAMJV5CAAAHmX7tQZsJlj5hA1Af/aC/E7wHQAAADCJfR8AQI0TXiZY4xIRGwAA///s3cEJACAMA8CO5sCCKziaCLqBPrR3W7SERKkGvKtYZwYAALJxBwEAwDlWsElEKBPgcasgSeiLn/VWm/83AAAAkMJcT/fvAwC4TrHGFhEDAAD//+zdwQ0AIAgEMDbTzRyN1fw4gjFB2hUuIfcBHNWA2paBBgAANDMEDgAAV/mGTQfzLGMDUFfKjs/p5QAAAEALDmoAADyVp3/1FhEbAAD//+zd0QnAMAgFQEfrCoEM1IEKWcHR8pMRAiXxbgT9EZSnUA04n89aAABACStU0DINAAA2Wt+wU00pwE4N4FCtt1fvuFyOb5jJAQAAgOu5AQQA+MVTPlgjIiYAAAD//+zdgQkAIAgEQEdr/6kiaIUI/bshRFBfoRrQ3ylmFkgAAIAEhmkAAPCGr9gkWI6yAdoSjMR0+nEAAABgvBuoEX/MCQDwSXawRlVtAAAA///s3YEJACAIBEA3jyYvAleISO+mUNB/oRpQw8jlEgAAoDLH8wAAcEG2YmvGpgN7JcBnBCLRwMx5HAAAAKA6gRoAAG+dYI3V8h89IjYAAAD//+zdQQ3AMAwDwEAbhXSFWakQSm0oJm3JHYo8HFupBtQhBAgAAJSV9xCeBwCAd1nHpgXP2QD/kTMvWQiq22u7TQAAAIDyuq+iAwB8zGlXrBERDwAAAP//7N1BDQAgDAPAOQP8m+KDBRLo7iw02a+dUQ3IMZXMAACAYEO4AABwz/mObViDDpSzAf7hZpNuSRgAAABId7pOLb+hAwA8rNewRlVtAAAA///s3dEJACAIQEFXFNqn1RqtH1cIQu+2UOQpqgG97Il1IAAAoLeac8w6AADwmC/ZTJErfUMD+FyutBOku1NhOwAAAIC26vZPPBcA4E9zwhoRcQEAAP//7NzBDQAgCANARnM1NzcmzmBIuRuBVx8tnmpAHiVAAAAgjfI8AAD8s92aAdYbawPQl6I96eRuAAAAYAIbJwCA3u5jjfzMVlUHAAD//+zd0QnAMAgFQEfraBko4AoZLQQ6Q2n0bgQ/goJ5CtWAgro8YAAAQBsW6AEA4CM5c5yr2epNA2ZNgJ96g4+EH1HZypl6bgAAAKA0f5sAAK7xlO/dImIDAAD//+zdgQnAIAwEwIxWR6gu5ECCKxahO1jTuxUCgUDyEaoBOa0GZsEEAAA4ntkGAAC28DWbP7jeo20AvseyPanNMYsKAwAAAJndrXbBuQAAR8kdrBERDwAAAP//7N3BDQAgCANAViRxIEf34wxG690KvAikFaoBuTyZAAAACTQHAwDAYbs1W3M2P7BzAlymR08zIZwAOwAAACDaLtJygwEAeE9usEZVLQAAAP//7N3BCQAgDATBlGbBgi0KYg/qOVNFHslGVAOCpVeBAACAL6jVAwDAAb5n84nmeBvgOpbtiTb6MHsAAAAA6dwyAQC8a4U1digtR1VNAAAA///s3UERACAMA7BJwwLg3wuHCrguEbHX2irVgGwj8XABAAA9zL08FwMAwFtWtOlAeBvgE4qOaEBxHQAAABDNODAAQISbS88q1qiqAwAA///s3TERACAMA8A6wzB3WEAaCx6A8G8hU4ekRjUgn4MUAAB4VZMcAACc44s2v1DiBriGoSOSzdHHlDAAAACQapcuPQYGAMiRM6xRVQsAAP//7N3JDQAgCARAWiSxITv3Yw/GZaYFfhyLUA0YQNIjAADwKQM2AAB4zzdtJnDEDfBYr7bXQLqtwgAAAECqe2ypxwcAkCcjWKOqDgAAAP//7N1BAYAwDATBSMNCCoZw3k89tBwzKvLJrVEN+IcraQ0IAADI1/dQCQYAgAOsmraiNvE8cwPs008rWJLuXXc1AAAAQCoD5gAAub4/rFFVEwAA///s3cENACAIBDA204FNXNEPMxiFdgWeHIdSDehDEBAAAPjJMC0AAHiGr9p0MPOoG4D7BO4pba+tRBoAAAAoKx9o2bEAANT2d7FGRBwAAAD//+zdQREAIAgAQSqq/bv4IYMjsBsDhkNUAwZZZwtrAAAAVViyAQDAJ/Krts/aTOCoG+CxDBqZBdKZQB0AAADQVh5W2q8AAMxQN6wRERcAAP//7NzBDQAhCABBSvP6NaEFS7uPNRiFmRb4EVhRDehlvF4CAgAA6tvlegAA4CI58zMPGhj7uRuAcxzcU9nKmfbdAAAAQGX2ewAAvbwZ1oiIHwAA///s3dEJACAIBUBXFNq31SJogj6C9G4Ff0TkPaEa0M80cwAAAAAA4IKWbTrw/AnwSI7cYQPCjKjM/gwAAACUdcqz3PcAAPr5L1gjIhYAAAD//+zdUQ3AMAgFQKTVAutkLqmFSttPNSwdvbPADyHwEKoBB8p+CdYAAAB25oAJAAA2tL5sT7WhuJZ3WgAF+IY5IJXN8Qy9MwAAAFDSOqI03wMAONe/gjUi4gUAAP//7N1RDQAgCEBBomkENwMZyM2KpnBTvIsAX/w8RDXgT+XFChAAAJCfWwUAAK7n2zY/EKgHOKz1NsyYzNZc1YIBAACAxAQ1AAB4J6wRERsAAP//7N1REQAgCERBKqqFjO4PFZxB3M1xPEQ14F/GgAAAQEWiGgAAUFh+2/Zxm/YcewNcZ3RPZ0J0AAAAQFtjzW3nBwBAeiOsEREHAAD//+zcwQkAIQwEwLQYtUzBFu9zDxsQgs50EbK7RjXgYdmbYQ0AAKAaYXoAAKhPSZAXuE8BDsmRsgpcbc1lnAsAAAC40l+Y9EMBAGBXf1gjIj4AAAD//+zdsQ3AIAxFQY8GI1hiTCRWYLQskDIFMXcr/NrPohpwt/aXAhAAAAAAAHCGNdcW1uAGOdJBLMDHcmTzxZLiuoEBAACAwgQ1AAB4c3ZYIyIeAAAA///s3TkBACAMA8BaBARhDWksXdkYeO5sNEmNagA+wAAAAEcorSorAQDAJXzf5hM9y98A7CN0z8tGDtABAAAAPCfzfe4mAACsnDusERETAAD//+zcwQkAIAgFUFdvoGqFRougcxB0iHpvBE+K+oVqAGOwFawBAAAAAADsSirGBzx/Axwyg4oc3fMy/TEAAADwMjsTAABWWs3lzgD6iOgAAAD//+zdsQ3AMAgEQEZz9rXEChktQkqfwo1N7kZwhbD4F6oBlLFz+g8AAPAbPt0AAOAgObPaqDRx0914j8ABWGf/R2d3zjQbAwAAAC0p8wUA4EMFalzbPlJEPAAAAP//7N1BCoAwDATAfDHQZwr5ohTqsZd6sOrMLxI2G6UawMWACwAAPEbRHwAAvJZv3PyBI3CAm7JlL+OyA+Sz6qitQ4IAAAAAq0a2z24PAICZ7Qs1IiJOAAAA///s3bENACAIAEFGcwUS95/FxthZWRjI3RZA8ohqAIdyJAAA8JGjGwAAFLS/cfvITXcjZ5pbAd4IFNGZ0BwAAADQmd0eAAA3JYIaERELAAD//+zdsQ2AMBADwN8MVvjAQBkIKStkNFoaGpoo4W4Ey7VtVAN42r1DAwAAg2yCBwCAOXnl5ieM0wN8lGdW2bGw3q6m4wAAAMCS8ijVYRYAAC+mGdSIiLgBAAD//+zduQ0AMAgDQO8/dfqIKk2EdTcF4jFCNYCbhUAAAOAHgzcAANjNd27qOQoHeOaTJc3UwQAAAEAzvT0AACarAjWS5AAAAP//7N1RCQAgDEDBVVRrClYwmgEEwR9Bvauw3+1NVAOYpJKFNQAAgGNSyYIaAABwOd+5+YTFUYBNgkQ8rrfauiEDAAAAL3JbBADAwl3h+YgYAAAA///s3bENgDAMRUGPFkYwsGZgRRrKFBEFkqO7Ob6fRTWAkZbHbtgCAAD8RVQDAADWUOr7AHzhOBxgXp7ZBIlYXLmxIAAAAMCM91GWXR8AACPb3a9a4fmIeAAAAP//7N0xCgAgDAPA/Fz8uUtHRVfL3StKIYlSDeBkWIsGAAAAAABe1Uq3pW66GxUSB+BOoQadzbp/AQAAADry2wMAYOfLQo0kWQAAAP//7N2hDQAgDATAjs5AJF0Rg0KAI6HcrVD1Ff9KNYAdIRgAALhB9gAAgDqsdfMDORbgYBYQKSGirOzZXBcAAACoaA70+u0BALB6tlAjImIAAAD//+zdsQ0AIAgAQUZzBXVgV7OxMtHYSu5WoIVHVAO4KbU3SwAAAAAAAMCT9a3bx26yK+tYHIAzASIyE5IDAAAAMhumCwDA5uugRkTEBAAA///s3LENwCAMAEGvxmRZCMkrZLQ0lCAaGpy7FdxZ9otqADvPqEwCAAAcJ+QHAAD1ZM9mrPyAZ3GAhREecmdAVW/2tNcGAAAASnLPBwDAxPVBjYiIDwAA///s3bENACAMA7Ccxv9XsTAgsdA1sq/o0CRKNYAfngIBAAAAAIAJ6920Wyc0DsDLkiXN3LkAAABAM/khAABuFYUaSbIBAAD//+zdsQnAMAwEQG0Wr2DImAavkNHSpHIR3Lh57kZQJZD0EqoB7GjSJgEAgEMuhQUAgDzf9+6IgSr8cDQOsOh3t1tAsmeOqccFAAAAIrkbAgBgEROoUVX1AgAA///s3bENwCAMBECvxgiQgbIQEitSUaWhSPW6W8GVLflfqAZw6+3P0LYFAAD8zZ4BAAC5tHgTz/M4wIcmS2KtuZrpAgAAAMHc9gAAOKICNaqqNgAAAP//7N0xDQAxDATBo5g84FBLYwD59jRDwZVlaS2qAfxhQQYAAAAAAJ7MF2+fvGnnfgYwhIYoJxgHAAAA1FrfPqYLAMCoC2okyQUAAP//7NzBCQAhDATAlJYW1DYFW5S7DgRfcaYFIaJkV6kGcCLb6JZgAACAK7wvAADgCcKHlCdEDvDPwlQ0RGVrLvc9AAAAUFIb/fvbS6cLAEDVQo2IiA0AAP//7NzBCQAgDASwruZk4j6CKziaCL4FvzVZoVC4Qk+pBvCqnsAMAAAAAABwNfqYijX4gCdyALuQ3Ir5AgAAAIm57QEAsLWshRoREQsAAP//7N3BDcAgCAVQNnMGEte0HaGO1osTGE/43ghwghC+pxrADgMzAABwQlNFAACoT6o3N8ien0YDt8qekiypbK5HcQAAAADlrNBduz0AAOY7nro3XhHxAwAA///s3dsNABAMAMCOxgiYyOYiMQF/dTdC/TR9cVQDuFHa6AZgAQCAV5pxAADwj+mtSa6cpXKAH/mYg8zksQAAAEBmansAAOyDGjV1FCJiAQAA///s3cEJwDAIQFE3L9lHcMUS8NxDj/reFBL0R1QD+OvpIiUAAAAAAMCnyrqxbj98M53FU2CdDgrZHWCqU1lmWAAAAGCkvgnytgcAsNuKoEZExAsAAP//7NzBDYAwCAVQDg7mCupA2sm6WmPiBJ5aeG8CCklP8LcJagDWdVuABQAA/jiu89E4AAAop1nMI7n9PS53fAsU0w2crL5gOAAAAICshIUDmbSF3uL/BWZRJlAjImIAAAD//+zdyRGAIBAEQDLTFFZNU01BM7MIwKv4KHRHAB8+Ozso1QBK9HkRbp0XIQIAAAAAAOBSLhqIKTbFGlROKT3QjJhCVoCa/SmADQAAAPBKjENvZgd8RJ6t7mdHqXRv8dGdbj4w7LzjQKGmCjVSSukAAAD//+zdwQmAMBAEwCtNS4jajw0JacHOlHxFBRU/yUwJ98hBSHaFagBfzWkcyuHpcSAAAAAAAHArL7lPU9pMiYp15ZO5ZnugEZrUqNVqlwMAAACVc7cH/Ok0KEOx9zNv5nURxCGAAzhqLlAjImIHAAD//+zdsQ2AMAwEQI/GCsBAKJsjSqQUQVAE+26Fr+Ikb6UawBds3AIAAJ5yKQcAAHU1ZwKSO0a3CwH81VUgJDwSa8IFAAAAslr3bfG5GnjpNkNVljGP0Sw65RvecEAdJQs1IiJOAAAA///s3cEJgDAMBdBsZlcodEyhKzia5KYi6MFTfO+WDUJIfoRqAF9o2UhpgAEAAAAAgCf59buPbiGD0vLY3Id7oKo+erNcSWHbXKfHMgAAAEBlZnvAG8fgjDzANjct5OYO9FRfQjcWYUxQxm8DNSIidgAAAP//7N2xEYAgDAXQjOYKwECck7maZ6FFCs/CxvjeCEDBkeQjVAN4y2yjuyADAAAAAABPHAXazUpR2MyNRwCFaLqnstXuAgAAAFW10ReD0UByvYn6cJvT3VlIgRtqRvAdvw7UiIjYAQAA///s3bENgDAMBECvaCkLsQ9SRgA2Q2koKGigQM5dlT4pLOv1UaoBfGkMQUo1AACAR7dlKgAAMKHx+3e23IX2qCxbbn3tUwcSgHqypdA9lS1jTnXDAAAAQGF2ezCvsfs8QnkGL93ez3VWtgG/Nn2hRkTECQAA///s3cEJwDAMA0Bv1qzWfQJZsXiDPkIK6t0UxsiyUg1gp9HDj8EaAAAAtvMhEwBIdAvuEW708bnjXCCMECSx1lzyLgAAAEA6+z34BwUaHPeibOOSEYFPKNRoVfUAAAD//+zcwQ2AIBBFQVpE7YfWLM2s4cDBgwdDdJ2pwUBMPk9UA3haq+sSh6xxIAAAANwzBjP8UwMAvxGhgbrV3WiC5FofrQF8XoSC3NskZkwIAAAApDY8agbyOTeIAhq80dV3KbQB8whqdKWUAwAA///s3cENgDAIBVA2U0do4sA6mYaYXvWiB+l7I9ADCaEfoRrAFywHAgAAdybVYWA9QEN4BgDAFayxtLUdakFhc35CzxAZjwwU4IolVW16NQAAADAA8z2oIWeZux1E/uwhaEO/gvcI1Ogi4gQAAHwF1ssAACAASURBVP//7NzBDYAgDAVQNhNHQB1INjcaD70YExMPwHsXBuBQQtsvVAP4Qz4fMdLtAACABxKFGYkGFgDAu2oogs4JpAeaV7ay+9ejY9XlAgAAAD0Li8pAe8wgMoSwi3qdZV3y3Zua9Kjgk1ndCFJKBwAAAP//7NyxDYAgEAVQRnMF1H10IBJWcDQDMRZWWlgA760ABTn+faUawF+2uMwe6wAAAIyofmIpmwQAeCenvMc1CkHQs6kso5e77pSBhinAoldHTlm2BQAAAOid+R60pRYByyAysmsv9Z7fK9mATxRqPIUQTgAAAP//7N3BCYAwDAXQOJqTSfcROoKrSYveehBB0PjeCMktJD9CNYAnbRExqTAAAAA/0YaPxRASAOCWYumB5Jbzow7A17RgIE0jq7rWWXMBAACAzI4jZODd+iOvHgJs/xCGhGzAZQI1RiJiBwAA///s3cERQDAQBdC0GNGQfsSWQGmGMxfGDPFeCzlt8vNXqQbwqFy6OeokgAAAAOxy6QTwadFi9gUAuGfbDp77vAg60LLtU3qMYS4GvsgWS1o1OFkAAADgB9zvwTvtRRpRJ++HcIGSDTikUONMSmkFAAD//+zcwQmAMAwF0IzmCgUX6mQ6WslB8CCeLGh8b4XS0sDPV6oBzLbkh8RDDAAAQEE563YzLwDAY7pgA8VlaFUoDviUtrbNiVHUruwKAAAAqO60YAy8gyINmOSiZOO4Z8ql+AuFGnciYgAAAP//7NzBDYAgEARArMwaLqEg7MeEFizN+OPnx0g8Z0qA8OH2VqkG8IYrZLM4aQAAABLx8QgA8LC+9yNqbAINZBY1mgVe4CuihsA9mW1uFwAAAPgBczeYT5EGTDC8uTaUTK1mXyQl136nlHICAAD//+zdyw2EMAwFwHSGKMFAP7AFASVAaSjSas9clk8yU4IvVhT7WagGcInou22dl1a1AQCgek3tBeD1du9bAID/yWEDMYThPko2xhD5Mr5hBuAN9GRKpRcDAAAAtbA4DPf5CNKAZ/iGDfz+BaLvJgEbFESgxhkppQMAAP//7NzBCcAgDEBRR3MFofuUbF4KHjz2FDR9bwXBQ4xfVAPI0t+il8sZAAB+z/CRkwlqAADkCJ94Ke5eF3YAdjSu0c3yKCwcLgAAAFDd/DAM5Iq5Z+gtEDa2Bm8ENjicoMZXrbUHAAD//+zdwQmAMBAEwLMzWwhYkPYjpASxM8lDkPz8BBNnSsjnYLnbKNUAWjoiYvLiAAAAdEjoCADQSN7zmpZkYYGRzeVY3Q/5wMcpuGJUmxkMAAAA/ISMD9ooeeP5PNIH+lEVbNyl82YoPbDb/kZEXAAAAP//7N3RCYAgFAVQaTNHsBqohaoRarQQXKCPQh/nTCA8/JHrfdM4RwUiKMt8GSQAAACD8egIAPA/28OJTggH6FZZy6bciqhqgZvhAgAAANG1T8HAt+6WLcwKNSCGmhWu9/ncj7pYPsuu0DHZ9rdSSg8AAAD//+zdyw2AIBAFwC2NFkhsaDs3Jpw8moC4zjQB7OchVANYrXmcAwAA8CGKjgAALxi/h7uHUVnrR9czA3Yl+IeqDL8CAAAAf6HGB/PktXA/wjT0tKGoW8BGmmFhI+n8eSAiTgAAAP//7NzBCcMwDAVQFbpXyQhqMmbAIzSbtQRyyDkUHNvvTWCQjeBb6NnciYEefCLioZIAADCWnN82cdMaoSMAQEVlLVMu+VUDOubPDLidXFKGR6+2shb3GwAAABiFxd7wf/s8oYwRBnR++8c8/EuvpZJNL7ooIn4AAAD//+zdgQmAIBAF0KvNHKGaUx2h1cJogojQem8CURDxTv885KiB4S3bultFAAAAOubSEQCgD9LE+TSP14EOSbDkq5wrAQAAgF8QfgWPaqFcqeYy6ScE4vpgo+Zy7gtqD7ys9bYnk35TRBwAAAD//+zd0QmAIBRAUUerEazGDFzB0UKwv/4keuQ54ASCH0+8imoAX1nyvqlxAQAAEJKhIwBADH4TZwIerwNh5CP7HIO/quUs1e4CAAAAk3D3AOPumEZbZovAox7YaHGNtZ8b8BZBjVEppQsAAP//7N2BCcAgDADBrBhwoe5TcMUS6AKlgqJ3Q4Qg8hHVAGbyIQcAAIAVeXQEAFiL/YytZUvxGGC6bFlHMRzGYEv97vZJAAAA4AiO38JvYhrAZzUv3rlRgY1LYIPBBDVGiIgHAAD//+zd0Q2AIAxAwa7mCOpA6kDqCo7mTycQEgjercAPoeFVVANoal4XYQ0AAAB68hiGAQD0JbeKu6Mxsi0/swO0ZHslozqcLAAAAPAj3vngOzENoNh9XnsGECYzCioQ1KglIl4AAAD//+zciwmAMAwFwHQzR9N91KwoQhcoFFrauxUCgXx4QjWA0Q5JmAAAsA0HO6Zn8QgAMC2PBqzOzAwMU4N93O1ZUt55qiwAAACwEXs+aHfl8xZhGkBPf0+pARul/rzoMbQSqNFTRHwAAAD//+zcwQmAMAxA0YymI6hrCh1BR/MS7wqKob63QukpyRfVACrYvAIAAAAFONQEACiqrW23YEDnhjxqB/iCsA+9smgIAAAA/Ma0zOKicM8Z0/B3gFdlXGPMuYXdF64Q1HhaRBwAAAD//+zdwQ2AIBAAQTozlqC2qV4LlmYwvI0fkeBMC/w42BPVAJowLbOwBgAAAJ8yHAMAaFusYVhM73xqB6orQR9RH3p0lDAbAAAAwF8MThoeyfeGo/eCQG2x7VcoIQd9LALkhqDGG1JKJwAAAP//7N3BDYAgEATAKw1LEPvvxZiciT9eiOBMEeRysItSDeAryn5UD3UAAAAYxXIaAGAO5jZWVjLcDvAmH2CwKnMjAAAA8BuZx3HHAG1bBtoV8gJDXcU+j3INZxI3hRq9RMQJAAD//+zcwQ2AIBBFwW3NEkgsSPoh2RYNiWdvKsJMFQQ+T1QDGImxDgAAAJ9QnQcA+IdseRgTMDnvZcBryl7chzCrmi2dGQEAAICVCGrAvdo/r4tpAKO54ho9orDZwyxPUONJEXECAAD//+zdsQ3AIAwAQa/GCEkGYvUIiTJtkDF3I1AhhN+iGkAq13P7KAgAAAXNEj5kZWslAMBe3N8ozZA7sFB32FQ0Q2wAAAAAJ/HWB9/GgHqzdAvIbkR/xDWOJqjxt4h4AQAA///s3bENwCAMBEBns6yWgUJWjJCgpEQCczcCNBbwj1INYDW3sB0AAKRkzmdlDp8BADbSfh03w5GZh6/AdAp8SEwBGwAAAHAUGRwYempAuQbVLRGwi16u8b3lcudxFHs9W0T8AAAA///s3NEJwCAMBcCM1hWEjik4Qh2t5NMBKlXvVggYSMwTqgH80aMqAAAAzGJpBgCwJMtktubYHfhSucslwIdN9VabHgoAAACcRqgGjPI/YB6kmxUCS8t3TLjGEQRAzRARLwAAAP//7NxRDYAwDATQWgQEzRBQC5PGDwkKWEZ5z0SbS+6MagBTWrbVsAYAAAAjCJoBAD4o9+x+OYprd+kd4A0GNajKfwgAAAD8kbwPHj2PUzkZKMW4Rmlu1igRcQEAAP//7N3BDYAgDEDRjoYjCAs7mjHh4l0IlvdG4AjtR1QDWFU5WzUoCAAAwGguIgEAfsov5GzAECzwuR7s8RZPRlcPrwEAAABsw94NvDyLyYcjAbIS10hHUGOmiLgBAAD//+zcgQ0AEQxA0drMwqxwq4nECHfi6r0pqPqiGsDJHhd8AAAAvmQYCQDwexYFyKyuz+8AbxLsISvnQgAAAOBG3hFgBndbL3YBgVuIa6QgqLFbRAwAAAD//+zc0Q2AIAwFwK7mZrIP2hWJiSNoFHo3QvtD6MtTqgH8nUAPAAAAb/GZDAAwuey5XyEpe2RhbmXAY+6iHiF7VtSypzchAAAAUJE7AtW1PM6t+hCAmpRrTEuhxhciYgAAAP//7NzbDYAgDAXQbiYrAAu5GasZE0bQKPScEdq/Pq5QDeDvSu3t1CUAAFjeoYUAAMBLHAewszKf4AGeMFSRHc2gNQAAAIBUam/2B2R3PyWbDQLpCddYikCNr0TEBQAA///s3bEVABAMBcCs6D37WM1oGp1SgbhbIiTkW6oBvKC57AMAwPOc6bmOgRoAQA4zldzAmcykzAHbSi36IGQlhRIAAAD4lTd5/Kr7lAywslzjemrXSRExAAAA///s3LENwCAMBECPloETvAKj0VBGVJEgcLeEJdv/SjWAv/AsCAAAAAAAvMo7hSnZ2SUMD3zAzZ0d1V6wBgAAAHAiOz9OVPMpQskAA8o1lmR2zRYRDQAA///s3MEJwCAQRcEtzRbU/nsRrUBCIHGdaWEvIp8nqgGcotTejAUBAAB4i49JAIB8jAHIzDAWeEyYh8S8/wAAAIAr1d6Ky3OhFdRweIA9M64xYw42058T1PiDiBgAAAD//+zc0QmAIBSGUUdrBaF9on2Eu0JtFkELFEJ1PWcEHwTB/xPVAP5k8fAHAACgk91BAgDkEi0MhknNKB54os51EuYhqS1a+IAIAAAAjMq2htGsghoA950xh+v+FNd4h6DGV5RSDgAAAP//7NzJCQAgDATA9F+LYIviV/CjIBpnigghxwrVAF7j2AcAAAAAAJhxSEVm9mTACrWDlGqp+j4AAADgZ+Z+/KQ/JAufB9gwhGtwhkCNm0REAwAA///s3cENgCAMAEDcjBUKLORkOpofBjBREoW7FfqgLWlrqQbwNzlqUQgBAADwlCYlAMCE+rVyuR7TihaH6AJ3RYvsYiWT2gUWAAAAWFXUoufHSgwkA7yoL9fY/LUMd3q/PialdAEAAP//7N3BDYBACARAStPKtCA9WrA0Y2IBJuYex810wJcNi1INYESbJQAAAAB/WFQCAJQm+Key5T2SB/jCt0oquvJIz1gAAACAmckJmIVCDYBO8my7co1unkKNtehs44qIGwAA///s3LsJACAMRdHsP4vgihKws7AR8XPOEGlyeUY1gFuJfwAAAAAAgEEtNcMqcRUv8ycDpvoAj7ieF4k7AQAAgN/5E/ADgxoAG+S4Rt5cnc0yBjVOFRENAAD//+zdwQmAMAxA0YzWFdQ1hY6go0khN8GLUDS8N0IOvbT5FdUA/qot2+rnEQAAAAAA4Kbv3QU1lbVclgd4cpgOBZ0ZUAMAAAAA6hLUAJhonLkZgvDW5h1BjS+LiAsAAP//7N2xFYAwCEBBHBF1H1dPY5smjRjupsgLvI+oBvBnT16nhUEAAChOEI+CDNwAAHpwxZyduUIHTOWd/uPYlfcdAAAA0JpdPBoQ1AD4yBvXOMxjlghqVBcRAwAA///s3MENgEAIBEA6UzvTfk6pwc6MDRj9edxMCbxIWFapBtA7gUEAAAC+Ok0MAKC+bLkqVKOw2dM88MAdnYq2bGm3AwAAAEY3jT4ASlOoAfADuR93FmGRuXlNoUYPIuICAAD//+zdsQ0AIAgAQUZz/6mMCZ3RWuFuBAo6HlEN4HdDaRMAAAAAADjwPYPKHM0DG8EdqspgGgAAAEB3o/sAKEtQA+AhaydnKEIs4k5Q4xcRMQEAAP//7N3BEQAQDADBKBEFad3Hx4wCiN0yRC6iGkAGo/bmYQAAAAAAANisa+Y+X5GW5XngQHCHjITSAAAAgO/ZmyExQQ2AS624RjGrORLUeElETAAAAP//7N1BDYAwEETRsYaEJsgEVgJII1x6wkA370nodTa/ohpAFw6DAAAAAACAP4Z9OrORAdPYx+01aOipo0SkAAAAABJRDToS1ABYQJ3Xt9VsPraZBDVWk+QFAAD//+zcUQ3AIAxAwUrDwsDmEiwgjRD2MwmUOxFNP9onqgFkUZ5WHVEAAAAAAAA//e1DWIPMPNEDsWdBcVRPUvY4AAAAgE1om2yGoAbAOdbM/kISt8ckBDVOFBETAAD//+zd0Q3AIAgFQNzMFbQDuVpHa0z46Qji3Qok8AMPoRpAJWs805IQAAAAAADw47s5xfU8pgfuZqGeit4MSAMAAAAAanGQDHCoDNdou5dfWEPz61QR8QEAAP//7N3BDcAgDAPAzFjWrMSKFVL+vOvcDRGkYIxSDSCNoBAAAAA3gvgAADP55Zxk7shgsC7WUa5DnP1uoUQAAACAswNcjwJ5kniQDBCgZ/moee78+rGq+gAAAP//7NzBDcAgCEBR3MzROpAtKxqTnnsvvDeCFxMCX1QDqGYaFgAAAPDlFJI9EABAP7nyElijsPke1QM9CetQkSAaAAAAABTkIBmgjrOTnfczmuzj+L/+LCI2AAAA///s3VERgDAMRMFYq4RQ/GCdYehXHXDs2kjvVVQDSHT1PDwaBAAAAAAAdsaZJDOqhx/qs59olPs4cVYQDQAAAICXGwApDJIBAq1g0giOawyfOn5cVd0AAAD//+zdQQ3AMAwDwEArtfGZVAqFNlXKZxScOxB5pI0tVANIZWEAAAAAAAD87HefIe0YzLT6uB6Yxds4iXysBwAAAGhKZwnyOEgGyHVnfIdrpBXeCNRIUFUfAAAA///s3cENgCAURMFfmpagtGlCC5RmjFxoYZkpggNhH6IaQKrjardHgwAAAAAAwKI/3UiTZMb1sBEhHUKNGUIDAAAA4CeqQYJvaO1OG2AD87w/Qz69EdRIUVUvAAAA///s3cEJwCAQRcHtLKVZUZIWRQiCkAb8zpTgQRbEt6IaQLKmyAkAAAAAAPxI24oBk0/2cBQhHRKZ0wAAAABWl/Ngd+/9WHwAcJARovju/p3ffQQ1klRVBwAA///s3bENwDAIBEBWtJSBkn2cMIJXc5PGIxjfrUBB8ehRqgFU54gIAAAAAABYZE+lA1QmH4MDtKsNc6agJ3s6TgQAAABYeTbL7hRqABwq3+/+98Bu+Y9CjWoiYgIAAP//7NzRDYAgDEXRjsYKBRZyIHRF46duQD1nCRLyekU1gOpajm5MBAAAAAAAfBlvUVbOFI6BwnJmM6SnIuEzAAAAgLcc3T8guzscJQP82/MOXOvcKawhqFFRRNwAAAD//+zdwQ2AMAwDwIzWzSo2r0B5IHWBYu5W8C9RHKUawB8MgwQAAAAAAOCtv6BbgpNq9tE9kGnKlUCXUAEAAAA2Zv182X1ErUgXgEcXa5z+AEehRqqqWgAAAP//7N3BEYAwCARArCwNayhBS3Oc8RPTgOJuCfAEDqEawF/sOg0AAAAAADw43qQyR/dQ0B2YY5Geao5c03I9AAAAwKypCR9mFgvA4AqsyK0vL32CI1Cjsog4AQAA///s3MERQEAMQNGURgmoSD/YFpRmzJg9cXNY8V4JOWY3X1QD+I1hGoU1AAAAAACAqixlb/ShHt7QXcf3QC6COWTkcz0AAADAPXt+vmp2mAzAk7Ju/RmxaGhAghrZRcQBAAD//+zdyw2AIBAFQOzMFlALoiCBFijNmBiPnjwQmGlhb/t5K1QDmMka901DAQAAAAAAeNWz9jSkh785voeBxCMmS/QMqD1BZwAAAADAGFrNJaklAF/uEIuay9LBMxyBGjMIIVwAAAD//+zdsQ2AQAgFUEbTEVAXciC9EVzN3lhcZ+TeW4ECQsJHqAYwmkvFAQAAAACAB9/RqWrKLR3gQx2CcqjIHAYAAADwItdFKAF/ZecHQLd2nPOHvWMXqDGIiLgBAAD//+zdwQmAMAwF0K7mCFUH0n2qWcHRRCjePSjSvrdAroH8JI5qAN3J0+iwBgAAAAAAcIsSyw8+X8BbzMagAXnOAvS0aI0SejAAAAAAaIflZAAei22/ZqHDx9mdo9alBymlEwAA///s3bENgDAMBECPxgokAzERyYoICSQKqhRIOHcLuHBn6d9KNYAZLWstPnIBAAAAAABPPiaRljA+pLBZI9lcxWYAAAAAvHMT5HeEkwEYdZYy9b19Vaxxz2IWEXEAAAD//+zdwQkAMAgDQPefuh9xgdJH490SgoREqQawlUUuAAAAAABg9Eq61SRSCd7CxxTjEEpQEQAAAACy+PkBcK3LLl7eFIUaG1XVAQAA///s3cENgCAMQNGOhiMUXMjNHM2YcPDgUQ/AeyP0QtKkH1ENYFnZqrAGAAAAAADwdJgGs3KUD2PKPYswDhM6e9AMAAAAgBfZajEXBnMfKNv5AfCJ/qZsP3yOI6ixqoi4AAAA///s3LEJACAMRcGM5mauLkJsrWxM7pZQPuSJagCdDUMDAAAAAABw5HGnsAZVzTzOB/4iqEFF/lsAAAAAd/Z8fmPzA+CpHdbIAMarN0ZQo7OIWAAAAP//7NyxDYAwDARAb8ZqDAR4BBgNRYpERYUoEt+N8KX1fqMaQHVn9QAAAAAAAIBHbrmKg4l5zoeB9CEc5Xlmc/UhMwAAAADeLbJhIO1J2c0PgF/kfrQez9cxDIMa1UXEDQAA///s3cENgCAMQNG6mSuoa4pd0ZB48GZC4gF4bwHuDf0V1QCmtx27sAYAAAAAAPDmkhKjWp8lfaAPQjgMJ8/0YREAAADgm1k+3bCkDMDfarwpy7XUOEbDU4IaRETEDQAA///s3MsJACEMQMHUqA1ZkGCL4qcB97CgzDQhJPGJagCM48GcDBwAAAAAAICp1VY+LuLhBj7pwwV2AMcem9cIlwEAAADAW8z8APjNjmOcvD2CGiwR0QEAAP//7NzBCYAwDAXQjOYKtnNqR+hqHgzoSXoSLe+NEAqBpPlCNQBOXR0AAAAAAIAbH8CY1ZLH+sC32WEznQwuAwAAAODBWosZCr/Rtt17BeBV2XtGgjIEanCJiAMAAP//7N2xDYAwDARAM2KAMQlegdFQEA0NLci6G8Htv95GNQBubZmVkgAAAAAAgEtueYyA3TUoSi4GP9bWpoRMRUqLAAAAAFCLJwUAfCL7PgYzppdej0ENniLiBAAA///s3cEJgEAMBMB0pi2oBdmQmhYsTZCDA334VI+ZEpLnko1SDYCqH6bRVy4AAAAAAOCUSwrYaZajffi02XpozF4KywAAAAB41pkRf5DrJmsC4FWlOOOaQSnU4C4iDgAAAP//7N3BCQAgDATB679qPyIKPnzGMFOFCNkT1QA4WeUCAAAAAAB2FpboytE+FCR4Q1PeUwAAAADvjMXyA39+AJQwAxoroiGowVWSAQAA///s3cENgCAQRUFKswXUhuwH2BYszcR4IhSAZKaNzX8rqgHQyccurAEAAAAAALyihHEzyzLeh7nkM2+CNyzoihL9hzAAAAAA4MeiNjcmAKYRtd1fWENQg7GU0gMAAP//7NzBDQAQDEDRjmYFTGRzkXBycUTeW6FxaeOLagDsUq5F2RMAAAAAAFgc3fmVz/twF2+S7wiUAQAAAJzLtdil8IJmSgDcZoQ1ZlwDdhHRAQAA///s3cENACAIBDBWJGFfVzPErwMoaUfge8B5qgFwt8wFAAAAAACIcwzaobvgnZGyUi4GD8jKLn5Q/sA0lusBAAAAYB65KQDwl4jYAAAA///s3bERgDAMA0CPxgrAQFmIxCtkNBooqbn4/kdQbclGNQA+7OfhgBAAAAAAAHgphVLV9pT5gX81+VPMzCt9VgUAAACAWmb2YVQDAFhLRNwAAAD//+zdsQ3AIAwEwB+NFRLWRGIFRktDS5EqBN2N8bbfSjUA1spVbwuEAAAAAABAeuvD1yUO5pgfPjSLbcymOY1CMgAAAID35PXsTu4HAPxPkgcAAP//7NyxDcAgDARAjxYGJoyAR6OAOm2EdTfCl375jWoAfJvyAQAAAAAAYg9rNEFQ1HOe+oF/6KWpJs8gGQAAAABQR47+uvsBAPeJiAUAAP//7N2xEYBACARAWgQsyNbs7KOPHSOV2S0B0ps7pRoAN7JLgAkAAAAAANisLzGV9Tt4QR55ujvTKCIDAAAAeC67lF/zdZcPAQC/FBELAAD//+zd2QkAIAwFwZSWhtUWRSxA8MeDmTIi+zSqAbCWjhMAAAAAAEDMSHTEz35g4kcp7ocjDNrwGwNkAAAAAHt0K1ytleodCQB4U0R0AAAA///s3EENADAMA7HwJzVq+xRAX5MW2TSinKgGwM4R1gAAAAAAAIazKK2c++EhIRsaTYAMAAAAAOhiHwUA/pXkAgAA///s3MENwCAMA0BvBh0BqQMzGuoGiAcq6G4E5+kknmoAzLNECAAAAAAAfMeiPUmXBDdy5A97tLdVHTQXegwVAAAAYFkRHT+mGwUAzpVkAAAA///s3cENgDAIBVBGY4XqnLYrMJoXBzAemtq8NwIJFwIfoRoA72U7D0uEAAAAAABA+MbExhz5wxx6jd3UEzwGAAAAwDepbiyqxtXN/gCA/4qIGwAA///s3DERgEAMBMBIw8LB+3lpDM5oMEBB8WHXwjWZTHJKNQDemTl2iwoAAAAAAPi552lUsQYtZeSULHwnI5sDeRoyFwEAAABAT5dcAYClVdUNAAD//+zdUQlAIRAEwItmtFdIrfCiiWABBUFlJsL9LrerVANgnsUgAAAAAACgF2t8rsCj0nj6B/aQOfOafxSOAQAAALDA+Csnq7nIRAGAu0VEAwAA///s3dEJgDAMBcA3mh1BXbOQFfvjAiJCW+5WyFdC8iJUA+C947wvDSEAAAAAABBf2dmYo3/4wRNYY0GerVSvpqIAAAAAn5gZMithugDA+pIMAAAA///s3DENACAMRcFKwxkIIqkGnLGggLDQ3Fno2v9ENQDudCVQAAAAAAAgZw7PZBTVzvgfeEuwhmoExgAAAACgruW2AMD3ImIDAAD//+zdQQ0AIAwEsFkkQRCGAAtI44MCwoellbHdbko1AO4JOwEAAAAAAOGYlMTsw+ChUkvzcZJk1ikYAwAAAAASmn2Y/wEA/4uIDQAA///s3NEJwCAMQMGM5grWNQuu4GhScILih8S7EfJngk9UA+C/UtvjcQgAAAAAAJfrbx/fp9Lb50BKZUUAgD2EashGWAwAAABgD7tDTuT+CQDkEBETAAD//+zd9YnVEgAAIABJREFUQRGAQAhAUaoZQQ20hZyhgttsLzZwT/BeBLgyH1ENgH/GeV8+CQEAAAAAQHP55NF9BpTlkBc2EKihoPcLiwEAAAAANU17BQBKiIjF3h3UAADDIADEv5duFieie5E7FU0g1KgGwJ4iIQAAAAAAEN/aaWUMAL6QK9PG3QMAAAAAxe4c+RAA0CHJAwAA///s3FENwDAIBcBKqwXaGZqfJkjYpE1EfxZ6J+HxBSRPqQbAvh5zWBQBAAAAAOBwudK/gKqUAcCGuOKRH8XcufI1VAAAAIB9MUcXIz/k/gcA1NFa+wAAAP//7NzBCQAgDAPArOYIgvs4m5uJK4gPKXcjtL8EYlQD4I0pyAAAAAAAAJI0R6AiowBwp49+emRdMqUYEgMAAAB4Sn7Ij5avAABlJNkAAAD//+zdQQ0AIBADwZOGYcAinzNAwqvM2GiyFdUAeMdDFwAAAAAAfK5f2z03kWh0HAC4Y0cmjYAYAAAAAITbcwnrAgA5quoAAAD//+zcMREAIBADwZeGBUARzpBG8waYoQF2JaRLc6IaAOeU2pvTCAAAAAAAjO8X4FXiALAhQzRiNLxkZkAMAAAAAAAA4A4RsQAAAP//7NwxEQAgDATBSMMCIAjrNBFAQcGEXRmZ/IlqANy1+hyeogAAAAAA4GM5NjU4paKWkQDgjBAN1QiHAQAAANznjshr3AEBgFoiYgMAAP//7NxBCcAwDIbRWJuEwARN0KAWKm0UKqCHXpa+J+E/JvCJagDs56ABAAAAAACHa2+7Tt+AsvzCYEHe+YwQja0opM9wGAAAAAAAAMB/RMQHAAD//+zdMQHAIAxFwUjDQqCCaqjFIhJYmMKdhL/nRVQD4LyWo792BQAAAACA6/niREUtnxQKgD0BGkoRDAMAAACAO8zvdxMFANQSEQsAAP//7N2xDcAgDARAr2jCPlkIiRGyGmIAyjTmboUv/Xob1QD4x5tPUyYEAAAAAICLzTF34cxHdyr6pApn2VPhmGoMhQEAAADAHdw2AYB6ImIBAAD//+zdsQ0AIAwDsLwIXMxnLMxMIKHKfqFbo6ZKNQDe8XkIAAAAAABwhEpJSgPgSFZMKbsoDAAAAIDL2uj2LvxmmggAUE6SBQAA///s3TENACAMBMBKAwkkyCRBAkjDACtLuZPQbt/kq1QD4J0i4AAAAAAAgL/NMbePTiSlNAAuWm/LXEimWigAAAAAfMNdEwDIJyIOAAAA///s3EENgFAMA9BJw8Lg+yEIAiwgjZBwwACX7T0JPbZJnWoA/GvNZZ5kDAAAAAAArW3dA6CmHOlgHj5y5LMN24ep5HoPwgAAAACABs790AcCAPVExA0AAP//7N2xDQAwCASx35zVU8AKKULsKZAQh6gGwH2+dAEAAAAAwMfmGFVYg41qIgJAsxtmG/MLAAAAAAAA8LYkBwAA///s3UEJwDAQRNFxllpoo6h+CrHYSywEwuY9CXNd+CuqAbDedffHly4AAAAAADjY+IZbAVWJCECSGZgRmaGSd4bBAAAAAFin2ZaNiOwCADUl+QEAAP//7NxBEQAgDAPBSsMCIAjrfLBAH+2ujEzmRDUAcpy5lwMVAAAAAAD05ohGRePFBKA7gRlKEQQDAAAASGFfBwCA3yLiAgAA///s3UERACAIAEEqOmMgC6kRrObHDD5gNwJvOEQ1AP45Zg0AAAAAAHW941Qf38lITIDSWm/D8jvJCIEBAAAAQDF7LqFdACCniLgAAAD//+zcQREAIAzAsEnDwgDBSOODBu4YiY/WVAPgohzdWAMAAAAAAP4mUqWiljMNBfiZsQyVrDMCAwAAAAAAAHhfRGwAAAD//+zcQRHAMAgAQaTFAm1kZiYWIq1TE3nArgWewIlqANw18n0cFAIAAAAAQFN77fM/q5o/BYnL01LOFB+gGgEwAAAAAOjH/hIAqCsiPgAAAP//7NxBDcAgEEXBtVYJFEEYIsECdcalFmiaZcbCv202T1QD4HseCgEAAAAA4GCjj8v+ZCQuwKGa4UlkvgEwAAAAADYr9XZT508eawAAaUXEAgAA///s3QENADAMw7BS/Mefy2Fc6mwgiagGwAdnrrAGAAAAAADs5gJPI3EBVhGSoY3wFwAAAAAAAFAnyQMAAP//7NxREYAACERBolEBNaZKRWM4A7sR+GXuiWoA/CPrPNLtAQAAAABgp77bEJuRRAbYoq5KIRmGEfwCAAAAgKX6ef13AIC5IuIDAAD//+zdQQ0AMAwDsTAvtFHbZxwmpTaEALiIagD8c2wPAAAAAACreYOn0bzYALQT1KCK4BcAAAAAAABQKckFAAD//+zcQQkAIBREwa2o1hSsYDQvdhC+MxX2uPBENQAeaqMLawAAAAAAwKfWXDvJtj8FiQ1Q2g3HiMdQidAXAAAAAPzLXwkA1JbkAAAA///s3EERgDAMRcE4IxYKinAGznqJhpYJuxLyr5knqgGwV47r9GwFAAAAAAD/dduehrKiA9CVcAydPBX6AgAAAGCtw735iNcQAEBrETEBAAD//+zcQQ0AMAwDsfAnNWr7FMMqZTaF/irlRDUA9h03AAAAAACAP82I1ZCVRqIDVJpgjGgMTQS+AAAAAHb4MwIAwAtJLgAAAP//7NxBDQAgEAPBkwYSAJskWEAaH0SQY8ZCn01WVAPgAW10YQ0AAAAAAPjUmqvanoTKjQ9ANr5dMtk38AUAAAAAAACQU0QcAAAA///s3UERwCAMBMBIq4UU/IAhisXaYMKuhftlbi5GNQDO8GR7lQoBAAAAAOBevsRT0ZAqlWTPKVAqMewFAAAAAOz1uX0DALVFxA8AAP//7N0BCQAgFEPBRTOw8CuKLWTe5RhvohoA7/BoBAAAAAAAn5o9d6zmKZ42S4SAMkIxNBH0AgAAAAAAAPolOQAAAP//7NxBEQAgAMOwWQQMI40PIriR+GhNNQAeMtY01gAAAAAAgH+JW2lkQkAFgxjK7Dv0AgAAAAAAAOiW5AAAAP//7NxRDcAgDEXRSquFwmQuwQLSCC42OMfC+2vSK6oB8C1ZvaVNAAAAAADgPuMdcz+5mp7TiBHwd/VUCsRwGCEvAAAAACDcCgGAK0TEAgAA///s3EkRACAMBMFYBASDND5o4AjdFpLn1ohqANynuwkAAAAAAHzLcI2MxAh4nR8mk7FCXgAAAAAcUloVowYAgF0iYgIAAP//7NxBDcAwDATBgxYKl4Y/ln4KoklmKPhjyfKKagD8UJ8prAEAAAAAABf6nlyFNThOV92/2FJXR5JhehzEngEAAAAAAADcI8kLAAD//+zdSw0AIAxEwUrDAiCI4IcEi1wQwWfGwl6bV1ENgDOlXIvDLAAAAAAA+NAc03cyXpR2nABu0yzGQ/oOeAEAAAAAAAD8ISIWAAAA///s3TEBACAMA8H49wJYZGFAQil3MjJ8RDUA6vLWBQAAAAAA//IiT0fiBDzlhGDEYGhDuAsAAAAAuK0xbYYAQH9JNgAAAP//7N1BEQAgCABBomkEtX8XP4RQ2K3Ak+EQ1QB42DpbWAMAAAAAABrKo1ef5KlmZKQAfmFfSyXTNAEAAAAAAIB2IuICAAD//+zdUQ3AIBAD0JOGhYP5WfBDggWkYWOD9yz0t2mNagB8W8lWFQsBAAAAAOBOXe4c6BUqf5BPeufjJGuOaawLAAAAAAAAuE9EbAAAAP//7N1BAQAwCAOxSsO/qn0QwSDx0auoBsB83o8AAAAAAOCgHr8awLJNiRXwCQEYNhHqAgAAAAAAAG5K8gAAAP//7Nw5EQAgEATBs4YEwCZVWEAaCQESeLotbLbBiGoAXCDXIqwBAAAAAAAf6q0nu/MgsQKOJvzCY8YKdQEAAAAA7PyGAMAfImICAAD//+zdQQEAIAgEQaJRQU1sM2sgzFS4H49FVAPgD7nOTlsBAAAAAMBIvsvTjmgBxQm/0IZAFwAAAEBJbpBUcK0AAIwQEQ8AAP//7NxRDQAgCEVRKrIZ040IVrOGwjkV+OTtimoA/OO4FQAAAAAAzFO7xAfoyGCYJ+VKf1k6EeYCAAAAAAAAZouICwAA///s3UERACAMA8FIw0IB/1qwAXTXQr6dq6gGwENqTQdcAAAAAADQky/zfEe8gNvUrpFkGIZfCHMBAAAAAAAA7SU5AAAA///s3EERwCAAA8FIwwJUEIaYwQLS+qmIArsW8s2cqAbAXkp9mtMLAAAAAABcZo65kiy7c5jyRQzgL7olOIggFwAAAAAAAHC9JHkBAAD//+zcQREAIAhFQSqqgRybGc0LIVR2K3DkzxPVoCKjAV432+jGhQAAAAAAUM9ycz4kYsAVMvDiD8svdga5AAAAAAAAAGqLiAMAAP//7N2xEQAgCAQwRnM0F1JXtKG29Q6SEWgfHqUatHPW9sWLCiwXAgAAAABAM3kcK+eimpFlBvCbDJZKFHEBAAAAAE9n7WlCAEALEXEBAAD//+zcYQmAUAxG0UXTCFML2UddRRHsIL6dU2G/xgdXVIOW6rxml+fnplwXzysAAAAAADRTR9m5GJGYAZ/KLZ/tVdyFUexviAsAAAAAAACgvYiIGwAA///s3cENABAQRcEtTQsoSEMSLbpQg2CmiD39vBXV4GcGh9yu5VoMuwAAAAAA4D++z/OatKIGcIqwC88YfbinAAAAAAAAAFtETAAAAP//7N3BDQAgCANA9t9FXdGY+GADI9ytUWiVatDWGvOscljm4HeOuwAAAAAAoJn7LCvnohq5F08odKEYxVsAAAAAAAAAWURsAAAA///s3EEVgDAMRMFIKxJKdQIWKo1Lq4FHMqNj94tqUNpz3YfBIT/X+jiNvAAAAAAAoB6nWdIRN+Ajgi5kMVd4CwAAAAAAAIAtIl4AAAD//+zcQQ3AIBBFwZVWCwv1gyESJIC03iugCXRGwu7154lqgMEh+2tZy+WPAAAAAADwH6OPJR7PgcQN+FTeOV2cg9i/AAAAAAAAALxFxAMAAP//7N2xDcAgDARAr2iJgViIZAVGQ0gUmSCFuVvBpV//SjW43jueKVhAAQKGAAAAAABwHz8uysmW3VX5Q7bcwwXGC6hinsItAAAAAAAAAL4iYgEAAP//7N1BDcAgEATAk0YlAIJaQU2wyAMsNCkwY+G+t7tKNWAUazyWvFhcyrV4MAQAAAAAgIPM8KxiDXZzz7ID+JrhArbR3na5JgAAAMAaZD/4CTk6AOAcEdEBAAD//+zcsQ2AMAxFQa8YMhALIXkGNqOJRJ2CAvtuBLd++kY14CU45O/OMQ+BIQAAAAAANJJXCi+pyNgBn1rDLX6rVKF3AQAAAAB23S4GALQREQ8AAAD//+zdsREAIAwDsYzGwsCKNKnpaIy0hnMfUQ1oey6fvEjgwBAAAAAAAP5j4yLN6OgBvGJXJYbAFgAAAAAAAMBFVR0AAAD//+zcsQ2AMAwEQI8WRnBgTWAFRosiUVDRpSDcjWBLbmy/UA14OPejHxpcasKHlVyrgxkAAAAAAPiR+5nWjovZCD1giNyyz0yhLcxi0UkAAAAAAACAFxHRAAAA///s3UENwCAQRcGVVgsL9YMhEiwgDQFNeusBOmPjb96KasCTT17srmUtjsAAAAAAAOBfbFyc5so7bV58QbCFU8zRh6gWAAAAAAAAwJuIWAAAAP//7NyxEcAgDANAr8gdA7EQMAKMliYVDU0q538EuZXsqQYcZh9b6ZAEFMEAAAAAAOBH3lGtYS3ZLBflS6WWJlAS0W0BAAAAAAAAuImIBwAA///s3TERgDAQRcGTFiQEDCEo4SwgjYaSSUVD2LVw7Z93ohrwIPuxGx3ycaVuq0EYAAAAAAD8SLZc3JvZiCDwMs8JmMV5B7UAAAAAAAAAGImICwAA///s3UENACEMAMFKw0IBP0g7a6eAhAcfYEZC+2yyFdWAOR89ON3IVostAgAAAADAU9y4uI0IAltkz88kuYWQFgAAAAAAAMCiiPgBAAD//+zdwQmAQAwEwLQYuIIsSE0LlnZcAYLgLzfTQvJcdpVqwIu67kfokAaEDAEAAAAAYCN11uHedJMj/TW/5Mg1RmCQgC5kWQAAAAAAAAC+iogJAAD//+zdwQ2AIBQD0D+aK4gDOZGwAqMREs8mcBPeG6HnpjWqAR/Kk3s5q8qIHzvOKykZAgAAAADAXrzXs5r7HUWAWc4IWEU1oAUAAAAAAAAwICIaAAAA///s3TENACEQRcG1CAjCEAkWkEZDT+46YMbG/rwV1YA9Hz44XU0lGxkCAAAAAMAjeutDOJ4LiSLwywqyuJdyCxsWAAAAAAAAgC8iYgIAAP//7NwxEQAgDATBSMMwYAFpNOmBNuza+J8T1YCD2cdySqAAJ0MAAAAAAPiLfYtqWsYR4JWtlCpWhrMAAAAAAAAAuBURGwAA///s3cEVABEMQMGUti2gIQ2hRRcFrCNmWsgxLz+iGvDDaL365sXhvlRyNUQAAAAAAHjDOrq13+I24ghsWSEWMRZuIZgFAAAAAAAAsCsiJgAAAP//7NxBDcAgEEXBldZKAAQ1+CFBAta4IIAeS2ck7F5/nqgG7DNO4OueVLLBGAAAAAAA/ERv/fZrDnOtSALsGi7FIeoKZgEAAAAAAADwRkRMAAAA///s3cENACEIAEFaNLEgC/KkBUuzBeOTmymB8CNZRDXgUn5rC2tQgO9dAAAAAADwL+5bVCOSwJXW2zApqsiZ9hkAAAAAAADgRUQcAAAA///s3cERgCAMBMCUhiWgdQotMs5QgPIz7LaQZy45TzXgg363J6Sg+YM/K/U6hW0AAAAAAGAT8wjXfotUPEvgJYUDZHGYJAAAAAAAAMCiiBgAAAD//+zdQQ0AIQxFwUpbC7CC1hBJLSANByRwW5ix8I9NXkU1YJ1vXvzdV976WBEAAAAAAK7hvsVpxBKYEl7hID1bimMBAAAAAAAA7IqIAQAA///s3LENwCAQA8AfjRWQWBMyAoyWJi0FSvfcreDWtlMNOPT0sRQPSWAKEQAAAAAA7vCNcQ1yScVpAju11eJ4hUT0UwAAAAAAAAD+iIgXAAD//+zcMQHAIAxFwVhsMVRDFAtIY2FlyQbcaciY/0Q1IKHV//N4yO6e8gprAAAAAADAPYxyOY1oAitug1P0GcYCAAAAAAAAICsiBgAAAP//7NyxDYAwDARAjxZGcMiYSFkRRaKhhSrW3Qpfvv1GNeA7h4fsruXZmxQBAAAAAKC+5ylXv0UpOdKIPC85cvWfOlBKmNc8JAkAAAAAAADwU0TcAAAA///s3EERwCAMRcFIqzMQVIhFLq0BhlPYlZBc33yjGrApxxQeUoHQEAAAAAAALpFvdr+mmOcbUYBfcwmK0KMAAAAAAAAAnBARCwAA///s3EERwCAMRcFYpOiEWkAaA1MH5QLsSsg5/4lqwA9vqePxsLkhO0v5EdYAAAAAAIB7GOlyGhEFpi+wIrLCEYSwAAAAAAAAABaJiA4AAP//7N0xAQAgDAOwSRsSAP9eeOYAHiCxsLftjGrAPsFDbpd9DuEyAAAAAAD4QJV0jcbzkqwxBfBMgFc0lwQAAAAAAAA4JCIWAAAA///s3EERwDAIAEEsZqZ+GkFtsBBpFZG+YFcCPGFOVAMO5bu2sAYFeDADAAAAAIA+3Lao5rbR3sY1ZvcZUMbOJ8WvAAAAAAAAAP4SER8AAAD//+zdwRUAEAxEwZSmBdSJFl2UkAtm2tiXH1ENSLDG9NGL69XehDUAAAAAAOAD51jXtsVLiqjC94RVeIXwFQAAAAAAAECmiNgAAAD//+zcMRHAMAwEQUGTISRBZD6ZMUU3hqAmyi6Fb39OVAPqODbwdXk9d1oRAAAAAAD6W+8aZqYZUYWfElShkXnCVwAAAAAAAABUiYgNAAD//+zcQQ3AMAwEQUMrhUiB2dYQEmgh4ZczQ8GSPyetqAYUye/fwho0sBwRAAAAAACuYduiFXGF+4w5HkEVusg3/TAAAAAAAACAahFxAAAA///s3cERABAMAMG0iDrRotEDD7HbQr7JRVQDDpp97AUHX0N4WmlVWAMAAAAAAD7geJeExBX+Y+ZkIXQFAAAAAAAAcENELAAAAP//7NxBEcAgEAPAk0YlhCIYaZ16oI/CroU8k4lTDVjP0IG/a7l7kyIAAAAAABzhEjM7yYgD+UNk5O009ZrsYDq6AgAAAAAAAPhIVT0AAAD//+zdwQ0AIQgEQEqzs2voPFqwtIuJJRgfONPC/mADjmrAZtm/oXxIAcqGAAAAAABwgXxz7raGrCmkrWML1PfImCI8bwEAAAAATjNjBwDuERE/AAAA///s3EERwCAMRcFYhBrCENRCpfUSC+0MYddCrj9PVAM+kGEN40O21q4urAEAAAAAAGfwzEs1hqDFZThFPIUKngxcAQAAAHCIe67h1gAA8KOIeAEAAP//7NzBFQAQDETBlEYJqBMtumjBQd5MCTlnv6gGPLLnqm7L50ob3SMaAAAAAAAkd8e8Br1kUm50gbyEU8hC2AoAAAAAAADgpYg4AAAA///s3VEJACAMRdFVHFjIPoIRrCaCFfxwnFPhfQ7uRDXgLWENfrcsCAAAAAAA9c0x3bWoRnShqGx5vjiKplBBv2ErAAAAAAAAAF6JiA0AAP//7N1BAcAgDATBSKsFwGYhFvlggUfTGRH33BPVgItyLq9efF4bXVgDAAAAAAD+wVs+lTwnvkA9gimUkG/aKAAAAAAAAIDbImIDAAD//+zd0REAEAxEwZSmBdSJFv1ogRmZ3TqSd6IacNka06oXvyu1N0tPAAAAAACQ3HnuFYwnE/GFZIRSSMQtCQAAAAAAAMALEbEBAAD//+zcQQ0AIAwEwVrHD0klgDRcNGmZsXDfy4pqQA1nCLo7FgQAAAAAgC8sMzOJCMM4QilMcHOniBUAAAAAAABAhYh4AAAA///s3cERgDAIAEFKSwsktqm2YGl+UoMZyW4LPBkOUQ34wH1ej69e/F2OLqwBAAAAAADFzSNfey0qEWEoIo+0r6QKASsAAAAAYLkcvZkCALCFiHgBAAD//+zc0Q2AMAgFQEZrRyDpmtYVHM2YOIOm5W4E/uCFp1QDPnIes5s1i2sWZgAAAAAAKMGzL1tRxrC+HPnklLJKdnC9BVYAAAAAAH9zdwcAaoiIGwAA///s3EENADAIBEGk1VkNNcFiP2gggcxY4HusqAb0EtZgOoNDAAAAAABYrp59hTXY5FSUgbmu27FBvrQbAQAAAAAAAOgUER8AAP//7N3RCcAgDEXRrFi7UAfSZkURnEEwnLPC+w03ohpwUI5/HSD6OMLVnrcJawAAAAAAQHHZ87MxxYgyXGoHUURRqECwCgAAAAAAAOC0iJgAAAD//+zdQREAIQwEwUjDApxOwALS+KDhKFLdOjYTUQ342ezD1xFeV+rXjNYAAAAAACA/x79kUk6cgfcIopDBEqwCAAAAAAAAuCAiNgAAAP//7NzRCQAgCEBBVxTat0aLoB1EuVtB8Ed8ohpQQ1iD7rawBgAAAAAAzPaff48xM4g4QzO58u0hd0kmEKoCAAAAAAAAqBARFwAA///s3EERwCAMBMBIwwIzldkSC0jrtw4oYVfG5XJGNWCBfMZUQKQApUMAAAAAAKjPEzCVtH51Aw17cZOkgpl36ogAAAAA8CUv4g9k8ADAGSLiBQAA///s3EERgDAMBMBIAwkBBGEIKoHBGR9eFQDTzK6EyzPJKdWAn7TjnGXP4KZcl90QAQAAAACgrvcJ2GEnlVymOYbc0i6SKhRUAQAAANC7JQIAAB+JiAcAAP//7N1RCQAgEETBq6gGEvsIV9EfO4jHTI2Ft6Ia8JawBr+bbXRvXgAAAAAAUFjutGlRiljDNzzkUcG6gSoAAAAAAAAAXoiIAwAA///s3UENACAMA8BZJEEmMAlYQwZk3EnYd02rVAMuyrkse1GBMBsAAAAAANRnZZ9K/Lce13rbv9+AGnKkEh8AAAAAAACAmyLiAAAA///s3cERwCAIBEBKswUS24xp0bGKGNwtgeEHHEI14GPvM3z24u9a3pdFIAAAAAAAKMxRMNVkTz29qezZ1gzy9DpQgkAqAAAAAGBr7oEAgCNExAQAAP//7NxBEQAgCEVBKqqBqGY0L4RAZrcCR/48UQ3oQViD3+U627ANAAAAAABm89Nikqx4A/2kmzDAFaQCAAAAAAAAaCAiHgAAAP//7NxRDUAhDAPAWcfPg1l40ggJIsZyZ6GfbepUAwrIuf4zqJAFjzNuAwAAAACAxvJLnRbd6LeKuUcnzk7oYEgRAAAAAAAAoICI2AAAAP//7N1BFYAwDETBSKuFFp0UC0jrJR4IeTM+9q+oBhTx3NuzF3835rU87QAAAAAAQG9GwnQyMuJAHUIndPBmiAoAAAAAAACAr0XEAQAA///s3MkJwDAMBEC1qMT9pKGAWzQB//OVxUwbezjVgFoca3C6J+9L8RAAAAAAAJraI2FDYTpx4lBEjvwO/GWNHG++U/cDAAAAgD+yFqqQkwAA/UXEAgAA///s3LENACAIBEBGcwUTF3IgdUUbeztjyN0KVAT+lWrAR9aYnhDJwEINAAAAAACJCQuTTKmtKnL4gzsjGXRTBAAAAODm5IcAAIAXImIDAAD//+zcURWAQAgEQKJdBTwDGUglgtWM4cmbqbD8LeCpBiymrtsSIn83cm6HFAEAAAAAoDVHw3TySPNbuad+kRbqLLMMAAAAAAAAsJKIeAEAAP//7N1BAQAgCANAKqqBqO7HDgreNeDPNqUa8CbFGlSXY02LXgAAAAAA0NQJDVtRow2lDtfl5/fTg18PAAAAAKAcw7oAQHsRsQEAAP//7NxREQAgCERBqttHpQLRjCHD7FbgkzdnVAMaynNLhMgAwjcAAAAAAJhtuS+D+G19YtCEISp36jwAAAAAAAAAuomIBwAA///s3UENACB/jUlYAAAgAElEQVQMBMFKqwUSbAIW+aCBQDPj4/ZENeBRa0wPJvwu1SoBAAAAAKCuMx42IKYMcYf7Wm8paEIRQlMAAAAAAAAAL4qIzc4d0wAAwlAUrDQsAIIIzlkwwEKgubPQ7Sd9ohrwNmENfjdqb8UVAQAAAAAgLU/EZDJ25IF7BDXIYO7QFAAAAACcsCnxCls9AJBbRCwAAAD//+zdwQ0AIQgEQEq3oFNquM78WIEPo2SmBHgRwiJUAy6WffjuRQWGawAAAAAAKGodEQvWoBK7rUNWgIkQE56XXzZdBAAAAGDDr2gAAHBAREwAAAD//+zcwRHAIAgAQUozJaB1Rlv0YwuZicxuCzyBE9WAn1vvfMyIy7Uc3RERAAAAAAAU5ZmYYtqJPfA9ARMqEJYCAAAAAK6Xo9uNAAB1RcQGAAD//+zcQREAMAgDQZzXWqXxqYU+ktl1AQwnqgEZhDVIdwzYAAAAAABQzVMxTcQePnvhEvdD0l1hKQAAAACghJ09ANBrZhYAAP//7NxBDQAgDAPAScMwIAGk8ZkFEljuJGzftkY14AOzjy2ISAHChwAAAAAAUFSWirf/UkTL0QfuWW5LAXIcAAAAAAAAAK+LiAMAAP//7N1BEYBADAPASsNCAZlALSANFTwus2sjaWpUAxYx96OIyOq2PnZfegAAAAAAIJfjYpIYjP9Jny0zJME71+hwAAAAAAAp5CIAQK6q+gAAAP//7N1JEQAgDASwSsMCIAjrfOqA6YNOomMPoxrwF0FEfnfmXl69AAAAAACgoSwXKxjTxTD+UEYwlw7kNwAAAAB4kue7AABAtYi4AAAA///s3TERwDAMA0BTC7TwSWMKhdYlELpE909Bo3WyUQ24SD/7VcwggJIcAAAAAACE6tVDtgRx1/qZoRJCzDMkBQAAAAAQwxNdACBWVX0AAAD//+zcMQ3AMBAEwYdmCh8HZiRTdBMIbnyaAXHVaUU14DJ/idI5g5uNno+zHAAAAAAA5BKJJ4YIxDn99hAqIcH6ll0AAAAAABKJagAAmapqAwAA///s3EERADAMAjCc7aas1mdin3KJhPKlGNWAnRQR2W4sWAIAAAAAQCfPxpQxAvGPW9LgShEAAAAAKHUECwBUSvIAAAD//+zdSw2AUAwEwErDQpMnE6gEKg0RcIBmxsLeNv04qgE/VMfZDmswgKE5AAAAAACYy9IxY+TKS5rP5MrNhzsG6NqrBQkAAADAi/RNfIkeHwCYKSJuAAAA///s3cERwCAIBEBKswW1oTQUU0M682MFTh6R2S2BHwMcQjXgUM89Ls0zhyu1NwuIAAAAAACQ0Do6Nssii7JCIdgncJ8MPD8BAAAA4GuvivIntTfzEAAgn4iYAAAA///s3DkNADAMBEFDC/RAS2ME6e40w8KPVlQDsnnYIN0xcAMAAAAAQC23LJqIQnzaIImbIOnuBqMAAAAAAJrZ5wMAfWbmAQAA///s3MEBgCAMA8BuJuyrdAQczQ8L+KTcrZBnmxjVgI3lM17PiBQwhQgAAAAAAPWs8rECMlW0NQ7Bf+6BbC/v7FIEAAAAAA5wCRkAKCciPgAAAP//7N3BEYAwCARAWkTtxzQU02Iq8OET3K2AGb7HoVQDilvzGcKIVJfnIUgHAAAAAAANOUKmmdtCv8krR6V54YVnJwAAAADAXygYBwD6iYgNAAD//+zdwQ3AIAgFUEZzBXHNJq7gaF5coIcmlbw3AxwI5CNUA2pwwMHtWh9p8AYAAAAAgJrssqiiCYl4TRAJt1vzmfoeAAAAgE+cR7vwK32kugQAaomIDQAA///s3DERACAMA8D69wJIoNJYEMBK7t9C1iRONSDAGrOVEQmwhQgAAAAAAHnuGLlFSwgnEY8ckBBCFwMAAAAAAADgZ1V1AAAA///s3EENACAMBMFaBGySYAFpfBDAt2VGRnNdUQ0o4tYpjRFJrY0urAEAAAAAADV5SqYMsYhnAiRkt9dcdhgAAAAAwG/c9wGAWiLiAAAA///s3LEBwCAQAsAfzRXeuP8sNvbWkrsVaAGnGpBFGZHXjf7mkCIAAAAAAGQ5o2TDZFIok170amf6JNDBAAAAAAB+ybYHAIhSVRsAAP//7NzBCYAwEETRbTFgQxYUbSGlieA1RyEZ3itj9zNGNSDI3a8h6iCAwA4AAAAAADL5YxHDaMRcO9ob2opt2d35DUIBAAAAwN/8T1iROz8AkKOqHgAAAP//7N2xFYAwCAVARnMFzUBmoBhWtEnnBMG7EaDjfcBRDSgmn9l9+WJ3Z7uEEAEAAAAAoJi1nCwYShXHOh7B160m7C5Hdk0EAAAAAH7MrB8AqCMiXgAAAP//7NwxAQAgDASxSsMC4N8LCxMO+iQ2el9PNSCTGJHuxtxLhAgAAAAAAGGMlAkjKH3cRyPufHSnuQAAAAAAvmfXAwDEqKoDAAD//+zdwQ3AIAwEQZeWhiElQGl8kOgAJaeZEuynpbWoBgR6W/fliwTDFgEAAAAAIJI7FimeHZHgEBrh76YAFAAAAACXTQPno9xAAIAMVbUAAAD//+zd0Q2AUAgDQFZEHegtpK7oDzMYbe62IIWiVANC3ee1DNb8Xe+bYg0AAAAAAAgzx8pyLFIokRh99LJgSwDFTwAAAAC8ah7rwhfJQACADFX1AAAA///s3EkNACAMBMBKwwJgk6QWkManJmhmbOzhVAN6U/bgd2PupXgHAAAAAAD9yLHoYtSZBMq1/O/mSQMGAAAAAIBi0wMAtBARDwAA///s3DERACAMA8Bawy93lYA1FhYkEP4tZGwToxoQ7KxVekjkdUuCAAAAAACQ5ZSWFZdJ8f2YhGEREvTsIUgAAAAAgMv3NxAAIEBVbQAAAP//7N1RFQAhCARAolnhtJCFTisaQ+HNVOCPtyxKNaC4/a8pkEh23+iKNQAAAAAAoBjHy1SiVEKolvQ8LAEAAADgJvspXtVMBgBILyIOAAAA///s3AENACEMBMFKewsFZJJgEQNvoHTGxbXJimpAD8Y11X05hyEOAAAAAADv8cfiFW2jErlSIJ/yzj7dwzgAAAAAAL9yDvdTAKC2iLgAAAD//+zdQRHAMAgEQKS1EpiJzbYWKi0KYuDYtQDP41CqAQN8z/sLJBJAGA8AAAAAAMI4YiZJrx63z7368qWOALchAgAAAAAcjS0WBwBCVNUGAAD//+zcwRGAIAxFQVoECrIhNS1QmuMMPWhgt4Vcf56oBmwirvsdcA33JrPam7AGAAAAAACsxzMzqzhmZGInhrRkN+IMWwoAAAAAPjV/fuC3am8C2wBAXqWUBwAA///s3DERADAIA0Ck1Vqdd2HvHPi3wMRBolQDdrnmTbhjEQcAAAAAgFk6zCzQzBRrSia6QMTtjnT+KAAAAAAA/pRsAwC5quoBAAD//+zdMREAIAwDwErDGoIACSCNhZmd8m8hY3OpUQ34yGh9KYSQwBQiAAAAAACk44ZFFuWMTfxAgZbX1TPsBAAAAADAnSe5AMC7ImIDAAD//+zd0Q2AMAhAQVZEHagDqaxoTByi1LsV+KR9iGrAz9R1D5e+6C73TVgDAAAAAAAW8n1qtsNiFcvHJvLId+/s8Syt1VnDBAEAAACYiAA5sxPbBgB6iogHAAD//+zcwQ0AIAgEMEbTEUgc08QVncEn2K7Ai3CcUg34k0Wb6jRcAgAAAABAM2efaaY0MXJl91uW4CzVyU0AAAAAALzxxwMA1BQRFwAA///s3EERgFAIBUAqogYykEoEfzQzOF4UdxMwAyceg6ca8EO1H8OBCA2cmggAAAAAAO3IsOiibZaVS64vKAOeGLWVOQYAAAAAuCnnyW4VAPieiLgAAAD//+zc0Q2AMAgFQFbUDtSJ1BUcrWnSDfyheDcBCV/khadUA37que55xLz2z86OdirWAAAAAACAQtaTswyLEgqXT/QEM8AXCpwAAAAASGf9+UB2MgIAYD8RMQAAAP//7NxBAYAwDATBSCsS0iKzUAtIwwO/lBkL901WVAN+bF33YX+Kazl6MyIAAAAAAGzFszO72O6wNM8Uvae6Z80l3gQAAAAA8FGOLgADANQSES8AAAD//+zc0QkAIAhFUVcU3KfRWi2CNuhLOWcNfVdUAxDWoLstrAEAAAAAAHO8sbPBMyNk5ZjH0qy8Nzl3OboTbgIAAAAA+LPseACAViLiAAAA///s3VEVACAIA0Ca+wykVvSHEIJ3NcaGUQ343FnbUSIdtPvyBQAAAAAAn1N6pouRYxQdyOSobuZwEwAAAAC8Sj5CFTIDAKCOiLgAAAD//+zdwQ0AIQgEQErTEvTaNLFFY2IJfvBmSuDLsijVAHaxRjUFkivt6898+QIAAAAAgL87R8+Co7wifbD0FIP4Okdqc0w7ZQAAAACAO/Ydj70BAJBDRCwAAAD//+zdQREAIAgEwItmM6sZzY+GOGa3Ai8GOIRqAJ9gDdptDTkAAAAAAMzh+JlB1gulaObjHO3sRAAAAADQ4KgSRcwOAIAOSS4AAAD//+zdUQ3AMAgFQKTVWv1sxUKlLVkqopA7C3wR4CFUA/jlu7bmmwY05AAAAAAA0MtUT5ooO8c6gSDC7als55P2IQAAAAC43rntgSqG57gAQAkR8QEAAP//7N3RCcAwCEBBR+toGaiJI3S1UgjdIBDD3Qz+iPAU1QB+2YfPLFT3LeS+1gEAAAAAwCHyziYMzyGuGaeo6DGEFCfQBAAAAACwhhsCALC/iHgBAAD//+zdQQ0AIAwEwVokwQ+GSLCANP4o4MiMjbZbUQ3gJqxBuqF0CQAAAAAAX3EMzS/iFktbb4L2pNtrLnEmAAAAAJKYixDFc1wA4HlVdQAAAP//7N2xDcAwCARANs9CjlnBo7lxkwEsBXS3AuWLf6UawEe+c1n7ooHHEQEAAAAAoIfzDC2/ooWCJRVyN0rLkYZFAAAAAADuMo4LAPxbRGwAAAD//+zdQREAIAwDwUrDMGCRPxggnV0d6VVUA3jsuYxKSDeULgEAAAAAoA9H0TQSE6kIDIDAzUdPAAAAABIJjZNIpBsA+FdVHQAAAP//7N1REYAwDETBSMNCZ5BZiIVKQ0H/uc6ujsuLqAawY5hIOqVLAAAAAAA4i+NojpAQqxj3uAxgCbd6tjAMAAAAAHH6eUU1SOQ5LgDwX1X1AQAA///s3bENADAIA7D8fzULYw9okP0FCgSlGsDTDuEGcdpZ9AMAAAAAgCMcR3NIQ4YlZ6OdIiYAAAAAmrnnoZHnuADAn5IMAAAA///s3MENgEAIBEBaswSSK1OlBLUzYwH+j8tMB8ATWKEawK86zk13aE7SJQAAAAAArMX+iiXkyGvWOnLkd/Dq6JXO7trL0wEAAAAAnT2mR1NCuwGA+UTECwAA///s3TERADAIA0Ck1Vqds7B3LHD/FliTYFQDeBFMZDpLlwAAAAAAsESVpBWl2eDUeEVHAq9Md10QAAAAAOALz3EBgH4iIgEAAP//7N2xEQAgCAAxVncgcUUba2vgkjWAR1QD+Do7LSYygcU/AAAAAACYw7E0U5SbYb3Qh2A9na0XYAIAAACAts5OUQI68xwXAKglIi4AAAD//+zcsQ3AIAwEQI+W7AvxCKxG454ygO5GsNy9/o1qAEvZv9eVOJylSwAAAAAAuESVpRWmucFTIxY7GT6Lk2VLuTAAAAAAwP/kDQDAPiJiAgAA///s3NEJwDAIQEFXtM0+ofsUsmJWyGeUuw3EP4UnqgGcEtagOqVLAAAAAABoYv3L74ou5i1z5EgxAqr7bBAAAACARty7KC3fR1gDALhDRGwAAAD//+zdQQ0AIAwEwUpDMFALSMMCCZ9CZmz0shXVAI7kmD5+8YMyo0QAAAAAAOCaMSk/aIViFm5pvGxlT2EYAAAAAIA6mrAGAFBCRGwAAAD//+zd0Q0AEAxAwY5mYawoEgOIHzR3K/iS6iOqAWzrtfnxi9/NC7mHVAAAAAAAkMBanhaFJ4PrMYuHwh5wSmgJAAAAgGzMQMhg7vEUJwkAXBURAwAA///s3FENgDAMRdFKw8IS/MwQrBKYNDQQPgbNOS7a5F1RDeApYQ3+rjvIAQAAAACgDCNqSlgZtWh7274Q9oAXZh5pYAAAAABAKXkOPy+quOx4AIClIuIGAAD//+zdyQ0AMAgDMPafpRIr9sMCfVVE9hZROBzVAJ5MKBfM2c5QIAAAAAAABJglat0VCX72V7ozVuvTnoMAAAAAkEoHQgqHNQCAf6rqAgAA///s3dEJgDAMBcCO5grRLuRA6gjiZqIbFKTScLdBmo985JE6qgE0O7ZdIIXRTbHMv/32BQAAAAAAfGr1nGQQNc7eZUSNJ8AqxMrIzAAAAAAAMrt0l0S670EAAF6llBsAAP//7N1BDcAwCEBRpM3COkE11AQLlbbLFOzQBPKeBbjyEdUA/hLWoLqpcgkAAAAAAPXlyu2omiauL3Jx0rQ8VJYrPVMAAAAAoLNtunRyP0NYAwA4LyJeAAAA///s3UENACAMA8BJwzBgAWl8UMCDhObOxbK1U6oBXJl9LMM5ARwJAgAAAABAAKFqgjzbX50CDyX0/MwzEAAAAACinewOJGmKNQCA56pqAwAA///s3FENwDAIBUCkzVr9dMVCpTVLpmAfTcruLPAFeTylGsBneQ8BFU73LONCtgAAAAAAUEMzRwq43rKLHRTQc7KZPT0UAAAAAPAH7mBUo1gDANgrIhYAAAD//+zd0QmAMAxAwawYdR8dqNAZullxBlFIvVsh9CvhVVQDeEpYg+rO3Dc/cAEAAAAAQHG99cthKYt4PXaRR97vxY6MyoSUAAAAAPiLYdIsSFgDAPhOREwAAAD//+zcUQ3AMAhAQaRV8FosVNp+5qBhS9idCwg8UQ3gSM61HSfSgEEcAAAAAAB68GRNB+OJXlQqD3dAoZ1XulMAAAAA4Bdyrup9MXxFWAMAeEdE3AAAAP//7NzRCQAgCEBBV2vfyhX7aYMwKO5G8E/QJ6oBHMsxmynyOos4AAAAAAC8bz9Ze7TmB2XRiwvBDiiVPd0oAAAAAAD8QVgDAKgXEQsAAP//7NxRDQAgCAVAolnN5s4OwgbeRYAvGDyhGsArjlbo7g7iSxcBAAAAAKA3z9ZMkRh+kRbYAQW2IgMAAADwIXsxJhOsAQDkiogDAAD//+zdgQmAQAhAUVcUGrNyhdvsoh3uiOS9LUT5imoAS9R1+/pFB4ZwAAAAAADowXEpHSyPX+SR9mH82aizdsVmAAAAAAD4zhvWmJ7lAgBbRMQDAAD//+zdUQ0AIAhAQSq6WVONYDVnB37QuxrAQ1QDSLPG9PWL8tQtAQAAAACgPkfXvCIzgtF6u4uollGpTDAJAAAAgC+tMc09+MUW1gAA0kXEAQAA///s3EENACAIQFGi2cxCblQwmhcjcBHfq4AXcPuiGkA1YQ1eNyzgAAAAAADQgn8rOhg3hlFhehE8bOfKbYAAAAAAfMx9jF8IawAAtSLiAAAA///s3cENwCAMA8Dsvwt0BboZqsQGREIldyPkbTtGNYBUT+vDdxgukPbxCwAAAAAAOGOVrwVMucH2GMYa5hBA5c/kEAAAAACo7q1+AEr5hjV0ewCAHBExAQAA///s3FENwCAMRdFKQ9oQNGaRnzooyQKc46JJ3xXVAJb73vF4UGR3jm8AAAAAADiCETYnaBnFqCiHOeBHPUNJAAAAAHCt3OrATZptDwCwRERMAAAA///s3dEJwCAMQMGsKDhmwRErgU6g9CN6t0UwLzqqAfzFgiLV5fDtty4AAAAAACjsi7CF2Jxg+ShG6y0Xrb17UdZ4hlgAAAAAAOBO2fa8+h4AYEtETAAAAP//7NzRDUBQDEDRjsYID2OiIzCaT/9NJDznrNCkX+0V1QAekdt+CmvQAUVLAAAAAAD4uFxzNEM6MLSlVQ9Gy0EOeAE7HAAAAABu/nT4q6PNkwAzAFATERcAAAD//+zdwRFAAAwEwLQY9ENBSAtK8/RmxiPslpFcLko1gNfUti8+f9FdjoNiDQAAAAAA6E/IlC+4vbfKKQVM6eyotWQOAAAAAOBiXsafzW58AIBHIuIEAAD//+zdsQ2AMAwEQI/GCsBALETwiEF0tERCIuRuBZd+v5VqAG8TUKR307wurV+/AAAAAACAD8g9lcHzCw0lGZvJ0zF5AwAAAAC4yXLYdTC668anuvMBAB6JiBMAAP//7NyxDYAwEATBa/GBMpFcgimNhIzECcGjmS6sfZ9RDeBTz4PdoQvdWbIEAAAAAID+NCv+YHkko47SuOjsGufwQQAAAAAA3vQOSGbtmw4CAKxJcgMAAP//7N2xDYAwDATAjAYjOGEgBgIyIghBiaCisHS3gZXKejnvUw3gd33dNH+RnmUbAAAAAAByu4+zZVakF1PMXzPEFGdDm5Y20upLH70eAAAAADySdcBliFb3aFUeAgC8K6UcAAAA///s3cEJwCAMQNGM5mZOpI7Q1bx46aE5CinvrRAQQuArqgHcooRJdc2iDQAAAAAA5blZ8Qf9RDMy3aQpzFsNAAAAAB/WmKIa8Pb4SBcASEXEBgAA///s3c0JgDAMBtCsqC7UgQoZsVLoRUSPQuS9FXLKD1+EagCfWE27wxeq02QDAAAAAEBh2dPOir94DM1YgRvC4ikrezbVAwAAAIBXdh1wNR/pju3YzZcBgLuIOAEAAP//7NzBCYAwEEXBLS2WoCnIitQWJRDwEvEWWJlpYU97+E9UA5jmOs72mChikpp6JQAAAAAA5GaszU+UHs8YeQ1uQAKLIwEAAADAJ9scGNvb7metm/g4APCIiBsAAP//7NzBCYAwEEXBLc0WApapbglaWsjFi0huwspMF8lnn6gG8DU1TKpbPK4BAAAAAKA8mxV/8IhntLWNaIwti6qu3NIxAAAAAABM5H74R4N3Yyc5xTUAgFtEdAAAAP//7N3BCYAwDAXQjOYKhQ7UgYSO4Gpe2ouCeCpE3xuhOaV8fpRqAEuNxV1IkewOEwQAAAAAgLz63psrbnzAVmq5hkFvRRuQiCwBAAAAALznPw2ezXKN5p0A4Oci4gQAAP//7NyxDYAwDEVBr2hgH8Q+AY8IoqFOhRS4WyFd/PSNagCvq/0QKTK8e7HSKwIAAAAAwNDEpnzBc7PKJUWhjGyrVjoCAAAAAOjnPw36rDlPp3ENAPixiLgAAAD//+zdsQ2AMAwEQI+WFUgGYiHAK6ahQHSpkMXdCi79fivVAL4ipEh1bRv9/fkLAAAAAAAo4j7eFjilvEeZxm6aVJVHCjMDAAAAwII8LzsOWKNcAwD+KiImAAAA///s3LENQCEIQEFWc7K/kIkjuNpvLGy1MejdClQQ8kQ1gCPG8i6sQXbdBAEAAAAAIK9WWzE+LvBNYQ3IyO8AAAAAAOxxW4N14hoA8JqI+AEAAP//7N1BEYAwDATAWKQIooJaYgFpeOiHSdm1kO/dxagG8Jmcd/f9i+qOsxnWAAAAAACA2gRO2cHlihT15EjBZQAAAABYo5MD64xrAMBfRMQLAAD//+zcwREAEBADwCtNC6gTLfopgIdhdlvIN4lTDeA2JUVel3ItSYoAAAAAAPAmY26Aq3QGAAAAAGDTaN2pBpxb5xr2QQDwqYiYAAAA///s3MEJwCAQBMBrLSXEFJSGApagpUkgHSgRZaaFfR3snqcawFTfAa8kw+qKBAEAAAAAYGmH+AB+V/OTlf4BAAAAoI9NDoxxv/ug80rFcw0A2ExENAAAAP//7N3BCcAgDAXQjNaBrVlRBA+9WxTlvRVCDmLyI1QD2C7f2q9/GZThaP3RrIIAAAAAAHCmsdTtvwpgoSwp0AgAAAAAJo2dHOA/zydcQ38BwA0iogEAAP//7NzRCQAgCEBBR2uFbKBGL9ohIuFuBD8CkZ6oBvALZUyqa5ZlAAAAAAAozb0K4B1vLgAAAADcIxwO9524xuwj1/kv1Ec2MwaAoiJiAwAA///s3VENgDAMBNBaHAiaoUElbDjDBJCNvCehf00ud0o1gCnkcQ6hGX6gepIBAAAAAGBN2XIInQJ8I1saLAAAAACA51xuCa+qEdHLvnWDvACwoIi4AQAA///s3dEJwCAMBcCM1k6mA7VmxJaCI1RQuVvhQb6SPE81gGnk3apFRTZQhAgAAAAAAGvKK0/RAQxn1gIAAADAj/o9DjDe0Qt5n++5hmJeAFhERLwAAAD//+zdUQkAIBAD0ItmNfsIRtBoYgcVD96rsM/BZlQD+E2VCMkVq5MAAAAAAJCavgrgntlbd7YBAAAAAOfpN+Ctfco7DGwAQAIRsQAAAP//7NzBDQAhCARAOr+GVFqwNOPTAsypmWmB1wZYpRrAUbK2LsjzgE8YBgAAAACAO2XJWZ7t4RtgD/cAAAAAALCH3Qb8ZynYMAcAOExEDAAAAP//7N3BEcAgCARAOrehKCXE0vxYgo4ms9sCP+Y4lGoA18naBBX5g2KKAAAAAADwWY6+Adbr+aQsAAAAAABsMJ/c2r/BeWWWa7wKNgDgEhExAAAA///s3NEJgDAMBcCMFkdoXciBCp3BzUTwwwEstnAHWSD5CiRPqAYwK4eKrC4tvwAAAAAAsKbn6dvhKcCHeuubfgIAAADAUKf2wjTyFbBx11H2msYDAD+IiAsAAP//7N1RCQAgDEXR19xEagSr+WMERYVzQgzG4E5UA3jSKmQKa/C7YuEFAAAAAIBvuVUB7GOmAgAAAMBhvTaPQeFdJckQ2ACAC5JMAAAA///s3bsJACAMBcBs7kJCVnA0ESwcQEXhrskAVvnwFKoBPGs2834A43fFCwIAAAAAwH+yphB4gD1a1nTMDwAAAAB32G3A+9aAjVHN0AHgpIjoAAAA///s3dEJACAIBUBHc4VqoUaPoBEiEu7ACfwS8SlUA/idYZ7q0nALAAAAAAA1OQIHuMLeHwAAAADe8dwWauK2YcgAACAASURBVMkdsnECNnbNNnrqIQBcFBGLnTs6ARCGgQB6qzlZF1IzQh1NhE4gIi28t0K+LiSnVAOYWh3nE+Y3U2JxTaAFAAAAAIBleQYHeO+qvRzxAwAAAMBPxh+OnRysqyXpo2CjK9kAgA8kuQEAAP//7NzRCQAgCEBBR2uzGihwxXaIiJK7FfxS4YlqAM+z0FNEN0gAAAAAAPhPzhx+VQDbhIkAAAAA4D53OaihiWwAwAERsQAAAP//7N3BDcAgDAPAjFZGY59CVkQdoTyQgu5W8CuS5RjVAErIMZukKO75DlchAgAAAABAScqnAP/1fNMoEQAAAAAc5rktXMvIBgDsiIgFAAD//+zdsQ0AIAgEQDZ3IRNmcDMbCxsLK4O5G4EOAo9QDaASwRpU1zSqAAAAAABQzzoKt3wKcCF7ejoAAAAAAO8MtYfvnUI2zOcBYBcREwAA///s3bERwCAIQFE2d6FERoxN6O089b0VuKPjI6oBbEMpk0M0gwQAAAAAgP3kkwLwAPPsTAAAAABYKN/uqB7uU5GN9kc2vopseBIMwNUiYgAAAP//7N3BDYAwCAVQRnMz031URmhH66WePRrS9xIWgCPkI1QDKCXvx+EN1R0SHwEAAAAAoKxmdACfRl7pYQYAAAAA/M9eAzhX9RWy0d+gje07A8A+ImICAAD//+zcsRHAIAwEQZXmzmjIoBZJcELiFDG7bfzPiWoAFQlrUF1TeAQAAAAAgHryTecygH+O+gAAAABwgOzDrgHsni+0sSIbQhsA3C8iJgAAAP//7N3BDYAgDABAHg7mCuBE7qMygriZIYGf/sXcrdCEtCVtJ2EGRpP3o8QllZbEw6hqAeo6EwAAAAAAjKcugD/FDeBRyVv2DwoAAAAA37G2+QWAN3Of04tL6u9F7fVfwYIeAP4ghHADAAD//+zcsQ3AIAwAQY8WRkDKmAFWyGgRUUoqqli6G8GuXPhFNYCURutllvBsj8SOWXB0WAIAAAAAQC7zWbyeVQAeYGFco5gLAAAAAPzKLaoBbFiFNuIL9cQb2W5dZBuAHCLiAQAA///s3bEJACEMBdCseOdAh6PdZhLEytbCwHsDWFgERP6PUg2gMlvAqO572usRCQAAAAAA9XSlGgCb7koAAAAA4C6ZV8jcgn8N4JBVsJGZqHVizpg/5syxfBiA+0TEAAAA///s3NEJgDAMBcCM5gpV9+lChazgaP6odIGilbsF8hd4JDylGsC0BHt+ol7hEQAAAAAAmES2PMpe3KkAOtnSoywAAAAAfJOycGCk5d4xZVtrN+cp41a2AcCrIuIEAAD//+zd0QmAMAwFwI5mR0jrQA6kZkT9ELpCLdyNkHw9Ai9KNYCl5XXX6O2xRRa2RW+HcAgAAAAAAGvJM2vs4U4F8KnmAAAAAAD/5KktMMko2FC2AcBUpZQXAAD//+zcsQ3AIAwEQG8esU8kRiBshlxESpMuBYS7zrW7t/VKNYA/yOecZpMs7MiAKoMqSwQAAAAAgKWU5zMYwKauela3TgAAAACYW1GqAUzirWwjbw39HhRuAPCZiBgAAAD//+zdwQmAMAwF0GymKxTcR7uP0BV78VC8eWvseyPkEAghP0I1gPQkZvIT5zP8AQAAAAAASbS7XeUomz0VsLi6egEAAAAAYHZub4AE9rFHvQI3xl2Ex8YAfBMRHQAA///s3bEVgCAMQMGMpiMAA4n7qIyoLZV99G6DPMrkfUQ1gE8Y57WWVm+vSWJLabWrKAIAAAAAQDp+dgP+bB/HcLgKAAAAADnYaQBZzYGNrbQ6jyG4AcC7iHgAAAD//+zdsQnAMAwEwF8tIxgyZsAjhGwWVKTMALLvOtcGgzCvt1QDWMmR5HajNFZDneENAAAAAAAaqTD5OIdmN2BL85pKAwAAAACgicoqVGbBnwawmL+FG/XePd9BETLAxpK8AAAA///s3dEJACAIBUDbrBWqido8+nOF8m6FB4IIT6UawDcs93ziFsM0YQIAAAAAwFN8dgMq2lIHAAAAgOe4aQBV9Dzvxpq5fEPhBkAlEXEAAAD//+zdsQ2AMAwEwKzGCCEsxD6ARyCbgUKFKOgT3Y1gW66st1ANYCixH1Mu86Wr9CyX+WyzrIkAAAAAANCH2KLmJa+fL0gAI6uxhQNTAAAAAOiMh7YAj7/AjXeoeG17U8kAOpdSugEAAP//7NyxDcAgDABBj8YKhuwTMVlWi+hoMoDDXe3OFUJ+UQ3gj1aM4LFZCms5evPoAgAAAACAOtZxeV4pqgGcYto0AAAAAJQ1RTUAPu1/vneOvs8JbgBUFBEvAAAA///s3EEOQDAQBdA6Ii7EfVSvwMlIEzYSC4kI9d5uttPdzPQL1QCKIzWTQuRgmMpjAgDA/eq2WbQVgKekOJrxAPxLfziyAijRlIbkSBQAAAAAPmr7d2OnAXDdWeBG3pvMe5Hi2OktwIuEEFYAAAD//+zcwQmAMAwF0G6mjtDqQA5UzQiuJr2JZ0Fa3lshIZdPvlINYEhxnIsnKXqX13K1XTZIAAAAAADoQ9TY85Yn5e/AyKKGDBMAAAAAOtcevvNalGoAfGN+ZsSv+6pwA+BvKaUbAAD//+zcuRHAIAxFQZVGC9gVURmUxihz5IwAzW4LP+N4ohpAZfmQZ1qYi7X+Pi0rsEYEAAAAAIBrDFENoLBhXAAAAAAoI8/7hDUAzvoLbnzvXZY/ZACHRMQGAAD//+zdwQmAMAwF0Dpi1H10IDUrdDTprXgWwfLeAj0EQqDtj1ANYFhtiIxlrh4t8nMtGGZSRAAAAAAA+Ic8ssYa7qiAIeWRtqcBAAAAwCDyvPbH524AvtX34C2WuT9c4AbAW0opNwAAAP//7N2xDYAwDATArJYRHBgTyAiIyUCRoES0JLrrXL87S2+lGsDQ6rrlmMopZXoWU9nbLgsRAAAAAAD6UJeaYw43KmA0bpYAAAAAMJ58PwMF4F/eCjdaucbxDK0gSW4AH1JKFwAAAP//7NzRCcAgDAVAR8sKxom6T8EVOlrxT0oXSHu3giAkT59SDeAPDPhUF31kaBQEAAAAAIBSjsdDJ4DKrnlOeSUAAAAAfMz6p9BHrt1fOFuAEmK/s/vIPZNWuAHwprV2AwAA///s3bENgDAMBEAzYiQGIvsgZQVGi9JR0fO5W+Ery/JbqQYQz4BPiFUMcwgTAAAAAAD+YdzjamdTqgGk6JIEAAAAgFjdzQ1AhK/Cjfeu5/H8GdhKVU0AAAD//+zd0Q2AIAwFQFZjBGAgF1IZQTfTmPjBCoW7DZrXz+ZVqQawhH6cubT6SJvISqvXt8tCBAAAAACAMPJfnA0Q2d337rASAAAAACblmS3AEsaCja20Os6scAOYW0rpBQAA///s3bEVgDAIBUBGywpRB3IglRnczJfC0gEwdx1tOh7wI1QDmImlRaprfV2axgQAAAAAAGoYR+h965ZQgdLySMH/AAAAAPBzPrMFmNpX4MaYdd9vkee1z/5QQFER8QAAAP//7NyxDcAwCARAsplXcDwRm1vurGxAuFvhC4oXb1QDaMNyJj9xhmEeYQIAAAAAQBmpnwIKS+EBAAAAQBv5eawGoLdxd91zvfeNMLgB1BERGwAA///s3bsRgCAQQEE6s4YDy3TmSpDSHDIjx8wPuyXAZcBDVAOYinImfxCt7mOWbSYAAAAAALxfbtljDeF34It6bukCJAAAAABMYjyIjlYXZxoA3HAV3DhH2/v4LN2CAo8qpRwAAAD//+zcsQnAIBBAUUczI6jZJ7hPwBFCNgsWQvpAQHyvuv6qK+6LagAr6jGCy+aZWEwlRwcFAAAAAADMoZ1tS3sSfgdmU20MAAAAAJZTRTUA+Ogd2DhSyWPuv3D3mP3GAb8JITwAAAD//+zdwQ2AIAwF0LqZK4ATuQ8JKzAa4Wa8SyS8t0IP7aH9FaoBbGcMW+nKvoGxuhEMc6giAAAAAAAs434tDwH8WaulWmQEAAAAgM24uQHgQ+ejvwjbAOaJiA4AAP//7NzRCYAwDAXAbiaOEHUg3UftCI5mKbiCYundCi8/IeQp1QC6lI9zjHm6LPm0rM5wnWUhAgAAAADA/+U9r7HE4D4FNGITFAAAAAD06fm5ucUPwEeUbQDvSikVAAAA///s3NENgDAIBcCO1hXUgbT7qKxonKCfDeFuBPgijzylGkBlw9MiyfXt2LuDAAAAAAAA0pBPARmMuEMGCQAAAAC1/ZnGWX0IACw1LduI572sCJhqrX0AAAD//+zdwQmAMBAEwLMya7jEhuxHSAlamgREtIOIM58rIK+Q241SDeC3ehFB1uKSz9ftETE5RQAAAAAAGF8PqeeSh2INYGRta5YPAQAAAODnekg5a5m9aQAwoLtsI2t5ZkPXax4+sQZeIuIEAAD//+zcQQ2AMBAEwLWGhLaCCIIKErDG6zxQmFFwyb02m6xRDeDXhHy+oI1+X/PcPBMAAAAAAJZw6KaAF9M7AgAAAABFpwHASmpgY2+j19mGNoAkyQMAAP//7NvRCYAwDAXA4GSu0HYgHUjoCHYz/QmdweIdvAXyEUJCNmUAmIMRrGovrVpUAQAAAADAAvrVh/sU8FEjexQAAAAAQOTzsZsGACs7Mndp9cmcGf948BcR8QIAAP//7NxJDQAgEAPAlY4gYCVgjfDEAceMhb6aJnWqAXxPyecRQ5AAAAAAAHCHrFlEBRzIbg4AAAAAbLL1tWk44wXgJY424DcRMQEAAP//7NzBDQAhCABBWlTbNLEEr7R7+TEWoGSmBV6EsKIaAJZ8kiitCmsAAAAAAMA7PK8DN/lGH27mAAAAAMCJmwYA2e2hjblCGyYPCUTEDwAA///s3LERgDAMBEGVZvq1UQvuDBJ7SCgADbstKFLwJ6oB8PDkU11TwwMAAAAAgBqyp+g78BnZ83ANAAAAAOBNjnPa3ADwM22HNlZk49qRDfs9KCgibgAAAP//7Ny5DQAxCARAOndFZ5dAa5fg1LGfGYkGCBAIaYVqABRHPpdIizkAAAAAABzDbwrYgVkEAAAAACyNrwsLB+B1rSorZCNn0MbrjYHtRcQPAAD//+zcwQ2AMAhAUUZzMxciYYVuZi81euxNYt5bgROBfFENgBdLPj9xGiQAAAAAAPRXWcNtCvhaZXn0AwAAAAB2CPQCwOO4QxsrsnGJbEBTETEBAAD//+zcwQkAIQwEwJSm/app4Uq7AgTxp8JMC4GwyWOVagDMHPm8rgjfAAAAAADwhmxZjQo4yA4CAAAAALZkH5+fIgAsKdmAG0XEDwAA///s3MEJACAIBVBHa+CgFRwtgk6dvFXw3gh2UcMvVAPgsId8wRr8bjXfzSsCAAAAAMAX/E0BN+ToI1UeAAAAAKjaNzf2igBQI2QDXhAREwAA///s3MENwCAIQFFW62Q6UJEVXaCXetGY90aAEwn5ohoAHypHd+RzgWaJAAAAAABwvnrL0wywg6APAAAAAPBb5XhMDQCWiGzADhExAQAA///s3cEJADAIA0BH62rdp+CKnaAfC4JwN0XAEI1qALwpEDHdEqoBAAAAAGAMBVSg086THk0AAAAAAFXuGgDwz8gGdIiICwAA///s3LENgCAQhtEbjYGVG0FGIyYUNjYYDTHvrUBDcd9vVAPgRu61GdbgB85PdfGQAAAAAACwthG3C9yBT+SWjvEAAAAAgGmaGwB4xXVk4xgjG9pAeCoiOgAAAP//7NzBCYAwEATAK83OkoY0JdiaBO7twxAhYaaFg3vtrlENgBftvKrwIhsojggAAAAAAEsQPgX+4NcAAAAAAMN0bgBgqiN7gXeObPSBDcP58EVEPAAAAP//7NzBCYAwEATAKy1WZkPRayGliaBvfSRiYKaEfR3cskY1AJ4pFDG74mAGAAAAAID/y5pN+RQYrGVNv0MAAAAAoIvc9kWSAPCJc2BjvQY27pGNInp4ISIOAAAA///s3MENgCAQRcHtnIbELUFKI9y8EC5KjJmpYpO/eaIaAAtZzyaswQ8URzIAAAAAAHxfHun5FHiT7RsAAAAAeJptAwD2G5GN6xbYENaHmYjoAAAA///s3bENgDAMBEBvHgZK8AgwWhQpFRUFEQLdreDS+n+lGgA3ZNs3q2D8QHFEAAAAAAD4BKF3YIUza/p7AwAAAACPMmYLAK8rc5R7FGwcCjbgIiI6AAAA///s3bENgDAMBECP5hUgC2WgSF4R0aWkCFIQd5IncGM3/0I1AJ7z4PN16SAGAAAAAID91SiB78ByNUpbJAAAAADwCmW2ALCNnAI27ulHO9N6+LWIuAAAAP//7NzBCQAhEATBydyI9EIwNVPwoXBqVRDLwkCLagBMUs7kEsUTDAAAAAAAR7BLASu5KQAAAADAVl9twr4A8D8lSRfY4GlJBgAAAP//7NxRCQAgDEXRNddAg1UwmhkEEdFzImyfD66oBsAC5Uwe0TwSAAAAAADuVlnDLgXsUlndMQEAAACAA4Q1AOBeAhv8KSImAAAA///s3dEJACAIBUBHa+FqhUaLRggiku5W8EdUnkI1APb54EN2ZTW9qggAAAAAAM+zlwJOcMQOAAAAAFzRaxtmkgCQgoAN/hEREwAA///s3FsJACAMAMA1t5CwCkbzZwVEEJW7EGNvTzUAFlWBb4GR1zWJLgAAAAAA3C17mksBu0bFEgAAAACAI+ruRl8SAN7hwQZ/i4gJAAD//+zcwQ3AIAwEQbeWynBBAbdID4mEAM20cC8/vKIaAB9UH+nA5wLNiAAAAAAAsLd6K00E/CDMAwAAAAAsV308/m4A4EgCG9wnIiYAAAD//+zcsQkAIAwEwIzmwEJWcDSxtE2jgbsVvgnkeaMaAHXKR3Q3zmErRQAAAAAA+J6/FFCxcqbSOgAAAADwhGENAGjvGtgQJ21FxAYAAP//7NwxFYAwEETBs4ayICiwEkAaDQaggeTNSLh674tqALyUbT8NGJlAU4sDAAAAAIB/S89qdAo8lZ7F0QAAAACAj/m7AYA5tDuucQhsMJyqugAAAP//7N2xCQAgDATAjOZmTqSuaGNlJxYGuVshkOr5V6oBcGG0LsDID6orAgAAAABAekKnwAk/AwAAAAB4bg3aKgAGgH+UrWDD4Df5RcQEAAD//+zc0QnAIBBEwSvN0ixIuBJiaSFgAYI/F5lpY5cnqgFwzhmJv2vqcAAAAAAAUFuOnGLvwKaZI+1/AAAAAEAJwhoAcK0vqPGswEYX2KCsiHgBAAD//+zd0QkAIAhAQTd3ocARWq2fBgj6sbibwlBeohoAl/bjXliD16WhFQAAAAAAeqtRDk6BE/bXAAAAAEArwhoA8L3cgY3pA3DaiYgFAAD//+zdsQ2AMAwEQI+WzWCggFdgMxBS6lQprOhuBXe2/C9UA2CBvO5TMxgbOAwRAAAAAADK8ywPzDzZ0+0aAAAAAChnBGvYXwLA3tooAH//cA1F4JQQER8AAAD//+zdwQmAMBBFwS3NFoxtaraEtCaBnD0JRjJTxsJ/K6oB8JK8qmImf7epwAEAAAAAwNzyTLd84InwDgAAAAAwrbG9EdYAgDX0J+BtP0qzW+RTEXEDAAD//+zcwQkAIQxFwZS2nS32s5ASVwSPHkUUZ9pI/hPVAJhLWIPTvepvAAAAAACwPTcpYKTkl57RAQAAAICtCWsAwHWevlv8W1zDfpHlIqICAAD//+zdsQ2AMAwEQK8YGIiFAI8QRosi0dAjFOBuBVeW9W+lGgA3ym0/LPZ8wGKIAAAAAAAwrjM07yYFXOSavjsBAAAAAK+gWAMAfqtnF2uZp6pcg8dERAMAAP//7N3BCYBADATAlJYWPCuyco+DPK4ABYMzLSyE5LNRqgHwsDrsobNcS6kEAQAAAADg0y7xABszAQAAAABoRbEGAPxaVrnGfZzD8wDeFRETAAD//+zcUQkAIBBEwY1mMwsJV8Fo/mgEQWEmx+4T1QC4Q1iD3zWlNwAAAAAAeFeNmoamwDZrlKEZAAAAAPAdYQ0AIEk/cQ2fRq5IsgAAAP//7NzRDYAwCAVAVlQHMu5jywhdzbBDTay5GwH+XuAp1QB4QbbuiJE/GLYIAAAAAADflXcqegfKZQoAAAAAwMJknABAOeuncTv2oVyDqSLiAQAA///s3cEJACAMBLCO5sCCKziaCHUDBcVkhX76aO+EagAckmmZ8LS5gJogAAAAAABczaEp/K232hQ+AAAAAADPymJbPzgAwFKEa7BVRAwAAAD//+zcwQnAMAgFUEfrCkkXykABR0zpobeeCoGEvjeCXhTxC9UAmMtSz+4OgycAAAAAAKwre7b7qV6L4J+yp5s0AAAAALA9wRoAwIsnXGOUszYF4rOIuAAAAP//7Ny7CQAgEAPQbC5O5mo21haC4Oe9FcIVgSNGNQA2GqXeEyO3axIEAAAAAICjVfHAl9w+AAAAAPAMwxoAwEQxrsGyJB0AAP//7NzBDYAgFETB3yLaJrotWoLxQCIw08UmmyeqATBYrtugZ3rtPIQ1AAAAAADgp9Ij9A4bSo/DGAAAAACwFGENAOCFuAbfVdUDAAD//+zcSw0AIAxEwUqrBUARzrHQE+EzY2FPTZMnqgGwh4Oe22UbPa0IAAAAAADHmqaBr/hBAwAAAABPEtYAAArENaiLiAUAAP//7N27DQAgCEBB9p/FxBFkNBt7rYyfuxUIBc1DVANgg3HQ+w7G7ZoJAgAAAADAmWqpKawB38ix8wAAAAAATxLWAAAWiWswFxEdAAD//+zcsQ3AIBAEwW8RaBPzLboCAhJk8EwXJ51WVANgk3yGMc/xSqvCGgAAAAAA8FHZ00kE/kFABwAAAAC4nrAGALBAXIO5iHgBAAD//+zcuw2AUAwDQLPZWwGYiH2ArMBoiJqGCvG5W8FVLMVGNQDu5Zjn7Vo/Dk2KAAAAAADwWJ7t4dummmuTMQAAAADwB8ewRi1rl0QvCgBcYVyDsyQ7AAAA///s3LENgDAMBECvxmYMFPAIrEZjKXWaKJC7FSwXr5feqAbARLWSKcjzdY8LAgAAAADAmrLlqY+C/6ofBwAAAADYSl73of8AAAYY16CLiBcAAP//7Nw5EQAgEATBtQgowjkJCggonm4LVxdsMqIaAJvNIQ9XK60KawAAAAAAwLm628CT/DYAAAAA8C1hDQBggbgGSZIBAAD//+zcQRHAIAxFwUjDQotNZmIBaT1hgAtQdi3k+vNENQDWENbgdOWpb3FFAAAAAADYT7bsRqXwOz1bGnoBAAAAAFcT1gAAJo24hp/IG0XEBwAA///s3EERwCAQBMGzSKIIP0lOwllDBI9Q0G1hv1sjqgHwg3w/R0Z2UFYEAAAAAIA15ZMi77CXbk8AAAAAAGENAGBKtfsqcY3DRMQAAAD//+zcyQ0AIAgEQEqzYBNbsDRjQgV+vGZa4AOBxVMNgE1yiIerzQZSBQEAAAAA4FhC+PCG3mpzIA4AAAAAkDKTYw8CAKwonmt8JiIGAAAA///s3KERACEMBMCURmkUBKRFFAaL+IfZbSEm4u6MagB8y7AGtyseRwAAAAAA+KdsWZ0GniAYDgAAAACwyT6qXg4AcGCNa8hWvC4iJgAAAP//7N2xDYAwDARArxgYCLEP4BEYLQiJko4iCbpbweXbfk81ABrK/bjbhDQKMbrTBAEAAAAAoFuWSWFsa24pUwYAAAAAePHc5chCAIAvljJP1XONH4uICwAA///s3MEJgDAMQNGM5gpt19RmBFcrgmdPQq28N0JugeSLagBMlke3vLO80qqwBgAAAAAAfND9jO8hHxaVezrcAgAAAAB4IKwBALzkimucpdXNQH8mIgYAAAD//+zdUQ0AIAgFQGxmNQOpEazmbODmj7q7CvzAGA+hGgB3MLzzuqxZBAAAAACAaxWlgSfZIwMAAAAAbFjBGr22JGgcADi0biSHJ+SfiYgJAAD//+zd0QmAMAwFwKzmCOpCDmTNCm6mCB2gH3605W6EQCAh8CJUA6ADNRXT4s7oDIoAAAAAANChPNMtCsZz194FAAAAAKBRlmtxEwEAfvA9IX/WfTsUcwIR8QIAAP//7NzRCcAgDAXAjOYKrQNJ9xFcsQguIPhh4G6E5CsJL55qAFxiDe6Qmg9sAAAAAABwp9GHWxTk8ukXAAAAAMC+lc+xYwUATmgzM/nUt6hmYhHxAwAA///s3cENwCAMA8CMxmgdCJoRYDTEClUfRLqbIg879lQD4C7CjFTXHIgAAAAAAHAtAVKoYWVPS4oAAAAAAB/leB8dHQDgJ6cvOQ2SFxYRGwAA///s3dEJgDAMBNCs5mYOVL0RKwU30I8U3psikEvOUw2ARnLdKxglHMXuDIcAAAAAANBQRk67KOgvI4LeAAAAAAAfvTc6h90IAPCTVUg+lZJvqKoeAAAA///s3NEJACAIQEFXb6BqhFaLoBH8ULhbQfzTJ6oBUMyey4EU7amuAQAAAABAWcNooDQ7CgAAAACQ5IU1/p+OsAYAkOX4n2wmIi4AAAD//+zcUQkAIAxF0UUzmoGEVbCZIhjBjwnnVNjv3hXVAKhJWIPfNcU1AAAAAACoJ0dOj6NQ1syR3XkAAAAAAN66YQ1RYwDglbOfXDaUn4iIDQAA///s3dEJACAIBUBHb6FqBFcLdyiQuBtBEPx4qqMaAA3VJUxhRj6QhkIAAAAAAGhJaBR60psAAAAAAI/suYYnuADAZbVDmYraXEQcAAAA///s3cEJgEAMBMDYmS2oBdnQaVq4zhThSlCIMNNCyHN3lWoAFDVaMOHvdhcEAAAAAIBasmUX3ody+vhNAAAAAAA+8ozg5nFOhnABgBfNy7ZeBsoLi4gbAAD//+zdwQmAQAwEwLSoNmRBB1dCWjsES5BjhZkSkk/Yx0apBkA2xRr83XMQ3rYIAAAAAABZ5pjye8ii6AYAAAAAYJP3Ea5cFgD4Uh/X2SYaqKoWBMC0EAAAIABJREFUAAAA///s3YEJwCAMBMBsbt3HNiMq7iASyt0WIfy/Ug2AwnYDpiOdH2ha1gAAAAAAoCR/KKih50iriAAAAAAAF+X7PcZwAYDD9kj5lKcsJiIWAAAA///s3dEJgEAIAFBvxLqBWqjLEW61CG6ECIP3RlD8EEUd1QAobjXpFqj4u0MGAQAAAACgljzTHAoKWLUIAAAAAMDHnme4Oa5mXgIAvGxufZ+CWkRE3AAAAP//7N3RCcAwCAXAN1ozQiBrtl2xuEPABu5G0E/1KVQD4Ay+hHG6SlizDAgAAAAAAP9jDgXN5prmaAAAAAAAjd77GUmGHgAAG9VNZYVrXIraLMkHAAD//+zcsQkAIAwEwKwouE9WczQJ2NkKotytkCbwySvVAHhANV86aOQDaQEEAAAAAACATbbe5GgAAAAAABet350q1hjmAAAcUjmwYo3bImICAAD//+zdSQ0AIAwEwFpDGRgCJGCN4IGEIzMW9tW02SrVAHhEr60YzPlAFiIAAAAAAFxliAOuYI8GAAAAAHDYKtbotSWPcQGAzVaxhvuMUyJiAgAA///s3dENgCAMBUBGwxEeMBCba0wcwSgkdyv0q23a56kGwF405eyuprepigAAAAAA8L+MmNnDOmpGpBMBAAAAACzgCcY9hOMCAC+6byvP9GYv/LVSygUAAP//7NxRCQAgDATQVTOZidQIVhM7iEx5r8IY3M+dUQ2Ah+zFS8MafKAKfgAAAAAAkEJ1BkjFTwIAAAAAJLE7PKP1oscDABw29Ssvi4gFAAD//+zc2wkAIQwEwJTmlRCwIDu71kSwBPEBMyUkv7trVAPgMXPt0tIlrxMIBAAAAACAg7Lm7/5wnZI1m7cAAAAAANxj9ng+XR4AYKExrCG3sUtEdAAAAP//7N0LDYAwDAXASgMJBWxus4A0Ug8QtuROx/sY1QBYk5VLVrfleQgEAgAAAADAD/LKejzxegJzMk4PAAAAADCZ0fo9Wt/1eQCAF1XHssY15De+FhEPAAAA///s3NENgDAIBUBWJHEfJ7Ku0NEadtAUzd0K/PBIeEo1AD6owrggzg+cFj4AAAAAANjC0z40lkcqpwcAAAAAaOi+Rt1vq1xjmg8A8ID6r1Ss8baIWAAAAP//7N3RCcAgDATQjNaOIHSfTlRdUYSMUEXhvR3yETjulGoAHCofcU84pxPaBQAAAACAhcpTrgxlAPt681YBAAAAANjMGMptX72N5QIAPxrFGsYXZomIDgAA///s3UENACEMBMBKAwlwgpCGNT5IAHJNZiT01SbNrlANgNwc4GRXLHsAAAAAAPDUNG5IQTg9AAAAAMCP7bLcqjAXADhktK/76bghIhYAAAD//+zdgQnAMAgAQUdLRxCyZpoVi9ANQqApd1MI4iuqAXCwqlsKa/ADNez5tAUAAAAAAJtlT6FrOEfLnnZoAAAAAAAfVnc9c9zXG9cAAFjVhDU2iIgHAAD//+zdwQkAMAgEQdN/0QkBS9DHwUwZoquoBkC4LluqWpLOpy0AAAAAAFjUx/nm8ZDFshQAAAAAQICOaxz3PQDAgB/WuB6ZD6qqBwAA///s3VEJwDAMRdFnrRIKM1RB6yTM2qiH7iPlHAv5CQRuRDUAzjDMkeLWouc7HgAAAAAA/EdQAwrqV3dDAwAAAAAo4rlnS9LENQCADV5hjU2SfAAAAP//7N3RCQAgCEBBVwzap9FaLYQ2yJ/kbgoRfIpqADSQRUthDRpYhjwAAAAAAKg35sj9ux08/EkQBwAAAADgI3njc+Ma7nwAgFfbM/MCEXEAAAD//+zdyxEAEAwFwCjRjII0hBK0ZtTAhdltIbd8XoRqAHxitF4lWfIBS4EAAAAAAHCf/js8LJc81Q8AAAAA4C37zme0noRrAACH9jNzM+MTEbEAAAD//+zdwQkAIAgFUEezEYT2nyWCNqiL8d4Iggc9/C9UA+AvDm26S8lpAAAAAADwTs3af/c0Umgta5Y9BgAAAABo6JToDkW6AMCFFKxxISIWAAAA///s3FENACAIQEGqmcxEagWjOSuoP7K7CGz8wRPVAEhktD6FNUhgl9McBQIAAAAAwBvVHCEFuwwAAAAA8Kn97zNaL+IaAMAFYY1TEbEAAAD//+zdsQ0AIAgAQUZzBRIHcnQbC2utIHcj0JGQR1QDoJlTsLRgU52jQAAAAAAA+JQzlxlCGyNnCtMDAAAAABR2xTU81AUAXghrvIiIDQAA///s3dEJwDAIBUA7Yto5k47YImSAkL/I3RQK76mjGgA1Wa45XQ53gr4AAAAAALBplu8dsYZahKMAAAAAAArIh7pvH5f+DwCwIbuXX3tuTxlWRcQPAAD//+zcQQ0AIAwEwVpsgh+kYY3ggMDvMqOifdyKagAEOuVKjzUBpsMOAAAAAACeCWpAoB4tTA8AAAAAEEJcAwD4sOwvL1XVBgAA///s3bENACAIBMBf0cSBHc3YWUopuVuBiuR5lGoANHUW6yTLfPmcb1sAAAAAAFA05jihCcEJ6ElhDgAAAABAM1e5hjsgAKBCscaLJBsAAP//7NxREYAwEEPBWKuEA2xSLFZCp5/c7NrI5IlqAPSmVMnv1X0JawAAAAAAwBmne2isnrKfAQAAAAA09L1zJBniGgDAAWGNnSQLAAD//+zc0QnAIAxAwYzmCgEH6kLqCh2tuEDR33A3QkAIAZ+oBkBha8xXWIMCmqUOAAAAAADOZM9n39aNC0pr2dM7BwAAAAAoaP8FEtcAAC4Ja/yJiA8AAP//7N0xDQAgDEXB7xwMARZRQAJruZPQpEOXV1ENgOLWmN0RTQG+bQEAAAAAwJ1mTvAFuw4AAAAAUJi4BgDwSFjjJMkGAAD//+zcwQ3AIAwEQZdGC0doKJ3TAELKkzDTgn/WaUU1AO7wujOny9OFNQAAAAAAYCMjfulwj5YRgygAAAAAgJ8T1wAAPhDWWKmqCQAA///s3MEJACAMBMErzf6rEsGX+PDtzVSRBLKiGgAF1gItrMEHhoEOAAAAAADu9nO9Ozp0EdIBAAAAACghrgEAPBLWOCWZAAAA///s3cEJACAMBLCuKLiPLqSu6FfECWwyQvs6KFelGgBJrDG70MwHHAYCAAAAAMBbMxfIp9TSrR0AAAAAII+rXMMDXgDgRbHGKSI2AAAA///s3NEJgDAMQME4YtR97EK2K4pQwQ8XkNwNEQgkT1QDoBbLMr+X2yqsAQAAAAAAL7nnfQjhGAJqOuYMAAAAAACgkBnXaOPsi38hAOCDsMYjIi4AAAD//+zcsQ0AIAwDwYzGZqyOItFQZADkuxFSxc2LagAE6cF8S5Tws+WZAwAAAACAhyA1ZNvpBwAAAAAASCauAQAMhDVaVR0AAAD//+zcMQ3AMAwAwYdWCpYCqNAKrUumMqhyB8Fe7RfVADjMDms89s7POQ4GAAAAAIBq1tzmAMe7Zo1DKAAAAACAw33iGn6HAICENarqBQAA///s3FENwCAMRdFnDQkwQShis0iWgAjCORLapH+9ohoAF/rGW+yd09WnCWsAAAAAAEDSzQBwCwAAAAAA2FZc4/8dKuIaAMD1YY0kEwAA///s3UENgEAMRNFKWwtNVhAIYrGANE6bYIHMexLm1NOvqAZALmEN/m6kH3IAAAAAAGTr2QLUwDZ69mENAAAAAAC2+1rPJ65xGgYAouU+aqiqFwAA///s3cEJgEAMRcFY4oIFbUO6LUpgDx6swD/TRSB5EdUACNWDsdokP2BZGAAAAACASOMcHZ4WnwbeopegAAAAAAD4tuMac133Ia4BALH6yXnmPWZVPQAAAP//7N0xDQAgDEXBWkMCCYKQzsJAQhBA/p2ETl36KqoBEGzXJuFryYscAAAAAADRHM8Dlz76NBUAAAAAAF6OuEbzrBcA4mSGNapqAQAA///s3cEJwCAMBdCsKHQfcSDrCo4mgkfpveS9EXIIIZAfoRoACNbg7/Yg5xMfAAAAAABpnKN5u3Hgppan6A8AAAAAAHwa/Z37We8J2GiqBQBp5AvWiIgFAAD//+zdsQnAMAxFQa2WyeyFEq9oBK5D6vy7FQQGFXoW1QAI10uwsiQ/EFlHAwAAAAAg1jB64IU3AgAAAACAz9b9zBPXuNwYAUCEDmv0hy4ZqmoDAAD//+zd0Q2AMAgFQEarI6Ddp3FzQ+IC+qfcjfD+GuBVqQYA9fjdpMDXdWxHAwAAAACgn5zZaqkBeGXkzCE6AAAAAACeqI9768boLtg4hQcAv7by2HvMlSPiAgAA///s3MENgCAMBdCOxmayEDoCjEZI8G68ad8boU2aXv5XqgHATbEGX1cyPXEAAAAAAOSzQ/KH1QMPuBUAAAAAALx2tbPuco2VNxomCQC/1FNkMiNiAgAA///s3MENgCAQRcEtDUsgoSAsSCmB1gzGAky4bWZKgNMe3jeqAcBrrUk6cklg+kQAAAAAABITyQN/ldpq91oAAAAAAOxYvdG47uMb2Di1RwCQTv4mMyIeAAAA///s3bENgDAMBECvxggGBmIhYMUoUsQEaWLuRnDn4v+VagDw6U+ua7C6PHbFGgAAAAAAlJNn9mWQX6yDANMo4gEAAAAAYJr3fq6RPdpGwQYAUED5TGZENAAAAP//7NyxDYAwDEVBsxkrGBgoC5GswGgIiYoOiQbrbgTX/k9UA4AnYQ3+bs518VQMAAAAAEA1xvHAa7llczUAAAAAAL409n7cgY1JYAMASrg2mXXDGhFxAgAA///s3bEJwCAQhtF/RcF9JJtlNBFskjKQQn1vBIsDi/tOVAOAh/GxTXJ7FRa3fRkNAAAAAIBzzKV4QWngi1ZqMT8AAAAAAPjFK7Bx2UkCgGWNsMaeRxuSdAAAAP//7N2xEYAwCEBRVmME40BMpK6Yxi5lziLxvRHgjvIjqgHA4LnuNBVWt3sZDQAAAACAXynrBia4IQAAAAAAfO6Na6TABgAsq46z7fe0ISI6AAAA///s3dEJACAIQEFHawWhfVutCfoVtLspBPEpqgHAi7AG3a2pAxwAAAAAAP/InWO/gABlVu60NwMAAAAAoIzABgC0dcbdZUbEBQAA///s3LENACAIBEA2dyJ1BB3NxtLSxGDuVviKAK9UA4CjXts0sPKBIUQAAAAAALLaT/BFgMAF9mYAAAAAADyhYAMA0vnrViUiFgAAAP//7NzBCQAhDATAlGYLUQu60sUC/AmSY6aE/QU2a1QDgKN9sEqH6nJ0BUEAAAAAAKoyqAFckzM/aQIAAAAA8JKBDQAoof3qLzMiFgAAAP//7NyxCQAgDATAjOYKggu5uaQXbCyi3K3wTQjJK9UA4ESxBq/LAc6BIAAAAAAAT+mjt9xxSw24SFEPAAAAAABlbAo2pnQAoIz8y/zjbiUiFgAAAP//7N2xDYAwDABBr8YIkbJPWAgYIRmNJjW1Ze6GsNz4LaoBwKfnupfqIwWMSgscAAAAAAC/UOrjB5BD681sAQAAAAAgnR3YOHdg4xDYAIAUZom7zIh4AQAA///s3bsJACAQRMErzRYOLMjSxVwwEj/MlKDxvRXVAGBpVB+9Eh+wvAUAAAAAwBOyZvNTwCYla4rRAwAAAABwrTEQPAlsGAwGgDPev8uMiA4AAP//7NyxCQAhDEDRjOaNoDfRTeZqIlhYXqMQeA+ygEWq+EU1APhLWIPsSn2bI2QAAAAAADIQigZOsmMAAAAAAEhhC2w8K7LxrQEA7pj/Mnvqt46IAQAA///s3dEJgDAMQMGMpiNEu4+OLoUM4I/QyN0WIe2LqAYAr8whVNWRH7jyPFzeAgAAAABgWTmy/UMEYHlbjrQzAwAAAACgnQps3BXY2Cuw4b8TAHxrhjX67pgj4gEAAP//7N0xCsAgDADACP2g+iD784rg1LkUA3dTRkm2SJLrgDcAkMTa6lh7e9SL5IaGCQAAAAAAJ9pD7gbdgT+sBT5FpgEAAAAAyOp9QLj2du9wKCoAfC7vH3NETAAAAP//7NzBCYAwDAXQ6GQ6Qq0D6UDqilLowQFEWnkP/j2QWxIyNlADAH2Z9YvOTY9BCQAAAAAAtMSBH/CZtCY7MwAAAAAAfuM6zq1mKImIvQYAeEHKS3ms0Z+IuAEAAP//7N3BCcAgEEXBbXFj+gnpXAQPkpsEgoaZMhb2fVENAKY8K46wqSvLYekPAAAAAIBl5Jntbu12DXxJyAcAAAAAgN8aIxt9ZPj2EwUAr+w5eB4RFQAA///s3cEJACEMBMC0lhKEa1NtUYRrQO5zkZkS8shr2VWqAcCx2Ue6GhcQEgQAAAAA4E/KrnkAdbWn+T0AAAAAAFxvjwy/BRupZAMAPqk3eB4RCwAA///s3dEJACAIQEFHawWhhdq8DQrqI4y7EfwUeYpqAHBKWIPqylbRAAAAAAD4S/a0rwZeadmz3METAAAAAADcWEQ2hsECwFath+cRMQEAAP//7N0xCgAgCEBRu/+lQ2hoaHLT3gOvEAjyE9UAoCSXRzVGBmhZRQMAAAAAYJx2xwbAKN4gAAAAAAC+dkU2ctYJbYhsAMBbrw/PI2IDAAD//+zdsQkAIAxFwYzmCoHs62piZ2VhI8rdCL8OL6IaABybNUbr8QFHggAAAAAAXJOV3frAZS0rhegBAAAAAGCxiWx4UgwALz08j4gBAAD//+zdQQpAIQgFQIN//zOHUZtoHcafOUHgQsiefQXOAMDbcrGGx568bGxFy4sOVQQAAAAA4KYZYhdkByrImW9TCQAAAAAAONtzJzNIvGZ9PnwF4I+y/9VfNhURHQAA///s3cENgDAIBVB0wyYu5EDqCo5mMB3AI63vJdzhDp+1QA8ADOw6zlvCIhMYKhUNAAAAAIBpWK4DymhbE0IPAAAAAAAf5U1VBm30WrL68+LdrRUAP/E+PC8/akQ8AAAA///s3bENgDAMBMAU7IUYIcA+LARkBBgtQqKgoKKK0d0E7l//7hq4AYDgyrYPeRoPn9QILswqGgAAAAAA8d3lddkK0JIlz/ksa5GZAQAAAADAB2/Pix9l414+CMAPXb3Mtoc1UkoVAAD//+zdsQ0AIAgAQTY3bm6wtiQGzd0GSmXhI6oBQJXpYcfjdhUtC6EGCQAAAADABcMlAw0J0QMAAAAAQKHTPxWhDQB+kkv7c3l/2yNFxAIAAP//7N3RCYAwDAXA6GR2hKj7iAOpK0qhKwit3EH+A/1ryMvcQQ8A/EBLUjy9JYM7clt9RgAAAAAA8KncU8Az0Ksl9zQvAwAAAACAD9WgjVblue6pVkSUtptlPwuA0dSD5/3OmSPiBQAA///s3cENgCAMBdB/cEFhIEdzNUMCbqCp5r1Tj4QbJf3dCpwBgJ8Yj7m9NwmJfJ3tWwAAAAAAPGYOqx9uGCjMfxkAAAAAALxsLjxe/fk7pH/vbdVmtgCo7EwyQqLqSXIBAAD//+zdwQnAMAgFUNvJkhECXagDJV2xBHLoADlYeA/cwJPi99Q6AGwmDZG/K5+BAwAAAAAA7CZQA8iutKvZlwEAAAAAQALzCfKq+vRxzIqIum64bkHZAGSR9i4zIl4AAAD//+zdwQmAMAwF0B7cS1dI6z7FzRxNhB4KXkVaeW+C3JOfvwwwAwA/cn9FjJIPB6FMrkbJZ/vyCQAAAAAAr4g9Nu1RwCRq34IHAAAAAACMo+VdHpmXKLnfR652kwB8bMxcZkrpAgAA///s3MEJgDAMQNGsGO0+OlChK0rx4sVbBQPvbZGEfFENAJab9cPcN4MX1R1qnQAAAAAALCZKDpSRLc/Rh7AGAAAAAAAU8RbbiDu48dz5u1sC8JX//WVGxAUAAP//7NzBCYAwDEDRjtYVqu4j7iN0BUeTgHjotQgG3jv13ltCvqgGAF85RDVIrsbAICIxPhIAAAAAgFlxnG53AiSzt61d/exC9AAAAAAAkNxwH/O+27rUYY8puAHAjLjLrE/o6R9KKTcAAAD//+zdwQmAMAwF0GzmDG0Hkm7maCJ48CIIVkzhvRFyacKniaUaAHziePBKq90gxeTW0uqWrYEDAOC1roQAAMAPZCbAjFJeEQIAAAAAAMY4/8xcs4C7hRuLIwIAPJQrZ46IHQAA///s3NEJwCAMBUBHc4WoYxZcsfhTpPRXqO3dEiG85CnVAGCZ0WAYtViY2J1DQQCAj7m1rQMAACwXLewhwK5ytMj96PIyAAAAAAD4mYfCjUvUMmeg/scAmOUxJ15zt59SOgEAAP//7NxBCgAgCARAv97PQ+hSh26B0swjRJFdpRoAvDYcRTRXboEDAAAAAKCPDKOvAmeArpTQAwAAAAAAm1vO5ijc8CsF+FPO/xqZzIiYAAAA///s3MEJgDAMQNHoZDpC1X2km4tQoXgSL9ryHuReyLX54w/eAEDHSpEw2zGN29O6iMMAAAAAAPCGT2JA66a0JQF6AAAAAADgkTO4Uc1wTUTM5c4suzcD6N8tsvSdiDgAAAD//+zd0QmAIBQF0Be0V61gtW+OFoJFn/1EKedMICqCXOWO9hsAbyuXoLQuU3lsZbJp2B4RgwUEAAAAAOCptKVZPgJ04lctQgAAAAAAQHtqeXO+DfzKHmoZ7pmt+ocG0IdSdp7r+f+diDgAAAD//+zdsQmAMBBA0azmCJe4kPuoGSGriY1YWFiIEnlvhEt1HPyIagDwlskyQ++i5FaXdfCQAAAAAADc1AwK+IsYo9W5upUBAAAAAACPuwhuHKLkc/hbcAOgL/sHDt9GNVJKGwAAAP//7NzBDYAgDAVQRmOFKgPpPiorGhKvXBHNeyv00DQ//Uo1ABiiHTaxLvuzAOGrcmu+nKEZDQAAAACAuUWJzYiAn8lRItejysoAAAAAAIBh6nl1s1eFGwDTe/8nM6V0AwAA///s3bENgDAMBMBnRML+uyC3KZIOA7pbwZX18lupBgCPqQXmvIblhK+rr4KHKQIAAAAAsKFoHPijV3wRAgAAAAAAyKJwow64pxs2+S1An96cOckNAAD//+zcwQmAMAxA0Y5WR4i6kPtYO4KOJoJ4EM9F5b0REsgtX1QDgNYmUQ2+LoZ+rWXpLBIAAAAAgCcxxmowwE/lGCPXuQprAAAAAAAAr1XLst0euK/4huAGQHP5uL3nbW4vpbQDAAD//+zcsQ3AIAwEQDNZZoAslGweuaOjiQJEd6VbCrDQv1INAD6Vl149223ZYHPTH3EAAAAAAKwpw+YKxoGfy+Kg4pABAAAAAIAdDQo3rm5++PsFeE1miufkMSPiAQAA///s3cEJgGAIBlBXtBrIgSpXjO51Cop+3ttAPAn6KVQDgNf1tlfOk6GCv7MsCAAAAADAFcHiwPByyeq1S6cBAAAAAICRnHdvd+UI3AB45LtH5xFxAAAA///s3dEJgDAMBcCMVkeoDiQOVB3B1aT4I6K/FfVuhUAghLwI1QDgKZPBgbfLQ78uZe4UEgAAAACA2I/Mk/0H8BPj8WsbAAAAAADA190FbtQj8dOe2CMGgGu1P7YP1YiIDQAA///s3MEJgEAMRcG0GLUh+xG2hG1NBBGtICs700JOOfwnqgFAiasmleuyexL4udI6GgAAAAAAw+lOAswit+ztaAL0AAAAAADA1O5d0Xtb9MQ3BDcAPmr2mBFxAgAA///s3cENgCAMQNE6maxQZUwTVjTcuXiRKO+t0GPhV1QDgGl6nS/PY3exjY/rD6Q3QwQAAAAAWFvWHF4lAvixkjVLu5oAPQAAAAAAwMCD4IY/dsAqelzo3R1zRNwAAAD//+zdwQ2AIAwF0I7mCsBEDqSO4GqGxBgPnCXIe0M0PbT/C9UAoLfVws/oUsnnse1auAAAAAAAJlWfyjUKAZPqcvAEAAAAAAAwukbgxiOV/C51ELgB/MlSQ4XuGfiNiLgAAAD//+zdwQmAMAwF0IzmCupCuo82K0qvgjdpLb43QK4N/PCrVAOArurDN6/L7tCUwXVZ5AAAAAAA+Aw5B/BXUy0WyiPlZAAAAAAAAC/Js2xPk26FG7JqYERtP2+IiAsAAP//7N2xDcAgDATAz4gkA7MacpOCAUgQdxW9G6SX30o1APhcffLbc2vMY3c9yWWKAAAAAABnqWVyGQdwODkZAAAAAADAIlPhxvuug8FTdq1wA/irtUfOkwwAAAD//+zdsQ2AMAwEwKzGCAEGgn0Aj8BqCCkFTUpQUO5WcPv/NqoBQCtWgVP+Lk/jGfsxOCQAAAAAQFcEkYDu5TkvsUX1YxoAAAAAAADvKuX0Z0G9NrjhOTbQgjtv882oRkrpAgAA///s3LENwCAMBECvCAwUZXMERUSR2oB0N4Ul/79RDQCOMI720uoreMrl0hfSAAAAAADYZ5TIhY0ApmcNZgIAAAAAAHCOn8GNT2l1/fHo9gFZ8rqYEdEBAAD//+zcwQmAMAwF0DiaI1QdyIHUjtDVpFDEBRSL751yDMk1+UI1APiMvB9rmidJd/SuRMRgiwAAAAAAv+CgCKBJSyp5y6N5AAAAAAAA9KP+9N2avWphG8AL6i/x86EaEXECAAD//+zdQQ2AMBBFwUqrhYUKAj9AJWCNcOyNhJQAmbGw15+3ohoAvM0sqsHXxTjsdd0MBgEAAAAAfixKTO4L0MhRItelPjJ6AgAAAAAAoJ8LsQ3PtYG7zmBP//1NSukAAAD//+zdsQmAMBAF0NPJzAjqnElWcDQJpLCwsRA0vAc3wUEgxf83WxUAX1JzOXqxBvzZsu6bTyEAAAAAwKBaaNwlHoBb3kYAAAAAAICBtbKNPqnmMrWJiNQzgXKBwCOXop73RMQJAAD//+zd2wmAMAwF0AgO5gpVB3IgoSPoaKLUP/30yTkTFAKlcJukVhYA3mZ9VKeuNamOr5siolJFAAAAAIBf0jQOcKxJfRrymG/5+AQAAAAAAMDzyqLtuRxky4nKwuK9P1DGDpxZ74dr8+WIWAAAAP//7N27DYAwDEBBw2TTeAg8AAAgAElEQVSsYGAhJmO1yFIKKrpIfO4kL5C08cvs+AF4KFU6Xi+39XSLAAAAAADfknsuwuAAtzyKBAAAAAAA+LkKbdTn232mmr4zeFwCHAC1hzk2qhERjZ07tgEQCAEoymbKCCS3/yw2V1iYWJF453sbEFr4ohoAfNKs06XtsLhzVhUBAAAAANiHZ3GAFzWq/egJAAAAAACAtdwiG/kQ2gD+62idPCIuAAAA///s3bsJACAMQMGsKLiPo7majYWVVoKfuxUC6fIiqgHAsXpYQ3WO21UTBAAAAAB4Qz8SF1MGWCspJ/sSAAAAAACAqSG0IbIB/9r73DwiGgAAAP//7NzLCQAgDETBtKgWZOtiB/Eg+JlpYSGXwBPVAOBoszpnIW5XWhXWAAAAAAB4Q7cjQJqbCQAAAAAAwBKRDfjWvv9yRAwAAAD//+zcUQkAIBAFwYtmhQf2z2IGhfs4nKmxsKYaAExgrMF07ac0AAAAAAB6ZcdAGeDOyo5GBgAAAAAAwDOTDfhGX1uuqgMAAP//7N2xDYAwDATAXxFYCAYijEBGo0lBSxGJwN0GljtL/1aqAcDrHXupSapNMbhTsQYAAAAAwJhaKNyNF+C5rt+EAAAAAAAA+Jd7yUZ75r3JHsI3TMu8dhkkyQUAAP//7N3RCYAwDAXAjGZHKHQhB7KuKIVMIPQjegeZIH/h8aJUA4AS7ms2m+IDhAYBAAAAAGpy3wV45+ijbws+AQAAAAAA8F/rmXcWbLQs2ThzgJr25HMi4gEAAP//7NzBCQAhDEXBlOaWkHULsnRZsALRQ2CmhBzD54lqAFCJsAbVtZu1NAAAAAAAzssv2//fdVqAbcJEAAAAAAAAXLcCG2MFNh6BDagn+3t+oxMREwAA///s3bENwCAMBMBfESn7MFoYLaKnAyKQ7kawGzf/VqoBwDV6c1ySZmNcru467AAAAAAA2OI1VoA55SmK5wEAAAAAAPhNzyIOCjZkE+F86582JPkAAAD//+zdwQ2AMAhAUVZjBBL36UTaFb14cADSWPPeChwJH1ENALYyzytNjB/wjQsAAAAAYAOOwAHajDpKeB4AAAAAAIDlXoGNfCIbAhvwXf175Yi4AQAA///s3NEJACAIQEFHa4VqojbvpzYQMrhbQfBLn6gGAD8S1uB3rc/hEBsAAAAAoD6RZIA8dioAAAAAAADP3cDG+VNcJgK1pP9eRsQGAAD//+zd0Q2AIAxAwTqZrlBlH0djNULiCHxUcjdBEz6bPkQ1APidWYZTgmMDbz6337gAAAAAAIrKlt3bACx1ZUv7MQAAAAAAAEqYd4pfYOMQ2IBSzqXTRMQAAAD//+zdsQ0AIAwDsJ7Ga3zO0okZiUay32iTKNUAIFI3wUE6a1wAAAAAAAN16FvwmySeu0jhPgYAAAAAAMA4V8HGNgoOX62ng+ZVdQAAAP//7NzRCcAgDEDBjFZHEBxI9ym4YhH64QClGLhbIX4Egk9UA4DMhDXIbi133RQBAAAAAI7j0zeZjHlP9wayuGqr3isAAAAAAADHeuMaZQtsAP/7LqoREQ8AAAD//+zc0QmAMAxF0YzmCoXu42qOJoUKfksqpJyzxkuuqAYAZY36m+IbGzizq2kAAAAAAHzXejuyh3lY6HoFNRxzUYVwEQAAAAAAACXMwMYT1/DLCP/J25Uj4gYAAP//7N3RCcAgDEDBrOYIAfftaiVQigMUMeVuhUC+9EVUA4DWqvhmgvyAh4MAAAAAAOe4zIJG3pDGEteA4+VMuxYAAAAAAIA2nrhG/WUc4hqwx2fHzCPiBgAA///s3dENQEAQBNDTmRYWZTrbgtLEn/g+5OS9MnYms0Y1APgDwxr0box5UnQFAAAAAPhYLOFWS0/2XPNe1pKb0YsxlmhWgAIAAAAAAIA3ZN32c1wj6zZcnyAAj2iTKZdSDgAAAP//7NzBCcAgDEDRbB4XaruiFLx5EtJDynsjeJBA9ItqANDeO4iqu/EDWVlOAwAAAADgzPrcnY6NRrYHWiuyYW9GF+5cAAAAAAAA2nque4hrwKdqdsoRMQEAAP//7NzBCcAwCEBRR+sKTRfKaB2tFDzmVkpQ3hvAizeRL6oBQAtv3c0macDjIAAAAADAPm60VHJnQGPFwxZVHBk0AgAAAAAAgLLENeA/5zXm5+kR8QAAAP//7NyxCQAgDADBbKabu5pNWkFQQeVugDRpLMyLagDwE2ENXld3PfIAAAAAAJiXR90Ou3nJ8DNWxjZGwQ24TbMRAAAAAAAAfiCuAUeU5akR0QEAAP//7NyxDYAwDEVBr2hgn4iBQlZMQ00DQop1N4Lr7yeqAUAZo18GglTQct8MtwEAAAAA/tXcm4WcdzjjiZEWy8gjRecBAAAAAAAoQ1wDPvX+1zIiJgAAAP//7N3BDYAgDEDRruYI6ppoV/TC3QOEhOa9FXqk/YhqAFBKPu9hohRgeRsAAAAAYJF+zC12zDay5W+AoEc3xOjZhbcxAAAAAAAAyhHXgDnO+xr7qCEiPgAAAP//7NyxDQAgCARANtMVSNzX1VxBow3mbgAaGornlWoA8CPFGlTXXxx6AAAAAABs8cxNJSdhK8EsysiR07YAAAAAAAD4kXINuNauJkTEAgAA///s3VENgDAMBcBJw0JhfjA0qAWkERIEQAgfW+409K/te0I1ABhObrvmLUawxjJrRgQAAAAA+FHUEHBMV7Ll45nNloejLDoyRQ27MQAAAAAAAIZ1hWvcheJ+H+Gdb7vkUsoJAAD//+zd0QnAMAgFQFfrCE3nbLNiKGQBC4FU7lYQ/BB9CtUAoKR+P4fKUoDviAAAAAAAi8zjbXNY/iQdkJEJ4YAN6MkAAAAAAACU9j4Un7ePwjUg4bza9/2HiBgAAAD//+zcsQkAIAxFwYyW/aeysbCxkCASuZsiEP4T1QDgZ8IadJfVYw8AAAAAgC3jbVopBDKOYxzwSM7gEQAAAAAAAHxtiWv458JtETEAAAD//+zdwQ2AIAwF0K6IDiQLiSO4miHh7AFNDPjeCD010P4K1QBgWrWxlNbGBLa0LoYHAQAAAABe1Ja2vb0yku4w+QdhHPCFU9UBAAAAAAD4i2Mvuf0H24OEe/3HcyLiAgAA///s3csJwCAQBcBtUUiZgi2ktCB49qC5rM7U8T5GNQA42lhrg+y8JQIAAAAA/Etpm0zeVttugMq7EWmUpxiCAQAAAAAA4Br9XHz0IHUhYWL5vDwiPgAAAP//7N2xDcAgDABBZzNWCKyJxIooEmUqksbibgVTUOBHVAOAE7hMkl25W/V4EAAAAADgB5a1SehzEGP04dyTieA8AAAAAAAAx1lxjev5eMH04dVeVCMiJgAAAP//7NyxDYAwDARAr8YIkdiHhQCPEEZDNFRUhCbhbgU3lt5+pRoADO9aJi2SDGBpaVIDAAAAAODmWZueHLnmVzmXInq6UeZSTQsAAAAAAIA/ym2f5Lvw6N3NT0ScAAAA///s3bENACAIBEBG0xFIXMjNbdhAG+LdBJQkwCNUA4AvVCMJ3Vn0BgAAAAC44EibhvarkiucQxA9XYxcKXAeAAAAAACAL9Wj8WnGCw9ExAEAAP//7N3RCcAgDEDBjNYV1IU6mqOJkAVaRBDvRvA35kVUA4CbCGtwuqe06sM3AAAAAMAPuZxtQZuT9AxhrLQs0gEbCM4DAAAAAABwrRnWyGPj5ryQSqvv57eIiAEAAP//7N2xDYAwDABBbwYrRGIgBgK8IkKK6INoDHcjpEphv0U1APiNXmfzgaS6K6xh6BsAAAAAYJzlbErJLV8PxvdIh0tGVDG3pT0aiAIAAAAAAICvyP1YHRyH2zT8FBFxAgAA///s3bEJACAMAMGs5giC+7qaCBlABIvg3QppLJJXVAOAr+QD0qIg1U0TBAAAAAA410ffsWLBYip5GYoXoacSQSQAAAAAAAC+lx+ON7eRcLH/ExELAAD//+zcsQ2AMAwAwazohIEYCPAKjIbYAIoUVu4mcOPGsl5UA4AVeRSkvBhdWAMAAAAA4Ds3VUrJI/dZ8+aRt0crKoktpu0DAAAAAAAAVPGGNfK8hDVYXoz+L6zRWnsAAAD//+zcwQnAMAwEQZUWlyBIP2ndD7sB+xEQmqlCsOiMagDQzl5lM6xBdc/N8QcAAAAA0I1nbAr6o2NpZVTy5Zu6GAAAAAAAAKz/yKH50txZP46ICQAA///s3bERgDAMA0CvlslgoIBWpEmfo6AI+R9BhRufZaUaAGwp131qZOMHfFYEAAAAAJg7ZMRK0vN5EUx6lNCzGrMcAAAAAAAAhnEf2eTBpt7tj6vqAQAA///s3YEJgDAMRcGM5gpfu6a6gqM5gaAgherdGEl4EdUA4M8cCjK8LLOwBgAAAADAhbSYoTKabvurHvEOeNGUlsffhgAAAAAAAOCr9nU7hDXghqo6AQAA///s3bsNwCAMBUCPlhWAhRmNhgJRJVVkuFvBDfLnIVQDgGvNR6NgDbJ7SqsWCAEAAAAANvP4Wv+UTPoPQRdmZWTy+bchAAAAAAAAONkSrNEVmpuUVt/vV0TEAAAA///s3cEJwCAMQNGM5gqCA7mQumLxJpSeCpW2782QQy75EdUA4NdG69XCyAf4tAgAAAAAcOb4mrd5PHCxIeIBd6RcspkFAAAAAACAxQxrjNaFNeBKRBwAAAD//+zdsRGAQAgEQEqzBd82naEFSzMh/OCzH3S3BNKDQ6kGAPjAxQec11CsAQAAAABQ6uj6MA8aefLOXQtOsjI6UZgEAAAAAAAAE4o1+Jn17DgiXgAAAP//7NzBDYAgDEDRjuYK6kIOZNIVDYET8U6A92bore0X1QBge6XE5liQBRznfTkQBwAAAACoPF0zm2G7qnzzMS3MpIWTAAAAAAAAgI6wBvyIiA8AAP//7NyxDYBACAVQVnME1H28gUxuBB3NwtbCzpy8NwI0JMAXqgEA97DYDIv8wKGJAAAAAEB1nq0Z0Nn3/vWeahqyclS15ZrC5gEAAAAAAOCBYA2qyGV+dyMUERcAAAD//+zdsQ0AIAgEQFZUB3J1GxNt7EyI8W4GQgM8QjUAYEn7AAa3lFYFawAAAAAA35pH1l0F8Jj0GdUM9bBUxUv0egAAAAAAADgQrAGbiBgAAAD//+zdsQGAIAwAwYzGCuJEDiSswGg0KS0sRe7WSPIR1QCA1O82hDX4gXKc1WcuAAAAAGBXjqxZzZVBiy8wJ2MlJUNKAAAAAAAAwANhDTbwbk8oIiYAAAD//+zcsQ3AIAwEwB+dgUg8AquloUiVOsDdBJbcWLL+lWoAwEtdd3MosoFhiQAAAADAaWa4WsCapVSv9pd5Z7mHPxkrUaQEAAAAAAAAHxRrQJIkDwAAAP//7N1BFcAwCERBpNUCJP61REAOvUI7Y+M/FqMaAHDzhYvxcpVhDQAAAADgbxxXM03HJqWTMcmTO9sM0wAAAAAAAEBTOjCflavem3FEHAAAAP//7N2xDYAwDARAjxZGIKwZ8AoZjSYVBTUhdyO4siz9W6kGADzkeXWLIj9Q9qP6yAgAAAAALGGEqt1EmUq2/FwZQLbsvhQxGYVKAAAAAAAA8GLkJTczYlkRcQMAAP//7NxRDcAgDEDBOpuGJgiaoQ0JWMMA2X5Xdueg4bPliWoAwEK/7tPBIBsYHhEAAAAA+Amfqqnmy4F38XlKyZZ2YgAAAAAAAPBAWIONHa+zRcQEAAD//+zcsQ2AMAwEwIyWFQwZiIEieQVGo6GNaHF0t8K7+5c91QCANYNByovzMCIEAAAAALYWIy4JU03O/O3d5sxbT0YxPUZ0oQEAAAAAAMDa+1hDF8xuvrvi1toDAAD//+zdyw2AIAwA0I7GCspATiSu4GiGxCvhCs17I5RDm/SDoxoAMKBIJIly1NMQIQAAAACQ0r9EfXldNrP87z8rH/2AAbkAAAAAAAAAJp679V7wK05kMt2fjIgPAAD//+zcsQ3AMAgEQEZL9k3CCM5oblzTg+5WoEF6/RvVAICCJ5EhlkMCAAAAAEMpUdPNn092yZ6Mz9PJdYaWAAAAAAAAgEK+360zyTB1VhwRGwAA///s3LERwCAMA0CvSFiIgbhjRRr6hA6H/wncy5JRDQB452GQ9Ep9DGsAAAAAAL+yytMK1GSTJncafbQDzoAd8jAAAAAAAAD4RmeSe0TEBAAA///s3bsRgCAMAFA2U0dA3ceFVFZgNBtqrSySe2+DkCZ3+eCoBgB8aNfdFYkkMNdtNVwOAAAAAGRieZpoejtbtN9+9MgIpe7VMRgAAAD+NnlhAAAgurEzuUgkSRyvcZRSHgAAAP//7N2xCcAwDARA7T+LHa0YDK7cxJBK4m4Hdf8voxoAcCHns8JX1UKOcBIwBwAAAABaUJqmqHIDFTnSrVHNZ1gKAAAAfvLgDAAAaGEPa+hM0l9EvAAAAP//7N3RDYAwCEBBVnMEWsdUWcHRnMCkvzR3awAPUQ0AWOcTF+3lHMIaAAAAAMAOHE3TzVtXdV1G8p2IVvJM8zAAAAAAAABYUPdzCGuwg5zjP4IZER8AAAD//+zcsQkAIAwAwYzmCoJjCq5oYytaGrmbIpDkRTUA4NIqrwlrkF05DYgAAAAAAC/zLE1Go4+0YYoVA3FERSaltmofBgAAAAAAAHf8TPKD/Y44IiYAAAD//+zdsQ0AIAgEQDbXhdQRXM3G3lhC7lagI8+jVAMAPqwxu9AgBWzFGgAAAABARvdI2n6TbCoEkISoyKaZGAAAAAAAALx5Rk55EXEAAAD//+zdsQkAIAwEwIzmaA4kZAVHs7EVsYzcrZAmhOejVAMA3lkQ+YEgIQAAAABQkdsm5eTIXn1qOXIqnqeYtouYAAAAAAAAgAvPyPnAOVMUEQsAAP//7NwxAQAgDAOwScMCIBhrPAiAcyOxsLNrjWoAwCPLaxTR+hzpn3gBAAAAgH+ccrSCNNlUypTkY2SzXAwAAAAAAACuyYSpKSI2AAAA///s3VENwDAIQEEsstXPDDXBQqVNQZNlfzR3NoCHqAYA/KC8xiGevC8L6AAAAABAF46jaadmHRO4rlnLfIxucqTIPAAAAAAAAHzgGTndbW8lI+IFAAD//+zdMQ4AIAgDQH7u110cnYwDNHdfYCFpKEo1AOCdBZEEyxQBAAAAgO4cRTNUYpYkH2MaWRgAAACQTAkuAABfnWfkMNW9VKOqNgAAAP//7NzRDYAwCAXAjlZHQDtmE0ZQN3MHExNL7kbgfQEBTzUA4CWf1yiix7FrdgAAAACA34oR3VE0C7pyZrn5e860H2M5MeKUGgAAAFDULVgAAD6wKSqltNYeAAAA///s3bERwDAIBEFKcwuyC1LrSgilyIEGZrcOuBfVAIAfsrym8Et1c3zvscIGAAAAAHCZoAYVtQ1PdIyF0N6TgSYAIBlgAQAAAABOcozczyQV7W+MImIBAAD//+zcSRHAIBAEwPWvJbAWkMYnAlLFJ0x125jDqQYAHOoxPa+RQCkdAAAAAPiddwRtCM1tVj+dXjCKPQ0hliwMAAAAAAAAvpMJk6OqNgAAAP//7N3BEcAgCARASrMFZyzThBYzduAjj2B2a+AH3AnVAIB3CNaguqaFBAAAAAD4IE/QVHT8cVHOtFOgmtZHN7cAAAAAAACwIa97FUmcXibBX0TEAwAA///s3bsNgDAMBUCvGBiIhQCvwGg0KVMiEcPdFJZ/z1MNAHiAIpGP2Nq6SHwEAAAAAKbQj5/1LKnmyj3/MjOSTEQ1HjUBb7FPAgAAAABAOXmcgsgpZxg8HhE3AAAA///s3bENACAIBED2n8XEGdzMxtLSGNC7EagI+TxKNQDgEEsijxAmBAAAAACycK+kom+KJnrr2yAKZLYKmwBuGyYOAAAAAEBRni1QX0RMAAAA///s3dEJgDAMBcCM1hUK3ae4j5oVO0HxR4Tg3Qr5zMuLUg0AeJdiDapruzY2AAAAAICvOHqmqCPP/Nsnersxqpl99GZqAAAAAAAA8CyvW36D+iJiAQAA///s3LENgDAMBECvCAwUsQ/gFRFSOhoKJGRyN4IbF/+2pxoA8KLcj6soOVpZkv9p0zIrEwIAAAAAn+jHzs30qSa3HK5M1J+IyMaoxo4BAAAAAACA51azopB7HhwRJwAAAP//7N2xDQAgDAOwnsbDhRdZ2FmQENQ+I4oSoxoAcNjI7pGLHygTAgAAAAC3yCd5UeUSkQIVr2lrwAkAAAAAAADYGNnLHUzwmYiYAAAA///s3bENwDAIBEBGywq217TECh4tTRZwkSjIdxPQ8hKPUg0AeIdiDaq72ugWHgAAAADgU8+Rs0NnysmZx2bqOXNFxPrBKLBDgRMAAADb2uiySwAA4FSeLVBXRNwAAAD//+zcsQ3AIAwEQI/GCkjsw0TAihmAioJITu5GcPv/9lQDAC5YYyoP8gVdAAQAAAAAvMzImYyUh9yAfEpt1YN5AAAATulUAgAAv7TGlK2RxraJjIgHAAD//+zdsRGAMAwDQK/GvgGtSJOGLk24M/yP4NayrFQDADbJeR1mywcIsAMAAAAAr5jHzULptJOR34eHMqJwno7swQAAAAAAAGCdZwt08cwfVdUNAAD//+zdsQ0AIQwDwIzGCg/770LzEiUVSBZ3a8R2jGoAwFmGNUjXvtGfDwMDAAAAAFcoN5PILWgRoCLOP+gEAAAAAAAA7Hm0QKaqmgAAAP//7N2xEYAwDANAr2jIPlkI8AgwGk16qhTh/kdQq7NsVAMAJqrz8pWLP+i5b75DAgAAAADTZMtbuizoqaP0QMPIwrAGq+nZUg8GAAAAAAAAH9xKsqyIeAEAAP//7N2xEYAwCAVQNstqDmTCijY2prKJJ/reBNzR8Q9wVAMAFss+fCjjC3yIBAAAAACWOJeZLTRTkQMSk9xze1VBcI8cDIA/aroOAFBf9mEeBwDA0+TkVHDNgCPiAAAA///s3bsNgDAMBUCPlhWANSFegdFoUtJQEMnK3RKW/HkWqgEAcwjWoLq2HbvGOwAAAADwB8fMVHTnmT7wvLNERTVtBDwBwErUPgAAAADgs7y6OTn1RMQDAAD//+zcuwnAMAwFQK0Ye6AsZPAIXs2N2kAKYxDcraBG6POEagDABdksahip7n16c1QBAAAAAByTT8zmjlQkOOLDHFNINxUtVQMAAAAAAIBf7MupJSI2AAAA///s3bENwDAIBEBWywiWMmZsVshort2kSiJh3Y1AQYHgEaoBAD/JPg61ZgM+RgIAAAAAb3LETEV3XilM/ZklKsppZxMIA3wi+9BfAAAAAADYhrk3FSzPxSNiAgAA///s3cEJwCAMQNGM5grVNYWs6NGjQqE08N4OOUjIV1QDAL4lrEF17RndwwcAAAAAeM3xMlXlTPueg5xpvqlIXB4AAAAAAADu+IiCv9tRjYhYAAAA///s3LEJwDAMBECtaMg+JgM5HsEezX2amBQBhbsVvhE8eqMaAPCh3q7pYOQH6n2pDQAAAADgBc/LZHRKbZvxEdIpRxlSAwAAAAAAgEe6c/KIiAUAAP//7N3BCYBADEXBlGYLCxZkQau/RY+eBPEgRGZayDV5EdUAgI9lPywQ8gcWCgEAAACA1xwt01VmNsN7JjNi83S0jHWIywMAAHBHKBgAAOB6Pg49VNUJAAD//+zdsQ0AIAgEQDZzBnX/XWyMraFSkrsJCC08OKoBAG84rEF5fQ5L7wAAAABA2g4rCyxTkU87eXpGRQJSAAAAAAAAcGcezM/aKS4iFgAAAP//7NyxDcAgDEVBj8YKCQtlICSvSIOUioIqsXS3AuU3T1QDAD6wSmxqbFTXrn47fAcAAAAATvmsTEk58vFyZ3KkTYyK2gpAAQAAAAAAAHu2YP7s3XwjYgIAAP//7N25DQAgDASwrMbAwAisRkONEA2P7BEuZXSJoxoAcEjNJcmeDzRDBAAAAABWjZKyojIv8mFnn+x4kR0YAAAAAAAATIzH43C/iOgAAAD//+zd0QnAIAwFQFeMdqAOJGQFR+sKpT81crdCkIQQnkI1AOBfgjUoL0Z3VAgAAAAAvGWfSEUrZ94q903OXH4ooqK4wrsH4Ggxul4HAFCbMFsAAHZgLmV/rbUHAAD//+zdsREAIAgEMEZzBXUgV7exprFQ7pIRoP0HRzUA4KFzjU2IkOpan8NnSQAAAAAgpZxMYUJA98yQipatAQAAAAAAQEo3kv9FxAYAAP//7N3BDYAgEARAStMSTilTpQVL8yFfXpooZKYE7kMCtytUAwA+VvZjNgMGoF0SAAAAAGiKHJPlZDp1lq34BPRQPUPBGnQncngDA97iPgEAAAAAwHBq6Tj8UqzLXQCUUroAAAD//+zcwQnAIAxA0YzWFdSFOpDgDG7mxWtPlaLlvQUCuSZ8UQ0A2IOwBsdLJXsqBAAAAACeCGpwKiGIRVpt9yeDYK1rhqEA3uo2CAAAAADAT7mrs7eIGAAAAP//7NyxEQAQEEXBK00LaNOMFpQmkcgFbma3DP49UQ0A+MApsqmykV2pvRkVAgAAAACXc4zs7ZCM1hzT/81bxlRkJAwFAABA2EcCAABAUhGxAQAA///s3LsNgDAMBUCPBpsxEIlHYLU0qRAlRT53G1ivsiw/pRoAMIgs9ZQFC3iECAAAAAC8eEZmVgogfpZ3XksNxC6OXhAFAADA3uyGAAAAH7JUd2DGFhENAAD//+zcwQmAMAxA0WzmDLEOZPcRukJHE3r3KDTw3gSBHBO+qAYA7EVYg/KyncIaAAAAAMCSV96ezSmqj2dMy/uFWAkVuX8BAAAAAADAN/d1dnSsoSLiBQAA///s3UsNgEAMBcA6AwuAIAwBtQDOCFkkQLK7mZHweumhH0c1AKAiuR+nBpIOjNMyG5IHAAAAAB6rFGhRbumTzk9kS6veQ1EA0JNBNQEAAACAj1yCpEJlxzEibgAAAP//7EHFnfAAACAASURBVN3RDcAgCAVAVnMEk+5jHEi7Yqdogni3AfEDPuApVAMAknnXboI1KMBvXQAAAABwOcfHHGx6vN+14vVR0+hPFywPQCX6GgDA2eybAwCQifmUvCLiY+eObgCEQSgAsqI6UBeqZQVH648rmEC8W4EPCIEnVAMAanKsSXvHdQrWAAAAAICfep+Oh/rTUc4UCPOxnPk4qqIpvQ0AAAAoIe9lvwYAQBnmU0qLiA0AAP//7N3LEQAQDAXAlKYF9N+LiwZcTMJuCTmZfB6hGgCQ0H5ECtagutbn8KsJAAAAAPzJ0TFVmc/co9ZU1HZwFMApy8QAAAAAALxOL5ycImIBAAD//+zdwQ2AMAgFUDZztQ5UZYTWzbx4NvFi2vreCPwLCQEc1QCAQeV+FI0kC2hCBAAAAIB/uZeNLRwzo541i+S+kTW7WRiTcjgKeM2HPgCAJWxiBAAAeHQqD0OKiAsAAP//7N1RDQAgCEBBolkBNZDRbeCnk3kXgU/YHqIaAPA2H7ooL0cX1gAAAACAv9gJUpW7zH1mTkUtZwrwAAAA/EdIGAAA4Exgmufk6CsiYgMAAP//7N1RDcAwCAVApM1CO0Ez1KQWKm0/JHOwlPROAnzyAEc1AGBj+alEmJDqrnZ3wyQAAAAAOIAlYwpbc0wBn59lzdWdih5dAwAAAAAAgE/uQsJ+IuIFAAD//+zdwREAIAgDMEZ3IXVFX27gnaDJCLxpq1QDAJKbfTTPhDzAMiUAAAAA/EHImKqUnN/j9pSkSAqAF+yFPgAAAACAQ+QgySciFgAAAP//7NxBEYAwDATASMNCoH4wxEwttM744KENsysh90tu4qkGANSgTEh5eZ0eawAAAADAj2VLO0CqGv3pij2LfLN3C6OiO1sekgMAAAAWsM8EAGBXUzJsJyJeAAAA///s3UERwDAIBECk1UJSQTWUBIv9VEB/GTK7FvjBAY5qAEABOZcwISe42t0FCwEAAADgQN9Ssf4fVZnBbJYjfUinqkflAAAAgA0sKgIAAPwVES8AAAD//+zdMRHAMAwDQEMrtABqYwqB1sUAMsa5fxIefJKUagBAE/nNoVWYC1iqBAAAAIA7CRXT1co3/V/OoNyEjp4qlgLY4dYBADRlUAwAAGBPZSDhLBHxAwAA///s3EENwDAMA8BQG4R1NCuFYj8FMUd3FPKLbBvVAIAsAhbEe79lWAMAAAAABrllYqFyIvXux+X+oXcLV5HKsBQAAMB8/p8AAACQqqoOAAAA///s3EENACAMBMFKwwIJflAEWEAaD0xQMiOhfV6yohoAkMgacwtr8IGi2g4AAAAAXxHSJSuby3v8hIxKbVUUBgAAAAAAAK7tDjykR0QcAAAA///s3EENACAIAECaayCVDDazhA9xdxGADR6ApxoAUEzO1Q2WfMCSPQAAAAB8wBExleVI9fsYOaGwJnkAFKWHAQAAAAC3bRHlKRFxAAAA///s3VERACAIRMGrZgS1fxdrcONuBH4ZHqIaANDJly7q7XuENQAAAACgnwMsWtm1zLV+HwCdhKYAAAAAAAAABkryAAAA///s3NENgDAIBcCO5gqo+7hQLSs4mnEIk6J3I8APeRA81QCAgvIcl2NPPmCJbXVcCAAAAABFxR4e51JW9pRPTyp7Pnuw6+91oKQj9li0DgAAAHhbnkO+CQDAtMyrTKe1dgMAAP//7NyxDQAgCARAVnMEdSBXt6G195O7FWiAPHiqAQChurkUKCTdmXsJFwIAAABAmD4attsj1VC573kuT6qjcsCLEDEAQDTzHgAAAKSqqgsAAP//7NxBDQAgDAPASUMwySwgjQ8iVnJnob91qVENAMjmoZAfKJsAAAAAII+7HqlO7zZaPtzLSE4kWm94CgAAAAAAAIAJquoCAAD//+zdWw2AQAwEwErDQjlsAhI4aQQRJCyZsbB/fTqqAQDBzv2YDmvwA0uP1UceAAAAAAjRWz/1PAvDpNJXySErUl2SAyCJmQ0AAAAA4AX6vXxHVd0AAAD//+zdQRGAQAwDwFoEBB2COGoBaXzOAxNm10KezaRGNQAgXM/79KmLHxjbsSvhAwAAAECGISdCPX21m0qIlZW8iLQGqAAAAAAAAAD4WlW9AAAA///s3cERACAIA7AZ1YUc3Rn80V6yAs9CUaoBAB00t9HAIj4AAAAADOdImHDylDxmRiq5FwAAQAkPwxhIES0AAMCHdfZ9AAAA///s3NEJgDAMBcCO1hUCHVPNCNbNRHCIptyt8H4CL4mnGgCwgTyvaamQDfRvQBUkAAAAAKwpRnRHwhQ280jL5sX8menAKClG3JIDAADYgqcarOaRCAAABejnWUdr7QUAAP//7N0xFYAwDEXROANnVBAQi106IIAh6bnXQpY/vYhqAMAm8nmHsckGLlV3AAAAAChLUIPOhBmayjsFuenqXEEqgC+bhIoOVwEAAAAA/rSeiEMNETEBAAD//+zcQQ0AMAgDQKzPzxIs8pmIldy5IG3xVAMAdlG+YAPFfAAAAAD4zBsFGwaT6vRthZ1sMjBSyb0ASODWAwAAAABgr6oaAAAA///s3cENACAIBDBGcwV1TRNX9MMOimlX4EeOQ6kGAHwkG9yECqmu9Tl8nQMAAACAtzgKpqy9tp1zcWZIYS2LqQAAAAAAAAC4ISIOAAAA///s3UERgDAMBMBYTMEPNQRIwFqnFng1nV0L971cjGoAwGbe+5mlQt/WqO7KoykYAgAAAMAC8szuczGFGSPfhyyp6pMcAABAaQaHAQAA/nHjyBoiYgAAAP//7N0xDQAwCARApFdQEzTUWZc66ALkzsJvQB6lGgAwk6NCJrCIAgAAAIAazOpoK3cu6c0gSzp7BVUAAAAA394DRgAA6OBIiRIi4gIAAP//7NzBEYAwCARASoslROs0aSGlOZMmFNwtgSdwp1QDAAqa91iKNSig9eu0+AcAAACAFwkBk5xbST3H3wdAWgqqgE34ja/ynwEAAAAAQFkR8QAAAP//7NxBDcAwDAPAQiuFbOUzQpUCYYW2zzBUSnVHwc/Y8VQDAA71FzGWfCnuifvqQgQAAACA/WJENwKmsJUzDQMPkzOX+xdVxYhXeAAAAAAAAACbtdY+AAAA///s3UENADAIA0CkzcI2/172mQdScmeBHyVFqQYAzOYDGxM42gcAAACAHnZzJJORzGW2pFq/sAoAAIAQ+x6lrQAAAJCuqh4AAAD//+zcwRHAIAgEQEqz4CgtUFo+1pBRstvCPeHOqAYANJZzlcdCGhgOUwAAAADwrV36VfzlVpVPlvR62tnKl1sZrAIAAAAAAOAXci59MM4QES8AAAD//+zcsQ2AMAwEQI/GCsBAGY3V0ngBGsQndyPYjWW9XqkGACyuj0/BQtKN874E+AEAAADgO49ZE0zh+PrsmFRHF1cBe5Ph4I8UPwEAZPAXAwAAeKuqJgAAAP//7N3RCQAgCAVAVwwaM3CF2qyfZgisuxH0T/QpVAMA/mCAygsscAAAAADABa03n0KobOZIh6qPOz3WZ6oSXAWs7ysAAAAAAABwS0RsAAAA///s3EENwCAQRFGcARJadAIWG0T0MOE9C3vbTL6oBgBcYM91RoXdrQnXnvEa8wMAAADA/wRuSSY0fg+3JpaAFQAAQAy/UgAAAEhXSv0AAAD//+zdQQ3AIBAEQKRh4Qp+MNQEC5XGBwtNemXGwj73smdUAwAOsYc1fOwiuxHtqlIEAAAAgHdED9/zyeyZ99SFHGJnbViDrEb00HkB8CnuMQAAAAAA+KVS6gIAAP//7NxBEcAwCARArNVZBSXFYj610EkouxLgA8NwQjUAoJGcz6Xf/IDkdwAAAAD4wPvc64mKsnKkO0gzOfLuXgNKc/MC4DT2QQCA8wkVBgCgGjMs+0XEAgAA///s3EERwCAMBECkYQFQVEGABpz1UwmdaTPZtXCvTC7xVAMA8lEoJbraRleSBQAAAID3Oe4lskt6acmeqOrz0ApIZs9l3w0AEEAb3czG7+y5HCQCABDNkRifK6XcAAAA///s3LENACAIBEA2dyETVrRhBAuRuxXonvwb1QCAYSpMFajS3fKwAgAAAIB7qtQrc6Ot3KmcOpTb05xBKwAAgHfJSwEAAOAHEXEAAAD//+zcQRHAIAwEwEhrJTCDoQoqSMAaJvpoyK6EXJ43Z1QDAAqa77jlzgGUDAEAAADgO8stSewRXnl+gKyu1pthGAD+Qg8DAAAAAIDzRMQGAAD//+zcQQ0AIAwDwEnDAmCTBAtIwwKB18KdhKXPtUY1AOBfhjXIrtTePBkCAAAAwCNlXrKbY8rw52SA5BSYAQAAgBPLlQAAAC5ExAYAAP//7NzBEYAgDATAlGYLYkFWJLQAnfmyAfiA7LaQvG6SU6oBAJsqT67CVX7gPq90GCQAAAAADPHMy8qUiPOxCyxLwRVsyb0GAMD85KbMppkIAABAh4h4AQAA///s3dENgDAIBUBWJOk+LqQyQh3NxDiBX7a9WwG+CDyEagDAwuo4LRcyg66KAAAAAPBNtjRfY2RX7eUglcfbC/qBUW3ZUpA8rMUxHL/ksQkAAAAAANOJiBsAAP//7N2xDQAgCATAX1GdyM1trOzsxNytAA0JPEI1AADBGpTXRrf4DwAAAACX9vGugykqm6rHQU9QmQ/IALzAjAgAAAAAwF+SLAAAAP//7N25EcAgDARAlUbBBrXg0kiUEBJ5wLs1XKbnPNUAgJ/LPrR2cYOmLQUAAAAAtjne5WRvPmm+waIyIRecqtXDKwAAAD5mHxEAAAAuEhETAAD//+zdsQ2AMAwEQG+GGCESA4WBAiOwGoIeidKGuxHyLiIXb6UaAMBVrDF7BT7gECIAAAAAvNOW1l0gprhVgDwwG1Sm8Ar+QwkUWU2SAYCb3Snp7GPrUgEAoBr/WFKIiBMAAP//7NyxDYAwDEVBj8YKkDUhXoHR0oSOghJHdzNYcvWfqAYA8BDWoLy9HcIaAAAAAPCN0S6V3XmmISqv5m24D6raZvgKWFxe3a/irwyIAQAAAABYS0QMAAAA///s3MENABAQBMDrjBZQkc4l4s1TyEwLe8+9NaoBAEyrsKG0wetyaVXBAwAAAAA2POvygS5EDtwILzN8BQAAcF+SAQAAAHwiIgYAAAD//+zdwQmAMAwF0IymIxRcyH3UjOBqgogn6cGLrbw3QhoIBPIrVAMAuOW6jarBD+weEQAAAACelakMjnXp3JxLCgmn6uoRwRp0SwAWAF/ymQkAnMxDWmMnCgAA8FZEHAAAAP//7NyxDcAgDABBr0gYiIUiMQOb0VChFFEqHN2tYEuu/KIaAMBOWIP0Sr2ENQAAAADgmaAGqfW7ezTnFbtCcm2FsIB/8xTHqdwgAIDzDDMBAAD4KCImAAAA///s3TEVACAIBUCiWc1AagWjubg4uinvrgJMvA84qgEAHEbrU3CDBIrPKQAAAABw2su55mb8rKoel/QMP3MIC/KzFAcA8CDZQwAAAEgmIhYAAAD//+zcsQ2AMAwEQG8G2SwDQTwCq9HQICqaSEnuRni7ceFXqgEAfOTZilSYwGWIAAAAAPDiOZeh5ZHVBPnDzjC4/SnEAoDeNokDsDi3GAAAAMwkIm4AAAD//+zcuw3AIAwFQK/owEBkM0ZDGSANDVi6W8Fu/NETqgEA/BGsQXnZHsEaAAAAAPDtynoOz+AU9yogm/QOlbl1AXCC2REA4D5TTQAAADZFxAIAAP//7Ny7DYAwDAVAj8YKwEAwEIlXyGg0KamokuhuBH8ay3pCNQCAT1lqc4BlAdt+Hp49AAAAACDiUgMm1vLJWwP5w+wwux6MBSwoS7XfAABjcktlOP2vGwAAgD8i4gUAAP//7N3RCQAgCAVAV2uEoIUaqFqxCfoKgupuBP1T9HmqAQAsjdaT6vAACV4AAAAAfC2XbEbG7aoOssnOi5s55gLgOAEmAAAAAAA8IyImAAAA///s3bENgDAMBECvaMKYkbJCRouQ6CkokMndDN9Y8tuOagAATywZUl62Q2kAAAAAgC3lmVcRShmKyubowxdGXrkzJEeU5UAWAB8wRwIAAAAA8A8RsQAAAP//7N2xFYAgDAXAjMYKwkI6kLIiDTWNFoB3KyRVXt7/QjUAgKF6P54M2UHSogIAAADAT2m3Z3WXCfIRu8TKUg/KAvbjHwMAYCJHyad5MCF3LQAAgDciogEAAP//7N2xFcAgCAVAVsu+GlbQzWzs06SI5G4E4D2qD45qAACPst+XKlGAD14AAAAA/MoO3wrgcrKRLQVNecWeJfPEyRzKgpqmvvJR9g4AAAAAADVExAIAAP//7N0xFQAgCEBBmmkFtX8XFwM46IDeReAxMXxENQCAXcIapNdGF9YAAAAA4CfuYWTnAyOn2SkyqyuYBQAAwD3FbAEAAOAxETEBAAD//+zd0QmAQAgAUEdrhasGaqDKFRqtnwYILqK73ltBQVBRRzUAgFty233vogdDmUbLhgAAAAB0r8xlEWUad+Sa5hI86sopeUXLHMwC4DX2KwD4KfWPL9LPAgAAqBERJwAAAP//7N3bCcAgDADArOZkxX2qWbE/DlCEgtq7ERLylZejGgDAa9l6ES0OYNgQAAAAgD+4ZJmd5Z16Enyliiw7czgLzpKtq2lWZqkYAGAB4zEiAAAAsyLiAQAA///s3DENACAMRUEsFjCEHxIsIA0NDAwldxo6NT9PVAMAuGXESnrRqrAGAAAAAN+KHv5fZCd6wDNrru3GSE44CwAA4IFoVfAMAAAAflTKOAAAAP//7N2xDcAgDEVBj8YKThgTiRXTsABFkIzuZnDr90U1AIAtq3aseEx1Ld/HogoAAAAA18mezZow1c0xPTDwKzdGdQJaABwi5AQAAAAAQH0R8QEAAP//7NzRCYBACABQN7tutAaqVuznFoiDUHlvBBVEUD3VAAA+e657ihoNWDYEAAAAoCNHT1R3yiA/UWtUdqxHWkAPehIAQA5DHkjIvAAAALArIl4AAAD//+zcwQkAIQwEwLSoNmRBgi3e5yoQFIwzLSQQ8thVqgEArFKswfVKq4o1AAAAAEjjD9cK2HK1OWY3QU6waySgSAuA7UqrfkwAXuLuAQAAQEYR8QEAAP//7NxBDQAgDATBSqthwALS+KCABJKSGRN99LKiGgDAkdH6VD/mA2kAAgAAAMBHRGSpTtCb1/y6qCx3UAsAbnJrAAAAAACoLSIWAAAA///s3YEJgCAQBVA3awargRrIuhFytAiaoCC03hvhDkTO4ytUAwC4Ldbt/MGrqiCd2wVrAAAAANC7POdFE+lcjRLeHHhVlHB20juBWvAN7kC0bNAdAP4gT6MZAU26drUBAAB4IqV0AAAA///s3bENACEMA8CsxmQ/EbDiN2xAAUZ3IyRdItlCNQCAXRq8eMFniwAAAACkWi31blyk82/glGbyJBOsBflmH0I1uJmSEgAAAAAAslXVDwAA///s3DENACAMBMBKwxmGSLCANJYqgIGU3Gn4qfm+UQ0A4EqWOxRdqa5ZmgcAAACgMIMaVLfmmJ5JeSKzJ39U1nNgCwAAgHNurAAAAPCriNgAAAD//+zdwRGAMAgEQFqMKUgbMmkxHzuIM4izWwMv5g4c1QAAts17XMKG/MDZ+iFwCAAAAEApT4nWXovqHO8mmxmkOuUvqE/mgs/ypAQAII2dFQAAwBsiYgEAAP//7NxRDQAgCAVAohnYzQrazB8j6BR3VwF+YPCEagAAu1jc8gMHhwAAAABkY6dFdr3V5omUq1YP6kMyKytoC8hrqB0AwB0CpAAAAM4xc/GEiJgAAAD//+zcgQlAIQgFQEdrhaA1qxX+aJ92KMi4m0EQFZ9QDQBgi9nHJ1iDBxTDGgAAAABZ1FbXLssDLdm5LXALtUh2grYAOEWPAQAAAAAgr4j4AQAA///s3dsNQFAMANBuxgoYCPugK/q5G5C4lXNGaJr0oy9HNQCA1+R5bb548QPrtMwWEQAAAACowGIT1e15pL4CXWi5KB+pbGwHt4Ca1CAAgO8MYk+P2lw2AAAAT0XEDQAA///s3cENACEIBEBa1GtTpcVrwgeSmRp4kBB2hWoAALdp8aIDzwgAAAAAlOZplg5ypTmmGncuXufGBY/KfYRqUNr4pt0dgM6UcAEAAEBnEfEDAAD//+zcSxHAIAwFwEirhbTIZAYLlcYFAT30EJhdG+/jVAMA+NUqeigcsjshGQAAAABlZcvLaJYDyBIoZ/Qh52J7jrcAAAC+y+fWFQQAAIDTRbwTAAD//+zd0QkAIAgFwNFbqHKFRougEQos7mbwR3g+lWoAAMdF6yuo5YsKAAAAAMAdCjV4XtRw9E1KZpMPlF3ABbxHzoLM7KEA/Mr+RFaKXwEAAA6J1scEAAD//+zcSxEAIAgFwNfM7DbzYgRlxNmNAJz4eaoBANyimQsAAAAAcNg+krXoTXdmCLxOjdKdw2foacobAEC5IeQAAADwuSQLAAD//+zc0QnAIAwFwIzWFbQLdSDBFRxNhI5goYa7FZKPBJInVAMA+MRK73JwCAAAAACwnSdZTjd6648q8md6lASuN4gLALYpdzUjAZCR3QkAAACyi4gJAAD//+zcywmAQAwFwLQYtSAbUluwtEWwA3E1y0wJIZd8eEI1AIDXHNt+HdNPFQYAAAAAeC6XXD15MwCB3FShV6lOEBcUc/9YAADQSc6TXSu/ZT4AAGAgblZ8LyIaAAAA///s3EENACAMBMFKQzBJLSCNDxLKozDj4pLLimoAALc5HAIAAAAA1HA0oLuVM8W4aSFnisfT3ThBLgCoYpMC8BpRDQAAAPhBRGwAAAD//+zcwQkAIQwEwLQo2KZnCVqaFfjyBJWZEkI+S8gq1QAAtqrl64o1AAAAAADWpJyaEfIA9wJuY2e5nednAACAOZmJUyl6BQAA+FNEDAAAAP//7N1BDYBADATASsPCAYIQBNQCOOODAsIllMxIaPfXZKtUAwDoLrfdJy8AAAAAgIfa3AZfE/mBI9d0K6CUO7NyS2mKuaAchU58WpvGxYYAALo7jRgAAOBFEXEBAAD//+zdwQ0AIAgDwG6m+0/lxwmMMQHvRiD8SopSDQDgFYcfAAAAAABnfEykAzkBVdldqpu7oAsAbhimCEAHiqIAAADgI0kWAAAA///s3MENgDAIAEBWVCfqPlpW6Gh+uoAPTTF3K0BCIICnGgDAJ/Lqw9IhAAAAAMAz8wjWISzVtTxziCIVzdyVv1TnQRfUoeawOv0pAMD79AUAAPzCduzmiaygRUTcAAAA///s3bENwDAIBEBGy2gZKA4jeLU0XsBNBNbdCHS80KNUAwD4TY73FvQCAAAAAGyZxkV3+aTPn3SnOJ7urlXUBRS3HpZAaQ7hATiE8kHKshcAAHAQWSI1RMQHAAD//+zcUQkAIBBEwasoGFO4Ckazgh8ieM7U2OWJagAAtzkdAgAAAABsaL0JEVCBXYDn5cgpHE8BQl0AnOIID8DTBKIAAADgMxGxAAAA///s3cEJACAIQFFXa9/AFbt07xKh8d4KngT5imoAAE/terIDWgAAAACAM98SaS9nisPwhZw5TJLuBLugDTcVVGdXBaA7UQ0qsw8AAADcFhELAAD//+zdwQ0AIAgEMFYkcSAXUld0Ar8mYjsDH5KD81QDALhujdm1eQEAAAAAnGVLbfJUIABONWaa1zmCBgAAsBsBAADAXyJiAwAA///s3VENwDAIBUCkzQLtBE1Qk1qsgf4u68idBfiAhDyEagAAX3F0CAAAAACwkXdeviVSwRzzUUgq0dNUILgLfsGTEo6XvZmLAADeYR8AAKASoYacISIWAAAA///s3LENwCAMBEBvRhiYZAVGo6GkRIpBdyt8Zfn1RjUAgF987e2GNQAAAAAAlpQKuEGVIpfy3+J0zxzwApKafQrIrkgIgBMZhiI79wAAAMB2PSJiAAAA///s3EENgDAQRNG12ARBCCqMBaQRuCCAA2l5z8VuMl9UAwD4TLZ9VVQGAAAAAHi0pV1/U0NXRnekx/+fKaXH+IYZCHgB8Ja7FYBRCUMBAADAj9zxwqo6AQAA///s3dEJACAIBUBHawWr/WfpsxEyuZtBkCeojmoAAK/55gUAAAAAcFlypQOzf7pT4/xu5E7L0FCbXkN5Pv0D8ClZiMrkAAAA2sg15S/qiIgDAAD//+zd0QnAIAwFwKwodEwhI+hopdANClr1boWEfATyIlQDAJjqTfqyBAYAAAAAjleu4iCJHfSs2VWSnWXNZ17rc1bXVBCAj3z6B2ApAqEAAACGEqrBf0TEDQAA///s3cENACAIBDA2dyJ1RT+uYBRpRyB8SC6HUg0A4LrZh+AhAAAAAFDa/hbfqs+BLyjSpgq7TnoKveBpMhRkIBQPQDYKoXidOwAAAOCEiFgAAAD//+zd0QlAIQgFUPefpXKFRuvnrfBA65wZBBXkKlQDAKjC4SEAAAAA8DKBGtxg50iH3zzhq3X1TnfmDygq59JjaMHHfwCaEQhFafYAAACAn0TEAQAA///s3VENwDAIBUCkbRJIKnNJJdTaPjYR0N5Z4KcB+hCqAQCU8DeCBWsAAAAAAMfJkZeFbnYwn3krJIcx26K9HLlUEcryoY4OXPwHoAVBUDTg/Q8AwG6Eu1PBN9OPiBcAAP//7NxRDcAwCAVApFXaBHXDwuasP7PQhLZ3FviAAHlCNQCAMvJ+LkthAAAAAOBAHgnYgXABjpM9X7ctNtD+gC+gnk9NWIAeAsAqBEFRnfkfAABglogYAAAA///s3UENACEMRcFaJFlBCIKtRTxwAjojo0n/M6oBABwl569iBwAAAACU0b7WPSHxghyp9klVBmV4gYEvALYp/wNwCTdYAAAAqCoiFgAAAP//7N1BEcAgDEXBL62C28YC0nqpiAR2NYQZOOQhl49sMQAAIABJREFUqgEAdCSsAQAAAACcwhIrOxAV4Fh110qyTADDXX/oC2iknte5ZAo//wPQmgAUE7j/AwCwE+8w2knysXcHVQCAIBAF6Z9F3Yp28MTDmQwc4SOqAQC0k30sHwIAAAAA4zleZYqsmGW+lhXBeCYQ+gLglc//AHQnAAUAAAA/q6oLAAD//+zdgQnAIAwEwIzWFYQu1IHUFQvtEm+4W0FCguhHqAYAEGnP5fEhAAAAANDWuMfl8ypNPA4SPmqB4wn8gkj6C0eweRKAcAKgSGfuBwCgG+GGRNhz/XfXVfUCAAD//+zc0QkAIAhAQTdvocAVGi2CFugrkbsd/FKfqAYAUJmwBgAAAADQlaAGHayc6XkOzjGOWaCHccNfAPDKkTwAJQk/AQAAfGHfRC0RsQEAAP//7N3BDYAgDAVQViydUx1BN9OYcPHuoZD3ViAkbfL5KNUAAMo6tv16A7lOCAAAAABYyXisKkDACvygCF/uBCtQ/AW1yEwwCzsuAFUpfmIG5n4YIvsZ2e/IbscAAOA/rbUHAAD//+zd0Q2AIAwFQEbTEdQ10Y6Ao/khH8YJCrlboQkphL4K1QAAUovzWlUIAAAAAJhMU1AmcEcNn73hI2rYfssMlh4ABiTQl5HAELZj1wsBkEofyHa/IT19P7x+53YTrAEAY/JOSEqllAcAAP//7NzBCQAgCAVQVwzaJ9q8YxDduqS8t4KECvmFagAAGQjWAAAAAABKaL35PEAVUyXhytuggqGK8BUHdmShfwDwG8fYZGDehx2ocYbSC9YAAODF3rciYgEAAP//7NzRCYAwDAXAbKajOVAhK9jNRBQE0f+03K0QKO0reUo1AIDy7gZmoTEAAAAAMANLRsxgz5Zye/iQLTf/WkxgVQQGpXTjYBQW3gAoRhbLCNz34fJ3Zp/FGu+yDQCgtsV8KOJ5b0XEAQAA///s3MENgCAQRcEtTUsgsSELElv04pnzfjLTwgYICTxRDQAgwvvM06QAAAAAgGTjGh79sYvbJGHJGmEHPp9BH2JNJHF+ANCC0BNAjj+asdq3D2ENAIjiPkY/VfUBAAD//+zcsQ2AMAwEwIzGCgYGgn1IsiINNaIjhrsVIit6yX6lGgBAJoo1AAAAAICUYo3J4gAfsfejO+yEG9eMmBPSizU2rwjv67X5U8hE7gVgFIqeSKHXJnvza7HM28McoVgDABJQcMiwSiknAAAA///s3MEJwCAQBMDrXNJPwBINgStAX54yU4IfEXfXqAYAcIwMigiLAAAAAAAnEuLmCv3tQt4w53FOXKDlMBgATMtSHADs5i0DUFyWblf+z/5hjaGsCwCluaepKSI+AAAA///s3LENgCAQQFE2M+4r3AisRkNia2zk8L0NCAUXAl9UAwBIJWo77RgAAAAAkMn8jOrhADsQCYCH4gqxeHYhDAZrMIeRibMDgE8JPJGIOZ/fmmGM/nL9XVgDAJZ12BpWEbXd9wOllAEAAP//7Ny5DQAgDARBl0bBSLRIQgE8AQbNFAGJb0U1AIAXCWsAAAAAAC/ZPQqEVFptBgmwxjCCH5QRCAOAaQZuAFwm8ASQ3+lbLawBADn5n8kpIjoAAAD//+zdwQ2AIBAEwGsRtUyVEmjNjy9/JiZwOFMAX46Q3VOqAQCkU4/TZi8AAAAAIIWyFSUEzEI5ALxU9+pPi1kIpEFnz21qkIC7A4AuBKzJxJzPX5V1aR8Fbtt9FgAwAO8xhhYRFwAAAP//7N3BDYAwCAVQRqv7VlnRi5cea0ykzXsrcILCr1ANAGBJeV6HygEAAAAAC3BIxBaypwVveCF7etNiB01QGACTLNAD8BfzWIDCnmPbL/uFJlgDAMowE6SS8fOLiLgBAAD//+zcwQ2AIAwF0G7mDKgLORqbefHi2VQLvjcBgQQItF+oBgAwMkWIAAAAAEBZbW+K+JiF93h45jB/TEBjGnzPecJQ2rYKZALgVQmN2pDJ/Z7fufbpjL8zwRoAUMNiHSik38YSEScAAAD//+zc0QmAIBSGUVcUGtO6K7hZEfTYS4Rpcs4Sws/1E9UAAH4r1q3eVcMAAAAAAHrLS3bAzSxqlLDFwwtRwodSpiAYBsBDgkwAfM0eCzC2ltvSGdbYr3AHANCHd5hxpZQOAAAA///s3UsNwCAQQMGVVguATkBCrfVSCQ3lM6MBAiHhragGALC0XpvpeAAAAADAjHweYhcmJsI37CV2cL3hMOAHvTaRJpaTSrZuARjJmyzLcL/nNKnkUbHWW1gDAMZz/jK9iHgAAAD//+zdwQnAIAwF0KwodKAOJGSEOlovvfVYSFXeWyFgApqvUA0AYAeCNQAAAACAabSjnX7gYBMjew7FhO+yp0UJdmFJDf5lNmM1+gYAJQQ5AczrOaMr780ufQEAynkjw1ReQYYRcQMAAP//7N3BDYAgDABARnMF1H2MA6kjqJv5cQQDFO9GKJSkTQGPagAA4R3bfhkcAQAAAAAa4tIQvVitJHxKTtGDIc/ZYCTUc4s90filEoBC9GSJRI+I33jrgRpn9JKn8bTTAKAYNRltSyk9AAAA///s3cENgCAQAEFK0xJQC7Ig9FqwND+WAEHITAs8SC6wJ6oBAEwhrnt1kgAAAABAb/nINl8xiydKCFpDRVHiFIpnEj4kQD/uEUbkQT0ATeV9M5MF+KEvqNFzjrQIawBAe6K6DCGl9AIAAP//7N3RDYAgDAXAjubAQkfUmPjnNwHq3RCQFvoqVAMAqESwBgAAAAAwzbu13bAQJeSZeu4whk2klCBIDObI1oVqsKPDx3oABtOTZSvZupqav1jhfH7qkUtNAgBDuWdZzfctJSJuAAAA///s3LENwCAMBECvCKwZiRFQNkuTLjUCnLsJ6GwZ+4VqAABpvMsjFkgAAAAAgFUsb5OFo3+YpF/dfxZZ6HtgHXWEE6kbAExRWhVOwGn08/xCaXVsdmA7BGsAwDRmf+zm/jwoIh4AAAD//+zdwQ2AIAwFUDaTFZowpsoIrObFo0dRIO+NQC8NaX+FagAAS6nH6XIeAAAAAPC5KJFd32AVda+WEaAvwTUsIUo0lYRfPA6DwuCyBTYAOtk8LJPRz7O8O/BoxP6/CWMCgHf582MaKaULAAD//+zdsQ2AMAwEQI/GCsBALISUFRiNxh1tiBLrbojEX/itVAMAqEixBgAAAAAwmssbVGHZH37W7va4SkoRWxaLAWP5Q1iV3AxAV7m8JZOwGvM8peXbPPPsf+3noSgWAPqRyZjRN3dFxAsAAP//7N3BCYAwEATAK80WApappgRbE8GnHyGEXJypIguXXaUaAMB06n44RAQAAAAAuilrGXVxCz6rW7XSBn0osGEWPkhDZ89NBGS0WK4EoDF5hHS85/mBDIUVdzY55RMAaEIuYzivuSsiLgAAAP//7NzRCYAwDAXAjKYjFBxTzYpScAOlkHC3QelHmpI8oRoAQEt53bubBQAAAAAWMSRAF5b8YZE8U0g8XWzjGBYQYD3vNqrSPwPwi3cRWi9CNf6CaG0GVRQ636whgjUA4AN1lFIi4gEAAP//7NzBCYAwDEDRjuYKBQdyoEJW0M28eBQRqWLKeyO0hwYavqgGADAyYQ0AAAAA4FV1rpkWBOHKGi0WJwTfiRb+shiFeQiAuybL9gB0ItRERptbY1RHUCPjrC+sAQDPeUP5o/OYYSllBwAA///s3cENgCAQBEBaRC3IhoASbM0PTz/GoHKZ6eEIucCuUA0AIKxWqoYvAAAAAGCY3srukQBRaDuHb5g9QshbFswEL2qlmjlm5hM0AI/kddntZZmRezxR9VCKmc/lo4eCAAD32PPxR9dhhimlEwAA///s3ckNwDAIBEBKc8FOaCGl5eMCLFk5jGaqWCRYlGoAAKXlcfrwBQAAAAA8xYIAVVzZU0k1fCB7OqagCrkI3ie/savmEzQAi8wfAD8xsn2FQoqmWAMA5o2yQ9hHRNwAAAD//+zdwQmAQAwEwOvMGgLXkJUr9/OhICJq4kwJgXwCu1GqAQD8gWINAAAAAOBW0SP71y3Ymk0DXmUHKSF6CB7Asw6/rUECwtAAXCK4RWLuP1RV6R40ijUWJYAAcMpkTHzUfiF5a20FAAD//+zduQ2AMBAEQJdGC0CbhisBl0biDJEgxHOaqeK01q6NagAA6cWyNmE0AAAAAHAzpVGyaFHDL+fwoqihEEQWQx8eA57hhuPPBkU1AC4yzMRfud9JZ5ynrG9lmxEnADjXcz3ZHp/Ue6RHpZQdAAD//+zc0QmAMAwFwKxYcB9dSLuiP/0uiCIm3u2QUEreU6oBAPxC34/NhzQAAAAA8IS2NId0VKKUGr7BLFKFgBu8ZHYYCkkoqwTgEgFnMvN+p5qxkyuHadfCpSEAcJdCDfKJiBMAAP//7N3BCcAwCAVQR8tq3SfgiqUQ6KmHQimJeW+DXAKKfoVqAAA7MYwIAAAAAHzBsihVHNnTMDdMIHsKiKeKJoAMfmUOgqVZjgbgJX1ZVqXnQynjOv0Of3K7gjXGewGAm9qMWT3XXhFxAgAA///s3dEJwCAMBcCsKHThbiat+S2IXzbebaCCIiZPoRoAwDEy5VlBCQAAAACwrF3Nr1SUkU38wD68Y1GFYkoAZjkzAJjyNDWbKX7stnhUkQETJ+3J73gFawDAICSXzX3fvSKiAwAA///s3cENgCAQBEA60xYuoUyVErQ0E8PfhIcRmCmBFzl2D0s1AICplP3wyxcAAAAA0CRyrDU8ByNQ3oefKVu5vGMxisghVAkfqBkI6JqSNABvapHZXJZuubczmFkX451KxADwWBwDXUop3QAAAP//7N3RCcAgDEDBjNbNXKjgiv74rVAoRHM3hZjwIqoBAFRkURgAAAAA+MIFXa7R3275E3Iyx+IWbQbJgP8JMnG6x9VnADb8ywIkMIN4ld/uTRQQgMoED8luGTSMiAEAAP//7NyxDYAwDATArAgsxEBAVgiTgZBQKhoaRJy7EVLE0st+pRoAQHfyuhULiQAAAADAG/dRqOUAopCRw0/lJRfH0QTi8A2+sXtnAjAzAHg0TOMsl6VxslhC8B9XVyngoRgQgE7J8GhXSukEAAD//+zdwQ2AMAgFUEbrwCYdwdW8cNFD9WKU9r0hmhLgI1QDAFhSJo8ZSAQAAAAAnnJ5imn0rQ+vcwCfs2zBLFoGkwEvuru8BkW0XNIDgCtLW1RnVpnyMkDCe3y2q2EAWEn+B/R8+LNx7RURBwAAAP//7NzRCYAwDAXAruYIVfdxIbUr6GZ+C0X/pKZ3ExQKeaUksVQDAOiZhkQAAAAA4FWes6Y4IhncJrStrOUwcEEgBi7gG3KDCGQGADd5Gi065vfKtnurE4F6XLfIKgA64u+O1p2PB0wpXQAAAP//7N3JDYAwDARAl5YWgDaR0gKdwcc8UX6ImJkmcmi9VqoBAPxWflQr1gAAAAAAHuV2deEAqjhyWB/4uL53BThU0RSUwSuGYVGYgYE0AG62IFOEjDLTc0cfasu2nnluAUBJ3meUEBEXAAAA///s3bENgDAMBECPxgrAQiwEjMBqadyCaCIRc7dDpLdkf5RqAAC/du7H5scWAAAAAOCBQg0qscQNY/FmqUKegv7sPVDF5BgNgGSOoAI5naFloYZ8/s41r4tiWQCqMp/xeXkjei8iGgAAAP//7N2xDcAgDARAVrTEPlmIxCtktDSUqSKlwNzNQGFZj99RDQAAgUQAAAAA4EX00LZBJXeOFOKGheRIIWzKiB7eM/woz8ucRyWasAE2Nz8l28uyPHM6K9NI/8kxD5EAQBlmAsporT0AAAD//+zdwQ2AIAwF0I7mCspAji6XnryQmHhoeW8EEqA06UeoBgCwvWxaC9YAAAAAAN78tkEn+uBQk71LF3cGlgH/cWfQhkE0gH3lwJa+LB2ozykrz2I1+TfHOa4n1xAAOvA+o4J1oGFETAAAAP//7N3BCYAwDAXQjuYK6kIdSMgI6mYe7F1BRBrfm6DQS/pJUks1AADOxRr1bgEFAAAAAOTXflPX8EYWWywhA4cOxRLVvZGIxkt4l3qPTAZDaAC/5d0A8D0LNZ5bx3mS7QLQtZbPyejowX55yFLKAQAA///s3bEVgCAMBUBG0xFQ93EhlRVt8FnaaJF4NwI04eUnWKoBAHCzFRoAAAAAuAhvk0bb2ug2ITQ9LLIY6lKFL+EjbT8s1SAbg3wAP9OHj70ZSKF/9gfh1HlSh79ndZ4ABCc3QxTP/ZFSygkAAP//7N3BEYAgDARASrMF1IIsyBlK1E8K4MMjYbcJQuY4lGoAAIQImAglAgAAAMDm+t2FXanE3huSG+94ZoNAkIAAJqxl9qMUD9AA9hE/ILsvUIU9DikpN1ri6Nf5xTkHAGmYC8hkqnS8tfYDAAD//+zdsQ0AIQwEQZdG5+g7+8QBDRD4mGmBBCF7EdUAADh0GdpjNgAAAAA8qn9PN7xNjF7GB+azJE2KJWAGV5l3IM2yfAbwDCElknxOk2nEja7booEADONeQJaq+gEAAP//7N3BCYAwDAXQrKiuKXQEO5oIvXnppWDie0OUUH5+lGoAALwJJQIAAADAfwkGUIn/biiina1blKYQ8xYsMnuNDZKxeAZQnCVjqhkH/iCNUajhLV7vKQ28FAcC8HXbsZtnyWQuFxMRNwAAAP//7NzBCYAwEATAtHiQMoW0KMq9/Cu6zjRhYnbXqAYAwEWHTASNAQAAAOBnatYRYhNkI8balrALZPF+RYyapagB9/G9II6yNUCuLhb7J0sSQ3d8kQHU55wDJsrKALxV39GcDcgzxtgBAAD//+zcsQ2AMAwEwIyWzVgIKSvAZmlcItEgRJ67FVJEsv2vVAMA4EK1RBtsAwAAAMC/OAwgiTAlhBn7OOyvCNKr0Ax4nr+CRF3oDCBPhbUUJ5Hm9KKspArszGjetykPBOCj3M2wlMqA3mutTQAAAP//7NzBCYAwEATAtCjYjxakpgU7U4R8ffiQyDrTxOXI7SrVAAC45+AYAAAAAH5iGIfZ0SBB9rpUgTPI5P+KJA4z4QV13ZRqkGpq4WsActgJiPMk0AW9teI6b+x+rvLAw54DwFe0mWQukamUcgIAAP//7N3RCYAwDAXAjuYKBccUOoKriZBfwR/RPu+WaJu8ND7VAAC4UEETwUQAAAAA+AcBbpKobUOosY2zf2VYmhRLX7twJjzDfZBUNjkDhKjt/N4DpFGzYRo1NKs39g17nYsA8DbnEbO53wtprR0AAAD//+zdsQ2AMAwEwIwGIwQYEykrwGTQpKYDkdfdCi7ysmLbUg0AgAd9Y7QmNwAAAAAEq1v1MYAkRx+6B0K1vc1qSxA5DN4hDxLLsBnA+Fw/JtipuAxErv6Xqa7L1d9IAPicnhvxSik3AAAA///s3dENgCAMBUBGcwXUgVxIHcHV/Om/MSEG6t0KhAZIeRWqAQDwzAQXAAAAAEgqpqNrUCMTb9rwD/Y6adS1blYT2jr3Q6gGmU2a/AHGFZ+F1XFSikF+0D3n6a5ddZnVEgA+JfiQUb26g5VSbgAAAP//7N3BCYAwDAXQjuZmXaiQFRxNhN49Kfb3vRVySeAncVQDAODBDJsIJgIAAABApq6uBDlrlAVK2ECNEqwmiX4M3iHnQLLDB2eAZVnkJpX+myXMgxp66X/rd53MPAB8yJxGvtbaBQAA///s3dEJwDAIBUBH6wpC9p+lPw7QQAvV3O2QD8nT56gGAMADdblMEBkAAAAABsmV2jaYRnAbzuLNM0auFNiEl2nJ5gCWzACaqUVumErGmN/TQt/KVTOP2R6AT5nTaGzvrzwibgAAAP//7NzRDYAgDAVARnMz4z5oVyQmHcAPTaTcDUFLeDylGgAAzwkmAgAAAEAtwgFUckQPwW1YSPQQqKaSLQvPgHfZD6lOsQbAJPKjljObsuK87N78Wu7N3sXms98z1L0HgC9keZMZwxpaawMAAP//7NzBDYAwCAVQRnOFJu7jRNoZ3MxLB9CkB6HvjdAeIBC+UA0AgJfGwFuwBgAAAAAU0PbmEJlSHNfDsuyuqOTwmzDd7UlZgPoB8HMOtViA+QwZ6Jvz2kagoD0QANOMwCb9AWn18/rWG0XEAwAA///s3dsNwCAIAEBGcwWT7tPVGxMWsO2Hyt0KfEiQh6UaAAATMuGyTRoAAAAA9qc5gJNo2oaicqGOvytO0frVDdrBj940lcKG2rjcLHAAazKoRRFqMywt82U1l/3dI5b5tgLAV+pp1BIRDwAAAP//7NzRDYAgDAXArlh1IBdSVzQxLIDxA8vdCiTQ0L5aqgEA0M9wMgAAAAD8WG5pOIBSWqgemJfeFZWo0+B7An7MwGINgAG10K/7mfKu41RzM6xcl91CjVKet7WdKwC84h+NAvr74xFxAwAA///s3dEJwCAMBUBX6whC93Ghgit0tFLIAC30wyZ3IxiQKOYpVAMA4KW4/N6sGwAAAAD8T/x+7vEgmRimh+LmMU8D02TS924oAL6lX6QKwRoACxGoQSH6bZYVe/FQoZTGff6JGgPAYwK3KKu1dgEAAP//7N3BDYBACARASrNglRYs7RJjAebi44SZFvhAAotQDQCACU+whuVEAAAAAPgfy4NUcuWeDo+BcMBBMfo1+JCv2TSz+dgMsAyBGrSQx6n3YEnCjVq4ayxcEIC3BG5RxdQcFhEDAAD//+zdwQmAMBAEwLRmCQH7sSH1SlQU3z6CoOZmSsgrCeyuUg0AgEaxrIOzAwAAAID/uFbPLW7QEyF64BRzKISnK3WswgDwLPdGMpmsNQO8S7iXRPzF8GUCs3kc5YKbdxAAdxRukV4pZQcAAP//7NzBCYAwDAXQjOYKBfetbtZLvXpQQU3eW6EQAs3/SjUAAO5RrAEAAAAA/+GAkEy2GaIHOAhMk8nS1iYIAM+xN1JNFygDeMcs1DCDqWL30nyRWVxWV2wFwAn3MmRx7U88IgYAAAD//+zd0Q2AIAwFQEZzBcCBXAgYUX+Mib9qjMLdCiQNpO1DqAYAwA2tVL9+AQAAAMAPxDkuzonOWJ4HTvagHX0remLAEx5itoFBCdYAeJklbkbTStV34HP2O7BaPK4p5rTGnNQnAA7eanTmWq8jhLABAAD//+zdwQ2AIAwFUEbTfVVG0NEMSS8ejcSQ8t4IcICm6a9QDQCAj+p+rM4QAAAAAMYVW84NZZLJFcPzAA91q/pWZLIIRoOubNFmRoI1AH5iSIsJCT1mOPH3Pd0MrS/a3mb1EABqNbKJEPH3Sik3AAAA///s3bENACAIBEBGc/+pbCysLAwmBu6GML6BV6kGAEAOA4oAAAAA8C+FGlRjYBs4cUZQiXscJPGLNo1ZJAN4zJIWTSk95kcKNdiNlYe8BwA0JatR0H0Oi4gJAAD//+zdzQmAMAwG0I7mClH3caFCV9DJ9NKjXvwBad/boFACDclXoRoAAC+oKWca5AAAAADwMzHHYEiAxqwlF/1o4FLJxZA0TYk53Gl4j+AleiVYA+AjlrTo1Prkd2T4Qq3HcGaJady9iQD6UkOV1H5as90+T0rpAAAA///s3cEJwCAQBEBbS2VpKHotSsACJPoI50wJPg5O3FWpBgDAJlHb5SwBAAAA4Hf8bk4q8YS7aGCG0DSZ3KMoDVgn+MfJFGsAbKZQg4MtBblgN/OYSe9OZC8COMCY9d7KkE7U9r2Iv5TSAQAA///s3dEJwDAIBUBH68CFjNDV+uMAAf0I5m6FgBjiiz7VAADoZZgZAAAAAA6RW80NhjGJkDywZb2rNFAEBzL8CQ1ym7aPNbiZABlAEwFublYNckGn7G/VY3Y9eS9SxwCGyt7gc74MVHvbiIgfAAD//+zd0Q2AIAxAwY7mCqj7OBqjaUhcQOGDlLslIMArhmoAAAzkAQoAAAAATEV8SSoieeAjg3jIZCtnEYjAGH7VZnX1DcEB+KEFWuXYbwE3C3PewjREs3S42npu6CBALvYGJNd3txERDwAAAP//7N3hCYAgEIDRG61GEFqzWjE4XEAUSntvBP/doZ+iGgAAg93ntTtTAAAAAHhXOYr4AKtxWRtoUkM8YvCsRDANBvCrNqRNWAOgnQdakOxa+BK7EnpldFBcA2B+5jV+oG8Wi4gHAAD//+zd0Q2AIAxAwY7GwuoKjmZCygBEjIh3I/ADTeAhqgEA8AxhDQAAAAB4Sf5i7iIhS8nH8QC9BHlYSRFOg2HsDyCsAdDFAy2ozmPbRTWYQp5lhRAYobS4htUE+CbzGn9wexaLiAsAAP//7N3hCYAgEAZQR2uFaqEGCpyhyYpI+itUUh3vjSCid4qfQjUAABoohZqDcwAAAAB4h0ANohHkDFyS5+zOimjUefAMewMcOr8yA9R5oAWnxVDwBf04TAI1aGDvj9YyvwD4ibJu69eI7n5QeEppAwAA///s3UENgDAMBdBJw8KS+UERYAFpHCgHEk6MAYH3VLTbb2upBgBAI9MwCjkDAAAAwM1yyZ0gIR8zx1A8wFmXhIzgLXLJgv1QyaEQ2NmuMntLADgQV+sNaMFaR+tHeVzUrZaO0lIfyzX0SAAvF/2auoA/qP/PSCktAAAA///s3UEOgCAMBMD+3K8bw1702oAGZx5BWKCLUg0AgLkUawAAAADAWh54sxvD8EBLinkMTrOTI0VqQI9ftuFOsQbAQwa0rI0wOKflddmvugdjlSsjyUkAHyWv8ScpCu+pqhMAAP//7N3BCQAhDATAlGbnd6WJ4EfwlzsRnSkjYXeVagAA/Mi6CwAAAACsY7WcA709DA+QJfjBaSyvQZKVbZh6eiAB4GotPNsW6gW0YOBOyw7cQ1itKNcA2I9CDS7zzZ87IioAAAD//+zdwQ2AIBAEwCsNSyCxTbUFS/ODD+NPURKYKYEHOZLbRakGAMDHtmWdnDEAAAAA/MIyIb0RggeqKAU9wh/0JOU5WxiF98yfYGGqAAAgAElEQVSbcJcUawAjK4FZ9yBc7bV+RoanhGdp7CzXUNAJ0FApQDQTMJo6b7GIONi7oxMAQQAIoK4otE8LVa7QZkXgR1B/mYW+N8Wl3mVUAwCgDsMaAAAAAPCiOEQPvWnNmkvwAEWkKbmvojXyHzyU5kUZBu4dBYXNn5iB3uRylpwNV8bo+FTOpbIpfzDmbyXnCQCVnQYQZQK6UmzgMISwAwAA///s3cEJwCAMBdCsKLj/LL3k0IuCVKXoe0OEQH4SRzUAADbIBk74GQAAAAAWyC/lggOcRlAbWEFt4SilFgF++E6WAdp8Ygau4Nsx9M1c4oJRrwVa+BPHNQA2ynqrH+BG82bbEfEAAAD//+zdwRGAIAwEQDpn7AdNi35460MQJ+6WwOsGwkWpBgDAS2I/bP8CAAAAgDmqcyWZLVoY1AaGixaGnMlGDoTnFC7Btdo/mgOkZNsx3JKXWU0W5cuUawBM1u+lvIXwV+PmZkopJwAAAP//7N3BDYAgEARASqOFS2hTbdGY3JuPKBFnqiALuxjVAAB4l2ENAAAAABgoWlQPvlmN0jvwMGUQlhItlEvghvx126Ab9NUsiskfgKVkOct5GjqObZfVMo1xNz7EuAbAYFcOlWcBeRS/lfcXY5RSTgAAAP//7NzRCYAwDATQjObmHU0R8l9pq2J8b4hyhdwZ1QAAeJBjFAAAAABYzkEh1Si7A7cy3ENBWw6tAeNkULimKTYCFWQ5a1fOgi45mdco0fJR57hGM0gIMCffUVmAv1v7H4uIAwAA///s3cENgCAQBEBKwxJI7MeK1Bb9nH8VgoHMlACfu8fuKdUAAOjs3I/FmwMAAABAvbIWoWCmI+wOdCIUwmw2Pwrftb72BpPLcYFZqAEYUlyQVxAEz5iT+UXMmuZNRpXvQkJ7E8B7UaxlZ4PW+1hK6QIAAP//7N1RCoAgEAVAj9YVhO5bNyui/fCvQkmUmUOIK763SjUAAPpQrAEAAAAA9YQnmY2QO/CLKPARDGEmS16zT/pQx10Uvtki5AAwhCvUGueWN1V4Z1c+Rw/FZnoYXVmuoVAe4EHMbIdiLbg1n8dSSicAAAD//+zdQQ5AMBAF0F6xifs4EY7A0QSzsLApotK8d4o/k/6poxoAABVEsLNsBwAAAICbcpc9KKQ1S5TcAb6iPE1r5EN4YBpGWRTK7WUHvy8DfxdF1lk5C4rYm1CL40e0ZssffcxOdg8AF04zG3B4fx5LKa0AAAD//+zdzQmAMAwG0K7mCAXHVDuCjiZIDwUPUv8p742QU0LTfI5qAAB8JI1Tp/YAAAAAUC+nkFsApzWWtIFXpSE5Ak9zYh8t5sM1elI4Z0tfVjvgb4qkYx+0oc7yRCoyHMk9pfcvWua4BkAhz2yzmQ127p/HQggrAAAA///s3MENgCAQRcEtzYbVFijNy948CQEMzBRBCOE/UQ0AgLmENQAAAADgOx8KWE3JcTvAaMbTrMY9ERrc52XUAvUO4zDgT3KYJfgDdbyXMFzeIwU12IW4BrC9PAMFteCtT+QwIh4AAAD//+zd0QnAIAwFQFcUum/pZiWQzxZKRQJ6N4I/Rs2LhmoAABTKIk+jNAAAAAB8lL+PaypgNZq0gRI50MdbFUvpRxcchDFqUxgT4bAzfhq1jkCFCGZFSNUdKvw3K8AFb7J2NCiUHRmuAWwn9v08s9n74dk1ZV1aazcAAAD//+zc3QmAIBgFUEerEYTWNEeo0SKw14h+FOycFQQ/Fe9VqgEA0FhO82gNAAAAAOAyHwvozVpC7QCtCE/TmyFOUYAQ7nM2hef2ObQo1wBqEsyC13gnoapyXlQQyt8d5RruUEDX9n3O3IdzOc3flG2FEDYAAAD//+zd0QmAMAwFwKxYcP9ZRIj0SwVpUMLdEC2kfS9KNQAA/kGxBgAAAAA8GNuwpYiOfNIGPpXFPgLUdCNICC/lVm73AqxxlmuYZwBlskxDMAsWqQxwwQUzDJgUFAItHbOhLEF0tsG9ureJiNgBAAD//+zd2wmAMAwF0IzmwEJXcDP9SX8URKT1Uc4ZIiSQ3AjVAAD4AEspAAAAAHAuv41bLGQ0Sx6zA7yqzEUAPKOZsn8E7hH8Bm3Vr8uOdIFmdmEael9oQx/Mo7KOq+FwVMM1zFHAr+Xcttp1gcv6zWQRsQEAAP//7N3BCcAgEATAa82C1RZDwFdAkKDByEwRJ6K7p1QDAGATNZekWAMAAAAAunwy4DhC7MBmBEc4jU3d8JLFILCMcg1gijZHBLFhspqLM5rP3CFbcxyGuEcBv/MoQQQGtbeJNSLiAgAA///s3cEJwCAMAEBXFDpmwRG6WhHSjz8FS5C7GTQkkkRLNQAActGsCAAAAACD+GVcYyGn8R4MpNLupimZ49SrOtewTr4K+xgKA5b0uOGXY9hG/stvYqGGIVuY89VRT9whgHSGZRpiFczZW5OVUl4AAAD//+zd0Q2AIAxAwW7uROqKJqY//oGmpiF3SxCgPEQ1AAAayaKag3kAAAAAeDIkznI8Xgeack/FarYMtAGTcn6h9Fc4QFwDGCOmAfXO/bAe8ydBDXjvjtLYSwGdiGnAd+V7soi4AAAA///s3UEKwCAMBMD8/9VSCHrordUoMvMET1Gyq1INAIDD5BBoMQUAAAAAxu/ilg64jdA6cCSFP1xK8BC+M7dCDeUawEuGspRpQA1zL2UycAvM0e9Sz+zkTIEd8j1HmQb8sz5HGRENAAD//+zd2wmAMAwAwIzmCgXXVEfQ0aSICH5KDaXcTZF3HNUAAOiTAj0AAAAAXAyMMxxL60Dn9KkYzVTmYpgVPtiW9fAUBFI5rgG8PxyrjUKCjI/IEM/SrRoFtFdjpr3GUPIpIMOdtzmCCM3835+OiBMAAP//7N3BCcAwCAVQR2tHCHTfrtaLvfRYUELy3gohoOFrLNUAAJhQBlMEFgEAAADY2riG37pY0elUgZnl4h8D1KxGqBX+k12Afu9yjdtvy7CPzzINdx/6qHdpkXWd9wmodeingEr6NqiRc5S1IuIBAAD//+zdgQmAIBAFUEdzBaExA1dosyK4FijUsvd2EDy9+ydUAwDgpSL5WsMiAAAAAL8U28Q1ITCbra7Vuy/wBQZKmE0uS7GlEm6IZlZ3WBgj27YM8zvPd2w3NpQFA0SvLjQVg/2C5KGvq57a1VPAU8I0oKk+/9IppQMAAP//7N3BDYAgDABAHg7mCqj7GDbTzQyGAYyJIHq3AgmlhZbBOgIAvFqScAEAAADwU37r4os0qQNdyAOA4hI391R8TD5fekAP93i7AG2dg0fjPOVYljT/Qv9Kc/WoBgrNqddSi/0e2lpLPpVr3rucCriqDOURx+FB1eJyCOEAAAD//+zd0QmAIBAAUGkyVxDcp9Fqs0K4j/6CILN6bwVRPO/OmywkAMC4YuKLR3sAAAAAfqXUkjVs8UFra1K3sMCLyFHxOaUWBfNwQdQuuMvCGOaYtLyYtgzv0/btYbqxxix4mKZqeohzX84LxpDFVMCZ9glixG6buA1u1y/vkFLaAQAA///s3UEOQDAQBdAu3MsZivtIT8bRpHRjKyGD965QMenI/zrnCQAQW13a53HoLVQBAAAA+JHFYfNBwunAq9QioDzl1TcqPmauz7WiK7ikmAkQyl5I2v62XPYix6MABwimBrJaEMschVjsa7ldC+x7/0NM7lTASZvbslvwrOfuZSmlDQAA///s3cENgCAQBEBKswW1IGLnhISHFiAcMFMBv8sF2BWqAQAwB49TAAAAANiC9nAW5fMuMCt3VKwo926+ghXUjyXnfQlbgphya1uuh3u07sN4LUjj0GoMcZmX/O0VqgTE99mpBGzAPuxuMFTfeZtSKgAAAP//7N3RCYAgFAVQN8sVXrlPNFm4WQhO0IdlnbOA4I948V2VagAATKA/Tjlc1AAAAAD4ARkYX+TXQ2BKrRAoShig5mtylMgKr+AWZUvwfnv/abmdc9XAMIxjGAumIq9lhNMuw5QUbMAPxLa2vGSRdcKj6tDVU0oXAAAA///s3bENgDAMBMCsxggmLMQ+SIwIAkFDRxGEo7sVUliR8x+lGgAASRxL7qijSxsAAAAA3YopPDCkR7PQLpDZuqxDTLE5RDpzh42BF64PQZQtQQ5nuF/BBrSlSANyMhNpLepo3wV9eBZsmCGQmCIN+JfPZ2opZQcAAP//7N3dDUAwGAXQjsYIxUDsg64oxINXEaJfzlmhD/2/V6gGAEBdtL4AAAAAENLeFu7si4jKXDyuAyKYfBIjmCYPeTRPw31lWdvcd8KWoC7XgI2kbRmeEaQB1ZsMIW86AzXcd0E8x9pPcCHURZAG/Nb3+7KU0gYAAP//7N3BCQAhDATAtChc/7UcHj78eiCaMFODEJR1o1QDACCRsfVFaBEAAACAirx5UZGANlBCLx5oTzOrqaafacF3+EduAXKzbRkWjY9YYf5BfmYeO03FS0Btc3HhV7ChuBDuoUgD7nfkXhYRLwAAAP//7N3LDYAgDABQVnOEKgO5masZEzwYTx4Iob43AhzaJv1YqgEAMJkrcYxtVeABAAAAkEbU0GRISq7fA8kYoCadqLGL1/Bd61sQEyCH17Vlw2DwGIrWpwe5LP6TXlrsODww/M6dN1pcCIOo32A6Y47TlFJOAAAA///s3MENgCAQBEBaPKUfYz8mtGBpxocffz6QADNNXDhuV6kGAECfdo89AAAAAAbiyJARNTsEAKjhLh6IHALUjGaLHGc5iuAwfKdsCcbzDoMp2WAaQlgwBfOM2vx1AUlxIfwj1uUprrGfhP60mYkppQsAAP//7N3BDcAgCAVQVlQH6modrSHpscc2BvreCh4MCh+hGgAABeWjylhTgwoAAAAA5eV2cKdIQ6et90BT/qfo6NjZwAdV5cbVe0AE6EvIBm0J0YBfEoLMZ8aaAjWAJ2oqeIkaDtrYdwdGxAUAAP//7N1BCoAgEAVQj2ZHEDxm4BXDcNEmsEWU+t4ZBB38M2OoBgDAoFpARUEIAAAAwLBSTlFjLpMS0AamVAcGpZz8TzGbWN+lZS+C7PDcZhszLOWuIezMMTkK/Nlli7F6BtakeZnXtDvG3QL0MGQDOhmiAdP6LksTQjgAAAD//+zcQQqAIBAFUDtidaJu5tFCUGjRIgWR9L0ruBCd+V+pBgDAv10eiAAAdR4LUwDAR5bi6UihBjOKQrnA5MynmFEqBdicLNRJgY/9PKJ7AZZVAi5p/lb+eBRtMJwCDeCFEmS6yIFfsy6glZINyJRowBLG3m8hhBsAAP//7N3RCYAgFAVQVxQcqPYJGqHVQjCQvhKsyM4Zwa+e3ndTqgEA8GEloDK7kAUAaOLbCQDaCcDTXf4buDAEgxLQBoaWi4NiihaoGU5McVqX1ewD7ZQtATVFGzxKgQZwgcVkblGWfzenC3R0LtkIx7ujWYrRVLOcPC/8x7tZmhDCDgAA///s3cENgCAMBdCu5gjqQE6kruBoBuPBg9Fw0Ai+NwIkkJT2I1QDAKBwqUDS9p1HQQAAAABKozmCGi1p2NzOAj9ggJoaDQIFId/+GYiwJeDKWdBGHBvpDYhx5zBwFeqKQI55nBoLxkPcR8AbtrNGaCElE4YIfCLsMCJWAAAA///s3cEJhDAQBdCUti1MYpmCJVjaLrmIiBdBNxrfKyGXISH/j1INAIA++LgIAAAAwGPULeDes+hU880aAP9QC4RiCAFquhNDzNM4CVzBQTWoGCV/nRtw0BJE3ZRtLCGxJCj2KpviDGEr4Azea7lElDybU0Aje6WFija4hSj5s5qP7nTAWvu7WUrpBwAA///s3cEJwCAQBMArzRaENJTOLC0IPoKEPEKEaGZauMehuKtSDQCABbSfX3atxwAAAABMwj0WKyo1ZG6ywI8ofWdFKW852enwiDcLwFvOIZy+cCP6R/hCY/PoSjNCyAoYzY5ghLbP7C/gS66KNuJ0dio1b2JivKk737kTBO58Yw9FxAEAAP//7N1LCoQwDADQXjHqfbya3mwo2MWMH3DAX31v111XgaRpYqgGAEAlcvE/2sZDIwAAAAC3Fl1oYqVKttoDb5OHDkQXg7cpKtRP2x2BHaaeBQ30wBm+Ys1K7Jltv/Sx+jgLwzKSgRnADajXcpTB52HgIUqs6qNtyo1zDBvLQZ7Elp9cT44H/GtWp7tESukDAAD//+zdQQ6DIBAFUI7GFYDet0ermZ3a2sREG6Dvbd2hCweYP0I1AADmYiIYAAAAAN2Kqd8uGjKpbi4BAPxSBAqVR3lZdCaT4781gmO8WDgtGheflg3owNv+05fgn01T2afn/zLV+SAcY82+HjAKE/m5TXxbpVW1DzCqvO432dVJm/NOgRvzK63mXf+R4Azgav3UZimlBQAA///s3cENgCAMBVAc3X1MWMHRjAkHRRP1oGJ9bwUutLQfoRoAAIGURm3vARMAAACARulbEVIesqEy4M+8TRHRvBjTOVm4pswsjIbvgY+pl4hqy1+dzzgK6XiSezrwV0KQuZVgDSCoVf1QBW5s6hyhG23bCcxIQjOAF7RTm6WUJgAAAP//7N3RDYAgDEDBrlhlINnM0Qy/Gn6MiQTutmgDr6IaAACTacuJ3DfDLgAAAABDade+7ayYlAfawNJaWChL+qzHdLLkIZwFr1SzH7A4OzCAf9WRLiEzL2ENYDGPOecW3YheYFB84zudUEaIZQCDOoeazSLiAgAA///s3dEJgDAMBcCsqE7k5qLoR6GgUtAQ7mYopJS+F6UaAAA1+aQCAAAAQDbCtpQkbAtwWM16CtrPtDkPL53BMnMBAIBfCO7yJcUaAI1u4UOnfONyt7ggXRh71LTMT+4p3tSAKnItqImIDQAA///s3dEJgCAQBmBXa4Qr92mhoBGizUJ6rwwKke8bwJd7EE/vV6gGAECHPFIBAAAAoCXll28hsHRqUFiAM2AocriXojuRY1uX1X4Plcog48XABAAAfMX5jd8J1gB47a53NMc01q5dQjj2D0ui3wXwTHvBSCmlAwAA///s3cEJgEAMBMB0Zlo4sEzhWrjSRLACBYlhpok8kt0o1QAAaOo+UtmEFQAAAAAowHEJHa15zFbfkQBeUvhORzn2kWY+PCJUBgDAl9p9s+c/FGsAlJHyMwAlXHvjWiLiBAAA///s3dEJgDAMBcDg5A6kZkURMoEfpsS7FVIoKenL5mwAAMyV5yV1GwAAAIBWz3ZvFWCoJYcAALrkkXttgYNphMXAC/Wh0b0AAMBXvNfSqnogc9sAAPzdmoGHEXEDAAD//+zdsQ0AIAgEQEZzNTdzNGNiaWOjBu+mIJDnPdUAAMjPghYAAACAK0artyYYkmoa6wGWBFjIqMy5FtikCAQAgEPqq6Et/uKxBgAAPHovjogOAAD//+zdsQ1AIQgFQEZ3IXUEV7P55a9MjAbvRoCGhPAQqgEAkJzvLwAAAAAc5Ks3WTkaB/jxBQ7ZS5HR0FVYZnYGAGCrXltRYW4hWAMAgIfdG3gYERMAAP//7N2xCQAgDATArBhwYEezSWklKKJ3U6TI/yvVAAD4gPUXAAAAAE6rNW+L3ryoV2gcgDnhaZ6ULYW0YEEFHN3PAADs4j+W6yjWAADgR1cXHkbEAAAA///s3bENACAIBEA2dzVHs7E2sdAQuJuCQP5RqgEA0IflLAAAAAA/+eZNVcLiAAe7eEh4morGLo4D7pmhAQB4YWb+gkxvijUAAGgm9x0gIhYAAAD//+zdwQkAIQwEwHQuFqS26Cdv4eAE0ZkWfARishGqAQDwiGzO+jwAAAAAYDtXvLlYzWVxANYsT3Or4mXhu5xXUBsAAPjVaF1gAUcTrAEAwCtG62fPikXEBAAA///s3NENABEQQMEtTQsSZUq0eD8KIBFxzLTgwybWE9UAAHiIBwQAAAAANvHZkCu12gRjAAb0AJEIETdKueTkZGFeX6h1NwAAsIp9WH5BWAMAgAecP+9GxAcAAP//7N27DcAgDAVAr4iUMZEYIRmNhgVAUODcjeDKH+lZqAYAwP9YzAIAAABwTHnKq7ok5bM2wIRWm5sUWQmQg3V6agAAdvhGUAFcQbAGAACJ3TGfRUQHAAD//+zdyxGAMAgFQEqzhcxYkAWptOiFBvxcgrstcAgTkodQDQCAn6lG1TABAAAAgM/V1m6bu2kp99xUFuA2n6fpaBnr0BfAA/VewdkAAMAreZzCCZiOYA0AAJqa484/Ii4AAAD//+zdwQ0AIQgEQEq3IbWFK82PFWhMlJupYhNgUaoBAPBDBgoAAAAAHOJrN1k5/ANYoJCIxOReWNRrKx6BAACwwf4rz1KsAQBAMt/MuPeLiAEAAP//7N2xDUAhCAVARnMFEgd2NGP/K7+NeDcCDYSEh1ANAIB3WcoCAAAAcEz2bOtrt4pS0HAUDvCLYCJKyp7mA9inNwAAsOOqgy34IlgDAIAqrnr6HRETAAD//+zcuREAIAgEQDq3NFszITVwNAF3SyBieE6oBgDAp3Ioa7kAAAAAwCtTJWnKwx/ABcFENDYyWA44lPcK+mwAAI5Ue9iCHcEaAAA0UGvGHxELAAD//+zdyxGAMAgFQKxcCzKhhZTmpAQ/l+BuC7nABB5CNQAAfswHAwAAAABfcKWbwkaeKZwY4D2L01S1e1l4Jls/HAIBAOAG866UMoM1svVNXwQAwIJmLbvWrFhEXAAAAP//7N3RCQAgCAVAR2vgwBUjcICIfpK7GfwQ5amjGgAAWDQAAAAAcK2+cwsT0pUQOMADOVNwmq5G9cPAHf02AAAndmDLXIGW6kGi+gYA4Cf/zfYjYgEAAP//7NyxDQAgCABB9p/FxBUczYbagtiId0toQF9UAwDgc7loMIwFAAAAoEpQg67WHNPsFOAeH6fpyn0YivK9gvMBAICjjA5AW8IaAAA85M3oYURsAAAA///s3bERQBEQBcArTQtmFKQhtCgRC8xP+LstXHAB751SDQAAPDgAAAAAcGRd5XaZm1cJ9wF8aBUVCQfwopRLriYLZ0br1X4AAGDD/1Z+QbEGAAA3uDaDGBETAAD//+zduREAIAgEQFq3cxMNDXwCYXarYGC4E6oBAMDk8AAAAADALq3cVNXG8zcAbwksoipzMVxQBAIAwELaBmQ4IVgDAIDP5d3lR0QHAAD//+zdwQmAMAxA0YzmwIWs4GhCycFjKQga3xuhp5LAj6gGAABTLR4MYgEAAABYUte4D69FRznStXmAB1SwyD6Klup/DOwT1gAA4O4UX+OPhDUAAHipb0cPI+ICAAD//+zduwkAIQwA0KwouI/c5jZiYadw4Oe9FYIpEpNYqgEAQKcBAQAAAMAE17i51SeyAL+SZ7lVSTlZOgeLHAIBAGCgfsCz2n9ubwAAgG0cP3MYERUAAP//7N2xEYAgEETRK137QbdFEyMCEsYZYd6rgZD7K6oBAEBPWAMAAACAISvc7Cwt3jfAh9LiaJqdCc/BBIvMAAC8ztUXkGFWrvvwpxsAgJ9YP/hWVQ8AAAD//+zdsQ1AIQgFQEZz4J+4gqP9hsbGwkITvJsCCPA81QAAYCL9BQAAAICVTN92LEhVkt8ADuhfdxBAVS3rZWCfmhwA4G0jnwnA83Kn2xwNAICbavRoEfEDAAD//+zdsQ0AIAgEQPafxcQRXM3GxmhloQnerUBFeMBRDQAAFuP7CwAAAADsOKhBWrVUYW2AeyxNk1VTWThnaQwA4G/yqzDTIwEA8FiOmW5EdAAAAP//7N2xCcAwDARArSjIQt4so6VRE4irgE2UuxGMCvOgl1INAABmBLAAAAAA3NTVbZe36UomCrCQIiM6yyPNN7xQS2OnNwQA+B0ZLTxQrAEAwCaj/qLfFxEXAAAA///s3cEJgDAMBdB0cheyZgVHk4In6U3pIb43QqGQlCbfUg0AAKZ8UgEAAABgQuo2VZ25p/dQgPXKJBvBw+ZA4J07oVyNDgDwH6WGteBr435kP5o+CQCARUb9WWeJfERcAAAA///s3bEJACAMBMCsKDim4Io2tlaiQryb4gnJR6kGAABLc0kFAAAAAHzbJjtH3QAP9NblC9IqtSikg31yOgDAH9Ida8EpCggBALgk13w+IgYAAAD//+zdwQkAIQwEwJSmJQiWeWALV9p9/IvCIYSZFnwEYtgVqgEAwIpgDQAAAABC2zaJveMZDlAB7vEXRVal9Va8LpybTeXmBABAcgrgYI9gDQAAflbnfj6PiPgAAAD//+zdsQkAIAxFwb//VI5mk9pCESHeTRGivIhqAACwVEOwxSsAAADAx1zZpjnXrwEeqrCRtyi6EqaDQ/4sAAC0J6gBG4Q1AAC4ZHQMaiTJBAAA///s3bENwDAIBEBG82rezKOloXeRyJHed1OAxD9KNQAA2NICDgAAAHCv/q7twzapVoe5AfiXgiNSjZ6ngReExQAAYs3UsBac0LuSG28AAD4TmyGsqgcAAP//7N3RCQAgCAVAR2+goBFaLYIGCOoj7G4Ff0TxKVQDAIBdhq4AAAAAf/Jdm7RabeaeAA9YAUeOaMiqqyxcIYAJACCX+f24qCmcWcE0dh0AANyQt6+MiAEAAP//7N3RCcAgDATQrCh0oW7maP3JAIJFyvW9IYKKl7NUAwCAJf3o6jMjAAAAwI90q7ZmbVIJ5QF8i7lMrHENQTHYJCgGABBlJrcfw2nuSwAAvODuc2WmqnoAAAD//+zd0Q2AIAwFwDq5C4FdkZA4AFE/tN6t0J9SykOoBgAAy1xiAAAAAPyOX7UpK1t63ArwItlSwDuV7aoL950LvUKYAAC+T08HD5vnpezHZr4GAMAFs5esvUMTEQMAAP//7N3BDQAgCAQwVnMEE/efxQ8LmJio2O4gH+FOqAYAAKsEawAAAAB8QJs2xVnaBriT+UxZfXSBdbBBLvY6EgMAeFer3n4MJ2WBojcGAMCK+n+0ERJOxzAAACAASURBVDHZu6MTgEEYCoAZzRUEF+o+QlZ0hiCFVu9WyFcIeU+oBgAAJZpfAAAAAK6hTZtj5UyhMQAflDPdoThZ66M3E4Z9nsQAAH7rEagB77MzAQBQcEfwYUQsAAAA///s3cEJACAMA8DuP5WjidC3IIhovdsi0KRGNQAAWObzCwAAAEBtvmhTnLI2wMUMH1Gc4TrYJEtiAAC8o+XtKXBAZia5CQCAmZHT/ugHRkQHAAD//+zdwQkAIAgFUEdr9Ebr4rFTRKC9t4OQ2FdLNQAAOOXjOQAAAEBDeT3bBW26msLaACWYQ9HVyPc2cIeAGABADdNSNHgvA5JqDwCAnb/6tIhYAAAA///s3bENACAIBED2X8rVbCwsjTExwN0KVBB4hGoAAHBlDVotNAIAAADU43s2lZlpAiQgAInihgLDGw7EAAByEKgB/2x9U5sP5AAAHOm1PxMREwAA///s3QEJgEAMBdBVM8KBgQykXgWjyWAJRFDP91Jsf/CnVAMAgMv6ti9CVgAAAIBxtLll3uNzNqM6+trlmQDfoQiJYdXcDdzAQxAAgNdTqAEPy72pym3cSAAASFNl6/8REScAAAD//+zd0QkAIAgFQFcM2qeFglaMZqiPsrsV/FL0KVQDAIBdllMAAAAA8mhqSWJmmQAPGX0IHSCzVmoRZgeHeAgCAHCtLw+14FaCNQAAWLszX/ZpETEBAAD//+zdQREAIAgEQPpnccYKRPNjA30o7LaAgTuhGgAAHNH6AgAAAFCDtmyKyzmmQ1GA/2izpTKBdnCR5zAAgOe0fdSCl+3Zyc4NAKCn3CHV/UTEAgAA///s3UERACAIRUGi2T+Vl99ADyK7KRwZHqIaAAAcc/UFAAAAoLdcybbUx8+EgQEaShDJDIpfrbzDgUuENQAAnjF6UQtel+CNsAYAwDD5Q5+pqjYAAAD//+zcgQ3AIAgEQBy9A6krdLSmiSOYGORuCSDAC9UAAGAXR+kAAAAAeQnU4GbPesoGICc7KG6mD4f91A0AgLPe6o9akMEfrDH7aIIJAQDKqD2nRcQHAAD//+zd0QnAMAgFQEdLRwh0zEBWzI8jBIr2bgdBRN4TqgEAwBWZWuw5BQAAAKCYbMfWkE1be22NiACFZTCS5366GvOddhW4SOMyAMCnBGpAMTmzbm8AAL09eTv/r4g4AAAA///s3cEJACAMBMErXQtSW/RjCYIYZnowSB4bUQ0AAK5ZYzaLVQAAAIDvuI5NZULAADWY51TmPw6XCWsAALwhqAF/Om/X/g0AoKYuqJEkyQYAAP//7N3BCQAgDAPAjubAQldwND8dQQTr3QoihD4SpRoAAJzmqAoAAADwiFrFHt6LrnKm5XeABnLmUuxOZ5XLgYMUawAAXCd7wcNqWNE/BgDoZVXO+15ExAYAAP//7N2BCcAgDADBdLSOIHQfJ6quKEK7gQiGux0UCfIR1QAAYKnvY4qwBgAAAMAZbMUmM3NKgFzc62RWy1PE7mAxYQ0AgG1um4/hfPMc97dd4rYAACnMt535+C8iBgAAAP//7N2xDQAgCABB9p/FhBVtqKwlUXI3gzZEXlENAACuq4qdgSoAAADAw/yGzXS50hkHGCRXCrszneAdNKjlTu8XAAD6CGrAMLV86V4DAHxMUOMQERsAAP//7N2xDQAgCARARnP/qWyorCXRz90UEOARqgEAwBRLjQAAAACP6i/YjvZIZjkAIJDAJMKtrtOByxyEAQCMEagBobqPMmsBAPiTOu5UVRsAAP//7NyxCQAgDADB7D+L4AqOZpPS0oCGux0EQ/RFNQAAKJGLEmENAAAAgDcJatDZmmN6yA3Ql/0TnbmnQxFhDQCA6wQ1oLk84z5kAgD8xax2EhEbAAD//+zdywmAMAwA0LiZKxQcqAPZZkURvHqzoPW9FZIcAvk4qgEAwDDZejWUAgAAAPAu1/drH7CZmWVrgInlnlV8mdhatiLHYRCHNQAAHmNJC37irPVsfdFLAQB8gl7tTkQcAAAA///s3MsJACEMBcB0vtiPYAlraV48exFB4kwLOeX3hGoAAHCaA3YAAACAu/zqQWK91eZAACA/+ycy+1QXzhGsAQCwrXvSgvfMXspMDgDgXkWvthARAwAA///s3bEJwDAMBECtaMiYSbSCRwsBtWkCBmPfDSGeL15GNQAAGKoCuRIVAAAAYAK+XrMBXSTABvJMmYaltaMZwoOBDGsAAPzWK0sBG8rrfjs5NwAAYD69shpfIuIBAAD//+zd0QmAMAwFwLhZVyg4ppoVOlpBHEA/ilLvVshPEsKLUA0AAIa7GnMHKQAAAADv8/WambXc0h4S4D8c8DOzUtdaVBjGEawBAPCYQA3gfLaY+7GYpwAAPsOsdkdEdAAAAP//7N2xCQAwCARA958l4IppbNKlSQLmbghBeF+lGgAA3OJDJAAAAMBDvl3TXY4UEgD4SBUpCe/TmUI8OEyxBgDANkdawKJmgmw4AMBbdrVdETEBAAD//+zd0QnAIAwFwDeao3Uh2xWL4KdQ/GgFezdESAJ5EaoBAMAnWjKx5SkAAADAGv3LtU/X7MzuEeCf1H92VnofD7xIsAYAwCNHWsDQVc8jifoAALCGWW1GkhsAAP//7N25DYAwDABAszkDBTwCjIYi0YJEERfhbgVX/h3VAACgzF08NYwCAAAAUM+Xa6aWLVcRBvifbHnqPTG5Q4BhPIc1AAAeWdICXvWni7nti5wKAKCUXO2riLgAAAD//+zdsQkAIAwEwKwYcP9ZbOxsRDBFvBvCYCD/QjUAAKimMQwAAACg0Gq31nBNZ3aOAH8zB2gtRwoPgwKCNQAANo60gGPrvbCnAwB4z1/tRkRMAAAA///s3cEJgDAQBMDr3Iai24KlST7+FbxHnGnhIJAcu1GqAQBAq9lI7NEUAAAAoJXfrVlaRgRNAX4sI6cQNIvbDBh6KNYAALgJaQGPZT/mvsbZAQDwHXe1t6rqAgAA///s3dENABAMBcAaUWJNrCgSE0j44G6JRluvQjUAALhuNU0togAAAAAc5qo1HxDgC0CoB7wulywoDy4RrAEA4JMWsG8eX+y1Je8qAIAjzER3RcQAAAD//+zd0QnAIAxAwYxmRxA6ppAVHK0UnKDYCvZuBD9CIPAU1QAAYBWLPAAAAMCL6lmLX63ZXM+WwjEARLbsbk9sroz9HviAsAYA8GOCGsAUY5aYJwAA8xx3wMx7PhQRFwAAAP//7NzJCQAwCABBW0/n+UgaMAfEmSpUZEU1AAB4Igd5z40AAAAA5whq8Dv3RQAWoSUaMN/DRcIaAEBDQ1AD2Cl/xe1WAAB1ghpVETEBAAD//+zdwQmAQAwEwJSmnVmQmhYsTYS8fEpQOGequCyXjVINAAA+k9u+CEoBAAAA+tUVa5esGdmRa8oWAbhTuMTIpnrnAy9RrAEA/Mhc/zkBWl3LnzVbye0AAJ5RqNEhIk4AAAD//+zduwkAIAwFwKzmvoIjuJqNnZXgB/RuhKRK4CWOagAAcJslKQAAAMB6vljzOntFAAYlFwEgXld1GM4S/gIAPiCgBWzXD/cklQYAmGJeWyUiGgAAAP//7N3BCcAgDAXQdEShY7Z1BUcrgtf2JArhvRE8SKL56lENAAC2GsW9Q1IAAACAScpZ+lCaH6zJrNWrGhoA4IvgM6mNeh9YSPgLAEhMQAtYpu839X6Ofs9j1QEAfjX92mQR8QIAAP//7N2xDcAwCARAVstkXigxK1qW0rqzhITuRqB6Ch6lGgAAlPtDvqAPAAAAcMcwR5pzLA3AUb6pcIDu5H0o4GEIANCQAy2gRH7zsV8BABztIjL72m0RsQAAAP//7N3JCYBADADAWOKCDdmPmhK0NBH8+NqHeLDOtBDII6ejGgAAfMJRIAUAAADgAl+r+YEhxzQ4AECNvhNNK31ZRBie57AGANAQC1rAq/YclNPcecoIAHCy2q+7SURsAAAA///s3dEJwCAMQMGM5gpCxxRcsSD5LwiKlbspIiRPUQ0AAE5i8AcAAACYVJ9a/FrN7XrrwjEAfMoAk4V8blZy/gc2E9YAAH5uHLELagCnyKNRbywAAEGNtSLiBQAA///s3dEJACAIBcC3epv30wIFkcndCn6oiOqoBgAAZaxBjWENAAAAwBkHNehuiDAAG+QNulP/wyM+KgMAn7KgBZSkxwIA0K9dl2QCAAD//+zd0QnAIAwFwIzWFYQO1IGErNifDKA/rbV3KwQ0AX0RqgEAwFIMAQAAAADzaku1TdVsLXteKgzAqOwpzJ3dHe1s+iN4Ub1vcNcAAF/ggxawvDqnBOUCAH9jXntCRNwAAAD//+zdwRFAEQwE0JROQWjRRQMc/I/3msjsTLJRqgEAwB8JAwAAAABzfKnmdpYoAVhhfnA7OQA+plgDADhAdqAFnKKVmsYeuZwFALxAocYuEdEBAAD//+zd0Q2AMAgFQEbTfaus2JgwgP5oJXcj9I/wynNUAwCA5eRxag4DAAAAuKnaqTfvRWc5Ugs7AI/lSDsn2qt5APhQhZ4FnwGAFe31QR3gN64cec1ZDuYCAJ05gPimiJgAAAD//+zdywkAIQxAwbRmCYL92LqXFLCw4CfMVGGCvIhqAABwJYMBAAAAwGeuU1OdXSEAf/h8T3Wzjy6yB4fl8RCzCwBwk5ZvFIAnZRSoieYCAAUJIO4WEQsAAP//7N2xCQAhDAXQrCg45oEj6GgiWFx1xTVKeG8Ei0jg86NUAwCAmwmcAAAAAHwotXTvQ3KjPU1YEoDf9j+iWIPsFO3BBV7FGnYYAOCkoVADyGLNsn2oUaYcAMjCvnZCREwAAAD//+zdsQnAMAwEQGWzDBzQioagIkW6FIrF3RR+0Pt9qgEAwG9VSBAUAAAAAF7UGrVFaqZTggbgs7zS0hPTnZUPgGaPwpdbBwCgw/0WUdACpqmsdchaAMDm5LUuEbEAAAD//+zdwQkAIAwEwbRuP4ItWJog/vwKapgpIiAcq6gGAABPW2MTAAAAAHZ+oya73mozJgDgFKEmsvM+gIcIawAAFxR7SyC7defcOgDgNzMQJqhxUUQMAAAA///s3cEJwCAQBMArLS0IKciCArZgaeHARwoIQc1MCeJHYXeVagAAsAKfnwAAAAAPY4XaEjW7E34G4DXtatVpsrmjnMU9h4kIewEAH8q1Y+8B4BcyjJqhVEWGAMAiugLECUTEDQAA///s3dEJwCAMQMGs5mSl+wiOUEfzR2gHqBD0bgQFP0J4imoAAJDeLPEZfAIAAAC8HmfB5nqrzUwQgL8JNrG7yw1DLnPfwcI0ALBS8dsxcKJPyNAbCABkdQtqJBERAwAA///s3YENwCAIBEBWc18TVjS2HUETrHdT8JA8SjUAADiCEAEAAADw8n2aG2RP+0AAlsue5ih+T16AenxRBgA2eWYMhRrAzb681ZTpAgAFzQJEN5sqImIAAAD//+zdwQ2AQAgEQErTEkjsx9Ys7T48rgBNkMy0wIcEWIRqAADwJxbpAQAAAHyfZj6LjwB8ybyJ6e688lBl6MehFwDwIt+OATZ1sHoKMwQAGngqUENf0klELAAAAP//7N1BCoAgEAXQuaLQMYU5QleLxIWLVkFk+d4V3PgZ/aNUAwCAz+iBQqgAAAAAllW2sjt9/i5r2tQBwGOypnkTK1DEB5MaPnoBANxl2zHAhfOdeS8ckrkAgLe0+4hCjQlFxAEAAP//7N2xCcAwDARAZbOs5s0DRkWqgBsjK3dL2BLoX6gGAABHka4OAAAA/FW2TWucpjutzQDs4L2huzvnB6CgPPS6hDwBAIvmH8JxFsC318xlBwgA7DTcvBUWEQ8AAAD//+zdwRGAMAgEQFqzMwuK0kJK80MB+shMTHarAIYDRzUAAPgjTQYAAACwI9+mWV629GERgOGyZRdkZgP6B5hcLVgLeQEAb3ThLIBv8rrP2jk3BwQARjuq9mBWEfEAAAD//+zdwQnAIAwF0IxmRxA6cEcrQg699CJY1L43RCSSn1iqAQDAcnLTug9OAAAA4DfyyrRL0+xOmAyAL3l32F2pZzXACZN7hLwAAN4cFmoA9Gkz51lD1VEAYIQrezYZt9lFxA0AAP//7NzBCYAwDAXQOLkLFTKCjlYoHopXRVr73go5NKH8r1QDAIAp+SQCAAAAFnMYOD93ZkmhTwA+kyWVuLOC3ZRhfFfIa/MuAQA3bUcQzgJ4rru7FO0CAG9p5V1utklERAUAAP//7N2BCYAwDATArNYRCg5UB7KuWArdQEFS75YIgeRfqAYAAJkJ1gAAAAC2p12an3DECMAXzB+2V48qoA+SWOUiZhMAMJ2KxwDed1+9rftzz68AwBPFzpZMRAwAAAD//+zdwQnAIBAEQEuzBSFlBmzB0kJgG8gjgTMzTegd7qpUAwCAstLmZ6kJAAAAbGsco/tdmh9Y85z2fAB8LueP8DK765krgAIEvACAhLOUbQO85H5/nhCs2QsAeGplZnOHqKa1dgEAAP//7NyxDQAhDAPAsP8qL7Ei4itKKlDI3RSxwDaqAQBAapb9AAAAgMcZ1KACZWYArulfV1SiArkCElkKXj5mA0At8wZoylkAZyzZyzsVALDjvx1ktqQiYgAAAP//7N2xDYAwDARAjwabMVDAK2Q0FCkFFW0U624LW69/pRoAAFSgWAMAAAAoZ65JW5Smup4tBQ4AWE1wnuqOeV8AG/ksJwMA9Z0GxgDWyPu5RqmRHyEA8MPNtruIeAEAAP//7N2BCcAgDATAdHMHKjhCVxMlnUGMdysEDEL4F6oBAMDxMuXP4T0AAABQjTZpbuBAEYDt+tubKXCBz5DhPNmc/LiJAICy1q7XdAyw3wzXyGBDbzIA8PNnqyIiBgAAAP//7N0BCcAwDETRWKuEwgzVz6AWx0ZEdMd7LgLHj6gGAAARFP8AAACAJPOa72jLJ2nSrX1vwwMATiH0RLy+M4Af6k2EXQQAZPHpGOAwHTYc4hoAwLdpcbPlqKoHAAD//+zcwQ0AEBAEwFO5hiRaUJoPiRI4My14XDaya1QDAIBMhBUAAAAgi+olya63rtQJwDXcJT4hZ8DDVrmrKHYBwPPGGtRw0wEudYxrGOIFgP/szObvMJOImAAAAP//7N3BDQAgCAQwVjRxISdzNWPiwxEE2xV8mYNDqQYAAGWckEnQBAAAAKTmejSfMIQIwIsUuFNe6216ZcjtupoMAOSzF7MUagAksZdpT7mhXAsA/jD82YqKiAUAAP//7N2BCcAwCADBdLOsEOiYAVfoaIXiENXcLSEB84pqAADQSi6PAAAAAJS07jVdj+YEsUM8BoDfiR0C7pxg5rsDKCyvJl/mFgCU8c1uH7MAahLXAID2nowg2mXpaozxAgAA///s3cEJACAMBMG0Zml2LoIPS4jnTBNyIBtRDQAAEglrAAAAAK8S1OAHPhwC0Jl3ih/YHRDiHB4Z4hoA0NpwLAwgwxXXsMEAIMfcm00EMVxVLQAAAP//7N2BCUAhCAVA/2YNHLhCo0XgEH27WyIkfU+oBgAA7dQgY5gBAAAAfqXaojVG093KmZo9ALhWzvTPxAtGzR9AA2dHog51BUMBwF3OG/05zALoR8AhALSwKgTRDssLImIDAAD//+zc0QlAIQgFUFdrtCZrtQh68DYI9ZwV/BBFr1ANAABKustKi0oAAAAgk6VaNODJC4AM9Cs6MH9AMff4260EALz3PWYNtQCo6xdwaA4DgHzm6eNCEBuJiA0AAP//7N3BDQAgCAQwVjRxYEfzox8HMArtEoQAh1ANAAAys/AIAAAAfKH15usBFYz1/R8AnrbqlZpFevoQyOc46gIA7nOYBVCMcA0A+MoOQTQfqSYiJgAAAP//7NzBDQAgCAQwHM3JXN0PMxiBdgUeBAgnVAMAgLbyMCVYAwAAAKjgqBID2NUBUIm+xQTmEGgqn7qWfgYAz3jMAhhOuAYAfG8LQRwsIi4AAAD//+zd0QnAIAwFwKwouJCTtaOJENygYOPdCn5I0PeiVAMAgNLykcrAAwAAAByr9fY4HS7w5tZ/APiFvLcEkSnPPAK15Z8JgS4A+JZgFgCbcg0AOM5YBcRmtstFxAQAAP//7N27CcAwDAXAN5pXMGTMgFfIaG5cBdIF8tHdCqpkS09CNQAAqMDAIwAAAPBKfestSVMdCvBGB8DnjH24MEwFbfUlwE+dFroAgPtYzALgknANAHjcsUIQ/feRJJkAAAD//+zdwQ3AIAgFUDqak3U1R2tMiOcmHlrlvRU4GAJ8hWoAAHC8HFpZ2gcAAAD+6FYVCuj52z8A7MiMiQr0JVBAHnRd3jYAWOYwC4DXhGsAwCdGCGITgsgUEQ8AAAD//+zdwQ2AIBAEQOzMFkgsk+RaJCbnyxcfo95MDXwI7K5SDQAASsgHLJchAAAA4DVyDdoiNL8XI6whA/BZMUJIigr2fnRnHYrI/xPCXACw7irTEMwCYJlyDQB4xFmmsSlB5Ka1NgEAAP//7N2xCQAgDATAbO5ormZlZyMoiH+3QoqQQD5CNQAASOLbCgAAAPCSrhoEsJMD4Af6GQmaKkMOx1wAsM2XYwCOMI8BwBUzBFGYBmtVNQAAAP//7N0xCgAgDAPA/v/VLrooOCmCufuElNpEqAYAADH6QsunRwAAAOA5LdCk0O4PwA+8Z6Qwp0Ce6ZgLAFhpOQbgCuEaAHDECNMQgsheVTUAAAD//+zdsQ3AIAwEQLNZVkBinyibZbQ0iIKKCqT4bgVXL8tvpRoAAKTSl1uCEgAAAHCaL9BkoOAWgD9xbEwGd231MmnIpx9zFTkOAIZXmQYAO0zlGjIZAKx7lGmwLCI+AAAA///s3cEJgDAQRcFtMWBD9hNICVqaCMGreFHwz5SwtyzkragGAACJLBwBAACAz7SlbaZPAlf9AfiT0ccu3E4IAUAIdn4cFtcAINx15Th9EAC8a8Y1vMkA4N4qgshjVXUAAAD//+zdsQ0AIQwDwIzG6D8aTUT1FQVI+G6LBGIL1QAAIE6nEFo2AgAAAMd167PmZxL4dA7Ai7wvkWD03AIEc8gFQKAVpqHlGIDbzGQA8OsTpsG2qpoAAAD//+zdwQkAIQwEwPRflaUdSPBxTx8i7kwNwrIEE0s1AACI1CXK8AsAAAA4zdVnEoy+5g8AT+l8k3Ek0FuAyUcuAAJYpgHAtX6dTE4BkGr1Ni+AbVX1AQAA///s3YEJACEMBLCOpiMI7j/L89IRRNAmS5QTe1WqAQBAZT59AAAAAMeMOf6STxefqcC7GwAvM+eooGV+AVjycEm3xAXAQ5RpAHCNLNfochkAxcht7BMRHwAAAP//7N1BCgAgCARA//+qnhaBlzpHkM58QhZWdVQDAIC2MlQpPgIAAACv+PZMByO/+ANASTnnzDo6kF+AzepYWOICoABLWQB868hlOvAAVCW3cV9ETAAAAP//7N2xDQAgCABB3NyF1BVtKG0tlLslzCcgPtUAAKC0vKYisgAAAICrXHmmEAN8AFTgvaMEHQOcWOIC4FGWsgD4RnZZX2M2XQbAR3Qb90TEBgAA///s3bENACEMBLCMBiMgsQ+rMdo3KV6ipgDsJaIDJeeoBgAAeEwEAAAANmq9FS3PPGJmez8AXC3nnf8lXjAyzwAsLHEBcAhLWQBc7ZfLqqJJAA4lt7FfRHwAAAD//+zcsQ3AIBAEwW/NnVEQEi2SfE6EZetmWiA6BCuqAQBAvB5dHngAAAAAtwhqkMIdGwAx1lzDaRPCngGOxDUA+CCfsgCI0uHDp+MathkAf2C38Z6q2gAAAP//7N2xCQAgEAPAH83V3NwmhZ2NiPB3S0jgTZRqAABADjy08wIAAAC3ZdXZsjMdzKz2A0AnjtPpYCTXABwp1wDgAz5lAdBayjX2bOY9BOA3chvvVdUCAAD//+zd0QkAIAgFQFdrtDaPIIg+g8DAuyXkwVMd1QAAgE2pAwAAAHjNV2dK8K0fgIrMPwqRa4ArFrgASNAtZQHAaWWzNmeknjwAH5DbyBMRAwAA///s3TEOgCAMBVAG7yVXKHggvblp1M3FxOjAewkjC0vzgcJk+QEA4JChLHrbXAoDAAAA3hBLZJOlH50ZgUt4AIzM2RIjqJlvPCQDPJUNXDkleqtnvbRPAsDbtqveAAD3zsblHGv0lnVzls8A+JDcxv9KKTsAAAD//+zdsQkAIAwEwOj+QzmaCIK1IiLkboUU4YtPqjEAAMAyg5qLhwAAAMANypWkoFwJQGb2IInIN8CxUeDyHRmAi9osZRXFLADYM3anfAbAI3Ib/4iIDgAA///s3cEJgDAMBdAc3EscoeBC7iN0hK4mIp7spdaD6HsjJKfAJ3+wDgAAuFh83wUAAAB67C3OBshPCNsBwBFAL+bA16U5lbzmyaKBuyrtyB72ANDifKahNAsAOlXus1F+HoAHuNt4p4jYAAAA///s3cEJgDAMBdDoZO0IBccUXMHRREgPXjyoB9H3VughfEj6R08DAABHGd4cAwAAAACXtKkVRyH8xKqdHwAilnnpC+jwdSXzDsBt2Y485OdU5igAZ3q7cXWYBQDPy3xWM6PZoQfgin1+VLmN14qIDQAA///s3cENgCAMAMA+HMwVgIGU0dzMkGB8+DHGmBjuRoBHaSllsjsAAHDVioOpZBN3AQAAgCcM1GAUmuoA4FTdKzGIxeN34E3H78ip5LnHUnUVAKKfObfWx2c1AOA7PfaucjQAbqryNn4hInYAAAD//+zd4QmAQAgG0ButFQ5aqH2CVnC0MOxnQRBE3HtTqKifpxoAAHDN8iMAAADwSKU2mycwgqhUfgAgl83XLfrcQy3IAKbse9SCwNvO5xp1vJWL+IJQAMa0HLNHycYA8Ck9GgA3op5p6Nv4j9baDgAA///s3bEJgEAMBdA4ojpRJpPbTFIIglhYCEreG+FShBT3v1ANUlPXtAAAC09JREFUAAC4UQfevC4pYRcAAAB4YPNYNJEGDQAXAtvpou6eybSBtxztlpqRAdqoj1hDuzEAfNN5RwvYAGgt3W38VkTs7N3hCYAgEAZQbTNHCFpTW6HRQrgfQUT/gvS9FQSPD727xekBAMCzCHymJwIAAACv1m31cMwsDpvJAeAu6qMayRTkH+ALfRlK/7ex15ZjeJU6CzCWfreXvbaiMQsA/iEyWrnkNADGdkRuy3Ibv5ZSOgEAAP//7N3BDYAgDAXQHhzMFZCFdDQ2MyQcMXoyAd5boQfS0uZvKggAAK+kigEAAABfSE1lFRbkAOCZfyVWUfsfC7TAbzrJyOYwAGOqB1nFMRYAjK+952fKx95movo0gHlc+jamEhE3AAAA///s3cEJwCAQBMAjnVmCkIZSWSwtHNwz+A3RmRIUlEWPPewoAADMZfOJQQEAAABgpp/9tkBsYlQLPwDwou5J70psQQ4CvlLNyNmK3Ny7AL9xVbNxM5gFAGvJv/ZyGsAS8vxuld3kNtYSEQ8AAAD//+zd2w2DIBQAUDpZ2xGuupD7mDiCcbIaW74b/TCinLMBfBAu3MfjzBXpFM0Z8gUdAGC3aJvJZDEOpJMntyX+BwC4Pm/r/0UX63uBYjKqMA6j8wAANoguPvaJSrw1XQNKkP8kn/I6AIrSf5v0/oZaAQCVibZ55RhN/ihAudZ4bVbLwu2llBYAAAD//+zdIQ4AIQwEwAr+zfFzAkGcQOAg6UzSF9RUbLbFlgEA4FgTvgAAAAA2hIDIwlcpADjX3IkkUVfoFuCqf/BfwQbAVYo0AIBp3QNjPgUbAE9RpEE+EdEBAAD//+zdwQmAMAwF0K7mCIEu5D6FjKgXrx6KaNW+N0IOhXxI/9AWIU21jKBNDwC44gj0NM9yh1UowV/Z/wEAvk+2fi5qyAqYRrb0FgBAh6ixmReTWLKlo0nglXywAfAIB1kAQBe7GsAQblaYVyllBwAA///s3LEJwDAMBEAVWTDxRN7MoxlBCrcOIQR0N4JcSeb/qD4AAADYkY25Z7uGAx4AAABwU6hBFd1LA8C2rnCYInIvUsAG/NIaFBDaAniVIg0A4DG7GsBn8q9qZBbKyCktIiYAAAD//+zdwQ2AIBAEQErTEk4pU6VFQ+KLH+jDhJkaSGAJtyjVAACATuW81tg3P4sBAADA5CKHx8JMoxzFegeATnX/jBxKNZhCzUfOjMDfGdoCeE2RBgDwuSarLU9Oc68KME6RBrRSSjcAAAD//+zdwQnAIAwF0KzmCEIHcvQiePBUiwdB8h5kAi+GmK9QDQAA2FP8RAsAAAB51ad6yEMmxWkDwDYzJbLo/ZHlSuAaAjYAfrOMBQAcM+4cvdoUsKFfA/gmABFWIuIFAAD//+zcwQ2AIBBFwW1xlTJNKEFKM3jSxItcjGGmCcKHPFENAAAY0Ae7XJdmoAMAAIBpCWowi1a36sM8AAzq52iW9KbEFLLkXrcqyAb8zkNgI2w/wOSENACAz10CGyf3NYAbIQ14IyIOAAAA///s3cENgCAQBMArDUtAbYiC1BI1xg9v/GhupgT43CbsYakGAAAMOrZ9qst8Oj8AAADIpa61KEWSSHPZAPBaMz+SRLnzkqVswJ91RQS/IgOZKGMBAJ8nrwE87zdkNxgQERcAAAD//+zdsQ3AIAwEQK+IlH0yGowWQRqKVKEC341AAUKy/4VqAADAmt60VJ0hAAAApKL5hiyahUgAWNff03KVZribJO65QRRgZ1qRgcNZxgIAtvXxXxOyAZxoBCCO2Y333gP+iogHAAD//+zd0Q2AMAgFQEZzhaoD2X1MuqLpDOpH4W6F/kADD6EaAADwwmxM27EbggQAAIAi2tku/wAU0j02AHymqyMpYpt907iH5UwgHVeRgcVZxgIA0hKKCCQiABH+EBEPAAAA///s3bENgDAMBECvxggB1iSswGYgd/QgBPhuhKSwXnI+SjUAAOCidelDm8bdOQIAAEAJlm6oYstf9d02ANwj52qbm6J2qsjcZOEX+DUPtoAPUKIBAJR1LkUMmQ14N9kNnhARBwAAAP//7N2xDcAgDATAX43R2CcSI2S1iJ4SKQjfjWBXX/itVAMAAPZoSV6zBAAAgHvNb8vWSyHdsgFgu65UgypmfhrPkKGAMhxsAYfw0RgAYEFmAw6iRAP+kOQDAAD//+zdwQmAMAwF0G5mV4hmH+lmjiYFj56kiNj3VsihCfQnlmoAAMAAfZiNbXVdDAAAAH4qMqoPNUyk9Wv6Cg4AY/X3NTKavpJJ7JFx6CuBWQlsAS+xRAMA4IGbma1eOYBFHgAYzBIN+IJSygkAAP//7N3BCYAwEATAa80SovZjRWqJihDFlyhEEDNTQj45wu1GqQYAABQyj1OTunZxngAAAPBLAg9Uw4/iAPCe7Z5NfTJbUoshLwwDVO+iZENgC7hrD2Ip0QAAKCwH3Y93rFPJRtgVAB5SogFfFBErAAAA///s3cEJgDAMBdCMVkcouFD3ETqCq4kHL0E8KYp9b4T2FPj5UaoBAAD3miJi9aYAAADwH3WuxXIDA2k+GwAe1wSxGUTZ56m+dMFhgCQvxLuKDJywiAUA8JJUsqEcEbhyZCzMbvBlEbEBAAD//+zdwQ2AMAgFUFZE3cfVHK3pwcRoj5qovLcCh/KbAJZqAADAjXoIznnafJQBAADArxh4pIx+PV+1AeBZ/b3NJfWYVLEer3wCMHa+ihwGtqCafYHGZekOAADvMOrT5DYoR3aDr4qIBgAA///s3TENACAMRcGPMywA/r2QMCEBmjsLnTr0tRkeAAAAAAAAAAAAAMC7xpr9OtIS6IK/+WQMAFCU0AaUcnY3AQ0oIMkGAAD//+zcQREAIAwDwfh3hTOmPwYFhe66yCMnqgEAAAAAAAAAAAAA8JgrtOGwBT0JaAAADHeENiKSCC3VVlsR0IB/JdkAAAD//+zdsQ0AAAgCMP6/2hfcSLT9ggEwqgEAAAAAAAAAAAAAcIRnZKhQwgIAYM1IItTIbvBRkgEAAP//7NyhEQAgDAPA7L8LsAKjcZiyQBX3r6LrIlJPNQAAAAAAAAAAAAAAPmawBW1qgHXzGnM7LQAAXXQ3aKO7AU+SAwAA///s3DEKACAMA8D8vF8XHQXpWvDuDVkyJE41AAAAAAAAAAAAAAA+dA22tpIDOAywAAAYQ3eDJ90N6CVZAAAA///s3bEBABAMBMCsiIUshBW11CrcdalTfZGPUg0AAAAAAAAAAAAAADap5LrMPiTzovX4Kkbr1ZYBALiNwg0+ILsBZyJiAgAA///s3CEOACAMA8B+fT/HIhAYki3cvaC2onWqAQAAAAAAAAAAAADAtcNoy+kGXdWey/gKAICf6G4MorsB7yRZAAAA///s3bkRACAMAzCvCOy/CzV0ueNppCmcwo5RDQAAAAAAAAAAAAAAjlHc4pHlW3EUrwAAoKyNvmdo9xs3GM0A/kkyAQAA///s3DEKACAMA8D8XPy5uIl0rgh3T2inDIlRDQAAAAAAAAAAAAAAWhXDG1He4jDvYyhdAQDAG8Xwxja8A9kN+EKSBQAA///s3LENwCAMBEDvvwuwAmyGkOgSepzcbfDuvnh7qgEAAAAAAAAAAAAAwLUOA64w4krlMbTaeiu1//04AADwFfpbequfjZcQuhuQV0RMAAAA///s3bENACEMA0CPxgrw++9CR4GEeCEqdLdBShd2jGoAAAAAAAAAAAAAAPCU+rWSpGxuUur6b1WsGnwjBgAATshvV8luALMkHQAA///s3TERAAAIA7H6V40DGJjgEhdd+k41AAAAAAAAAAAAAABg0BSXL1IZBgAA3vq035xgACwlKQAAAP//AwABfYYWIBDxNQAAAABJRU5ErkJggg==',
			// 	width: 60,
			// 	opacity: 1,
			// 	border: [false, false, false, false],
			// }];
			// aHeaderColomns.push({
			// 	border: [false, false, false, false],
			// 	columns: [{
			// 		width: '*',
			// 		text: ''
			// 	}, {
			// 		width: 'auto',
			// 		table: {
			// 			body: [
			// 				[{
			// 					text: "UR NEXUS",
			// 					fontSize: 14,
			// 					bold: true,
			// 					alignment: "center",
			// 					border: [false, false, false, false]
			// 				}],
			// 				[{
			// 					text: oHeader,
			// 					fontSize: 14,
			// 					bold: true,
			// 					alignment: "center",
			// 					border: [false, false, false, false]
			// 				}],
			// 				[{
			// 					text: oSrvtyp,
			// 					fontSize: 14,
			// 					bold: true,
			// 					alignment: "center",
			// 					border: [false, false, false, false]
			// 				}],
			// 			],
			// 			alignment: "center"
			// 		}
			// 	}, {
			// 		width: '*',
			// 		text: ''
			// 	}, ]
			// });
			// aHeaderColomns.push({
			// 	image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWwAAABuCAYAAAADICkGAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAIjfSURBVHhe7Z0FeBTn9v9nQ/VWbv329ta9t0Zb3KKb3SRoEhLiuLtLgUIFKe6aECUhuLtLS7FSqhSHCoUK7W2Lfv/f874zKxEILRV+/z3Pc57ZHdvZ2ZnPfue85z2vAZ/5zGc+89lVYT5g+8xnPvPZVWI+YPvMZz7z2VViPmD7zGc+89lVYj5g+8xnPvPZVWI+YPvMZz7z2VViPmD7zGc+89lVYj5g+8xnPvPZ38Yu0E/rl0WYD9g+85nPXGbU6wWj5iAY4SNhhE6B4T8NRuBUGME59EwYIVmc0sOmw3Bkc5qrX4fTZVqd7yPoNfNh1JgBo84sGLVnwoiczSlfx8yBEc3XMfPoc2HEzdeetAhGwgIYKZwmL4TRYAmM+nzdcBVfL4fRbDWMJnzdbK1+3YrTlvQ26/ma3m4DjLacdtwEowO9yzswOtG7vwujG6c9tvP1ezB674bx6i4Yr3Hal97vA/oeGAM+hvHmRzAGfcrXn8AYspf+OYwR+2CM3A9jlOmjD9MPwRhzhM7X447CGOvh8t41j+tM/gLGxGMe/hX9SxiTTJ/M9y7/mvv+CsM+OW7+GoXNB2yf+cxnLjP69iDUXofRawhsXSYQgmkEZB6MRnPhV59AbUSYNiZ0GxG4Tfi+Kb0Z59FtLQjYlvRWhG3rxYQpp204bbuMQF0Koz2n7ZfD1nEFocrXnVZq70wQd+O0O0HcbR2nBG8Pei9CuOd62HpthK33Rvj13Qyjz0bClkB+7V3Y+m2F0Z/+OkH81jY6oTxgO/wG7IDt7V3wG0Iwv70HpYZ8SPB+CNtIAplTv5GE8+hPYBvzGaH6KWzjOJ3wOfwmEM5T9sE2hWCeegBG6kEYafR0AjqL8M06Clv2MZSaTtDmEL7ifC/zjDzOyyWcTbfN+Aq2PEJY5ovn87XL5f039OMwZp7w9pyvkXbgrPlrFDYfsH3mM5+5zBgWReg1g21gZ/j1702AU213HwG/DuMJZCrrhoR3A8I6ZR78GnLaeD5sCtxUyQLu5nSBtgI4Yd1qMfxaE9wK4oR2Ow1tBe8OnAq8XeCmd11DaFM5dye4BdrihLbxqkCboBZg9xWnaia0jde2EtwE9hsE95uEtrjAe9BO2AbvhDH4A06poodRRQ8nuMVHENyjNLSNMVTUAu7xe2EjtI1J9MkEt/iUA/CjK3CnH4YtXaBNQNONHIKZwLZxqoCdK8A2fTrnEdYK2AS3l+dTRStoE9gzigB29nGk7feFRHzmM5+VwGxjAvhI74AxshYhlwJjYCuCuzvB2I/wHAq/jmMI30wCehaMZAK7wVxCnLBuyGkjTpuIa+Vta05wC8AVuEV5c6qUtwnudgQ2p7b2hHZHvjbBbRPFLfDm9PZXqbJbUXn3WAdbjw2w9aTS7rUJNgK8lAD8tc0ENpW3UtsCboE2lTbBbXtrB8FNtU03Br0PPwVuN7z9BNyjP+Z3FmhTaY8luMcR3OM/h23SPvhNMpX2FFNpT6PSJriNjCMK2qUKQFuB3APaLnDnCqw5T5S2C9yisE1oe4I7mwp7/xnz1yhsPmD7zGc+c5ltdBjVZhDVpp3wcvJ1KOEWA2NIUyrXjoTia1S8g+HXaRhsbTOorqebiptK+3IUN9W2rY1AW0IloriXw9bBVNsWsKm+a4/fjiOnfiT0uUxCJEpxc9rbVNwSJiG0jX5U22Z4xCbQpsq2SYhkoIa2MXi3VtpDd2toDyesxUVpjzKVtgK2hrYxUUPbUtritqmEdoYGtpH5e5W2CeyCStsHbJ/5zGclNWNcIIwJhPREcUJ7PNX2pGCqT4J8VB0CrwGMAR0IyL4wXn2byroXjPiBBGoubPXnqFCJUZ/uUtyEdyHFzamltF2K21LdWnHbCG6/TgS3qO9mXNZ5LffJbbtvwDVU2QJuG8EtStuvt8S2N6kYt+21rfCTEIkV2zaVtm3AdrrAW4P7WoH2W4S3xLZH87XEtQXeYz6Dn4RISqK0s0uotGW5QNpTYYviFi+otCWG7QO2z3zms5KYMS5Iq+qJBLVAewJBrTxEAdxvohN+oyMIuhSq4ShzK+DunsNhtJ1ItZ0NI2EmjOS5Zox7nltxN3UrblHbfi0ltl1AcbcnsCVUQnUt0Da6iNJeiRu6rFGf81g/KmxpoLSUtiu2LWpbQiQFGiNVTJtKm64UN5W28TYB3fs97PiKoBzEeRIaGfkhgS0hEjOmXVBpT6EraGul7TfNW2kLrFUDZDFK2w3qAu6ltOnTfcD2mc98VkIzJgRTURPWEhJxKW0L4PTxnD+R8BaAjw+HMbAeAtIHEJadYXR9HbUm5WHYovdwS7Ncqm2CWMIl9WerzBK/plTdl1LcbbmNqbZt7SS2vQIP91uDiWsJS9muHUHdmU6l7SdZJWZcW8IlorYlVKLA3Zfgpgu0/VQWiVbYorTl9SNjPkT0zP24e/guAnsPjGEfwk+FSMwwSQGlrbJIJprQlkZICY9I9ogZ07Zg7Qnt36S0079E2gEfsH3mM5+VwIzxGtg2KmlxBW3lAnET2nSbwFrWnUhFPpyvR8bB6NcYA7ZsNPfEfcUPgVE3Ff9oQhgHZ1B156sYt2qYlPi2pbgJbFtzKu0WorS12lbhkfbLcb0AvOkyzNpxGPWm7OT8BYhO3aEbMHvo0IhS2pJJ0ovvrSySPu8oaHsrbXpfmXL7t7Zi1rtf8w9nJ659m/sdtgc2QrtIpT2eSnuCOME91QyPiE8zY9qSPaJAXRjal620M77yAdtnPvNZyUyp54kE8WSCWTmhLT6J0BblLQpbqWwP1T1J1LbMjyAIIwnVelTKLai4B2DsynfMPQNBfdfAiJ0Fo450mKGL4ia0bc2osFtIqIQQVrncnKpQiShuglu8OcEtjZcRs7Bh71cYuYrwbMv3kv4nroBtZpH0lBCJh9J+bStK9d8Mo9smzN9DuHZ/B3HzD+G7C+f4mgpcNUYS2EMJ6+KUtpX2ZyltaYikylYNkVTaNlHamQWUdjan0wltgtwCdrFZI5bSTvcB22c+81kJTcFaoG0Be5LA2nQBt8S3LbXtUtyh8FOKOwQ2wttvdHWq7mQq26ZU04l4a9k67Dh2HFUGLEbZ7gtx8PhJTFj0Ea6Jp+KWMIeobQVsa0pgt14Mm3S8saDdZjkhvlQdY+8FVL/1uazDahhd+CfQfT1s3dbBTzrcSEOkhEi88rXFt+Pewe+gRvqnqDhmN9YdPYLQqe/zqYDqetBuGEM0tI3hBLfkal9UaUtoxIK2VtpuYOvONS6FLapaoG2q7GKzRiz3KWyf+cxnJTVjMoE8hcCeSjiLu5S2h0+hi8IuSnGr19x+bAASFw/Dwe+/gzNzPCHcmTAeiIixueYnaTPCM2FEzaRLhxyCuukC+BWKbS+h2l4FI34mnu2+Ctnr9sNoOA9Vx27HbR25njROdpXONmaHGxPaVr62X+8tKoPk+s7L9WdyefCE9zF5zwncJZkjor4H79ZK+20T3hdT2p7ZI55KexqVdgaBLbFrgbYo6stV2j6F7TOf+aykZkwicAXYAuWpdIGyp1vQvqjipo8LQOm85jh39mecxXkYvZx4YmQ/tJqxGE+9mYpWU5chYiAVsT0Hh05+i3f3H8cjBKpKBfSIbevONlTTdbLNIzwLVZuk8VKU7qszR/7T01Tarh6SbmhLl3altJutwbdnz2DI6kMw2m9W2w1bewS3vLYNu06e4vrbYFMZJGYWCVV2sUrbM3vEytO2lLbKHDnq6saulLaESDyVtgXsopS2T2H7zGc+K6kpUE8mtFPDtAu0LbV9ScUt8DZdqe0gGANfoHp9DsagSjjw7VfmpwARU6ioG78Nw38Q2k7dqeYdoho36kg+txSHEsW9wN0o2XoZFfZsBI6gGq4/D+2mb8fX//sJ1yabQO8sPSQlDXAt/Lq6oa0aJbuuR2TmB+i9kIq43Sq8umYvMnedwKPD3kGXFYdQazoVtHRxl0wSUdoC7EspbTN7xEtpS5625GhnHIafh9K24tmFskaKUtoK2L6u6T7zmc9KYCok4gnsKYS05QLsEiluT3BLDnc4SkmYZNDL6LZiFHI+exf/eftV1JmoVXPeDirW4DEwHHNgBKWreWJBb1Axq6wSQrvZPMKbcBbVXZ/va+bj4xOiRH/SXeTrEvKSjSKhERUeEWgT1j0kg4SeuADLPv4C8Vkf4omhu7Dl0ElM3fGNAny3+QRtn3d1Fsmg9wso7YtkjxRS2gS3WSzKpbQlDGIpbYG3BewilbYP2D7zmc8uw4yphHUa4ZpG2IqnFnBPtX0RxW0jwMV1bFuc82U6uiKVaxWCMQIvTelrfiqoln+AETkB9UbtpMrORM/UbajUj4o5ZT6CB2/E3a0J5QaEdaOlGDR3h9qmwlsrYEQR1PUWqferPifwGlGNd1lFEK+CresalOq+nIDXjZUrPj2hyrz+cOpn9d7WYR3e3HgEZ/ELjE6bYHtDcrR1l3altEuSPWIqbQG2qvKnXMIjWmlLTFsaIt1Km16s0ub7aV8idf+v6viKMh+wfeYzn7nMmEJgC7QFzmkCX4G0OF/LvBIqbtuEgnnc4nadTTLWH4/nJKHNsmEwutlRZupIGK27Ys5H+82jAFpOfo/gnqHqby/54LCaV/X1ZQQ41XWTBfjlglahRmw+XnlzAx7puhLjFhGUTQl11UOS0O5K77QFLw/bgHv7bMdrc3aj9PD3MHrzQQxa9inKDtuMgauohJsT/K7CUWa+tqW0PbNHLqa0var8uZW2ytGW0qwWsC+ltNMF2D6F7TOf+awE5jc1mLAJgi0tDLZUgnsaoSuuFDdh7Km2xS+puGWeVtsuxT2yIrI+WWZ+IiHU9TkCM4Uwro2tX7qL9z9MRb3ww29Q9zWq5DhpaFxANT0HGSs+xvUNF8MIy4CRtMBcGwgauVmnCUq8u9NqXNtpjeqAU37wJrW8zWzCNnYpvvyfVrBG53cQnf6xft1mne5gQ2gXUtqDLq60VZU/qmy/8RrYup72QZ7Lg7BJF3ZC25ZJSAuYJZZtQruw0uZ76enoA7bPfOazktg1VNPXpNlhSw8joAlYcQG2wFugfTmKW4BtxrZdPSetOiVvv4DAWe1QY0EPGCNeQZ/NOnY9eq1kirSCUeM1ZGz7TM0TO3byWxgOGe1mCiau0vONmjPxUOdlqDZ0HT7+6kcc/fE4ob4cXXOpiBvkw2i/Ev/uuxHZ7x3Bv3uvxDWd12Hbl99gwZ4v0HwmIdxiEX668Atul67ukq9t9YosoLQL5Wl7Km1XPW2CW0IjltJWjZB0yc8WpW3Gs1XGiAC7KKUtgx/4gO0zn/mspGakBeOaDDuuJbCvmeaAX7qDKpEATw0ngAjxK6S4ldIeF6DytY0x1RC1oLd5BMCkDRLKaId7+ozH6DW7zblAcO9l+OKHnzB0/icwyqZTYVupfsDcnQdhVEzHQ93dyv06aaCMXYwfL/yo3hutV+DGdhLv1iO6GPELUHb4Ozj000kq8bXwkzKtHtAWpe1V5a+A0laDIcjINRIeocq2jd2rlLaNSltUtp/VhT1VlLaER6RzjcSxvaHtVto+YPvMZz67DLuW0L2RgL4hPRzXp4bhek6vmxbGR3o7/Ahyb8VNAIvinliV02ANbIGxUtxc5qm4LWCLyhbwe8a2Bd5jpDEyEFVmUV2/9gp2HD9mHhFwW6txBPQwdMj4xJwDfHb8Bxi1stA8W1ICz6t5Axa8j0lbjuCtlZ9g5Jp9KNViBTYe+hIpaTtR9q1NMJqvVuutPfQjItM+wv1vrFfv7++9Rdfalq7sVl1tC9yqaNR2D6VNN5W2GghBwiLWyDVmPW2b9Ih0hUboqYS2AFs1RFJpU20rpV0opu0Dts985rPLsOsyAnBjhgP/SDfBnenA9Rmh8FM9IP1xDZV3KYLaJuCeKso7BH23jMcDuYmwTQyBn0BbhU4cKCWAdiltE9SjXoYx4DHYJofDz4xr69g215UKgGP5RzCuGv41Kdo8Im0PdxuJQQt2Y/LGLzB3x2FMWa0zRcT2fvUdnu+xAvVG6A4xYnuOnoBRIR357+qGzJUfE4Z1crF+3zfq/a8XfoLhWISak9/HJ999DxnVxq8PFbZZV9sFbLrtdaptD6XtlT0iY0SqkWsKKO2JBLa4KO0p5uAHrnQ/3QjpgrYnsKd94csS8ZnPfFYy+0d6EG5Kd+KfmWG4ldObqLCvJZSfntMA/d+dSLXsj1LTwnWMe0oQSuc3Uttt/2ofIVVOq+/RpQl7QnvIswrcKt4tsB74mFpXzBhRhvviPAmLjKFCH0dYi9Iez+3HBKDt6sGE5tN4Jf1VGF0a4OvTluo8h2ELqGj/MwprP7M64pzFp9/8jMB+qyi2fwEu6Lknz5zG5gNfYdSmY7i++Qp8/dMpNf/ChdP4V6+NGLd6r3p/72sbVd62q662uAVsT6VNd41cIzFtcQmLFBwjUpS2FIqSIlGW0lYq26w5osqxFqg5YsWxFbB9CttnPvNZCeyWjEDclunErRlhuCXdgVuzBbblMf7D+ThDEgbM60CoBKFUOgE7qRpBW5nQepyQIoBFSY9+wdyTNmNCFSppgnicP2FcFTdQSXfZNJLrVeD7aoif3x8jtmXCT8AtnWzGByFodgdza8A2LpiQDME1PeviFzP0IZaxaR+O/vATX13AjiMnsOPoF3qBac631mHN++6wSoucd/F4vw3mu/NYcZiqumouZrx3kO/PwGi6whydnQrbVNpq+DGv0Ig5cs3AHbhm0E4CW0IjH8ImwKYrpS3AptIWlV1qHKFNcIvS1t3XCew0XdnPs+aIpbIVuNOO+YDtM5/5rGR2R4Y/3Y47s5y4MyMUtxPet2cQ2pMFsKUJmwDcRPUt6tkyNazYNM5L5XojnsGj2clK5P7464+4UUIko1/BW1smYsj2VK4bRIhJzJtwH/a83oFpxkAq8tH8E+h9F6rmNcKUXYupXKsgapFukBy5eTkeHzEURlI39V5L6XN498AJGDe9ie9+/Z+erewsRqz+1HzttgsXzuH7X35G6NAd2PnNKXzDfdzSZCmMbuvo69UINsq70yWu/TqB3Znw7vEODIll9yW8OxPkA3fT3+W6O2CMJKhlOkyATZXtGRqxqvvJiDVU2u4iUe7QiBUekXraRppPYfvMZz4rod2W7Y97COm7c+y4K5vAzgrDbQT2rZnhVN10Ku5bMkNxfRYV9hR/3J1ZmwCqQgAF42ZCe8+3xzDvAEE36BHCqzRVZTAeyogz967NGPg04V+FACSge92GZhveRkB+G65fDh03T1HrDKeiN/o9RsBXRfCcdmqe2Lx9BGXLWISPzeI7M/ahTNT3OZw+fwEnfpasEHnvBt9LXddi95cnzHfAQ32X4+nX1+L0WYkXX4DRZjUeGUBot1wOo8s6jF69F/e+sUWlBi777CTm7v2ay9ah3owP1fZGn/fQZLaEVLhtC63cbxtNYEuetowPqTrWUGmb3dddoRHlEh6RdD8qbc/8bMkemXbQB2yf+cxnJbO7MgNwH8F8b44T/yKw7+H0bk7vzHTgjnS7VtzpobiF69ySEYIbpvF1enWUoiq/iar5zBldae7e9EiCSfK5ZfzHpxAwtyM2ff85xn8wm+r8vxi0TYAriAXuVpkiBPj4akhY/oaaL1ZvZX+u+zICZrTDfZMjMfGzhXhmYhJ2f231iDyHPos3o1RSBs6fkz0R4BfO4+D3P8GoqsFv2Xn8igPfSgjF0y5g28HvYMTNRueZH6g54zdTCacsQ+4HX6r3t/cntFuvxA/nfkLbRVTEbbfg5TFbcd/I96m+t+mwicS0+3yAa4dTgQ//SIdIZCR2U2krlV2oJ6Sk+RXIzxa1TfU91Temo898dnXbOQUkbRcueCrLK2v/zqmGf0234/7pofgPVba8vic7mIrbQcVtxx3Z4Qra/yTAb6XyvoUK/GZOb0534posOwH1PAH9KIwMQpiAN8ZXxpzPNyN8WVeC7RnCqyLXKY/pn680PxH4/vx5gu5lOhV5v/9wHTuarBsIo/9DOPDjSXMtoFxuK6ryR9B07WBzjjYj7lW8Oec99fqX0zrHWuxskefpAnJ3HcMdbdw9JHd99T3qjtqKcdtP4t1Dx3Bd+40YsXE/qk0giJuvwc84g4zNVMTN16LKFJ2dctdbu3HbAF1l0Oj/ji4UNUTnZmtg00d794QsmJ+te0Lq/GyJZ6vR16ccQ9o+z9COt/mA7TOf+cxlD2T74/5sBx6c7sSDWaH493QH/p0dgnuzw+gOF7jvzAyn4nbg9owI3D4tTDVS/iPDiRszw3ADp5K7fY3kaU+oYu6ZsBlKYKuMEYL8rYdQb+mrGLJtGv6bmwRj0H9x6hfdwSV+cV8Yw14h2AMQttCKV2v7b1p9DNg5A7+cOY2tJ/Yhe9d2fPOrLuZ0+pxulCzdfiH+d1pUqhvelp09557385mfuMZZvP+lVtNiLXMJ15TF5jvg5r4b8MCbuu72RFHfLdYiJvNDNFhIGL9GRd2eCn/wDg3soqr7efWEpNIuGBoRlS3QJrBtWVTbU77wAdtnPrtq7fw5nD59Gs3bdkGlQAfsEXVQvmoIho0ca65wZe2BHH88kOfAAwT2AzmhWmnTvRR3TjA9lMrbUtwOl+KWBsmbCPIb+PpazitFkBsjnibInoR0uvEjsG/LqIFd336OynM6EMplVZzbGFywAfJBgq4SoVcR104IweD3MvBEaqy5VNuBk9/AaPMAMt9ba84RO4M5u77EYpUh4s4quZjd3HQxlu4/wscYrcjLjNiM1tP38M/gGALHbcPAlQcQmP4+FfYqPDJkq9qrFJUy3niXin+HWXNkJ/zoBXtC+o10p/oVys+myvYeE5LATj1AYPvysH3ms6vWnDXrIL5+E9SJSUJIWG3Yq0ehXSdv5Xml7LGcQDxEWD+eVx2PTQ/HIzlOPJwdSsUdRsVNtU1w35cVgnv4XtS2S3FnheFOaZyUhsl0J25JF6VNcE8Lxw2p4SiVGYFS6eEElaTuBeDzU18i7/N1hBmBLdklEirpeyearx6MgLltCPnnsfNLnSctZgyrQAX7GJqtfFvPMKMdcz5YipWHdQEnb6N29lDTxdnP5624to4bT3tvPyZu2KdeH/n2FIzYVWg0Z5d6n5xLxdx+I5rO/AyhaTIeJJX1W5LyJzVHZGxISfWjyvboCWkbUSA/WxogrfzsyVTZXvnZ9LSDPmD7zGdXqx0+cgSOiGhE1k3GuvXr1Lxvjh/H8KGj1esrbY/nBuCR/CA8PiMUj+WF4JEZDjycZ1eK+34q7Ps5/Y+ESai0/01w/4sAF8V9V5YTd2fY8c/s6qrTjcS2b8mQjjcOXJdlx7WE9zXpIfDjPBXbHvMKjHHlCSsCfHIVvPVuLg7++CXnVybQA1V2SI1l/cyjAkZ9mI/KMztg4eGt+PXsWew79RUO/3gc275yF4gSKzNiDOInzzbfXdpOnf4Vr5sNjrhwAf878xOMgOn46LCOnY9dT6DWmwtbh1X4Z18CWgb37UXvS3UtKX/SC7JAzREVGinQE1L3gvwUpcborJGCY0JKvRGV5jeJCvvzX9RnF2U+YPvMZ39j++bEN6heqx5q1InH119/bc794+zp3CA8kWvHU3lOPJkbiieopB+nin4sJwyPUm0/wunDhPP9hPZ/qLzv4/Q+Kuy7JURCiAu478oMVbHt2zxi2zdkOnGjwJvzrpOu7VTeakQb6Rk5NRivzG2C73/5iX8KcQQ4FfekKngxOw43jAvBgPemUc0+bB4huXr2An76+VfC8z48NCHSnOu29/gndznWNW07cO4XnPMKoZzFhHcPwUiah6kbZH9nYTRfws/crPO0+71DF2AX6AkpNUcGmzVHPHpC2iRrxIpnFzVSjShtUdmE+NS9OiZflPmA7TNl588XH++72DKxC+f/uKyF32oXPeY/4XDPn7/043hJrHGrDohPaYyUxi1QIzoB3Xr2QY9efdC4ZXscOXbUXOvK2dO5/ngiPwTP5IfiaarsJ2fY8WReYcWtGiUJaVHb91F5C7j/bYLbnU3ijm3fKo2RWQ5Vp0TUtsS2/SSTRAZLmFCWTmU9ujThFQJj2NPm0WiT+tnGyBew8MA76v0F87ed+eFy7Ph2L86o3/Mcjn77Jb77sXh1WrR5XydNMz/EpM2fm++AiLEEc/JitEnfCb9ea/CP3hvx9BDO67wFtv4boAY+kHojUkN74A74mUrbZiltyRpR9bM/Vu43+jPYZNADyRqZsE9DW4BNlS1ZI8ZEKmwfsH1WEvvx1CksX7kK6zduUr52w0Zs36bTpSz74KOPsY7z12/gOps2YSXX//Gn4lu1/0r76MM9WLOex2p+Hzne+fMW4sTJ78w1/lhbvnQZP3ez6/PXrLe6RpfcXixfFbGJjRCT2BB1E+ojKr4RasWmoFpwGPYd0LHWK2nPTw8kqEPw3IwwuoPgduBpAro4xf0gpw8QxBIquZ+K+16+98omyQrDHQT07ZK3LaESKmyB9vV8L4WiHsypjXl7t6DGwh6EdiUqTUJ8TFnMPqAr6YmN3ZlDmFdF0+X9zTnath0/pKZnJDuE/4/zP10HI9YoYVOjto4zP0SdwVvMd2K/ouGEdznV/+onzuhOLFuPnCK4l+Ga7vq46mVRSfckuHvRX6NLDW3pCWkpbVHZ4lLRT1x6Q44SpW3GslVVP4lnm/nZEhqRQXwn7sPUz34XsAt//eLUi2euqM+uPtt/4AAqBThRJyYRtesmoHqdWLRq28Vcqm3w2yPgqBWrlst6Fas51XZ/F7OuwU8/3YcKVYNd30WmQY6a6EKF+mfZc2UqIzI2CbVjElAzKp4KOdFcUnIbOXoCMrNzkZll+XQ1nTh5Co5/e+X/eP47IwClqaZfnBWKF2aG4NmZDvw33+5W3PkEd14oHqXafiw3BA8S6g9y+h8q6/skk0QaJbPdse27s8JxD1W29I5UeduitPn+xnSCOa0aum8YZ34y8Oj0WAI7GMbQ52H0uA7h89pgqMB66HN451t3N/M9xw/D6HQt/1zqqffnCvKIb88R4q4HqQvFd0QR23FEg//chfNU6+51931zEsbL6fj1tN7TnA++xhMDt+PR/utRdigB3XElpm48gJt6v0to67KstjcJa1VzRFL9OB0swKbSHqaVts3MGlHjQU7Yq1S2leqn8rPH7UXap78jre/bb79F9ci6KFcpCI2bt8NpM+fx0KGDcNaKQvmKAWjTrrua57Or2w4fPozw2rGo36QlH8FbIqF+U3Tv6R4oVWz02Imol9xULZf1wmvG4tDhK/9o/nvs5InjqOhvR2Kz9qjfuIU61rrx9dG5u4b1hSsUrriUVQ0JR4OmrdTnJzVshoSGzc0lf197cUYgyhDIrxDML3P6wkwnnieUn5vhpIfimbwwPE01/WSuuB2P8fVjVNMqtk2F/QDV9QNZHrFtiWsT4Cpvm8C+zVTat6ZLDDuAgHoOzVcNxrDtaQRZearPQPNIgAmfLCH0HoUxvhJSP5in5p0/r/+QW60ZhFYbx+KXn34tpCkVX81OM0bwk9h89GKxf72x3u9pGJUnYslH7vXbUIG3znkXM3Z+g7b50i1df358zocwGq3Eu0d1uVbptq5qjrwqqX5mA6TkZ4vKHiqhEcnPtrJGPtaNkON1aMQwY9k2UdrjPv9twLaUSgX/UF5szVGfF15ccmM0btlGzX+FALfm101owBv7NTXfZ1evKWBTPXsBu0dhYMcmN+HyFmq9sBoC7Mtr5PkjzHrqO/HNCVQLcfLYBJQC6xb8Hk3QqEUrtfzPtKohYeZx/D5gz50/H+kZOcii0hYfO34yeUQF+Qf0eCw9Kwhl8x14aXYIXsoPRmkq7NIzQ/E8wS3Afpav/5sfotT2U1TZTxDmTxTIJpH8bSu2/W++vjfTI287Kwz/zHRSXb6IxuveQr1VfXXPyCmEd7odD+VaqtkE49I3CPHSqqNNn12Zap5YzIoB5itth7//Dka/f6nXp818ak87c+60Utwnv/8BZ03oihm18jB50fvmO2Dnka/Raa6Emk7jxKmfMW2He2Dgf3RcjvBJ7vCJ0XMz/tN/I8LGEsqtVuMg9504kwq6J8H9+nZcM9gcYuztD+BnVvZTudlW1giVtsrNnvQ5/CSeLWERzk/75Dcq7PPnzqq8zwbqBm6h1ELVQCc+/fhT1IiM43t9Yyc3ao7omGRzK59drXY1A1vsAq/XMD711WtI9W/CWkRF9ah4c3nxRXX+CLtSwO7QqTtq1UtCNIVR3cSGqBDgMJdceSs7sxoq5NtRnoAux2lZKu0yhHPpmWEoTZUtivsFpbgdeJYKXNT2U9ND8URuwdg2wU3FLZkk/7HytrnuvRl2PvqXw/iP5pqfCPxAcWiMfQHXpIURYs+hxdoh5hIoJZ645i3zHeCc1QZGn5upTKuac9xmDCuLGvO7mu887PwFnLtwFr/+7xSMJ9oS3t4hkjP887Ps82/dOdCZmwjVatPx9Y9WrvZ5GA3WYPyGj5D30ZeoNlbnZ3/90/cwmq1CYq5uU3hl3Hsw3qC67rSRwN5FlS2ZIzrVr1DWiMrNltCIqbTHfPbbgG39e1eoZkdS0w5oSFgnNmiGmIT6an75aiFo0LgDUpo0R3xKUzRp6a6o5bOr065GYHu2m0TUqquf+kxYJzdqAUdEbXPpn29XCtjd+BvIbyH7kXMeEv7Hfadyc/xRcVYwKsxxovzsUJSdFYYyhPQrVNwvzwx2xbYF3KK4/5tP5/QJlU0SjEepslVsOy8MD1JlW3nbEt+WLu53Eer/SK+KtuuHm5+o7fo0qf5XBn23TkXKil4wel9PwD1GiL2MnI9113CBrtiDOcmE80N4aFqMem9Z3mfuHo/Dds1D9dntcfTHE1IPqgg7h7WffY1j38go7efIO9n3GRgPjMSUDe4sEVur5Wg97V30XPgB+qw+gHFbdd3txXuOwqg5G5sPfqvep23h+96r8ah0oukoo7TrrvFGD8J70Falsm3DCG6JZQuwpaLfGDNrRHpBSu1sKRA1ggr7t4RErEfMdes2omylAITXjkHFACdOntAlCjOn56NclUCE1oiCPSIS33//PecWeWZ8dpXY1QhsS1jUiaqH+AYa1HLs4sFhdcwGqb/murxSwJbf4M8CduVZgahCZV15Tihf21Fxth0VCOpyMx1U23a8nO/Ay4SypbifJ5hfyHW6skncse0IpbYfFld52/QsydUOw81ZAVSWjyFxWT8sOPoOIT0BxshH8PFxd/jh+A8/wBhVGkZaBKSetmcq5k2TQzHjU53il/P5JoTMaYNrxjkRv9K7QdnofitGbM0z3xW089iyj5C9caB6p6F+Hid/PU3I/4QfT32L/jM/witvu4cdM+rOxHUEuGXPDNyMykO3IGX6XjzSX0Il+jqTUMkzI3WYZfuRL2D0orrutYUq22qA5JTQ9swaUal+kjEy4hMq7IJVBd12yUZHyz7f692jyLID+698apHP/hq7moDtqaybNGuNOI9jkhCdvz0c33/356TvFWdXI7Arzq6CanPtqEKvPCcYleY4UInQLjfbgfIEeJlZ4SiTH4YXZwq0JbZtp9IOcmWTSGz7ackg4VTyth/Nc+DR3FAV176P0xtTyyF+eR8M2DENVRamENQPwS9NRpsph7WHdfW7s2e0kq44txVh/SzuyI2G0f8efmYSbp9ch+D7t1p+xux6nvfZKhjDy1CRP45+W3PUvM++OoaMvW7Yit59aGQ0fvr1nGQAethZ9V9wxlTvp09LSES/Xv35cRhVM7DkfRmVBnh1PoHaeBnu7LgaA+bthpGyRM0XM9qsxJNv6/j27m++UV3Ynxv7AZzpH2DkGp1FdccAwlrys1Wqn45nW6ERlTUixaF+L7BFwVyqceOPaPzw2Z9vV6PC7tLtVUTFN1THI8csYZCqweE4cuSvz1y5GoHtP9sfQbNDEUCF7U9AV5vrRDXCutLsEFSSUMmsUJSfGeKKbb88QxS3ziZRsW0qbYltP0X1/RQB/SgV+CPTCW0q7X9nBaHMPO+2rnore+PmtKq4TTrRjH0R277Q9UP+9/MZwvwJTPvQXQb1qelNYUypQriH4MX8xuZcAvL7A4T44+izZRo6bByuBkUw3rgfcz/3zK8Gkpa8BqPvSwWATV2s5PUFDF1KkFZKV68tixr7DgYs+QwP9lwLI2kWus76SM2vOvZ9NdjBy8O3qfcT1x2B0YJ/HJ1W4M43tqHTIp2GGDCZkO7GdS6cgfxVGD138Pi261KsEh6R0Aih7coaGf4Rpn6sqxYWZRcNiRQE8ceffIK169Zj3YYN2PX++zj1k/ufQNa9aO8y2uf7D2LNunXYsHGjcnkt84qyJUuXYcOmTXpd6aCxajU+/WwvHzo8jumCW2Vd2tzHdvSLY3jnnXfVfletWaPee1pJ8snPnfduuPjy66+wfv16ZOfMUHmy03Nzeeyb8FWB7sRynkqy/7/C/ipgS/frLZ6/R4EefMWdr+69eiMyNhn1eawaZq0UJPd8om+WS12PRdm5Ag2Tn3z6KVatXoN1/G137d6NHz2veY9sg6LsagR24NxqCJpjR8B8O/znBdMdhHYIqsxxojJBXnG2ExUlPOKKbdtVbPsFM7atgc1pnpNKOwiPTafq5utHcx14ODsED2SFmJ+kbfnBd2GkPY97Mmug07tDYYx7Ccbbd1N1Pgdjcnlkf6brZv9iUtYY9hQMGQB4XGnV8Nhp3Ri+rqpGsbFs8ZF3qFTLcd5zOE1FzQtBzZ/w4SI1Fdt8dD/u6zkAX54iHD040jLrY6z54DB+Ovs/fP3TGcxZ71GAqukiVVdk6/5jOPrD9zCaLIfRYR0MKm6j22p0maejEPf03wSj1Soc/0GnQButCfK2m/D0OMK682o174GRhPZwQl/1gnRnjRjDPkbq71HYM2cvQDRvCv/g6qheOw61o5OU16gdjxBnHdSOjMP0GXPMtS9uk6amwhFR17UPeS3zirIXXqmGOnWT9bpRSep1RM1YBDqqIyquPmbNdLcyl8SOffUlXu3zOvx5E4XXjFK1GepEJ6v9htWIQdUgJ7r3eQNffVFyZbZqxUq069ITVQJDFbgi66YgKiGZii8FsfGN1XGH8bMks6Z9565YyvX/zvZnAvvYl1+i3xuDeF2Fq3Pk+XuEc5+VqgXz3PbCgX3uG8bTxk6cjOpR9VzHKh5ZLxkbN+vY5u+x9WvWol5yYx5bGK+5euqYpPiSvuZrIqJ2DM/DBHPt4u1qBHbIHH/YCWf7XAdfhyJ4bhgBLoo7DAGEdVUCuiqVd4UCsW0rb1vi2i9SaT8+IwgPZwbBvigON057Do/lhSto355VhfBPwYff7cWWb/bgzkx/lJpU1vx0bRXmNMONaXY1CLAx/mXs/lpfA+mfEZATK9CrYML22XggM5KvK8E2SdIEq6Dm4lfVehtPEnxvPYrsvStx8IevcfDbLzBs1wLC8BW13GqEtL3eDWMXbNVvXOYWhNcnz6SqdrNtzCKqYRn/MZn7qjubkF6DUt1XoRSnRnd6s1X4+KsTWH+AMO9MkLdei+fHEcrNdKNpYOonMHrvxmvrpKPOrzD67eZx6swRq0ONMfRDKuzLALY1xI/chIF2gWOKignKhaJuDtP1e90SL+vYq9eiOtF/g8Upm8ysPMQm8vHV3Ie8lnlFmX9odd3pwFzXuljlBlBphIS2v6MGvvzSGure20SVWU8Iffu9icDQGuqit76H67t47FeWVw5yYFr2dLXd+WLSwD78+BME86apGR2PxAayz1Z0d2OXdr53fRb3zfVqxyTCWSMKn3+uG1fOnfOse3ABx7/+Bm8MfBujCIORYyZg2IjRWLDU3cjhab37veFaT6Z9+3vnpVqWmZ2DESPHqPUEMn3fHMRnjaKV4R8J7KJ+j/iUJub50V7w95CsJAlvTJ4mj6nev0dUfANCsLl5rt3bSY9CSUWtQtjWjknG6NFj8dVXkgkgVrziPndW77tZ284IrxOLZO5b/67e+5d58t2lu7gc24LFS9V2RVlJgT1q7BSMGD3O9Vv2e0Mawi640PGnAnuuPxwLg+CYH4TQeYEIWhCC4HkhpuIOotoORTUq8Ipese1QvEKovzIrBC/ODMWLBPijOZXNPQIrDm3Av9LL4pbUsngk247rpzwPY8pTuH7SSyp75JrJL6n1zppfeM2XVKITZRT2Kng+P5mK+y4q5kdhTCqDa6Ro1KRKekWaMeQJKnQpFhUIY+SLMAbeTzBTpXsobrFKeS2V6n54eoo5h38Au93d38UebDYT096RePMFyQSknYMRkAojZjZey9uG5/uvQdMcXcq181zCu/Vy2KiYbd3XwiYD+PbcAKMN1XQbKu6+m2F7TUZf36o8KG0Pjp/+juvwff9tnMfv+NY2TNp5GKXHE9bSoWYsp2/vQdrlAFvs0IF9VI0OJDRt5+opZt1MciFrgPNiNpfJI2m9hi0Q5Kxu7qFok1BBTGIDvT+6vJZ5RZkUa5cbVi5U6fggF7y1nYKh+VrU7YEDumupp1nRHGmQioxrqC50a1s5dvkO8l2898dljdoTqpGYNatoBb9q7XpUkRvRtZ3eh9on37uOmYCWPzPPG17WT+Q5rcRjXr3Ss+i6tkMHDiIgLBKxSU0QQ68Vk4Lho4suo1mumoPgbKrWq5fSDOUqBJlLvK19l+6oW6+h2qf0UKwSEGYuKWx/hsK+3N+jQaN2CK1eG3Nm655ulgn8vK8J7bJfz33XoygIcdREu86Xrh/dom0n1SNSQ9a8trkv+V3l+PSx6v2q35ZTe/VIjJ0wydyDt5UU2HXrpaBuYmP1W8pvWinI+z76M4EdPjcA4YR0+Fw7wuYGwTnfAQeBLYrbTigHUX0HEdSese3Ks6i0ZzlRnmpbwiRlqLDvySht7hHY+dWHMFIfwqwDy8w5QO0FbXFvTlU8MD0Yd+QEIHiO+9w45nfAdelV8cLMBuYcgmrMc7g+IwzXpUr6XyAez01CwIIOBLU/4V4NNZf2woKD7+GG8cG6e/uo8sj7TIcfxJYckPoejyJwJsH9+sMoNS4EL01rYS4VO48hiz8ioNNwQsIkpnUdpePgkWO2UFkvVIr7rJnHbUTlw2hHSCfM0iOu96CqlpHWpZpfn02ENl0q+vU3u653fkfXG5GBDoZwOvBDVM6RP4jzXJdKXIYUo8JO+/gy0vrOnT2LKv4hrotWpkmNmqFmnWQ4q9dBAi/Uerx4gkLDEduAFxDXURcSPTapEQYNGWnuqbBdDrCT6jdT3aK79eiDnq/2R8NmbRAaUQe1qWoTGrdVx6ZuBN5I1UJ4gStCW5pE29DhY9RjsvV54vH1WyA4xKm+g3wXJ2+4qNhG5o2ob0b5znKzedt5nPj2O1SsFurqbizrJjZsg9qxiTwf1dWxtWrTWR135669ER2ThGq8+aIIXgG5dU5l+2ohDnx9XHdrtUwDM8Y8Fp5nnk9RXEWZvz3CtV6DIo9XW/cevRHfwA2bkLBa5pLC9kcDe+Dg4eppzPotZB8JjXhM6vcQoLXg/iJRpy7VM6851/fj+ZK6IJ6WyN/OJRyKdL2tfI68lnMpaX5neX3DzAjwtI2bNsFZK9Jru0RCVnK7I/k7xvP3q8knpLAavAeatPbYdysKlVr49FN3rQvLSgps9eeu/qzM36gAkP9MYDsXBKEWIV19YQgiCG7nIjscC4IRuiAU9vnBCOY0aH6IV2y7yuxQVKDiLjc7GBXya+DZ3Cp4Iq88bkp7ETErU3BT6ou4Zeoz+gNMJfXjmR9xzcSn8Wiek1Oq6TH/hjH8ARjjHsPNWVVwRxZV8+TyhP2n+Pz7Y1SfpXG9jNaeEQE/6Sk5leCeSlUt9bTHlMbRU+6MIOPt0gR5NUL0H+i8biS++N+3eD63IZ7NcP8BXDPWTng+ibl7N5pzgIV73DVx3j3wA4y4WQgY6Ib+Ta1XwkiZDSN8DhqkEe715uPo/wjXCwRuw0VU2RthE5Xdm9NXN8GvN4FNUNteM0uwvvmerjUyaAf8Bu4itAnugZLyR7U98iP4icoe+D6mfnTK/MTCVgjYbTt04Q3ZTF0c+kJrrka42LylcGxQwgACIs8bwz8w3Fxa2C4H2MXZ1q3b1TBJ+sbSN0xsUkP07v+muYa2n3/9FRWp0q0bRv5QRD116tLTXMNtS5YsUyEOa5/yfWLimiIjM9tcQ1vX7r3VzWUdv9yEkdEJWFxM2MIyKTwvj+fWTSf7j0tsitf6eR9zQWBeHNjV3d+N05IBuxXsfxGwT373PaoEh7v2LdtLSKxV247mGm5btWoNnDWlE4x1HerfIy09w1xDYFgdVYLC4B8SUcgDHDUQxu3jpCyp+jx9fUoIJjZRd/wqaK2orusl6/Mk6yY1bIoaUYk4cMidGyy2f/8B1K4bp4SC9XQlbo8ofF5LDGyeZyu8I+fnrwR2jQX+iJyvoV2LyjpiYSgi5lNt871zHuFNQIcS0MFU2O7YtgOVFbideCjrWfR45y1M2JVB1VwLT2RXQ5lZDjyZbUfk8ibmp5AzG9/CfVlVceO00tj5pR5AwLG0E+7JCsK92aGq8p8M9mtMfIXwfRn/zAjHTRnS6SYC16eH6dFrpPExLZSK2o6HUiOUXDv2wzdUqU+hzhJ93WbtXUzFeyeM8QT0sGdhDiyDCe/mEJj/Rb+tuYT2NgzcvhYPddCFqHTWCJ98RlEph+SgbJ8V+OXcr7C1WIQOeRIS+RF+TRbAaLMUZV/Xg0q8vmgvjA4EuoRDelFtU2nbRGn3paqWwQ76m9CWqn4Dt8E2gLB+eydsgwlsGZ3G7AFpDNyJ1I9LCOyfT58xQaAvQpkKrA8cKhxysCzISaXXuA3X54XO9WvWScDOXe6++Z52JYAtduTwQVV5zdqP1DOpXM0bWIOGj0a8+uMhWOixVNaNW7Y2lxa28eMnITbO/ecjNYilFrGnSSch6zPlBpM46uVYdKy0B+j9y+fUjk0yl2j7vwzswSPcv4d4Ap/OGvBcFGdjx45HvUQLoC0UIBs2L3lv2uMnT2DQ28MRxj/3RPOJTI63Vt0UZE+fYa4FV1y9cqBTPano89kSoeHR+NJjcNaCFhYRxWMy98ttqkfHUaXrx2fLrkZg11xYFXWosusstqPOomDUXOBADQH2AjuBHQIHlbfEt0Vlq9g23X9uEJW2A6/MqIZ+73mPaP7cTGmIDMG/s0pTST9MAN8Fv3FP4L7sSng6Nxg3ZVXE7P0r1Lppexfi5vSKajQbgfbd06XaH8Gd5cTthPXNmXbXCDY3pIbhmnQ7rkurTmgHUYGXI5AfgzHqBXppHPje/fSa/xkBOro8FTvhPuQZtF43moCsiuSlb5hr8Olv/RwYrdogYKz72pi29Sg6Td6MOXu+guGfSRU9Hw2mSOlVCpCff4GRSLWduBTXtF2Bm3osgdFiGeZ/dBL/6inhkQ3wo8q2UW2r0Iipsm0yQg1Vtp8qwepRN1uNTkNgD/iAwPZ+8vY0L2DPnD1bqVC5MMRFTbbrWHTsz2pYHJ86japFF1gXj41vhMxsb2Vq2ZUAtnWD9ej7FuKSG7n2JWGHOXPccWd7RE3Ub+T+Iwnn4+6JE3rYn+LSxIIdFgTlMbw1/xS84SaNnHLDyOdJY2On7hpmUsqxJCahHevGS+KTSXgdXejGsv/LwPa3O11/7Gq7OpHYd0CndBb3e4Q45Xy7ISqFyC5lOh1VXunrZNbc+agZG6+gKn/c8kdRJ8p7MNevjh1FmCsUpf+MExu61aCnWdd97oxZiExwh9tieS0OHurd3fpqBHadhf6oOz8Y0VTWUfNDNbznByCC4K4uinsBFfdcgbYDoXz/Uu4reCX3ZfhTaZcnsAfuGGbuSVvNBbG4N/1FbDisQdd2WR88MqMinsp34qk8qf7nxC1TXsbDM0Jx3ZQX8HB2uOrK/p8ca0AEB26XwRBkuLEsGQwhTCltGSvyGipsW1oI7s6MRPbe9XhmZiP+IfiruHb1BT3U51lmvP0EbhlfEw9nxvP1M4R3AOHtnZ1iNAxE2+xFGLqainveh7iv1UKs2afhKVnURvV0GDFzMWDxPuw5fgJGnTxkbt2LebsJ9OSlBP4iTNp4DFLTxmixAjYZSkyAraBtqWz6GxIekdCIFIcisKXWiFT0kw41lwPstwaNUBX5rItQ4o3LVuh/v+JsOZdHxmjIyw0RndAI4ycXnap3pRS22JKlSxBdT/al/yhikpti3ISp5lJR/rVcN6B4OB+RL2U1YxLM/ekbQ1S8mPkfgSbNW6m4piyXG0wyHZSVMB9c/yHI8RAcDVuidRvvcMD/TWCfw+lff/UKY4nL08qlzF4j0rW+bGsPr4MLZhW3y7EahLE0HFr7CeZ+fvjB/di5as061IlNdH2W3APDR7nrNBdl333/PcKquyGvQoNNvJ/grkZgRy2qgpjFIYheQmAvDkbkolC6ncrbqdR29YXBOrZNaPvProJtX2/D+sMb8FxOWQQQ4s9kPo/xu9Pw0YmDeItq++HsCrh5ymPm3gm+sz/j5mnP4oV8rjtTBkYIxVNU2o/nhOLxXKcqHKVHa3fgXirt/xDaUlf7Tk7/6am0pQEyk4qZgB79/jRz7wTaOBmFnYp74H2oMKMJ1n25B1FLexPOj+O7X/Rv3n3DRBhjqkLGjrw3NQo/nzmLr349if8MddcrT1tLxRuajdsbzjTnSAx7OcE8D9c0pbKuMxdGg0VYvVf34Zi/6wiM5itgNFqgc7PNrBFbb4llb6bC3gxbP3ECm+AuZY1Qo2LZu9zV/Ajy1D0lDIlIQ5l1YYjXqpuAd7Z6jzhS0KRzSJ3oJHMbgjOpCUaNmWgu9bYrCezde/ao8IsVo4xLaY6OXfS/6r7PP1epWZ43U6v2RVTxKmDSEKmzAYq+MTJ4rFJK1oKVjAAyupjvWtAkHl43ToNOPDKhIfLyvQcL/b+qsA/s2+dVZ1sa2KTR8FKW2EivW9zvUVIbNmKclxCpFZOIDevdjU3SYUcGOLCWS5vIpClp5tLiLcTh/hOS68ZR4E/oagR2LBV2PAEdt8iBOKrsGII6hqCOJKhFbavYNmEdsKAyZn46y9yKYmZNfZTNrYKXZlbGvWn/wtM5z+Jlqfw3246XZvBPYFFLbDm5Ffa5cXwfiBepsJ8ntJ+kS5nWp/LC8VhemKo/IiVaH84K00qbLmNF3ktY35klw46F4eZsB/5JhX0TFfZ1EiKZ4s6QEmBfP8mBfae+RtaBZVSvD8MYS9U9rgp6b5psrsX1Bv+XSjwMxltP0B8nPCUVsIxeaD4wX9c8D0biPBj2dNQYuoGvZ8BI0T0vgwdL3vUSXNd0sXovZtTMw6RV+3FDZ35uF0K7B6H9qhXLJrTF+1Fp021qhJoCsWyp5vfmjpIDu2uPPl7Alov4Uh0RpHXdE9hyM8tNXZRdSWAfOXKMsHBnVAiUuvP4xQoCQlRxswLx6KLsYjeOpbIDgiJUZogFwCBHuBrkQazoR/tz+IUKs1pIhNefQbXACHO52/6vAvvgoUNev4ec46Qmlwb2pUBWUhszfpI6l7IfcbmuZbgwywoCW67LrOziiga5ze60skrEJfPHu8H9agR2vSXVEL/YjvhlwYhbEoTYpSFU3IGI5LzIhTq2XWtRMKrPD4QjPwSrD65A7qfZVNZPo9u77oFMyudXRKVZkkXiQIW5dpTOD8JjWRUJ6gC8nB9MsIfiOS5Xw5AppU1oywDAhLXUH3lEikVN10pbYtr3ZQXjnuxg3JEVQqUdqsaIvDnTiRsIbJso7REE8LBHqLgDMGaHOyS794eTMEY/D78pXGfYi3DMb4sH06MJ8GCCXOdzV8htz9cyUnsg7hsdreaJGbHusq5PdVpI9byIqnohgt5cjaC3Cd6WhHkzwrlqBh7qvRRGkjsaIfFsW7e1uKbrJiptiWXrND9b362w9ZcxIIuIZcugva9vQ+qHUkivaPMCdt9+g8wBP/VFKJ1TFix0d+csyuRil96IepuLA1tugsLAvvSNUZQJJAQW+obxBvaZ06cRGiE3k75ZZLkMd3Upu9iNY410MS09C5FxVuyyBRIatybkLv54L1kFOq2P++V2EmpKn1Y4zv9XA/vIHwLsC+oPzVkz2rVfmUpWzqXsSgF72IixXgpb4LzWY3zFooB9KSHx1fHjHiERPjXxzziufjNzqbarEdiJi/yRsigUSUtDkUg4Jwi8F4UglvNiOI1e6EDUfDvC5wUieF4lVM5/BVVnVUDA/EoYss1dx7rJiiYoPydA9Y6sIp1r5oWgwiwHXuFr6WBTZoZTFY8qTaUt3dmfEpcSrbnheJjLHs8Ow8Om0hZo35cTirtyQnBvhjRChuHO9Aj8k9C+hVNj1JMwRhLYfG9MkRKv3m1DxkAun+iPZ6YnUcU+DzUquzRAmj0f5c42Br3IZWVQaWYbGB1Kw+jVlcDup5ZbZtjTYDQkpEV1N1msFHbFt3SWiFFf3s9Hu7w96n2Dae/BaLeC+1pOta1T/Yw+G2HrIwrbHcvWaX7iEsumK2CXUGGPmzTZS4nIRdKpSy9zadFWMCRyMWBPTctUqVzW/uV16rRMc+nlmQJ2zYLA7m0uhRoiysrIkHUkf/awOfx9cY1cJQVEdFyiWlffjIQ2Xyc30I1U0igqbvWcq9+0jQsWEuOPa9QKEbU14E3R7rKSANtq9Kp2CWBb37HLq/2QkCKA1etdDNgHjxzlsRUAdhFDhF0OsK1G4kr+oV6/hzQCHzQ7PP3e3+NSJvnwrs+m14iKw4cf6BtL7HKAbZ3/rJxcRCdYOeW6TaJNu05qmWVXJbCXVkHK0kB6CFKosBOWhSJhCVU2PdaMbddZGIh6SyMw45NMOObqBsnwBYRv7rPo9V5P9HinK5V0WYRI78jZIYS2XUN7bjDKE9rlZkYoaL9Cpf2KKhxlx3O5dBnsVxWNslNpO/AwpzI6+31c5z8y7Fi2XdXTvic7FLfx/S0EtzFe95IUM8ZVxnVpTs4rjbAF+rfI+IzQHPwoNnwhw3sBr2/JILwrENhcT6A9ojyMCVTXY/yRvMxdnvW6/nEE7Ov4d0d3W4ZRJxMV+29Am0wq4cgclGpDdR2fh1V7v0A5gttoRzjHL8a/eq6G0WYFmmXpdMWnBxDWPTfCr4+ERURpW7FsE9hvuWPZRr9dSP3A6plb2LyAvWv3B6ge6a7PIFN7jWjs+fgTc43CphR2FBWn2kYa/wjsMUWrwp69CY/6Gh7ikfWSsHxF4R5/JbGiFbYb2M3bdVWZHPqzWqhRSKQzxsUsvkSAOI9ffvmFCreGa13rezdprodPs6x9p66I9si6kZu3fNUg/GQWECoIqqKB7f3nZwEw0FHTtZ6ko1UMsKv5Bc0pDW4uUAqwdUNqUbZk2TL+Gbk7tggkOnfR9Rksu1xgW4Br0a6L1+8Rzz+uuOSGallxVrLf4+K2jtdnzWj5Tu5zUDHAyjbR5/+yFfaF83CE1UFiozbqT1j9/gmNMTnV3fgldlUCe7EAOwj1CepkQrv+EodS3Il8rxV3GCrkPGKuDcz5NBf2uRVQfb5O/wuaHYTgWQFwznXCMTsUAZz6E9gBKk9bK22BtqW0pQaJFI56TmLaUk87PwxPE9pP5DrxUJ4Dj00Pw0MqPCKhkVDckysj13CaEYbbMqsTzmbcmfbq9vGE78u4e1od3JBOIL/5b0K5IkFeDV22uO8jYxAV9xQBtgO2qU7YJoYQ2CF4Jtvd6LhwP0HaLRlGpzeprAfBiJ6hOtL0nb5dLW+WTjVcfwFsrRdxupCAJqxbLELX/N14Y+XnuuZIc1224MiPp2C0Wqm7rr9KYEsvSAG2xLMlN/utbbAN3Mk/Fnr/95G6pyTAtkAQHIHkxu3URSgXiMBA4DBixGicLKK+8M5du1E9mpDnurJNrFy4GYUf9yW9qgYfiy2wy4UcVjtGdYP/LfbDDz8grJbV6FMY2PMXLFI95qzvodQtlWZ8QkO8u1WXRCxo9QkU3SFC3xjBF1GjP//8P9SIjlXratf7j6qboDpXJDXSN77nclGv357UA0AUZadOfeuVXibAnpLq7ixi2aAhI1SvUmvfEhtPTCkcE5Y85BjVSKrXk/1KT8JTpwp3ff3iiy9U6MaCu7g8GQwd6d01/vJDItpmz1tAKLrLoKbwcyRtNKpuIjZt0SlfBe1yfo+CdvLb7zBx0lQEOt1/bNZ3GjBslLmWtvd37lINkdY6MXzymznLu0HYsrkLF8EufQDUPs1ri6/liUd6wnra1QjspGXV0GhxEBouDUbDZcEEtwN1l1ZAcPZ/ETb/ZcQtkc4zL2LL4XX46cyPiJ9TGzWWBLqySHS+djDsnIbMD0bo3FCEzileaZfN1yPZvEJYP0/F/UJuKJ6RmtqEtIRIpGDUowT0w1TUMiK7DIIgo7LfLXnaWUG4MT0Yj0yPw5idWTCmViTc3aPQdNw8hgCvBL9phPPwF9Fg1VsImdmBoCagVVjEw6WA1JDSGL09S2279tD7hKk7s+xfrQjs5Dkwaubj259/weI9hHL8fPi1WKI60NjoRutleLG/jmNLnRGj4xoYbVcgOo3KueNqlB6xEw9SoRt9NxYdyx5EYHN+6p4f1D6KMhewLbW3eNlyqjKJN+rHfesiiSMgwqpHoVJQKOomNVSP2UotN2hGpWF1Fac3as35DVWesawTm9IYlahopIu4ez3uk1NRqZbFEfRJKU1VbzS174s5PzehfmMkNLaOsTCwxRx8OtAA0p8pU2kwrBkTD//QCARRbUoWgipCRDjEN3DfhOJyE6mMBt4snp+vhkRr1goNmrf3Wl/tn99R/sB0D1Brvt6XnNMmLdvqY/fYn95nE3WsVsOkuJz3mnWTERuXxG00vBzhNVA3oZH5B2muR49r0hjVAsNRT+qucLvgYCfqJvJ7ea3H89S4rapWKPVMkjkvifOq2iNQvXYU4ng+tWLU69cmTAtWGPytwBaTMgA6vc7j9+D5qhWTQFFQQxVsEpBf7u9hucyPiKqnar2EUxzEuOqC6O3F5fzKcHbqGuI2SQ3p/BzPPyp5ncAngKTkRlxHg7ICr+Gg8FqIikvm+XULGpnKn2f3Xt6hI7GrUmET2A0J7PrLQtCAHrekLMZv0R1M1h5YiFrzyiNpsROh819AcP4LqLWkGqIXhCJqUbBqlJTwSA2qaOkZGTZXoC2V/4pW2uVUbW0HXuZ8qav9vBSOypPRa/To7BIeUfW0Ce2HcsJwP6cyco0UjLo7x6mgfQf9H9JxJq0qrp1sR/hS3W/k7GkdkjRGPUuQB1NBv0x4VyWc/VFqchgBLZD2APZEAlv87RdhDKtGwL+Cf06yYuHCxgswQlJh1OYfQ0AajLr58Gu2mCqaCrv1YiptArud5GKvgNF0gfl6OQYv+YTQXgWj83JEZ+pa2kbzZQrYnrFslZc9cBuM194rGbA9rWfv11RaXIIHYK2LRS5AuaAFHuL6QndDRq/vuVyDyr1M70NSoBbxz8GyOAE8L0pZ39r2Yq4/1zq2ooH9HdVsVYJLClPJsVvrCsTkGGSe5z7d+3O753IvVzdY4fXlXHhC0tv1oLDKC+xPvrcnrC2XY3Sdb/lM1/cosB4Vvf5tuB+u5z7nBdaT72/+jrI/va7+HE9YS82VsOp11Hm0wjBivwfY3317ApX5hx8vx+o6Jn2+9O+hj8k6J5f1e5iuj8uqJVK0e16/6hyo7S6+jjxpus+pXl8+Iyq+EZ8S9CC/Be2KAbvnnwfs+kuroinVdaMlAWhMj11UAfmf6uJW0z4cjdiFFVF/SRDilvF35HoxiyVPOxjR8wltquraC0NRnWpb8rVVr0jOC6LSds7mH948b6Ut2SNSf6ScFIzKt6P0rGA97BgVtowXqUavoeKWUdmfzKHKnh6shhtTY0RKfjaVdqlJUm61LG7IDMKtXGaMeV4NL2aZZIg8PiMZn536Gv/NrKsaJY3UUEKc64qbwL5WFPbYKmi5diiV9kswxnP+gOfw/jF3L28jLhWb953ErG1HCO482JoSyi0J7BaLYGullbbRnsq6/Qr4dVqpQiYSEPz4yx+5Dt+3WoXm+XuotteqvGx3LFvnZdsG7oDxquRhlzCGLXbmtC75mZEzHYFB4eqRWtLirAtWLpjf5npbufCCnLUx4G13i7JYgnljFN6uZC7j+XXv6Qa2FTs9deoUYhNTIEWVRLnpi968oQvso0gAN7EA99e5HIMCtbg6fnEpP9pU5YWrDBQZwd5zPdNlPYGPFPqXEIvAqbjvL138ZV/yNBRBFW49dXnG2gXYUh3QWj+8ZsmArYou0X795Req7OaqVkjB30Nq03gdj+fvYPnf4PeQcyRhkypBTvR73V3WtmCbRNWQCFW4SraRa1uu8aLsksDu8ZoKH8ky2Z90QvqjrP5yfzRdZkfDpYFotIy+NBRxC8vAnvsUoheV4XId205aEorEJSGIX+hQ0I4mpKOprqMXBaLWQjvqSI9IKSA116GgHUqFHUyoF1TaZQnwsjPD6A68xNcvzQyn0pbMESeepuJ+RsaIpPp+gor6YSrsR5TSFmgTsJPcJVTvzaqBGzOCcEt6IBXyE2ixaQjuyooijCthyHYzREvdYQx/hsAmjCWG7QFsY4I/Kufp0gdTP5gLYwT/CMZyfpe7MWDDbOTsJEwD3L2+s7YeUGVXjRYLtbei2qbSVsq6HRV0B8kQWYF7uy3Hir3HuQ5BLjWyGy/EtRLDVr7RFcu28rI1sEvY07Eoy8qZgca8UMr72xEYVhPh1WOovOpepsfAzsfJQD56d+neW41cU9BCI2JU4Xpnkdtf3GUbB9Vg4xbF15rYsWsX+r35FkIiIhHgqI6wiLqoXivO/Dx+ds1IxLtCLBoOcoPIIAQycMJvOa4r4jVieAyJXgM5yEASUly/dYduWLBwCVq17YCKVR1qfq2oBK4r6yfydSKCnTVUg9qGzVswbvwERCc2QpUQp9q35/eXkrIVqgahdduOyJ813zxrhe3NQUMQwH3KNnJsZSr6Y98+7wJJJTFp4H5z4GAEEz6B3J8jLBoRteqp43HK71ErUj8Zmb/FX/17OCOiERJah2KjBlq07YzM7Ok4XQDQBe3pF15yXdMylWu8KLtUB6EmrdoixBmpjiOc5/y5lyoTPlqQXGlrRGA3J5CbLgtGM3qTZUGEdgCnIcpFXTegW1kk8ZwXuzQIsYR3FAEv3dmjCehaBLZU/Ku5IBhh0jOS6lpi2oWUtsrTDnEr7Ty7qqktSvuF/FA93JjqWOPA45xKx5oHcxx4MJswnfQsTki1PFqf9yag1FQp11oP9db1JbSfw/VpwSiVFkbwlseJX37C/lNfwhhZ2hvYMlUNkPShz2D1wV0YuiOXwK6Eh6fFkvHnUXfmQKrnOEJ3CLLfc1/rRmiaConYlAuwl8DWdpmpsiWGLdCmspY4d5cNCJqgOyEazZbDJr0f+26CX4FYtvHqFqS+f5khETFLoRa0z3lzHjp8+LJ8/4ED+EUNblm87T94kOseKrRtSf3AoQM4crTwaDEFVY9l3373HQ6ozzyMg1SI0oiZ3FjXsLYAUSs6Ae9te0/tt+Dn/Rl+kC4FiDa/8w7Wq2HVNmHtunXFFtf6guvKOrKu8g0bcerHoseH8/z+Bw4eUt/f04QHRV0D3xz/mr+V+3fat28fVfPFf9uS2M9U3nKdWN/71Kkf0LC5DvF4/h7btm/7038PKX72zTfFNxYXZ5/t/ZzbHzH3c0hd40WZvUYd1x9TUcA+evSY6nxkHc/ez3VDfXHX9u+xhiawmyhYB6PpihA0Xh6EhgRzY7pAuv6SQJfSlgyShKU6X1ugLUo7irCWqUC7JhV4GMEdRvUtDZHFKe1yorRl2LH8MJSeFUqlHaaU9rMqP1vCI048zunj08PxYK7uDXkfFfd1E8uix3tjcO208oTsU+a3AHI/JTDTKuA6GStymp2gfgky+roxlbCeynkuhW25CfERXGdMZXoVvLHBnfUTkNqfiph/BLEDMGHlh9h+4BiMyDwCeyFszbRLLRHV+EiFbbTXbhNod1qJ66XXY33pJXkBt0qmyKu6F6TR5x1dGMqq5tf7HaR+UMKOM/+/W0hYlLphrBtHGi1/PFX8yfPZH2tOPgVZsJbfI6xmDI5/XXwFvavVAkPcRcXEgxy6Md4KI/2Z1mR5FTQnlFsQ0uISzxa13ZQquslifwVtcYG2l9ImtEVpxxPadblMQVti2ouCqLR1yp+TCjvMVNp2GTdSxowUaNMrS9YIpxVmBhHaDqW0pWONDDf2HJX1c1TaMhr7kzlOPCaZI5w+KCOxZ9txa3pl3MP3xlidbmi1uRjDniaUq+IGGZFmYkVcOyWc8OZ64gLtImLZLoCPD8Y1o51qP2ILDu6kgo5Hr/mrEDV0NYxyU+DXeD5sjRfAaEpYq1j2Yncsuy3/MCQsIrHszvQua2Hrvk6PA0l4l+rxLl4YRUB33IjrJJ5tlV7ttR6pu4of7d8HbNP27NmjxhVUsV8TEJUC9A9W3NOGz/44++ijj1CzwO8hWSRi/5d+j5WrVyPaLJ6mvqcA26kV9l/xPZuuqIYWhG9zBWytspXSXk7VTSBfTGkLtJOptOtJBxtXTDuYStuJ6nwtsWyttEPVCDYBptIWYFeb5VTQLk+lLaPWlFVK26FCI9ITUsW0qbB1zRFCOycM92YH4/bMaqoXpORn35oZiIoLdXprxoFVBPh/0fMd3Sekz/Z0GBMqFAa2pbStjBFpfOTUNoFwH18JL07X+2u7chyB6s7T7jeHAI+ZCYPQNprQqbS9YtmW0u5ohkYIbAVtGZWmJ73zeoxf/ynm7/kGRjcqbqWwJYYtwP4TFbY8pnlmFWg7z/lFXXx/3Y13/ry3elFphw11S7zEsaURs2Xr9uZSn/2Rpi8X78f7OvJ7NHD/HtKTsMElOj79/c37epcxUKWjlGe7Sb36jdH7tf7mGn++NVlWDW1W+KP5skDlAm1R2s0JbXGBdkmUtiumbSrtOgsCUIPq2q209Qg2WmkHUWk71KjslefojjVl+LrMrBA1sK/0hHw+145nZthd+dn35/ijxqIWeHPHFNgml8H9WXb8OysEd2RIr8VnCOeyuHZaIIIX6AqKX/5IME54UcNaBj2Q0IgnsAsobZsAfGIYjJHlCVIq9bGEfe8qal+nzT9So+YsGEl0yc+W0EjzRe68bDOWrRofLZXdlX8i3dfTBdoblQLvv/gDvqbClk40/amyu23BlD1fq/0XZX+Ywh45eiLiEhujXZfu+J/Zs09s8NDRqBOVgDcHDMbpP+GRT46hS7c+yM2fiQ8+/NgrxPHVF18gZ/oMhIZHecFB1FyN6CQsXOIeg85nV8YS6zdD+449kJ2bx9/jQ6/f4/jXXxf9e3BaOzYFs+YU3xj6d7XMnBw1wO6nn7iHEDt/7gxWr16nYC1tJrrdRF93kke+Zp2uT/FXmAC7NYHdYkUwWq4MUg2PzQltNS2h0vaKaS9yoi5VtVT6q7HQUazS9p8bRlg7UGWuHeXnOFGGXpYQt3pCviBFovIJbZWfHYZr0/6Ln8xyqR02vYU7MwOojp8jZJ9TtUbukOJQWQTy5MpwLm6PR2fEw2+aQJpQniagFmibwPaEtgVsyckeXRltVg03u6/bYQz3R4+V7tpHFfovR4Wey9F0ItV25AwYzRaYjY+LdSy7LV1qiYjCVsCmSyyb0L5GRqWRno/0a3pRYb/2joZ2dwH2ZaT1XQmTsfukNGuipDKlNFVDQ4l17NFLdX2WhiRJi6oRpfNXCyvyK2eS6lc3qTFiEuqjOm8Gyf8ODqutXHoV6t6IlsKRm0antoXXdlft8tmVM/k9pBt/TIL8/nEev0ct1Y2+uN9DasFcjZaRmYuadeNVyQcpeBUQWgP2iEhzrFENaut7Snpfreg4c8u/xlosp8Je5o/WBHPrFSFouTRQuUtpKy+50pYSrVGLguicqnQ/T6UdAuccqux5wQghrAOorqvNpNKeaQ3sa0dZqmnpCemdn23HfVTY7dfoanoB8xpRVT+J/T9o0N2Z6Y/bqbSldrYMeOCXGojrpobgunQ7StGNVCpnKzQiKttTaZvANqRzzVs6Jr7t+D4YQ2WoMq7X7WVEzk3Fgg/3wKgxEvN26hS8RmMI3foLdFjEM5YtaX4CblHZHend1iq3idImrG2itPsQ3DL2o6T4ddmI1N1/MrClzoK+4ehNzC7Z351ElQCHyiO1bsaQ8Dr44mjJOl38VpPONNKpRt0U/FxRMZ7uOk5zmdw0VYIjcPKklEz960I2/1fN8/ewzvnFf49mapBlq4Tt1WaZZoVK97Vn5sAX+p5a2PyosnqufPZHSa25KOzl/mhJYLeit1wWxPdU2HSltE1ol0hpc369RQ5zMAQnIqmwIxcEU2k7UYMK2ylKe54o7RAC20mV7YA/p6K0JTRSbrYT5VRPyBCUduVnh+Fpqu5nZNix7Coqte9ewvvxGe6R5red3Mv5L+Haaf5Uxq/gH5lO3JTuxPUE+DV0W1oEYU0oC7BFabuAzXmesexRFTFqh64pYwx6XnWoGb19Jh4c0ZkQFp+Iaq/pethffPctVfYcE9gesWxJ7/OMZQuwu6/TDZA9OVW1RQTaki1Chd11M1I/+JNDIkmNmypVlNykORo27YjKQQ4131k9SnUQaCCdPBq1Q5VAPf+PtI5deqKuOYSZu4OGp+vc63opjVVtk6h6SfjZzO302ZW3Ev8eyY3hrF0XUXGJ+P77qzdTJ5MKOza54SW/Z3Tc3+O6a7GiMtoSxG1WBCsXlS3eiuBuuSTAI6ZtNkpeQmknEtZxS4IRT3WtRrDhNJKArjk/GBHzQxE+T4YbC1SFoiQ/O3AWVfZsO6rOdqDSHDsqUGlLI6Q7a4QqW7JGckPx1IxgPDU9DI9SfRujnwHO6Cf1D775iKB+Ek1WD8SXP5zANVMrqrEgb6C6vt4cC9KW5oRN8rElg0QN5EtFLa7S/kylLRAfWQHGgKdUt/Wb+d6y+4b3oBoeCqNeOhqO3YFe+dthJM6FISl+nrFsqehXRCxbKWwBdw9R2VJfZBNski3SdQ2m7ChenPwhwN63fz/KVeWPUjeBqsGBoSPHqPnvvLsVFaqFqlCIVJfLys1X8/+IfFLLpkxLR4NWbRHKP4uA0Oqql5gU05eejzKythS2kuHEXnv9TWzh8Wn76xTO/3Ur0e8RVhuv9u2HDZs2m1v9cSGzP9pyc2fjpUoBCOF3uvT3/OuvOwF2aw9gW0rbgrZLaauY9qWVdtISB+Kkt6SptCM5FWjXlF6Q83VZVgcBLvnZQQR4EBV2tbl2upPAdqgRayQ/u7isEamf/cgMQjsvFNekVUC/7SNxhyjpqS9jzgF9XoftyiOU/XFDZiihbY4FOS1cQVup6zQ7IW0Ce4oHsOkqlj3RgVLjud7A59X+xHI/ohru1pWQJrQjMjmlum5EZd10vq4lQmiLyra1JrjbEtxmPrbyris1sHsIsDfCTwF7M4G9hcvWEth/UVrfmjXri6xOt2z5Kpw7a443/yfb2TNnsH/fPhw6dAjHjn1hzr36rGCWizQDXI3pbv9Xfo+S2NXwPVutqIIOK/3RZmUI2tItcLfyUNqtVFikZNkjyXydzG0SF4UgbnGIGgShzqIgRM/Xo7LXosKuPp8qu2B+9iw7Ks8JNkMjUtkvVJdjLSZr5PFsBx6aHow70v1Vup9U9Lt+ajVsOLIDpefWx82pdtyS4cQ/qKivLyqWPVXe0wvFsuU1ndCWocaezWmqztOyvbsJ5iR8/+tPWLjzIAx7Fq5tMhNGEwmJLEIps+ejnxSFEmC3o8omtBW4RWVLSERi2VTYRu8N8JMRaURhd9yEKbuL72vwxwHbQxR5NipeOO9+fe5PBIwFswtFDJj7dwTd3s8/x9PPv4SqIeGoGhyOF16uiKXLvAdE3rh+AwYNGYnJU9P1jD+w8fZK29X2e/xWs54er5bv2YoKu93KAAVngbaX0uY8iWkXVtrFZI8sDkTyilAk8b2ERqRTTcwiqmxJ+Vvo0MONUWVLzRFnwawRiWNTaVeZG6qyRsrPcuKV2YR2gayR/0rWCNX3rVPL4JZp5QjtCPxnuh33TA/DvzODCN+yuI3K+vaMCDXgwW+KZauONFw2gT66KoyhFXVFv3bukab6z34fRvxsApvqutkC+DWjwm7pURRK0vw6LIOt8yoYXUxgdyewRV3LaDQy7qNMO2/8i4Dts99lhw4f5eNzPdVIKx5ZN0WNn2nZ3PmLEOCsreo7S+ZNnZgkc4nPfPbbre1yKuxlAWi/MpAeUEhpu2LahHWrpYGXUNrBaLA8FPU5TVbpfiFIoMquS4UtSjuSU0n3k+7rkjUS5soaCUHI7BD4zw1CAEFdhaCWWLbuuh7iqur3gmSMzJTY8n+x7esPMO/ASpSa8gweyCG0s0Px7xwZcd2OOzNCVZjkVvrNBPaNGZcZy5bQiIB7Qgj+NTVSl2AVxd23Jlbt+9w8c+dgOLNgSM9HgXZzcWl8tLJFdKOjXwdTaUsnGs9skV4EtzQ+dtyAKbu+MvdZ2HzA/pua1KBwj6jTUhV/kpFRLIuOiUdyk9auxjsZ+ssaAs1nPvut1m5FNXRYEYi29PYrg9BaYF1QadNFaUu6nyhtaXy0lHYzLpNu7A0JZxUakVi2TJc4CGxR2XY93Jik+VFhRxLcMvhBdaprlTVCxa0GP5hDlT0vGAFzw1BVYtlU2mVnh+uqfnN0Vb8XCOvHqKajl7g7VDVY8yr+lVVVjwMpdbPFMx1qxPV/ZjlwS2YYbuT7G6Zdbiyb897QaX5H//cDjIGPUm3Xoip2DxxiRGTDaDSP0Karno+6u7rKGFGNj8vg13GlBnZXgbWo7ALZIp0I7Pd9wL7qrCCwZdxMKexkWd16DRDfQGcayDohzjpFFr/ymc8uxzqsrIzOVNadCOuOK/wvqbRbrhB17c4eUXVH6FIwqvFSfzQguGXkmhSBNl9L1/X4xUF0GR8yCJGSp73QjloLJZbtmTXicGeNzLGjysxQVJwdjPIzg1FmhkP1gHx+ph3P5AfhrvTy5tEDyat74t6sang406ybnWXH3dky4noobqPCvn1a2G+PZQ97Afu/Pak+xzaO88YFweifSEg3gdF0LIwGc2BrOF93VxdXHWmk8XGRHuBAskYKZIv4dTWzRVRONlV2x/VI3VF8G4cP2H9Tu5TC3rZ9J8r5B6sa1zWj49G4ZVtzic989tutw8oqhDWBvToYnVaJ0g66uNLmPIF2M6pqleZHOFtV/poQ2gLpBkuD0WCFQ0E7ZbGuOSJKO5rvJT87itCuRcUt+dnhVNeFs0ZClcquRNWtao1IPDvfoWLZL86MwON51fBSbg0029wHN6c+h8dznXh4eriqm30foX2PxLRznLg9O+zSseyCNUYsYEtIZKId/5xcHQsPvkt1XQ3GyMroujYdfVZRTTfqhVLN82HUp7puOFcXhGpu9Xw0q/i1dVfvs7JFFLAlW6SXmS1ytQFbGmJK2vOxJOmAan+F0sJ0Y88fmU5YUlO1V4pIW5MY9sUUttixI4cwcfI0zMifq95fmR6jhRvCfk/j2OVuq86H+hre28k5upzfSz73cta/2Lm7nP3o4y+8L5l/uefC2s2V+V1LZh1XVkJXKusuhHBXglqgfVGlTWiLt1wpIRF3j0ip8idhksZmaESgrZQ236v8bLNIVLwobFHbCwNRh7CuQVh71s+2ao0EzJJaI/SiekDmh+Kp3GA8nFMNT+Y68FhuiKrm90COHfdRWUtFv7v5+i6JZWfqWPYtmXbcmO7AdWlhKCUlWCUsUlSNEZmKW+CWLuojyukY9gB3OdfGuQR1iwkEtqjrubqKX7OF8FNlVxfD1lLCIkt0JxrJGum0qshsEaP9Vaqwd76/G9k50zFs5FiMGjNBjR4+aco0zJozF9t27sRZc2Scktqxo8dUStX+ffvN3mR/L5O60pK/btnXXx+/qMIuyn4PWD1N0s9kBPd9Zt3lK2GHDh3Bgf0HXCMaXcpkZHn5rVQa3NHfngZ39MgxbN+2A2s3bMTa9RuxY/sOfFdMR5wvjh7G5ne28o9xM9asW48vvio+lngpO378G7y/azc2bt6C/fwOv8nO//mCQoDdZXkAuhDW4sUp7daEslLaZmikhQqNSMEoHdNWKptuZY2oMSIJbSs/W3eoIbCtnpDSACmNj/SwRVb9bJ01EkilLbHsyqoXpHcPSIllP5pbTQ1yIF3WZaCDx/LseqCD6Xq0danmJ7Hsu8xYtgwldmuWAzdmOHFdRjiuyZS4NaFcsMaIUtiWa2BLXrZtAl8LsIeXRd6na9V5+/70j1TWbxLYuZwS2o3oTebrbBEBtjQ+Shd1s+djkdkiEsO+WoB97qweNHPilFRU9Q9F9ag4VW9CHvnFZaDT2KSGiI6rr0IA5SrZsdRjTEjLzp792XwFpKamo57UMglyIqxWXdVpIbx2DEIjIlE1OAx93hyCY1+4U2g8lZQUn3/qufLwD60O/5AIlKvmQJ/X3jSXFjZZJuvIuv72CLz4SjUsWVq4eNSF8zr//KNPPkX/NwYg0FkLQc6aulMFXTqT1KybiBmz56Bugnsk74IKe8HCRUjPyEZWdq7y8eMnCrHNpZc2rQT16x/4BzZ4xGjYw3UnIquDh0yr8ftUj4zHyLHj9Mq080WApKAKlWNq3rItKvo7VKcRdf7Ncy9dsNt06KzW8/yTkSyYtp17qTTG0OqRan3V0YTbVg50okGztli4eKm5doHPNNPmVq9dh35vDkBEnTh1LmXbmlHxqB2TqFxeS0mE2lGxmDNvIZ9O5qiBpKsEhanaMrV4bdWum6DWlQ4ulYPseHuE9yjrnuZ5DF8fP47XBw3hvuxqCDSplSI1deR7SHpmdHwDZOfOUOuKai5KOUuBq2Yt2qASv68cp5w7GSQ5LjEF09LNoa7+QOu0qjK6UUl3XemvvEilvSIA7VbZtdJW4CbITXBLwagWLnAHFZ2fvTSwUNZIXapqycuusyDQVWtEskYc80IQTKUdNIf31twQrx6QMrTYfzJfwbidqQiaG4tHZgTiGUL6SelQQ1A/kmvHg9lOBez7qbL/ReV9V2YIbsuw45Z0CYuEEtoSFglVGSPesWxCW5S2QFuBWwNbw5vzBdqitt8ua545wrRhJzzQYwaMMEK78Wz4NddxbGmA9DMbH/UAB0vh10HnZOtskXXKVWGoduswdcdVktZXOyYedWKTkNykvWsEjqJc0tyqBkSYWxW2tavWqm7vdeNkJHIZf7BgF2g9komkxAk8Ro7WNXM9zTOtTraJS2mGMeP0YKRFmSyTdWRd2aZO3eRiFXG3Xn0I6ppqhPOCXbTl+0n1tpiExkhuqBsVZV5Bhd22c3dExaQgKrEBovlHVpl/cpdnGhZSqEvGHoxLaoqURm1cx+F2OVfN+OfRDJWr2XHk0AG1XXE2c+ZcVOIfV0xSE8TVtwav9d6n/MYyZJllp3/5GbVjE1CDkJXRzAuub7lU8NOjyDcwt/S2lCbNVXmBuPrS9V2fS9nOeu05L7FRa0Tyzz+S+0rkefb8HGsbmTZo0gaxCU1QLdiBEyeKH3Xm7WGjUIXnMT5ZroGizmNrJPH4I+s1wktlq6ptPGH/wQd7EGB3ok69BkWeNykvKwP+VvZ3YskS73z8K2mdVlUioAXY2juvDC6ktNsR2m0JbE+lbXWsEaUtwC7UE9IMjUg4pAGhnVIgayRmkR2R0nXdVWsklCrbDgfVdTBhHjzPiYB5Dq8ekC/mU8mv7mIeOXDTpKfxzIwwPJnvxBO5YQS4gyqbUM8jtCUskh2Cu3McBLYT/8wMx01U1jfwtQJ2SWPZAmwpAmWp7DEBMAaWg/FGfarqruo4/kfxaQRnwdZIl12VbBG/llTYUsVPlV0lsAtki6j0Pknta78OU/7OwLYU1qChIxDDC1LfVDrzQQri1E1qgKiE+ogmmOS1VP+TAUlbtemgtrPszBk9TNXYCVMQElGL27thJ/uSqdQxcZeztG7KVqqS2rgJU9X2lnk3+rVQI4XLALTFmedo4rLfgor4/Hn9BCHqWf4orGPSx6CPTYCkj1t/prWvovbnVdSK24SE1TKXlNyaNGuNqLgU13cs2q3jlM9pjYrVgtXjvlhBVf3W4GFKlbvPvd5e9i/zxBvxM0W1WyYQrBLk0L9JgXPiWWLVmi+v5fevyc8paN17vqaumYLbyL5lXzJ1n3fvfcqxWetJHRz9Haz19DVjp+oXO28+JVnWo3dfqvJEcxu9vrU/fTx6cGnZXz0C/Y0Bg80ttU2aOk092Xj/Dnp9t3DR82Qd+VPq0+91c+sra51XVkZ3Kuiuq/zRjV5QaXckxDsu91fQlpi2qGwNbW+lrQdA0PnZLeiSNdKEyroBoS2xbCs/O5HArkeIq6p+VNtR0gNyoe4BGSHxbKmbrar5mXWzVSw7FJWosF+ZGYQqs91VHP+R+ryuMSIj01BNe8ay71d52aG4N8uOO7J0xsjNmXbcnObEjYT0NYS0TVS2xLIvBWxxAfZ4iaGnoNQo6UyTQHXcxjwSIGEM4Zsyl0qbwG42/yLZIpy6Gh/XEuprkPq3BrY5mGilgGBenG3VhSkXZQQvyjadeqn6yFnZM5BNn8wLu3XHHqpOyTiCuaC9s2kLgsNqqsJS1gUuN408FjtrRKF+0zaqxGXN6AQFh/qum6CVGl3mJ4/iO78X2EXFnBs3b6MUpLWOeDxvaAmJSPgnhUCsykfzeLWOdaNqL7i/gsCWPOzLsc5de6JuovUHqUEgoadq9up8UqA6pstrGdncExrxVKa1YuqZe3Hbzt27ERRWxzxfel1rnxIGEUiLBzpqUCk2NLcCf48a3Kf3n2tUvRT+Hg71e9WmGpeBk5MaNnOtI9Oo+MYYM977yah7j74ewNZPOhIWiaKSbtSiPUHcXNXw8PxjEJfPrBkdh/A6sWjSqoP6HYO4nlw77vVaqBDHhrXetaqzcvPUdu7vzT8aHquzZjQiKASSGrbgkyO/Q3gdnkv+1nY9ao5lElsPCq+lFLX1OTLV5YfjlJiISWhgHov7HEVExiIzR1eSu5LWeWUlFRLp4gK1p9IORge+7kBg65h2oIppSyeagkrbyhqx8rMbcXljAtuKZWtgm7FsTl2x7AI9IMOpqkOpsouMZc9y4tm8yohb3BzPUG3/N9+u6ozokWmsWHY4HpJR1qmw7yW47yW078x24vaMMNxCiN8yLUyFRa7ltBTVtupAI8C2ej4KpAXYBXs+Sq/Hwc/j+7O6Tcbo/wKMPm3RKHueej905scwEmforuoXyxbpsgpGNzO9T0ajabP27w1ssc/37aMyq+e66OtSUc+ee/Fi9acKDBorJqOh633oC1tuEKn29kWB2g3btm6FgxCIb8xHV7UuQUTlM8gjVnmlFfbGzZvgrM0/DS6T5eJR9ZLRqVsPcw23dZMa3vGedaEvrbAvB9i79+xRatE63zJ11IzC0JGjzTXc1r1XXxU2sI5D1pXfavuuXWq59YQktc/lKUGvR0XauB3CIuqoBuOCkXVpfBQbOmK0apvw/OP0D43AgsXesf/Tv/6MRk0J/xRvaFcJtIYM03VVunkAW45TCkwVtAsUCDXqJPD4PM5tbNHhq1hC03MQYPnzmTA5zVyqQ0oSW/cEezT/eBs3b43vTuqnEMt+PXMGnbr0xPTpuuDZBbPQk2xv/Q7isbwOnRQV6VnZeP+DPfjok08wY9Yc1KhdFzEStjLXk+Py5x/qDz/K4CAFz/Bvt66rqqDHqmrovjrQ5d343qW0qbLFO6wOQTvVuUa7jmcHuoBdMGvE6lDjFcumsla1Rjhf8rJlwIOCPSCrXzSWHYIKs0PwQl4QXiKcX5gVosaAfHamrjHyJF8/QZX9IGEtsez/TNcZI/fkBOGuLKeKY/8zMwz/yAjFDWlhhLYDpQhum+Rhmz0fbanhhLcJbXFTaauej6Mr482tuizES9ObwhiURBXdBe2y1+PlHoRxSr7Ox27q0fhoZovY2kqPx+Ua2gJvM1tEKeydf3NgHzhwwHyU1hejhAwG8fG6KPNspPJ8vXDBYkTGUKWaN6I81oqyKmjW4+yHH32McCpv/ZmEHuHtb3eXT7zSCrtV2058HNaAleXxKY3Rscur5lJ3aEFGIxGTfbmHLLuyCrtTt15eoQMppm+pNWkIk/NquVgjngNRjdaxCLhGj3Ofi/NnTyPAXkMpWnU8XEdGTpnL30Sbu1CVZ02NatXcsJKpKPGPP9NdfaU9zvMYxCL4lGSBViAZQWW75/3d5lJvhS37c48+7g20nJw8BWPr+9SNr48ZM2eZS922k39KMlK7tV4cf7M33nKHMyRrScoCWNeInKPmLd3DynmGjC5ccJ+Dc2d1+G78hMnqycpSz7L/pnwKK8669+iDaB6r9f3kz+7VPld2OLEuBLaEQrqvCtBOYHddWc2ttKmsJTzSfpUAO0hDm67j2QQ2wSzunTUShCYqlh1YbK2RhKUOxC4t3AOyuFh2VTOWXXFOqOqy/hLhLB1pVI0R6VAjsewZhDZB/vB0B+7P1j0f/01VfXdOMO7ODsOtWeG4LSsCN2U6cL2k9xHYfi5gi8K2m8AWWJvQtoCtqvhxnWEVMGV7HuFdiYo7lgBuTgU9irDOg19DAlqyRZoVzhaxikEZki0i0BZgWyGRvzuw5YaSVnTrhpcLUi5MZ80Y5Obl4n8/uzM/xDxvYstaduiuIGjdXJF1k7GpCNXkaXUJKksd6Ru8DoGpbyzvPOjfprA3brTKZmolZT32yj4DPOK4Rdns2bMRy8d+z/1dKYVdSYFSn2tpfKsTXTjE4WmbN29B7Vh3xorEeVu11VkeYmvWbVJZFdZy1VZQ/+LjLy5Zthy1uI31xBFXvwm6v9rHXFq0ZU3PVeEB63MEuqnTMs2lhRW2G9jetp7nUWqvWPuRAQakbnVRJiPh6GtAt6l06e4+Rrl29FNFC3XtBobWwFmzLaUkFhDifiJMbNQWUXUvXQ+maYs2/N31NrKtf7AeYf1KmSjsXqsroceaIPSkW9BWSnsFwc33XQh0aYDsRIh3WBWsvA1VdaH8bKW0NbhbrrArtd1UGiKprrXSdodGkgnoOEK8noplB6tYdm2PWLZjbqgrL9tf8rJn64EOKs0MQvlZdpTJt7trjMykylax7GA8nuPEI3kOPCKxbEnxI7DvyQnB3SqOHYrb08NVd3XJGLkhQ4BNWBfq+UgwFxnL5nxVEKoyjLEhCMnvgp/PnCage8BokQubysmWruqetUUkW4TwbkN13aFAtkhXAfZqpG7/G6f1WSqkGQEgylouRE8XaIU4I1EvvoFqGLQUaEELcHgoPMKoir93rLAoGzxktPmZ+gYXlb9/v849/r3A9lTEBz7fp9Sg68Yn8Np16aWWFWfv796N6rXjXNtcKYX90Scfe+y3BeomNsGU1GlqWcFGRMukmUHqVlvHksTH8fjERuZSYFpGtrdiTRDFqmN5xdm4iZNVmqa1jfwhLC4iDdLTPtu3H9XruENnovRHjh5vLr2Ywva2DZu2ENjuPxgF7KyigS37sD5P9i2fYVnVIAeX6T9hibHXb6Z7mxZ3Hj1NGludNXVYSv60asbEY9OWd9Syora35u07cBBhdaL0dvTqteKwywxPXQnrRmD3XF25SGB3JbA7K2ALqKXruqT3aWALnD17Qqoa2kppm6ERAlsaIhsvpdomsBuZwJa8bHcPSEK7mFi2U9UY8YhlC7ClIw0BXp5Tq8bIiwT2c1TZVixb6mXLAAcPE9j35zqosHW2yD3TzZ6PBPbNAuyMMNxApV3qt2aLjKqCFquGq3M4ZM0WGE3HwKYaHSUf24S11BYRhS3QbivALlBbRFL7RGH/nYHtaTWjZcSXhiqVygKfBpKGRL3kRlSqYXj19QHqkdnTpJHIurFUyh5vrktZWkaWCzSyrQyKKh1GxK5EDHujqYhXr1vvBQgBzfhJ3lkpBe3o0WP8/BjXd7pSCnutHEu0jCeo9xtdLwnz5y8ylxY2K1dY0hDdcGqu/nQsmzA51Ru+/K6b333XXFq0deXx10uxjr+l+q5ffVX80Eg8Epz85gQcNa0wlj6Po8a6Gx5LDmxR2L8N2KLixeSs2MM0ONX1kdIMbw8bqZaVxDZs4FNJFI+B28t5lfNbUpMRnKzfIjIuGbNmX7nBibusroI+9B5r/AlsCY24Y9nag9DNjGVb+dmitNt7ZI14xrJbEcqeVf2sWiMK2BIWoatYNuF+sVi2Do0EI1TFskMQSFWtRqbhtBLhXX6mHS8RzK8Q1i/MDMELuU7VCPkk1fWjkjFCVf1AlgP35+hsEQmN3Mn3d2dJHDtUxbNvIKBd2SIC66J6PnopbLoo7ImhKDU+HMbAV9Q5PPbTNzDqD1Dd1G0NCG0pCCWDGkhHGiu9z8zHLpgtYrRYjSlXQ8cZSzmPnjAZVYP5D1svRd0gckPom8INJ8lcqOgfhO++0yMzXKD6sHvcWOqRvGlLtexilmWOtyfbyLZXEtieinjdho2FgD2W3/Ni5v35V05hSzhA9mUdi4SF5s4rHthW+EkyRryA7fGHOIrfXb6TtU/5rp7HWpR16d7L1Yiozj2B/cWXF+tZqBWmdCSxzslfCeyPP/kUETUttd9C5Z2Pn1g4c6k4W7thA2p5ALtysLv95FIW7coa4R9uYn2kTbtyHWoE2K/SuxPWAu1uXsAO0MCmwrbys5XSFlCbDZCSNSIZI1Ys21XVj5CWkEhjCYkoYNvRaElwyWPZVNXO+cGuWHagWWOkyqwQVCSwK8xx4OVZYS5gP09gq1HW88PxWK6d7sADVNVWtsh9fH0XVfedVNfSVf3WzHDcSJWts0UE0oSx6vkor01IC7CLqpMtCls60YzzR7XsLjx3VNDtCexm0wlsglqALV3UCW1bgXzsgtkiRsurBNgFbcGipejQpTv8g6ujBh/hJYsjpZEuJ6pdMgrc8buqQeHqwlc3a1PeANUuPV6k3KR/FLA9Ffb77+9Gjeh4V7xW/nB69x+glhVnBYF9pRT2Zj5214rUaY2ybVRCoxL1oJOMhOKBPeGygT1g0DCeL4Erj5/b1IxNwJoCKXNFmSdA/wpge4ZEglW+v14Wn9wY3Xrr3OiShER27NiBmubvIPuQP6xTJSyZIPeE9VvI09KaNbp79JWwHmsqoe8qQntNAHrTRWV7Zo1IpkjB/Gzxglkjrli2qbStWHbr5XZVFKq4WHYi1bU7L9uOKKvGCN+HLySwPWLZgQS3GmWd0C4/S8Z+dKBMXihK54fixXwH/iuNjwS3ZIs8SWg/TGX9YLZDZYsIuP813er5GIp/UmHfnOkws0UI7Uw7bFJqVaA9VepmF58tYqPK1o2QITBGE9yvtYSt5wCq6Ryq7NmwUVmr0Ehzc2CDVovg18pM71Mpfsths1R2yxVI3XHM/DUK298O2KLoCoY7dr3/PobzxrRH1HBdqCpLoHYsdmx/T60jXZE1ELViq147HvvMeHRxdjFgHzx0CGE13cCOIVzGjS9eFY8dN0mtI+vK/jwV8bfffo9QyQNX+9IeEnbxR+A/SmF/c/IEnNXd2THSg65RE3dN3+LsSgNbwih1qUqt8yUZD8NGFU4rLGh/J2BXDCBkzHMi30MarcVKWqwpMMQK4/H6im+MKVMvrdAXLVqE6Fj3NeusHoNjF30yuTzrsbYKXlsjDY/+Cto9OO1OYFtK2w1qz6wRQtrMGpF6I57Alqp+rlj2cgKbylqArbqsW7Fss8aIAraM/8hpwRoj1QnsMALbqjEi9bID5ofAn+q6ymzd87HMzDDVXV3GfpTBDSRb5GkC+wkC+yn6w7lhrmwRGeDg7pwQ3MP3t2c6cWu6UwFbZ4uEwS+D4BUwq7DIxbNFNLD5fjzXm8D13k6B0asPVfUIGClU1QJsc1ADv2a60VENHSY1Rayhw6zaIn93YHuPTXjxC/3r49+ojgTWjSYpVbPm6MatAYOHmF299TLJZEggWLQVvd+LAfv7H35AqCtGKamGjdBv4FC1zFNBWSGDN98eiQQqZwUgbiOAXeuhGB0EdBKfCixARcUlYVKazuEs2HNO7I9S2GLB9ghTYfN706VBdOu2nWqZldZX0K40sD/6+CNEuNIq9T6Dw2rjh+91fr1U5yvqOP5OwG7VtqNKH7X2ExmbjPketU48rahrJqW+O3dd2mikU4/nCPEFlbrkkMvAvboTkXxmC15XhXPNf4/1WFkJ/VZXQe+1QehNWPdUKruw0haX/GzpTKO6rpux7HYmsAv2gLRi2XrAA49YttllvdFi6QWpa4xI46OuMRKImIVOQtuOmlTT1ec7VL1s5wIq7dmhCJ5nRwBBXXluMKrKqDRzqLBnSEEod7bIc3nS+BiCJ3KcKizyyHRdEErFsrOosDn/9iy6mS3yj2mENmEtXdWNaYSvq/Gx6GwRS2GrsIgJbaNbiDqX1cfmwkiWbBGqbMkUaToftgL52Hpgg6VewJ6y7W+usLv1ek3lt37zbfHDu4upzAKPbASpSbHKfBx8Z+t7quCOvrk0FOslNUaDZi3x1ddFN2bNmDGnWGCLBdrd3YUVFEVBmT0zve2CyqKwjku2kfimjMtomYRMJCNDH1sLNGzcgccbhbeHjjDX8LbvvvseTo9GxyulsMXeHjJG5fxa50m2D3TWQE6e7tRRlEkvxSsJbLEgfqa1jXxPgVZQaHVs2VJ8g6Vnmt1fAWwrhi2WP3uBEg3u89iS0K2Od7frP7+CtnH9OkLYLVBWrl6LGlHxrm2lsTyQ338rr+WC9umnexHK609lo/B3kM5Gkfzs3BmzzTWujPVY5Q3sHqKyPZS2F7BXVvOIZUtxKO9YtqsHJL0l4Vwwli2vpcaIqOxGi4OQQmDXX+L0rjFCdR1FiFv1ssMIbIc0Ps51IphK25+gFmBXJrg9q/i9QGA/n+/As6Ku80Lo4Xg8z4mHsgXYWmFbwL4tiyrbzBaRburXZYSaJVc9gc33RQHbVNgWsNXrPhXVudz/3QkYdcfDZqnsIvKxdXqfR/W+liv//sAeRZjVqZdM6EUiNi4Z4yelYvny5erGkkayaRlZiIqvrxoirZtMLtrKgd5x6pjEZHVTabDom0gucEfNaFX9r+urr/OG6628e5/X0LpDJ5fCkRumILBrRca5GncsMAaFVcfwcRNUl3npgDGGxyodbiyYWccmNTcKWmWvR2hdX0LSCgWGyY2boRuPSY6tR88+6NCttws+4ldSYePCOVSoGoyEJroUgD5mgiuhgcoXb9auC3r26us6V337van+/KxjuVLAnjVzrqq8aG0nLschdTmC+H1adeiO7jwX0vOza49X0fPV11SXeWvdvxLYVtSjWnA4Epu6SyHIbyFd1SXMlJ6Rg2xeI1K5sGGztrqLvUd2jVg8Pzu+gWzr/h3knETUjsZbbw/FgGEjEJ2QDKn4Zx2vrBvXqBXC+IcvVsSDyG+2XmuqoP+aaui71h99OX11dYCX0i6YNeIKkRDa3URdFxPLdveANGPZZmjEimXrGiMhOsVvSZCrxkg9KmvJFpGiULXMbBGn5GWrsR+tno+SMaKr+FWcFYoy+dL4KKOrW9kioaoTzWMzpPHRrsuuEtjSTV0aIO/KDMUdWWZX9YwI3JAWSpUdCjV0WEnS+6zqfQrYEsfmn0z2WHU+jbojYJMBDaQDTbH52Mtc+dhG8+UEdvFD/f1tgC03n1ysSY3bIDqxMSJjUlTnl1oxCaoTjUBCw1Nf2KK0Jb1P7Lwaif08p+dUOU+pz+GuzaBvAtlOOtbE1efFzkdRacRMNIfYstYpCOzpeXNUL0BrP7JucsPWqJfYVLXUS1GquCQ+nroaQ7kfTuXG7tC1t7kXt7333g5UDgozj0fvz/rsxAb87jy2evWbqWOUfbj/LK6cwrbiq1s2byVs5Fjc58By+ZOrx3Mk50lcXlsNpnr57wf2mTO6M1Tztp35pORZOEnvQ94nmL9XvBxHCn8zvvZc568AthUSscIan3zyGaoGOb06fcm5sqrrRfMakaJlAmpZpxav62EjxqhtLQuVcBnVtc6E0seeItdZUhNep025ra7cp49Xf0bVECe+NZ9Iiwod/VazgN1nbQD6rK5mxrK10hZgdyOElbo2gW3FsrsQyl0lhl1MLNsrL1v1iHTHsgXYEr/WQ4nZkbI4GElmLFt3pLGbVfykq7oAO1gVhQqV9D4qben5KAP1VlTAdqiR1V8msJ93ZYuYwJbaItPtXtki4jKowR1U1wrY6RG4nsC+LkMaGksAbMkWceVjE/LjwwntYBivJ1Ex94Ct/XgYKdJ5xopjSz62ALuIfOxOGthTtxc/1N/fAtjDR41VjU7JjawL0n1TerpctEmN2iqIx6e4O2542tmzZ5HQoJFSOdJ7TkGP+7UueLmZPOHjuW/pOGMB2wJb7ah6qJug/0z0ugWPT0PT2kdswxaoGuzAz//70S3DPOzjjz/mY3111I6tz+PU21gu+ynq+GSZZANYWSdiojw1sGX5ZSps0z7a84GCdlSMnPtmVIGt9bHIPgu45/HIo7tnHrYCdrIGtjrWEipsy0aNm4hK/kGIS2ym9m3txzoW9d6cerp8phewe3oCu9UlgS37l3Xlzz8zK89c6m0a2PrPXwGbn1HQNq3fpOpm1/O4zgpfJ3pZHK+PZ14sgy+OuW/KC+fOIpxPgXUT5E/aW5hY+5FtVZlbQjw4NALffVt8qdffYwLs101g9xVoq9CIqGztKpZNkHuqbNUDksukwp/EsjsT1DqWHeTKy7ayRVqr0EgQWi2Vin7moL1U2TpbxFTZXD9lsQOJ5lBidam0owjq2gtDUGe+jErjUI2PoaK051JhU2kHzjYH650dgrKzJDTixEszdbaI1BaRbJGnCO2nckNVV3WpLSKhEamV/a+cYFVb5NaMcJWTLQMbqGyRdAE2XeqKSGqfuMBaXMAtLtCWqdWBRgbrlWyREckw+vWDrfM42BrM1vnYapzHhapyX9H52ALsFZj8dwf2itVrVJF8uTmk/ocoJ6lYJ5Xt5CaRBj+pXhZeJwbB9hqYnj9TbXf+nC5Z6m26oWbjps3o/mpvBITWUIWOpBC+KmIvxemLcLmBpWLf/gO6MJFng48UQJKwhRRkch9bU5fLvLpU3FJsKDou0TWizfkigG3ZrDkL0IA3oBTOl9i7ZLxId+mijk2OO8BeC6vWrDG3Blq36YiISL1cjr1MpUBzScnsnMe5mzt3voK/hEOkaL80Ql7sXEmR/+qRcebWwMAhI1RFRLWc20njmdW2cCmzamz8/PMvGDlqDMJ4HoIcNVQIwDXwQIHPt1w+Uz7bslZtu6C6HDuX6XMSxLmFfwM5NjlGa9+OGtGYPEX39vS2C2ofsi9ZT/Ytn+Fp587pJ4Uff/xJPdXJftV1wmvWuj7k+pV5wc5a6unFUxl7qmNpo5Ha5BISkmvKvX1jdaxSvuGtgUPMta+ssras/fJn0W35c+i4/Hl0UtPSaL/0ObRf9oLy1sueR+slz6HVkhfpLxC+L6LFoufQjK+b05ssLo0mi15Ag0Wl0ZCesvhlJC8sjaSFL2tf8DIS5r+IpHkvI27BS6jH97HzXkTd+S8pr0OvtfBF1J5TFhHzyiBizisImfsSgmeXQ+CcMvDPfwWV88uiAv3l/JdRNq8cns97CS9ML49nppfFEzkv45Hs8ng0sxzuzyqD/3B6T9YruGtaOdyWUQ53TCuDf6SWxY2p5XBtahlcO7UMAfwSwVueoK1AtVyW03IwxvH9BPp4eU0fw/lj6aPlNX0kfZSHD+My8eHcx3Duc2AQjG6tqKLfghEzDUZkPoy6M2DEzaLPhpFAgCfTpfu6GriXqrvJIs5fhBFbih+h6G8BbMtOnjiO2fPmY+ykyejKR89uPV9Dh869MGTYWKRlZOLTve5GvMuxH099j8NHj6phnyQmXpwvX7mK654yt/K2X86cQd6MfIwcO1EBXGKZ3ai25PjGjJuC6bl5OHi4+NjTxezkN8exd/8BBZIN/KMpdGxUhKtWrVFZMpZt3b4Da9dvMNfZjOVLlxUl6C/bvvzyKzU0mPTOLHQcpq+jb1jvBvLHH+3hubWOZRP/gNfieDENvSW1fQcPqIGGpdOR52d7unymfLZl27e9p8qVWsuXLteF/gum2cmxyTFa661eux7793lfW9Y2sg9rPdm3fMbF7Ief/qcKSQ0dPhaduvZW18fgIWPUPFlWElu+fCUmTklHJz5Syz7eHj4GC+YvNJf+sbbti0XYeWwxtn+xTPmOL5bSl2HbsSXYLv6F+FK8x+k2cc7bdmwpth3llP4u58myd7mPreKcJ77l6GK8Q7emm75YjM1cvvnIUk6XYtPh5dh0ZBk20jcdWY61R5diPZet4rZr6CsPL9Z+hK+PLMaKQ8uxir7o8FIsPbwMCw+uxOJDK7HwwDIsos+jy+s5B5bz9XLM3r8Mc+l5fJ1Pz/t8GfI/X47s/UsxnfOzP+d031Jk7V2OHC5L27sM0/h62mdLOV2K1E+XIPUz+qfLTF+ONHrqJ/r9VE6nyvyPuc4nSzDtw1WY+v4WpG37AFO3HEDq+kPK0zbQOZ2y5TCmbqK/cxRTNx/BlK1HMeXdoxi74QgOHi+aQWJ/G2CXVC3IjVSSjgmW/RYV8kcol+LsSn6WZ0W4yzU5p5fLe/ktLnb8f9a5l20KQtmygsdY0uO92D4vto/fbao9phi73B/IZ1epFc+3v5XC9pnPfOYznxVvPmD7zGc+89lVYj5g+8xnPvPZVWHA/wNXMHMxVFmXKwAAAABJRU5ErkJggg==',
			// 	width: 130,
			// 	opacity: 1,
			// 	border: [false, false, false, false],
			// });

			// var oHeaderBody = [aHeaderColomns];
			// //extra add
			// doc.content.push({
			// 	table: {
			// 		headerRows: 1,
			// 		widths: [100, "*", 130],
			// 		body: oHeaderBody,
			// 		border: [false, false, false, true],
			// 	},
			// 	layout: {
			// 		defaultBorder: true,
			// 	}
			// });
			// //extra
			// var oSimpleForm = {
			// 	table: {
			// 		widths: [100, 200, 90, 200, 90, 200, 90, 100],
			// 		//	widths:[70,100,90,100,90,100,90,100],
			// 		heigths: 10,
			// 		body: [
			// 			[{
			// 				text: 'eTicket No      :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.Docno,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Well Name       	:',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.WellName,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Vendor ID            :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.Lifnr,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}],

			// 			[{
			// 				text: "Contract No",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "66000003651",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Rig Code              :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.RigCode,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Vendor Name     :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.Lifnr,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}],

			// 			[{
			// 				text: "PO No",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "65109809890",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Rig Short Name  :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.RigShrtName,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Vendor Ref. No. :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}],

			// 			[{
			// 				text: "",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}]
			// 		]
			// 	}
			// };
			// // oSimpleForm.table.body.push(oMCRow);

			// doc.content.push(oSimpleForm);
			// var oBorderTable = {
			// 	table: {
			// 		margin: [0, 0, 0, 0],
			// 		widths: ["*"],

			// 		body: [
			// 			[{
			// 				text: "",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, true]
			// 			}]

			// 		]
			// 	}
			// };
			// doc.content.push(oBorderTable);

			//extra
			// var firstTableData = this.getFirstTableData();
			// var secondTableData = this.getSecondTableData();
			// doc.content.push({
			// 	style: "header",
			// 	alignment: "center",
			// 	text: "E-Ticket Report"
			// });
			// doc.content.push({
			// 	table: {
			// 		headerRows: 1,
			// 		// widths: [100, "*", 130],
			// 		widths: Array(firstTableData[0].length).fill('*'),
			// 		body: firstTableData,
			// 		border: [false, false, false, true],
			// 	},
			// 	layout: {
			// 		defaultBorder: true,
			// 	}
			// });
			// doc.content.push({

			// 	text: '',
			// 	pageBreak: 'after'

			// });

			// doc.footer = function (page, pages) {
			// 		return {
			// 			margin: [5, 0, 10, 0],
			// 			height: 30,
			// 			columns: [{
			// 				alignment: "left",
			// 				fontSize: 9,
			// 				text: "oVendorId"
			// 			}, {
			// 				alignment: "right",
			// 				text: [{
			// 						text: page.toString(),
			// 						italics: true
			// 					},
			// 					" of ", {
			// 						text: pages.toString(),
			// 						italics: true
			// 					}
			// 				]
			// 			}]
			// 		}
			// 	}
			////////////////////////////Second Table///////////////////////////////
			// var getData = this.getView().getModel('oETicketModel').getData();
			// var oHeader = "";
			// var oSrvtyp = "Drilling and Work Service";
			// // Header for the PDF
			// var aHeaderColomns = [{
			// 	image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAENUAAAeDCAYAAABxxqQsAAAACXBIWXMAAC4jAAAuIwF4pT92AAAgAElEQVR4nOzBAQ0AAADCoPdPbQ8HBAAAAAAAAAAAAAAAAAAAAABXqgEAAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zUgQnAIAwEwHQuEVzGPbqHywjiXt2hpbbC3QTJJ/yxcqM6ZomI4o1u6y2nvunssC3d9Yje4jN1zFP6/9ZyciMAAAAAAAAAAAAAAAAA4B0RcQEAAP//7NwxCsAwCAVQh1y15+jZQum9QuYiFAyBwHurm+LftG1u7TxKv42zxHE67Ce7auQWSyRPMuzmwa7n/Tu/mSM9K3rOAQAAAAAAAAAAAAAAAAB8RMQAAAD//+zcsQnAMAxFQW1mLeNBMlvIXiHgIhiiMo3uKqH61+/vqAYAwKd5XrlCNo/xuuktqy0UcY5jfwhwAAAAAAAAAAAAAAAAAEATEXEDAAD//+zcsQkAIBAEsFvWScW9rCzkbUWQZJBINQCAJ1ofKzeQZ3BLyTYOAccWb0g3AAAAAAAAAAAAAAAAAOATSSYAAAD//+zcoQ0AIBRDwe4/FWyGIoGPh5DcufrqJ6oBAFyxRDSO0AE8tP2xRDdakj6H4AYAAAAAAAAAAAAAAAAAfCTJAAAA///s3MEJACAQA8GUZmt2fiD68S8cMgOBVLGiGgDAEyIafGDsLVdwY54jtgEAAAAAAAAAAAAAAAAADSUpAAAA///s3FEJACAQBbDXzOrazB+RC3AgyBZkUg0AoM2JNEaNCOBTN9go2cZMsiLaAAAAAAAAAAAAAAAAAID3kmwAAAD//+zcsQkAIBRDwewlgnu6zB/NSis7wepuhEDaJ6oBADwR0oBj7B9cQhs1eytTAQAAAAAAAAAAAAAAAMAnSRYAAAD//+zcoQ0AIRAEwOuLfDnUwX8dlEPoiyBAkrzAzYhTpzZZu0Y1AIDfcutrPKBID452V3Lr6++bpz7pFR0AAAAAAAAAAAAAAAAAXBIRAwAA///s3LEJACAMALB+5jVeWvqXKLqLOCaHRKoBAFzrWTMBaDsJAN6sjKZnnZRGsgEAAAAAAAAAAAAAAAAAv0XEAAAA///s3LEJACEABMHrS6zNQr4Z7UwEg88EwWwmufwKWFENAOBoxzSap+CJf2SjJxlrv1q6uwEAAAAAAAAAAAAAAADgUpIJAAD//+zcsQkAIAADwYzmMs4hzibuJYKtjYXVHaTOBi+qAQBciWnAd+Ws1TH3dxfYAAAAAAAAAAAAAAAAAIAHSRYAAAD//+zcsQ0AEABFwb+XmI09TGMz0UkUWsXdCq9/phoAwMVMA77RjsHGHmvMUUuXBwAAAAAAAAAAAAAAAAAekiwAAAD//+zcsQkAIAwEwIyWZZzD4UL2EkFsbS3uRnj48t+pBgBwjeo8I/6UCnxn9zJH9XSwAQAAAAAAAAAAAAAAAAAPEbEAAAD//+zcQQkAIRRAwd9LjGMQcxhGQewlioetsDBT4d2fqQYAcJW5upkG/MZ3sFHPZKPlNOQDAAAAAAAAAAAAAAAAgCciNgAAAP//7NxBDQAgEAOwBa/4wBkPgi7IySC0ErbsuyYLAPhbX3v0tY9DDXhWHWvM2nHtWY0AAAAAAAAAAAAAAAAAkCTJBQAA///s3EEJwDAQBMB9xFUpxEx0lOiomUCIr1KoimZGwh773CtyAIA9tbnqN8b3TAP+42pzvb0eSfp9HsNtAQAAAAAAAAAAAAAAANhSkgcAAP//7NzBCQAgDATBYK/pw858SOpSEKvQmRaW+15THgD+cw81hkMNeNbZeM5aOavLDAAAAAAAAAAAAAAAAMB3ImIDAAD//+zcQQ3AIBQFwXfAVYMcdJDqwMxPCL7qo8xY2Ps21QHgLmMfMw24yxz7zCRvklr9Kf0BAAAAAAAAAAAAAAAA+L0kHwAAAP//7NzBDQAgDAOxiF2ZkwdiL9Q1WnuFSHnesjIAzCGoAaNVWOPUD+z7/AAAAAAAAAAAAAAAAAAAvSX5AAAA///s3EENwCAAA8A+5ooswQxC0IGYkZD54oMKciehfbePigHgfmdA/6kaOMc6ta1/JunjLVMoAAAAAAAAAAAAAAAAAFwnyQYAAP//7NzBCQAgEAPBYK/W6UPsSzj82sAx00JgnxlWBYDeHGoAH9WGuc96nQAAAAAAAAAAAAAAAACAPpJcAAAA///s3DERAAAMA6H3r7oWOudACFINABgm1AAe5BoAAAAAAAAAAAAAAAAA7KkOAAD//+zcMREAAAgDsfpXzcbeES6R8ALeVAMAnjLUAEo71xAOAAAAAAAAAAAAAAAAgPOSDAAAAP//7NxBEQAgCABBolmGHnZjyCUhfOnsRrgAZ6oBAB8y1AAurKw+Wb1FBAAAAAAAAAAAAAAAAOBZETEAAAD//+zcMREAQAjEwJOGs7dOgwSaZ3YlREBMNQDgGEMNYMmbuUYJCgAAAAAAAAAAAAAAAMB3kjQAAAD//+zcMREAMAgEsDeLToZefVVFB7hESKQaALCIUAP4oOvclmsAAAAAAAAAAAAAAAAAMEqSBwAA///s3DERAEAIxMCThrSXToMFimd2JURATDUA4AhDDWBRzVzjiQwAAAAAAAAAAAAAAADAF5I0AAAA///s3EENACAMBLAziw6k7UHwxQcLJAtphVSqAQD/EGoAr82xdt3EBwAAAAAAAAAAAAAAAAD6SnIAAAD//+zcwQ0AMAgDsYzO6FWWQKiyR4B3TlQDAD7Qkbs/Aksa1GhYYxwcAAAAAAAAAAAAAAAAgLOSPAAAAP//7NxRCQAgEETBjWYZcxhO7CUHZhCFmQoL+/lENQDgcyeo0ewIXDbqf/pc/gcAAAAAAAAAAAAAAACA9yTZAAAA///s3MEJAAAIA7HuP7UI7qBCMkR/PVENAHhszuwO7cCW3h9hDQAAAAAAAAAAAAAAAADuSVIAAAD//+zcQQkAAAgDwPUvZTURDKFwV2Gw3+ZUAwCe2hF7yQ84YI419BEAAAAAAAAAAAAAAAAAdyRpAAAA///s3EEJADAMBMGTFme1Xgrx0ARmLOx/TTUAYK+jHTBIvbFGD38AAAAAAAAAAAAAAAAA4K8kFwAA///s3EEJADAMA8CYnY95K/M1qmIr3FkI5Jc41QCAgVad3QN22QGf6V5yrAEAAAAAAAAAAAAAAADAe0kuAAAA///s3DERADAIBMF3jrRYo8EDYWbXwvVnqgEAN5VuwMfezH8AAAAAAAAAAAAAAAAAYEeSBgAA///s3EEJADAMBMEzGx2V1keJr8oIgRkLC/c8pxoAsEy9vpoBCxx7BQAAAAAAAAAAAAAAAMCYJB8AAP//7NxBDQAwDAOxQAuZIa3GazCmSjaF+5+pBgAscuY2STUDlqixBgAAAAAAAAAAAAAAAABfJHkAAAD//+zcwQkAAAjEsNvc1QVxBkFIVui/phoA8IDgAc4AACAASURBVEvpBTwzY42dAgEAAAAAAAAAAAAAAADAjSTNzh2UAADDMACM2fqYt1FfoyYGhTsLgfwSpxoAsETdPjNOlxew0HSXYw0AAAAAAAAAAAAAAAAA/knyAAAA///s3EEJAAAMA7E6n/W5KBQSC/c/Uw0A2HFaAeOMNQAAAAAAAAAAAAAAAADoSPIAAAD//+zcMQ0AMAwEsScbHuVWlVdQdEhkU7j9TDUAYIC67+gELGGsAQAAAAAAAAAAAAAAAMB/SRoAAP//7NwxEQAACAOxOsc6KjrAJRZ+f1MNALhhdAIeMdYAAAAAAAAAAAAAAAAAoCvJAgAA///s3EEJADAMBMEzGx/1VuorKgohzFjY/5pqAMBwdd/RCFjIWAMAAAAAAAAAAAAAAACAf5I0AAAA///s3MEJAAAIA7Fu7upOURBJVrj/mWoAwH2jEfCUsQYAAAAAAAAAAAAAAAAAHUkWAAD//+zcMQ0AMAwEsScbHuVWlVdIdIgim8LtZ6oBAIPVfUcfYDljDQAAAAAAAAAAAAAAAAD+S9IAAAD//+zcMQ0AAAgEsXeGNKxjgoGE1sLtZ6oBALeVPsADLTIAAAAAAAAAAAAAAAAAq5IMAAAA///s3EENACAMBMGTVjPo5NHUFyZ4kDBjYf9rqgEAj1o9laT0AT5Qq2cLDQAAAAAAAAAAAAAAAMA1SQ4AAAD//+zcQQ0AAAgAoeuf2hI+3IQgSDUA4C6hBvCJWAMAAAAAAAAAAAAAAACAPdUAAAD//+zcsQ0AMAgEsd+cjI6YgSYS9grXn6kGAPyrtAGOmbHGEx0AAAAAAAAAAAAAAACAtSQNAAD//+zcQREAIAwDwUirGXQgjsEXIvrpDLsa7ps41QCAgYzKgY/tdW4JAAAAAAAAAAAAAAAAAICWJA8AAP//7NwxDQAACASxd4Z0rCGChYTWwu1nqgEAN5UuwGNtrAEAAAAAAAAAAAAAAADASpIBAAD//+zcMREAAAwCMZzXekV06R2JhN/BqQYA/GRMDrSb9gAAAAAAAAAAAAAAAAAAHCRZAAAA///s3DEVACAMQ8FIw0x94Iyhr77wwMRwJ+Fnj1MNAPhM9WybAGRVz5EBAAAAAAAAAAAAAAAAgCdJLgAAAP//7NwxEQBACAPBOOP9q2LAwXcUuxKS/kQ1AOCe8gnAmrDGMwUAAAAAAAAAAAAAAAAA35I0AAAA///s3KEBAAAIw7D9/xSvIadxiOSP1lQDAP4RkAPUGGsAAAAAAAAAAAAAAAAAcJZkAQAA///s3DEVACAMQ8GYrQ7wxsMXAjp1Y7iT8LPHqQYAfKTO3fYAaJYkAAAAAAAAAAAAAAAAAIwkeQAAAP//7NwxAQAACMCgRbN/KjP4eUAQpBoAAMB3Ix0CAAAAAAAAAAAAAAAA4KRaAAAA///s3DEVACAMQ8FIqxl0VFwfvjDAwMhwJ+Fnj1MNAPhL2wPgqtfskgYAAAAAAAAAAAAAAACAJ0kOAAAA///s3DEBAAAIgDD6pzaCnh5bDzDVAIAnxOIAK+MhAAAAAAAAAAAAAAAAAG6qAQAA///s3EERACAMBLGTVjP4wBuDLxy0Xx6JhBWwphoA8A9TDYBerXO3RgAAAAAAAAAAAAAAAACMkjwAAAD//+zcMREAIAwEwXcWNehAHIMvHCQtxa6F689UAwD+UVoAjPY614QIAAAAAAAAAAAAAAAAgF6SBwAA///s3DERAAAMAjGc13odcB07JBJ+B6caAPCHkTjAzegEAAAAAAAAAAAAAAAAQJVkAQAA///s3DENADAMBLGHFjJFWpVXGFQZM9ggbjxTDQBY4NxnqAEwV7oJAAAAAAAAAAAAAAAAwFeSBgAA///s3CEBAAAIA8H1L0U1EkzgEHcR3m9ONQDgB+NwgJvRCwAAAAAAAAAAAAAAAIAqyQIAAP//7NxBDQBACASxNYuP80bwhYEzQNJamP+YagAAACdVz1MOAAAAAAAAAAAAAAAAgK8kCwAA///s3DERAAAIA7E6xzoGurAxJBb+rmOdagDAD6MDwJntBAAAAAAAAAAAAAAAAKBLsgAAAP//7NxBDQBACASxNYuP80bwhYBTQNJamP+YagAAAGdVz1MPAAAAAAAAAAAAAAAAgE+SBQAA///s3DENADAMA0FDC5niKLiqvAogW5YudxRe8minGgDw2Tq3NAAY23YUAAAAAAAAAAAAAAAAgCbJAwAA///s3KEBAAAIAkE2d3Uz2WC5G+E7ONUAgH/G4AA3ox8AAAAAAAAAAAAAAAAAJckCAAD//+zcQQ0AMAgEsJOGmSkl+OI5DSStkEo1AACA6+r1CIoAAAAAAAAAAAAAAAAA+JIsAAAA///s3CEBAAAIA8E1IxrVcRRAYO4i/PycagDAv7IBwFlLCAAAAAAAAAAAAAAAAMBKMgAAAP//7NwxDQAwDANBQwuZIq3KK0MhZMhyR+Elj3aqAQD7SgOAsTr32VMAAAAAAAAAAAAAAAAAviQNAAD//+zcsQ2AMAwEwC/YCiFlMwZhGbNZGteUKcjdBm+92z+cAgDYTCV5O3I911kKsFYPH3yNH9x/zM0So38cAAAAAAAAAAAAAAAAgN0lmQAAAP//7NyhDQAgEAPAX5Y5gNkIe2FQH4Im4U7WtrpONQCAH3QHGu/YPdy6aDkoY+bM8QYn9bQfAAAAAAAAAAAAAAAAAD4UEQsAAP//7NzBCYAwDAXQv5eIXcZBnKPjSPcqgoiHHgVB3zvlXxOSYzzVAIAXDR4F8KytzpMef8Bgjlde91aSlDMut5ofOu6qvQcAAAAAAAAAAAAAAAAgSToAAAD//+zcQQ0AIBDEwPVF0IYQzCCN7wUJ3IyDGqipBgDwIzONRvYcJ8l5i8tsw2ijl1WnKwAAAAAAAAAAAAAAAAA0leQCAAD//+zcQQ0AIAwEwVpDDDoQR/BFSOCHgnZGwt1/RTUAgGzajSxQ3C+20ed6sYVRfZ/Mzs/COgAAAAAAAAAAAAAAAADFRcQGAAD//+zcsQ0AIAwDQW8W9p8KCVFQMUBy17j3AC+qAQB0IqjB1xNaOHsjG5Vkea6Vmn4AAAAAAAAAAAAAAAAAwHhJNgAAAP//7NyxCQAgDEXBjJZlnMPhxL2sBFtBEPRuhEB++UQ1AOCu6v7HCGqwbYlszMBG+MsnZGk9bQIAAAAAAAAAAAAAAADAxyJiAAAA///s3LENACAMA0FvxmqMjiJR0KcC7kZw4fJFNQCAFwhq0HYENuYObIyKM1j2WhVH8QsAAAAAAAAAAAAAAAAAv0qyAAAA///s3DERADAMxLBnHmqFliVDAXTJVYJgADbVAAC2O4YavHYNNjKDjRJ5HUMUAAAAAAAAAAAAAAAAgJ8laQAAAP//7NzBDQAQEETRoS1xUKdmRaIFB/FeCbtz/vX3AwAAb5u9DS/kph3YmL2VJHtrAi4POUEUAAAAAAAAAAAAAAAAAH6UZAEAAP//7NxBDQAgDATB+iIEbejADNL6QQNJ0xkJd/8V1QAAKtve45czx30RF3GNOlb3AQAAAAAAAAAAAAAAAADaiogEAAD//+zcQQ0AIBADwUo7Mygl+EIEyRHCjIQ++lxRDQC4ZMxVtj8mbEA7cY2nlK8FAAAAAAAAAAAAAAAA+FSSDQAA///s3EENAAAIA7H5V03QwIMQWhH77UQ1AGCPo/dMhw0EDVgjrnGGrQUAAAAAAAAAAAAAAAD4KEkBAAD//+zcMREAMAwDMTPPFVqZZS2E9CJBsPcX1QAAfnU9xwRPXOM4ZKTaPgAAAAAAAAAAAAAAAADASkkaAAD//+zcUQkAIBQDwGcuESxjD3tYRhB7WUPxLsK27znVAABeNTXHTUbJfZScbPM+be36ewYAAAAAAAAAAAAAAAAA34mIAwAA///s3DENADAMBLHnFWUIzpAtjVa1Kdx+phoAwJO2y7iAK23XJBl1rmKqAQAAAAAAAAAAAAAAAPCbJAcAAP//7NxBDQAgEAPBoougDSGYJbg4cjMSmr5XVAMA+JGgBqW96MtZc/hqGbv7AAAAAAAAAAAAAAAAAADtJLkAAAD//+zcUQ3AIABDwfoiJEwMQtAxNQuZL2QQwp2Evv861QAATvSpxgneWp4kQ6z9+vzb7RsAAAAAAAAAAAAAAAAAXCXJAgAA///s3DENACEAwMD6Ij/gDB+YfRWEgTsJFVBTDQAAOGh/Y1VT4+tMNQAAAAAAAAAAAAAAAABeUv0AAAD//+zcQREAIAwEsfPFoK1CagZpqGB4NHGwBtZUAwAAHuu9jrHGdzW8HwAAAAAAAAAAAAAAAGCWJBcAAP//7NyxCQAwDAMw/39VTuvauRBKiHSBB6+2Uw0A+MfA+11NDc5e17GG/gIAAAAAAAAAAAAAAABAtyQHAAD//+zcQQ0AIAwEwfoiyMEHPpBD8MUHD6TpjINL7r2iGgBAOi9OACm/u3oT1vhk7DNLDgcAAAAAAAAAAAAAAACoKCIuAAAA///s3DEBAAAIw7A5w78rXMCxxEEN1FQDAACOGWu8mdJuAAAAAAAAAAAAAAAAgD5JFgAA///s3DEBAAAIw7BJw78qHjTAQSKhAmqqAQAAB2aswa7SGwAAAAAAAAAAAAAAAOCJJA0AAP//7NwxEQAwCASwN4vSHr5wQQcSIZFqAADAP2KNZfVarAEAAAAAAAAAAAAAAABwQZIBAAD//+zcQRUAIAgFsN+LZ1LLGI0WcmALMqkGAAAMuaeeWOM7qQYAAAAAAAAAAAAAAADABkkaAAD//+zcMQEAAAjDsDnHOi7gWOKgBmqqAQAAj4w1zk1ZLwAAAAAAAAAAAAAAAECnJAsAAP//7NwxDQAADMOw8kc1aHsKYdIem0L+mGoAAMCzjjVGBwAAAAAAAAAAAAAAAAA4kmQBAAD//+zcQQ0AIAwAsfkiPBCDD3wgZ8EXLgjJWgdn4Ew1AADgA7u3YazxxsyzKnQCAAAAAAAAAAAAAAAAlBYRFwAA///s3CEBAAAIwLBXpzklEIitwv1NNQAA4I/RAgAAAAAAAAAAAAAAAAAOVAsAAP//7NwBDQAgDASx90XQNiEzgzRcEJK1Ds7AmWoAAMAneq9jrPFEDWgEAAAAAAAAAAAAAAAAmC3JBQAA///s3DENACAAwLD5InjDB2aQhggejtbC/plqAADAR/YcqzqaAAAAAAAAAAAAAAAAAMCD6gIAAP//7NxBDQAgEAPBSsMMQk4bwRcqSMgx42DTf51qAADAe8omd821R+c+AAAAAAAAAAAAAAAAgO8lOQAAAP//7NxBCQAgAMDA9RKTWsZophBE7irsP1MNAAB4zJpjV1uXq0w1AAAAAAAAAAAAAAAAAH5WHQAAAP//7NxBDQBACAPBOkPbOUcFCTlmHGz6r1MNAADY6dllVH3cBgAAAAAAAAAAAAAAAHBekjQAAAD//+zcAQkAIBAEweslwve0jNFMIcg702ALrKkGAAA8aM2xjTWuqsZtAAAAAAAAAAAAAAAAAN9LkgMAAP//7NwxEQBACASx88W8N3xgFg9fUSQWtl9TDQAAOGpetTYAAAAAAAAAAAAAAAAA8CHJAgAA///s3EEJADAMBMEzGyHVVuorKgohzFjY/5pqAADAbEefP+o+0xIAAAAAAAAAAAAAAACArZI0AAAA///s3DERAAAIBKDv5ZnUsmZwc4AgSDUAAOCx6RI/AAAAAAAAAAAAAAAAAMBVkgUAAP//7NwhAQAACMCwV6c5GXCIrcL9TTUAAOC/0QgAAAAAAAAAAAAAAAAADqoFAAD//+zcQQkAQAwDwTivtZNWKqJwlBkHS/5xqgEAAP97NlpRB5sAAAAAAAAAAAAAAAAAGEkaAAD//+zcMREAMAgEsPfFVSlmkIaGbgyJkEg1AADguH41Yg0AAAAAAAAAAAAAAAAA+JBkAQAA///s3EENACEAA8GVhpkTSgi+zgQfyIyDTf91qgEAAHeYdjrvW3u81gQAAAAAAAAAAAAAAABAVf0AAAD//+zcMQ0AMAwEsecVlVt5lGxQdEhkU7j9TDUAAGCAd+rq9IWpBgAAAAAAAAAAAAAAAMBGSRoAAP//7NwxDQAACMCwWcc5FnhJWgv7Z6oBAAB/jFYAAAAAAAAAAAAAAAAAcFAtAAAA///s3EENAEAIA8E6w/pJI3jgc2TGwab/OtUAAIB/PFutq2M9AAAAAAAAAAAAAAAAAIwkDQAA///s3EEJACAAwMD1EsGelrWEH+WuwQrMVAMAAB6x5zDVuG/9FgQAAAAAAAAAAAAAAABAVR0AAAD//+zcMQ0AAAjAsFnHORK4SVoL+2eqAQAAv4xeAAAAAAAAAAAAAAAAAHCoFgAA///s3DENAAAIwLD5V4U0JHCTtBb2z1QDAAB+Gb0AAAAAAAAAAAAAAAAA4FAtAAAA///s3EENACAQBLH1RZCDD3wgh5wvTPCBtA7GwJhqAADAQ1ZvphqXjV3zqyAAAAAAAAAAAAAAAAAAkiQHAAD//+zcQQ0AAAwDofOveg72bwJCkGoAAMAesQYAAAAAAAAAAAAAAAAAfKoDAAD//+zcMQ0AAAjAsPl3hTMc8JO0FvbPVAMAAP4ZzQAAAAAAAAAAAAAAAADgUC0AAAD//+zcQQ0AQAgEsfVFzhs+MIuD+5O0FuY/phoAAHDMvGrNAAAAAAAAAAAAAAAAAOAjyQIAAP//7NwBAQAACMIwmlvdHrBFeICbagAAAOtuPQAAAAAAAAAAAAAAAABAnSQPAAD//+zcMQ0AAAjAsFnHOQoQQNJa2D9TDQAA+Gl0AwAAAAAAAAAAAAAAAIBDtQAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3DENAAAIwLD5V4U0FCCApLWwf6YaAADw0+gGAAAAAAAAAAAAAAAAAIdqAQAA///s3EENACAQBLH1RZCDD3wgh5wvTPCBtA7GwJhqAADAg1ZvphoXjV3zmxgAAAAAAAAAAAAAAAAAkiQHAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwxDQAACMCwWcc5BjBA0lrYP1MNAAD4a7QDAAAAAAAAAAAAAAAAgEO1AAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcMQ0AAAjAsPlXhTQMYICktbB/phoAAPDXaAcAAAAAAAAAAAAAAAAAh2oBAAD//+zcMQ0AIADAsPkiaEMIZjHBA2kdzMBMNQAA4FF7DlONe9YvIQAAAAAAAAAAAAAAAABU1QEAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3DENAAAIwLD5V4U0fhyQtBb2z1QDAAB+G/0AAAAAAAAAAAAAAAAA4KgWAAD//+zcMQ0AAAjAsPl3hTN+HJC0FvbPVAMAAH4b/QAAAAAAAAAAAAAAAADgqBYAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcQQ0AIQADwZWGmfNJQvB1JvhAZhxs+q9TDQAAuNu03xnf2uOFDgAAAAAAAAAAAAAAAACq6gcAAP//7NxBDQAwCASw80WmFLOY4DPSCqlUAwAAPtavpBp7pBoAAAAAAAAAAAAAAAAAVyQZAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3DENAAAIwLBZxzkvFkhaC/tnqgEAAP+NhgAAAAAAAAAAAAAAAABwVAsAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NxBEQAACIAwmtm/lQ9beFsEAmCqAQAAcEYHAAAAAAAAAAAAAAAAgCeqBQAA///s3EERAAAIgDCi2T+VD1t4WwQCYKoBAABwRgcAAAAAAAAAAAAAAACAJ6oFAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NxBDQBACASx9UXOGz4wy/cskLQW5j+mGgAAcNy8ag0BAAAAAAAAAAAAAAAA4JNkAQAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NxBDQBACASxNYuP80bwxfcskLQW5j+mGgAAcFz1PA0BAAAAAAAAAAAAAAAA4JNkAQAA///s3EERAAAIgDD6pzKaD1t4WwQCYKoBAABwRgcAAAAAAAAAAAAAAACAJ6oFAAD//+zcQREAAAiAMPq3spkPW3hbBAJgqgEAAHBGBwAAAAAAAAAAAAAAAIAnqgUAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwxDQAACMCwOcO/K14skLQW9s9UAwAA/hsNAQAAAAAAAAAAAAAAAOCoFgAA///s3DENAAAIwLBJw78qXiyQtBb2z1QDAAD+Gw0BAAAAAAAAAAAAAAAA4KgWAAD//+zcAQ0AAADCoPdPbQ8HQZBqAAAAAAAAAAAAAAAAAAAAAPClGgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3EERAAAIgDD6pzKaD1t4WwQCYKoBAABwRgcAAAAAAAAAAAAAAACAJ6oFAAD//+zcQQ0AIBAEsfVFkIMPfCCHnC9M8IG0FuY/phoAAPCwsWvqd8fqzVQDAAAAAAAAAAAAAAAA4BdJDgAAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcMQ0AAAjAsDnDvyt+HJC0FvbPVAMAAH4b/QAAAAAAAAAAAAAAAADgqBYAAP//7NwxDQAACMCwScO/Kn4ckLQW9s9UAwAAfhv9AAAAAAAAAAAAAAAAAOCoFgAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcQQ0AIBADwUrDDEJOG8EXwQOfIzMONv3XqQYAADQ11x62e6Y+6QAAAAAAAAAAAAAAbEneFgAAIABJREFUAADgSnLYuQMaAAAYhkH1r/oGbmAJCEGqAQAAu6QaAAAAAAAAAAAAAAAAAPCpDgAA///s3AENAAAAwqD3T20PB0GQagAAAAAAAAAAAAAAAAAAAADwpRoAAAD//+zcMQ0AAAjAsDnDvysMYICktbB/phoAAPDXaAcAAAAAAAAAAAAAAAAAh2oBAAD//+zcMQ0AAAjAsEnDvyoMYICktbB/phoAAPDXaAcAAAAAAAAAAAAAAAAAh2oBAAD//+zcQQ0AIBAEsfVFkIMPfCCHnC9M8IG0DsbAmGoAAMCDxi5DjYtWb/ObGAAAAAAAAAAAAAAAAACSJAcAAP//7NwBDQAADMOg+ld9BRewBIQg1QAAgE1SDQAAAAAAAAAAAAAAAAD4VAcAAP//7NwBDQAAAMKg909tDwdBkGoAAAAAAAAAAAAAAAAAAAAA8KUaAAAA///s3DENAAAIwLA5xzoKEEDSWtg/Uw0AAPhpdAMAAAAAAAAAAAAAAACAQ7UAAAD//+zcQQ0AIBADwUrDDEJOG8EXwQOfIzMONv3XqQYAADQz1x42e6o+agEAAAAAAAAAAAAAAADgSnIAAAD//+zcQQ0AAAwDofOveg72bwJCkGoAAMAeqQYAAAAAAAAAAAAAAAAAfKoDAAD//+zcMQ0AAAjAsDnDvysc8JO0FvbPVAMAAP4ZzQAAAAAAAAAAAAAAAADgUC0AAAD//+zcQQ0AQAgDwUpD+kkjeOBzZMbBpv861QAAgP+UzVa9Qy0AAAAAAAAAAAAAAAAAjCQNAAD//+zcQQ0AIBAEsfVFkIMPfCCHnC9M8IG0FuY/phoAAPCQsWvqddfqzVQDAAAAAAAAAAAAAAAA4DdJDgAAAP//7NwxDQAACMCwOcO/KyRwk7QW9s9UAwAAfhm9AAAAAAAAAAAAAAAAAOBQLQAAAP//7NwxDQAACMCwScO/KiRwk7QW9s9UAwAAfhm9AAAAAAAAAAAAAAAAAOBQLQAAAP//7NxBDQAgEAPBmsUHp43gi+CBz5EZB5v+61QDAACaGGtPWz1Xn/UAAAAAAAAAAAAAAAAAcCU5AAAA///s3DENAAAIwLA5w78rLPCStBb2z1QDAAD+GK0AAAAAAAAAAAAAAAAA4KBaAAAA///s3DENAAAIwLBJw78qLPCStBb2z1QDAAD+GK0AAAAAAAAAAAAAAAAA4KBaAAAA///s3EENACAQA8H6IsjBBz6QQ84XJvhAZiRs/3WqAQAADxi7pp3uW73pCgAAAAAAAAAAAAAAAPCjJAcAAP//7NwxDQAACMCwOcc6FnhJWgv7Z6oBAAA/jE4AAAAAAAAAAAAAAAAAcFQtAAAA///s3DERAEAIBLEzi4/3xuALDd9RJBa2X1MNAAA4rnqeRgAAAAAAAAAAAAAAAADwIckCAAD//+zcQQkAQAwDwTirtnNeKqJwlBkHS/5xqgEAAP8rG614B5sAAAAAAAAAAAAAAAAAGEkaAAD//+zcMREAIBDAsEp7Myjl8IUGNobEQveaagAAwMfWPlONRgAAAAAAAAAAAAAAAADwoLoAAAD//+zcQQ0AQAgDwTrH2klDBQk5Zhxs+q9TDQAA2K3sM+Z92gUAAAAAAAAAAAAAAABwXpI0AAAA///s3FEJACAUBMHrJcIrYyrjiL1MIYjMVNj/NdUAAIBHjbUrSelzx+zNVAMAAAAAAAAAAAAAAADgV0kOAAAA///s3CEBAAAIwLD3L0U1OqAQW4X7m2oAAMBfow0AAAAAAAAAAAAAAAAAHFQLAAD//+zcQQ0AIBADwZrFB6eN4AsVJOSYcbDpv041AADgQWPtaZerqnEbAAAAAAAAAAAAAAAAwPeS5AAAAP//7NwhAQAACMCwN6c6HVCIrcL9TTUAAOCn0QUAAAAAAAAAAAAAAAAAjqoFAAD//+zcUQkAIBBEweslxrGHPQzjx2EvUwiiMw0e+79ONQAA4DIt17TJWaOW/nIfAAAAAAAAAAAAAAAAwPciYgMAAP//7NwxEQAgEMCwSnszKOXwhQgWhsRC95pqAADAR9Y+U40mAAAAAAAAAAAAAAAAAPCgugAAAP//7NxBDQBACAPB+jfFSUMFCTlmHGz6r1MNAADYpewx7n3eBwAAAAAAAAAAAAAAAHBekjQAAAD//+zcAQkAMAwEsTdboWPMV12MQhMHZ+BMNQAAYIi6z1Djj7MhEgAAAAAAAAAAAAAAAGC1JA0AAP//7NxRCQAgEETBjWYZexhNEHtdCxFupsFj/9epBgAAfGCeu5IMWzyxGzQCAAAAAAAAAAAAAAAA9JakAAAA///s3EEJACAABMHrJcYxh0GMI/YSSyjITIX9r6kGAAA81uY6M42uwx2jFlMNAAAAAAAAAAAAAAAAgN8l2QAAAP//7NwxAQAACMOw+TeFNR40wEFioX9NNQAA4NAMNUqDNYYaAAAAAAAAAAAAAAAAAB8kaQAAAP//7NwxAQAADMIw/Luas8ngIHFQAzXVAACAEkONihtsBgAAAAAAAAAAAAAAANiT5AEAAP//7NxBAQAACAIxmlvNaLbQh1uDIwBONQAA4E7Zfl0/6wUAAAAAAAAAAAAAAAD4KckAAAD//+zcQREAEABFwd/LmFFGKmEcjF5acLAb4QV4phoAAPBAX3smadrfNWox1QAAAAAAAAAAAAAAAAD4QZIDAAD//+zcMQEAAAjDsFnHOS7gWOKgBmqqAQAAxww13kxpNwAAAAAAAAAAAAAAAECfJAsAAP//7NwxDQAgEAPADlhFJyQEXwQTMPydg7Z7m9kBAOCNvvY90hjq/mYWzQ0AAAAAAAAAAAAAAABQT5IDAAD//+zcMQ0AMAwEsVdoVUVaskFRZYhN4fYr2QEA4D9DjXnvHlMNAAAAAAAAAAAAAAAAgC2SNAAAAP//7NwBCQAACMCw909tCkFwCzKpBgAALBNqnCDUAAAAAAAAAAAAAAAAAPikGgAAAP//7NwxDQAgEAPADgjDDEIJwRdBBGH4Owdt9zaDAwDAO2Pte6bRVfzdLJ4fAAAAAAAAAAAAAAAAoJYkBwAA///s3AEJACAMAMH1EuOYQ3sYR+wlhhCE3UX4AG+qAQAAD7S170ijG2r8YdYysjcAAAAAAAAAAAAAAAAASCUiDgAAAP//7NwxDQAgEATBM4sPpH1C8EWDBIpPmLGw/ZpqAADAY2PteYca9FA6AAAAAAAAAAAAAAAAAHwmyQEAAP//7NxBDQAgEASxlXZmEEoIvvgggQfJtRJGwJhqAADAI2PtujON0vQrs3sAAAAAAAAAAAAAAAAAgHaSHAAAAP//7NxBDQAgDACx+SLIwQc+EMNjwRcmeJCslXACzlQDAAAeGHm2mcafVm+zegMAAAAAAAAAAAAAAACAciLiAgAA///s3FEJACAQBcFX1hxWE8Rechn8EW4mwgZYUw0AAHgw9qlhw9TwW6t7AAAAAAAAAAAAAAAAAICWklwAAAD//+zcQREAAAjDsPl3hTM88OOWSKiAmmoAAMCBmcYb0x4AAAAAAAAAAAAAAAAAoFKSBQAA///s3FENABAARdHXy2zK6KGHOKaXCn7NORFugGuqAQAAl/raLUkz03jHrGX83gAAAAAAAAAAAAAAAADgS0kOAAAA///s3LENADAIBLHfHGVzGnrqCHuF689UAwAAFjPTqBlq8I+nFQAAAAAAAAAAAAAAAMBRSRoAAP//7NwxEQBACASx868Kad9Ah4EfEgvbr6kGAAAseqQxMw3+VLoBAAAAAAAAAAAAAAAAHJXkAQAA///s3EENwCAABLDzRRbU4GM+ZoaE4IsPj1kgtEIq1QAAgJ825puk7lCDc/XvKVINAAAAAAAAAAAAAAAAgFslWQAAAP//7NxBDQAgEMTAk4YZdKCNEHzdBxXsjIQKqKkGAADR5rnjDTRWeovP7PQAAAAAAAAAAAAAAAAAANGqqgEAAP//7NwxEQAgEAPB+GIYrOEDszRfoIHfbSIg/YlqAADQyhPRWLV86Myx/QoAAAAAAAAAAAAAAADQWJILAAD//+zcAQEAAAjCMKrb3B6wRXiAm2oAAFDNRGPSrQcAAAAAAAAAAAAAAAAAmJfkAQAA///s3EENACAMA8CaRQdIIyH42hcN7M5B23+dagAA8I1x7nqyTMu2tbsXAAAAAAAAAAAAAAAAANBekgIAAP//7NxBDQAwCASw80WmdGYmbX8cEFohlWoAADBKizMiz6B595RUAwAAAAAAAAAAAAAAAGC7JB8AAP//7NyhEQAgAAOx3wxWY3MOj8EhkhFa/6IaAAB84RLLOEY1PcSDZSwAAAAAAAAAAAAAAAAAqjYAAAD//+zcQQ0AIBADwfoiaEMIZk4aCu5LIJmR0P5XVAMA+E4TX+Btyz9cUHuOMjQAAAAAAAAAAAAAAAAASXIAAAD//+zcQQ0AAAgDsVnHOcneGCBpJZyAM9UAAD4yaAAuowoAAAAAAAAAAAAAAAAAlWQBAAD//+zRAQkAMAwEsae2xpTOTKUNKqMkEu5KCQAAYIF+97SRAAAAAAAAAAAAAAAAAIwkHwAA///s3DENAAAIwLBZxzkfIkhrYf9MNQAAgA9GRQAAAAAAAAAAAAAAAABOtQAAAP//7NxBDQBACASx9UVOKWaQxu88kLQW5j+mGgAAwHXTr0ZFAAAAAAAAAAAAAAAAAL4kCwAA///s3DENAAAIwLBZxzk3EkhaC/tnqgEAAHw3CgIAAAAAAAAAAAAAAABwVAsAAP//7NxBDQBACASx9UVOKWaQxvskkLQW5j+mGgAAwGXTr0ZBAAAAAAAAAAAAAAAAAD5JFgAA///s3DENAAAIwLBZxzkCUEDSWtg/Uw0AAOCzUQ8AAAAAAAAAAAAAAACAo1oAAAD//+zcQQ0AQAgEsfVFTilmkIaAU0DSWpj/mGoAAABXTb8a9QAAAAAAAAAAAAAAAAD4JFkAAAD//+zcQQ0AQAgEsfVF7oFOzGLgDJC0FuY/phoAAMBJ86qVAwAAAAAAAAAAAAAAAOAryQIAAP//7NwxDQAACMCwWcc5ChBA0lrYP1MNAADgo1ENAAAAAAAAAAAAAAAAgFO1AAAA///s3EENAEAIBLH1Rc4bPjCLghNA0lqY/5hqAAAA58yrVg0AAAAAAAAAAAAAAACAryQLAAD//+zcMQ0AAAjAsFnDvykc8JO0FvbPVAMAAPhmFAMAAAAAAAAAAAAAAADgVC0AAAD//+zcQQ0AQAgEsfVFTilmkIaD+5O0FuY/phoAAMAl069GMQAAAAAAAAAAAAAAAAC+kiwAAAD//+zcMQ0AQAgEwfNFvkAnZpHwNcmMhe3XVAMAADhjXrVaAAAAAAAAAAAAAAAAAHwlWQAAAP//7NxBDQAADAOh8696FvZtAkKQagAAACuEGgAAAAAAAAAAAAAAAAD8VAcAAP//7NxBDQBACASx9UVOKWaQhoX7krQW5j+mGgAAwAXTr0YpAAAAAAAAAAAAAAAAAL4kWQAAAP//7NwxEQBACASx88V8gU7MYuFLisTC9muqAQAAnDevWiUAAAAAAAAAAAAAAAAAviVZAAAA///s3DEBAAAMw6D4Vz0N+3qAEKQaAADAOqEGAAAAAAAAAAAAAAAAAD/VAQAA///s3DERAEAIBLHzxbxSzCANDd9RJBa2X1MNAADgsulXoxAAAAAAAAAAAAAAAAAAX5IsAAAA///s3DERAAAIA7Faw78prhLYGBILv7+pBgAA8FWHGqMOAAAAAAAAAAAAAAAAAGdJFgAA///s3CEBAAAIwLBXpzkdUIitwv1NNQAAgK9GGQAAAAAAAAAAAAAAAABOqgUAAP//7NwxEQAwDMSw55XrUJwlE2jlkCmDRMG7TTUAAICN7jvVygAAAAAAAAAAAAAAAAAwkuQDAAD//+zcMQEAAAjAoFW3uSF8PCAIUg0AAOCbEWoAAAAAAAAAAAAAAAAAcFItAAAA///s3DERADAMxLDnlSu38iiZQCuILBkkCt5tqgEAAGzS79RVBAAAAAAAAAAAAAAAAICRJB8AAP//7NwxEQAACAOxWsO/Ka4aWBgSC7+/qQYAAPBFhxqjBgAAAAAAAAAAAAAAAABnSRYAAP//7NwxAQAADMOg+Fc9Ezt6gBCkGgAAwAShBgAAAAAAAAAAAAAAAABvqgMAAP//7NwxAQAADMOg+Fc9Ezt6gBCkGgAAwAKhBgAAAAAAAAAAAAAAAAB/qgMAAP//7NwxDQAwDASx5xV1KM6SCbSSiJTFpnD7mWoAAADb7jvVKgAAAAAAAAAAAAAAAAAwJskHAAD//+zcQQ0AAAwDofOveiaW9ANCkGoAAABLQg0AAAAAAAAAAAAAAAAA/lUHAAD//+zcMREAAAwDofevuip6WUAIUg0AAGBFqAEAAAAAAAAAAAAAAADAj+oAAAD//+zcMREAAAwDofevuip6WUAIUg0AAGBBqAEAAAAAAAAAAAAAAADAn+oAAAD//+zcMQEAAAzDoPhXPRXrBUKQagAAAGtCDQAAAAAAAAAAAAAAAAB+VQcAAP//7NwxAQAADMOg+Fc9FesFQpBqAAAAS0INAAAAAAAAAAAAAAAAAP5VBwAA///s3DEBAAAAwqD1T20LLwiCVAMAAHgRagAAAAAAAAAAAAAAAADwUQ0AAP//7NwxAQAAAMKg9U9tCy8IglQDAAB4EGoAAAAAAAAAAAAAAAAA8FMNAAD//+zcMQEAAAjAoPVPZTRT6AVBkGoAAACXRqgBAAAAAAAAAAAAAAAAwLtqAQAA///s0DERACAMBLAf6opjQCdmkFYVZUokpKwDAABD3t3ryAUAAAAAAAAAAAAAAADguyQNAAD//+zcMQ0AAAjAsAX/olFBeFoJE7BRHQAAOGCoAQAAAAAAAAAAAAAAAMCfagEAAP//7NAxEQAgDASwH+qKY0AnZpBWE71jSSSk9AMAAMPO3etJBQAAAAAAAAAAAAAAAOCbJA0AAP//7NwxDQAACMCwBf+iMUHC00qYgI36AADAIUMNAAAAAAAAAAAAAAAAAP5VCwAA///s0TERACAMBMEv4oqhQCdmkBYTKSh2JdyVDQAAwIB39zpCAgAAAAAAAAAAAAAAAPCFJA0AAP//7NwxEQAACAOxHs5xXhEsDImF33+UAAAAjtZQAwAAAAAAAAAAAAAAAIBXkhQAAP//7NwhAQAACAPBCfpnIhqGBCjEXYSfX1kEAAA46j3UaAEBAAAAAAAAAAAAAAAAeCXJAAAA///s3DERAAAIA7FKRzpXC0wMiYQX8KYaAADARWcaoxwAAAAAAAAAAAAAAAAALyVZAAAA///s3DEBAAAIw7D5VzVpPBjg40gkVEBNNQAAgIvuUKOqAQAAAAAAAAAAAAAAAPBWkgEAAP//7NwxEQAACAOxSkc6VweMDImEF/CmGgAAwFVnGqMWAAAAAAAAAAAAAAAAAO8lWQAAAP//7NwxDQAADMOw8kdVaHv2755kQwiAmGoAAACX7lCjSgEAAAAAAAAAAAAAAADwQpIBAAD//+zcQQ0AAAgAoatm/1I28O8GQZBqAAAAl5FpAAAAAAAAAAAAAAAAAPBOtQAAAP//7NwBDQAwCASx90XmbdOB2RnAAEkr4QScqQYAADB5feoqAwAAAAAAAAAAAAAAAMBKST4AAAD//+zcMQ0AAAzDsPJHVWh7dozCJBtCAMRUAwAAuLpDjaoCAAAAAAAAAAAAAAAAwFtJBgAA///s3AENAAAAwqD3T20PB0GQagAAAMk0AAAAAAAAAAAAAAAAALhSDQAA///s3AEBAAAIw6D1T20PD0GQagAAwDaZBgAAAAAAAAAAAAAAAAD/VAcAAP//7NwBAQAACMOg9U9tDw9BkGoAAMAmmQYAAAAAAAAAAAAAAAAAf1UHAAD//+zcAQEAAAjDoPVPbQ8PQZBqAADAFpkGAAAAAAAAAAAAAAAAAP9VBwAA///s3EERAAAMwjCkT/oOHSQW+q+pBgAAbOhI47QGAAAAAAAAAAAAAAAAYEKSBwAA///s3AEBAAAIw6D1T20PD0GQagAAwG8yDQAAAAAAAAAAAAAAAAD2VAcAAP//7NwxAQAACMOw+Vc1aTyogMRC/5pqAADAPd2ZRrUFAAAAAAAAAAAAAAAA4KUkAwAA///s3EERAAAIw7BJRzo3G5BY6L+mGgAAcEdHGqMnAAAAAAAAAAAAAAAAAO8lWQAAAP//7NwxDQAgAMCw+SKIQwdmkMaDCZLWwv6ZagAAwN9WdfYcR0cAAAAAAAAAAAAAAAAAeKoLAAD//+zcQQ0AAAwDofOveg72bwJCkGoAAMAekQYAAAAAAAAAAAAAAAAAfKoDAAD//+zcQQ0AAAwDofOvehb2bQJCkGoAAMAGkQYAAAAAAAAAAAAAAAAAfFUHAAD//+zcMQEAAAjAoFWzfykz+HlAEKQaAADw24g0AAAAAAAAAAAAAAAAAOCoWgAAAP//7NExEQAACAOxHsrwr6oa2BgSCf+jGQAAvLb2AAAAAAAAAAAAAAAAAMBRkgIAAP//7NwxEQAwCASwN4uOiuPwhYZuDImQSDUAAOC2Vz1iDQAAAAAAAAAAAAAAAAD4kWQBAAD//+zcIQEAAAjAsDenOhlwiK3C/U01AADgv9EIAAAAAAAAAAAAAAAAAA6qBQAA///s3DERAEAIBLGThplXyuALC19SJBa2X1MNAAC4r15P6QQAAAAAAAAAAAAAAAAAn5IsAAAA///s3DENAAAIwLA5xzoWeElaC/tnqgEAAD+MTgAAAAAAAAAAAAAAAABwVC0AAAD//+zcMQ0AMAwEsYcWMuVRblV4lULWSDaF289UAwAAdqjz+moFAAAAAAAAAAAAAAAAAANJPgAAAP//7NwxDQAACMCwOcc6FnhJWgv7Z6oBAAB/jFYAAAAAAAAAAAAAAAAAcFAtAAAA///s3EENAEAIBLE1i4/zRvCFhHuTtBbmP6YaAABwSPU8vQAAAAAAAAAAAAAAAADgI8kCAAD//+zcMQ0AMAwEsYcWMsVRcFV4lUH2SDaF289UAwAAdrnndWkGAAAAAAAAAAAAAAAAAIMkHwAA///s3DENAAAIwLA5xzoO+ElaC/tnqgEAAP+MZgAAAAAAAAAAAAAAAABwqBYAAP//7NxBCQAgFAPQf7CVCJYxiDksI4i9LOFFea/BtvuSfgCAB3WjPcUBxH21rV1HyfO3YAAAAAAAAAAAAAAAAABwRUQcAAAA///s3EENwCAABMGrLoKc+sAHYngQfCGi6QMy4+By/xXVAACO02tpXjvHO1eENX4xkjwX7gIAAAAAAAAAAAAAAACA75JsAAAA///s3DERADAIBMEfvEYpgy8MpKXblXACrmQEAOCSCcqd16MtAAAAAAAAAAAAAAAAAPwkWQAAAP//7NxBEQBACAOxWkPZWUcEwz2YxMFWQJ1qAADwQ1l5xTvYBAAAAAAAAAAAAAAAAABzSRoAAP//7NxBDcAgFETB9UWQgyrE9CdNfSECeiEzDt4KWKcaAAD8bvZWScrS5433e25rAgAAAAAAAAAAAAAAAIBtSRYAAAD//+zcsQ3AIAwEQO+FIrEMeyRzMA5iL1rqSFDA3Qbvr9+7n2oYUgJcpD7p1Tcw+RxjiVxazwfmAgAAAAAAAAAAAAAAAID/ImIAAAD//+zdsQ0AMAwCMD7P611yQaV0SO0P2Jjg6ahGP5QDAPCh7oL64IzaGAoAAAAAAAAAAAAAAAAAriU5AAAA///s3FEJACEUBMDXSwQNYyrjiL3sICrcMdNg93/36akGwEcZKgMc0nOquryitDHLD3MBAAAAAAAAAAAAAAAAwJ6IWAAAAP//7NxBDQBACAPBWkfZWcMDCfcgMw62AupUAwCA38riK97BJgAAAAAAAAAAAAAAAACYSdIAAAD//+zcQQ0AIBADwfNFkIMO8IEcgi+CCB4XZiRs/3WqkUv/PQAAkN+sZZjxjba2tgAAAAAAAAAAAAAAAABwRcQBAAD//+zcQREAAAjDsFnDvyluIjg+iYQKqKkGAAAfRvUTJmwAAAAAAAAAAAAAAAAAUEkWAAD//+zcUQkAIRRE0eklxjGVYfbBsr3MIMh+yDkN7gQYpxoAAPxu9lZJyvLnjfd7bmsCAAAAAAAAAAAAAAAAgG1JFgAAAP//7NxBDQAgEAPBSjszCEEbwRcW7kNIyIyDrYA61QAA4JVp+StqrF0fdgEAAAAAAAAAAAAAAABAX5IDAAD//+zcQQ0AIBADwfoiaEMIZk4aFu5DSMiMg62AOtUAAOCJPUclKetfsT5sAgAAAAAAAAAAAAAAAIC+JAcAAP//7NxRCQAgEETB6yWChrGHPYwj9rKCPyLITIO3AdapBgAAz4ycqvWvKG2u/mEXAAAAAAAAAAAAAAAAAJyJiA0AAP//7NzBCQBACAPBdC7XuS34kQOZ6WDJP041AAD47VlgRR1sAgAAAAAAAAAAAAAAAICZJA0AAP//7NwxDQAgEAPA90WQgw98YIaE4AsLLITh7yS0Scf+ONWY6gFIwd4DV0YtXVJvtLVlCwAAAAAAAAAAAAAAAEBOEXEAAAD//+zcwQkAIQwEwJSmxViHtYnYlx0IIiJ3zHSwIeS3efFUo1k34CuUkY+498CObFpX1NJH+mEuAAAAAAAAAAAAAAAAAFiLiAkAAP//7NxRCQAgFAPA9RKzGcQyRrOBPyLC467B2Pf241SDC0aRAEBFs7eVZCn3iVEwEwAAAAAAAAAAAAAAAACcJdkAAAD//+zcMQEAMAjEwJeGtTpHBQPlzkL2mGrsY6oBAPzqKTuijNkAAAAAAAAAAAAAAAAAOCdJAwAA///s3EENACAQA8H6ImhDCGZOGgruSULIjINN/3WqAQDAE/YclaSsccX6sAkAAAAAAAAAAAAAAAAAekkOAACv444nAAAgAElEQVQA///s3EEJACAURMHfSwQNYw97GEfsZQGvgshMg8fe16kGAADPGDlVa1xR2lz9wy4AAAAAAAAAAAAAAAAAOIuIDQAA///s3MEJAEAIA8F0Lte5DfgVDpnpYMk/TjUAAPjNs8iKOtgEAAAAAAAAAAAAAAAAALMkDQAA///s3DENACEURMHvixDU4AMfiKEg+EIACR1XXGYc7BOwTjUA7oo+AN/qOTXJ36hzjT/uAgAAAAAAAAAAAAAAAIBDRGwAAAD//+zcsQ0AIAgEQEbDYZzUuJc7SKQwdyN8wVdP+1MNI8kyA3/olfK+494DRUOAT+RcW7cBAAAAAAAAAAAAAAAA8L+IOAAAAP//7NwxDQAgEAPA+iJoQwhmkMbMTGD43DloOrffTzW4ZgQJAJQ3e1tJlqafGAUzAQAAAAAAAAAAAAAAAMApyQYAAP//7NxBDQAgDATBk1YzCEEbwRcqmjRkxsL+11QDAICptjItap1r1AYAAAAAAAAAAAAAAADA35I8AAAA///s3MEJACAQA8H0JVZqMV5pPq8CQWSmgyX/ONUAAOBJa45KUta5Yn/YBAAAAAAAAAAAAAAAAAAtyQEAAP//7N2xCQAgEAPA30ssHMY93MNxxL0Ee0sR5G6DkD4xqgFw4MUf4L2eU1HDHXXM9mMuAAAAAAAAAAAAAAAAANgiYgEAAP//7NzBDQAgCAPAbk7c3IczaMDcbdCQPounGgMZ+sMzugbQw3KHK+rDTAAAAAAAAAAAAAAAAABwJNkAAAD//+zcQQ0AIQwEwPoiyMEHPhDDg+ALEUC4XGYcbB/72756qmEYucfQH/g6PQ8c03KqrnlHGbP/MRcAAAAAAAAAAAAAAAAAREQsAAAA///s3FEJACAQBcEXTcNcUrGXGfyQA5mJsAG2a6oBAAA3plpPjFrbsA0AAAAAAAAAAAAAAACA/yQ5AAAA///s3EENACAQA8H6ImhDCGZOGiouITDjYNN/nWoAAHC9PUclKUu1WA82AQAAAAAAAAAAAAAAAPC7JAcAAP//7NxJEQAgDAPAOqNmEII2Bl+ogOHYdZDmnXqqcafy+wFgEyNjgLM0fSyRtY98MBcAAAAAAAAAAAAAAAAAP4uICQAA///s3UENACAMA8D5IihFDEhDxCAQuHPQT39bTz3VsDKe4+gRuJ2eB5ZrtQz9sk1/NBcAAAAAAAAAAAAAAAAAv4qICQAA///s3DENACAMBMD6IgyIwQc+kEPwxYIFQgJ3Dr7Db98rTzX2IBKAR+l54JSeU3HcM+qY7cVcAAAAAAAAAAAAAAAAAHwqIhYAAAD//+zcQQ0AIBADwUrDDDoI2gi+UEG4kBkL++ivT041AKrrazeRAMqa0lwx7B8AAAAAAAAAAAAAAAAA30hyAAAA///s3UENACAMA8D6ImhDCGZRsWTAnYP+9mlnVONSPolDOaVigKb2HO6gOuvVYAAAAAAAAAAAAAAAAAB8JskBAAD//+zcMQ0AMAwEsYeWginSKryKIkMkm8LtZ6oBAMBGR7URdV8bSwEAAAAAAAAAAAAAAACwX5IPAAD//+zcMQ0AIAADsPkiaCPowAzSuBFASKB1sB07d/NUo79SIgAb+w4cN2qZSaamj2gPZgIAAAAAAAAAAAAAAADgN0kWAAAA///s3EENACAMA8A5AzP4wBvBFyLIAoE7B+2/PXmqwZ6iP0hlUAxwPyc+OWobs78YDAAAAAAAAAAAAAAAAICPRMQCAAD//+zcQQ0AIAwEwfNFSPCJmUpDBY+mMxJWwJpq9HWmBwAAZrt7VZKa3uETcykAAAAAAAAAAAAAAAAAekvyAAAA///s3DENACAQBMH3RSgQgw98IOeDL1RQADMONtefUw0AAK41a2nWO6PnGi92AQAAAAAAAAAAAAAAAPCJiNgAAAD//+zcwQkAIQwEwPQlgs1Yx2EdliP2ZREinjDTQfJY8tlce6rRc1LS21THLE8PAD+lRLxHvgMXNEs/4nNvAgAAAAAAAAAAAAAAAPCsiFgAAAD//+zcAQ0AMAwCQZzP+ky0WcLuHCCAfxbVYISTIwDwPTGfVad4GwAAAAAAAAAAAAAAAADNklwAAAD//+zcQQ0AIBADwToDxKCU4OsE8OZxyYyE9r+iGgCvYROAdpbLvpj7XCE3AAAAAAAAAAAAAAAAAPpJUgAAAP//7N3BCQAwCAQw9yqd1GUcrTsURIRkAX/HfdTpoxo1PH87n8Ohh+Xhf3IdGJH3lAxqo3MCAAAAAAAAAAAAAAAAsE9EPAAAAP//7NxBDQAgDAPAScMMPkAaIfjCBGTJcmegWR99LvupxkrOB+Atuw5kmtr/ovV9RsG7AAAAAAAAAAAAAAAAAKgsIi4AAAD//+zcUQnAMBAD0Pgag5mpjgqZmcKYr4pYS1l5z0Eu37nVTzX4qDzv5YYwjtEwwH/d59GSNBVOUTfMBAAAAAAAAAAAAAAAAMDOknQAAAD//+zcsQkAIBADwN9LLBzGqRzGQtzLxg1EBLnbIOmT16caRo/nnGoAAGwtp6KLO+qY/cdcAAAAAAAAAAAAAAAAAHwqIhYAAAD//+zd0QnAIAwFwOxVil3GPdo5Oo50L3/cQIsodxOEPPL7MrVUo30Tp0+yPxjKTXV4z+NednhgJ480f3Hl8il0AwAAAAAAAAAAAAAAAGANEVEBAAD//+zcwQ0AMAgCQDZ39S6hMTV3G/DgCaunGrQwbIReOgXwOQc/o+pwNgAAAAAAAAAAAAAAAAAuSfIAAAD//+zdwQkAMAgDwIxmN+9onaKgcjdBwEd+scOoxm2QASC+7wOscpzzi9KXAAAAAAAAAAAAAAAAAIyQ5AEAAP//7N0BDcAgDATA+lomZ0LQgZhtWfA1EUACzZ2Cr4D/rjCq8S6QYWvX13xjhzGUhPuUncMDudTzeIy3TXMnvQsAAAAAAAAAAAAAAACATCLiBwAA///s3EENAAAIA7E5w78rVJAspLVw/2uYagC0GCUAXjH7OWLqBgAAAAAAAAAAAAAAAEC9JAsAAP//7N3BCQAgDAPA7iWCmzmIyzhahxChyt0GoZ+80gqjGj6In5uvB4AihkMA/GP1tnXNa/RPAAAAAAAAAAAAAAAAAGqLiAQAAP//7NyxDcAgEAPA3wtRZBj2yB4MkwKxVxo2QBHK624Dy7V9/FRjjR0BjmpjOtTY1Gu5fx0ASKnXcmn2G23MJ2MuAAAAAAAAAAAAAAAAAJKIiBcAAP//7NzRDQAQAEPBjmYZg5hN7GUIhMjdCv3uux7VYI/ahzM7rBHVAPhXs+0RRZQKAAAAAAAAAAAAAAAAgGclmQAAAP//7NxBDQAgDAPA+SIEaQjBDNIQQQiM3ClYH32ur4xqeHTc17IHgMt0aM/MfDzwt1GL8bFz+q/BAAAAAAAAAAAAAAAAAEguIhYAAAD//+zd0QkAIAgFQEerYRo0or0aQgKjuwkeiPj3rFKqQZ4v4ZBjh3Lmy+GBL3RjvqKNtd1QAAAAAAAAAAAAAAAAAOqJiAMAAP//7NxBDcAwDANA85oKpzzGY2BaqSqvcpi0x6I7Bo7fjqcahRg0wjt97dvpAGp72jWTTDV/YhTMBAAAAAAAAAAAAAAAAMDfJTkAAAD//+zc0QkAIAhAQfeKaLbmaNl2sAKDuxEU/POViGqs3jy03yGqATnD3M6448AnpkW9IVAFAAAAAAAAAAAAAAAAQDkRsQEAAP//7NzBCcAgAAPA7CWO0zkcpMsI0r3cQSwI3o2QPPLLEacabNNECUsc0gBc4K2lJ+m6/kV7xmdPAQAAAAAAAAAAAAAAADhHkgkAAP//7N3BCQAgDAPA7CU+nNNlnUGoUOFuhdBn0k6jGj6HF1BmhDtupoSCOvCNPceS1jMG3gAAAAAAAAAAAAAAAADoI8kBAAD//+zcQQ0AIBADwUrDOs7QQOCSI8w46KPf7RTV4A6BANjjM+fm6wOA74i51RhiVQAAAAAAAAAAAAAAAAC0kWQBAAD//+zdwQkAIAwDwOwl7uYeLuNozuBDKHo3QaCU/tJKpRqrQIYX+BAOZ+wMwGdmb8PMr3FXAQAAAAAAAAAAAAAAAKghyQYAAP//7N1BCQAgEATA6yWChjGVccReVvChoDBTYR/32r1nRjV6TkY1DvEhHPa0MZWqD1BOBz5VBXdFcV8BAAAAAAAAAAAAAAAAeEJELAAAAP//7Nw7EQAgDETBc4Y0rNNEAAXM8Nl1kFRXvWOiGkVYYw1RDZjT/AngTxV0sz336C8eBQAAAAAAAAAAAAAAAMBlkgwAAAD//+zcyQkAIAwEwDRrH1qaiH3ZgiCCx0wF2c/+sqeNatQDbniBR0aYY4BmXbk9APA1HbZJaj0/GQwAAAAAAAAAAAAAAACAe0TEAAAA///s3MEJwCAAA8DsVRyncziIywile3UDXxUF70YI5JnsdqrBTwwZYUxHAGjl6kn68UHMUe/ndV4FAAAAAAAAAAAAAAAAwDpJPgAAAP//7NzbCQAgCAVQ94qIJmuQlm2Iih6cs4Fe0C+96qlGz8mR+zrll0Jgk6ax88xt4HU9pyrEbexaAAAAAAAAAAAAAAAAAM6JiAEAAP//7N2xCQAwDAMwn5bX+nn30rEhHaQTDAFPzlejGjxVvoPDndsA4LAE0kIfBQAAAAAAAAAAAAAAAGBOkg0AAP//7N1BDQAgDASw+SJ4wwdiQBoGeI6EQOvgltxz241HNSw15vEdHPZ0I8d8IQRAr6V9P4RzxqvBAAAAAAAAAAAAAAAAALhcRCwAAAD//+zdsQkAIAwEwKzmMA4q4l42qaxVRO42SODb/xdLNdjHMjgscjFfNvZoPxwBkIpHnFH7UFoCAAAAAAAAAAAAAAAAwH0RMQEAAP//7N3BCQAgDAPA7CXO5iAu42gO4LeCyN0GpZBf0+dKNXwKr+WIEQ4KNYrIa+Ans7eVZFnqFePDmQAAAAAAAAAAAAAAAAB4XZINAAD//+zcsQkAIAwEwCzrIE5mIe5lncJOIcjdBh/48lPuqQbXGTFCphMAnHSXeaPNNX7MBQAAAAAAAAAAAAAAAEBhEbEBAAD//+zc0QnAIAwE0NurFFzGPbpHlxHEvRyiFkTe2+AIl79k16caDhoXqn08x4SBD3RhKXsaOM57Xy1JM9lflNpHOTAXAAAAAAAAAAAAAAAAALtKMgEAAP//7NzJCQAgDATA9CU+rMxCbNYO8vFAZKaDDYS8Nq8+1VBm3Kv/FAYW2AUAUqOWZkLHuMMAAAAAAAAAAAAAAAAA3BMREwAA///s3UENACEMBMD6upBgBh+g4+QQfN3nJEBCYMZBd9Nvu+VRjf9LOBOVPqo8uZkdmOtNjzyBkzXtLpFLH/nAuQAAAAAAAAAAAAAAAADYUUR8AAAA///s3bENACAMA0Hvv1RWo2EACpCicLeBi7SfllGNTVjjLp/B+Z0bAOCIcNBTNXgbAAAAAAAAAAAAAAAAAJ0kWQAAAP//7NzRCQAgCAVAV2uYBmm0iPZqgT4rou4m0Ifgl978VKNeUMNTcusORPmS2V+uPNYPwEySyh72MgAAAAAAAAAAAAAAAABHRMQAAAD//+zdwQnAMAgFUPcKhS6TOTJIlwmU7JVLj+2tQgjvbfBF9KbLHtXwITxFq/c4N8wFn56ebyr0q75RFoBX11G6eZfGXgYAAAAAAAAAAAAAAAAgX0RMAAAA///s3DENACAMBMCaRQjKGAi+WJBAkwbuHHz667fsUw3SGDHyG52/7AzNAX7QXTlHm2u8mAsAAAAAAAAAAAAAAACAQiJiAwAA///s3LEJACAMBMCMlmWcVNzLJqWlgujdBoEnpMnfXqrhkXG/bH3ka0PBSmVd3veyl4FvVImQIqEz3KQAAAAAAAAAAAAAAAAAnBUREwAA///s3cENACAIBDD2Mj6czEFc1iEICdF2gyN8ObqXajhirOEzOL+w6wCknDmWCZbZj+YCAAAAAAAAAAAAAAAAoIOIuAAAAP//7N3BCQAhDATA9CUHNmMfd3VYjtiXH1sIHDpTQgJLXptfl2rs7+AkaGO+5srJ2pgKNRL0p8gO4EafraeoblIAAAAAAAAAAAAAAAAA0kTEAgAA///s3EENACAMA8BJwww6EEfwxWcSIBC4c9Ck3/bqU41kxLhHq32UF4NBdlu/13N0BHzJodBW7eFsAAAAAAAAAAAAAAAAAJwUERMAAP//7NwxDQAgDATAWkMMOgkh+MICAx2AOwff/Nq/YVTDE3ee9mowvqfbOfqLoQA2FYfKUcc0WgIAAAAAAAAAAAAAAADAeRGxAAAA///s3MEJACEMBMD0JcI1Yx1XiOWIfd3HFoKHznQQyGM/u78f1ei1GNVI1MY0PsBR/HSeXovSM3CtlUnl0hxvG/M58TAAAAAAAAAAAAAAAAAANoqIDwAA///s3LEJADAIBEBHy2Yhm6dxBVHkbgKFL2ze8U810hsxxU5HiZEtMsvyXEORHMBNWunuXQ0AAAAAAAAAAAAAAACAFhHxAQAA///s3LENACAIBED2Mk7qMOpmNg5gIYXmbgPCFzT8K6UanrlzdcUavG5nuFtkmvnpXADHWi3DXZpG0RsAAAAAAAAAAAAAAAAAd0XEAgAA///s3bENACAIBED2MhZu5h4ua+MCJlJg7jaAfEIFlDiqcRYYyeU7ONXJcKLV2/y2OIALq7ehX2nMcgAAAAAAAAAAAAAAAADeiYgNAAD//+zdsQ0AIAgEQFZ3MlczJjT2mojeTUAIxVdPiVKN1K6Y4l3zO3j/fQnUlLfru/05io0AVnLpGTOPKnECAAAAAAAAAAAAAAAAYI+IGAAAAP//7NxBDQAgDATB+iJoQwhqcIYFPm0CzDg4Abc3RTWcuvMJa3AdQY0S64ONAMdmb8IPecarwwAAAAAAAAAAAAAAAAAoFhEbAAD//+zdwQnAIAxA0exVBDtMp3IZQdzLBTxqIfDeCDnlkp80UY1Wni6s8QsfwknjG7MKatzneBxg6zWWO+yiAAAAAAAAAAAAAAAAABwREQsAAP//7NyxDQAgCARANjdOZtzMhgk0JGruJoA8BdU/U6qR5hVT/K9lWQFcK290SKhc/3w/gC0K30r5RQEAAAAAAAAAAAAAAAA4FxELAAD//+zdQQ0AIAwEwfoiaEMIYrCGgj5pgMw4qIDbPhXVmL35Wl1nGTNyK0GNUgbjADnhoXPGr4cBAAAAAAAAAAAAAAAAUCQiNgAAAP//7NyxCQAgDEXB7CWCe7qsTVorMSjcDfFJk/dVVCN58K4jrMFzBDVqzd5sLsBGbqSdvGO4QwEAAAAAAAAAAAAAAAA4EhELAAD//+zdsQkAIAxFwb+XWDinyzqCIBgU7kZIkXQvP0Y1fASvJazBMwQ1ytm3ABuzt2FG17j5AAAAAAAAAAAAAAAAAJxLsgAAAP//7N0xDQAhEEXB9XVBDj7wgRyCLxoUkByEMOPgV9u9vS6qMT+Cs5ewBscJauxX01de2wywSIToJ7l1twgAAAAAAAAAAAAAAACANRExAAAA///s3MEJADAIBEE7T+shYAH5qCTMdCDc130uqpE8LvY7YQ1BA0bk9uyvl4ARwCURolLr49sAAAAAAAAAAAAAAAAAqBQRGwAA///s3MEJACAMA8CMVvdfyo8LKFgR7kYIfeTTfDmq4XHxmTKsQbd1cyX4dsaLAPYMed2hfwIAAAAAAAAAAAAAAABwJMkEAAD//+zc0QnAIAwFwOxVhC7jVF1GEPcqFheoIFJ6t0EgPPKT98lSjcHD9x5PsUauTckBS/UdU6ixTbnSUX46O8CUkZuyc43T7QkAAAAAAAAAAAAAAADAaxFxAwAA///s3NEJACAIRVE3b7Y2k6ANQqQ6ZwPB33dvjmoYLfZZo0ZhDcrs3xLU6DN/PRzgkOhbnfHqYQAAAAAAAAAAAAAAAAAUiYgEAAD//+zd0QmAMAwFwOxVhI7mHh3G1UqhC0gVLbnbIOF95Otl21IN38B/YRRrXNmXwLNmpuTqQ+0oZ9rhARa4T19VFboBAAAAAAAAAAAAAAAAcEtEdAAAAP//7N3BCQAgDASw7iU+nNNhXE0KDiCIiJCMUEp/d/22VGPxDfy9DDgOIUdO5Q6tQg279Ja7CnCg19LM7xqlWwAAAAAAAAAAAAAAAADsi4gJAAD//+zd4QkAEBCA0dtLdrOHZaUMIBLqvRXO1f36fB3VGL+Bc1+PIPSwRjELVoy3I6jxgJqTPQbYJ1B0iHsTAAAAAAAAAAAAAAAAgGkR0QAAAP//7NzBCcAwCEBRl3WODCfOlRLoADk0kMJ7I4gHL/5fRzVenhbvMbJ6ZrUwAlvWrmT1imkME7uCUBHABwSKjnIzAAAAAAAAAAAAAAAAALAnIh4AAAD//+zcsQkAIAwAwazm5K4mAQsbrRQi3EEWkBRp/O+jGj4tltQzlCCuwc4S08ixJ3WIFAHc07zlG/OGAAAAAAAAAAAAAAAAAICziBgAAAD//+zcsQ2AIBCG0duLmLAMe7CHy5AY97KBwspGEwzvjfAX1933+6hG5xF8PnnENVYfgrtynFVMY0pt31JbfQSAt/Sb6q5+I4u3AQAAAAAAAAAAAAAAAPAoIi4AAAD//+zcQQqAMAwEwP1X8W32Hz5WCXgUTxaKnXlBDkvIJfuLUo1ja32CMXhWT4/nXaTAwioDlYUkuxxMSTkRwPfs1nHcEwAAAAAAAAAAAAAAAAC8S3IBAAD//+zdsQ2AMAwAQe+FIrFZBmGZjJbGtKlAIvhuBBfu/P5FVCM5Wvy2fsc1fBavRUxjC+Nqx6g+BICn5W61X99xirYBAAAAAAAAAAAAAAAAsBQREwAA///s3M0JwCAMBtA4VxHsaJ3DZUXw6qVQiuG9EQL5uXwpmSq0gvucYQZMH0H+nNbjlOaRxjFuvfgPe+u9Xq9UNwy56fXvmAUAAAAAAAAAAAAAAAAAbEXEAAAA///s3cEJACEMBMBgrxZylSmIfR0pQPAj3MlMBSH7yWtTLtvO84EZ2JOFC62O2XwZv0dmmZlmtgo1fqMr1AA4zo16iDsSAAAAAAAAAAAAAAAAgKWIeAEAAP//7N3BCYBADATA9HUIWoyFWIfliH3JgT9/wnEkzPQQNp9syn129gk8tX7Yfzjwz2W/7vUtSVGikdNm5uaRWf+dSyu3w1CbeR9KlgEAAAAAAAAAAAAAAADwFREPAAAA///s3MEJgDAQBMB92JjFWEewMgWxr4AEUkFEw0wJe9xzd5kwll25/7eecYbtutPueCpIfpMhjWn4MYD3rEkOeQ9R2jgbAAAAAAAAAAAAAAAAAHRJKgAAAP//7N2xCYBAEATA6+v5cuzDPr4YA7EvEUxMRXhYZ0q4ZC/ajVx5twQe5yrYqNHb+vdDzKRII5Jl/8nk1Xujt8gfhmzLfmx3lvI9mQYAAAAAAAAAAAAAAADAU1WdAAAA///s3cEJwCAMBdAc3KvTdBBHk+JeUovgAvYQ3rvkrkhy+bEkPZIq+J/KvMv76esX8vZWwcmztiUalwBwSt4QwP+qnnrMmhMBAAAAAAAAAAAAAAAA4BMRAwAA///s3UENgDAQBMDz1VQOPkBH5TToghcIgJCQuxkJ+9rXbtqXd0/gZVwjGzF6W6uH8YYRjXI8+v/AMvejegZPjd7Sdhhy01E/temDAAAAAAAAAAAAAAAAANwi4gQAAP//7NyxCcAwDARALZs5MloKk72CG5POEJBRzN0Ej0Dq9DuXavRnxatAFNZTtDFxtPs9l7NkSDJ5Oi5CqcZ3SjX4M7ufx20AAAAAAAAAAAAAAAAAYIiIBwAA///s3bEJwDAMBEDtFTxc5sgyGs2QuDApDYFY3HVqhcDVv0uHzvwEzss5jXm1IysvaBTLzPevPIObwPF/CNavc8fsbJRbeZe/oTgKAAAAAAAAAAAAAAAAgEdEdAAAAP//7NyxCQAhEEXB7UyuNCuztePASAxEOFhlpoJNNvzv9qjGFxRoCU7hDHVyZcr4Rh/jjoqIDAuMjRMR1dgnqsHp/P+vntvjaQAAAAAAAAAAAAAAAAAsiIgXAAD//+zdsQnAIBBA0SuyWIZxjuBmAXGvYC8YCIKY9/prxMLmvsfO59SW6VKp2U/gvNS7J1cqdTTdi3F8IY7BLLegBsAyTvG3adqbTlQDAAAAAAAAAAAAAAAA4O8i4gEAAP//7N3BCQAhDEXB9CWWY1UWswexL8ESBEE2M038nPJSVN6VwAE25f7H2KdzvZYUNwz/1sb8PNK6xuYBAAAAAAAAAAAAAAAAZBcRCwAA///s20ENACAMA8AFZ0hDGUjDwj6EBe4UdO177ZMOeoEMADctz8UA5QyTHDMfvQsAAAAAAAAAAAAAAACArIjYAAAA///s3DENACAQA8D3RZCDD3wgh+CLhZ2JhMCdg25d2i9ONdaQ3Jgc+FbLybkQwGV01LNKH/XlfAAAAAAAAAAAAAAAAABsRMQEAAD//+zcsQ0AIAwDsHyO+JwTmJBQY3+QTlnSiqcaMSgHuu32AwD8Skd9ag3OBgAAAAAAAAAAAAAAAMBNkgMAAP//7N2xCQAhEATA60ssx6osRuH5vkzMjQTRmQ42u2T3nhnVmBTLgdf0mpNP/QBnc6NuUr6/XRkMAAAAAAAAAAAAAAAAgLWIGAAAAP//7NwxDQAgEAPAl/Zm8ElC8MXCygghcKegFdB+daoxh+X1gigApxhqA1zO+dFWWVrPh/sBAAAAAAAAAAAAAAAAsBIRAwAA///s3KENACAQA8DfiyCYjDAHy2LQOAT83QZNdZvqVGMzMAeyGLMWR0IAb2h6uqZ/mgsAAAAAAAAAAAAAAACAk4hYAAAA///s3LENgDAMAEHvhZC8TPZgD5aJhNgrjWs6iiR3G1hu3Pi3i2rUg7mwBrC6fp/HZcsAc4oWKxIAACAASURBVKgbVQjpH9meN1ccDAAAAAAAAAAAAAAAAIAPETHYuUMDAEAYBmA9fZ/xGmIaiWAkH9TUtd+daqRHi2W0CAznPAjgPbr7njU1GAAAAAAAAAAAAAAAAAAHSTYAAAD//+zcsRGAIBBFwevLIbAY+5A6KMehLwIMSZlB2a3gLvnh2zKqET2scS5wBsAMuaRDOAjgY97ttt+TXE+9f/kYAAAAAAAAAAAAAAAAAGMR0QAAAP//7NxBDcAgFETB74s0wQw6EFIzJARfXHqoAQ7AjIMVsO/aqMZHWAM4TXuf5DQMsCnht6Vq6SMfvA8AAAAAAAAAAAAAAACAv4iYAAAA///s3bENADAMAjA+j/p59+5diP0BygxZParhGzjQRhkboMJxxm+mNBcAAAAAAAAAAAAAAAAAryQXAAD//+zcQQ0AIQxFwfoiJJjBx/pADsEXRzDApTvjoOn5v19HNeIM0IU1gAwENQASGLV8/vhM63O1pLcBAAAAAAAAAAAAAAAAcIuIDQAA///s3TERACAMBMH4YtDGoAOzNCkwQEHYdfAG7r+PaiRv4MDr5upNIAigDqGke0bVYQAAAAAAAAAAAAAAAAAcImIDAAD//+zdQQ0AIQwEwPoil2AGH/g4MyQEXzzAAg/IjIU+up9ulWqsb+DN4SJwsfZ/qRogwDt2PlWWdEYufdibAAAAAAAAAAAAAAAAAK+LiAkAAP//7NwxDQAgEAPA+iJoI+jALAtIYOBz56Dp3DrVOAwXgV+t3pwCAdQ09frMKJoLAAAAAAAAAAAAAAAAgCvJBgAA///s3DERACAQA8GYxQfeGHzRUGCAgmfXQQTkRDUO+5gurAG8RFADoCjRt7vamL3yPgAAAAAAAAAAAAAAAIDvJVkAAAD//+zcMREAIAwDwEoDMehAHIcvlk7sDPT+JWTKkjjVuDjWAD7Sc3ANQFHZTXljjrWbbAEAAAAAAAAAAAAAAACKiogDAAD//+zcsQ0AIBACQDY3buZotha2nxj/bgLoqHCqcTdfDAVwWA41ANqwTeuMX4sBAAAAAAAAAAAAAAAAtJdkAwAA///s3cEJgDAMBdDsJYUs4x7u0XFK9xLBo9dCMe9tEAL/lh+lGh/eQ3VfwYFdPYUaMgqgiN6Oy66XyXPM/OlsAAAAAAAAAAAAAAAAALVFxA0AAP//7NyxDQBACAOxbM7qPwElEnrsDdKkPFGNhrAGsJSgBsBNvn9O/ToMAAAAAAAAAAAAAAAA4LQkDwAA///s3LEJQCEMQMGM5jLuoZt9EPeysbYT5OdugoQ0qZ6oxsEOa/RnBwTSEdQAyGn/pZ/zX1HqmO2HewEAAAAAAAAAAAAAAADkFhELAAD//+zcQQ0AIBADwfoiaAMfmEUCLxLCzTiogK6oxsHqbTowAo8Q1ACoTeztnvHrMAAAAAAAAAAAAAAAAICykmwAAAD//+zcMQ1AIRQDwOeLMCAGVYj5A8EXCwJYCMnnzkGXdqtTjQ0tp+JYA7istJz0EMDD1g7YgkNqH98vgwEAAAAAAAAAAAAAAAC8KiImAAAA///s3LEJACAUQ8GM9pdxUnEvQRzARgS5GyFVqieqcUhYA3hIUAOAZX9S7qjWR9kWAAAAAAAAAAAAAAAA4BNJJgAAAP//7NyxDQAgDANBbx6xOT0dBYoU7jawB3hRjQvCGkADQQ0ATssjz9TQXQAAAAAAAAAAAAAAAAD/SbIBAAD//+zcMQ0AIRREwe+LkGAGH/hADsEXAqgooLibcbAr4IlqHBLWAB4S1ABg03NqXrmm1DHLR7cBAAAAAAAAAAAAAAAA/EtELAAAAP//7NxBEQAgDAPBWK8yrOGABzP0UXYdJAJOVOOCsAbQQFADgJPyzjNr6C4AAAAAAAAAAAAAAACAvyTZAAAA///s3DENACAQBMH3RZCDj/eBHIIvHFCQ0MCMg+uuWlGNQ8IawEWCGgBs9VrSF72njZmvbgMAAAAAAAAAAAAAAAD4RkQsAAAA///s3EENADAMA7Ewr8Z8FCZN/bQ2gwTAiWp8ENYAGghqAPDqeKpNDd0FAAAAAAAAAAAAAAAAsEeSCwAA///s3LERABAABMFvVp0Coy+JAswgYbeDjz47UY1NwhrAQYIaACybn+E3Limt1yeHAQAAAAAAAAAAAAAAAPwiyQAAAP//7NxBDQAgDATBSqsZhKCN4AsPTfk0Mw7uBKyoRgNhDaCBoAYAFdtr3+Q6N4duAwAAAAAAAAAAAAAAAJgvIh4AAAD//+zcoREAMAwDMW+e1Us6QdOQnLSBkdmLanwirAE0CGoA8OT+h7DGnNo6DAAAAAAAAAAAAAAAAGC9JAcAAP//7NxBDYAwEETR9dWQbMXgAx/IIfjiUgdtOWzeczAj4ItqLDTCGr3MIOAPghoATLmPdnlwmzyfN4tuAwAAAAAAAAAAAAAAAKgtIj4AAAD//+zcMREAIAwEwaCLQRw6EAPSaOhpQsPsOkj6P1GNZGccL6wB3KzRahHUACBJ98hn5qd3AQAAAAAAAAAAAAAAAPwtIjYAAAD//+zcMQ0AIAwAwfoiyMEHPpBD8EWqgAUWcuegHdrtRTUeENYADjKo4UYAcM2oped/sdE32lz9x7kAAAAAAAAAAAAAAAAAvhYRGwAA///s3LENgDAMRUEzF0JimcyBPAfjRNkL0aZ3Y91tYPf/iWoU+cMa73Uexo3AJgU1ACiSHlvmGXPdTW8DAAAAAAAAAAAAAAAA6CkiPgAAAP//7N0xDQAwCABBfDUdqqxCarYhwQILuXPAxsIjqtGsjueFNYB03l4+3QPQIqNu9s5Wd/BsAAAAAAAAAAAAAAAAAPNExAcAAP//7NwxDQAgDEXBSgMxCMEZCcEXCysjDM2dg9+9T1TjgxPWqOmHAjfjBDU8OgPwWnfhZ0qbqyTdBgAAAAAAAAAAAAAAAJBPRGwAAAD//+zdMQ0AMAgAQaxVWa1VWtMECzDQOwdMTDyiGk3ymH75Hg7fOS+sI6gBQIfcN8IadfbUwQAAAAAAAAAAAAAAAADGiYgLAAD//+zcUQnAMBAD0PNVCjUzH6uOyRn1NQ5qYQdj70kI5DNxqlEoR445rnesAb8xd+cBoMzV2ynt14zjXvIFAAAAAAAAAAAAAAAA+IKIeAAAAP//7NzBCQAgDATBtGZlYuci2EIIHDMdJP89oxoDfmQvtIdcbzhniZoBGHQ8v80OvQsAAAAAAAAAAAAAAAAgS1VdAAAA///s3FEJwDAMRdH4KpNTVTUTGPM1CrFQWrZzJATC+7uiGpuMq2WFNfKXB4DvyhnOqR8HgC0q7GSLFun3I5wFAAAAAAAAAAAAAAAAcLqIeAEAAP//7N1RCQAgDAXARdMw5jCc2EsEK4gy7hrsY/B+3uaoxkO7dL/L9z6JQxr17DQA/EDGvKe3MUvW4QAAAAAAAAAAAAAAAABSiIgFAAD//+zdwQkAMAgDQDtaJ+vqRXCFgpW7DcRHfolSjQZqSXxbE4dvZUHOyqIcLwSgi8ol2fTOmXoYAAAAAAAAAAAAAAAAwAgRcQEAAP//7N3BCYBADATA9CUHSTFWdeUc9iWCLQg5melgH4F8slGq0cRz9DjHUT6Kw3bqnV0A6Mhu+Z0815V/DQcAAAAAAAAAAAAAAACwvYi4AQAA///s3cEJACEMAMFYl1ib14fNSsAWhHjMdBB85JVVVKOYNfqXR/p+FYfyMoTTMojjqQCo6uwpYY175l8HAwAAAAAAAAAAAAAAAHheRGwAAAD//+zc0QnAIAwFwOxVBB2me7iH44h7ieAQabmbIAQC+XlPqUZCJ/w4ytNuuQaQywknt3ujAPCF37InGOOv6juX/QIAAAAAAAAAAAAAAABkFBEbAAD//+zdwQkAMAgEQVN5SOchYAuChpkO/PnaE9VoLOMay7o4tHFeTCNX/wFgEv9knf3rYQAAAAAAAAAAAAAAAACjRcQFAAD//+zdsQnAMAwEwF8tw3hOF8F7GYxWCEHmbgNVUqN/oRoNVLv4k8QjP/zjBNxo+gegq9phbsmPjHfNKwcDAAAAAAAAAAAAAAAA6CzJBgAA///s3NEJwCAMBNDsJQUdpoN0jo5T3EsEV6gQeW+DEO7zzqhGEu9VZqm/GdeArWbW2soeAGT3+OBv6v31euhtAAAAAAAAAAAAAAAAADlFxAAAAP//7NzBCQAwCAPAbN7VS6GULuBDudtAQfIySjWa+co1PEVCnVemcW7OngGY4GaaXKuzpg4GAAAAAAAAAAAAAAAA0FKSDQAA///s3EENwCAQRNGtLrIJZvABOpDT1FdNwAHynoO5zemLahxqZukzyyOuAcsNMQ0ALuY77lPb+9VbxwEAAAAAAAAAAAAAAAAcJyJ+AAAA///s3MEJADAIBMFL/0WltSCkhOShzHSgIPhaUY3mxDXgmYpprLopKwVgqhuN8jf+s6cOBgAAAAAAAAAAAAAAANBOkgMAAP//7NzBCcAgEATAs1jrCKlNrMsg2EAEMZiZEvZgudcmVztLLrUPAlx/zwFeuA1psEsutQl/zhiUAibpn6X8FgAAAAAAAAAAAAAAAABfEBEPAAAA///s3bEJACAMRcGv+w/laCKktRRE71ZIk+Yl3SDesgK+Co19IIe9UcFrE70C8Cm74jkO3AEAAAAAAAAAAAAAAADcIMkEAAD//+zdwQmAMAwF0OwlQh2mUzmMhdK59NKDZ0XQ+t4GSS655MeX98Hl2lI/7Et/7wWcwjSKZvAGubbdIK7pAVLADbm2zY74mLLO0zJobQAAAAAAAAAAAAAAAADfEBEHAAAA///s3NEJACAIQEFpshqtzUOQNoig7kYw/ew1T/W2jAfUh75RQQH4Ue7+yFsQ1ACAbRrFMb3idgAAAAAAAAAAAAAAAADcEhELAAD//+zdwQ2AIBAEwOuLUA51iHVQjA9CXRofNmA0mjBTwu7nXnu+vE+o9FEjYpk9B6awtpyqqvmr0seunHtaTm4YeEDpYzsHIGT5imvcDgAAAAAAAAAAAAAAAIAvRMQBAAD//+zcsQkAIBADwMfJdDQ3czR5sLcSQe9GCGmTIvj/5MnAGiPnyG/8ngfPyU637LhDDQDY6iI6pq4zOwAAAAAAAAAAAAAAAABuiIgJAAD//+zd0QnAIAwFwGzmNM4hnU2cS6FkArEU4W6EBEJ+8uLLO688+Cs+lXOxR4gGt6l9TE3bk+FQwAG5Bza1/IZ5BQAAAAAAAAAAAAAAAPCTiFgAAAD//+zdwQmAMBAEwOtLAjZjVTYTCPYVAvn4lQQ5mGlh4X67p+DFy9Wecw5rKFaSwfiuX+9yVGmRkVGN75TUYS33aCvDXwAAAAAAAAAAAAAAAAB/iIgOAAD//+zcQQ0AIBADwbOGGHzgjeALBfchQAiZUdFP1yGVlMAGjxLS4BtO7OtENWCv2kez+Y4qtgsAAAAAAAAAAAAAAADAZRExAQAA///s3LEJACAMRcGs5jDOaSHuJYIDiIiC3I2Q6jd5HlJZIrDBY0IafElUY5+oBpyXaytz73He2DHJXQEAAAAAAAAAAAAAAAAuiogOAAD//+zcsQkAIAxFwWwmTi5uJoKFraIWcjdCqjT/GaSybApsJMNLLunxjCqkwe9ENfaJasB548crTntN9tcAAAAAAAAAAAAAAAAAPBQRDQAA///s3MEJwCAQBMBrLcVYR0xlPsS+QjAVKEIwMwUc3P53FVKZlmrL741Tmky4ohflsxD5C6Ma44xqwBqptmI0bZlnLOzY9DcAAAAAAAAAAAAAAACA74mIGwAA///s3bEJwDAMBEBt5mk8SCYzwXivIFAfCHGa3I2gSs3/C6TyuirZaAKZ3Mil9rMCplbb+SWlGs8p1YA9+lz5vw3n3eZQIAYAAAAAAAAAAAAAAADwkYi4AAAA///s3KENADAIRUE27+o11FQ2+ZjejYAgGJ6HVKL6MfPENZZpf01EAy6iGu9ENSCnA2nuthD7CwAAAAAAAAAAAAAAAGBIVW0AAAD//+zdsQ0AIAgAQTZzNjc3RgsbGxMozN0QhOZB0EW5HWpO7Ti4wX96rHDUN3a4cFTjnSgdcplPqbr9CAAAAAAAAAAAAAAAAKBARAwAAAD//+zcQREAIBACQHo5hjOHZS6aHzuo424D+INBKldwtPG8sQPU7K1+LwMAAAAAAAAAAAAAAAAAAIDDkiwAAAD//+zdsQ0AQAwCMTb/1aMUL2UECnsF+kNUg1ontLGepSr8eEY8rAMAAAAAAAAAAAAAAAAAAFAryQAAAP//7NxBCcAwAATBlRYz9dkQ6iuvQgX0E5gRcJyCFdXgONd6RjU+vwU3/nVX810UzwAAAAAAAAAAAAAAAAAAAOA41QYAAP//7NxRCQAgEETB6yViGoOYwzKC2Mv/i6AzDXYDPFENntP3yRGIliIcvxtp/5q1rN9PAQAAAAAAAAAAAAAAAAAA4CERcQEAAP//7NwxDQAwDASx588qzKoO3VIAUez1OJypBms1841n0oTjzjDq18wyAAAAAAAAAAAAAAAAAAAAWCnJAQAA///s3DEBAAAMAiD7p16DHfpCEKQaMHpyjpYMAwAAAAAAAAAAAAAAAAAAABZJDgAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDZPHNhQAAIABJREFUAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Uo19OCABAABgGLT+qd/jKCgAAAAAAAAAAAAAAAAAAAAAX6oBAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///swwEJAAAAw6D1T/0eR0EBAAAAAAAAAAAAAAAAAAAA+FINAAD//+zDAQkAAADDoPVP/R5HQQEAAAAAAAAAAAAAAAAAAAD4Ug0AAP//7MMBCQAAAMOg9U/9HkdBAQAAAAAAAAAAAAAAAAAAAPhSDQAA///s0gENwCAUQ8Hi7FuAGcLQhkVckIXcKXhJ20wKAAAAAAAAAAAAAAAAAAD8SX9GJanTSev9piMAXCLJBgAA///s3EEBABAABMFrJgMK00wEfPjMFNgGa6oBAAAAAAAAAAAAAAAAAABcqb2dzCfKjzHGJyPJ3KVNOwAeSrIAAAD//+zcMQ0AAAgDsPlXjQI4uEhohVSqAQAAAAAAAAAAAAAAAAAATw05xqcQ44o25pBxACwkKQAAAP//7NwxEQAwCASwl1YLBf9eunREAZcIiVQDAAAAAAAAAAAAAAAAAAAWuV1nCDEkGfuMCYeAA+BL8gAAAP//7NyxDQAwCASx35zVMwCCPsJe4foz1QAAAAAAAAAAAAAAAAAAgE8Mw4zSj0WbbxhvACckeQAAAP//7NxBDQAgEASxtQinCOd8CX+SC2kFjIQx1QAAAAAAAAAAAAAAAAAAgEZGzXt4YJrBa+vsm24AX0iyAQAA///s3LENwCAAA8HfjIwOm1GlyQARSHcTWHL/ohoAAAAAAAAAAAAAAAAAAPCzTzhjVI8PONSs1jtNcAO4RrUBAAD//+zcsQkAAAgEsd/c1e3tBZFkhBvgTDUAAAAAAAAAAAAAAAAAAGDJmGeUzjxjuAHclaQBAAD//+zcoQEAAAjDsL3O5ygUEoFJZI+oqQYAAAAAAAAAAAAAAAAAAByZZ8BSE8w2gBdJGgAA///s3DEBwCAAA8FIwwKgs2ABaV3KXga2uzlTBLyoBgAAAAAAAAAAAAAAAAAA/FR7K0nKtxbPgHM7trHmM5b/gGuSvAAAAP//7NxBDQAgEAPBSscQoAFn5P73JLxmDDSpgBXVAAAAAAAAAAAAAAAAAACAhoAGfFNxjVNje67hduCJJBcAAP//7NxBDQAACACh65/aEH7chCBINQAAAAAAAAAAAAAAAAAAeE+gAeeINoCdagAAAP//7NyxEcIwDABAb8YxgpIMBPsEPAJsFppUaYDzBZzTf+3KLiRLtv46VCPG4SKpoNFVEAQA9hDjsNhYfkxuC3AQm4bZO6cv1gJAt+rtnnpQe0yhTkA25zrXp1MHgP3EFA91I7Koc819p9R7pkPZaz0A0MI/GHojtwNot8b34r0fHIpBG8DnSikvAAAA///s3MEJgDAQBMA8bPDUfkIKUluwND9G9CP4EAzOlHAhEMjedsZF43IM/bpMs1AfAAAA8NhNQYYADABwVrwP+Jm8B1AAgBfEGE9KW6F1xQkCAAAA8CWnEg05AGjX8dcSQ1/vci3asHMMXKWUNgAAAP//7N3dCYAgFAZQR2uFoIEayLoj1GhhINhrEIGes4GK4O93hWrQg1K5Q7ImAAAA8NBcfFVS5AGAVyLHOi+ztQQjmcpn38jhkQkAfOPQrwziLPspgw0AAADAX5rCW+78oX91vpdi/rWxd/BzbLuzahhZSukCAAD//+zdwQ2AIBAEQFqzBMCGKAgtwdiZkYTE+MeHzLSwz9vsGdXgF2JOx163RZoAAAAwj8exq7MaDwCMVBRsmIxhewAYIK5RaZOZFGkDAAAA8CUjGsBL6xbHnHrH+H4ucrZR6Lp5NAKzCCFcAAAA///s3bENgCAQBdAbzRUA93EhE1ZgNENBY2OjMYH3VqDg4I6PUA1msfWC1yYGAAAA87mFZ2h0AQC/qGdtaU9NLcJK+qNfP4sDwOsEw7KK1s9RVhsAAACAr6WSR0/T/SvwZMwkH6nkELIBi4iICwAA///s3bENACAIAEFWZ3NDZ68mKncjaEOieUQ1+IltWQAAAPC46XFLPAMAuFGaUWimPp2JagDAJhWscpY0ki4bAAAAgBOmRV0iGsAqkQ3oICIGAAAA///s3VENgDAMBcBZQ0JhhuYHmASskSU4ABLY7iz0q8nrq1INuhLLfNRtn0wVAAAAvk+BBgDwN+3LcuQogjmMpB3/1rU6AAaAmyKHgDcjKW1/MnEAAAAAnnLlDWUNgbcp2YAepZROAAAA///s3LENwCAMAEGPlhUssU9WYzTkjp6CBO6WABn8ohqc5qnSnMMJAAAAvmUqw3vUAgB+reIC2dIyJDd5s2W3FAkAy9whuYYoGwAAAACrpj+HZqvATiIbcIKIGAAAAP//7NzBEUAwFEXRrzNKCPoxCkIJWjNm2FhmI5Oc08LfJW+uqAY1OiOic1kAAAD4j4gGAFC51XCHxizPMAQAyJDm1HsjoyGDYwMAAACQI03jG2v1Hw+U6hvZuDdEcWy72DSULCIuAAAA///s3dERQDAQBcCUpoWIMklKQGdGhgL4MMhuFTf3kndKNfilmPq5TFlACwAAAA9RogEAtGS/uhyHaO6hJd3+GbiMRbEGANzjATitWMyMAAAAAFxxFGnI34GvqhlQTP15rGStu/Ip25XDm4QQNgAAAP//7Ny7DYBACABQRnMFdSC9gdQVzRXUxsKYHO+tQAHh56kGo5r6MY/EAwAAAN8xzAIAimvqIIrJBRAA4IX+mErdSCFNsAEAAAB4YvcQGFTOhLZ5XSJ75tdx7gIOP4uIGwAA///s3UEKgCAQBdDpZl3B6r7azcLAZQshCJr3jjBuRMb/hWrwZzUiFicMAAAA7+gBluOx10gBgOx6+3I5SrPkQyJr/xSseRwAplUjI4nmrggAAADAE0EaQEL3vnXZt1FicgrYgI9ExAUAAP//7NzBDUBAFEXRaU0JHw3pB1OC0ogJYiMRCwvOKWH+apKXK6rBp0VTT3kYK1cGAACAZ4Q0AACu5T5X0cbsifiRfegBANwQbRhG8hvr/8i1AQAAADgT0gA4lD32FthYdSVWPYw2GPCGlNICAAD//+zcsQ3AMAgEQEbzCokHiryPJa8YsQFuUsR3K1DwEuKVavB3uWSaxQIAAAB1ijQAALYMuYmDtHwOXnN5EAaAGjmRUwyTBgAAACAUaQBU5Q3pufodCjbgAxHxAgAA///s3LEJgEAQRcFviYJtqiWonclmJiKo2c6UsHfBsRxPVIMOtiSDkwYAAIB7QhoAAO9UXGCcRm8oOqn7LqoBAA8qRGVGNLGLrgEAAAD05v8hwCfXwEaFNY51Xuzd4U9JTgAAAP//7Ny5DYAwEARAt+YSzqYfoCCgBFpDICQiMmc308Jm96xSDVKI3s5j26u0AQAA4GORBQAwTH1LviGF+0nY4yQA/IspzNzIZJU2AAAAQE7R22IWCjDUc9sdvc0KNmCgUsoFAAD//+zcwQ2AMAgFUDbTFZo4ptoVGM006dWTphfeW4FDgf7gqAZVjEdk79edKg4AAEB18yNrm4tXAAA+6mfPdrTUX1HICG8IbQDAOyFyqsgxD6k2AAAAQB3yhwDLOLABf4mIBwAA///s3cEJgDAQBMCzMy3hIA2lHyEl2JoE/PgWEbyZFvYTjmVjVINK5g9xi8QBAACoaI5NXsdVhX4AgHd0pSEqyZbH2McmdAC4y5ardyGFdGEDAAAA/J/+IcDnDGzAExFxAgAA///s3csNgCAMAFDiZK4ALKSTMZpG04snTibGvjcCTUj6gS4OkExqb0PAAQAAyORqZkU+PDS0AADeE9uZbWgmkzUeDQMAT2pwZLFHHgQAAADAT9XeNvOHAJ9zf3JUezvinja7ATOllBMAAP//7N3BCYAwDAXQHhxMRyi4j7hPNSMqhYIXz4LtexOUHJvkZ1IkBlMXieY4Tg1dAAAAulY/STWxAAC+FSWWvOZL2RnIJkwGAB4tcMrgIkOIEi7gAQAAAHSoLWfP5g8BfmFrARv1rXud4bA/DS9SSjcAAAD//+zdgQmAMAwEwOBkrqBO5GQZTQnGGcT2boQUCm0/6aIuTCgtOgAAAKPqicOXBy0AgM+cSs9E1m4eBgAeMinMwrkHAAAAYDA1TGM79ux7TvlDgP+pvTsrR96fMwKviLgBAAD//+zdWw2AMAwAwH3giyChgB8UbVgAZ2QJaCBZ7ySsP+3Sx+QxyKgn+Gdti+ADAAAwgncz/OEKJgDA//q15thjlpuRSK9FXDkBIL3YQ3MiWVy97hFtAAAAgDG8g9eWaACM5Yht/fo57rM2//rkVkp5AAAA///s3dENgDAIBUDSyVjBuv8sNRq+nEDL3Qh8kNDA62hfAbrKOjgCAACA33olw5tzAQC+w6/NdJKOiAHgYemcLsw7AAAAABu4wzSOcy5vmwBbywrYWNX37ZvTU0RcAAAA///s3NEJwCAMBUALXVDoPtJ92rqCo5WAQyi5G8H4YYy+U+lJLD4cHTYAAAAAu5kXmk2QBgDAmvrTR73qcF4jkehPBGsAkJaAKRIZ0e8oOAAAAMCevD0ESK3NgI1Yg7u/n/kWeZRSfgAAAP//7N3RCcAgDAXA4Gbdt+AIHa0SyEdH0OZuhXxIUN8bxk1n1eYLAAAAx6hd9nGpBQCwPe3NtOIzMQDNaXKkhXnPy6QBAAAAzpNhGt4eAvCR4Rpvng0VuAT/FhELAAD//+zdWxGAMAwEwEjDQgBBOKs1pjP5RUDIroh2+sidUA2mOyz4AAAAdJDX+ezLSw9aAAA9VHuzYA0mMUwMwEh5p0IXpnC+AQAAAGim/h0K0wDgy94bVgVsKFPhvyLiBQAA///s3LENwCAMBECPxgpI7MNCkVgxRShQqpQB3w2BZON/pRrwPPiGAgAAAH5pKdMQUAMA2My4hs9mUhEqBiCb2mpxiE4W5hsAAACAfbzuDu0wAfiiz3INmWvOExE3AAAA///s3cENACAIBDBG08ldzRgZwYdKuwIvCBxCNWBzmAQAAMBV1jAyE+L1rAAAb/PNmUpaHhcDQBVmd1TRVRoAAADgfp54AXDA2vsYGbAhcJs/RMQEAAD//+zd0QnAIAxAwYzmZl2o4Ah1NCnmowsUlNytIAhReYpqwNJs7gAAAOzgE9N4FOIBAM6XvzkPS0khHugBUEKGpJzfUcHodzfTAAAAAGxMTAOAn1wZ13gjG+7FOFdETAAAAP//7NyBCcAgDADBjNbNbCfralIIuIFtk7sRFAJCfFENWIahDgAAwJsy+CimAQBQz+VOaeTIT8YAUJ3ldLrwngEAAAD4KDENADZ59kDujGucDp3fiYgJAAD//+zd0QnAIAwFwKwodB8dzdFKwB8XsFXvlggvgRelGjATIAAAAFguSx5zySiXAgCcaXx19tmZm8g2ABytPKUpxuUSfeQZAAAAAH5EmQYAH8n7WM0ZpFyDrUTECwAA///s3dEJwCAMBcCMZkcQOmbBEVxNBPvRBUrQuxUCgQfhRakGfBWLHAAAgD+tMo3uCB8AYG/taZcRc5BS7yrjALAzh+ocQY4BAAAAyEWZBgCJvOUafT6YNBhSi4gBAAD//+zdwQkAIQwEwLQoXD9ylaW1Q/DnWwiXmRYCwmLYKNWA0/SAAwAAcNvKnvtzSwYFAOjjNWsaScMG4I/GMxxroQv5BQAAAKCIvW+YyjQAKGjtwqdyDUqLiA8AAP//7N2xDYAwDARArwhZM1JGIJuFBiQKWpQI321h2f9WqgHvDBgAAAB85lpuCZgBACTTahPAJBWhYwB+yk0JGXTzCwAAAMB8jzKNwwMvABZ3l2uMrex2DKwlIk4AAAD//+zcsQ3AIAwEQI9GRkBinyib01JQIhHw3QovuXn5jWrAXHG0AQAAWG0ouJRbAAB5PbInEU/HAFyltmoolyw+SQMAAADsY0wDgMO9xjX4lYjoAAAA///s3csJwCAMANCM1hUCjllwBUcrgvTWW0Ew743gIZCvjmrAtxm0JR0AAAD8YhUFNbgAAIrrdx/z1+fq70Ad2dKABABHyJaX2h5FjJW3AAAAALCBWUMADvIe17CvzVYR8QAAAP//7N2xDQAgCARANnc0R9OYYGtjYdS7JQgEHqEasOZ7FgAAANsyMV6PCQDA5OszPyl5hAwAtzPf4xf6FQAAAIAD8uC4mUUC8KBR2+rYqReuwRER0QEAAP//7N3BCcAgEATAK83W7FwCi0/BT0K4mS5cj12lGnA20u4HAAAA157QL59cwj8AALasPlt+phOHfwD8WgqiZHx0MPNeAQAAAOAluTM03AVAB0O5Bp+oqgUAAP//7N2xCcAwDABBjZZMloUMGsGrpVFpMGkMQXcjqFBlv0Q1YO+xnAEAAPiqIo3T4AAAWMmRt8HQyFWfkQHgrzxmp4Uc6fgQAAAAwEEV05iivgA0I67BWRHxAgAA///s3cENwDAIBDBWJOlAzeSJugGvSBX2CPxAp0OpBtQIRwAAAFCmNR4AgKJlUDRiRwLgl/LJV6CdJhT/AQAAAFzyPe3KObbbIwDNKdfgjog4AAAA///s3cEJwCAMBdCM5gpCxyy4gqNJITeh7cWD+N4IuSWQ/4VqwD8lG4YBAADgVQZqOOoBAPApW6C7SXGIUq9qVwJgR4KhOEFvd7ObAAAAACz2PAwr7QKAiXAN1oqIAQAA///s3cEJACAIBVBXDNonmqzVungN6tAhem8EBUGEr1AN2NcMYwAAAFby2CU5HgCAU13F+MjQbABeUmrxgIVf2EsAAAAALsswDU+7AGBNuAZ3RMQEAAD//+zdsQ0AIAgEQPafytFsvrMi0cJwtwUE/oVqQI8UQAAAAA5Z2nkOAwCgLW3QGqEZw3MyAJ9xJ8IEK3MJAAAAAA8o7AKANuEa3FVVGwAA///s3bEJACAMAMGs5r6CI7iaCGKvpBHvVkglJK+oBpyZjxiLfgAAAGyCGgAAJPArND9xnAzAE4Sg+EWrrRg2AAAAQL4V0+j2CwHgmrgGOSJiAAAA///s3cEJACEMBMCUZguC/VjatXYP04AEQXCmiEBYslGqAfum4QsAAECs0EvgBQBAWX6FVqzBMxwpA3C7PnpTBMUj7CEAAAAAB+RT5y+PgQGAGuUa1ETEDwAA///s3MEJADAIA0A370KFrlgKTiA+Ct5toSQxqgE1ghMAAADD5aCGpxwAAC3OPkYGmGRlWRkAfiUXwgjuEAAAAIBer+ib2UI/RgDoZ1yDmoi4AAAA///s3bEJACAMAMGMpvsvZROsRQwIuRtBuxBfUQ24M7IYCAAAQEOCGgAAFPFLNJ1YJATgSxl+Mvujg+mWAQAAAN7Jt2Z2CwGg3o5rOGuORMQCAAD//+zdwQnAIAxA0YzmZl2o4ApuVhFy7UXaUsh7I3gRxXxFNWDfoWQEAABQj6AGAABvyV+ihwWmiJZDywDwN8JPVDD62Z09AAAAAB6w5svyXaG7RQD41tqDrwxbwb2ImAAAAP//7Ny7DQAgCAVANjdubkNtI1ET7kag4/eEasAZzQ4AAEAjAjUAALhgKjKN2LUB8JUMfDL/owN9BwAAAECBfOJ1VwgAbw3hGmxFxAIAAP//7N3BCQAgCAVQR2u1Jmu1LnboLETgeysIgqBfoRpQMzRZAACAHgRqAADwQn6L9jGaLkYeLwPAL5ZK0MDMuQMAAACAgtwpFCIPAP844Rp2UbhFxAYAAP//7N3RCcAwCAVAV8sIge6ThQKO0NWKP10gUEJzN4KIXz51VAPWDQMWAADg3xzUAADgSzmzKTgHEV4GYAv96p6qcIScqdcBAAAAFlSOrAK7dgoBYFt37f/LfvOKiAcAAP//7NzRCQAgCEBBR2u1Nu8nWiAhybsR/BP0iWpADlVBAACATwlqAADwyDR4uvDEDEARbj/owJ4BAAAAcGHfE4rGA0B9Q1yDIyIWAAAA///s3YEJACAIBEBHa/RGi6AWiEDKuy0e9VWqAXe0FYoAAAD4iEINAACy+B5NMY6YAUil4IkiupwBAAAAcGYe49onBIAn7XINM5LKImIAAAD//+zcyQ2AMAwEQJcWSjDQT0TlyYcGkJA4PNPCPu1doxpwn2atCAAA4D8cwAAAeIFFCFShzAzAU3LPZuCJIg5BAwAAAFx3lnD9EwLAt/Xc1mFco6iImAAAAP//7N3RCcAgDAXArNh2TcERdLQiuECh0GruRogfIWKeQjXgXU09AQAA1idQAwCAP6il9vGbtMMgCcvMAHxFDyKDPucLAAAAAB6YbwndIQLAPka4Rjuu065AJhFxAwAA///s3dEJgDAMBcCs5giBjil0BFeTQAfwQ0TN3Qr9KH1pEkM14GbrsQQAAMBHrYBMSAYAwFvYJk0bOVKdDYBH5UhZIC3MfW5OGgAAAOC6+kdY2+zlhwDwS3W/H/rBG4mIEwAA///s3dEJwCAMBcCM5gq2C3V0oWQBQUo1dyv4lWDeE6oB6zUJRQAAAHvKec5yDACA38g2aY3SVNHyuBkAvqJhkgoE9QEAAABM8I8QAMp4Q7T6fT2e/HARMQAAAP//7N3bCQAgCAVQN2+hoBUjcIB+ih7nTKGoV6EasIbGCQAA4DIGYQAAnMpXaT7juBmALTLISZgTz2u1WQQFAAAAmJQf6+0RAsBfyqgB8p6AF0VEBwAA///s3cENACAIBDBGc/+pjIYB/JCotFsc5MBRDSiSIQoAAIB3yHEAANzH14WgAAAgAElEQVTMd2m6GFlyBoBq5oF04EAfAAAAwIFVos0umD0VAPS0H3Tqhn8qIiZ7d3ADIAhDAbSjuQLqPjKQCSuwmV5690Si8t4I9FSa/grVgHEWqUQAAADf4PMLAIC3y+vSXaGYxKHQAIxU9lI9MBPo7Wx6CAAAAIAHuf8lUAMAiNwNv8q2mif+SUTcAAAA///s3LEJACAMRcGM5mbi5iKksrESlNytkCrF+0Y14C5RFgAAwOOsywMA8JHhWBTRxM4AXGbAiQr8DwAAAAAHGczqvwCAXV+dQY5v8buImAAAAP//7N3BDQAgCAQw9l9KRzMmfH2SqLRbADnOUw0opu0YAADgXnkQs+gCAOAJ2TKtaZouhJ0BKOFxE03MnB8AAAAAOMjMl5sUAHCycwZDTvwDEbEAAAD//+zdwQnAIBAAwStNSxAsM2CJCYLfQB4RFGda8OXJnpZqwHzJJiIAAID1jLuaBzEAAHbjt2mOIXoG4G+lFjNBjtCulp00AAAAwLsRx+q9AIAveid+a8U3FhEPAAAA///s3bEJACAMRcHsv5SrSSCtjYgYvFtCUvynqAbcoUIEAADwHrcaAADt1G/Twhr8wugZgNO8LfzAvQAAAACwkGPYHMUKagAAG0aFuegmIiYAAAD//+zd0QmAMAwFwIzmCtEO5EBCV+hogvjpn1IsvVshEHgkJI5qQCcaJQAAwH/IaAAAjKwedVdAZpEl5TcAPpElF4vyTKDJCwAAAADP7u/yZk8AwBvXga7cVvOYkUTECQAA///s3bEJACAMBMCM5mauLkJKO0UJ3o2Q7gOfOKoB97QMXwAAADyUCyz5DACA6nyf5hctS9AAsKubIB+QEwAAAAAWHNQAAA7r89Gn3ngRETEAAAD//+zdsQ3AIAwEQO8/CxIrMBoicpU2gpBwtwLVI/utVAPWEr4AAABelJ9WhucBAPi8vD7dvCSHkOMAeCQLmgy08XetliojAAAAANyMhVc7XQDABFdpVx79ZGcR0QEAAP//7N3JCQAgDATAlGZnti5CXj4FD3Smihxs4qgGbJaNGAAAAGcIYgEA8BJfqPlFyTA0AMwyF+QH+gMAAACAQea47JkAgJVqrznyASg3iogGAAD//+zdyQkAIQwAwJRmC4IFuZ0vQirwEURnSvAR1FyGakC9JjACAADUkxwDAOA2uYXaJmpeoRkagC199OlfkAd8+T4AAAAAIKkZBAAKrTvHGqwxHfqBIuIHAAD//+zcsQnAMAwEQI3mTJaFDBohq5mACrdp4uDcjSA1D0KvVAPWuMwdAADgPVVu6DgGAMB2sudhq/xEq6doAHhKMRPby55yEgAAAMBEoQYAsMh555D6X+ArImIAAAD//+zc0Q3AIAhAQVa0ncjJ25C4QH/ElLsV/JEQnqgGFFnDGQAAAHuYwQAA+LPpdWnCUTQAnwgy0YTQHgAAAMCSB6zjvh5BDQCgUP5DMqxhV3mKiHgBAAD//+zdMQ0AIAxFwUrDGYZIsIA0BhQwEBq4s9C574tqwD1FaQgAAOA8UUMAAF5nlZqfeI4GYJMgE68bvfXhygAAAAArqGGACwBIpPplSCIiJgAAAP//7N3RCcAgDAXAjOYKURfq5O2PA/gjFnK3QkACSZ5CNeAujyEAAMBBa0gm0BAAgAr8Tk0VjqMB2JIz7WRQwaPKAAAAAAI1AIDfajn6u3oVbomIDwAA///s3bENACAMA7C+WImD+AxOY2FmQwjVfqFThyRKNeAxLUMAAABXCVsBAFDCXqe2UE0J2bK7NAAn2VLZLhXM/QcAAAAAlKZQAwD4wJAnfygiFgAAAP//7N3BDYAgEEXBLQ1LUAuSgkgoUWLi1ZsJ0Z1pYa/8h6gGzFcUhgAAAN637lv1cB4AgGT8Uk0Wxz2WBoAnYrv8Xm99cWUAAAAgO0ENAOBDrj35aVM+QUQMAAAA///s3bENACAMA7D+/xSvsWRkRAio/UWrKFGqAXdwvAEAAGyUR5PgPAAArWSl2lI1Xbj5AFhK8ZIgGr9TqAcAAAC0p1ADAHjUyIAop1TVBAAA///s3dENwCAIBUBGc4XWgVyoiSs2Tfzqtya23E0BhAeOasAmjnpq4gAAAOYRrgIAICXfqkmkjNA0ALyZDfJ7/eoWLQEAAIDUHNQAAD6uPbnyUdOwWkTcAAAA///s3dEJACAIBUBHa4WggRo9iH76DiLybghRwadQDXhHUfwAAADOrdnKfAUAQGa+VpOFo2kANrXVbjdIAoL0AAAAgNQEagAAn5g9jdvyCyJiAAAA///s3cEJwCAMBdCM1hUExyy4gqOJ4KH3Ioh5b4QcQiDkR6gGnEXzAwAA+M+yDACA1NbX6p69DqTwlFrs1gD4ErjE7Xp7m1kfAAAASEugBgBwoXlbbr7ZKSIGAAAA///s3MENgDAMA8CM1hVSGIhuXlF1AsQDkbsR/Ioiy0Y14HsUPAAAAB7Ko1+yAwCAZYiBIpQKAFjyTL9BKnDnAwAAAGUZ1AAAfqzdwxr73uFtETEBAAD//+zdgQkAIAwDsJ7ma34uyC4QBHHJFWXQzqgGvGcogQEAABwzVAgAAEnqe7UP1rSgRA1AcRvkd7NyPgAAAEA7BjUAgAZ23tExvyDJAgAA///s3bEJACAMBMCsKLiPCwmuKNZWgoWYuylCyH+UasCbmjYhAACAM5ZHAACw8cWaLISoAZIrtTim53ujDztwAAAAICWFGgBAMitjbva5KSImAAAA///s3bENwDAIBEBG8wrE3n+VuKFIaSlNFO6mAAGPUA34Lst/AAAAh2popo8CAICH+mItWIMWcqUjU4CmcuWor03wZ+p6AAAAoCWBGgBAUyPndVctxFsRsQEAAP//7N2xDQAhDATBK43OvjQojeRDAgIChGeqsCx5LaoB92q+LAMAAGwT1AAAgAXfrCnk+4+qAajHbpDXDXM9AAAAUJGgBgBAurDGAUkmAAAA///s3UEKACAIBEB/3tcjkG556RI58whRwVWoBrxtKHYAAAC1nJvMTgAAcOarNV04qgZoJgOV7Ab5nX4eAAAAaEegBgDAtoI19EU3ImICAAD//+zdwQnAMAgFUEfLwAVXyGih4C0Q6K3E90bwZIJ+hWrA/xn+AwAAOPNuAgCAg7pqPdWIBkYtVwPQh79BbjfzSb08AAAA0IpADQCAzXiDNapP4quIWAAAAP//7N3BCQAhDATAtGZnFnRgi+KRnw/hXoeZaSGQx0pWpRrwf2vRdXMCAADYZSgkGAIAgDO/W1OF42qAIrJISTbI1cYzmgkDAAAABXnvAQDYvcVjijU+iIgJAAD//+zdsQ0AIAgEQEZzMx3dkFgao6V6NwIFDeFfqAbcoVpyAAAAU45nAACwYbRba7jmB2U8WQPwPk2VvE4wHgAAAPCdbGAXpgsAsJTBGs2IDkREBwAA///s3bENACAIBEBWNHEfFzJxRRsKS1r1bgYKEuARqgH3cCgGAABwyPBBwzMAACjy5ZqPOLIGeFzrzZIYz1tzqXMAAADgKwI1AADKRvZOVETEBgAA///s3bEJACAMRcGM5uauJoKNjZDS5G6MQN4X1YB/DOUgAACAi/ggAADkWbumBc/WAOW5DVKdIB4AAADQiqAGAEDa/jufZ6yUl4hYAAAA///s3dEJwCAMBcCM1s26kJAVHK0o/hc/NXcrBCSQ+CJUA87yetwAAADmAO0xQAMAgH2uXVOIz9YAlxKcRAE9W3aFBgAAAKpYR4jtAwIA7Bs9lGCNPxHxAQAA///s3TEVACAIBUCiWcH3LGQyq7kwujkpdxXY4AOOasB7BAABAAAM0AAA4Iav15Rg6RrgP330JjdBAVORAQAAgCpyAVTPDwDgzspDZZxExAYAAP//7N3BDcAgCABARnMF60COZkfrh2dfTT/i3QokhEAARzVgP01iAwAAMEQDAICv8uu1z9ecYObyNQB16AtS3Z31OgAAAEB5eVBjiTQAwC9mH5fa6k1EPAAAAP//7N2xDcAwCABBRosny0KRWNGK5Mq1UwTuVnCFZB5RDfinew2OAAAA7QgNAgDAEa5f04Xla4AiVijJXwlKyyeHFwYAAAA6ENQAAPjE9YY17KBvImICAAD//+zdsQ0AIAgEQEZz/6lMDIW9oUDutoDAv1AN6MsBIAAAMJV5CAAAHmX7tQZsJlj5hA1Af/aC/E7wHQAAADCJfR8AQI0TXiZY4xIRGwAA///s3cEJACAMA8CO5sCCKziaCLqBPrR3W7SERKkGvKtYZwYAALJxBwEAwDlWsElEKBPgcasgSeiLn/VWm/83AAAAkMJcT/fvAwC4TrHGFhEDAAD//+zdwQ0AIAgEMDbTzRyN1fw4gjFB2hUuIfcBHNWA2paBBgAANDMEDgAAV/mGTQfzLGMDUFfKjs/p5QAAAEALDmoAADyVp3/1FhEbAAD//+zd0QnAMAgFQEfrCoEM1IEKWcHR8pMRAiXxbgT9EZSnUA04n89aAABACStU0DINAAA2Wt+wU00pwE4N4FCtt1fvuFyOb5jJAQAAgOu5AQQA+MVTPlgjIiYAAAD//+zdgQkAIAgEQEdr/6kiaIUI/bshRFBfoRrQ3ylmFkgAAIAEhmkAAPCGr9gkWI6yAdoSjMR0+nEAAABgvBuoEX/MCQDwSXawRlVtAAAA///s3YEJACAIBEA3jyYvAleISO+mUNB/oRpQw8jlEgAAoDLH8wAAcEG2YmvGpgN7JcBnBCLRwMx5HAAAAKA6gRoAAG+dYI3V8h89IjYAAAD//+zdQQ3AMAwDwEAbhXSFWakQSm0oJm3JHYo8HFupBtQhBAgAAJSV9xCeBwCAd1nHpgXP2QD/kTMvWQiq22u7TQAAAIDyuq+iAwB8zGlXrBERDwAAAP//7N1BDQAgDAPAOQP8m+KDBRLo7iw02a+dUQ3IMZXMAACAYEO4AABwz/mObViDDpSzAf7hZpNuSRgAAABId7pOLb+hAwA8rNewRlVtAAAA///s3dEJACAIQEFXFNqn1RqtH1cIQu+2UOQpqgG97Il1IAAAoLeac8w6AADwmC/ZTJErfUMD+FyutBOku1NhOwAAAIC26vZPPBcA4E9zwhoRcQEAAP//7NzBDQAgCANARnM1NzcmzmBIuRuBVx8tnmpAHiVAAAAgjfI8AAD8s92aAdYbawPQl6I96eRuAAAAYAIbJwCA3u5jjfzMVlUHAAD//+zd0QnAMAgFQEfraBko4AoZLQQ6Q2n0bgQ/goJ5CtWAgro8YAAAQBsW6AEA4CM5c5yr2epNA2ZNgJ96g4+EH1HZypl6bgAAAKA0f5sAAK7xlO/dImIDAAD//+zdgQnAIAwEwIxWR6gu5ECCKxahO1jTuxUCgUDyEaoBOa0GZsEEAAA4ntkGAAC28DWbP7jeo20AvseyPanNMYsKAwAAAJndrXbBuQAAR8kdrBERDwAAAP//7N3BDQAgCANAViRxIEf34wxG690KvAikFaoBuTyZAAAACTQHAwDAYbs1W3M2P7BzAlymR08zIZwAOwAAACDaLtJygwEAeE9usEZVLQAAAP//7N3BCQAgDATBlGbBgi0KYg/qOVNFHslGVAOCpVeBAACAL6jVAwDAAb5n84nmeBvgOpbtiTb6MHsAAAAA6dwyAQC8a4U1digtR1VNAAAA///s3UERACAMA7BJwwLg3wuHCrguEbHX2irVgGwj8XABAAA9zL08FwMAwFtWtOlAeBvgE4qOaEBxHQAAABDNODAAQISbS88q1qiqAwAA///s3TERACAMA8A6wzB3WEAaCx6A8G8hU4ekRjUgn4MUAAB4VZMcAACc44s2v1DiBriGoSOSzdHHlDAAAACQapcuPQYGAMiRM6xRVQsAAP//7N3JDQAgCARAWiSxITv3Yw/GZaYFfhyLUA0YQNIjAADwKQM2AAB4zzdtJnDEDfBYr7bXQLqtwgAAAECqe2ypxwcAkCcjWKOqDgAAAP//7N1BAYAwDATBSMNCCoZw3k89tBwzKvLJrVEN+IcraQ0IAADI1/dQCQYAgAOsmraiNvE8cwPs008rWJLuXXc1AAAAQCoD5gAAub4/rFFVEwAA///s3cENACAIBDA204FNXNEPMxiFdgWeHIdSDehDEBAAAPjJMC0AAHiGr9p0MPOoG4D7BO4pba+tRBoAAAAoKx9o2bEAANT2d7FGRBwAAAD//+zdQREAIAgAQSqq/bv4IYMjsBsDhkNUAwZZZwtrAAAAVViyAQDAJ/Krts/aTOCoG+CxDBqZBdKZQB0AAADQVh5W2q8AAMxQN6wRERcAAP//7NzBDQAhCABBSvP6NaEFS7uPNRiFmRb4EVhRDehlvF4CAgAA6tvlegAA4CI58zMPGhj7uRuAcxzcU9nKmfbdAAAAQGX2ewAAvbwZ1oiIHwAA///s3dEJACAIBUBXFNq31SJogj6C9G4Ff0TkPaEa0M80cwAAAAAA4IKWbTrw/AnwSI7cYQPCjKjM/gwAAACUdcqz3PcAAPr5L1gjIhYAAAD//+zdUQ3AMAgFQKTVAutkLqmFSttPNSwdvbPADyHwEKoBB8p+CdYAAAB25oAJAAA2tL5sT7WhuJZ3WgAF+IY5IJXN8Qy9MwAAAFDSOqI03wMAONe/gjUi4gUAAP//7N1RDQAgCEBBomkENwMZyM2KpnBTvIsAX/w8RDXgT+XFChAAAJCfWwUAAK7n2zY/EKgHOKz1NsyYzNZc1YIBAACAxAQ1AAB4J6wRERsAAP//7N1REQAgCERBKqqFjO4PFZxB3M1xPEQ14F/GgAAAQEWiGgAAUFh+2/Zxm/YcewNcZ3RPZ0J0AAAAQFtjzW3nBwBAeiOsEREHAAD//+zcwQkAIQwEwLQYtUzBFu9zDxsQgs50EbK7RjXgYdmbYQ0AAKAaYXoAAKhPSZAXuE8BDsmRsgpcbc1lnAsAAAC40l+Y9EMBAGBXf1gjIj4AAAD//+zdsQ3AIAxFQY8GI1hiTCRWYLQskDIFMXcr/NrPohpwt/aXAhAAAAAAAHCGNdcW1uAGOdJBLMDHcmTzxZLiuoEBAACAwgQ1AAB4c3ZYIyIeAAAA///s3TkBACAMA8BaBARhDWksXdkYeO5sNEmNagA+wAAAAEcorSorAQDAJXzf5hM9y98A7CN0z8tGDtABAAAAPCfzfe4mAACsnDusERETAAD//+zcwQkAIAgFUFdvoGqFRougcxB0iHpvBE+K+oVqAGOwFawBAAAAAADsSirGBzx/Axwyg4oc3fMy/TEAAADwMjsTAABWWs3lzgD6iOgAAAD//+zdsQ3AMAgEQEZz9rXEChktQkqfwo1N7kZwhbD4F6oBlLFz+g8AAPAbPt0AAOAgObPaqDRx0914j8ABWGf/R2d3zjQbAwAAAC0p8wUA4EMFalzbPlJEPAAAAP//7N1BCoAwDATAfDHQZwr5ohTqsZd6sOrMLxI2G6UawMWACwAAPEbRHwAAvJZv3PyBI3CAm7JlL+OyA+Sz6qitQ4IAAAAAq0a2z24PAICZ7Qs1IiJOAAAA///s3bENACAIAEFGcwUS95/FxthZWRjI3RZA8ohqAIdyJAAA8JGjGwAAFLS/cfvITXcjZ5pbAd4IFNGZ0BwAAADQmd0eAAA3JYIaERELAAD//+zdsQ2AMBADwN8MVvjAQBkIKStkNFoaGpoo4W4Ey7VtVAN42r1DAwAAg2yCBwCAOXnl5ieM0wN8lGdW2bGw3q6m4wAAAMCS8ijVYRYAAC+mGdSIiLgBAAD//+zduQ0AMAgDQO8/dfqIKk2EdTcF4jFCNYCbhUAAAOAHgzcAANjNd27qOQoHeOaTJc3UwQAAAEAzvT0AACarAjWS5AAAAP//7N1RCQAgDEDBVVRrClYwmgEEwR9Bvauw3+1NVAOYpJKFNQAAgGNSyYIaAABwOd+5+YTFUYBNgkQ8rrfauiEDAAAAL3JbBADAwl3h+YgYAAAA///s3bENgDAMRUGPFkYwsGZgRRrKFBEFkqO7Ob6fRTWAkZbHbtgCAAD8RVQDAADWUOr7AHzhOBxgXp7ZBIlYXLmxIAAAAMCM91GWXR8AACPb3a9a4fmIeAAAAP//7N0xCgAgDAPA/Fz8uUtHRVfL3StKIYlSDeBkWIsGAAAAAABe1Uq3pW66GxUSB+BOoQadzbp/AQAAADry2wMAYOfLQo0kWQAAAP//7N2hDQAgDATAjs5AJF0Rg0KAI6HcrVD1Ff9KNYAdIRgAALhB9gAAgDqsdfMDORbgYBYQKSGirOzZXBcAAACoaA70+u0BALB6tlAjImIAAAD//+zdsQ0AIAgAQUZzBXVgV7OxMtHYSu5WoIVHVAO4KbU3SwAAAAAAAMCT9a3bx26yK+tYHIAzASIyE5IDAAAAMhumCwDA5uugRkTEBAAA///s3LENwCAMAEGvxmRZCMkrZLQ0lCAaGpy7FdxZ9otqADvPqEwCAAAcJ+QHAAD1ZM9mrPyAZ3GAhREecmdAVW/2tNcGAAAASnLPBwDAxPVBjYiIDwAA///s3bENACAMA7Ccxv9XsTAgsdA1sq/o0CRKNYAfngIBAAAAAIAJ6920Wyc0DsDLkiXN3LkAAABAM/khAABuFYUaSbIBAAD//+zdsQnAMAwEQG0Wr2DImAavkNHSpHIR3Lh57kZQJZD0EqoB7GjSJgEAgEMuhQUAgDzf9+6IgSr8cDQOsOh3t1tAsmeOqccFAAAAIrkbAgBgEROoUVX1AgAA///s3bENwCAMBECvxgiQgbIQEitSUaWhSPW6W8GVLflfqAZw6+3P0LYFAAD8zZ4BAAC5tHgTz/M4wIcmS2KtuZrpAgAAAMHc9gAAOKICNaqqNgAAAP//7N0xDQAxDATBo5g84FBLYwD59jRDwZVlaS2qAfxhQQYAAAAAAJ7MF2+fvGnnfgYwhIYoJxgHAAAA1FrfPqYLAMCoC2okyQUAAP//7NzBCQAhDATAlJYW1DYFW5S7DgRfcaYFIaJkV6kGcCLb6JZgAACAK7wvAADgCcKHlCdEDvDPwlQ0RGVrLvc9AAAAUFIb/fvbS6cLAEDVQo2IiA0AAP//7NzBCQAgDASwruZk4j6CKziaCL4FvzVZoVC4Qk+pBvCqnsAMAAAAAABwNfqYijX4gCdyALuQ3Ir5AgAAAIm57QEAsLWshRoREQsAAP//7N3BDcAgCAVQNnMGEte0HaGO1osTGE/43ghwghC+pxrADgMzAABwQlNFAACoT6o3N8ien0YDt8qekiypbK5HcQAAAADlrNBduz0AAOY7nro3XhHxAwAA///s3dsNABAMAMCOxgiYyOYiMQF/dTdC/TR9cVQDuFHa6AZgAQCAV5pxAADwj+mtSa6cpXKAH/mYg8zksQAAAEBmansAAOyDGjV1FCJiAQAA///s3cEJwDAIQFE3L9lHcMUS8NxDj/reFBL0R1QD+OvpIiUAAAAAAMCnyrqxbj98M53FU2CdDgrZHWCqU1lmWAAAAGCkvgnytgcAsNuKoEZExAsAAP//7NzBDYAwCAVQDg7mCupA2sm6WmPiBJ5aeG8CCklP8LcJagDWdVuABQAA/jiu89E4AAAop1nMI7n9PS53fAsU0w2crL5gOAAAAICshIUDmbSF3uL/BWZRJlAjImIAAAD//+zdyRGAIBAEQDLTFFZNU01BM7MIwKv4KHRHAB8+Ozso1QBK9HkRbp0XIQIAAAAAAOBSLhqIKTbFGlROKT3QjJhCVoCa/SmADQAAAPBKjENvZgd8RJ6t7mdHqXRv8dGdbj4w7LzjQKGmCjVSSukAAAD//+zdwQmAMBAEwCtNS4jajw0JacHOlHxFBRU/yUwJ98hBSHaFagBfzWkcyuHpcSAAAAAAAHArL7lPU9pMiYp15ZO5ZnugEZrUqNVqlwMAAACVc7cH/Ok0KEOx9zNv5nURxCGAAzhqLlAjImIHAAD//+zdsQ2AMAwEQI/GCsBAKJsjSqQUQVAE+26Fr+Ikb6UawBds3AIAAJ5yKQcAAHU1ZwKSO0a3CwH81VUgJDwSa8IFAAAAslr3bfG5GnjpNkNVljGP0Sw65RvecEAdJQs1IiJOAAAA///s3cEJgDAMBdBsZlcodEyhKzia5KYi6MFTfO+WDUJIfoRqAF9o2UhpgAEAAAAAgCf59buPbiGD0vLY3Id7oKo+erNcSWHbXKfHMgAAAEBlZnvAG8fgjDzANjct5OYO9FRfQjcWYUxQxm8DNSIidgAAAP//7N2xEYAgDAXQjOYKwECck7maZ6FFCs/CxvjeCEDBkeQjVAN4y2yjuyADAAAAAABPHAXazUpR2MyNRwCFaLqnstXuAgAAAFW10ReD0UByvYn6cJvT3VlIgRtqRvAdvw7UiIjYAQAA///s3bENgDAMBECvaCkLsQ9SRgA2Q2koKGigQM5dlT4pLOv1UaoBfGkMQUo1AACAR7dlKgAAMKHx+3e23IX2qCxbbn3tUwcSgHqypdA9lS1jTnXDAAAAQGF2ezCvsfs8QnkGL93ez3VWtgG/Nn2hRkTECQAA///s3cEJwDAMA0Bv1qzWfQJZsXiDPkIK6t0UxsiyUg1gp9HDj8EaAAAAtvMhEwBIdAvuEW708bnjXCCMECSx1lzyLgAAAEA6+z34BwUaHPeibOOSEYFPKNRoVfUAAAD//+zcwQ2AIBBFQVpE7YfWLM2s4cDBgwdDdJ2pwUBMPk9UA3haq+sSh6xxIAAAANwzBjP8UwMAvxGhgbrV3WiC5FofrQF8XoSC3NskZkwIAAAApDY8agbyOTeIAhq80dV3KbQB8whqdKWUAwAA///s3cENgDAIBVA2U0do4sA6mYaYXvWiB+l7I9ADCaEfoRrAFywHAgAAdybVYWA9QEN4BgDAFayxtLUdakFhc35CzxAZjwwU4IolVW16NQAAADAA8z2oIWeZux1E/uwhaEO/gvcI1Ogi4gQAAHwF1ssAACAASURBVP//7NzBDYAgDAVQNhNHQB1INjcaD70YExMPwHsXBuBQQtsvVAP4Qz4fMdLtAACABxKFGYkGFgDAu2oogs4JpAeaV7ay+9ejY9XlAgAAAD0Li8pAe8wgMoSwi3qdZV3y3Zua9Kjgk1ndCFJKBwAAAP//7NyxDYAgEAVQRnMF1H10IBJWcDQDMRZWWlgA760ABTn+faUawF+2uMwe6wAAAIyofmIpmwQAeCenvMc1CkHQs6kso5e77pSBhinAoldHTlm2BQAAAOid+R60pRYByyAysmsv9Z7fK9mATxRqPIUQTgAAAP//7N3BCYAwDAXQOJqTSfcROoKrSYveehBB0PjeCMktJD9CNYAnbRExqTAAAAA/0YaPxRASAOCWYumB5Jbzow7A17RgIE0jq7rWWXMBAACAzI4jZODd+iOvHgJs/xCGhGzAZQI1RiJiBwAA///s3cERQDAQBdC0GNGQfsSWQGmGMxfGDPFeCzlt8vNXqQbwqFy6OeokgAAAAOxy6QTwadFi9gUAuGfbDp77vAg60LLtU3qMYS4GvsgWS1o1OFkAAADgB9zvwTvtRRpRJ++HcIGSDTikUONMSmkFAAD//+zcwQmAMAwF0IzmCgUX6mQ6WslB8CCeLGh8b4XS0sDPV6oBzLbkh8RDDAAAQEE563YzLwDAY7pgA8VlaFUoDviUtrbNiVHUruwKAAAAqO60YAy8gyINmOSiZOO4Z8ql+AuFGnciYgAAAP//7NzBDYAgEARArMwaLqEg7MeEFizN+OPnx0g8Z0qA8OH2VqkG8IYrZLM4aQAAABLx8QgA8LC+9yNqbAINZBY1mgVe4CuihsA9mW1uFwAAAPgBczeYT5EGTDC8uTaUTK1mXyQl136nlHICAAD//+zdyw2EMAwFwHSGKMFAP7AFASVAaSjSas9clk8yU4IvVhT7WagGcInou22dl1a1AQCgek3tBeD1du9bAID/yWEDMYThPko2xhD5Mr5hBuAN9GRKpRcDAAAAtbA4DPf5CNKAZ/iGDfz+BaLvJgEbFESgxhkppQMAAP//7NzBCcAgDEBRR3MFofuUbF4KHjz2FDR9bwXBQ4xfVAPI0t+il8sZAAB+z/CRkwlqAADkCJ94Ke5eF3YAdjSu0c3yKCwcLgAAAFDd/DAM5Iq5Z+gtEDa2Bm8ENjicoMZXrbUHAAD//+zdwQmAMBAEwLMzWwhYkPYjpASxM8lDkPz8BBNnSsjnYLnbKNUAWjoiYvLiAAAAdEjoCADQSN7zmpZkYYGRzeVY3Q/5wMcpuGJUmxkMAAAA/ISMD9ooeeP5PNIH+lEVbNyl82YoPbDb/kZEXAAAAP//7N3RCYAgFAVQaTNHsBqohaoRarQQXKCPQh/nTCA8/JHrfdM4RwUiKMt8GSQAAACD8egIAPA/28OJTggH6FZZy6bciqhqgZvhAgAAANG1T8HAt+6WLcwKNSCGmhWu9/ncj7pYPsuu0DHZ9rdSSg8AAAD//+zdyw2AIBAFwC2NFkhsaDs3Jpw8moC4zjQB7OchVANYrXmcAwAA8CGKjgAALxi/h7uHUVnrR9czA3Yl+IeqDL8CAAAAf6HGB/PktXA/wjT0tKGoW8BGmmFhI+n8eSAiTgAAAP//7NzBCcMwDAVQFbpXyQhqMmbAIzSbtQRyyDkUHNvvTWCQjeBb6NnciYEefCLioZIAADCWnN82cdMaoSMAQEVlLVMu+VUDOubPDLidXFKGR6+2shb3GwAAABiFxd7wf/s8oYwRBnR++8c8/EuvpZJNL7ooIn4AAAD//+zdgQmAIBAF0KvNHKGaUx2h1cJogojQem8CURDxTv885KiB4S3bultFAAAAOubSEQCgD9LE+TSP14EOSbDkq5wrAQAAgF8QfgWPaqFcqeYy6ScE4vpgo+Zy7gtqD7ys9bYnk35TRBwAAAD//+zd0QmAIBRAUUerEazGDFzB0UKwv/4keuQ54ASCH0+8imoAX1nyvqlxAQAAEJKhIwBADH4TZwIerwNh5CP7HIO/quUs1e4CAAAAk3D3AOPumEZbZovAox7YaHGNtZ8b8BZBjVEppQsAAP//7N2BCcAgDADBrBhwoe5TcMUS6AKlgqJ3Q4Qg8hHVAGbyIQcAAIAVeXQEAFiL/YytZUvxGGC6bFlHMRzGYEv97vZJAAAA4AiO38JvYhrAZzUv3rlRgY1LYIPBBDVGiIgHAAD//+zd0Q2AIAxAwa7mCOpA6kDqCo7mTycQEgjercAPoeFVVANoal4XYQ0AAAB68hiGAQD0JbeKu6Mxsi0/swO0ZHslozqcLAAAAPAj3vngOzENoNh9XnsGECYzCioQ1KglIl4AAAD//+zciwmAMAwFwHQzR9N91KwoQhcoFFrauxUCgXx4QjWA0Q5JmAAAsA0HO6Zn8QgAMC2PBqzOzAwMU4N93O1ZUt55qiwAAACwEXs+aHfl8xZhGkBPf0+pARul/rzoMbQSqNFTRHwAAAD//+zcwQmAMAxA0YymI6hrCh1BR/MS7wqKob63QukpyRfVACrYvAIAAAAFONQEACiqrW23YEDnhjxqB/iCsA+9smgIAAAA/Ma0zOKicM8Z0/B3gFdlXGPMuYXdF64Q1HhaRBwAAAD//+zdwQ2AIBAAQTozlqC2qV4LlmYwvI0fkeBMC/w42BPVAJowLbOwBgAAAJ8yHAMAaFusYVhM73xqB6orQR9RH3p0lDAbAAAAwF8MThoeyfeGo/eCQG2x7VcoIQd9LALkhqDGG1JKJwAAAP//7N3BDYAgEATAKw1LEPvvxZiciT9eiOBMEeRysItSDeAryn5UD3UAAAAYxXIaAGAO5jZWVjLcDvAmH2CwKnMjAAAA8BuZx3HHAG1bBtoV8gJDXcU+j3INZxI3hRq9RMQJAAD//+zcwQ2AIBBFwW3NEkgsSPoh2RYNiWdvKsJMFQQ+T1QDGImxDgAAAJ9QnQcA+IdseRgTMDnvZcBryl7chzCrmi2dGQEAAICVCGrAvdo/r4tpAKO54ho9orDZwyxPUONJEXECAAD//+zdsQ3AIAwAQa/GCEkGYvUIiTJtkDF3I1AhhN+iGkAq13P7KAgAAAXNEj5kZWslAMBe3N8ozZA7sFB32FQ0Q2wAAAAAJ/HWB9/GgHqzdAvIbkR/xDWOJqjxt4h4AQAA///s3bENwCAMBEBns6yWgUJWjJCgpEQCczcCNBbwj1INYDW3sB0AAKRkzmdlDp8BADbSfh03w5GZh6/AdAp8SEwBGwAAAHAUGRwYempAuQbVLRGwi16u8b3lcudxFHs9W0T8AAAA///s3NEJwCAMBcCM1hWEjik4Qh2t5NMBKlXvVggYSMwTqgH80aMqAAAAzGJpBgCwJMtktubYHfhSucslwIdN9VabHgoAAACcRqgGjPI/YB6kmxUCS8t3TLjGEQRAzRARLwAAAP//7NxRDYAwDATQWgQEzRBQC5PGDwkKWEZ5z0SbS+6MagBTWrbVsAYAAAAjCJoBAD4o9+x+OYprd+kd4A0GNajKfwgAAAD8kbwPHj2PUzkZKMW4Rmlu1igRcQEAAP//7N3BDYAgDEDRjoYjCAs7mjHh4l0IlvdG4AjtR1QDWFU5WzUoCAAAwGguIgEAfsov5GzAECzwuR7s8RZPRlcPrwEAAABsw94NvDyLyYcjAbIS10hHUGOmiLgBAAD//+zcgQ0AEQxA0drMwqxwq4nECHfi6r0pqPqiGsDJHhd8AAAAvmQYCQDwexYFyKyuz+8AbxLsISvnQgAAAOBG3hFgBndbL3YBgVuIa6QgqLFbRAwAAAD//+zc0Q2AIAwFwK7mZrIP2hWJiSNoFHo3QvtD6MtTqgH8nUAPAAAAb/GZDAAwuey5XyEpe2RhbmXAY+6iHiF7VtSypzchAAAAUJE7AtW1PM6t+hCAmpRrTEuhxhciYgAAAP//7NzbDYAgDAXQbiYrAAu5GasZE0bQKPScEdq/Pq5QDeDvSu3t1CUAAFjeoYUAAMBLHAewszKf4AGeMFSRHc2gNQAAAIBUam/2B2R3PyWbDQLpCddYikCNr0TEBQAA///s3bEVABAMBcCs6D37WM1oGp1SgbhbIiTkW6oBvKC57AMAwPOc6bmOgRoAQA4zldzAmcykzAHbSi36IGQlhRIAAAD4lTd5/Kr7lAywslzjemrXSRExAAAA///s3LENwCAMBECPloETvAKj0VBGVJEgcLeEJdv/SjWAv/AsCAAAAAAAvMo7hSnZ2SUMD3zAzZ0d1V6wBgAAAHAiOz9OVPMpQskAA8o1lmR2zRYRDQAA///s3MEJwCAQRcEtzRbU/nsRrUBCIHGdaWEvIp8nqgGcotTejAUBAAB4i49JAIB8jAHIzDAWeEyYh8S8/wAAAIAr1d6Ky3OhFdRweIA9M64xYw42058T1PiDiBgAAAD//+zc0QmAIBSGUUdrBaF9on2Eu0JtFkELFEJ1PWcEHwTB/xPVAP5k8fAHAACgk91BAgDkEi0MhknNKB54os51EuYhqS1a+IAIAAAAjMq2htGsghoA950xh+v+FNd4h6DGV5RSDgAAAP//7NzJCQAgDATA9F+LYIviV/CjIBpnigghxwrVAF7j2AcAAAAAAJhxSEVm9mTACrWDlGqp+j4AAADgZ+Z+/KQ/JAufB9gwhGtwhkCNm0REAwAA///s3cENgCAMAEDcjBUKLORkOpofBjBREoW7FfqgLWlrqQbwNzlqUQgBAADwlCYlAMCE+rVyuR7TihaH6AJ3RYvsYiWT2gUWAAAAWFXUoufHSgwkA7yoL9fY/LUMd3q/PialdAEAAP//7N3BDYBACARAStPKtCA9WrA0Y2IBJuYex810wJcNi1INYESbJQAAAAB/WFQCAJQm+Key5T2SB/jCt0oquvJIz1gAAACAmckJmIVCDYBO8my7co1unkKNtehs44qIGwAA///s3LsJACAMRdHsP4vgihKws7AR8XPOEGlyeUY1gFuJfwAAAAAAgEEtNcMqcRUv8ycDpvoAj7ieF4k7AQAAgN/5E/ADgxoAG+S4Rt5cnc0yBjVOFRENAAD//+zdwQmAMAxA0YzWFdQ1hY6go0khN8GLUDS8N0IOvbT5FdUA/qot2+rnEQAAAAAA4Kbv3QU1lbVclgd4cpgOBZ0ZUAMAAAAA6hLUAJhonLkZgvDW5h1BjS+LiAsAAP//7N2xFYAwCEBBHBF1H1dPY5smjRjupsgLvI+oBvBnT16nhUEAAChOEI+CDNwAAHpwxZyduUIHTOWd/uPYlfcdAAAA0JpdPBoQ1AD4yBvXOMxjlghqVBcRAwAA///s3MENgEAIBEA6UzvTfk6pwc6MDRj9edxMCbxIWFapBtA7gUEAAAC+Ok0MAKC+bLkqVKOw2dM88MAdnYq2bGm3AwAAAEY3jT4ASlOoAfADuR93FmGRuXlNoUYPIuICAAD//+zdsQ0AIAgAQUZz/6mMCZ3RWuFuBAo6HlEN4HdDaRMAAAAAADjwPYPKHM0DG8EdqspgGgAAAEB3o/sAKEtQA+AhaydnKEIs4k5Q4xcRMQEAAP//7N3BEQAQDADBKBEFad3Hx4wCiN0yRC6iGkAGo/bmYQAAAAAAANisa+Y+X5GW5XngQHCHjITSAAAAgO/ZmyExQQ2AS624RjGrORLUeElETAAAAP//7N1BDYAwEETRsYaEJsgEVgJII1x6wkA370nodTa/ohpAFw6DAAAAAACAP4Z9OrORAdPYx+01aOipo0SkAAAAABJRDToS1ABYQJ3Xt9VsPraZBDVWk+QFAAD//+zcUQ3AIAxAwUrDwsDmEiwgjRD2MwmUOxFNP9onqgFkUZ5WHVEAAAAAAAA//e1DWIPMPNEDsWdBcVRPUvY4AAAAgE1om2yGoAbAOdbM/kISt8ckBDVOFBETAAD//+zd0Q3AIAgFQNzMFbQDuVpHa0z46Qji3Qok8AMPoRpAJWs805IQAAAAAADw47s5xfU8pgfuZqGeit4MSAMAAAAAanGQDHCoDNdou5dfWEPz61QR8QEAAP//7N3BDcAgDAPAzFjWrMSKFVL+vOvcDRGkYIxSDSCNoBAAAAA3gvgAADP55Zxk7shgsC7WUa5DnP1uoUQAAACAswNcjwJ5kniQDBCgZ/moee78+rGq+gAAAP//7NzBDcAgCEBR3MzROpAtKxqTnnsvvDeCFxMCX1QDqGYaFgAAAPDlFJI9EABAP7nyElijsPke1QM9CetQkSAaAAAAABTkIBmgjrOTnfczmuzj+L/+LCI2AAAA///s3VERgDAMRMFYq4RQ/GCdYehXHXDs2kjvVVQDSHT1PDwaBAAAAAAAdsaZJDOqhx/qs59olPs4cVYQDQAAAICXGwApDJIBAq1g0giOawyfOn5cVd0AAAD//+zdQQ3AMAwDwEArtfGZVAqFNlXKZxScOxB5pI0tVANIZWEAAAAAAAD87HefIe0YzLT6uB6Yxds4iXysBwAAAGhKZwnyOEgGyHVnfIdrpBXeCNRIUFUfAAAA///s3cENgCAURMFfmpagtGlCC5RmjFxoYZkpggNhH6IaQKrjardHgwAAAAAAwKI/3UiTZMb1sBEhHUKNGUIDAAAA4CeqQYJvaO1OG2AD87w/Qz69EdRIUVUvAAAA///s3cEJwCAQRcHtLKVZUZIWRQiCkAb8zpTgQRbEt6IaQLKmyAkAAAAAAPxI24oBk0/2cBQhHRKZ0wAAAABWl/Ngd+/9WHwAcJARovju/p3ffQQ1klRVBwAA///s3bENwDAIBEBWtJSBkn2cMIJXc5PGIxjfrUBB8ehRqgFU54gIAAAAAABYZE+lA1QmH4MDtKsNc6agJ3s6TgQAAABYeTbL7hRqABwq3+/+98Bu+Y9CjWoiYgIAAP//7NzRDYAgDEXRjsYKBRZyIHRF46duQD1nCRLyekU1gOpajm5MBAAAAAAAfBlvUVbOFI6BwnJmM6SnIuEzAAAAgLcc3T8guzscJQP82/MOXOvcKawhqFFRRNwAAAD//+zdwQ2AMAwDwIzWzSo2r0B5IHWBYu5W8C9RHKUawB8MgwQAAAAAAOCtv6BbgpNq9tE9kGnKlUCXUAEAAAA2Zv182X1ErUgXgEcXa5z+AEehRqqqWgAAAP//7N3BEYAwCARArCwNayhBS3Oc8RPTgOJuCfAEDqEawF/sOg0AAAAAADw43qQyR/dQ0B2YY5Geao5c03I9AAAAwKypCR9mFgvA4AqsyK0vL32CI1Cjsog4AQAA///s3MERQEAMQNGURgmoSD/YFpRmzJg9cXNY8V4JOWY3X1QD+I1hGoU1AAAAAACAqixlb/ShHt7QXcf3QC6COWTkcz0AAADAPXt+vmp2mAzAk7Ju/RmxaGhAghrZRcQBAAD//+zdyw2AIBAFQOzMFlALoiCBFijNmBiPnjwQmGlhb/t5K1QDmMka901DAQAAAAAAeNWz9jSkh785voeBxCMmS/QMqD1BZwAAAADAGFrNJaklAF/uEIuay9LBMxyBGjMIIVwAAAD//+zdsQ2AQAgFUEbTEVAXciC9EVzN3lhcZ+TeW4ECQsJHqAYwmkvFAQAAAACAB9/RqWrKLR3gQx2CcqjIHAYAAADwItdFKAF/ZecHQLd2nPOHvWMXqDGIiLgBAAD//+zdwQmAMAwF0K7mCFUH0n2qWcHRRCjePSjSvrdAroH8JI5qAN3J0+iwBgAAAAAAcIsSyw8+X8BbzMagAXnOAvS0aI0SejAAAAAAaIflZAAei22/ZqHDx9mdo9alBymlEwAA///s3bENgDAMBECPxgokAzERyYoICSQKqhRIOHcLuHBn6d9KNYAZLWstPnIBAAAAAABPPiaRljA+pLBZI9lcxWYAAAAAvHMT5HeEkwEYdZYy9b19Vaxxz2IWEXEAAAD//+zdwQkAMAgDQPefuh9xgdJH490SgoREqQawlUUuAAAAAABg9Eq61SRSCd7CxxTjEEpQEQAAAACy+PkBcK3LLl7eFIUaG1XVAQAA///s3cENgCAMQNGOhiMUXMjNHM2YcPDgUQ/AeyP0QtKkH1ENYFnZqrAGAAAAAADwdJgGs3KUD2PKPYswDhM6e9AMAAAAgBfZajEXBnMfKNv5AfCJ/qZsP3yOI6ixqoi4AAAA///s3LEJACAMRcGM5mauLkJsrWxM7pZQPuSJagCdDUMDAAAAAABw5HGnsAZVzTzOB/4iqEFF/lsAAAAAd/Z8fmPzA+CpHdbIAMarN0ZQo7OIWAAAAP//7NyxDYAwDARAb8ZqDAR4BBgNRYpERYUoEt+N8KX1fqMaQHVn9QAAAAAAAIBHbrmKg4l5zoeB9CEc5Xlmc/UhMwAAAADeLbJhIO1J2c0PgF/kfrQez9cxDIMa1UXEDQAA///s3cENgCAMQNG6mSuoa4pd0ZB48GZC4gF4bwHuDf0V1QCmtx27sAYAAAAAAPDmkhKjWp8lfaAPQjgMJ8/0YREAAADgm1k+3bCkDMDfarwpy7XUOEbDU4IaRETEDQAA///s3MsJACEMQMHUqA1ZkGCL4qcB97CgzDQhJPGJagCM48GcDBwAAAAAAICp1VY+LuLhBj7pwwV2AMcem9cIlwEAAADAW8z8APjNjmOcvD2CGiwR0QEAAP//7NzBCYAwDAXQjOYKtnNqR+hqHgzoSXoSLe+NEAqBpPlCNQBOXR0AAAAAAIAbH8CY1ZLH+sC32WEznQwuAwAAAODBWosZCr/Rtt17BeBV2XtGgjIEanCJiAMAAP//7N2xDYAwDARAM2KAMQlegdFQEA0NLci6G8Htv95GNQBubZmVkgAAAAAAgEtueYyA3TUoSi4GP9bWpoRMRUqLAAAAAFCLJwUAfCL7PgYzppdej0ENniLiBAAA///s3cEJgEAMBMB0pi2oBdmQmhYsTZCDA334VI+ZEpLnko1SDYCqH6bRVy4AAAAAAOCUSwrYaZajffi02XpozF4KywAAAAB41pkRf5DrJmsC4FWlOOOaQSnU4C4iDgAAAP//7N3BCQAgDATB679qPyIKPnzGMFOFCNkT1QA4WeUCAAAAAAB2FpboytE+FCR4Q1PeUwAAAADvjMXyA39+AJQwAxoroiGowVWSAQAA///s3cENgCAQRUFKswXUhuwH2BYszcR4IhSAZKaNzX8rqgHQyccurAEAAAAAALyihHEzyzLeh7nkM2+CNyzoihL9hzAAAAAA4MeiNjcmAKYRtd1fWENQg7GU0gMAAP//7NzBDQAQDEDRjmYFTGRzkXBycUTeW6FxaeOLagDsUq5F2RMAAAAAAFgc3fmVz/twF2+S7wiUAQAAAJzLtdil8IJmSgDcZoQ1ZlwDdhHRAQAA///s3cENACAIBDBWJGFfVzPErwMoaUfge8B5qgFwt8wFAAAAAACIcwzaobvgnZGyUi4GD8jKLn5Q/sA0lusBAAAAYB65KQDwl4jYAAAA///s3bERgDAMA0CPxgrAQFmIxCtkNBooqbn4/kdQbclGNQA+7OfhgBAAAAAAAHgphVLV9pT5gX81+VPMzCt9VgUAAACAWmb2YVQDAFhLRNwAAAD//+zdsQ3AIAwEwB+NFRLWRGIFRktDS5EqBN2N8bbfSjUA1spVbwuEAAAAAABAeuvD1yUO5pgfPjSLbcymOY1CMgAAAID35PXsTu4HAPxPkgcAAP//7NyxDcAgDARAjxYGJoyAR6OAOm2EdTfCl375jWoAfJvyAQAAAAAAYg9rNEFQ1HOe+oF/6KWpJs8gGQAAAABQR47+uvsBAPeJiAUAAP//7N2xEYBACARAWgQsyNbs7KOPHSOV2S0B0ps7pRoAN7JLgAkAAAAAANisLzGV9Tt4QR55ujvTKCIDAAAAeC67lF/zdZcPAQC/FBELAAD//+zd2QkAIAwFwZSWhtUWRSxA8MeDmTIi+zSqAbCWjhMAAAAAAEDMSHTEz35g4kcp7ocjDNrwGwNkAAAAAHt0K1ytleodCQB4U0R0AAAA///s3EENADAMA7HwJzVq+xRAX5MW2TSinKgGwM4R1gAAAAAAAIazKK2c++EhIRsaTYAMAAAAAOhiHwUA/pXkAgAA///s3MENwCAMA0BvBh0BqQMzGuoGiAcq6G4E5+kknmoAzLNECAAAAAAAfMeiPUmXBDdy5A97tLdVHTQXegwVAAAAYFkRHT+mGwUAzpVkAAAA///s3cENgDAIBVBGY4XqnLYrMJoXBzAemtq8NwIJFwIfoRoA72U7D0uEAAAAAABA+MbExhz5wxx6jd3UEzwGAAAAwDepbiyqxtXN/gCA/4qIGwAA///s3DERgEAMBMBIw8LB+3lpDM5oMEBB8WHXwjWZTHJKNQDemTl2iwoAAAAAAPi552lUsQYtZeSULHwnI5sDeRoyFwEAAABAT5dcAYClVdUNAAD//+zdUQlAIRAEwItmtFdIrfCiiWABBUFlJsL9LrerVANgnsUgAAAAAACgF2t8rsCj0nj6B/aQOfOafxSOAQAAALDA+Csnq7nIRAGAu0VEAwAA///s3dEJgDAMBcA3mh1BXbOQFfvjAiJCW+5WyFdC8iJUA+C947wvDSEAAAAAABBf2dmYo3/4wRNYY0GerVSvpqIAAAAAn5gZMithugDA+pIMAAAA///s3DENACAMRcFKwxkIIqkGnLGggLDQ3Fno2v9ENQDudCVQAAAAAAAgZw7PZBTVzvgfeEuwhmoExgAAAACgruW2AMD3ImIDAAD//+zdQQ0AIAwEsFkkQRCGAAtI44MCwoellbHdbko1AO4JOwEAAAAAAOGYlMTsw+ChUkvzcZJk1ikYAwAAAAASmn2Y/wEA/4uIDQAA///s3NEJwCAMQMGM5grWNQuu4GhScILih8S7EfJngk9UA+C/UtvjcQgAAAAAAJfrbx/fp9Lb50BKZUUAgD2EashGWAwAAABgD7tDTuT+CQDkEBETAAD//+zd9YnVEgAAIABJREFUQRGAQAhAUaoZQQ20hZyhgttsLzZwT/BeBLgyH1ENgH/GeV8+CQEAAAAAQHP55NF9BpTlkBc2EKihoPcLiwEAAAAANU17BQBKiIjF3h3UAADDIADEv5duFieie5E7FU0g1KgGwJ4iIQAAAAAAEN/aaWUMAL6QK9PG3QMAAAAAxe4c+RAA0CHJAwAA///s3FENwDAIBcBKqwXaGZqfJkjYpE1EfxZ6J+HxBSRPqQbAvh5zWBQBAAAAAOBwudK/gKqUAcCGuOKRH8XcufI1VAAAAIB9MUcXIz/k/gcA1NFa+wAAAP//7NzBCQAgDAPArOYIgvs4m5uJK4gPKXcjtL8EYlQD4I0pyAAAAAAAAJI0R6AiowBwp49+emRdMqUYEgMAAAB4Sn7Ij5avAABlJNkAAAD//+zdQQ0AIBADwZOGYcAinzNAwqvM2GiyFdUAeMdDFwAAAAAAfK5f2z03kWh0HAC4Y0cmjYAYAAAAAITbcwnrAgA5quoAAAD//+zcMREAIBADwZeGBUARzpBG8waYoQF2JaRLc6IaAOeU2pvTCAAAAAAAjO8X4FXiALAhQzRiNLxkZkAMAAAAAAAA4A4RsQAAAP//7NwxEQAgDATBSMMCIAjrNBFAQcGEXRmZ/IlqANy1+hyeogAAAAAA4GM5NjU4paKWkQDgjBAN1QiHAQAAANznjshr3AEBgFoiYgMAAP//7NxBCcAwDIbRWJuEwARN0KAWKm0UKqCHXpa+J+E/JvCJagDs56ABAAAAAACHa2+7Tt+AsvzCYEHe+YwQja0opM9wGAAAAAAAAMB/RMQHAAD//+zdMQHAIAxFwUjDQqCCaqjFIhJYmMKdhL/nRVQD4LyWo792BQAAAACA6/niREUtnxQKgD0BGkoRDAMAAACAO8zvdxMFANQSEQsAAP//7N2xDcAgDARAr2jCPlkIiRGyGmIAyjTmboUv/Xob1QD4x5tPUyYEAAAAAICLzTF34cxHdyr6pApn2VPhmGoMhQEAAADAHdw2AYB6ImIBAAD//+zdsQ0AIAwDsLwIXMxnLMxMIKHKfqFbo6ZKNQDe8XkIAAAAAABwhEpJSgPgSFZMKbsoDAAAAIDL2uj2LvxmmggAUE6SBQAA///s3TENACAMBMBKAwkkyCRBAkjDACtLuZPQbt/kq1QD4J0i4AAAAAAAgL/NMbePTiSlNAAuWm/LXEimWigAAAAAfMNdEwDIJyIOAAAA///s3EENgFAMA9BJw8Lg+yEIAiwgjZBwwACX7T0JPbZJnWoA/GvNZZ5kDAAAAAAArW3dA6CmHOlgHj5y5LMN24ep5HoPwgAAAACABs790AcCAPVExA0AAP//7N2xDQAwCASx35zVU8AKKULsKZAQh6gGwH2+dAEAAAAAwMfmGFVYg41qIgJAsxtmG/MLAAAAAAAA8LYkBwAA///s3UEJwDAQRNFxllpoo6h+CrHYSywEwuY9CXNd+CuqAbDedffHly4AAAAAADjY+IZbAVWJCECSGZgRmaGSd4bBAAAAAFin2ZaNiOwCADUl+QEAAP//7NxBEQAgDAPBSsMCIAjrfLBAH+2ujEzmRDUAcpy5lwMVAAAAAAD05ohGRePFBKA7gRlKEQQDAAAASGFfBwCA3yLiAgAA///s3UERACAIAEEqOmMgC6kRrObHDD5gNwJvOEQ1AP45Zg0AAAAAAHW941Qf38lITIDSWm/D8jvJCIEBAAAAQDF7LqFdACCniLgAAAD//+zcQREAIAzAsEnDwgDBSOODBu4YiY/WVAPgohzdWAMAAAAAAP4mUqWiljMNBfiZsQyVrDMCAwAAAAAAAHhfRGwAAAD//+zcQRHAMAgAQaTFAm1kZiYWIq1TE3nArgWewIlqANw18n0cFAIAAAAAQFN77fM/q5o/BYnL01LOFB+gGgEwAAAAAOjH/hIAqCsiPgAAAP//7NxBDcAgEEXBtVYJFEEYIsECdcalFmiaZcbCv202T1QD4HseCgEAAAAA4GCjj8v+ZCQuwKGa4UlkvgEwAAAAADYr9XZT508eawAAaUXEAgAA///s3QENADAMw7BS/Mefy2Fc6mwgiagGwAdnrrAGAAAAAADs5gJPI3EBVhGSoY3wFwAAAAAAAFAnyQMAAP//7NxREYAACERBolEBNaZKRWM4A7sR+GXuiWoA/CPrPNLtAQAAAABgp77bEJuRRAbYoq5KIRmGEfwCAAAAgKX6ef13AIC5IuIDAAD//+zdQQ0AMAwDsTAvtFHbZxwmpTaEALiIagD8c2wPAAAAAACreYOn0bzYALQT1KCK4BcAAAAAAABQKckFAAD//+zcQQkAIBREwa2o1hSsYDQvdhC+MxX2uPBENQAeaqMLawAAAAAAwKfWXDvJtj8FiQ1Q2g3HiMdQidAXAAAAAPzLXwkA1JbkAAAA///s3EERgDAMRcE4IxYKinAGznqJhpYJuxLyr5knqgGwV47r9GwFAAAAAAD/dduehrKiA9CVcAydPBX6AgAAAGCtw735iNcQAEBrETEBAAD//+zcQQ0AMAwDsfAnNWr7FMMqZTaF/irlRDUA9h03AAAAAACAP82I1ZCVRqIDVJpgjGgMTQS+AAAAAHb4MwIAwAtJLgAAAP//7NxBDQAgEAPBkwYSAJskWEAaH0SQY8ZCn01WVAPgAW10YQ0AAAAAAPjUmqvanoTKjQ9ANr5dMtk38AUAAAAAAACQU0QcAAAA///s3UERwCAMBMBIq4UU/IAhisXaYMKuhftlbi5GNQDO8GR7lQoBAAAAAOBevsRT0ZAqlWTPKVAqMewFAAAAAOz1uX0DALVFxA8AAP//7N0BCQAgFEPBRTOw8CuKLWTe5RhvohoA7/BoBAAAAAAAn5o9d6zmKZ42S4SAMkIxNBH0AgAAAAAAAPolOQAAAP//7NxBEQAgAMOwWQQMI40PIriR+GhNNQAeMtY01gAAAAAAgH+JW2lkQkAFgxjK7Dv0AgAAAAAAAOiW5AAAAP//7NxRDcAgDEXRSquFwmQuwQLSCC42OMfC+2vSK6oB8C1ZvaVNAAAAAADgPuMdcz+5mp7TiBHwd/VUCsRwGCEvAAAAACDcCgGAK0TEAgAA///s3EkRACAMBMFYBASDND5o4AjdFpLn1ohqANynuwkAAAAAAHzLcI2MxAh4nR8mk7FCXgAAAAAcUloVowYAgF0iYgIAAP//7NxBDcAwDATBgxYKl4Y/ln4KoklmKPhjyfKKagD8UJ8prAEAAAAAABf6nlyFNThOV92/2FJXR5JhehzEngEAAAAAAADcI8kLAAD//+zdSw0AIAxEwUrDAiCI4IcEi1wQwWfGwl6bV1ENgDOlXIvDLAAAAAAA+NAc03cyXpR2nABu0yzGQ/oOeAEAAAAAAAD8ISIWAAAA///s3TEBACAMA8H49wJYZGFAQil3MjJ8RDUA6vLWBQAAAAAA//IiT0fiBDzlhGDEYGhDuAsAAAAAuK0xbYYAQH9JNgAAAP//7N1BEQAgCABBomkEtX8XP4RQ2K3Ak+EQ1QB42DpbWAMAAAAAABrKo1ef5KlmZKQAfmFfSyXTNAEAAAAAAIB2IuICAAD//+zdUQ3AIBAD0JOGhYP5WfBDggWkYWOD9yz0t2mNagB8W8lWFQsBAAAAAOBOXe4c6BUqf5BPeufjJGuOaawLAAAAAAAAuE9EbAAAAP//7N1BAQAwCAOxSsO/qn0QwSDx0auoBsB83o8AAAAAAOCgHr8awLJNiRXwCQEYNhHqAgAAAAAAAG5K8gAAAP//7Nw5EQAgEATBs4YEwCZVWEAaCQESeLotbLbBiGoAXCDXIqwBAAAAAAAf6q0nu/MgsQKOJvzCY8YKdQEAAAAA7PyGAMAfImICAAD//+zdQQEAIAgEQaJRQU1sM2sgzFS4H49FVAPgD7nOTlsBAAAAAMBIvsvTjmgBxQm/0IZAFwAAAEBJbpBUcK0AAIwQEQ8AAP//7NxRDQAgCEVRKrIZ040IVrOGwjkV+OTtimoA/OO4FQAAAAAAzFO7xAfoyGCYJ+VKf1k6EeYCAAAAAAAAZouICwAA///s3UERACAMA8FIw0IB/1qwAXTXQr6dq6gGwENqTQdcAAAAAADQky/zfEe8gNvUrpFkGIZfCHMBAAAAAAAA7SU5AAAA///s3EERwCAAA8FIwwJUEIaYwQLS+qmIArsW8s2cqAbAXkp9mtMLAAAAAABcZo65kiy7c5jyRQzgL7olOIggFwAAAAAAAHC9JHkBAAD//+zcQREAIAhFQSqqgRybGc0LIVR2K3DkzxPVoCKjAV432+jGhQAAAAAAUM9ycz4kYsAVMvDiD8svdga5AAAAAAAAAGqLiAMAAP//7N2xEQAgCAQwRnM0F1JXtKG29Q6SEWgfHqUatHPW9sWLCiwXAgAAAABAM3kcK+eimpFlBvCbDJZKFHEBAAAAAE9n7WlCAEALEXEBAAD//+zcYQmAUAxG0UXTCFML2UddRRHsIL6dU2G/xgdXVIOW6rxml+fnplwXzysAAAAAADRTR9m5GJGYAZ/KLZ/tVdyFUexviAsAAAAAAACgvYiIGwAA///s3cENABAQRcEtTQsoSEMSLbpQg2CmiD39vBXV4GcGh9yu5VoMuwAAAAAA4D++z/OatKIGcIqwC88YfbinAAAAAAAAAFtETAAAAP//7N3BDQAgCANA9t9FXdGY+GADI9ytUWiVatDWGvOscljm4HeOuwAAAAAAoJn7LCvnohq5F08odKEYxVsAAAAAAAAAWURsAAAA///s3EEVgDAMRMFIKxJKdQIWKo1Lq4FHMqNj94tqUNpz3YfBIT/X+jiNvAAAAAAAoB6nWdIRN+Ajgi5kMVd4CwAAAAAAAIAtIl4AAAD//+zcQQ3AIBBFwZVWCwv1gyESJIC03iugCXRGwu7154lqgMEh+2tZy+WPAAAAAADwH6OPJR7PgcQN+FTeOV2cg9i/AAAAAAAAALxFxAMAAP//7N2xDcAgDARAr2iJgViIZAVGQ0gUmSCFuVvBpV//SjW43jueKVhAAQKGAAAAAABwHz8uysmW3VX5Q7bcwwXGC6hinsItAAAAAAAAAL4iYgEAAP//7N1BDcAgEATAk0YlAIJaQU2wyAMsNCkwY+G+t7tKNWAUazyWvFhcyrV4MAQAAAAAgIPM8KxiDXZzz7ID+JrhArbR3na5JgAAAMAaZD/4CTk6AOAcEdEBAAD//+zcsQ2AMAxFQa8YMhALIXkGNqOJRJ2CAvtuBLd++kY14CU45O/OMQ+BIQAAAAAANJJXCi+pyNgBn1rDLX6rVKF3AQAAAAB23S4GALQREQ8AAAD//+zdsREAIAwDsYzGwsCKNKnpaIy0hnMfUQ1oey6fvEjgwBAAAAAAAP5j4yLN6OgBvGJXJYbAFgAAAAAAAMBFVR0AAAD//+zcsQ2AMAwEQI8WRnBgTWAFRosiUVDRpSDcjWBLbmy/UA14OPejHxpcasKHlVyrgxkAAAAAAPiR+5nWjovZCD1giNyyz0yhLcxi0UkAAAAAAACAFxHRAAAA///s3UENwCAQRcGVVgsL9YMhEiwgDQFNeusBOmPjb96KasCTT17srmUtjsAAAAAAAOBfbFyc5so7bV58QbCFU8zRh6gWAAAAAAAAwJuIWAAAAP//7NyxEcAgDANAr8gdA7EQMAKMliYVDU0q538EuZXsqQYcZh9b6ZAEFMEAAAAAAOBH3lGtYS3ZLBflS6WWJlAS0W0BAAAAAAAAuImIBwAA///s3TERgDAQRcGTFiQEDCEo4SwgjYaSSUVD2LVw7Z93ohrwIPuxGx3ycaVuq0EYAAAAAAD8SLZc3JvZiCDwMs8JmMV5B7UAAAAAAAAAGImICwAA///s3UENACEMAMFKw0IBP0g7a6eAhAcfYEZC+2yyFdWAOR89ON3IVostAgAAAADAU9y4uI0IAltkz88kuYWQFgAAAAAAAMCiiPgBAAD//+zdwQmAQAwEwLQYuIIsSE0LlnZcAYLgLzfTQvJcdpVqwIu67kfokAaEDAEAAAAAYCN11uHedJMj/TW/5Mg1RmCQgC5kWQAAAAAAAAC+iogJAAD//+zdwQ2AIBQD0D+aK4gDOZGwAqMREs8mcBPeG6HnpjWqAR/Kk3s5q8qIHzvOKykZAgAAAADAXrzXs5r7HUWAWc4IWEU1oAUAAAAAAAAwICIaAAAA///s3TENACEQRcG1CAjCEAkWkEZDT+46YMbG/rwV1YA9Hz44XU0lGxkCAAAAAMAjeutDOJ4LiSLwywqyuJdyCxsWAAAAAAAAgC8iYgIAAP//7NwxEQAgDATBSMMwYAFpNOmBNuza+J8T1YCD2cdySqAAJ0MAAAAAAPiLfYtqWsYR4JWtlCpWhrMAAAAAAAAAuBURGwAA///s3cEVABEMQMGUti2gIQ2hRRcFrCNmWsgxLz+iGvDDaL365sXhvlRyNUQAAAAAAHjDOrq13+I24ghsWSEWMRZuIZgFAAAAAAAAsCsiJgAAAP//7NxBDcAgEEXBldZKAAQ1+CFBAta4IIAeS2ck7F5/nqgG7DNO4OueVLLBGAAAAAAA/ERv/fZrDnOtSALsGi7FIeoKZgEAAAAAAADwRkRMAAAA///s3cENACEIAEFaNLEgC/KkBUuzBeOTmymB8CNZRDXgUn5rC2tQgO9dAAAAAADwL+5bVCOSwJXW2zApqsiZ9hkAAAAAAADgRUQcAAAA///s3cERgCAMBMCUhiWgdQotMs5QgPIz7LaQZy45TzXgg363J6Sg+YM/K/U6hW0AAAAAAGAT8wjXfotUPEvgJYUDZHGYJAAAAAAAAMCiiBgAAAD//+zdQQ0AIQxFwUpbC7CC1hBJLSANByRwW5ix8I9NXkU1YJ1vXvzdV976WBEAAAAAAK7hvsVpxBKYEl7hID1bimMBAAAAAAAA7IqIAQAA///s3LENwCAQA8AfjRWQWBMyAoyWJi0FSvfcreDWtlMNOPT0sRQPSWAKEQAAAAAA7vCNcQ1yScVpAju11eJ4hUT0UwAAAAAAAAD+iIgXAAD//+zcMQHAIAxFwVhsMVRDFAtIY2FlyQbcaciY/0Q1IKHV//N4yO6e8gprAAAAAADAPYxyOY1oAitug1P0GcYCAAAAAAAAICsiBgAAAP//7NyxDYAwDARAjxZGcMiYSFkRRaKhhSrW3Qpfvv1GNeA7h4fsruXZmxQBAAAAAKC+5ylXv0UpOdKIPC85cvWfOlBKmNc8JAkAAAAAAADwU0TcAAAA///s3EERwCAMRcFIqzMQVIhFLq0BhlPYlZBc33yjGrApxxQeUoHQEAAAAAAALpFvdr+mmOcbUYBfcwmK0KMAAAAAAAAAnBARCwAA///s3EERwCAMRcFYpOiEWkAaA1MH5QLsSsg5/4lqwA9vqePxsLkhO0v5EdYAAAAAAIB7GOlyGhEFpi+wIrLCEYSwAAAAAAAAABaJiA4AAP//7N0xAQAgDAOwSRsSAP9eeOYAHiCxsLftjGrAPsFDbpd9DuEyAAAAAAD4QJV0jcbzkqwxBfBMgFc0lwQAAAAAAAA4JCIWAAAA///s3EERwDAIAEEsZqZ+GkFtsBBpFZG+YFcCPGFOVAMO5bu2sAYFeDADAAAAAIA+3Lao5rbR3sY1ZvcZUMbOJ8WvAAAAAAAAAP4SER8AAAD//+zdwRUAEAxEwZSmBdSJFl2UkAtm2tiXH1ENSLDG9NGL69XehDUAAAAAAOAD51jXtsVLiqjC94RVeIXwFQAAAAAAAECmiNgAAAD//+zcMRHAMAwEQUGTISRBZD6ZMUU3hqAmyi6Fb39OVAPqODbwdXk9d1oRAAAAAAD6W+8aZqYZUYWfElShkXnCVwAAAAAAAABUiYgNAAD//+zcQQ3AMAwEQUMrhUiB2dYQEmgh4ZczQ8GSPyetqAYUye/fwho0sBwRAAAAAACuYduiFXGF+4w5HkEVusg3/TAAAAAAAACAahFxAAAA///s3cERABAMAMG0iDrRotEDD7HbQr7JRVQDDpp97AUHX0N4WmlVWAMAAAAAAD7geJeExBX+Y+ZkIXQFAAAAAAAAcENELAAAAP//7NxBEcAgEAPAk0YlhCIYaZ16oI/CroU8k4lTDVjP0IG/a7l7kyIAAAAAABzhEjM7yYgD+UNk5O009ZrsYDq6AgAAAAAAAPhIVT0AAAD//+zdwQ0AIQgEQEqzs2voPFqwtIuJJRgfONPC/mADjmrAZtm/oXxIAcqGAAAAAABwgXxz7raGrCmkrWML1PfImCI8bwEAAAAATjNjBwDuERE/AAAA///s3EERwCAMRcFYhBrCENRCpfUSC+0MYddCrj9PVAM+kGEN40O21q4urAEAAAAAAGfwzEs1hqDFZThFPIUKngxcAQAAAHCIe67h1gAA8KOIeAEAAP//7NzBFQAQDETBlEYJqBMtumjBQd5MCTlnv6gGPLLnqm7L50ob3SMaAAAAAAAkd8e8Br1kUm50gbyEU8hC2AoAAAAAAADgpYg4AAAA///s3VEJACAMRdFVHFjIPoIRrCaCFfxwnFPhfQ7uRDXgLWENfrcsCAAAAAAA9c0x3bWoRnShqGx5vjiKplBBv2ErAAAAAAAAAF6JiA0AAP//7N1BAcAgDATBSKsFwGYhFvlggUfTGRH33BPVgItyLq9efF4bXVgDAAAAAAD+wVs+lTwnvkA9gimUkG/aKAAAAAAAAIDbImIDAAD//+zd0REAEAxEwZSmBdSJFv1ogRmZ3TqSd6IacNka06oXvyu1N0tPAAAAAACQ3HnuFYwnE/GFZIRSSMQtCQAAAAAAAMALEbEBAAD//+zcQQ0AIAwEwVrHD0klgDRcNGmZsXDfy4pqQA1nCLo7FgQAAAAAgC8sMzOJCMM4QilMcHOniBUAAAAAAABAhYh4AAAA///s3cERgDAIAEFKSwsktqm2YGl+UoMZyW4LPBkOUQ34wH1ej69e/F2OLqwBAAAAAADFzSNfey0qEWEoIo+0r6QKASsAAAAAYLkcvZkCALCFiHgBAAD//+zc0Q2AMAgFQEZrRyDpmtYVHM2YOIOm5W4E/uCFp1QDPnIes5s1i2sWZgAAAAAAKMGzL1tRxrC+HPnklLJKdnC9BVYAAAAAAH9zdwcAaoiIGwAA///s3EENADAIBEGk1VkNNcFiP2gggcxY4HusqAb0EtZgOoNDAAAAAABYrp59hTXY5FSUgbmu27FBvrQbAQAAAAAAAOgUER8AAP//7N3RCcAgDEXRrFi7UAfSZkURnEEwnLPC+w03ohpwUI5/HSD6OMLVnrcJawAAAAAAQHHZ87MxxYgyXGoHUURRqECwCgAAAAAAAOC0iJgAAAD//+zdQREAIQwEwUjDApxOwALS+KDhKFLdOjYTUQ342ezD1xFeV+rXjNYAAAAAACA/x79kUk6cgfcIopDBEqwCAAAAAAAAuCAiNgAAAP//7NzRCQAgCEBBVxTat0aLoB1EuVtB8Ed8ohpQQ1iD7rawBgAAAAAAzPaff48xM4g4QzO58u0hd0kmEKoCAAAAAAAAqBARFwAA///s3EERwCAMBMBIwwIzldkSC0jrtw4oYVfG5XJGNWCBfMZUQKQApUMAAAAAAKjPEzCVtH51Aw17cZOkgpl36ogAAAAA8CUv4g9k8ADAGSLiBQAA///s3EERgDAMBMBIAwkBBGEIKoHBGR9eFQDTzK6EyzPJKdWAn7TjnGXP4KZcl90QAQAAAACgrvcJ2GEnlVymOYbc0i6SKhRUAQAAANC7JQIAAB+JiAcAAP//7N1RCQAgEETBq6gGEvsIV9EfO4jHTI2Ft6Ia8JawBr+bbXRvXgAAAAAAUFjutGlRiljDNzzkUcG6gSoAAAAAAAAAXoiIAwAA///s3UENACAMA8BZJEEmMAlYQwZk3EnYd02rVAMuyrkse1GBMBsAAAAAANRnZZ9K/Lce13rbv9+AGnKkEh8AAAAAAACAmyLiAAAA///s3cERwCAIBEBKswUS24xp0bGKGNwtgeEHHEI14GPvM3z24u9a3pdFIAAAAAAAKMxRMNVkTz29qezZ1gzy9DpQgkAqAAAAAGBr7oEAgCNExAQAAP//7NxBEQAgCEVBKqqBqGY0L4RAZrcCR/48UQ3oQViD3+U627ANAAAAAABm89Nikqx4A/2kmzDAFaQCAAAAAAAAaCAiHgAAAP//7NxRDUAhDAPAWcfPg1l40ggJIsZyZ6GfbepUAwrIuf4zqJAFjzNuAwAAAACAxvJLnRbd6LeKuUcnzk7oYEgRAAAAAAAAoICI2AAAAP//7N1BFYAwDETBSKuFFp0UC0jrJR4IeTM+9q+oBhTx3NuzF3835rU87QAAAAAAQG9GwnQyMuJAHUIndPBmiAoAAAAAAACAr0XEAQAA///s3MkJwDAMBEC1qMT9pKGAWzQB//OVxUwbezjVgFoca3C6J+9L8RAAAAAAAJraI2FDYTpx4lBEjvwO/GWNHG++U/cDAAAAgD+yFqqQkwAA/UXEAgAA///s3LENACAIBEBGcwUTF3IgdUUbeztjyN0KVAT+lWrAR9aYnhDJwEINAAAAAACJCQuTTKmtKnL4gzsjGXRTBAAAAODm5IcAAIAXImIDAAD//+zcURWAQAgEQKJdBTwDGUglgtWM4cmbqbD8LeCpBiymrtsSIn83cm6HFAEAAAAAoDVHw3TySPNbuad+kRbqLLMMAAAAAAAAsJKIeAEAAP//7N1BAQAgCANAKqqBqO7HDgreNeDPNqUa8CbFGlSXY02LXgAAAAAA0NQJDVtRow2lDtfl5/fTg18PAAAAAKAcw7oAQHsRsQEAAP//7NxREQAgCERBqttHpQLRjCHD7FbgkzdnVAMaynNLhMgAwjcAAAAAAJhtuS+D+G19YtCEISp36jwAAAAAAAAAuomIBwAA///s3UENACB/jUlYAAAgAElEQVQMBMFKqwUSbAIW+aCBQDPj4/ZENeBRa0wPJvwu1SoBAAAAAKCuMx42IKYMcYf7Wm8paEIRQlMAAAAAAAAAL4qIzc4d0wAAwlAUrDQsAIIIzlkwwEKgubPQ7Sd9ohrwNmENfjdqb8UVAQAAAAAgLU/EZDJ25IF7BDXIYO7QFAAAAACcsCnxCls9AJBbRCwAAAD//+zdwQ0AIQgEQEq3oFNquM78WIEPo2SmBHgRwiJUAy6WffjuRQWGawAAAAAAKGodEQvWoBK7rUNWgIkQE56XXzZdBAAAAGDDr2gAAHBAREwAAAD//+zcwRHAIAgAQUozJaB1Rlv0YwuZicxuCzyBE9WAn1vvfMyIy7Uc3RERAAAAAAAU5ZmYYtqJPfA9ARMqEJYCAAAAAK6Xo9uNAAB1RcQGAAD//+zcQREAMAgDQZzXWqXxqYU+ktl1AQwnqgEZhDVIdwzYAAAAAABQzVMxTcQePnvhEvdD0l1hKQAAAACghJ09ANBrZhYAAP//7NxBDQAgDAPAScMwIAGk8ZkFEljuJGzftkY14AOzjy2ISAHChwAAAAAAUFSWirf/UkTL0QfuWW5LAXIcAAAAAAAAAK+LiAMAAP//7N1BEYBADAPASsNCAZlALSANFTwus2sjaWpUAxYx96OIyOq2PnZfegAAAAAAIJfjYpIYjP9Jny0zJME71+hwAAAAAAAp5CIAQK6q+gAAAP//7N1JEQAgDASwSsMCIAjrfOqA6YNOomMPoxrwF0FEfnfmXl69AAAAAACgoSwXKxjTxTD+UEYwlw7kNwAAAAB4kue7AABAtYi4AAAA///s3TERwDAMA0BTC7TwSWMKhdYlELpE909Bo3WyUQ24SD/7VcwggJIcAAAAAACE6tVDtgRx1/qZoRJCzDMkBQAAAAAQwxNdACBWVX0AAAD//+zcMQ3AMBAEwYdmCh8HZiRTdBMIbnyaAXHVaUU14DJ/idI5g5uNno+zHAAAAAAA5BKJJ4YIxDn99hAqIcH6ll0AAAAAABKJagAAmapqAwAA///s3EERADAMAjCc7aas1mdin3KJhPKlGNWAnRQR2W4sWAIAAAAAQCfPxpQxAvGPW9LgShEAAAAAKHUECwBUSvIAAAD//+zdSw2AUAwEwErDQpMnE6gEKg0RcIBmxsLeNv04qgE/VMfZDmswgKE5AAAAAACYy9IxY+TKS5rP5MrNhzsG6NqrBQkAAADAi/RNfIkeHwCYKSJuAAAA///s3cERwCAIBEBKswW1oTQUU0M682MFTh6R2S2BHwMcQjXgUM89Ls0zhyu1NwuIAAAAAACQ0Do6Nssii7JCIdgncJ8MPD8BAAAA4GuvivIntTfzEAAgn4iYAAAA///s3DkNADAMBEFDC/RAS2ME6e40w8KPVlQDsnnYIN0xcAMAAAAAQC23LJqIQnzaIImbIOnuBqMAAAAAAJrZ5wMAfWbmAQAA///s3MEBgCAMA8BuJuyrdAQczQ8L+KTcrZBnmxjVgI3lM17PiBQwhQgAAAAAAPWs8rECMlW0NQ7Bf+6BbC/v7FIEAAAAAA5wCRkAKCciPgAAAP//7N3BEYAwCARAWkTtxzQU02Iq8OET3K2AGb7HoVQDilvzGcKIVJfnIUgHAAAAAAANOUKmmdtCv8krR6V54YVnJwAAAADAXygYBwD6iYgNAAD//+zdwQ3AIAgFUEZzBXHNJq7gaF5coIcmlbw3AxwI5CNUA2pwwMHtWh9p8AYAAAAAgJrssqiiCYl4TRAJt1vzmfoeAAAAgE+cR7vwK32kugQAaomIDQAA///s3DERACAMA8D69wJIoNJYEMBK7t9C1iRONSDAGrOVEQmwhQgAAAAAAHnuGLlFSwgnEY8ckBBCFwMAAAAAAADgZ1V1AAAA///s3EENACAMBMFaBGySYAFpfBDAt2VGRnNdUQ0o4tYpjRFJrY0urAEAAAAAADV5SqYMsYhnAiRkt9dcdhgAAAAAwG/c9wGAWiLiAAAA///s3LEBwCAQAsAfzRXeuP8sNvbWkrsVaAGnGpBFGZHXjf7mkCIAAAAAAGQ5o2TDZFIok170amf6JNDBAAAAAAB+ybYHAIhSVRsAAP//7NzBCYAwEETRbTFgQxYUbSGlieA1RyEZ3itj9zNGNSDI3a8h6iCAwA4AAAAAADL5YxHDaMRcO9ob2opt2d35DUIBAAAAwN/8T1iROz8AkKOqHgAAAP//7N2xFYAwCAVARnMFzUBmoBhWtEnnBMG7EaDjfcBRDSgmn9l9+WJ3Z7uEEAEAAAAAoJi1nCwYShXHOh7B160m7C5Hdk0EAAAAAH7MrB8AqCMiXgAAAP//7NwxAQAgDASxSsMC4N8LCxMO+iQ2el9PNSCTGJHuxtxLhAgAAAAAAGGMlAkjKH3cRyPufHSnuQAAAAAAvmfXAwDEqKoDAAD//+zdwQ3AIAwEQZeWhiElQGl8kOgAJaeZEuynpbWoBgR6W/fliwTDFgEAAAAAIJI7FimeHZHgEBrh76YAFAAAAACXTQPno9xAAIAMVbUAAAD//+zd0Q2AUAgDQFZEHegtpK7oDzMYbe62IIWiVANC3ee1DNb8Xe+bYg0AAAAAAAgzx8pyLFIokRh99LJgSwDFTwAAAAC8ah7rwhfJQACADFX1AAAA///s3EkNACAMBMBKwwJgk6QWkManJmhmbOzhVAN6U/bgd2PupXgHAAAAAAD9yLHoYtSZBMq1/O/mSQMGAAAAAIBi0wMAtBARDwAA///s3DERACAMA8Bawy93lYA1FhYkEP4tZGwToxoQ7KxVekjkdUuCAAAAAACQ5ZSWFZdJ8f2YhGEREvTsIUgAAAAAgMv3NxAAIEBVbQAAAP//7N1RFQAhCARAolnhtJCFTisaQ+HNVOCPtyxKNaC4/a8pkEh23+iKNQAAAAAAoBjHy1SiVEKolvQ8LAEAAADgJvspXtVMBgBILyIOAAAA///s3AENACEMBMFKewsFZJJgEQNvoHTGxbXJimpAD8Y11X05hyEOAAAAAADv8cfiFW2jErlSIJ/yzj7dwzgAAAAAAL9yDvdTAKC2iLgAAAD//+zdQRHAMAgEQKS1EpiJzbYWKi0KYuDYtQDP41CqAQN8z/sLJBJAGA8AAAAAAMI4YiZJrx63z7368qWOALchAgAAAAAcjS0WBwBCVNUGAAD//+zcwRGAIAxFQVoECrIhNS1QmuMMPWhgt4Vcf56oBmwirvsdcA33JrPam7AGAAAAAACsxzMzqzhmZGInhrRkN+IMWwoAAAAAPjV/fuC3am8C2wBAXqWUBwAA///s3DERADAIA0Ck1Vqdd2HvHPi3wMRBolQDdrnmTbhjEQcAAAAAgFk6zCzQzBRrSia6QMTtjnT+KAAAAAAA/pRsAwC5quoBAAD//+zdMREAIAwDwErDGoIACSCNhZmd8m8hY3OpUQ34yGh9KYSQwBQiAAAAAACk44ZFFuWMTfxAgZbX1TPsBAAAAADAnSe5AMC7ImIDAAD//+zd0Q2AMAhAQVZEHagDqaxoTByi1LsV+KR9iGrAz9R1D5e+6C73TVgDAAAAAAAW8n1qtsNiFcvHJvLId+/s8Syt1VnDBAEAAACYiAA5sxPbBgB6iogHAAD//+zcwQ0AIAgEMEbTEUgc08QVncEn2K7Ai3CcUg34k0Wb6jRcAgAAAABAM2efaaY0MXJl91uW4CzVyU0AAAAAALzxxwMA1BQRFwAA///s3EERgFAIBUAqogYykEoEfzQzOF4UdxMwAyceg6ca8EO1H8OBCA2cmggAAAAAAO3IsOiibZaVS64vKAOeGLWVOQYAAAAAuCnnyW4VAPieiLgAAAD//+zc0Q2AMAgFQFbUDtSJ1BUcrWnSDfyheDcBCV/khadUA37que55xLz2z86OdirWAAAAAACAQtaTswyLEgqXT/QEM8AXCpwAAAAASGf9+UB2MgIAYD8RMQAAAP//7NxBAYAwDATBSCsS0iKzUAtIwwO/lBkL901WVAN+bF33YX+Kazl6MyIAAAAAAGzFszO72O6wNM8Uvae6Z80l3gQAAAAA8FGOLgADANQSES8AAAD//+zc0QkAIAhFUVcU3KfRWi2CNuhLOWcNfVdUAxDWoLstrAEAAAAAAHO8sbPBMyNk5ZjH0qy8Nzl3OboTbgIAAAAA+LPseACAViLiAAAA///s3VEVACAIA0Ca+wykVvSHEIJ3NcaGUQ343FnbUSIdtPvyBQAAAAAAn1N6pouRYxQdyOSobuZwEwAAAAC8Sj5CFTIDAKCOiLgAAAD//+zdwQ0AIQgEQErTEvTaNLFFY2IJfvBmSuDLsijVAHaxRjUFkivt6898+QIAAAAAgL87R8+Co7wifbD0FIP4Okdqc0w7ZQAAAACAO/Ydj70BAJBDRCwAAAD//+zdQREAIAgEwItmM6sZzY+GOGa3Ai8GOIRqAJ9gDdptDTkAAAAAAMzh+JlB1gulaObjHO3sRAAAAADQ4KgSRcwOAIAOSS4AAAD//+zdUQ3AMAgFQKTVWv1sxUKlLVkqopA7C3wR4CFUA/jlu7bmmwY05AAAAAAA0MtUT5ooO8c6gSDC7als55P2IQAAAAC43rntgSqG57gAQAkR8QEAAP//7N3RCcAwCEBBR+toGaiJI3S1UgjdIBDD3Qz+iPAU1QB+2YfPLFT3LeS+1gEAAAAAwCHyziYMzyGuGaeo6DGEFCfQBAAAAACwhhsCALC/iHgBAAD//+zdQQ0AIAwEwVokwQ+GSLCANP4o4MiMjbZbUQ3gJqxBuqF0CQAAAAAAX3EMzS/iFktbb4L2pNtrLnEmAAAAAJKYixDFc1wA4HlVdQAAAP//7N2xDcAwCARANs9CjlnBo7lxkwEsBXS3AuWLf6UawEe+c1n7ooHHEQEAAAAAoIfzDC2/ooWCJRVyN0rLkYZFAAAAAADuMo4LAPxbRGwAAAD//+zdQREAIAwDwUrDMGCRPxggnV0d6VVUA3jsuYxKSDeULgEAAAAAoA9H0TQSE6kIDIDAzUdPAAAAABIJjZNIpBsA+FdVHQAAAP//7N1REYAwDETBSMNCZ5BZiIVKQ0H/uc6ujsuLqAawY5hIOqVLAAAAAAA4i+NojpAQqxj3uAxgCbd6tjAMAAAAAHH6eUU1SOQ5LgDwX1X1AQAA///s3bENADAIA7D8fzULYw9okP0FCgSlGsDTDuEGcdpZ9AMAAAAAgCMcR3NIQ4YlZ6OdIiYAAAAAmrnnoZHnuADAn5IMAAAA///s3MENgEAIBEBaswSSK1OlBLUzYwH+j8tMB8ATWKEawK86zk13aE7SJQAAAAAArMX+iiXkyGvWOnLkd/Dq6JXO7trL0wEAAAAAnT2mR1NCuwGA+UTECwAA///s3TERADAIA0Ck1Vqds7B3LHD/FliTYFQDeBFMZDpLlwAAAAAAsESVpBWl2eDUeEVHAq9Md10QAAAAAOALz3EBgH4iIgEAAP//7N2xEQAgCAAxVncgcUUba2vgkjWAR1QD+Do7LSYygcU/AAAAAACYw7E0U5SbYb3Qh2A9na0XYAIAAACAts5OUQI68xwXAKglIi4AAAD//+zcsQ3AIAwEQI+W7AvxCKxG454ygO5GsNy9/o1qAEvZv9eVOJylSwAAAAAAuESVpRWmucFTIxY7GT6Lk2VLuTAAAAAAwP/kDQDAPiJiAgAA///s3NEJwDAIQEFXtM0+ofsUsmJWyGeUuw3EP4UnqgGcEtagOqVLAAAAAABoYv3L74ou5i1z5EgxAqr7bBAAAACARty7KC3fR1gDALhDRGwAAAD//+zdQQ0AIAwEwUpDMFALSMMCCZ9CZmz0shXVAI7kmD5+8YMyo0QAAAAAAOCaMSk/aIViFm5pvGxlT2EYAAAAAIA6mrAGAFBCRGwAAAD//+zd0Q0AEAxAwY5mYawoEgOIHzR3K/iS6iOqAWzrtfnxi9/NC7mHVAAAAAAAkMBanhaFJ4PrMYuHwh5wSmgJAAAAgGzMQMhg7vEUJwkAXBURAwAA///s3FENgDAMRdFKw8IS/MwQrBKYNDQQPgbNOS7a5F1RDeApYQ3+rjvIAQAAAACgDCNqSlgZtWh7274Q9oAXZh5pYAAAAABAKXkOPy+quOx4AIClIuIGAAD//+zdyQ0AMAgDMPafpRIr9sMCfVVE9hZROBzVAJ5MKBfM2c5QIAAAAAAABJglat0VCX72V7ozVuvTnoMAAAAAkEoHQgqHNQCAf6rqAgAA///s3dEJgDAMBcCO5grRLuRA6gjiZqIbFKTScLdBmo985JE6qgE0O7ZdIIXRTbHMv/32BQAAAAAAfGr1nGQQNc7eZUSNJ8AqxMrIzAAAAAAAMrt0l0S670EAAF6llBsAAP//7N1BDcAwCEBRpM3COkE11AQLlbbLFOzQBPKeBbjyEdUA/hLWoLqpcgkAAAAAAPXlyu2omiauL3Jx0rQ8VJYrPVMAAAAAoLNtunRyP0NYAwA4LyJeAAAA///s3UENACAMA8BJwzBgAWl8UMCDhObOxbK1U6oBXJl9LMM5ARwJAgAAAABAAKFqgjzbX50CDyX0/MwzEAAAAACinewOJGmKNQCA56pqAwAA///s3FENwDAIBUCkzVr9dMVCpTVLpmAfTcruLPAFeTylGsBneQ8BFU73LONCtgAAAAAAUEMzRwq43rKLHRTQc7KZPT0UAAAAAPAH7mBUo1gDANgrIhYAAAD//+zd0QmAMAxAwawYdR8dqNAZullxBlFIvVsh9CvhVVQDeEpYg+rO3Dc/cAEAAAAAQHG99cthKYt4PXaRR97vxY6MyoSUAAAAAPiLYdIsSFgDAPhOREwAAAD//+zcUQ3AMAhAQaRV8FosVNp+5qBhS9idCwg8UQ3gSM61HSfSgEEcAAAAAAB68GRNB+OJXlQqD3dAoZ1XulMAAAAA4Bdyrup9MXxFWAMAeEdE3AAAAP//7NzRCQAgCEBBV2vfyhX7aYMwKO5G8E/QJ6oBHMsxmynyOos4AAAAAAC8bz9Ze7TmB2XRiwvBDiiVPd0oAAAAAAD8QVgDAKgXEQsAAP//7NxRDQAgCAVAolnN5s4OwgbeRYAvGDyhGsArjlbo7g7iSxcBAAAAAKA3z9ZMkRh+kRbYAQW2IgMAAADwIXsxJhOsAQDkiogDAAD//+zdgQmAQAhAUVcUGrNyhdvsoh3uiOS9LUT5imoAS9R1+/pFB4ZwAAAAAADowXEpHSyPX+SR9mH82aizdsVmAAAAAAD4zhvWmJ7lAgBbRMQDAAD//+zdUQ0AIAhAQSq6WVONYDVnB37QuxrAQ1QDSLPG9PWL8tQtAQAAAACgPkfXvCIzgtF6u4uollGpTDAJAAAAgC+tMc09+MUW1gAA0kXEAQAA///s3EENACAIQFGi2cxCblQwmhcjcBHfq4AXcPuiGkA1YQ1eNyzgAAAAAADQgn8rOhg3hlFhehE8bOfKbYAAAAAAfMx9jF8IawAAtSLiAAAA///s3cENwCAMA8Dsvwt0BboZqsQGREIldyPkbTtGNYBUT+vDdxgukPbxCwAAAAAAOGOVrwVMucH2GMYa5hBA5c/kEAAAAACo7q1+AEr5hjV0ewCAHBExAQAA///s3FENwCAMRdFKQ9oQNGaRnzooyQKc46JJ3xXVAJb73vF4UGR3jm8AAAAAADiCETYnaBnFqCiHOeBHPUNJAAAAAHCt3OrATZptDwCwRERMAAAA///s3dEJwCAMQMGsKDhmwRErgU6g9CN6t0UwLzqqAfzFgiLV5fDtty4AAAAAACjsi7CF2Jxg+ShG6y0Xrb17UdZ4hlgAAAAAAOBO2fa8+h4AYEtETAAAAP//7NzRDUBQDEDRjsYID2OiIzCaT/9NJDznrNCkX+0V1QAekdt+CmvQAUVLAAAAAAD4uFxzNEM6MLSlVQ9Gy0EOeAE7HAAAAABu/nT4q6PNkwAzAFATERcAAAD//+zdwRFAAAwEwLQY9ENBSAtK8/RmxiPslpFcLko1gNfUti8+f9FdjoNiDQAAAAAA6E/IlC+4vbfKKQVM6eyotWQOAAAAAOBiXsafzW58AIBHIuIEAAD//+zdsQ2AMAwEQI/GCsBALETwiEF0tERCIuRuBZd+v5VqAG8TUKR307wurV+/AAAAAACAD8g9lcHzCw0lGZvJ0zF5AwAAAAC4yXLYdTC668anuvMBAB6JiBMAAP//7NyxDYAwEATBa/GBMpFcgimNhIzECcGjmS6sfZ9RDeBTz4PdoQvdWbIEAAAAAID+NCv+YHkko47SuOjsGufwQQAAAAAA3vQOSGbtmw4CAKxJcgMAAP//7N2xDYAwDATAjAYjOGEgBgIyIghBiaCisHS3gZXKejnvUw3gd33dNH+RnmUbAAAAAAByu4+zZVakF1PMXzPEFGdDm5Y20upLH70eAAAAADySdcBliFb3aFUeAgC8K6UcAAAA///s3cEJwCAMQNGM5mZOpI7Q1bx46aE5CinvrRAQQuArqgHcooRJdc2iDQAAAAAA5blZ8Qf9RDMy3aQpzFsNAAAAAB/WmKIa8Pb4SBcASEXEBgAA///s3c0JgDAMBtCsqC7UgQoZsVLoRUSPQuS9FXLKD1+EagCfWE27wxeq02QDAAAAAEBh2dPOir94DM1YgRvC4ikrezbVAwAAAIBXdh1wNR/pju3YzZcBgLuIOAEAAP//7NzBCYAwEEXBLS2WoCnIitQWJRDwEvEWWJlpYU97+E9UA5jmOs72mChikpp6JQAAAAAA5GaszU+UHs8YeQ1uQAKLIwEAAADAJ9scGNvb7metm/g4APCIiBsAAP//7NzBCYAwEEXBLc0WApapbglaWsjFi0huwspMF8lnn6gG8DU1TKpbPK4BAAAAAKA8mxV/8IhntLWNaIwti6qu3NIxAAAAAABM5H74R4N3Yyc5xTUAgFtEdAAAAP//7N3BCYAwDAXQjOYKhQ7UgYSO4Gpe2ouCeCpE3xuhOaV8fpRqAEuNxV1IkewOEwQAAAAAgLz63psrbnzAVmq5hkFvRRuQiCwBAAAAALznPw2ezXKN5p0A4Oci4gQAAP//7NyxDYAwDEVBr2hgH8Q+AY8IoqFOhRS4WyFd/PSNagCvq/0QKTK8e7HSKwIAAAAAwNDEpnzBc7PKJUWhjGyrVjoCAAAAAOjnPw36rDlPp3ENAPixiLgAAAD//+zdsQ2AMAwEQI+WFUgGYiHAK6ahQHSpkMXdCi79fivVAL4ipEh1bRv9/fkLAAAAAAAo4j7eFjilvEeZxm6aVJVHCjMDAAAAwII8LzsOWKNcAwD+KiImAAAA///s3LENQCEIQEFWc7K/kIkjuNpvLGy1MejdClQQ8kQ1gCPG8i6sQXbdBAEAAAAAIK9WWzE+LvBNYQ3IyO8AAAAAAOxxW4N14hoA8JqI+AEAAP//7N1BEYAwDATAWKQIooJaYgFpeOiHSdm1kO/dxagG8Jmcd/f9i+qOsxnWAAAAAACA2gRO2cHlihT15EjBZQAAAABYo5MD64xrAMBfRMQLAAD//+zcwREAEBADwCtNC6gTLfopgIdhdlvIN4lTDeA2JUVel3ItSYoAAAAAAPAmY26Aq3QGAAAAAGDTaN2pBpxb5xr2QQDwqYiYAAAA///s3MEJwCAQBMBrLSXEFJSGApagpUkgHSgRZaaFfR3snqcawFTfAa8kw+qKBAEAAAAAYGmH+AB+V/OTlf4BAAAAoI9NDoxxv/ug80rFcw0A2ExENAAAAP//7N3BCcAgDAXQjNaBrVlRBA+9WxTlvRVCDmLyI1QD2C7f2q9/GZThaP3RrIIAAAAAAHCmsdTtvwpgoSwp0AgAAAAAJo2dHOA/zydcQ38BwA0iogEAAP//7NzRCQAgCEBBR2uFbKBGL9ohIuFuBD8CkZ6oBvALZUyqa5ZlAAAAAAAozb0K4B1vLgAAAADcIxwO9524xuwj1/kv1Ec2MwaAoiJiAwAA///s3VENgDAMBNBaHAiaoUElbDjDBJCNvCehf00ud0o1gCnkcQ6hGX6gepIBAAAAAGBN2XIInQJ8I1saLAAAAACA51xuCa+qEdHLvnWDvACwoIi4AQAA///s3dEJwCAMBcCM1k6mA7VmxJaCI1RQuVvhQb6SPE81gGnk3apFRTZQhAgAAAAAAGvKK0/RAQxn1gIAAADAj/o9DjDe0Qt5n++5hmJeAFhERLwAAAD//+zdUQkAIBAD0ItmNfsIRtBoYgcVD96rsM/BZlQD+E2VCMkVq5MAAAAAAJCavgrgntlbd7YBAAAAAOfpN+Ctfco7DGwAQAIRsQAAAP//7NzBDQAhCARAOr+GVFqwNOPTAsypmWmB1wZYpRrAUbK2LsjzgE8YBgAAAACAO2XJWZ7t4RtgD/cAAAAAALCH3Qb8ZynYMAcAOExEDAAAAP//7N3BEcAgCARAOrehKCXE0vxYgo4ms9sCP+Y4lGoA18naBBX5g2KKAAAAAADwWY6+Adbr+aQsAAAAAABsMJ/c2r/BeWWWa7wKNgDgEhExAAAA///s3NEJgDAMBcCMFkdoXciBCp3BzUTwwwEstnAHWSD5CiRPqAYwK4eKrC4tvwAAAAAAsKbn6dvhKcCHeuubfgIAAADAUKf2wjTyFbBx11H2msYDAD+IiAsAAP//7N1RCQAgDEXR19xEagSr+WMERYVzQgzG4E5UA3jSKmQKa/C7YuEFAAAAAIBvuVUB7GOmAgAAAMBhvTaPQeFdJckQ2ACAC5JMAAAA///s3bsJACAMBcBs7kJCVnA0ESwcQEXhrskAVvnwFKoBPGs2834A43fFCwIAAAAAwH+yphB4gD1a1nTMDwAAAAB32G3A+9aAjVHN0AHgpIjoAAAA///s3dEJACAIBUBHc4VqoUaPoBEiEu7ACfwS8SlUA/idYZ7q0nALAAAAAAA1OQIHuMLeHwAAAADe8dwWauK2YcgAACAASURBVMkdsnECNnbNNnrqIQBcFBGLnTs6ARCGgQB6qzlZF1IzQh1NhE4gIi28t0K+LiSnVAOYWh3nE+Y3U2JxTaAFAAAAAIBleQYHeO+qvRzxAwAAAMBPxh+OnRysqyXpo2CjK9kAgA8kuQEAAP//7NzRCQAgCEBBR2uzGihwxXaIiJK7FfxS4YlqAM+z0FNEN0gAAAAAAPhPzhx+VQDbhIkAAAAA4D53OaihiWwAwAERsQAAAP//7N3BDcAgDAPAjFZGY59CVkQdoTyQgu5W8CuS5RjVAErIMZukKO75DlchAgAAAABAScqnAP/1fNMoEQAAAAAc5rktXMvIBgDsiIgFAAD//+zdsQ0AIAgEQDZ3IRNmcDMbCxsLK4O5G4EOAo9QDaASwRpU1zSqAAAAAABQzzoKt3wKcCF7ejoAAAAAAO8MtYfvnUI2zOcBYBcREwAA///s3bERwCAIQFE2d6FERoxN6O089b0VuKPjI6oBbEMpk0M0gwQAAAAAgP3kkwLwAPPsTAAAAABYKN/uqB7uU5GN9kc2vopseBIMwNUiYgAAAP//7N3BDYAwCAVQRnMz031URmhH66WePRrS9xIWgCPkI1QDKCXvx+EN1R0SHwEAAAAAoKxmdACfRl7pYQYAAAAA/M9eAzhX9RWy0d+gje07A8A+ImICAAD//+zcsRHAIAwEQZXmzmjIoBZJcELiFDG7bfzPiWoAFQlrUF1TeAQAAAAAgHryTecygH+O+gAAAABwgOzDrgHsni+0sSIbQhsA3C8iJgAAAP//7N3BDYAgDABAHg7mCuBE7qMygriZIYGf/sXcrdCEtCVtJ2EGRpP3o8QllZbEw6hqAeo6EwAAAAAAjKcugD/FDeBRyVv2DwoAAAAA37G2+QWAN3Of04tL6u9F7fVfwYIeAP4ghHADAAD//+zcsQ3AIAwAQY8WRkDKmAFWyGgRUUoqqli6G8GuXPhFNYCURutllvBsj8SOWXB0WAIAAAAAQC7zWbyeVQAeYGFco5gLAAAAAPzKLaoBbFiFNuIL9cQb2W5dZBuAHCLiAQAA///s3bEJACEMBdCseOdAh6PdZhLEytbCwHsDWFgERP6PUg2gMlvAqO572usRCQAAAAAA9XSlGgCb7koAAAAA4C6ZV8jcgn8N4JBVsJGZqHVizpg/5syxfBiA+0TEAAAA///s3NEJgDAMBcCM5gpV9+lChazgaP6odIGilbsF8hd4JDylGsC0BHt+ol7hEQAAAAAAmES2PMpe3KkAOtnSoywAAAAAfJOycGCk5d4xZVtrN+cp41a2AcCrIuIEAAD//+zd0QmAMAwFwI5mR0jrQA6kZkT9ELpCLdyNkHw9Ai9KNYCl5XXX6O2xRRa2RW+HcAgAAAAAAGvJM2vs4U4F8KnmAAAAAAD/5KktMMko2FC2AcBUpZQXAAD//+zcsQ3AIAwEQG8esU8kRiBshlxESpMuBYS7zrW7t/VKNYA/yOecZpMs7MiAKoMqSwQAAAAAgKWU5zMYwKauela3TgAAAACYW1GqAUzirWwjbw39HhRuAPCZiBgAAAD//+zdwQmAMAwF0GymKxTcR7uP0BV78VC8eWvseyPkEAghP0I1gPQkZvIT5zP8AQAAAAAASbS7XeUomz0VsLi6egEAAAAAYHZub4AE9rFHvQI3xl2Ex8YAfBMRHQAA///s3bEVgCAMQMGMpiMAA4n7qIyoLZV99G6DPMrkfUQ1gE8Y57WWVm+vSWJLabWrKAIAAAAAQDp+dgP+bB/HcLgKAAAAADnYaQBZzYGNrbQ6jyG4AcC7iHgAAAD//+zdsQnAMAwEwF8tIxgyZsAjhGwWVKTMALLvOtcGgzCvt1QDWMmR5HajNFZDneENAAAAAAAaqTD5OIdmN2BL85pKAwAAAACgicoqVGbBnwawmL+FG/XePd9BETLAxpK8AAAA///s3dEJACAIBUDbrBWqido8+nOF8m6FB4IIT6UawDcs93ziFsM0YQIAAAAAwFN8dgMq2lIHAAAAgOe4aQBV9Dzvxpq5fEPhBkAlEXEAAAD//+zdsQ2AMAwEwKzGCCEsxD6ARyCbgUKFKOgT3Y1gW66st1ANYCixH1Mu86Wr9CyX+WyzrIkAAAAAANCH2KLmJa+fL0gAI6uxhQNTAAAAAOiMh7YAj7/AjXeoeG17U8kAOpdSugEAAP//7NyxDcAgDABBj8YKhuwTMVlWi+hoMoDDXe3OFUJ+UQ3gj1aM4LFZCms5evPoAgAAAACAOtZxeV4pqgGcYto0AAAAAJQ1RTUAPu1/vneOvs8JbgBUFBEvAAAA///s3EEOQDAQBdA6Ii7EfVSvwMlIEzYSC4kI9d5uttPdzPQL1QCKIzWTQuRgmMpjAgDA/eq2WbQVgKekOJrxAPxLfziyAijRlIbkSBQAAAAAPmr7d2OnAXDdWeBG3pvMe5Hi2OktwIuEEFYAAAD//+zcwQmAMAwF0G6mjtDqQA5UzQiuJr2JZ0Fa3lshIZdPvlINYEhxnIsnKXqX13K1XTZIAAAAAADoQ9TY85Yn5e/AyKKGDBMAAAAAOtcevvNalGoAfGN+ZsSv+6pwA+BvKaUbAAD//+zcuRHAIAxFQZVGC9gVURmUxihz5IwAzW4LP+N4ohpAZfmQZ1qYi7X+Pi0rsEYEAAAAAIBrDFENoLBhXAAAAAAoI8/7hDUAzvoLbnzvXZY/ZACHRMQGAAD//+zdwQmAMAwF0Dpi1H10IDUrdDTprXgWwfLeAj0EQqDtj1ANYFhtiIxlrh4t8nMtGGZSRAAAAAAA+Ic8ssYa7qiAIeWRtqcBAAAAwCDyvPbH524AvtX34C2WuT9c4AbAW0opNwAAAP//7N2xDYAwDATArJYRHBgTyAiIyUCRoES0JLrrXL87S2+lGsDQ6rrlmMopZXoWU9nbLgsRAAAAAAD6UJeaYw43KmA0bpYAAAAAMJ58PwMF4F/eCjdaucbxDK0gSW4AH1JKFwAAAP//7NzRCcAgDAVAR8sKxom6T8EVOlrxT0oXSHu3giAkT59SDeAPDPhUF31kaBQEAAAAAIBSjsdDJ4DKrnlOeSUAAAAAfMz6p9BHrt1fOFuAEmK/s/vIPZNWuAHwprV2AwAA///s3bENgDAMBEAzYiQGIvsgZQVGi9JR0fO5W+Ery/JbqQYQz4BPiFUMcwgTAAAAAAD+YdzjamdTqgGk6JIEAAAAgFjdzQ1AhK/Cjfeu5/H8GdhKVU0AAAD//+zd0Q2AIAwFQFZjBGAgF1IZQTfTmPjBCoW7DZrXz+ZVqQawhH6cubT6SJvISqvXt8tCBAAAAACAMPJfnA0Q2d337rASAAAAACblmS3AEsaCja20Os6scAOYW0rpBQAA///s3bEVgDAIBUBGywpRB3IglRnczJfC0gEwdx1tOh7wI1QDmImlRaprfV2axgQAAAAAAGoYR+h965ZQgdLySMH/AAAAAPBzPrMFmNpX4MaYdd9vkee1z/5QQFER8QAAAP//7NyxDcAwCARAsplXcDwRm1vurGxAuFvhC4oXb1QDaMNyJj9xhmEeYQIAAAAAQBmpnwIKS+EBAAAAQBv5eawGoLdxd91zvfeNMLgB1BERGwAA///s3bsRgCAQQEE6s4YDy3TmSpDSHDIjx8wPuyXAZcBDVAOYinImfxCt7mOWbSYAAAAAALxfbtljDeF34It6bukCJAAAAABMYjyIjlYXZxoA3HAV3DhH2/v4LN2CAo8qpRwAAAD//+zcsQnAIBBAUUczI6jZJ7hPwBFCNgsWQvpAQHyvuv6qK+6LagAr6jGCy+aZWEwlRwcFAAAAAADMoZ1tS3sSfgdmU20MAAAAAJZTRTUA+Ogd2DhSyWPuv3D3mP3GAb8JITwAAAD//+zdwQ2AIAwF0LqZK4ATuQ8JKzAa4Wa8SyS8t0IP7aH9FaoBbGcMW+nKvoGxuhEMc6giAAAAAAAs434tDwH8WaulWmQEAAAAgM24uQHgQ+ejvwjbAOaJiA4AAP//7NzRCYAwDAXAbiaOEHUg3UftCI5mKbiCYundCi8/IeQp1QC6lI9zjHm6LPm0rM5wnWUhAgAAAADA/+U9r7HE4D4FNGITFAAAAAD06fm5ucUPwEeUbQDvSikVAAAA///s3NENgDAIBcCO1hXUgbT7qKxonKCfDeFuBPgijzylGkBlw9MiyfXt2LuDAAAAAAAA0pBPARmMuEMGCQAAAAC1/ZnGWX0IACw1LduI572sCJhqrX0AAAD//+zdwQmAMBAEwLMya7jEhuxHSAlamgREtIOIM58rIK+Q241SDeC3ehFB1uKSz9ftETE5RQAAAAAAGF8PqeeSh2INYGRta5YPAQAAAODnekg5a5m9aQAwoLtsI2t5ZkPXax4+sQZeIuIEAAD//+zcQQ2AMBAEwLWGhLaCCIIKErDG6zxQmFFwyb02m6xRDeDXhHy+oI1+X/PcPBMAAAAAAJZw6KaAF9M7AgAAAABFpwHASmpgY2+j19mGNoAkyQMAAP//7NvRCYAwDAXA4GSu0HYgHUjoCHYz/QmdweIdvAXyEUJCNmUAmIMRrGovrVpUAQAAAADAAvrVh/sU8FEjexQAAAAAQOTzsZsGACs7Mndp9cmcGf948BcR8QIAAP//7NxJDQAgEAPAlY4gYCVgjfDEAceMhb6aJnWqAXxPyecRQ5AAAAAAAHCHrFlEBRzIbg4AAAAAbLL1tWk44wXgJY424DcRMQEAAP//7NzBDQAhCABBWlTbNLEEr7R7+TEWoGSmBV6EsKIaAJZ8kiitCmsAAAAAAMA7PK8DN/lGH27mAAAAAMCJmwYA2e2hjblCGyYPCUTEDwAA///s3LERgDAMBEGVZvq1UQvuDBJ7SCgADbstKFLwJ6oB8PDkU11TwwMAAAAAgBqyp+g78BnZ83ANAAAAAOBNjnPa3ADwM22HNlZk49qRDfs9KCgibgAAAP//7Ny5DQAxCARAOndFZ5dAa5fg1LGfGYkGCBAIaYVqABRHPpdIizkAAAAAABzDbwrYgVkEAAAAACyNrwsLB+B1rSorZCNn0MbrjYHtRcQPAAD//+zcwQ2AMAhAUUZzMxciYYVuZi81euxNYt5bgROBfFENgBdLPj9xGiQAAAAAAPRXWcNtCvhaZXn0AwAAAAB2CPQCwOO4QxsrsnGJbEBTETEBAAD//+zcwQkAIQwEwJSm/app4Uq7AgTxp8JMC4GwyWOVagDMHPm8rgjfAAAAAADwhmxZjQo4yA4CAAAAALZkH5+fIgAsKdmAG0XEDwAA///s3MEJACAIBVBHa+CgFRwtgk6dvFXw3gh2UcMvVAPgsId8wRr8bjXfzSsCAAAAAMAX/E0BN+ToI1UeAAAAAKjaNzf2igBQI2QDXhAREwAA///s3MENwCAIQFFW62Q6UJEVXaCXetGY90aAEwn5ohoAHypHd+RzgWaJAAAAAABwvnrL0wywg6APAAAAAPBb5XhMDQCWiGzADhExAQAA///s3cEJADAIA0BH62rdp+CKnaAfC4JwN0XAEI1qALwpEDHdEqoBAAAAAGAMBVSg086THk0AAAAAAFXuGgDwz8gGdIiICwAA///s3LENgCAQhtEbjYGVG0FGIyYUNjYYDTHvrUBDcd9vVAPgRu61GdbgB85PdfGQAAAAAACwthG3C9yBT+SWjvEAAAAAgGmaGwB4xXVk4xgjG9pAeCoiOgAAAP//7NzBCYAwEATAK83OkoY0JdiaBO7twxAhYaaFg3vtrlENgBftvKrwIhsojggAAAAAAEsQPgX+4NcAAAAAAMN0bgBgqiN7gXeObPSBDcP58EVEPAAAAP//7NzBCYAwEATAKy1WZkPRayGliaBvfSRiYKaEfR3cskY1AJ4pFDG74mAGAAAAAID/y5pN+RQYrGVNv0MAAAAAoIvc9kWSAPCJc2BjvQY27pGNInp4ISIOAAAA///s3MENgCAQRcHtnIbELUFKI9y8EC5KjJmpYpO/eaIaAAtZzyaswQ8URzIAAAAAAHxfHun5FHiT7RsAAAAAeJptAwD2G5GN6xbYENaHmYjoAAAA///s3bENgDAMBEBvHgZK8AgwWhQpFRUFEQLdreDS+n+lGgA3ZNs3q2D8QHFEAAAAAAD4BKF3YIUza/p7AwAAAACPMmYLAK8rc5R7FGwcCjbgIiI6AAAA///s3bENgDAMBECP5hUgC2WgSF4R0aWkCFIQd5IncGM3/0I1AJ7z4PN16SAGAAAAAID91SiB78ByNUpbJAAAAADwCmW2ALCNnAI27ulHO9N6+LWIuAAAAP//7NzBCQAhEATBydyI9EIwNVPwoXBqVRDLwkCLagBMUs7kEsUTDAAAAAAAR7BLASu5KQAAAADAVl9twr4A8D8lSRfY4GlJBgAAAP//7NxRCQAgDEXRNddAg1UwmhkEEdFzImyfD66oBsAC5Uwe0TwSAAAAAADuVlnDLgXsUlndMQEAAACAA4Q1AOBeAhv8KSImAAAA///s3dEJACAIBUBHa+FqhUaLRggiku5W8EdUnkI1APb54EN2ZTW9qggAAAAAAM+zlwJOcMQOAAAAAFzRaxtmkgCQgoAN/hEREwAA///s3FsJACAMAMA1t5CwCkbzZwVEEJW7EGNvTzUAFlWBb4GR1zWJLgAAAAAA3C17mksBu0bFEgAAAACAI+ruRl8SAN7hwQZ/i4gJAAD//+zcwQ3AIAwEQbeWynBBAbdID4mEAM20cC8/vKIaAB9UH+nA5wLNiAAAAAAAsLd6K00E/CDMAwAAAAAsV308/m4A4EgCG9wnIiYAAAD//+zcsQkAIAwEwIzmwEJWcDSxtE2jgbsVvgnkeaMaAHXKR3Q3zmErRQAAAAAA+J6/FFCxcqbSOgAAAADwhGENAGjvGtgQJ21FxAYAAP//7NwxFYAwEETBs4ayICiwEkAaDQaggeTNSLh674tqALyUbT8NGJlAU4sDAAAAAIB/S89qdAo8lZ7F0QAAAACAj/m7AYA5tDuucQhsMJyqugAAAP//7N2xCQAgDATAjOZmTqSuaGNlJxYGuVshkOr5V6oBcGG0LsDID6orAgAAAABAekKnwAk/AwAAAAB4bg3aKgAGgH+UrWDD4Df5RcQEAAD//+zc0QnAIBBEwSvN0ixIuBJiaSFgAYI/F5lpY5cnqgFwzhmJv2vqcAAAAAAAUFuOnGLvwKaZI+1/AAAAAEAJwhoAcK0vqPGswEYX2KCsiHgBAAD//+zd0QkAIAhAQTd3ocARWq2fBgj6sbibwlBeohoAl/bjXliD16WhFQAAAAAAeqtRDk6BE/bXAAAAAEArwhoA8L3cgY3pA3DaiYgFAAD//+zdsQ2AMAwEQI+WzWCggFdgMxBS6lQprOhuBXe2/C9UA2CBvO5TMxgbOAwRAAAAAADK8ywPzDzZ0+0aAAAAAChnBGvYXwLA3tooAH//cA1F4JQQER8AAAD//+zdwQmAMBBFwS3NFoxtaraEtCaBnD0JRjJTxsJ/K6oB8JK8qmImf7epwAEAAAAAwNzyTLd84InwDgAAAAAwrbG9EdYAgDX0J+BtP0qzW+RTEXEDAAD//+zcwQkAIQxFwZS2nS32s5ASVwSPHkUUZ9pI/hPVAJhLWIPTvepvAAAAAACwPTcpYKTkl57RAQAAAICtCWsAwHWevlv8W1zDfpHlIqICAAD//+zdsQ2AMAwEQK8YGIiFAI8QRosi0dAjFOBuBVeW9W+lGgA3ym0/LPZ8wGKIAAAAAAAwrjM07yYFXOSavjsBAAAAAK+gWAMAfqtnF2uZp6pcg8dERAMAAP//7N3BCYBADATAlJYWPCuyco+DPK4ABYMzLSyE5LNRqgHwsDrsobNcS6kEAQAAAADg0y7xABszAQAAAABoRbEGAPxaVrnGfZzD8wDeFRETAAD//+zcUQkAIBBEwY1mMwsJV8Fo/mgEQWEmx+4T1QC4Q1iD3zWlNwAAAAAAeFeNmoamwDZrlKEZAAAAAPAdYQ0AIEk/cQ2fRq5IsgAAAP//7NzRDYAwCAVAVlQHMu5jywhdzbBDTay5GwH+XuAp1QB4QbbuiJE/GLYIAAAAAADflXcqegfKZQoAAAAAwMJknABAOeuncTv2oVyDqSLiAQAA///s3cEJACAMBLCO5sCCKziaCHUDBcVkhX76aO+EagAckmmZ8LS5gJogAAAAAABczaEp/K232hQ+AAAAAADPymJbPzgAwFKEa7BVRAwAAAD//+zcwQnAMAgFUEfrCkkXykABR0zpobeeCoGEvjeCXhTxC9UAmMtSz+4OgycAAAAAAKwre7b7qV6L4J+yp5s0AAAAALA9wRoAwIsnXGOUszYF4rOIuAAAAP//7Ny7CQAgEAPQbC5O5mo21haC4Oe9FcIVgSNGNQA2GqXeEyO3axIEAAAAAICjVfHAl9w+AAAAAPAMwxoAwEQxrsGyJB0AAP//7NzBDYAgFETB3yLaJrotWoLxQCIw08UmmyeqATBYrtugZ3rtPIQ1AAAAAADgp9Ij9A4bSo/DGAAAAACwFGENAOCFuAbfVdUDAAD//+zcSw0AIAxEwUqrBUARzrHQE+EzY2FPTZMnqgGwh4Oe22UbPa0IAAAAAADHmqaBr/hBAwAAAABPEtYAAArENaiLiAUAAP//7N27DQAgCEBB9p/FxBFkNBt7rYyfuxUIBc1DVANgg3HQ+w7G7ZoJAgAAAADAmWqpKawB38ix8wAAAAAATxLWAAAWiWswFxEdAAD//+zcsQ3AIBAEwW8RaBPzLboCAhJk8EwXJ51WVANgk3yGMc/xSqvCGgAAAAAA8FHZ00kE/kFABwAAAAC4nrAGALBAXIO5iHgBAAD//+zcuw2AUAwDQLPZWwGYiH2ArMBoiJqGCvG5W8FVLMVGNQDu5Zjn7Vo/Dk2KAAAAAADwWJ7t4dummmuTMQAAAADwB8ewRi1rl0QvCgBcYVyDsyQ7AAAA///s3LENgDAMBECvxmYMFPAIrEZjKXWaKJC7FSwXr5feqAbARLWSKcjzdY8LAgAAAADAmrLlqY+C/6ofBwAAAADYSl73of8AAAYY16CLiBcAAP//7Nw5EQAgEATBtQgowjkJCggonm4LVxdsMqIaAJvNIQ9XK60KawAAAAAAwLm628CT/DYAAAAA8C1hDQBggbgGSZIBAAD//+zcQRHAIAxFwUjDQotNZmIBaT1hgAtQdi3k+vNENQDWENbgdOWpb3FFAAAAAADYT7bsRqXwOz1bGnoBAAAAAFcT1gAAJo24hp/IG0XEBwAA///s3EERwCAQBMGzSKIIP0lOwllDBI9Q0G1hv1sjqgHwg3w/R0Z2UFYEAAAAAIA15ZMi77CXbk8AAAAAAGENAGBKtfsqcY3DRMQAAAD//+zcyQ0AIAgEQEqzYBNbsDRjQgV+vGZa4AOBxVMNgE1yiIerzQZSBQEAAAAA4FhC+PCG3mpzIA4AAAAAkDKTYw8CAKwonmt8JiIGAAAA///s3KERACEMBMCURmkUBKRFFAaL+IfZbSEm4u6MagB8y7AGtyseRwAAAAAA+KdsWZ0GniAYDgAAAACwyT6qXg4AcGCNa8hWvC4iJgAAAP//7N2xDYAwDARArxgYCLEP4BEYLQiJko4iCbpbweXbfk81ABrK/bjbhDQKMbrTBAEAAAAAoFuWSWFsa24pUwYAAAAAePHc5chCAIAvljJP1XONH4uICwAA///s3MEJgDAMQNGM5gpt19RmBFcrgmdPQq28N0JugeSLagBMlke3vLO80qqwBgAAAAAAfND9jO8hHxaVezrcAgAAAAB4IKwBALzkimucpdXNQH8mIgYAAAD//+zdUQ0AIAgFQGxmNQOpEazmbODmj7q7CvzAGA+hGgB3MLzzuqxZBAAAAACAaxWlgSfZIwMAAAAAbFjBGr22JGgcADi0biSHJ+SfiYgJAAD//+zd0QmAMAwFwKzmCOpCDmTNCm6mCB2gH3605W6EQCAh8CJUA6ADNRXT4s7oDIoAAAAAANChPNMtCsZz194FAAAAAKBRlmtxEwEAfvA9IX/WfTsUcwIR8QIAAP//7NzRCcAgDAXAjOYKrQNJ9xFcsQguIPhh4G6E5CsJL55qAFxiDe6Qmg9sAAAAAABwp9GHWxTk8ukXAAAAAMC+lc+xYwUATmgzM/nUt6hmYhHxAwAA///s3cENwCAMA8CMxmgdCJoRYDTEClUfRLqbIg879lQD4C7CjFTXHIgAAAAAAHAtAVKoYWVPS4oAAAAAAB/leB8dHQDgJ6cvOQ2SFxYRGwAA///s3dEJgDAMBNCs5mYOVL0RKwU30I8U3psikEvOUw2ARnLdKxglHMXuDIcAAAAAANBQRk67KOgvI4LeAAAAAAAfvTc6h90IAPCTVUg+lZJvqKoeAAAA///s3NEJACAIQEFXb6BqhFaLoBH8ULhbQfzTJ6oBUMyey4EU7amuAQAAAABAWcNooDQ7CgAAAACQ5IU1/p+OsAYAkOX4n2wmIi4AAAD//+zcUQkAIAxF0UUzmoGEVbCZIhjBjwnnVNjv3hXVAKhJWIPfNcU1AAAAAACoJ0dOj6NQ1syR3XkAAAAAAN66YQ1RYwDglbOfXDaUn4iIDQAA///s3dEJACAIBUBHb6FqBFcLdyiQuBtBEPx4qqMaAA3VJUxhRj6QhkIAAAAAAGhJaBR60psAAAAAAI/suYYnuADAZbVDmYraXEQcAAAA///s3cEJgEAMBMDYmS2oBdnQaVq4zhThSlCIMNNCyHN3lWoAFDVaMOHvdhcEAAAAAIBasmUX3ody+vhNAAAAAAA+8ozg5nFOhnABgBfNy7ZeBsoLi4gbAAD//+zdwQmAQAwEwLSoNmRBB1dCWjsES5BjhZkSkk/Yx0apBkA2xRr83XMQ3rYIAAAAAABZ5pjye8ii6AYAAAAAYJP3Ea5cFgD4Uh/X2SYaqKoWBMC0EAAAIABJREFUAAAA///s3YEJwCAMBMBsbt3HNiMq7iASyt0WIfy/Ug2AwnYDpiOdH2ha1gAAAAAAoCR/KKih50iriAAAAAAAF+X7PcZwAYDD9kj5lKcsJiIWAAAA///s3dEJgEAIAFBvxLqBWqjLEW61CG6ECIP3RlD8EEUd1QAobjXpFqj4u0MGAQAAAACgljzTHAoKWLUIAAAAAMDHnme4Oa5mXgIAvGxufZ+CWkRE3AAAAP//7N3RCcAwCAXAN1ozQiBrtl2xuEPABu5G0E/1KVQD4Ay+hHG6SlizDAgAAAAAAP9jDgXN5prmaAAAAAAAjd77GUmGHgAAG9VNZYVrXIraLMkHAAD//+zcsQkAIAwEwKwouE9WczQJ2NkKotytkCbwySvVAHhANV86aOQDaQEEAAAAAACATbbe5GgAAAAAABet350q1hjmAAAcUjmwYo3bImICAAD//+zdSQ0AIAwEwFpDGRgCJGCN4IGEIzMW9tW02SrVAHhEr60YzPlAFiIAAAAAAFxliAOuYI8GAAAAAHDYKtbotSWPcQGAzVaxhvuMUyJiAgAA///s3dENgCAMBUBGwxEeMBCba0wcwSgkdyv0q23a56kGwF405eyuprepigAAAAAA8L+MmNnDOmpGpBMBAAAAACzgCcY9hOMCAC+6byvP9GYv/LVSygUAAP//7NxRCQAgDATQVTOZidQIVhM7iEx5r8IY3M+dUQ2Ah+zFS8MafKAKfgAAAAAAkEJ1BkjFTwIAAAAAJLE7PKP1oscDABw29Ssvi4gFAAD//+zc2wkAIQwEwJTmlRCwIDu71kSwBPEBMyUkv7trVAPgMXPt0tIlrxMIBAAAAACAg7Lm7/5wnZI1m7cAAAAAANxj9ng+XR4AYKExrCG3sUtEdAAAAP//7N0LDYAwDAXASgMJBWxus4A0Ug8QtuROx/sY1QBYk5VLVrfleQgEAgAAAADAD/LKejzxegJzMk4PAAAAADCZ0fo9Wt/1eQCAF1XHssY15De+FhEPAAAA///s3NENgDAIBUBWJHEfJ7Ku0NEadtAUzd0K/PBIeEo1AD6owrggzg+cFj4AAAAAANjC0z40lkcqpwcAAAAAaOi+Rt1vq1xjmg8A8ID6r1Ss8baIWAAAAP//7N3RCcAgDATQjNaOIHSfTlRdUYSMUEXhvR3yETjulGoAHCofcU84pxPaBQAAAACAhcpTrgxlAPt681YBAAAAANjMGMptX72N5QIAPxrFGsYXZomIDgAA///s3UENACEMBMBKAwlwgpCGNT5IAHJNZiT01SbNrlANgNwc4GRXLHsAAAAAAPDUNG5IQTg9AAAAAMCP7bLcqjAXADhktK/76bghIhYAAAD//+zdgQnAMAgAQUdLRxCyZpoVi9ANQqApd1MI4iuqAXCwqlsKa/ADNez5tAUAAAAAAJtlT6FrOEfLnnZoAAAAAAAfVnc9c9zXG9cAAFjVhDU2iIgHAAD//+zdwQkAMAgEQdN/0QkBS9DHwUwZoquoBkC4LluqWpLOpy0AAAAAAFjUx/nm8ZDFshQAAAAAQICOaxz3PQDAgB/WuB6ZD6qqBwAA///s3VEJwDAMRdFnrRIKM1RB6yTM2qiH7iPlHAv5CQRuRDUAzjDMkeLWouc7HgAAAAAA/EdQAwrqV3dDAwAAAAAo4rlnS9LENQCADV5hjU2SfAAAAP//7N3RCQAgCEBBVwzap9FaLYQ2yJ/kbgoRfIpqADSQRUthDRpYhjwAAAAAAKg35sj9ux08/EkQBwAAAADgI3njc+Ma7nwAgFfbM/MCEXEAAAD//+zdyxEAEAwFwCjRjII0hBK0ZtTAhdltIbd8XoRqAHxitF4lWfIBS4EAAAAAAHCf/js8LJc81Q8AAAAA4C37zme0noRrAACH9jNzM+MTEbEAAAD//+zdwQkAIAgFUEezEYT2nyWCNqiL8d4Iggc9/C9UA+AvDm26S8lpAAAAAADwTs3af/c0Umgta5Y9BgAAAABo6JToDkW6AMCFFKxxISIWAAAA///s3FENACAIQEGqmcxEagWjOSuoP7K7CGz8wRPVAEhktD6FNUhgl9McBQIAAAAAwBvVHCEFuwwAAAAA8Kn97zNaL+IaAMAFYY1TEbEAAAD//+zdsQ0AIAgAQUZzBRIHcnQbC2utIHcj0JGQR1QDoJlTsLRgU52jQAAAAAAA+JQzlxlCGyNnCtMDAAAAABR2xTU81AUAXghrvIiIDQAA///s3dEJwDAIBUA7Yto5k47YImSAkL/I3RQK76mjGgA1Wa45XQ53gr4AAAAAALBplu8dsYZahKMAAAAAAArIh7pvH5f+DwCwIbuXX3tuTxlWRcQPAAD//+zcQQ0AIAwEwVpsgh+kYY3ggMDvMqOifdyKagAEOuVKjzUBpsMOAAAAAACeCWpAoB4tTA8AAAAAEEJcAwD4sOwvL1XVBgAA///s3bENACAIBMBf0cSBHc3YWUopuVuBiuR5lGoANHUW6yTLfPmcb1sAAAAAAFA05jihCcEJ6ElhDgAAAABAM1e5hjsgAKBCscaLJBsAAP//7NxREYAwEEPBWKuEA2xSLFZCp5/c7NrI5IlqAPSmVMnv1X0JawAAAAAAwBmne2isnrKfAQAAAAA09L1zJBniGgDAAWGNnSQLAAD//+zc0QnAIAxAwYzmCgEH6kLqCh2tuEDR33A3QkAIAZ+oBkBha8xXWIMCmqUOAAAAAADOZM9n39aNC0pr2dM7BwAAAAAoaP8FEtcAAC4Ja/yJiA8AAP//7N0xDQAgDEXB7xwMARZRQAJruZPQpEOXV1ENgOLWmN0RTQG+bQEAAAAAwJ1mTvAFuw4AAAAAUJi4BgDwSFjjJMkGAAD//+zcwQ3AIAwEQZdGC0doKJ3TAELKkzDTgn/WaUU1AO7wujOny9OFNQAAAAAAYCMjfulwj5YRgygAAAAAgJ8T1wAAPhDWWKmqCQAA///s3MEJACAMBMErzf6rEsGX+PDtzVSRBLKiGgAF1gItrMEHhoEOAAAAAADu9nO9Ozp0EdIBAAAAACghrgEAPBLWOCWZAAAA///s3cEJACAMBLCuKLiPLqSu6FfECWwyQvs6KFelGgBJrDG70MwHHAYCAAAAAMBbMxfIp9TSrR0AAAAAII+rXMMDXgDgRbHGKSI2AAAA///s3NEJgDAMQME4YtR97EK2K4pQwQ8XkNwNEQgkT1QDoBbLMr+X2yqsAQAAAAAAL7nnfQjhGAJqOuYMAAAAAACgkBnXaOPsi38hAOCDsMYjIi4AAAD//+zcsQ0AIAwDwYzGZqyOItFQZADkuxFSxc2LagAE6cF8S5Tws+WZAwAAAACAhyA1ZNvpBwAAAAAASCauAQAMhDVaVR0AAAD//+zcMQ3AMAwAwYdWCpYCqNAKrUumMqhyB8Fe7RfVADjMDms89s7POQ4GAAAAAIBq1tzmAMe7Zo1DKAAAAACAw33iGn6HAICENarqBQAA///s3FENwCAMRdFnDQkwQShis0iWgAjCORLapH+9ohoAF/rGW+yd09WnCWsAAAAAAEDSzQBwCwAAAAAA2FZc4/8dKuIaAMD1YY0kEwAA///s3UENgEAMRNFKWwtNVhAIYrGANE6bYIHMexLm1NOvqAZALmEN/m6kH3IAAAAAAGTr2QLUwDZ69mENAAAAAAC2+1rPJ65xGgYAouU+aqiqFwAA///s3cEJgEAMRcFY4oIFbUO6LUpgDx6swD/TRSB5EdUACNWDsdokP2BZGAAAAACASOMcHZ4WnwbeopegAAAAAAD4tuMac133Ia4BALH6yXnmPWZVPQAAAP//7N0xDQAgDEXBWkMCCYKQzsJAQhBA/p2ETl36KqoBEGzXJuFryYscAAAAAADRHM8Dlz76NBUAAAAAAF6OuEbzrBcA4mSGNapqAQAA///s3cEJwCAMBdCsKHQfcSDrCo4mgkfpveS9EXIIIZAfoRoACNbg7/Yg5xMfAAAAAABpnKN5u3Hgppan6A8AAAAAAHwa/Z37We8J2GiqBQBp5AvWiIgFAAD//+zdsQnAMAxFQa2WyeyFEq9oBK5D6vy7FQQGFXoW1QAI10uwsiQ/EFlHAwAAAAAg1jB64IU3AgAAAACAz9b9zBPXuNwYAUCEDmv0hy4ZqmoDAAD//+zd0Q2AMAgFQEarI6Ddp3FzQ+IC+qfcjfD+GuBVqQYA9fjdpMDXdWxHAwAAAACgn5zZaqkBeGXkzCE6AAAAAACeqI9768boLtg4hQcAv7by2HvMlSPiAgAA///s3MENgCAMBdCOxmayEDoCjEZI8G68ad8boU2aXv5XqgHATbEGX1cyPXEAAAAAAOSzQ/KH1QMPuBUAAAAAALx2tbPuco2VNxomCQC/1FNkMiNiAgAA///s3MENgCAQRcEtDUsgoSAsSCmB1gzGAky4bWZKgNMe3jeqAcBrrUk6cklg+kQAAAAAABITyQN/ldpq91oAAAAAAOxYvdG47uMb2Di1RwCQTv4mMyIeAAAA///s3bENgDAMBECvxggGBmIhYMUoUsQEaWLuRnDn4v+VagDw6U+ua7C6PHbFGgAAAAAAlJNn9mWQX6yDANMo4gEAAAAAYJr3fq6RPdpGwQYAUED5TGZENAAAAP//7NyxDYAwDEVBsxkrGBgoC5GswGgIiYoOiQbrbgTX/k9UA4AnYQ3+bs518VQMAAAAAEA1xvHAa7llczUAAAAAAL409n7cgY1JYAMASrg2mXXDGhFxAgAA///s3bEJwCAQhtF/RcF9JJtlNBFskjKQQn1vBIsDi/tOVAOAh/GxTXJ7FRa3fRkNAAAAAIBzzKV4QWngi1ZqMT8AAAAAAPjFK7Bx2UkCgGWNsMaeRxuSdAAAAP//7N2xEYAwCEBRVmME40BMpK6Yxi5lziLxvRHgjvIjqgHA4LnuNBVWt3sZDQAAAACAXynrBia4IQAAAAAAfO6Na6TABgAsq46z7fe0ISI6AAAA///s3dEJACAIQEFHawWhfVutCfoVtLspBPEpqgHAi7AG3a2pAxwAAAAAAP/InWO/gABlVu60NwMAAAAAoIzABgC0dcbdZUbEBQAA///s3LENACAIBEA2dyJ1BB3NxtLSxGDuVviKAK9UA4CjXts0sPKBIUQAAAAAALLaT/BFgMAF9mYAAAAAADyhYAMA0vnrViUiFgAAAP//7NzBCQAhDATAlGYLUQu60sUC/AmSY6aE/QU2a1QDgKN9sEqH6nJ0BUEAAAAAAKoyqAFckzM/aQIAAAAA8JKBDQAoof3qLzMiFgAAAP//7NyxCQAgDATAjOYKggu5uaQXbCyi3K3wTQjJK9UA4ESxBq/LAc6BIAAAAAAAT+mjt9xxSw24SFEPAAAAAABlbAo2pnQAoIz8y/zjbiUiFgAAAP//7N2xDYAwDABBr8YIkbJPWAgYIRmNJjW1Ze6GsNz4LaoBwKfnupfqIwWMSgscAAAAAAC/UOrjB5BD681sAQAAAAAgnR3YOHdg4xDYAIAUZom7zIh4AQAA///s3bsJACAQRMErzRYOLMjSxVwwEj/MlKDxvRXVAGBpVB+9Eh+wvAUAAAAAwBOyZvNTwCYla4rRAwAAAABwrTEQPAlsGAwGgDPev8uMiA4AAP//7NyxCQAhDEDRjOaNoDfRTeZqIlhYXqMQeA+ygEWq+EU1APhLWIPsSn2bI2QAAAAAADIQigZOsmMAAAAAAEhhC2w8K7LxrQEA7pj/Mnvqt46IAQAA///s3dEJgDAMQMGMpiNEu4+OLoUM4I/QyN0WIe2LqAYAr8whVNWRH7jyPFzeAgAAAABgWTmy/UMEYHlbjrQzAwAAAACgnQps3BXY2Cuw4b8TAHxrhjX67pgj4gEAAP//7N0xCsAgDADACP2g+iD784rg1LkUA3dTRkm2SJLrgDcAkMTa6lh7e9SL5IaGCQAAAAAAJ9pD7gbdgT+sBT5FpgEAAAAAyOp9QLj2du9wKCoAfC7vH3NETAAAAP//7NzBCYAwDAXQ6GQ6Qq0D6UDqilLowQFEWnkP/j2QWxIyNlADAH2Z9YvOTY9BCQAAAAAAtMSBH/CZtCY7MwAAAAAAfuM6zq1mKImIvQYAeEHKS3ms0Z+IuAEAAP//7N3BCcAgEEXBbXFj+gnpXAQPkpsEgoaZMhb2fVENAKY8K46wqSvLYekPAAAAAIBl5Jntbu12DXxJyAcAAAAAgN8aIxt9ZPj2EwUAr+w5eB4RFQAA///s3cEJACEMBMC0lhKEa1NtUYRrQO5zkZkS8shr2VWqAcCx2Ue6GhcQEgQAAAAA4E/KrnkAdbWn+T0AAAAAAFxvjwy/BRupZAMAPqk3eB4RCwAA///s3dEJACAIQEFHawWhhdq8DQrqI4y7EfwUeYpqAHBKWIPqylbRAAAAAAD4S/a0rwZeadmz3METAAAAAADcWEQ2hsECwFath+cRMQEAAP//7N0xCgAgCEBRu/+lQ2hoaHLT3gOvEAjyE9UAoCSXRzVGBmhZRQMAAAAAYJx2xwbAKN4gAAAAAAC+dkU2ctYJbYhsAMBbrw/PI2IDAAD//+zdsQkAIAxFwYzmCoHs62piZ2VhI8rdCL8OL6IaABybNUbr8QFHggAAAAAAXJOV3frAZS0rhegBAAAAAGCxiWx4UgwALz08j4gBAAD//+zdQQpAIQgFQIN//zOHUZtoHcafOUHgQsiefQXOAMDbcrGGx568bGxFy4sOVQQAAAAA4KYZYhdkByrImW9TCQAAAAAAONtzJzNIvGZ9PnwF4I+y/9VfNhURHQAA///s3cENgDAIBVB0wyYu5EDqCo5mMB3AI63vJdzhDp+1QA8ADOw6zlvCIhMYKhUNAAAAAIBpWK4DymhbE0IPAAAAAAAf5U1VBm30WrL68+LdrRUAP/E+PC8/akQ8AAAA///s3bENgDAMBMAU7IUYIcA+LARkBBgtQqKgoKKK0d0E7l//7hq4AYDgyrYPeRoPn9QILswqGgAAAAAA8d3lddkK0JIlz/ksa5GZAQAAAADAB2/Pix9l414+CMAPXb3Mtoc1UkoVAAD//+zdsQ0AIAgAQTY3bm6wtiQGzd0GSmXhI6oBQJXpYcfjdhUtC6EGCQAAAADABcMlAw0J0QMAAAAAQKHTPxWhDQB+kkv7c3l/2yNFxAIAAP//7N3RCYAwDAXA6GR2hKj7iAOpK0qhKwit3EH+A/1ryMvcQQ8A/EBLUjy9JYM7clt9RgAAAAAA8KncU8Az0Ksl9zQvAwAAAACAD9WgjVblue6pVkSUtptlPwuA0dSD5/3OmSPiBQAA///s3cENgCAMBdB/cEFhIEdzNUMCbqCp5r1Tj4QbJf3dCpwBgJ8Yj7m9NwmJfJ3tWwAAAAAAPGYOqx9uGCjMfxkAAAAAALxsLjxe/fk7pH/vbdVmtgCo7EwyQqLqSXIBAAD//+zdwQnAMAgFUNvJkhECXagDJV2xBHLoADlYeA/cwJPi99Q6AGwmDZG/K5+BAwAAAAAA7CZQA8iutKvZlwEAAAAAQALzCfKq+vRxzIqIum64bkHZAGSR9i4zIl4AAAD//+zdwQmAMAwF0B7cS1dI6z7FzRxNhB4KXkVaeW+C3JOfvwwwAwA/cn9FjJIPB6FMrkbJZ/vyCQAAAAAAr4g9Nu1RwCRq34IHAAAAAACMo+VdHpmXKLnfR652kwB8bMxcZkrpAgAA///s3MEJgDAMQNGsGO0+OlChK0rx4sVbBQPvbZGEfFENAJab9cPcN4MX1R1qnQAAAAAALCZKDpSRLc/Rh7AGAAAAAAAU8RbbiDu48dz5u1sC8JX//WVGxAUAAP//7NzBCYAwDEDRjtYVqu4j7iN0BUeTgHjotQgG3jv13ltCvqgGAF85RDVIrsbAICIxPhIAAAAAgFlxnG53AiSzt61d/exC9AAAAAAAkNxwH/O+27rUYY8puAHAjLjLrE/o6R9KKTcAAAD//+zdwQmAMAwF0GzmDG0Hkm7maCJ48CIIVkzhvRFyacKniaUaAHziePBKq90gxeTW0uqWrYEDAOC1roQAAMAPZCbAjFJeEQIAAAAAAMY4/8xcs4C7hRuLIwIAPJQrZ46IHQAA///s3NEJwCAMBUBHc4WoYxZcsfhTpPRXqO3dEiG85CnVAGCZ0WAYtViY2J1DQQCAj7m1rQMAACwXLewhwK5ytMj96PIyAAAAAAD4mYfCjUvUMmeg/scAmOUxJ15zt59SOgEAAP//7NxBCgAgCARAv97PQ+hSh26B0swjRJFdpRoAvDYcRTRXboEDAAAAAKCPDKOvAmeArpTQAwAAAAAAm1vO5ijc8CsF+FPO/xqZzIiYAAAA///s3MEJgDAMQNHoZDpC1X2km4tQoXgSL9ryHuReyLX54w/eAEDHSpEw2zGN29O6iMMAAAAAAPCGT2JA66a0JQF6AAAAAADgkTO4Uc1wTUTM5c4suzcD6N8tsvSdiDgAAAD//+zd0QmAIBQF0Be0V61gtW+OFoJFn/1EKedMICqCXOWO9hsAbyuXoLQuU3lsZbJp2B4RgwUEAAAAAOCptKVZPgJ04lctQgAAAAAAQHtqeXO+DfzKHmoZ7pmt+ocG0IdSdp7r+f+diDgAAAD//+zdsQmAMBBA0azmCJe4kPuoGSGriY1YWFiIEnlvhEt1HPyIagDwlskyQ++i5FaXdfCQAAAAAADc1AwK+IsYo9W5upUBAAAAAACPuwhuHKLkc/hbcAOgL/sHDt9GNVJKGwAAAP//7NzBDYAgDAVQRmOFKgPpPiorGhKvXBHNeyv00DQ//Uo1ABiiHTaxLvuzAOGrcmu+nKEZDQAAAACAuUWJzYiAn8lRItejysoAAAAAAIBh6nl1s1eFGwDTe/8nM6V0AwAA///s3bENgDAMBMBnRML+uyC3KZIOA7pbwZX18lupBgCPqQXmvIblhK+rr4KHKQIAAAAAsKFoHPijV3wRAgAAAAAAyKJwow64pxs2+S1An96cOckNAAD//+zcwQmAMAxA0Y5WR4i6kPtYO4KOJoJ4EM9F5b0REsgtX1QDgNYmUQ2+LoZ+rWXpLBIAAAAAgCcxxmowwE/lGCPXuQprAAAAAAAAr1XLst0euK/4huAGQHP5uL3nbW4vpbQDAAD//+zcsQ3AIAwEQDNZZoAslGweuaOjiQJEd6VbCrDQv1INAD6Vl149223ZYHPTH3EAAAAAAKwpw+YKxoGfy+Kg4pABAAAAAIAdDQo3rm5++PsFeE1miufkMSPiAQAA///s3cEJgGAIBlBXtBrIgSpXjO51Cop+3ttAPAn6KVQDgNf1tlfOk6GCv7MsCAAAAADAFcHiwPByyeq1S6cBAAAAAICRnHdvd+UI3AB45LtH5xFxAAAA///s3dEJgDAMBcCMVkeoDiQOVB3B1aT4I6K/FfVuhUAghLwI1QDgKZPBgbfLQ78uZe4UEgAAAACA2I/Mk/0H8BPj8WsbAAAAAADA190FbtQj8dOe2CMGgGu1P7YP1YiIDQAA///s3MEJgEAMRcG0GLUh+xG2hG1NBBGtICs700JOOfwnqgFAiasmleuyexL4udI6GgAAAAAAw+lOAswit+ztaAL0AAAAAADA1O5d0Xtb9MQ3BDcAPmr2mBFxAgAA///s3cENgCAMQNE6maxQZUwTVjTcuXiRKO+t0GPhV1QDgGl6nS/PY3exjY/rD6Q3QwQAAAAAWFvWHF4lAvixkjVLu5oAPQAAAAAAwMCD4IY/dsAqelzo3R1zRNwAAAD//+zdwQ2AIAwF0I7mCsBEDqSO4GqGxBgPnCXIe0M0PbT/C9UAoLfVws/oUsnnse1auAAAAAAAJlWfyjUKAZPqcvAEAAAAAAAwukbgxiOV/C51ELgB/MlSQ4XuGfiNiLgAAAD//+zdwQmAMAwF0IzmCupCuo82K0qvgjdpLb43QK4N/PCrVAOArurDN6/L7tCUwXVZ5AAAAAAA+Aw5B/BXUy0WyiPlZAAAAAAAAC/Js2xPk26FG7JqYERtP2+IiAsAAP//7N2xDcAgDATAz4gkA7MacpOCAUgQdxW9G6SX30o1APhcffLbc2vMY3c9yWWKAAAAAABnqWVyGQdwODkZAAAAAADAIlPhxvuug8FTdq1wA/irtUfOkwwAAAD//+zdsQ2AMAwEwKzGCAEGgn0Aj8BqCCkFTUpQUO5WcPv/NqoBQCtWgVP+Lk/jGfsxOCQAAAAAQFcEkYDu5TkvsUX1YxoAAAAAAADvKuX0Z0G9NrjhOTbQgjtv882oRkrpAgAA///s3LENwCAMBECvCAwUZXMERUSR2oB0N4Ul/79RDQCOMI720uoreMrl0hfSAAAAAADYZ5TIhY0ApmcNZgIAAAAAAHCOn8GNT2l1/fHo9gFZ8rqYEdEBAAD//+zcwQmAMAwF0DiaI1QdyIHUjtDVpFDEBRSL751yDMk1+UI1APiMvB9rmidJd/SuRMRgiwAAAAAAv+CgCKBJSyp5y6N5AAAAAAAA9KP+9N2avWphG8AL6i/x86EaEXECAAD//+zdQQ2AMBBFwUqrhYUKAj9AJWCNcOyNhJQAmbGw15+3ohoAvM0sqsHXxTjsdd0MBgEAAAAAfixKTO4L0MhRItelPjJ6AgAAAAAAoJ8LsQ3PtYG7zmBP//1NSukAAAD//+zdsQmAMBAF0NPJzAjqnElWcDQJpLCwsRA0vAc3wUEgxf83WxUAX1JzOXqxBvzZsu6bTyEAAAAAwKBaaNwlHoBb3kYAAAAAAICBtbKNPqnmMrWJiNQzgXKBwCOXop73RMQJAAD//+zd2wmAMAwF0AgO5gpVB3IgoSPoaKLUP/30yTkTFAKlcJukVhYA3mZ9VKeuNamOr5siolJFAAAAAIBf0jQOcKxJfRrymG/5+AQAAAAAAMDzyqLtuRxky4nKwuK9P1DGDpxZ74dr8+WIWAAAAP//7N27DYAwDEBBw2TTeAg8AAAgAElEQVSsYGAhJmO1yFIKKrpIfO4kL5C08cvs+AF4KFU6Xi+39XSLAAAAAADfknsuwuAAtzyKBAAAAAAA+LkKbdTn232mmr4zeFwCHAC1hzk2qhERjZ07tgEQCAEoymbKCCS3/yw2V1iYWJF453sbEFr4ohoAfNKs06XtsLhzVhUBAAAAANiHZ3GAFzWq/egJAAAAAACAtdwiG/kQ2gD+62idPCIuAAAA///s3bsJACAMQMGsKLiPo7majYWVVoKfuxUC6fIiqgHAsXpYQ3WO21UTBAAAAAB4Qz8SF1MGWCspJ/sSAAAAAACAqSG0IbIB/9r73DwiGgAAAP//7NzLCQAgDETBtKgWZOtiB/Eg+JlpYSGXwBPVAOBoszpnIW5XWhXWAAAAAAB4Q7cjQJqbCQAAAAAAwBKRDfjWvv9yRAwAAAD//+zcUQkAIBAFwYtmhQf2z2IGhfs4nKmxsKYaAExgrMF07ac0AAAAAAB6ZcdAGeDOyo5GBgAAAAAAwDOTDfhGX1uuqgMAAP//7N2xDYAwDATAXxFYCAYijEBGo0lBSxGJwN0GljtL/1aqAcDrHXupSapNMbhTsQYAAAAAwJhaKNyNF+C5rt+EAAAAAAAA+Jd7yUZ75r3JHsI3TMu8dhkkyQUAAP//7N3RCYAwDAXAjGZHKHQhB7KuKIVMIPQjegeZIH/h8aJUA4AS7ms2m+IDhAYBAAAAAGpy3wV45+ijbws+AQAAAAAA8F/rmXcWbLQs2ThzgJr25HMi4gEAAP//7NzBCQAhDEXBlOaWkHULsnRZsALRQ2CmhBzD54lqAFCJsAbVtZu1NAAAAAAAzssv2//fdVqAbcJEAAAAAAAAXLcCG2MFNh6BDagn+3t+oxMREwAA///s3bENwCAMBMBfESn7MFoYLaKnAyKQ7kawGzf/VqoBwDV6c1ySZmNcru467AAAAAAA2OI1VoA55SmK5wEAAAAAAPhNzyIOCjZkE+F86582JPkAAAD//+zdwQ2AMAhAUVZjBBL36UTaFb14cADSWPPeChwJH1ENALYyzytNjB/wjQsAAAAAYAOOwAHajDpKeB4AAAAAAIDlXoGNfCIbAhvwXf175Yi4AQAA///s3NEJACAIQEFHa4VqojbvpzYQMrhbQfBLn6gGAD8S1uB3rc/hEBsAAAAAoD6RZIA8dioAAAAAAADP3cDG+VNcJgK1pP9eRsQGAAD//+zd0Q2AIAxAwTqZrlBlH0djNULiCHxUcjdBEz6bPkQ1APidWYZTgmMDbz6337gAAAAAAIrKlt3bACx1ZUv7MQAAAAAAAEqYd4pfYOMQ2IBSzqXTRMQAAAD//+zdsQ0AIAwDsJ7Ga3zO0okZiUay32iTKNUAIFI3wUE6a1wAAAAAAAN16FvwmySeu0jhPgYAAAAAAMA4V8HGNgoOX62ng+ZVdQAAAP//7NzRCcAgDEDBjFZHEBxI9ym4YhH64QClGLhbIX4Egk9UA4DMhDXIbi133RQBAAAAAI7j0zeZjHlP9wayuGqr3isAAAAAAADHeuMaZQtsAP/7LqoREQ8AAAD//+zc0QmAMAxF0YzmCoXu42qOJoUKfksqpJyzxkuuqAYAZY36m+IbGzizq2kAAAAAAHzXejuyh3lY6HoFNRxzUYVwEQAAAAAAACXMwMYT1/DLCP/J25Uj4gYAAP//7N3RCcAgDEDBrOYIAfftaiVQigMUMeVuhUC+9EVUA4DWqvhmgvyAh4MAAAAAAOe4zIJG3pDGEteA4+VMuxYAAAAAAIA2nrhG/WUc4hqwx2fHzCPiBgAA///s3dENQEAQBNDTmRYWZTrbgtLEn/g+5OS9MnYms0Y1APgDwxr0box5UnQFAAAAAPhYLOFWS0/2XPNe1pKb0YsxlmhWgAIAAAAAAIA3ZN32c1wj6zZcnyAAj2iTKZdSDgAAAP//7NzBCcAgDEDRbB4XaruiFLx5EtJDynsjeJBA9ItqANDeO4iqu/EDWVlOAwAAAADgzPrcnY6NRrYHWiuyYW9GF+5cAAAAAAAA2nque4hrwKdqdsoRMQEAAP//7NzBCcAwCEBRR+sKTRfKaB2tFDzmVkpQ3hvAizeRL6oBQAtv3c0macDjIAAAAADAPm60VHJnQGPFwxZVHBk0AgAAAAAAgLLENeA/5zXm5+kR8QAAAP//7NyxCQAgDADBbKabu5pNWkFQQeVugDRpLMyLagDwE2ENXld3PfIAAAAAAJiXR90Ou3nJ8DNWxjZGwQ24TbMRAAAAAAAAfiCuAUeU5akR0QEAAP//7NyxDYAwDEVBr2hgn4iBQlZMQ00DQop1N4Lr7yeqAUAZo18GglTQct8MtwEAAAAA/tXcm4WcdzjjiZEWy8gjRecBAAAAAAAoQ1wDPvX+1zIiJgAAAP//7N3BDYAgDEDRruYI6ppoV/TC3QOEhOa9FXqk/YhqAFBKPu9hohRgeRsAAAAAYJF+zC12zDay5W+AoEc3xOjZhbcxAAAAAAAAyhHXgDnO+xr7qCEiPgAAAP//7NyxDQAgCARANtMVSNzX1VxBow3mbgAaGornlWoA8CPFGlTXXxx6AAAAAABs8cxNJSdhK8EsysiR07YAAAAAAAD4kXINuNauJkTEAgAA///s3VENgDAMBcBJw0JhfjA0qAWkERIEQAgfW+409K/te0I1ABhObrvmLUawxjJrRgQAAAAA+FHUEHBMV7Ll45nNloejLDoyRQ27MQAAAAAAAIZ1hWvcheJ+H+Gdb7vkUsoJAAD//+zd0QnAMAgFQFfrCE3nbLNiKGQBC4FU7lYQ/BB9CtUAoKR+P4fKUoDviAAAAAAAi8zjbXNY/iQdkJEJ4YAN6MkAAAAAAACU9j4Un7ePwjUg4bza9/2HiBgAAAD//+zcsQkAIAxFwYyW/aeysbCxkCASuZsiEP4T1QDgZ8IadJfVYw8AAAAAgC3jbVopBDKOYxzwSM7gEQAAAAAAAHxtiWv458JtETEAAAD//+zdwQ2AIAwF0K6IDiQLiSO4miHh7AFNDPjeCD010P4K1QBgWrWxlNbGBLa0LoYHAQAAAABe1Ja2vb0yku4w+QdhHPCFU9UBAAAAAAD4i2Mvuf0H24OEe/3HcyLiAgAA///s3csJwCAQBcBtUUiZgi2ktCB49qC5rM7U8T5GNQA42lhrg+y8JQIAAAAA/Etpm0zeVttugMq7EWmUpxiCAQAAAAAA4Br9XHz0IHUhYWL5vDwiPgAAAP//7N2xDcAgDABBZzNWCKyJxIooEmUqksbibgVTUOBHVAOAE7hMkl25W/V4EAAAAADgB5a1SehzEGP04dyTieA8AAAAAAAAx1lxjev5eMH04dVeVCMiJgAAAP//7NyxDYAwDARAr8YIkdiHhQCPEEZDNFRUhCbhbgU3lt5+pRoADO9aJi2SDGBpaVIDAAAAAODmWZueHLnmVzmXInq6UeZSTQsAAAAAAIA/ym2f5Lvw6N3NT0ScAAAA///s3bENACAIBEBG0xFIXMjNbdhAG+LdBJQkwCNUA4AvVCMJ3Vn0BgAAAAC44EibhvarkiucQxA9XYxcKXAeAAAAAACAL9Wj8WnGCw9ExAEAAP//7N3RCcAgDEDBjNYV1IU6mqOJkAVaRBDvRvA35kVUA4CbCGtwuqe06sM3AAAAAMAPuZxtQZuT9AxhrLQs0gEbCM4DAAAAAABwrRnWyGPj5ryQSqvv57eIiAEAAP//7N2xDYAwDABBbwYrRGIgBgK8IkKK6INoDHcjpEphv0U1APiNXmfzgaS6K6xh6BsAAAAAYJzlbErJLV8PxvdIh0tGVDG3pT0aiAIAAAAAAICvyP1YHRyH2zT8FBFxAgAA///s3bEJACAMAMGs5giC+7qaCBlABIvg3QppLJJXVAOAr+QD0qIg1U0TBAAAAAA410ffsWLBYip5GYoXoacSQSQAAAAAAAC+lx+ON7eRcLH/ExELAAD//+zcsQ2AMAwAwazohIEYCPAKjIbYAIoUVu4mcOPGsl5UA4AVeRSkvBhdWAMAAAAA4Ds3VUrJI/dZ8+aRt0crKoktpu0DAAAAAAAAVPGGNfK8hDVYXoz+L6zRWnsAAAD//+zcwQnAMAwEQZUWlyBIP2ndD7sB+xEQmqlCsOiMagDQzl5lM6xBdc/N8QcAAAAA0I1nbAr6o2NpZVTy5Zu6GAAAAAAAAKz/yKH50txZP46ICQAA///s3bERgDAMA0CvlslgoIBWpEmfo6AI+R9BhRufZaUaAGwp131qZOMHfFYEAAAAAJg7ZMRK0vN5EUx6lNCzGrMcAAAAAAAAhnEf2eTBpt7tj6vqAQAA///s3YEJgDAMRcGM5gpfu6a6gqM5gaAgherdGEl4EdUA4M8cCjK8LLOwBgAAAADAhbSYoTKabvurHvEOeNGUlsffhgAAAAAAAOCr9nU7hDXghqo6AQAA///s3bsNwCAMBUCPlhWAhRmNhgJRJVVkuFvBDfLnIVQDgGvNR6NgDbJ7SqsWCAEAAAAANvP4Wv+UTPoPQRdmZWTy+bchAAAAAAAAONkSrNEVmpuUVt/vV0TEAAAA///s3cEJwCAMQNGM5gqCA7mQumLxJpSeCpW2782QQy75EdUA4NdG69XCyAf4tAgAAAAAcOb4mrd5PHCxIeIBd6RcspkFAAAAAACAxQxrjNaFNeBKRBwAAAD//+zdsRGAQAgEQEqzBd82naEFSzMh/OCzH3S3BNKDQ6kGAPjAxQec11CsAQAAAABQ6uj6MA8aefLOXQtOsjI6UZgEAAAAAAAAE4o1+Jn17DgiXgAAAP//7NzBDYAgDEDRjuYK6kIOZNIVDYET8U6A92bore0X1QBge6XE5liQBRznfTkQBwAAAACoPF0zm2G7qnzzMS3MpIWTAAAAAAAAgI6wBvyIiA8AAP//7NyxDYBACAVQVnME1H28gUxuBB3NwtbCzpy8NwI0JMAXqgEA97DYDIv8wKGJAAAAAEB1nq0Z0Nn3/vWeahqyclS15ZrC5gEAAAAAAOCBYA2qyGV+dyMUERcAAAD//+zdsQ0AIAgEQFZUB3J1GxNt7EyI8W4GQgM8QjUAYEn7AAa3lFYFawAAAAAA35pH1l0F8Jj0GdUM9bBUxUv0egAAAAAAADgQrAGbiBgAAAD//+zdsQGAIAwAwYzGCuJEDiSswGg0KS0sRe7WSPIR1QCA1O82hDX4gXKc1WcuAAAAAGBXjqxZzZVBiy8wJ2MlJUNKAAAAAAAAwANhDTbwbk8oIiYAAAD//+zcsQ3AIAwEwB+dgUg8AquloUiVOsDdBJbcWLL+lWoAwEtdd3MosoFhiQAAAADAaWa4WsCapVSv9pd5Z7mHPxkrUaQEAAAAAAAAHxRrQJIkDwAAAP//7N1BFcAwCERBpNUCJP61REAOvUI7Y+M/FqMaAHDzhYvxcpVhDQAAAADgbxxXM03HJqWTMcmTO9sM0wAAAAAAAEBTOjCflavem3FEHAAAAP//7N2xDYAwDARAjxZGIKwZ8AoZjSYVBTUhdyO4siz9W6kGADzkeXWLIj9Q9qP6yAgAAAAALGGEqt1EmUq2/FwZQLbsvhQxGYVKAAAAAAAA8GLkJTczYlkRcQMAAP//7NxRDcAgDEDBOpuGJgiaoQ0JWMMA2X5Xdueg4bPliWoAwEK/7tPBIBsYHhEAAAAA+Amfqqnmy4F38XlKyZZ2YgAAAAAAAPBAWIONHa+zRcQEAAD//+zcsQ2AMAwEwIyWFQwZiIEieQVGo6GNaHF0t8K7+5c91QCANYNByovzMCIEAAAAALYWIy4JU03O/O3d5sxbT0YxPUZ0oQEAAAAAAMDa+1hDF8xuvrvi1toDAAD//+zdyw2AIAwA0I7GCspATiSu4GiGxCvhCs17I5RDm/SDoxoAMKBIJIly1NMQIQAAAACQ0r9EfXldNrP87z8rH/2AAbkAAAAAAAAAJp679V7wK05kMt2fjIgPAAD//+zcsQ3AMAgEQEZL9k3CCM5oblzTg+5WoEF6/RvVAICCJ5EhlkMCAAAAAEMpUdPNn092yZ6Mz9PJdYaWAAAAAAAAgEK+360zyTB1VhwRGwAA///s3LERwCAMA0CvSFiIgbhjRRr6hA6H/wncy5JRDQB452GQ9Ep9DGsAAAAAAL+yytMK1GSTJncafbQDzoAd8jAAAAAAAAD4RmeSe0TEBAAA///s3bsRgCAMAFA2U0dA3ceFVFZgNBtqrSySe2+DkCZ3+eCoBgB8aNfdFYkkMNdtNVwOAAAAAGRieZpoejtbtN9+9MgIpe7VMRgAAAD+NnlhAAAgurEzuUgkSRyvcZRSHgAAAP//7N2xCcAwDARA7T+LHa0YDK7cxJBK4m4Hdf8voxoAcCHns8JX1UKOcBIwBwAAAABaUJqmqHIDFTnSrVHNZ1gKAAAAfvLgDAAAaGEPa+hM0l9EvAAAAP//7N3RDYAwCEBBVnMEWsdUWcHRnMCkvzR3awAPUQ0AWOcTF+3lHMIaAAAAAMAOHE3TzVtXdV1G8p2IVvJM8zAAAAAAAABYUPdzCGuwg5zjP4IZER8AAAD//+zcsQkAIAwAwYzmCoJjCq5oYytaGrmbIpDkRTUA4NIqrwlrkF05DYgAAAAAAC/zLE1Go4+0YYoVA3FERSaltmofBgAAAAAAAHf8TPKD/Y44IiYAAAD//+zdsQ0AIAgEQDbXhdQRXM3G3lhC7lagI8+jVAMAPqwxu9AgBWzFGgAAAABARvdI2n6TbCoEkISoyKaZGAAAAAAAALx5Rk55EXEAAAD//+zdsQkAIAwEwIzmaA4kZAVHs7EVsYzcrZAmhOejVAMA3lkQ+YEgIQAAAABQkdsm5eTIXn1qOXIqnqeYtouYAAAAAAAAgAvPyPnAOVMUEQsAAP//7NwxAQAgDAOwScMCIBhrPAiAcyOxsLNrjWoAwCPLaxTR+hzpn3gBAAAAgH+ccrSCNNlUypTkY2SzXAwAAAAAAACuyYSpKSI2AAAA///s3VENwDAIQEEsstXPDDXBQqVNQZNlfzR3NoCHqAYA/KC8xiGevC8L6AAAAABAF46jaadmHRO4rlnLfIxucqTIPAAAAAAAAHzgGTndbW8lI+IFAAD//+zdMQ4AIAgDQH7u110cnYwDNHdfYCFpKEo1AOCdBZEEyxQBAAAAgO4cRTNUYpYkH2MaWRgAAACQTAkuAABfnWfkMNW9VKOqNgAAAP//7NzRDYAwCAXAjlZHQDtmE0ZQN3MHExNL7kbgfQEBTzUA4CWf1yiix7FrdgAAAACA34oR3VE0C7pyZrn5e860H2M5MeKUGgAAAFDULVgAAD6wKSqltNYeAAAA///s3bERwDAIBEFKcwuyC1LrSgilyIEGZrcOuBfVAIAfsrym8Et1c3zvscIGAAAAAHCZoAYVtQ1PdIyF0N6TgSYAIBlgAQAAAABOcozczyQV7W+MImIBAAD//+zcSRHAIBAEwPWvJbAWkMYnAlLFJ0x125jDqQYAHOoxPa+RQCkdAAAAAPiddwRtCM1tVj+dXjCKPQ0hliwMAAAAAAAAvpMJk6OqNgAAAP//7N3BEcAgCARASrMFZyzThBYzduAjj2B2a+AH3AnVAIB3CNaguqaFBAAAAAD4IE/QVHT8cVHOtFOgmtZHN7cAAAAAAACwIa97FUmcXibBX0TEAwAA///s3bsNgDAMBUCvGBiIhQCvwGg0KVMiEcPdFJZ/z1MNAHiAIpGP2Nq6SHwEAAAAAKbQj5/1LKnmyj3/MjOSTEQ1HjUBb7FPAgAAAABAOXmcgsgpZxg8HhE3AAAA///s3bENACAIBED2n8XEGdzMxtLSGNC7EagI+TxKNQDgEEsijxAmBAAAAACycK+kom+KJnrr2yAKZLYKmwBuGyYOAAAAAEBRni1QX0RMAAAA///s3dEJgDAMBcCM1hUK3ae4j5oVO0HxR4Tg3Qr5zMuLUg0AeJdiDapruzY2AAAAAICvOHqmqCPP/Nsnersxqpl99GZqAAAAAAAA8CyvW36D+iJiAQAA///s3LENgDAMBECvCAwUsQ/gFRFSOhoKJGRyN4IbF/+2pxoA8KLcj6soOVpZkv9p0zIrEwIAAAAAn+jHzs30qSa3HK5M1J+IyMaoxo4BAAAAAACA51azopB7HhwRJwAAAP//7N2xDQAgDAOwnsbDhRdZ2FmQENQ+I4oSoxoAcNjI7pGLHygTAgAAAAC3yCd5UeUSkQIVr2lrwAkAAAAAAADYGNnLHUzwmYiYAAAA///s3bENwDAIBEBGywq217TECh4tTRZwkSjIdxPQ8hKPUg0AeIdiDaq72ugWHgAAAADgU8+Rs0NnysmZx2bqOXNFxPrBKLBDgRMAAADb2uiySwAA4FSeLVBXRNwAAAD//+zcsQ3AIAwEQI/GCkjsw0TAihmAioJITu5GcPv/9lQDAC5YYyoP8gVdAAQAAAAAvMzImYyUh9yAfEpt1YN5AAAATulUAgAAv7TGlK2RxraJjIgHAAD//+zdsRGAMAwDQK/GvgGtSJOGLk24M/yP4NayrFQDADbJeR1mywcIsAMAAAAAr5jHzULptJOR34eHMqJwno7swQAAAAAAAGCdZwt08cwfVdUNAAD//+zdsQ0AIQwDwIzGCg/770LzEiUVSBZ3a8R2jGoAwFmGNUjXvtGfDwMDAAAAAFcoN5PILWgRoCLOP+gEAAAAAAAA7Hm0QKaqmgAAAP//7N2xEYAwDANAr2jIPlkI8AgwGk16qhTh/kdQq7NsVAMAJqrz8pWLP+i5b75DAgAAAADTZMtbuizoqaP0QMPIwrAGq+nZUg8GAAAAAAAAH9xKsqyIeAEAAP//7N2xEYAwCAVQNstqDmTCijY2prKJJ/reBNzR8Q9wVAMAFss+fCjjC3yIBAAAAACWOJeZLTRTkQMSk9xze1VBcI8cDIA/aroOAFBf9mEeBwDA0+TkVHDNgCPiAAAA///s3bsNgDAMBUCPlhWANSFegdFoUtJQEMnK3RKW/HkWqgEAcwjWoLq2HbvGOwAAAADwB8fMVHTnmT7wvLNERTVtBDwBwErUPgAAAADgs7y6OTn1RMQDAAD//+zcuwnAMAwFQK0Ye6AsZPAIXs2N2kAKYxDcraBG6POEagDABdksahip7n16c1QBAAAAAByTT8zmjlQkOOLDHFNINxUtVQMAAAAAAIBf7MupJSI2AAAA///s3bENwDAIBEBWywiWMmZsVshort2kSiJh3Y1AQYHgEaoBAD/JPg61ZgM+RgIAAAAAb3LETEV3XilM/ZklKsppZxMIA3wi+9BfAAAAAADYhrk3FSzPxSNiAgAA///s3cEJwCAMQNGM5grVNYWs6NGjQqE08N4OOUjIV1QDAL4lrEF17RndwwcAAAAAeM3xMlXlTPueg5xpvqlIXB4AAAAAAADu+IiCv9tRjYhYAAAA///s3LEJwDAMBECtaMg+JgM5HsEezX2amBQBhbsVvhE8eqMaAPCh3q7pYOQH6n2pDQAAAADgBc/LZHRKbZvxEdIpRxlSAwAAAAAAgEe6c/KIiAUAAP//7N3BCYBADEXBlGYLCxZkQau/RY+eBPEgRGZayDV5EdUAgI9lPywQ8gcWCgEAAACA1xwt01VmNsN7JjNi83S0jHWIywMAAHBHKBgAAOB6Pg49VNUJAAD//+zdsQ0AIAgEQDZzBnX/XWyMraFSkrsJCC08OKoBAG84rEF5fQ5L7wAAAABA2g4rCyxTkU87eXpGRQJSAAAAAAAAcGcezM/aKS4iFgAAAP//7NyxDcAgDEVBj8YKCQtlICSvSIOUioIqsXS3AuU3T1QDAD6wSmxqbFTXrn47fAcAAAAATvmsTEk58vFyZ3KkTYyK2gpAAQAAAAAAAHu2YP7s3XwjYgIAAP//7N25DQAgDASwrMbAwAisRkONEA2P7BEuZXSJoxoAcEjNJcmeDzRDBAAAAABWjZKyojIv8mFnn+x4kR0YAAAAAAAATIzH43C/iOgAAAD//+zd0QnAIAwFQFeMdqAOJGQFR+sKpT81crdCkIQQnkI1AOBfgjUoL0Z3VAgAAAAAvGWfSEUrZ94q903OXH4ooqK4wrsH4Ggxul4HAFCbMFsAAHZgLmV/rbUHAAD//+zdsREAIAgEMEZzBXUgV7exprFQ7pIRoP0HRzUA4KFzjU2IkOpan8NnSQAAAAAgpZxMYUJA98yQipatAQAAAAAAQEo3kv9FxAYAAP//7N3BDYAgEARAStMSTilTpQVL8yFfXpooZKYE7kMCtytUAwA+VvZjNgMGoF0SAAAAAGiKHJPlZDp1lq34BPRQPUPBGnQncngDA97iPgEAAAAAwHBq6Tj8UqzLXQCUUroAAAD//+zcwQnAIAxA0YzWFdSFOpDgDG7mxWtPlaLlvQUCuSZ8UQ0A2IOwBsdLJXsqBAAAAACeCGpwKiGIRVpt9yeDYK1rhqEA3uo2CAAAAADAT7mrs7eIGAAAAP//7NyxEQAQEEXBK00LaNOMFpQmkcgFbma3DP49UQ0A+MApsqmykV2pvRkVAgAAAACXc4zs7ZCM1hzT/81bxlRkJAwFAABA2EcCAABAUhGxAQAA///s3LsNgDAMBUCPBpsxEIlHYLU0qRAlRT53G1ivsiw/pRoAMIgs9ZQFC3iECAAAAAC8eEZmVgogfpZ3XksNxC6OXhAFAADA3uyGAAAAH7JUd2DGFhENAAD//+zcwQmAMAxA0WzmDLEOZPcRukJHE3r3KDTw3gSBHBO+qAYA7EVYg/KyncIaAAAAAMCSV96ezSmqj2dMy/uFWAkVuX8BAAAAAADAN/d1dnSsoSLiBQAA///s3UsNgEAMBcA6AwuAIAwBtQDOCFkkQLK7mZHweumhH0c1AKAiuR+nBpIOjNMyG5IHAAAAAB6rFGhRbumTzk9kS6veQ1EA0JNBNQEAAACAj1yCpEJlxzEibgAAAP//7EHFnfAAACAASURBVN3RDcAgCAVAVnMEk+5jHEi7Yqdogni3AfEDPuApVAMAknnXboI1KMBvXQAAAABwOcfHHGx6vN+14vVR0+hPFywPQCX6GgDA2eybAwCQifmUvCLiY+eObgCEQSgAsqI6UBeqZQVH648rmEC8W4EPCIEnVAMAanKsSXvHdQrWAAAAAICfep+Oh/rTUc4UCPOxnPk4qqIpvQ0AAAAoIe9lvwYAQBnmU0qLiA0AAP//7N3LEQAQDAXAlKYF9N+LiwZcTMJuCTmZfB6hGgCQ0H5ECtagutbn8KsJAAAAAPzJ0TFVmc/co9ZU1HZwFMApy8QAAAAAALxOL5ycImIBAAD//+zdwQ2AMAgFUDZztQ5UZYTWzbx4NvFi2vreCPwLCQEc1QCAQeV+FI0kC2hCBAAAAIB/uZeNLRwzo541i+S+kTW7WRiTcjgKeM2HPgCAJWxiBAAAeHQqD0OKiAsAAP//7N1RDQAgCEBBolkBNZDRbeCnk3kXgU/YHqIaAPA2H7ooL0cX1gAAAACAv9gJUpW7zH1mTkUtZwrwAAAA/EdIGAAA4Exgmufk6CsiYgMAAP//7N1RDcAwCAVApM1CO0Ez1KQWKm0/JHOwlPROAnzyAEc1AGBj+alEmJDqrnZ3wyQAAAAAOIAlYwpbc0wBn59lzdWdih5dAwAAAAAAgE/uQsJ+IuIFAAD//+zdwREAIAgDMEZ3IXVFX27gnaDJCLxpq1QDAJKbfTTPhDzAMiUAAAAA/EHImKqUnN/j9pSkSAqAF+yFPgAAAACAQ+QgySciFgAAAP//7NxBEYAwDATASMNCoH4wxEwttM744KENsysh90tu4qkGANSgTEh5eZ0eawAAAADAj2VLO0CqGv3pij2LfLN3C6OiO1sekgMAAAAWsM8EAGBXUzJsJyJeAAAA///s3UERwDAIBECk1UJSQTWUBIv9VEB/GTK7FvjBAY5qAEABOZcwISe42t0FCwEAAADgQN9Ssf4fVZnBbJYjfUinqkflAAAAgA0sKgIAAPwVES8AAAD//+zdMRHAMAwDQEMrtABqYwqB1sUAMsa5fxIefJKUagBAE/nNoVWYC1iqBAAAAIA7CRXT1co3/V/OoNyEjp4qlgLY4dYBADRlUAwAAGBPZSDhLBHxAwAA///s3EENwDAMA8BQG4R1NCuFYj8FMUd3FPKLbBvVAIAsAhbEe79lWAMAAAAABrllYqFyIvXux+X+oXcLV5HKsBQAAMB8/p8AAACQqqoOAAAA///s3EENACAMBMFKwwIJflAEWEAaD0xQMiOhfV6yohoAkMgacwtr8IGi2g4AAAAAXxHSJSuby3v8hIxKbVUUBgAAAAAAAK7tDjykR0QcAAAA///s3EENACAIAECaayCVDDazhA9xdxGADR6ApxoAUEzO1Q2WfMCSPQAAAAB8wBExleVI9fsYOaGwJnkAFKWHAQAAAAC3bRHlKRFxAAAA///s3VERACAIRMGrZgS1fxdrcONuBH4ZHqIaANDJly7q7XuENQAAAACgnwMsWtm1zLV+HwCdhKYAAAAAAAAABkryAAAA///s3NENgDAIBcCO5gqo+7hQLSs4mnEIk6J3I8APeRA81QCAgvIcl2NPPmCJbXVcCAAAAABFxR4e51JW9pRPTyp7Pnuw6+91oKQj9li0DgAAAHhbnkO+CQDAtMyrTKe1dgMAAP//7NyxDQAgCARAVnMEdSBXt6G195O7FWiAPHiqAQChurkUKCTdmXsJFwIAAABAmD4attsj1VC573kuT6qjcsCLEDEAQDTzHgAAAKSqqgsAAP//7NxBDQAgDAPASUMwySwgjQ8iVnJnob91qVENAMjmoZAfKJsAAAAAII+7HqlO7zZaPtzLSE4kWm94CgAAAAAAAIAJquoCAAD//+zdWw2AQAwEwErDQjlsAhI4aQQRJCyZsbB/fTqqAQDBzv2YDmvwA0uP1UceAAAAAAjRWz/1PAvDpNJXySErUl2SAyCJmQ0AAAAA4AX6vXxHVd0AAAD//+zdQRGAQAwDwFoEBB2COGoBaXzOAxNm10KezaRGNQAgXM/79KmLHxjbsSvhAwAAAECGISdCPX21m0qIlZW8iLQGqAAAAAAAAAD4WlW9AAAA///s3cERACAIA7AZ1YUc3Rn80V6yAs9CUaoBAB00t9HAIj4AAAAADOdImHDylDxmRiq5FwAAQAkPwxhIES0AAMCHdfZ9AAAA///s3NEJgDAMBcCO1hUCHVPNCNbNRHCIptyt8H4CL4mnGgCwgTyvaamQDfRvQBUkAAAAAKwpRnRHwhQ280jL5sX8menAKClG3JIDAADYgqcarOaRCAAABejnWUdr7QUAAP//7N0xFYAwDEXROANnVBAQi106IIAh6bnXQpY/vYhqAMAm8nmHsckGLlV3AAAAAChLUIPOhBmayjsFuenqXEEqgC+bhIoOVwEAAAAA/rSeiEMNETEBAAD//+zcQQ0AMAgDQKzPzxIs8pmIldy5IG3xVAMAdlG+YAPFfAAAAAD4zBsFGwaT6vRthZ1sMjBSyb0ASODWAwAAAABgr6oaAAAA///s3cENACAIBDBGcwV1TRNX9MMOimlX4EeOQ6kGAHwkG9yECqmu9Tl8nQMAAACAtzgKpqy9tp1zcWZIYS2LqQAAAAAAAAC4ISIOAAAA///s3UERgDAMBMBYTMEPNQRIwFqnFng1nV0L971cjGoAwGbe+5mlQt/WqO7KoykYAgAAAMAC8szuczGFGSPfhyyp6pMcAABAaQaHAQAA/nHjyBoiYgAAAP//7N0xDQAwCARApFdQEzTUWZc66ALkzsJvQB6lGgAwk6NCJrCIAgAAAIAazOpoK3cu6c0gSzp7BVUAAAAA394DRgAA6OBIiRIi4gIAAP//7NzBEYAwCARASoslROs0aSGlOZMmFNwtgSdwp1QDAAqa91iKNSig9eu0+AcAAACAFwkBk5xbST3H3wdAWgqqgE34ja/ynwEAAAAAQFkR8QAAAP//7NxBDcAwDAPAQiuFbOUzQpUCYYW2zzBUSnVHwc/Y8VQDAA71FzGWfCnuifvqQgQAAACA/WJENwKmsJUzDQMPkzOX+xdVxYhXeAAAAAAAAACbtdY+AAAA///s3UENADAIA0CkzcI2/172mQdScmeBHyVFqQYAzOYDGxM42gcAAACAHnZzJJORzGW2pFq/sAoAAIAQ+x6lrQAAAJCuqh4AAAD//+zcwRHAIAgEQEqz4CgtUFo+1pBRstvCPeHOqAYANJZzlcdCGhgOUwAAAADwrV36VfzlVpVPlvR62tnKl1sZrAIAAAAAAOAXci59MM4QES8AAAD//+zcsQ2AMAwEQI/GCsBAGY3V0ngBGsQndyPYjWW9XqkGACyuj0/BQtKN874E+AEAAADgO49ZE0zh+PrsmFRHF1cBe5Ph4I8UPwEAZPAXAwAAeKuqJgAAAP//7N3RCQAgCAVAVwwaM3CF2qyfZgisuxH0T/QpVAMA/mCAygsscAAAAADABa03n0KobOZIh6qPOz3WZ6oSXAWs7ysAAAAAAABwS0RsAAAA///s3EENwCAQRFGcARJadAIWG0T0MOE9C3vbTL6oBgBcYM91RoXdrQnXnvEa8wMAAADA/wRuSSY0fg+3JpaAFQAAQAy/UgAAAEhXSv0AAAD//+zdQQ3AIBAEQKRh4Qp+MNQEC5XGBwtNemXGwj73smdUAwAOsYc1fOwiuxHtqlIEAAAAgHdED9/zyeyZ99SFHGJnbViDrEb00HkB8CnuMQAAAAAA+KVS6gIAAP//7NxBEcAwCARArNVZBSXFYj610EkouxLgA8NwQjUAoJGcz6Xf/IDkdwAAAAD4wPvc64mKsnKkO0gzOfLuXgNKc/MC4DT2QQCA8wkVBgCgGjMs+0XEAgAA///s3EERwCAMBECkYQFQVEGABpz1UwmdaTPZtXCvTC7xVAMA8lEoJbraRleSBQAAAID3Oe4lskt6acmeqOrz0ApIZs9l3w0AEEAb3czG7+y5HCQCABDNkRifK6XcAAAA///s3LENACAIBEA2dyETVrRhBAuRuxXonvwb1QCAYSpMFajS3fKwAgAAAIB7qtQrc6Ot3KmcOpTb05xBKwAAgHfJSwEAAOAHEXEAAAD//+zcQRHAIAwEwEhrJTCDoQoqSMAaJvpoyK6EXJ43Z1QDAAqa77jlzgGUDAEAAADgO8stSewRXnl+gKyu1pthGAD+Qg8DAAAAAIDzRMQGAAD//+zcQQ0AIAwDwEnDAmCTBAtIwwKB18KdhKXPtUY1AOBfhjXIrtTePBkCAAAAwCNlXrKbY8rw52SA5BSYAQAAgBPLlQAAAC5ExAYAAP//7NzBEYAgDATAlGYLYkFWJLQAnfmyAfiA7LaQvG6SU6oBAJsqT67CVX7gPq90GCQAAAAADPHMy8qUiPOxCyxLwRVsyb0GAMD85KbMppkIAABAh4h4AQAA///s3dENgDAIBUBWJOk+LqQyQh3NxDiBX7a9WwG+CDyEagDAwuo4LRcyg66KAAAAAPBNtjRfY2RX7eUglcfbC/qBUW3ZUpA8rMUxHL/ksQkAAAAAANOJiBsAAP//7N2xDQAgCATAX1GdyM1trOzsxNytAA0JPEI1AADBGpTXRrf4DwAAAACX9vGugykqm6rHQU9QmQ/IALzAjAgAAAAAwF+SLAAAAP//7N25EcAgDARAlUbBBrXg0kiUEBJ5wLs1XKbnPNUAgJ/LPrR2cYOmLQUAAAAAtjne5WRvPmm+waIyIRecqtXDKwAAAD5mHxEAAAAuEhETAAD//+zdsQ2AMAwEQG+GGCESA4WBAiOwGoIeidKGuxHyLiIXb6UaAMBVrDF7BT7gECIAAAAAvNOW1l0gprhVgDwwG1Sm8Ar+QwkUWU2SAYCb3Snp7GPrUgEAoBr/WFKIiBMAAP//7NyxDYAwDEVBj8YKkDUhXoHR0oSOghJHdzNYcvWfqAYA8BDWoLy9HcIaAAAAAPCN0S6V3XmmISqv5m24D6raZvgKWFxe3a/irwyIAQAAAABYS0QMAAAA///s3MENABAQBMDrjBZQkc4l4s1TyEwLe8+9NaoBAEyrsKG0wetyaVXBAwAAAAA2POvygS5EDtwILzN8BQAAcF+SAQAAAHwiIgYAAAD//+zdwQmAMAwF0IymIxRcyH3UjOBqgogn6cGLrbw3QhoIBPIrVAMAuOW6jarBD+weEQAAAACelakMjnXp3JxLCgmn6uoRwRp0SwAWAF/ymQkAnMxDWmMnCgAA8FZEHAAAAP//7NyxDcAgDABBr0gYiIUiMQOb0VChFFEqHN2tYEuu/KIaAMBOWIP0Sr2ENQAAAADgmaAGqfW7ezTnFbtCcm2FsIB/8xTHqdwgAIDzDDMBAAD4KCImAAAA///s3TEVACAIBUCiWc1AagWjubg4uinvrgJMvA84qgEAHEbrU3CDBIrPKQAAAABw2su55mb8rKoel/QMP3MIC/KzFAcA8CDZQwAAAEgmIhYAAAD//+zcsQ2AMAwEQG8G2SwDQTwCq9HQICqaSEnuRni7ceFXqgEAfOTZilSYwGWIAAAAAPDiOZeh5ZHVBPnDzjC4/SnEAoDeNokDsDi3GAAAAMwkIm4AAAD//+zcuw3AIAwFQK/owEBkM0ZDGSANDVi6W8Fu/NETqgEA/BGsQXnZHsEaAAAAAPDtynoOz+AU9yogm/QOlbl1AXCC2REA4D5TTQAAADZFxAIAAP//7Ny7DYAwDAVAj8YKwEAwEIlXyGg0KamokuhuBH8ay3pCNQCAT1lqc4BlAdt+Hp49AAAAACDiUgMm1vLJWwP5w+wwux6MBSwoS7XfAABjcktlOP2vGwAAgD8i4gUAAP//7N3RCQAgCAVAV2uEoIUaqFqxCfoKgupuBP1T9HmqAQAsjdaT6vAACV4AAAAAfC2XbEbG7aoOssnOi5s55gLgOAEmAAAAAAA8IyImAAAA///s3bENgDAMBECvaMKYkbJCRouQ6CkokMndDN9Y8tuOagAATywZUl62Q2kAAAAAgC3lmVcRShmKyubowxdGXrkzJEeU5UAWAB8wRwIAAAAA8A8RsQAAAP//7N2xFYAgDAXAjMYKwkI6kLIiDTWNFoB3KyRVXt7/QjUAgKF6P54M2UHSogIAAADAT2m3Z3WXCfIRu8TKUg/KAvbjHwMAYCJHyad5MCF3LQAAgDciogEAAP//7N2xFcAgCAVAVsu+GlbQzWzs06SI5G4E4D2qD45qAACPst+XKlGAD14AAAAA/MoO3wrgcrKRLQVNecWeJfPEyRzKgpqmvvJR9g4AAAAAADVExAIAAP//7N0xFQAgCEBBmmkFtX8XFwM46IDeReAxMXxENQCAXcIapNdGF9YAAAAA4CfuYWTnAyOn2SkyqyuYBQAAwD3FbAEAAOAxETEBAAD//+zd0QmAQAgAUEdrhasGaqDKFRqtnwYILqK73ltBQVBRRzUAgFty233vogdDmUbLhgAAAAB0r8xlEWUad+Sa5hI86sopeUXLHMwC4DX2KwD4KfWPL9LPAgAAqBERJwAAAP//7N3bCcAgDADArOZkxX2qWbE/DlCEgtq7ERLylZejGgDAa9l6ES0OYNgQAAAAgD+4ZJmd5Z16Enyliiw7czgLzpKtq2lWZqkYAGAB4zEiAAAAsyLiAQAA///s3DENACAMRUEsFjCEHxIsIA0NDAwldxo6NT9PVAMAuGXESnrRqrAGAAAAAN+KHv5fZCd6wDNrru3GSE44CwAA4IFoVfAMAAAAflTKOAAAAP//7N2xDcAgDEVBj8YKThgTiRXTsABFkIzuZnDr90U1AIAtq3aseEx1Ld/HogoAAAAA18mezZow1c0xPTDwKzdGdQJaABwi5AQAAAAAQH0R8QEAAP//7NzRCYBACABQN7tutAaqVuznFoiDUHlvBBVEUD3VAAA+e657ihoNWDYEAAAAoCNHT1R3yiA/UWtUdqxHWkAPehIAQA5DHkjIvAAAALArIl4AAAD//+zcwQkAIQwEwLSoNmRBgi3e5yoQFIwzLSQQ8thVqgEArFKswfVKq4o1AAAAAEjjD9cK2HK1OWY3QU6waySgSAuA7UqrfkwAXuLuAQAAQEYR8QEAAP//7NxBDQAgDATBSqthwALS+KCABJKSGRN99LKiGgDAkdH6VD/mA2kAAgAAAMBHRGSpTtCb1/y6qCx3UAsAbnJrAAAAAACoLSIWAAAA///s3YEJgCAQBVA3awargRrIuhFytAiaoCC03hvhDkTO4ytUAwC4Ldbt/MGrqiCd2wVrAAAAANC7POdFE+lcjRLeHHhVlHB20juBWvAN7kC0bNAdAP4gT6MZAU26drUBAAB4IqV0AAAA///s3bENACEMA8CsxmQ/EbDiN2xAAUZ3IyRdItlCNQCAXRq8eMFniwAAAACkWi31blyk82/glGbyJBOsBflmH0I1uJmSEgAAAAAAslXVDwAA///s3DENACAMBMBKwxmGSLCANJYqgIGU3Gn4qfm+UQ0A4EqWOxRdqa5ZmgcAAACgMIMaVLfmmJ5JeSKzJ39U1nNgCwAAgHNurAAAAPCriNgAAAD//+zdwRGAMAgEQFqMKUgbMmkxHzuIM4izWwMv5g4c1QAAts17XMKG/MDZ+iFwCAAAAEApT4nWXovqHO8mmxmkOuUvqE/mgs/ypAQAII2dFQAAwBsiYgEAAP//7NxRDQAgCAVAohnYzQrazB8j6BR3VwF+YPCEagAAu1jc8gMHhwAAAABkY6dFdr3V5omUq1YP6kMyKytoC8hrqB0AwB0CpAAAAM4xc/GEiJgAAAD//+zcgQlAIQgFQEdrhaA1qxX+aJ92KMi4m0EQFZ9QDQBgi9nHJ1iDBxTDGgAAAABZ1FbXLssDLdm5LXALtUh2grYAOEWPAQAAAAAgr4j4AQAA///s3dsNQFAMANBuxgoYCPugK/q5G5C4lXNGaJr0oy9HNQCA1+R5bb548QPrtMwWEQAAAACowGIT1e15pL4CXWi5KB+pbGwHt4Ca1CAAgO8MYk+P2lw2AAAAT0XEDQAA///s3cENACEIBEBa1GtTpcVrwgeSmRp4kBB2hWoAALdp8aIDzwgAAAAAlOZplg5ypTmmGncuXufGBY/KfYRqUNr4pt0dgM6UcAEAAEBnEfEDAAD//+zcSxHAIAwFwEirhbTIZAYLlcYFAT30EJhdG+/jVAMA+NUqeigcsjshGQAAAABlZcvLaJYDyBIoZ/Qh52J7jrcAAAC+y+fWFQQAAIDTRbwTAAD//+zd0QkAIAgFwNFbqHKFRougEQos7mbwR3g+lWoAAMdF6yuo5YsKAAAAAMAdCjV4XtRw9E1KZpMPlF3ABbxHzoLM7KEA/Mr+RFaKXwEAAA6J1scEAAD//+zcSxEAIAgFwNfM7DbzYgRlxNmNAJz4eaoBANyimQsAAAAAcNg+krXoTXdmCLxOjdKdw2foacobAEC5IeQAAADwuSQLAAD//+zc0QnAIAwFwIzWFbQLdSDBFRxNhI5goYa7FZKPBJInVAMA+MRK73JwCAAAAACwnSdZTjd6648q8md6lASuN4gLALYpdzUjAZCR3QkAAACyi4gJAAD//+zcywmAQAwFwLQYtSAbUluwtEWwA3E1y0wJIZd8eEI1AIDXHNt+HdNPFQYAAAAAeC6XXD15MwCB3FShV6lOEBcUc/9YAADQSc6TXSu/ZT4AAGAgblZ8LyIaAAAA///s3EENACAMBMFKQzBJLSCNDxLKozDj4pLLimoAALc5HAIAAAAA1HA0oLuVM8W4aSFnisfT3ThBLgCoYpMC8BpRDQAAAPhBRGwAAAD//+zcwQkAIQwEwLQo2KZnCVqaFfjyBJWZEkI+S8gq1QAAtqrl64o1AAAAAADWpJyaEfIA9wJuY2e5nednAACAOZmJUyl6BQAA+FNEDAAAAP//7N1BDYBADATASsPCAYIQBNQCOOODAsIllMxIaPfXZKtUAwDoLrfdJy8AAAAAgIfa3AZfE/mBI9d0K6CUO7NyS2mKuaAchU58WpvGxYYAALo7jRgAAOBFEXEBAAD//+zdwQ0AIAgDwG6m+0/lxwmMMQHvRiD8SopSDQDgFYcfAAAAAABnfEykAzkBVdldqpu7oAsAbhimCEAHiqIAAADgI0kWAAAA///s3MENgDAIAEBWVCfqPlpW6Gh+uoAPTTF3K0BCIICnGgDAJ/Lqw9IhAAAAAMAz8wjWISzVtTxziCIVzdyVv1TnQRfUoeawOv0pAMD79AUAAPzCduzmiaygRUTcAAAA///s3bENwDAIBEBGy2gZKA4jeLU0XsBNBNbdCHS80KNUAwD4TY73FvQCAAAAAGyZxkV3+aTPn3SnOJ7urlXUBRS3HpZAaQ7hATiE8kHKshcAAHAQWSI1RMQHAAD//+zcUQkAIBBEwasoGFO4Ckazgh8ieM7U2OWJagAAtzkdAgAAAABsaL0JEVCBXYDn5cgpHE8BQl0AnOIID8DTBKIAAADgMxGxAAAA///s3cEJACAIQFFXa9/AFbt07xKh8d4KngT5imoAAE/terIDWgAAAACAM98SaS9nisPwhZw5TJLuBLugDTcVVGdXBaA7UQ0qsw8AAADcFhELAAD//+zdwQ0AIAgEMFYkcSAXUld0Ar8mYjsDH5KD81QDALhujdm1eQEAAAAAnGVLbfJUIABONWaa1zmCBgAAsBsBAADAXyJiAwAA///s3VENwDAIBUCkzQLtBE1Qk1qsgf4u68idBfiAhDyEagAAX3F0CAAAAACwkXdeviVSwRzzUUgq0dNUILgLfsGTEo6XvZmLAADeYR8AAKASoYacISIWAAAA///s3LENwCAMBEBvRhiYZAVGo6GkRIpBdyt8Zfn1RjUAgF987e2GNQAAAAAAlpQKuEGVIpfy3+J0zxzwApKafQrIrkgIgBMZhiI79wAAAMB2PSJiAAAA///s3EENgDAQRNG12ARBCCqMBaQRuCCAA2l5z8VuMl9UAwD4TLZ9VVQGAAAAAHi0pV1/U0NXRnekx/+fKaXH+IYZCHgB8Ja7FYBRCUMBAADAj9zxwqo6AQAA///s3dEJACAIBUBHawWr/WfpsxEyuZtBkCeojmoAAK/55gUAAAAAcFlypQOzf7pT4/xu5E7L0FCbXkN5Pv0D8ClZiMrkAAAA2sg15S/qiIgDAAD//+zd0QnAIAwFwKwodEwhI+hopdANClr1boWEfATyIlQDAJjqTfqyBAYAAAAAjleu4iCJHfSs2VWSnWXNZ17rc1bXVBCAj3z6B2ApAqEAAACGEqrBf0TEDQAA///s3cENACAIBDA2dyJ1RT+uYBRpRyB8SC6HUg0A4LrZh+AhAAAAAFDa/hbfqs+BLyjSpgq7TnoKveBpMhRkIBQPQDYKoXidOwAAAOCEiFgAAAD//+zd0QlAIQgFUPefpXKFRuvnrfBA65wZBBXkKlQDAKjC4SEAAAAA8DKBGtxg50iH3zzhq3X1TnfmDygq59JjaMHHfwCaEQhFafYAAACAn0TEAQAA///s3VENwDAIBUCkbRJIKnNJJdTaPjYR0N5Z4KcB+hCqAQCU8DeCBWsAAAAAAMfJkZeFbnYwn3krJIcx26K9HLlUEcryoY4OXPwHoAVBUDTg/Q8AwG6Eu1PBN9OPiBcAAP//7NxRDcAwCAVApFXaBHXDwuasP7PQhLZ3FviAAHlCNQCAMvJ+LkthAAAAAOBAHgnYgXABjpM9X7ctNtD+gC+gnk9NWIAeAsAqBEFRnfkfAABglogYAAAA///s3UENACEMRcFaJFlBCIKtRTxwAjojo0n/M6oBABwl569iBwAAAACU0b7WPSHxghyp9klVBmV4gYEvALYp/wNwCTdYAAAAqCoiFgAAAP//7N1BEcAgDEXBL62C28YC0nqpiAR2NYQZOOQhl49sMQAAIABJREFUqgEAdCSsAQAAAACcwhIrOxAV4Fh110qyTADDXX/oC2iknte5ZAo//wPQmgAUE7j/AwCwE+8w2knysXcHVQCAIBAF6Z9F3Yp28MTDmQwc4SOqAQC0k30sHwIAAAAA4zleZYqsmGW+lhXBeCYQ+gLglc//AHQnAAUAAAA/q6oLAAD//+zdgQnAIAwEwIzWFYQu1IHUFQvtEm+4W0FCguhHqAYAEGnP5fEhAAAAANDWuMfl8ypNPA4SPmqB4wn8gkj6C0eweRKAcAKgSGfuBwCgG+GGRNhz/XfXVfUCAAD//+zc0QkAIAhAQTdvocAVGi2CFugrkbsd/FKfqAYAUJmwBgAAAADQlaAGHayc6XkOzjGOWaCHccNfAPDKkTwAJQk/AQAAfGHfRC0RsQEAAP//7N3BDYAgDAVQViydUx1BN9OYcPHuoZD3ViAkbfL5KNUAAMo6tv16A7lOCAAAAABYyXisKkDACvygCF/uBCtQ/AW1yEwwCzsuAFUpfmIG5n4YIvsZ2e/IbscAAOA/rbUHAAD//+zd0Q2AIAwFQEbTEdQ10Y6Ao/khH8YJCrlboQkphL4K1QAAUovzWlUIAAAAAJhMU1AmcEcNn73hI2rYfssMlh4ABiTQl5HAELZj1wsBkEofyHa/IT19P7x+53YTrAEAY/JOSEqllAcAAP//7NzBCQAgCAVQVwzaJ9q8YxDduqS8t4KECvmFagAAGQjWAAAAAABKaL35PEAVUyXhytuggqGK8BUHdmShfwDwG8fYZGDehx2ocYbSC9YAAODF3rciYgEAAP//7NzRCYAwDAXAbKajOVAhK9jNRBQE0f+03K0QKO0reUo1AIDy7gZmoTEAAAAAMANLRsxgz5Zye/iQLTf/WkxgVQQGpXTjYBQW3gAoRhbLCNz34fJ3Zp/FGu+yDQCgtsV8KOJ5b0XEAQAA///s3MENgCAQRcEtTUsgsSELElv04pnzfjLTwgYICTxRDQAgwvvM06QAAAAAgGTjGh79sYvbJGHJGmEHPp9BH2JNJHF+ANCC0BNAjj+asdq3D2ENAIjiPkY/VfUBAAD//+zcsQ2AMAwEwIzGCgYGgn1IsiINNaIjhrsVIit6yX6lGgBAJoo1AAAAAICUYo3J4gAfsfejO+yEG9eMmBPSizU2rwjv67X5U8hE7gVgFIqeSKHXJnvza7HM28McoVgDABJQcMiwSiknAAAA///s3MEJwCAQBMDrXNJPwBINgStAX54yU4IfEXfXqAYAcIwMigiLAAAAAAAnEuLmCv3tQt4w53FOXKDlMBgATMtSHADs5i0DUFyWblf+z/5hjaGsCwCluaepKSI+AAAA///s3LENgCAQQFE2M+4r3AisRkNia2zk8L0NCAUXAl9UAwBIJWo77RgAAAAAkMn8jOrhADsQCYCH4gqxeHYhDAZrMIeRibMDgE8JPJGIOZ/fmmGM/nL9XVgDAJZ12BpWEbXd9wOllAEAAP//7Ny5DQAgDARBl0bBSLRIQgE8AQbNFAGJb0U1AIAXCWsAAAAAAC/ZPQqEVFptBgmwxjCCH5QRCAOAaQZuAFwm8ASQ3+lbLawBADn5n8kpIjoAAAD//+zdwQ2AIBAEwGsRtUyVEmjNjy9/JiZwOFMAX46Q3VOqAQCkU4/TZi8AAAAAIIWyFSUEzEI5ALxU9+pPi1kIpEFnz21qkIC7A4AuBKzJxJzPX5V1aR8Fbtt9FgAwAO8xhhYRFwAAAP//7N3BDYAwCAVQRqv7VlnRi5cea0ykzXsrcILCr1ANAGBJeV6HygEAAAAAC3BIxBaypwVveCF7etNiB01QGACTLNAD8BfzWIDCnmPbL/uFJlgDAMowE6SS8fOLiLgBAAD//+zcwQ2AIAwF0G7mDKgLORqbefHi2VQLvjcBgQQItF+oBgAwMkWIAAAAAEBZbW+K+JiF93h45jB/TEBjGnzPecJQ2rYKZALgVQmN2pDJ/Z7fufbpjL8zwRoAUMNiHSik38YSEScAAAD//+zc0QmAIBSGUVcUGtO6K7hZEfTYS4Rpcs4Sws/1E9UAAH4r1q3eVcMAAAAAAHrLS3bAzSxqlLDFwwtRwodSpiAYBsBDgkwAfM0eCzC2ltvSGdbYr3AHANCHd5hxpZQOAAAA///s3UsNwCAQQMGVVguATkBCrfVSCQ3lM6MBAiHhragGALC0XpvpeAAAAADAjHweYhcmJsI37CV2cL3hMOAHvTaRJpaTSrZuARjJmyzLcL/nNKnkUbHWW1gDAMZz/jK9iHgAAAD//+zdwQnAIAwF0KwodKAOJGSEOlovvfVYSFXeWyFgApqvUA0AYAeCNQAAAACAabSjnX7gYBMjew7FhO+yp0UJdmFJDf5lNmM1+gYAJQQ5AczrOaMr780ufQEAynkjw1ReQYYRcQMAAP//7N3BDYAgDABARnMF1H2MA6kjqJv5cQQDFO9GKJSkTQGPagAA4R3bfhkcAQAAAAAa4tIQvVitJHxKTtGDIc/ZYCTUc4s90filEoBC9GSJRI+I33jrgRpn9JKn8bTTAKAYNRltSyk9AAAA///s3cENgCAQAEFK0xJQC7Ig9FqwND+WAEHITAs8SC6wJ6oBAEwhrnt1kgAAAABAb/nINl8xiydKCFpDRVHiFIpnEj4kQD/uEUbkQT0ATeV9M5MF+KEvqNFzjrQIawBAe6K6DCGl9AIAAP//7N3RDYAgDAXAjubAQkfUmPjnNwHq3RCQFvoqVAMAqESwBgAAAAAwzbu13bAQJeSZeu4whk2klCBIDObI1oVqsKPDx3oABtOTZSvZupqav1jhfH7qkUtNAgBDuWdZzfctJSJuAAAA///s3LENwCAMBECvCKwZiRFQNkuTLjUCnLsJ6GwZ+4VqAABpvMsjFkgAAAAAgFUsb5OFo3+YpF/dfxZZ6HtgHXWEE6kbAExRWhVOwGn08/xCaXVsdmA7BGsAwDRmf+zm/jwoIh4AAAD//+zdwQ2AIAwFUDaTFZowpsoIrObFo0dRIO+NQC8NaX+FagAAS6nH6XIeAAAAAPC5KJFd32AVda+WEaAvwTUsIUo0lYRfPA6DwuCyBTYAOtk8LJPRz7O8O/BoxP6/CWMCgHf582MaKaULAAD//+zdsQ2AMAwEQI/GCsBALISUFRiNxh1tiBLrbojEX/itVAMAqEixBgAAAAAwmssbVGHZH37W7va4SkoRWxaLAWP5Q1iV3AxAV7m8JZOwGvM8peXbPPPsf+3noSgWAPqRyZjRN3dFxAsAAP//7N3BCYAwEATAK80WApappgRbE8GnHyGEXJypIguXXaUaAMB06n44RAQAAAAAuilrGXVxCz6rW7XSBn0osGEWPkhDZ89NBGS0WK4EoDF5hHS85/mBDIUVdzY55RMAaEIuYzivuSsiLgAAAP//7NzRCYAwDAXAjKYjFBxTzYpScAOlkHC3QelHmpI8oRoAQEt53bubBQAAAAAWMSRAF5b8YZE8U0g8XWzjGBYQYD3vNqrSPwPwi3cRWi9CNf6CaG0GVRQ636whgjUA4AN1lFIi4gEAAP//7NzBCYAwDEDRjuYKBQdyoEJW0M28eBQRqWLKeyO0hwYavqgGADAyYQ0AAAAA4FV1rpkWBOHKGi0WJwTfiRb+shiFeQiAuybL9gB0ItRERptbY1RHUCPjrC+sAQDPeUP5o/OYYSllBwAA///s3cENgCAQBEBaRC3IhoASbM0PTz/GoHKZ6eEIucCuUA0AIKxWqoYvAAAAAGCY3srukQBRaDuHb5g9QshbFswEL2qlmjlm5hM0AI/kddntZZmRezxR9VCKmc/lo4eCAAD32PPxR9dhhimlEwAA///s3ckNwDAIBEBKc8FOaCGl5eMCLFk5jGaqWCRYlGoAAKXlcfrwBQAAAAA8xYIAVVzZU0k1fCB7OqagCrkI3ie/savmEzQAi8wfAD8xsn2FQoqmWAMA5o2yQ9hHRNwAAAD//+zdwQmAQAwEwOvMGgLXkJUr9/OhICJq4kwJgXwCu1GqAQD8gWINAAAAAOBW0SP71y3Ymk0DXmUHKSF6CB7Asw6/rUECwtAAXCK4RWLuP1RV6R40ijUWJYAAcMpkTHzUfiF5a20FAAD//+zduQ2AMBAEQJdGC0CbhisBl0biDJEgxHOaqeK01q6NagAA6cWyNmE0AAAAAHAzpVGyaFHDL+fwoqihEEQWQx8eA57hhuPPBkU1AC4yzMRfud9JZ5ynrG9lmxEnADjXcz3ZHp/Ue6RHpZQdAAD//+zc0QmAMAwFwKxYcB9dSLuiP/0uiCIm3u2QUEreU6oBAPxC34/NhzQAAAAA8IS2NId0VKKUGr7BLFKFgBu8ZHYYCkkoqwTgEgFnMvN+p5qxkyuHadfCpSEAcJdCDfKJiBMAAP//7N3BCcAwCAVQR8tq3SfgiqUQ6KmHQimJeW+DXAKKfoVqAAA7MYwIAAAAAHzBsihVHNnTMDdMIHsKiKeKJoAMfmUOgqVZjgbgJX1ZVqXnQynjOv0Of3K7gjXGewGAm9qMWT3XXhFxAgAA///s3dEJwCAMBcCsKHThbiat+S2IXzbebaCCIiZPoRoAwDEy5VlBCQAAAACwrF3Nr1SUkU38wD68Y1GFYkoAZjkzAJjyNDWbKX7stnhUkQETJ+3J73gFawDAICSXzX3fvSKiAwAA///s3cENgCAQBEA60xYuoUyVErQ0E8PfhIcRmCmBFzl2D0s1AICplP3wyxcAAAAA0CRyrDU8ByNQ3oefKVu5vGMxisghVAkfqBkI6JqSNABvapHZXJZuubczmFkX451KxADwWBwDXUop3QAAAP//7N3RCcAgDEDBjNbNXKjgiv74rVAoRHM3hZjwIqoBAFRkURgAAAAA+MIFXa7R3275E3Iyx+IWbQbJgP8JMnG6x9VnADb8ywIkMIN4ld/uTRQQgMoED8luGTSMiAEAAP//7NyxDYAwDATArAgsxEBAVgiTgZBQKhoaRJy7EVLE0st+pRoAQHfyuhULiQAAAADAG/dRqOUAopCRw0/lJRfH0QTi8A2+sXtnAjAzAHg0TOMsl6VxslhC8B9XVyngoRgQgE7J8GhXSukEAAD//+zdwQ2AMAgFUEbrwCYdwdW8cNFD9WKU9r0hmhLgI1QDAFhSJo8ZSAQAAAAAnnJ5imn0rQ+vcwCfs2zBLFoGkwEvuru8BkW0XNIDgCtLW1RnVpnyMkDCe3y2q2EAWEn+B/R8+LNx7RURBwAAAP//7NzRCYAwDAXAruYIVfdxIbUr6GZ+C0X/pKZ3ExQKeaUksVQDAOiZhkQAAAAA4FWes6Y4IhncJrStrOUwcEEgBi7gG3KDCGQGADd5Gi065vfKtnurE4F6XLfIKgA64u+O1p2PB0wpXQAAAP//7N3JDYAwDARAl5YWgDaR0gKdwcc8UX6ImJkmcmi9VqoBAPxWflQr1gAAAAAAHuV2deEAqjhyWB/4uL53BThU0RSUwSuGYVGYgYE0AG62IFOEjDLTc0cfasu2nnluAUBJ3meUEBEXAAAA///s3bENgDAMBECPxgrAQiwEjMBqadyCaCIRc7dDpLdkf5RqAAC/du7H5scWAAAAAOCBQg0qscQNY/FmqUKegv7sPVDF5BgNgGSOoAI5naFloYZ8/s41r4tiWQCqMp/xeXkjei8iGgAAAP//7N2xDcAgDARAVrTEPlmIxCtktDSUqSKlwNzNQGFZj99RDQAAgUQAAAAA4EX00LZBJXeOFOKGheRIIWzKiB7eM/woz8ucRyWasAE2Nz8l28uyPHM6K9NI/8kxD5EAQBlmAsporT0AAAD//+zdwQ2AIAwF0I7mCspAji6XnryQmHhoeW8EEqA06UeoBgCwvWxaC9YAAAAAAN78tkEn+uBQk71LF3cGlgH/cWfQhkE0gH3lwJa+LB2ozykrz2I1+TfHOa4n1xAAOvA+o4J1oGFETAAAAP//7N3BCYAwDAXQjuYK6kIdSMgI6mYe7F1BRBrfm6DQS/pJUks1AADOxRr1bgEFAAAAAOTXflPX8EYWWywhA4cOxRLVvZGIxkt4l3qPTAZDaAC/5d0A8D0LNZ5bx3mS7QLQtZbPyejowX55yFLKAQAA///s3bEVgCAMBUBG0xFQ93EhlRVt8FnaaJF4NwI04eUnWKoBAHCzFRoAAAAAuAhvk0bb2ug2ITQ9LLIY6lKFL+EjbT8s1SAbg3wAP9OHj70ZSKF/9gfh1HlSh79ndZ4ABCc3QxTP/ZFSygkAAP//7N3BEYAgDARASrMF1IIsyBlK1E8K4MMjYbcJQuY4lGoAAIQImAglAgAAAMDm+t2FXanE3huSG+94ZoNAkIAAJqxl9qMUD9AA9hE/ILsvUIU9DikpN1ri6Nf5xTkHAGmYC8hkqnS8tfYDAAD//+zdsQ0AIQwEQZdG5+g7+8QBDRD4mGmBBCF7EdUAADh0GdpjNgAAAAA8qn9PN7xNjF7GB+azJE2KJWAGV5l3IM2yfAbwDCElknxOk2nEja7booEADONeQJaq+gEAAP//7N3BCYAwDAXQrKiuKXQEO5oIvXnppWDie0OUUH5+lGoAALwJJQIAAADAfwkGUIn/biiina1blKYQ8xYsMnuNDZKxeAZQnCVjqhkH/iCNUajhLV7vKQ28FAcC8HXbsZtnyWQuFxMRNwAAAP//7NzBCYAwEATAtHiQMoW0KMq9/Cu6zjRhYnbXqAYAwEWHTASNAQAAAOBnatYRYhNkI8balrALZPF+RYyapagB9/G9II6yNUCuLhb7J0sSQ3d8kQHU55wDJsrKALxV39GcDcgzxtgBAAD//+zcsQ2AMAwEwIyWzVgIKSvAZmlcItEgRJ67FVJEsv2vVAMA4EK1RBtsAwAAAMC/OAwgiTAlhBn7OOyvCNKr0Ax4nr+CRF3oDCBPhbUUJ5Hm9KKspArszGjetykPBOCj3M2wlMqA3mutTQAAAP//7NzBCYAwEATAtCjYjxakpgU7U4R8ffiQyDrTxOXI7SrVAAC45+AYAAAAAH5iGIfZ0SBB9rpUgTPI5P+KJA4z4QV13ZRqkGpq4WsActgJiPMk0AW9teI6b+x+rvLAw54DwFe0mWQukamUcgIAAP//7N3RCYAwDAXAjuYKBccUOoKriZBfwR/RPu+WaJu8ND7VAAC4UEETwUQAAAAA+AcBbpKobUOosY2zf2VYmhRLX7twJjzDfZBUNjkDhKjt/N4DpFGzYRo1NKs39g17nYsA8DbnEbO53wtprR0AAAD//+zdsQ2AMAwEwIwGIwQYEykrwGTQpKYDkdfdCi7ysmLbUg0AgAd9Y7QmNwAAAAAEq1v1MYAkRx+6B0K1vc1qSxA5DN4hDxLLsBnA+Fw/JtipuAxErv6Xqa7L1d9IAPicnhvxSik3AAAA///s3dENgCAMBUBGcwXUgVxIHcHV/Om/MSEG6t0KhAZIeRWqAQDwzAQXAAAAAEgqpqNrUCMTb9rwD/Y6adS1blYT2jr3Q6gGmU2a/AHGFZ+F1XFSikF+0D3n6a5ddZnVEgA+JfiQUb26g5VSbgAAAP//7N3BCYAwDAXQjuZmXaiQFRxNhN49Kfb3vRVySeAncVQDAODBDJsIJgIAAABApq6uBDlrlAVK2ECNEqwmiX4M3iHnQLLDB2eAZVnkJpX+myXMgxp66X/rd53MPAB8yJxGvtbaBQAA///s3dEJwDAIBUBH6wpC9p+lPw7QQAvV3O2QD8nT56gGAMADdblMEBkAAAAABsmV2jaYRnAbzuLNM0auFNiEl2nJ5gCWzACaqUVumErGmN/TQt/KVTOP2R6AT5nTaGzvrzwibgAAAP//7NzRDYAgDAVARnMz4z5oVyQmHcAPTaTcDUFLeDylGgAAzwkmAgAAAEAtwgFUckQPwW1YSPQQqKaSLQvPgHfZD6lOsQbAJPKjljObsuK87N78Wu7N3sXms98z1L0HgC9keZMZwxpaawMAAP//7NzBDYAwCAVQRnOFJu7jRNoZ3MxLB9CkB6HvjdAeIBC+UA0AgJfGwFuwBgAAAAAU0PbmEJlSHNfDsuyuqOTwmzDd7UlZgPoB8HMOtViA+QwZ6Jvz2kagoD0QANOMwCb9AWn18/rWG0XEAwAA///s3dsNwCAIAEBGcwWT7tPVGxMWsO2Hyt0KfEiQh6UaAAATMuGyTRoAAAAA9qc5gJNo2oaicqGOvytO0frVDdrBj940lcKG2rjcLHAAazKoRRFqMywt82U1l/3dI5b5tgLAV+pp1BIRDwAAAP//7NzRDYAgDAXArlh1IBdSVzQxLIDxA8vdCiTQ0L5aqgEA0M9wMgAAAAD8WG5pOIBSWqgemJfeFZWo0+B7An7MwGINgAG10K/7mfKu41RzM6xcl91CjVKet7WdKwC84h+NAvr74xFxAwAA///s3dEJwCAMBUBX6whC93Ghgit0tFLIAC30wyZ3IxiQKOYpVAMA4KW4/N6sGwAAAAD8T/x+7vEgmRimh+LmMU8D02TS924oAL6lX6QKwRoACxGoQSH6bZYVe/FQoZTGff6JGgPAYwK3KKu1dgEAAP//7N3BDYBACARASrNglRYs7RJjAebi44SZFvhAAotQDQCACU+whuVEAAAAAPgfy4NUcuWeDo+BcMBBMfo1+JCv2TSz+dgMsAyBGrSQx6n3YEnCjVq4ayxcEIC3BG5RxdQcFhEDAAD//+zdwQmAMBAEwLRmCQH7sSH1SlQU3z6CoOZmSsgrCeyuUg0AgEaxrIOzAwAAAID/uFbPLW7QEyF64BRzKISnK3WswgDwLPdGMpmsNQO8S7iXRPzF8GUCs3kc5YKbdxAAdxRukV4pZQcAAP//7NzBCYAwDAXQjOYKBfetbtZLvXpQQU3eW6EQAs3/SjUAAO5RrAEAAAAA/+GAkEy2GaIHOAhMk8nS1iYIAM+xN1JNFygDeMcs1DCDqWL30nyRWVxWV2wFwAn3MmRx7U88IgYAAAD//+zd0Q2AIAwFQEZzBcCBXAgYUX+Mib9qjMLdCiQNpO1DqAYAwA2tVL9+AQAAAMAPxDkuzonOWJ4HTvagHX0remLAEx5itoFBCdYAeJklbkbTStV34HP2O7BaPK4p5rTGnNQnAA7eanTmWq8jhLABAAD//+zdwQ2AIAwFUEbTfVVG0NEMSS8ejcSQ8t4IcICm6a9QDQCAj+p+rM4QAAAAAMYVW84NZZLJFcPzAA91q/pWZLIIRoOubNFmRoI1AH5iSIsJCT1mOPH3Pd0MrS/a3mb1EABqNbKJEPH3Sik3AAAA///s3bENACAIBEBGc/+pbCysLAwmBu6GML6BV6kGAEAOA4oAAAAA8C+FGlRjYBs4cUZQiXscJPGLNo1ZJAN4zJIWTSk95kcKNdiNlYe8BwA0JatR0H0Oi4gJAAD//+zdzQmAMAwG0I7mClH3caFCV9DJ9NKjXvwBad/boFACDclXoRoAAC+oKWca5AAAAADwMzHHYEiAxqwlF/1o4FLJxZA0TYk53Gl4j+AleiVYA+AjlrTo1Prkd2T4Qq3HcGaJady9iQD6UkOV1H5as90+T0rpAAAA///s3cEJwCAQBEBbS2VpKHotSsACJPoI50wJPg5O3FWpBgDAJlHb5SwBAAAA4Hf8bk4q8YS7aGCG0DSZ3KMoDVgn+MfJFGsAbKZQg4MtBblgN/OYSe9OZC8COMCY9d7KkE7U9r2Iv5TSAQAA///s3dEJwDAIBUBH68CFjNDV+uMAAf0I5m6FgBjiiz7VAADoZZgZAAAAAA6RW80NhjGJkDywZb2rNFAEBzL8CQ1ym7aPNbiZABlAEwFublYNckGn7G/VY3Y9eS9SxwCGyt7gc74MVHvbiIgfAAD//+zd0Q2AIAxAwY7mCqj7OBqjaUhcQOGDlLslIMArhmoAAAzkAQoAAAAATEV8SSoieeAjg3jIZCtnEYjAGH7VZnX1DcEB+KEFWuXYbwE3C3PewjREs3S42npu6CBALvYGJNd3txERDwAAAP//7N3hCYAgEIDRG61GEFqzWjE4XEAUSntvBP/doZ+iGgAAg93ntTtTAAAAAHhXOYr4AKtxWRtoUkM8YvCsRDANBvCrNqRNWAOgnQdakOxa+BK7EnpldFBcA2B+5jV+oG8Wi4gHAAD//+zd0Q2AIAxAwY7GwuoKjmZCygBEjIh3I/ADTeAhqgEA8AxhDQAAAAB4Sf5i7iIhS8nH8QC9BHlYSRFOg2HsDyCsAdDFAy2ozmPbRTWYQp5lhRAYobS4htUE+CbzGn9wexaLiAsAAP//7N3hCYAgEAZQR2uFaqEGCpyhyYpI+itUUh3vjSCid4qfQjUAABoohZqDcwAAAAB4h0ANohHkDFyS5+zOimjUefAMewMcOr8yA9R5oAWnxVDwBf04TAI1aGDvj9YyvwD4ibJu69eI7n5QeEppAwAA///s3UENgDAMBdBJw8KS+UERYAFpHCgHEk6MAYH3VLTbb2upBgBAI9MwCjkDAAAAwM1yyZ0gIR8zx1A8wFmXhIzgLXLJgv1QyaEQ2NmuMntLADgQV+sNaMFaR+tHeVzUrZaO0lIfyzX0SAAvF/2auoA/qP/PSCktAAAA///s3UEOgCAMBMD+3K8bw1702oAGZx5BWKCLUg0AgLkUawAAAADAWh54sxvD8EBLinkMTrOTI0VqQI9ftuFOsQbAQwa0rI0wOKflddmvugdjlSsjyUkAHyWv8ScpCu+pqhMAAP//7N3BCQAhDATAlGbnd6WJ4EfwlzsRnSkjYXeVagAA/Mi6CwAAAACsY7WcA709DA+QJfjBaSyvQZKVbZh6eiAB4GotPNsW6gW0YOBOyw7cQ1itKNcA2I9CDS7zzZ87IioAAAD//+zdwQ2AIBAEwCsNSyCxTbUFS/ODD+NPURKYKYEHOZLbRakGAMDHtmWdnDEAAAAA/MIyIb0RggeqKAU9wh/0JOU5WxiF98yfYGGqAAAgAElEQVSbcJcUawAjK4FZ9yBc7bV+RoanhGdp7CzXUNAJ0FApQDQTMJo6b7GIONi7oxMAQQAIoK4otE8LVa7QZkXgR1B/mYW+N8Wl3mVUAwCgDsMaAAAAAPCiOEQPvWnNmkvwAEWkKbmvojXyHzyU5kUZBu4dBYXNn5iB3uRylpwNV8bo+FTOpbIpfzDmbyXnCQCVnQYQZQK6UmzgMISwAwAA///s3cEJwCAMBdCsKLj/LL3k0IuCVKXoe0OEQH4SRzUAADbIBk74GQAAAAAWyC/lggOcRlAbWEFt4SilFgF++E6WAdp8Ygau4Nsx9M1c4oJRrwVa+BPHNQA2ynqrH+BG82bbEfEAAAD//+zdwRGAIAwEQDpn7AdNi35460MQJ+6WwOsGwkWpBgDAS2I/bP8CAAAAgDmqcyWZLVoY1AaGixaGnMlGDoTnFC7Btdo/mgOkZNsx3JKXWU0W5cuUawBM1u+lvIXwV+PmZkopJwAAAP//7N3BDYAgEARASqOFS2hTbdGY3JuPKBFnqiALuxjVAAB4l2ENAAAAABgoWlQPvlmN0jvwMGUQlhItlEvghvx126Ab9NUsiskfgKVkOct5GjqObZfVMo1xNz7EuAbAYFcOlWcBeRS/lfcXY5RSTgAAAP//7NzRCYAwDATQjObmHU0R8l9pq2J8b4hyhdwZ1QAAeJBjFAAAAABYzkEh1Si7A7cy3ENBWw6tAeNkULimKTYCFWQ5a1fOgi45mdco0fJR57hGM0gIMCffUVmAv1v7H4uIAwAA///s3cENgCAQBEBKwxJI7MeK1Bb9nH8VgoHMlACfu8fuKdUAAOjs3I/FmwMAAABAvbIWoWCmI+wOdCIUwmw2Pwrftb72BpPLcYFZqAEYUlyQVxAEz5iT+UXMmuZNRpXvQkJ7E8B7UaxlZ4PW+1hK6QIAAP//7N1RCoAgEAVAj9YVhO5bNyui/fCvQkmUmUOIK763SjUAAPpQrAEAAAAA9YQnmY2QO/CLKPARDGEmS16zT/pQx10Uvtki5AAwhCvUGueWN1V4Z1c+Rw/FZnoYXVmuoVAe4EHMbIdiLbg1n8dSSicAAAD//+zdQQ5AMBAF0F6xifs4EY7A0QSzsLApotK8d4o/k/6poxoAABVEsLNsBwAAAICbcpc9KKQ1S5TcAb6iPE1r5EN4YBpGWRTK7WUHvy8DfxdF1lk5C4rYm1CL40e0ZssffcxOdg8AF04zG3B4fx5LKa0AAAD//+zdzQmAMAwG0K7mCAXHVDuCjiZIDwUPUv8p742QU0LTfI5qAAB8JI1Tp/YAAAAAUC+nkFsApzWWtIFXpSE5Ak9zYh8t5sM1elI4Z0tfVjvgb4qkYx+0oc7yRCoyHMk9pfcvWua4BkAhz2yzmQ127p/HQggrAAAA///s3MENgCAQRcEtzYbVFijNy948CQEMzBRBCOE/UQ0AgLmENQAAAADgOx8KWE3JcTvAaMbTrMY9ERrc52XUAvUO4zDgT3KYJfgDdbyXMFzeIwU12IW4BrC9PAMFteCtT+QwIh4AAAD//+zd0QnAIAwFQFcUum/pZiWQzxZKRQJ6N4I/Rs2LhmoAABTKIk+jNAAAAAB8lL+PaypgNZq0gRI50MdbFUvpRxcchDFqUxgT4bAzfhq1jkCFCGZFSNUdKvw3K8AFb7J2NCiUHRmuAWwn9v08s9n74dk1ZV1aazcAAAD//+zc3QmAIBgFUEerEYTWNEeo0SKw14h+FOycFQQ/Fe9VqgEA0FhO82gNAAAAAOAyHwvozVpC7QCtCE/TmyFOUYAQ7nM2hef2ObQo1wBqEsyC13gnoapyXlQQyt8d5RruUEDX9n3O3IdzOc3flG2FEDYAAAD//+zd0QmAMAwFwKxYcP9ZRIj0SwVpUMLdEC2kfS9KNQAA/kGxBgAAAAA8GNuwpYiOfNIGPpXFPgLUdCNICC/lVm73AqxxlmuYZwBlskxDMAsWqQxwwQUzDJgUFAItHbOhLEF0tsG9ureJiNgBAAD//+zd2wmAMAwF0IzmwEJXcDP9SX8URKT1Uc4ZIiSQ3AjVAAD4AEspAAAAAHAuv41bLGQ0Sx6zA7yqzEUAPKOZsn8E7hH8Bm3Vr8uOdIFmdmEael9oQx/Mo7KOq+FwVMM1zFHAr+Xcttp1gcv6zWQRsQEAAP//7N3BCcAgEATAa82C1RZDwFdAkKDByEwRJ6K7p1QDAGATNZekWAMAAAAAunwy4DhC7MBmBEc4jU3d8JLFILCMcg1gijZHBLFhspqLM5rP3CFbcxyGuEcBv/MoQQQGtbeJNSLiAgAA///s3cEJwCAMAEBXFDpmwRG6WhHSjz8FS5C7GTQkkkRLNQAActGsCAAAAACD+GVcYyGn8R4MpNLupimZ49SrOtewTr4K+xgKA5b0uOGXY9hG/stvYqGGIVuY89VRT9whgHSGZRpiFczZW5OVUl4AAAD//+zd0Q2AIAxAwW7uROqKJqY//oGmpiF3SxCgPEQ1AAAayaKag3kAAAAAeDIkznI8Xgeack/FarYMtAGTcn6h9Fc4QFwDGCOmAfXO/bAe8ydBDXjvjtLYSwGdiGnAd+V7soi4AAAA///s3UEKwCAMBMD8/9VSCHrordUoMvMET1Gyq1INAIDD5BBoMQUAAAAAxu/ilg64jdA6cCSFP1xK8BC+M7dCDeUawEuGspRpQA1zL2UycAvM0e9Sz+zkTIEd8j1HmQb8sz5HGRENAAD//+zd2wmAMAwAwIzmCgXXVEfQ0aSICH5KDaXcTZF3HNUAAOiTAj0AAAAAXAyMMxxL60Dn9KkYzVTmYpgVPtiW9fAUBFI5rgG8PxyrjUKCjI/IEM/SrRoFtFdjpr3GUPIpIMOdtzmCCM3835+OiBMAAP//7N3BCcAwCAVQR2tHCHTfrtaLvfRYUELy3gohoOFrLNUAAJhQBlMEFgEAAADY2riG37pY0elUgZnl4h8D1KxGqBX+k12Afu9yjdtvy7CPzzINdx/6qHdpkXWd9wmodeingEr6NqiRc5S1IuIBAAD//+zdgQmAIBAFUEdzBaExA1dosyK4FijUsvd2EDy9+ydUAwDgpSL5WsMiAAAAAL8U28Q1ITCbra7Vuy/wBQZKmE0uS7GlEm6IZlZ3WBgj27YM8zvPd2w3NpQFA0SvLjQVg/2C5KGvq57a1VPAU8I0oKk+/9IppQMAAP//7N3BDYAgDABAHg7mCqj7GDbTzQyGAYyJIHq3AgmlhZbBOgIAvFqScAEAAADwU37r4os0qQNdyAOA4hI391R8TD5fekAP93i7AG2dg0fjPOVYljT/Qv9Kc/WoBgrNqddSi/0e2lpLPpVr3rucCriqDOURx+FB1eJyCOEAAAD//+zd0QmAIBAAUGkyVxDcp9Fqs0K4j/6CILN6bwVRPO/OmywkAMC4YuKLR3sAAAAAfqXUkjVs8UFra1K3sMCLyFHxOaUWBfNwQdQuuMvCGOaYtLyYtgzv0/btYbqxxix4mKZqeohzX84LxpDFVMCZ9glixG6buA1u1y/vkFLaAQAA///s3UEOQDAQBdAu3MsZivtIT8bRpHRjKyGD965QMenI/zrnCQAQW13a53HoLVQBAAAA+JHFYfNBwunAq9QioDzl1TcqPmauz7WiK7ikmAkQyl5I2v62XPYix6MABwimBrJaEMschVjsa7ldC+x7/0NM7lTASZvbslvwrOfuZSmlDQAA///s3cENgCAQBEBKswW1IGLnhISHFiAcMFMBv8sF2BWqAQAwB49TAAAAANiC9nAW5fMuMCt3VKwo926+ghXUjyXnfQlbgphya1uuh3u07sN4LUjj0GoMcZmX/O0VqgTE99mpBGzAPuxuMFTfeZtSKgAAAP//7N3RCYAgFAVQN8sVXrlPNFm4WQhO0IdlnbOA4I948V2VagAATKA/Tjlc1AAAAAD4ARkYX+TXQ2BKrRAoShig5mtylMgKr+AWZUvwfnv/abmdc9XAMIxjGAumIq9lhNMuw5QUbMAPxLa2vGSRdcKj6tDVU0oXAAAA///s3bENgDAMBMCsxggmLMQ+SIwIAkFDRxGEo7sVUliR8x+lGgAASRxL7qijSxsAAAAA3YopPDCkR7PQLpDZuqxDTLE5RDpzh42BF64PQZQtQQ5nuF/BBrSlSANyMhNpLepo3wV9eBZsmCGQmCIN+JfPZ2opZQcAAP//7N3dDUAwGAXQjsYIxUDsg64oxINXEaJfzlmhD/2/V6gGAEBdtL4AAAAAENLeFu7si4jKXDyuAyKYfBIjmCYPeTRPw31lWdvcd8KWoC7XgI2kbRmeEaQB1ZsMIW86AzXcd0E8x9pPcCHURZAG/Nb3+7KU0gYAAP//7N3BCQAhDATAtChc/7UcHj78eiCaMFODEJR1o1QDACCRsfVFaBEAAACAirx5UZGANlBCLx5oTzOrqaafacF3+EduAXKzbRkWjY9YYf5BfmYeO03FS0Btc3HhV7ChuBDuoUgD7nfkXhYRLwAAAP//7N3LDYAgDABQVnOEKgO5masZEzwYTx4Iob43AhzaJv1YqgEAMJkrcYxtVeABAAAAkEbU0GRISq7fA8kYoCadqLGL1/Bd61sQEyCH17Vlw2DwGIrWpwe5LP6TXlrsODww/M6dN1pcCIOo32A6Y47TlFJOAAAA///s3MENgCAQBEBaPKUfYz8mtGBpxocffz6QADNNXDhuV6kGAECfdo89AAAAAAbiyJARNTsEAKjhLh6IHALUjGaLHGc5iuAwfKdsCcbzDoMp2WAaQlgwBfOM2vx1AUlxIfwj1uUprrGfhP60mYkppQsAAP//7N3BDcAgCAVQVlQH6modrSHpscc2BvreCh4MCh+hGgAABeWjylhTgwoAAAAA5eV2cKdIQ6et90BT/qfo6NjZwAdV5cbVe0AE6EvIBm0J0YBfEoLMZ8aaAjWAJ2oqeIkaDtrYdwdGxAUAAP//7N1BCoAgEAVQj2ZHEDxm4BXDcNEmsEWU+t4ZBB38M2OoBgDAoFpARUEIAAAAwLBSTlFjLpMS0AamVAcGpZz8TzGbWN+lZS+C7PDcZhszLOWuIezMMTkK/Nlli7F6BtakeZnXtDvG3QL0MGQDOhmiAdP6LksTQjgAAAD//+zcQQqAIBAFUDtidaJu5tFCUGjRIgWR9L0ruBCd+V+pBgDAv10eiAAAdR4LUwDAR5bi6UihBjOKQrnA5MynmFEqBdicLNRJgY/9PKJ7AZZVAi5p/lb+eBRtMJwCDeCFEmS6yIFfsy6glZINyJRowBLG3m8hhBsAAP//7N3RCYAgFAVQVxQcqPYJGqHVQjCQvhKsyM4Zwa+e3ndTqgEA8GEloDK7kAUAaOLbCQDaCcDTXf4buDAEgxLQBoaWi4NiihaoGU5McVqX1ewD7ZQtATVFGzxKgQZwgcVkblGWfzenC3R0LtkIx7ujWYrRVLOcPC/8x7tZmhDCDgAA///s3cENgCAMBdCu5gjqQE6kruBoBuPBg9Fw0Ai+NwIkkJT2I1QDAKBwqUDS9p1HQQAAAABKozmCGi1p2NzOAj9ggJoaDQIFId/+GYiwJeDKWdBGHBvpDYhx5zBwFeqKQI55nBoLxkPcR8AbtrNGaCElE4YIfCLsMCJWAAAA///s3cEJhDAQBdCUti1MYpmCJVjaLrmIiBdBNxrfKyGXISH/j1INAIA++LgIAAAAwGPULeDes+hU880aAP9QC4RiCAFquhNDzNM4CVzBQTWoGCV/nRtw0BJE3ZRtLCGxJCj2KpviDGEr4Azea7lElDybU0Aje6WFija4hSj5s5qP7nTAWvu7WUrpBwAA///s3cEJwCAQBMArzRaENJTOLC0IPoKEPEKEaGZauMehuKtSDQCABbSfX3atxwAAAABMwj0WKyo1ZG6ywI8ofWdFKW852enwiDcLwFvOIZy+cCP6R/hCY/PoSjNCyAoYzY5ghLbP7C/gS66KNuJ0dio1b2JivKk737kTBO58Yw9FxAEAAP//7N1LCoQwDADQXjHqfbya3mwo2MWMH3DAX31v111XgaRpYqgGAEAlcvE/2sZDIwAAAAC3Fl1oYqVKttoDb5OHDkQXg7cpKtRP2x2BHaaeBQ30wBm+Ys1K7Jltv/Sx+jgLwzKSgRnADajXcpTB52HgIUqs6qNtyo1zDBvLQZ7Elp9cT44H/GtWp7tESukDAAD//+zdQQ6DIBAFUI7GFYDet0ermZ3a2sREG6Dvbd2hCweYP0I1AADmYiIYAAAAAN2Kqd8uGjKpbi4BAPxSBAqVR3lZdCaT4781gmO8WDgtGheflg3owNv+05fgn01T2afn/zLV+SAcY82+HjAKE/m5TXxbpVW1DzCqvO432dVJm/NOgRvzK63mXf+R4Azgav3UZimlBQAA///s3cENgCAMBVAc3X1MWMHRjAkHRRP1oGJ9bwUutLQfoRoAAIGURm3vARMAAACARulbEVIesqEy4M+8TRHRvBjTOVm4pswsjIbvgY+pl4hqy1+dzzgK6XiSezrwV0KQuZVgDSCoVf1QBW5s6hyhG23bCcxIQjOAF7RTm6WUJgAAAP//7N3RDYAgDEDBrlhlINnM0Qy/Gn6MiQTutmgDr6IaAACTacuJ3DfDLgAAAABDade+7ayYlAfawNJaWChL+qzHdLLkIZwFr1SzH7A4OzCAf9WRLiEzL2ENYDGPOecW3YheYFB84zudUEaIZQCDOoeazSLiAgAA///s3dEJgDAMBcCsqE7k5qLoR6GgUtAQ7mYopJS+F6UaAAA1+aQCAAAAQDbCtpQkbAtwWM16CtrPtDkPL53BMnMBAIBfCO7yJcUaAI1u4UOnfONyt7ggXRh71LTMT+4p3tSAKnItqImIDQAA///s3dEJgCAQBmBXa4Qr92mhoBGizUJ6rwwKke8bwJd7EE/vV6gGAECHPFIBAAAAoCXll28hsHRqUFiAM2AocriXojuRY1uX1X4Plcog48XABAAAfMX5jd8J1gB47a53NMc01q5dQjj2D0ui3wXwTHvBSCmlAwAA///s3cEJgEAMBMB0Zlo4sEzhWrjSRLACBYlhpok8kt0o1QAAaOo+UtmEFQAAAAAowHEJHa15zFbfkQBeUvhORzn2kWY+PCJUBgDAl9p9s+c/FGsAlJHyMwAlXHvjWiLiBAAA///s3dEJgDAMBcDg5A6kZkURMoEfpsS7FVIoKenL5mwAAMyV5yV1GwAAAIBWz3ZvFWCoJYcAALrkkXttgYNphMXAC/Wh0b0AAMBXvNfSqnogc9sAAPzdmoGHEXEDAAD//+zdsQ0AIAgEQEZzNTdzNGNiaWOjBu+mIJDnPdUAAMjPghYAAACAK0artyYYkmoa6wGWBFjIqMy5FtikCAQAgEPqq6Et/uKxBgAAPHovjogOAAD//+zdsQ1AIQgFQEZ3IXUEV7P55a9MjAbvRoCGhPAQqgEAkJzvLwAAAAAc5Ks3WTkaB/jxBQ7ZS5HR0FVYZnYGAGCrXltRYW4hWAMAgIfdG3gYERMAAP//7N2xCQAgDATArBhwYEezSWklKKJ3U6TI/yvVAAD4gPUXAAAAAE6rNW+L3ryoV2gcgDnhaZ6ULYW0YEEFHN3PAADs4j+W6yjWAADgR1cXHkbEAAAA///s3bENACAIBEA2dzVHs7E2sdAQuJuCQP5RqgEA0IflLAAAAAA/+eZNVcLiAAe7eEh4morGLo4D7pmhAQB4YWb+gkxvijUAAGgm9x0gIhYAAAD//+zdwQkAIQwEwHQuFqS26Cdv4eAE0ZkWfARishGqAQDwiGzO+jwAAAAAYDtXvLlYzWVxANYsT3Or4mXhu5xXUBsAAPjVaF1gAUcTrAEAwCtG62fPikXEBAAA///s3NENABEQQMEtTQsSZUq0eD8KIBFxzLTgwybWE9UAAHiIBwQAAAAANvHZkCu12gRjAAb0AJEIETdKueTkZGFeX6h1NwAAsIp9WH5BWAMAgAecP+9GxAcAAP//7N27DcAgDAVAr4iUMZEYIRmNhgVAUODcjeDKH+lZqAYAwP9YzAIAAABwTHnKq7ok5bM2wIRWm5sUWQmQg3V6agAAdvhGUAFcQbAGAACJ3TGfRUQHAAD//+zdyxGAMAgFQEqzhcxYkAWptOiFBvxcgrstcAgTkodQDQCAn6lG1TABAAAAgM/V1m6bu2kp99xUFuA2n6fpaBnr0BfAA/VewdkAAMAreZzCCZiOYA0AAJqa484/Ii4AAAD//+zdwQ0AIQgEQEq3IbWFK82PFWhMlJupYhNgUaoBAPBDBgoAAAAAHOJrN1k5/ANYoJCIxOReWNRrKx6BAACwwf4rz1KsAQBAMt/MuPeLiAEAAP//7N2xDUAhCAVARnMFEgd2NGP/K7+NeDcCDYSEh1ANAIB3WcoCAAAAcEz2bOtrt4pS0HAUDvCLYCJKyp7mA9inNwAAsOOqgy34IlgDAIAqrnr6HRETAAD//+zcuREAIAgEQDq3NFszITVwNAF3SyBieE6oBgDAp3Ioa7kAAAAAwCtTJWnKwx/ABcFENDYyWA44lPcK+mwAAI5Ue9iCHcEaAAA0UGvGHxELAAD//+zdyxGAMAgFQKxcCzKhhZTmpAQ/l+BuC7nABB5CNQAAfswHAwAAAABfcKWbwkaeKZwY4D2L01S1e1l4Jls/HAIBAOAG866UMoM1svVNXwQAwIJmLbvWrFhEXAAAAP//7N3RCQAgCAVAR2vgwBUjcICIfpK7GfwQ5amjGgAAWDQAAAAAcK2+cwsT0pUQOMADOVNwmq5G9cPAHf02AAAndmDLXIGW6kGi+gYA4Cf/zfYjYgEAAP//7NyxDQAgCABB9p/FxBUczYbagtiId0toQF9UAwDgc7loMIwFAAAAoEpQg67WHNPsFOAeH6fpyn0YivK9gvMBAICjjA5AW8IaAAA85M3oYURsAAAA///s3bERQBEQBcArTQtmFKQhtCgRC8xP+LstXHAB751SDQAAPDgAAAAAcGRd5XaZm1cJ9wF8aBUVCQfwopRLriYLZ0br1X4AAGDD/1Z+QbEGAAA3uDaDGBETAAD//+zduREAIAgEQFq3cxMNDXwCYXarYGC4E6oBAMDk8AAAAADALq3cVNXG8zcAbwksoipzMVxQBAIAwELaBmQ4IVgDAIDP5d3lR0QHAAD//+zdwQmAMAxA0YzmwIWs4GhCycFjKQga3xuhp5LAj6gGAABTLR4MYgEAAABYUte4D69FRznStXmAB1SwyD6Klup/DOwT1gAA4O4UX+OPhDUAAHipb0cPI+ICAAD//+zduwkAIQwA0KwouI/c5jZiYadw4Oe9FYIpEpNYqgEAQKcBAQAAAMAE17i51SeyAL+SZ7lVSTlZOgeLHAIBAGCgfsCz2n9ubwAAgG0cP3MYERUAAP//7N2xEYAgEETRK137QbdFEyMCEsYZYd6rgZD7K6oBAEBPWAMAAACAISvc7Cwt3jfAh9LiaJqdCc/BBIvMAAC8ztUXkGFWrvvwpxsAgJ9YP/hWVQ8AAAD//+zdsQ1AIQgFQEZz4J+4gqP9hsbGwkITvJsCCPA81QAAYCL9BQAAAICVTN92LEhVkt8ADuhfdxBAVS3rZWCfmhwA4G0jnwnA83Kn2xwNAICbavRoEfEDAAD//+zdsQ0AIAgEQPafxcQRXM3GxmhloQnerUBFeMBRDQAAFuP7CwAAAADsOKhBWrVUYW2AeyxNk1VTWThnaQwA4G/yqzDTIwEA8FiOmW5EdAAAAP//7N2xCcAwDARArSjIQt4so6VRE4irgE2UuxGMCvOgl1INAABmBLAAAAAA3NTVbZe36UomCrCQIiM6yyPNN7xQS2OnNwQA+B0ZLTxQrAEAwCaj/qLfFxEXAAAA///s3cEJgDAMBdB0cheyZgVHk4In6U3pIb43QqGQlCbfUg0AAKZ8UgEAAABgQuo2VZ25p/dQgPXKJBvBw+ZA4J07oVyNDgDwH6WGteBr435kP5o+CQCARUb9WWeJfERcAAAA///s3bEJACAMBMCsKDim4Io2tlaiQryb4gnJR6kGAABLc0kFAAAAAHzbJjtH3QAP9NblC9IqtSikg31yOgDAH9Ida8EpCggBALgk13w+IgYAAAD//+zdwQkAIQwEwJSmJQiWeWALV9p9/IvCIYSZFnwEYtgVqgEAwIpgDQAAAABC2zaJveMZDlAB7vEXRVal9Va8LpybTeXmBABAcgrgYI9gDQAAflbnfj6PiPgAAAD//+zdsQkAIAxFwb//VI5mk9pCESHeTRGivIhqAACwVEOwxSsAAADAx1zZpjnXrwEeqrCRtyi6EqaDQ/4sAAC0J6gBG4Q1AAC4ZHQMaiTJBAAA///s3bENwDAIBEBG82rezKOloXeRyJHed1OAxD9KNQAA2NICDgAAAHCv/q7twzapVoe5AfiXgiNSjZ6ngReExQAAYs3UsBac0LuSG28AAD4TmyGsqgcAAP//7N3RCQAgCAVAR2+goBFaLYIGCOoj7G4Ff0TxKVQDAIBdhq4AAAAAf/Jdm7RabeaeAA9YAUeOaMiqqyxcIYAJACCX+f24qCmcWcE0dh0AANyQt6+MiAEAAP//7N3RCcAgDATQrCh0oW7maP3JAIJFyvW9IYKKl7NUAwCAJf3o6jMjAAAAwI90q7ZmbVIJ5QF8i7lMrHENQTHYJCgGABBlJrcfw2nuSwAAvODuc2WmqnoAAAD//+zd0Q2AIAwFwDq5C4FdkZA4AFE/tN6t0J9SykOoBgAAy1xiAAAAAPyOX7UpK1t63ArwItlSwDuV7aoL950LvUKYAAC+T08HD5vnpezHZr4GAMAFs5esvUMTEQMAAP//7N3BDQAgCAQwVnMEE/efxQ8LmJio2O4gH+FOqAYAAKsEawAAAAB8QJs2xVnaBriT+UxZfXSBdbBBLvY6EgMAeFer3n4MJ2WBojcGAMCK+n+0ERJOxzAAACAASURBVDHZu6MTgEEYCoAZzRUEF+o+QlZ0hiCFVu9WyFcIeU+oBgAAJZpfAAAAAK6hTZtj5UyhMQAflDPdoThZ66M3E4Z9nsQAAH7rEagB77MzAQBQcEfwYUQsAAAA///s3cEJACAMA8DuP5WjidC3IIhovdsi0KRGNQAAWObzCwAAAEBtvmhTnLI2wMUMH1Gc4TrYJEtiAAC8o+XtKXBAZia5CQCAmZHT/ugHRkQHAAD//+zdwQkAIAgFUEdr9Ebr4rFTRKC9t4OQ2FdLNQAAOOXjOQAAAEBDeT3bBW26msLaACWYQ9HVyPc2cIeAGABADdNSNHgvA5JqDwCAnb/6tIhYAAAA///s3bENACAIBED2X8rVbCwsjTExwN0KVBB4hGoAAHBlDVotNAIAAADU43s2lZlpAiQgAInihgLDGw7EAAByEKgB/2x9U5sP5AAAHOm1PxMREwAA///s3QEJgEAMBdBVM8KBgQykXgWjyWAJRFDP91Jsf/CnVAMAgMv6ti9CVgAAAIBxtLll3uNzNqM6+trlmQDfoQiJYdXcDdzAQxAAgNdTqAEPy72pym3cSAAASFNl6/8REScAAAD//+zd0QkAIAgFQFcM2qeFglaMZqiPsrsV/FL0KVQDAIBdllMAAAAA8mhqSWJmmQAPGX0IHSCzVmoRZgeHeAgCAHCtLw+14FaCNQAAWLszX/ZpETEBAAD//+zdQREAIAgEQPpnccYKRPNjA30o7LaAgTuhGgAAHNH6AgAAAFCDtmyKyzmmQ1GA/2izpTKBdnCR5zAAgOe0fdSCl+3Zyc4NAKCn3CHV/UTEAgAA///s3UERACAIRUGi2T+Vl99ADyK7KRwZHqIaAAAcc/UFAAAAoLdcybbUx8+EgQEaShDJDIpfrbzDgUuENQAAnjF6UQtel+CNsAYAwDD5Q5+pqjYAAAD//+zcgQ3AIAgEQBy9A6krdLSmiSOYGORuCSDAC9UAAGAXR+kAAAAAeQnU4GbPesoGICc7KG6mD4f91A0AgLPe6o9akMEfrDH7aIIJAQDKqD2nRcQHAAD//+zd0QnAMAgFQEdLRwh0zEBWzI8jBIr2bgdBRN4TqgEAwBWZWuw5BQAAAKCYbMfWkE1be22NiACFZTCS5366GvOddhW4SOMyAMCnBGpAMTmzbm8AAL09eTv/r4g4AAAA///s3cEJACAMBMErXQtSW/RjCYIYZnowSB4bUQ0AAK5ZYzaLVQAAAIDvuI5NZULAADWY51TmPw6XCWsAALwhqAF/Om/X/g0AoKYuqJEkyQYAAP//7N3BCQAgDAPAjubAQldwND8dQQTr3QoihD4SpRoAAJzmqAoAAADwiFrFHt6LrnKm5XeABnLmUuxOZ5XLgYMUawAAXCd7wcNqWNE/BgDoZVXO+15ExAYAAP//7N2BCcAgDADBdLSOIHQfJ6quKEK7gQiGux0UCfIR1QAAYKnvY4qwBgAAAMAZbMUmM3NKgFzc62RWy1PE7mAxYQ0AgG1um4/hfPMc97dd4rYAACnMt535+C8iBgAAAP//7N2xDQAgCABB9p/FhBVtqKwlUXI3gzZEXlENAACuq4qdgSoAAADAw/yGzXS50hkHGCRXCrszneAdNKjlTu8XAAD6CGrAMLV86V4DAHxMUOMQERsAAP//7N2xDQAgCARARnP/qWyorCXRz90UEOARqgEAwBRLjQAAAACP6i/YjvZIZjkAIJDAJMKtrtOByxyEAQCMEagBobqPMmsBAPiTOu5UVRsAAP//7NyxCQAgDADB7D+L4AqOZpPS0oCGux0EQ/RFNQAAKJGLEmENAAAAgDcJatDZmmN6yA3Ql/0TnbmnQxFhDQCA6wQ1oLk84z5kAgD8xax2EhEbAAD//+zdywmAMAwA0LiZKxQcqAPZZkURvHqzoPW9FZIcAvk4qgEAwDDZejWUAgAAAPAu1/drH7CZmWVrgInlnlV8mdhatiLHYRCHNQAAHmNJC37irPVsfdFLAQB8gl7tTkQcAAAA///s3MsJACEMBcB0vtiPYAlraV48exFB4kwLOeX3hGoAAHCaA3YAAACAu/zqQWK91eZAACA/+ycy+1QXzhGsAQCwrXvSgvfMXspMDgDgXkWvthARAwAA///s3bEJwDAMBECtaMiYSbSCRwsBtWkCBmPfDSGeL15GNQAAGKoCuRIVAAAAYAK+XrMBXSTABvJMmYaltaMZwoOBDGsAAPzWK0sBG8rrfjs5NwAAYD69shpfIuIBAAD//+zd0QmAMAwFwLhZVyg4ppoVOlpBHEA/ilLvVshPEsKLUA0AAIa7GnMHKQAAAADv8/WambXc0h4S4D8c8DOzUtdaVBjGEawBAPCYQA3gfLaY+7GYpwAAPsOsdkdEdAAAAP//7N2xCQAwCARA958l4IppbNKlSQLmbghBeF+lGgAA3OJDJAAAAMBDvl3TXY4UEgD4SBUpCe/TmUI8OEyxBgDANkdawKJmgmw4AMBbdrVdETEBAAD//+zd0QnAIAwFwDeao3Uh2xWL4KdQ/GgFezdESAJ5EaoBAMAnWjKx5SkAAADAGv3LtU/X7MzuEeCf1H92VnofD7xIsAYAwCNHWsDQVc8jifoAALCGWW1GkhsAAP//7N25DYAwDABAszkDBTwCjIYi0YJEERfhbgVX/h3VAACgzF08NYwCAAAAUM+Xa6aWLVcRBvifbHnqPTG5Q4BhPIc1AAAeWdICXvWni7nti5wKAKCUXO2riLgAAAD//+zdsQkAIAwEwKwYcP9ZbOxsRDBFvBvCYCD/QjUAAKimMQwAAACg0Gq31nBNZ3aOAH8zB2gtRwoPgwKCNQAANo60gGPrvbCnAwB4z1/tRkRMAAAA///s3cEJgDAQBMDr3Iai24KlST7+FbxHnGnhIJAcu1GqAQBAq9lI7NEUAAAAoJXfrVlaRgRNAX4sI6cQNIvbDBh6KNYAALgJaQGPZT/mvsbZAQDwHXe1t6rqAgAA///s3dENABAMBcAaUWJNrCgSE0j44G6JRluvQjUAALhuNU0togAAAAAc5qo1HxDgC0CoB7wulywoDy4RrAEA4JMWsG8eX+y1Je8qAIAjzER3RcQAAAD//+zd0QnAIAxAwYxmRxA6ppAVHK0UnKDYCvZuBD9CIPAU1QAAYBWLPAAAAMCL6lmLX63ZXM+WwjEARLbsbk9sroz9HviAsAYA8GOCGsAUY5aYJwAA8xx3wMx7PhQRFwAAAP//7NzJCQAwCABBW0/n+UgaMAfEmSpUZEU1AAB4Igd5z40AAAAA5whq8Dv3RQAWoSUaMN/DRcIaAEBDQ1AD2Cl/xe1WAAB1ghpVETEBAAD//+zdwQmAQAwEwJSmnVmQmhYsTYS8fEpQOGequCyXjVINAAA+k9u+CEoBAAAA+tUVa5esGdmRa8oWAbhTuMTIpnrnAy9RrAEA/Mhc/zkBWl3LnzVbye0AAJ5RqNEhIk4AAAD//+zduwkAIAwFwKzmvoIjuJqNnZXgB/RuhKRK4CWOagAAcJslKQAAAMB6vljzOntFAAYlFwEgXld1GM4S/gIAPiCgBWzXD/cklQYAmGJeWyUiGgAAAP//7N3BCcAgDAXQdEShY7Z1BUcrgtf2JArhvRE8SKL56lENAAC2GsW9Q1IAAACAScpZ+lCaH6zJrNWrGhoA4IvgM6mNeh9YSPgLAEhMQAtYpu839X6Ofs9j1QEAfjX92mQR8QIAAP//7N2xDcAwCARAVstkXigxK1qW0rqzhITuRqB6Ch6lGgAAlPtDvqAPAAAAcMcwR5pzLA3AUb6pcIDu5H0o4GEIANCQAy2gRH7zsV8BABztIjL72m0RsQAAAP//7N3JCYBADADAWOKCDdmPmhK0NBH8+NqHeLDOtBDII6ejGgAAfMJRIAUAAADgAl+r+YEhxzQ4AECNvhNNK31ZRBie57AGANAQC1rAq/YclNPcecoIAHCy2q+7SURsAAAA///s3dEJwCAMQMGM5gpCxxRcsSD5LwiKlbspIiRPUQ0AAE5i8AcAAACYVJ9a/FrN7XrrwjEAfMoAk4V8blZy/gc2E9YAAH5uHLELagCnyKNRbywAAEGNtSLiBQAA///s3dEJACAIBcC3epv30wIFkcndCn6oiOqoBgAAZaxBjWENAAAAwBkHNehuiDAAG+QNulP/wyM+KgMAn7KgBZSkxwIA0K9dl2QCAAD//+zd0QnAIAwFwIzWFYQO1IGErNifDKA/rbV3KwQ0AX0RqgEAwFIMAQAAAADzaku1TdVsLXteKgzAqOwpzJ3dHe1s+iN4Ub1vcNcAAF/ggxawvDqnBOUCAH9jXntCRNwAAAD//+zdwRFAEQwE0JROQWjRRQMc/I/3msjsTLJRqgEAwB8JAwAAAABzfKnmdpYoAVhhfnA7OQA+plgDADhAdqAFnKKVmsYeuZwFALxAocYuEdEBAAD//+zd0Q2AMAgFQEbTfaus2JgwgP5oJXcj9I/wynNUAwCA5eRxag4DAAAAuKnaqTfvRWc5Ugs7AI/lSDsn2qt5APhQhZ4FnwGAFe31QR3gN64cec1ZDuYCAJ05gPimiJgAAAD//+zdywkAIQxAwbRmCYL92LqXFLCw4CfMVGGCvIhqAABwJYMBAAAAwGeuU1OdXSEAf/h8T3Wzjy6yB4fl8RCzCwBwk5ZvFIAnZRSoieYCAAUJIO4WEQsAAP//7N2xCQAhDAXQrCg45oEj6GgiWFx1xTVKeG8Ei0jg86NUAwCAmwmcAAAAAHwotXTvQ3KjPU1YEoDf9j+iWIPsFO3BBV7FGnYYAOCkoVADyGLNsn2oUaYcAMjCvnZCREwAAAD//+zdsQnAMAwEQGWzDBzQioagIkW6FIrF3RR+0Pt9qgEAwG9VSBAUAAAAAF7UGrVFaqZTggbgs7zS0hPTnZUPgGaPwpdbBwCgw/0WUdACpqmsdchaAMDm5LUuEbEAAAD//+zdwQkAIAwEwbRuP4ItWJog/vwKapgpIiAcq6gGAABPW2MTAAAAAHZ+oya73mozJgDgFKEmsvM+gIcIawAAFxR7SyC7defcOgDgNzMQJqhxUUQMAAAA///s3cEJwCAQBMArLS0IKciCArZgaeHARwoIQc1MCeJHYXeVagAAsAKfnwAAAAAPY4XaEjW7E34G4DXtatVpsrmjnMU9h4kIewEAH8q1Y+8B4BcyjJqhVEWGAMAiugLECUTEDQAA///s3dEJwCAMQMGs5mSl+wiOUEfzR2gHqBD0bgQFP0J4imoAAJDeLPEZfAIAAAC8HmfB5nqrzUwQgL8JNrG7yw1DLnPfwcI0ALBS8dsxcKJPyNAbCABkdQtqJBERAwAA///s3YENwCAIBEBWc18TVjS2HUETrHdT8JA8SjUAADiCEAEAAADw8n2aG2RP+0AAlsue5ih+T16AenxRBgA2eWYMhRrAzb681ZTpAgAFzQJEN5sqImIAAAD//+zdwQ2AQAgEQErTEkjsx9Ys7T48rgBNkMy0wIcEWIRqAADwJxbpAQAAAHyfZj6LjwB8ybyJ6e688lBl6MehFwDwIt+OATZ1sHoKMwQAGngqUENf0klELAAAAP//7N1BCoAgEAXQuaLQMYU5QleLxIWLVkFk+d4V3PgZ/aNUAwCAz+iBQqgAAAAAllW2sjt9/i5r2tQBwGOypnkTK1DEB5MaPnoBANxl2zHAhfOdeS8ckrkAgLe0+4hCjQlFxAEAAP//7N2xCcAwDARAZbOs5s0DRkWqgBsjK3dL2BLoX6gGAABHka4OAAAA/FW2TWucpjutzQDs4L2huzvnB6CgPPS6hDwBAIvmH8JxFsC318xlBwgA7DTcvBUWEQ8AAAD//+zdwRGAMAgEQFqzMwuK0kJK80MB+shMTHarAIYDRzUAAPgjTQYAAACwI9+mWV629GERgOGyZRdkZgP6B5hcLVgLeQEAb3ThLIBv8rrP2jk3BwQARjuq9mBWEfEAAAD//+zdwQnAIAwF0IxmRxA6cEcrQg699CJY1L43RCSSn1iqAQDAcnLTug9OAAAA4DfyyrRL0+xOmAyAL3l32F2pZzXACZN7hLwAAN4cFmoA9Gkz51lD1VEAYIQrezYZt9lFxA0AAP//7NzBCYAwDAXQOLkLFTKCjlYoHopXRVr73go5NKH8r1QDAIAp+SQCAAAAFnMYOD93ZkmhTwA+kyWVuLOC3ZRhfFfIa/MuAQA3bUcQzgJ4rru7FO0CAG9p5V1utklERAUAAP//7N2BCYAwDATArNYRCg5UB7KuWArdQEFS75YIgeRfqAYAAJkJ1gAAAAC2p12an3DECMAXzB+2V48qoA+SWOUiZhMAMJ2KxwDed1+9rftzz68AwBPFzpZMRAwAAAD//+zdwQnAIBAEQEuzBSFlBmzB0kJgG8gjgTMzTegd7qpUAwCAstLmZ6kJAAAAbGsco/tdmh9Y85z2fAB8LueP8DK765krgAIEvACAhLOUbQO85H5/nhCs2QsAeGplZnOHqKa1dgEAAP//7NyxDQAhDAPAsP8qL7Ei4itKKlDI3RSxwDaqAQBAapb9AAAAgMcZ1KACZWYArulfV1SiArkCElkKXj5mA0At8wZoylkAZyzZyzsVALDjvx1ktqQiYgAAAP//7N2xDYAwDARAjwabMVDAK2Q0FCkFFW0U624LW69/pRoAAFSgWAMAAAAoZ65JW5Smup4tBQ4AWE1wnuqOeV8AG/ksJwMA9Z0GxgDWyPu5RqmRHyEA8MPNtruIeAEAAP//7N2BCcAgDATAdHMHKjhCVxMlnUGMdysEDEL4F6oBAMDxMuXP4T0AAABQjTZpbuBAEYDt+tubKXCBz5DhPNmc/LiJAICy1q7XdAyw3wzXyGBDbzIA8PNnqyIiBgAAAP//7N0BCcAwDETRWKuEwgzVz6AWx0ZEdMd7LgLHj6gGAAARFP8AAACAJPOa72jLJ2nSrX1vwwMATiH0RLy+M4Af6k2EXQQAZPHpGOAwHTYc4hoAwLdpcbPlqKoHAAD//+zcwQ0AEBAEwFO5hiRaUJoPiRI4My14XDaya1QDAIBMhBUAAAAgi+olya63rtQJwDXcJT4hZ8DDVrmrKHYBwPPGGtRw0wEudYxrGOIFgP/szObvMJOImAAAAP//7N3BDQAgCAQwVjRxISdzNWPiwxEE2xV8mYNDqQYAAGWckEnQBAAAAKTmejSfMIQIwIsUuFNe6216ZcjtupoMAOSzF7MUagAksZdpT7mhXAsA/jD82YqKiAUAAP//7N2BCcAwCADBdLOsEOiYAVfoaIXiENXcLSEB84pqAADQSi6PAAAAAJS07jVdj+YEsUM8BoDfiR0C7pxg5rsDKCyvJl/mFgCU8c1uH7MAahLXAID2nowg2mXpaozxAgAA///s3cEJACAMBMG0Zml2LoIPS4jnTBNyIBtRDQAAEglrAAAAAK8S1OAHPhwC0Jl3ih/YHRDiHB4Z4hoA0NpwLAwgwxXXsMEAIMfcm00EMVxVLQAAAP//7N2BCUAhCAVA/2YNHLhCo0XgEH27WyIkfU+oBgAA7dQgY5gBAAAAfqXaojVG093KmZo9ALhWzvTPxAtGzR9AA2dHog51BUMBwF3OG/05zALoR8AhALSwKgTRDssLImIDAAD//+zc0QlAIQgFUFdrtCZrtQh68DYI9ZwV/BBFr1ANAABKustKi0oAAAAgk6VaNODJC4AM9Cs6MH9AMff4260EALz3PWYNtQCo6xdwaA4DgHzm6eNCEBuJiA0AAP//7N3BDQAgCAQwVjRxYEfzox8HMArtEoQAh1ANAAAys/AIAAAAfKH15usBFYz1/R8AnrbqlZpFevoQyOc46gIA7nOYBVCMcA0A+MoOQTQfqSYiJgAAAP//7NzBDQAgCAQwHM3JXN0PMxiBdgUeBAgnVAMAgLbyMCVYAwAAAKjgqBID2NUBUIm+xQTmEGgqn7qWfgYAz3jMAhhOuAYAfG8LQRwsIi4AAAD//+zd0QnAIAwFwKwouJCTtaOJENygYOPdCn5I0PeiVAMAgNLykcrAAwAAAByr9fY4HS7w5tZ/APiFvLcEkSnPPAK15Z8JgS4A+JZgFgCbcg0AOM5YBcRmtstFxAQAAP//7N27CcAwDAXAN5pXMGTMgFfIaG5cBdIF8tHdCqpkS09CNQAAqMDAIwAAAPBKfestSVMdCvBGB8DnjH24MEwFbfUlwE+dFroAgPtYzALgknANAHjcsUIQ/feRJJkAAAD//+zdwQ3AIAgFUDqak3U1R2tMiOcmHlrlvRU4GAJ8hWoAAHC8HFpZ2gcAAAD+6FYVCuj52z8A7MiMiQr0JVBAHnRd3jYAWOYwC4DXhGsAwCdGCGITgsgUEQ8AAAD//+zdwQ2AIBAEQOzMFkgsk+RaJCbnyxcfo95MDXwI7K5SDQAASsgHLJchAAAA4DVyDdoiNL8XI6whA/BZMUJIigr2fnRnHYrI/xPCXACw7irTEMwCYJlyDQB4xFmmsSlB5Ka1NgEAAP//7N2xCQAgDATAbO5ormZlZyMoiH+3QoqQQD5CNQAASOLbCgAAAPCSrhoEsJMD4Af6GQmaKkMOx1wAsM2XYwCOMI8BwBUzBFGYBmtVNQAAAP//7N0xCgAgDAPA/v/VLrooOCmCufuElNpEqAYAADH6QsunRwAAAOA5LdCk0O4PwA+8Z6Qwp0Ce6ZgLAFhpOQbgCuEaAHDECNMQgsheVTUAAAD//+zdsQ3AIAwEQLNZVkBinyibZbQ0iIKKCqT4bgVXL8tvpRoAAKTSl1uCEgAAAHCaL9BkoOAWgD9xbEwGd231MmnIpx9zFTkOAIZXmQYAO0zlGjIZAKx7lGmwLCI+AAAA///s3cEJgDAQRcFtMWBD9hNICVqaCMGreFHwz5SwtyzkragGAACJLBwBAACAz7SlbaZPAlf9AfiT0ccu3E4IAUAIdn4cFtcAINx15Th9EAC8a8Y1vMkA4N4qgshjVXUAAAD//+zdsQ0AIQwDwIzG6D8aTUT1FQVI+G6LBGIL1QAAIE6nEFo2AgAAAMd167PmZxL4dA7Ai7wvkWD03AIEc8gFQKAVpqHlGIDbzGQA8OsTpsG2qpoAAAD//+zdwQkAIQwEwPRflaUdSPBxTx8i7kwNwrIEE0s1AACI1CXK8AsAAAA4zdVnEoy+5g8AT+l8k3Ek0FuAyUcuAAJYpgHAtX6dTE4BkGr1Ni+AbVX1AQAA///s3YEJACEMBLCOpiMI7j/L89IRRNAmS5QTe1WqAQBAZT59AAAAAMeMOf6STxefqcC7GwAvM+eooGV+AVjycEm3xAXAQ5RpAHCNLNfochkAxcht7BMRHwAAAP//7N1BCgAgCARA//+qnhaBlzpHkM58QhZWdVQDAIC2MlQpPgIAAACv+PZMByO/+ANASTnnzDo6kF+AzepYWOICoABLWQB868hlOvAAVCW3cV9ETAAAAP//7N2xDQAgCABB3NyF1BVtKG0tlLslzCcgPtUAAKC0vKYisgAAAICrXHmmEAN8AFTgvaMEHQOcWOIC4FGWsgD4RnZZX2M2XQbAR3Qb90TEBgAA///s3bENACEMBLCMBiMgsQ+rMdo3KV6ipgDsJaIDJeeoBgAAeEwEAAAANmq9FS3PPGJmez8AXC3nnf8lXjAyzwAsLHEBcAhLWQBc7ZfLqqJJAA4lt7FfRHwAAAD//+zcsQ3AIBAEwW/NnVEQEi2SfE6EZetmWiA6BCuqAQBAvB5dHngAAAAAtwhqkMIdGwAx1lzDaRPCngGOxDUA+CCfsgCI0uHDp+MathkAf2C38Z6q2gAAAP//7N2xCQAgEAPAH83V3NwmhZ2NiPB3S0jgTZRqAABADjy08wIAAAC3ZdXZsjMdzKz2A0AnjtPpYCTXABwp1wDgAz5lAdBayjX2bOY9BOA3chvvVdUCAAD//+zd0QkAIAgFQFdrtDaPIIg+g8DAuyXkwVMd1QAAgE2pAwAAAHjNV2dK8K0fgIrMPwqRa4ArFrgASNAtZQHAaWWzNmeknjwAH5DbyBMRAwAA///s3TEOgCAMBVAG7yVXKHggvblp1M3FxOjAewkjC0vzgcJk+QEA4JChLHrbXAoDAAAA3hBLZJOlH50ZgUt4AIzM2RIjqJlvPCQDPJUNXDkleqtnvbRPAsDbtqveAAD3zsblHGv0lnVzls8A+JDcxv9KKTsAAAD//+zdsQkAIAwEwOj+QzmaCIK1IiLkboUU4YtPqjEAAMAyg5qLhwAAAMANypWkoFwJQGb2IInIN8CxUeDyHRmAi9osZRXFLADYM3anfAbAI3Ib/4iIDgAA///s3cEJgDAMBdAc3EscoeBC7iN0hK4mIp7spdaD6HsjJKfAJ3+wDgAAuFh83wUAAAB67C3OBshPCNsBwBFAL+bA16U5lbzmyaKBuyrtyB72ANDifKahNAsAOlXus1F+HoAHuNt4p4jYAAAA///s3cEJgDAMBdDoZO0IBccUXMHRREgPXjyoB9H3VughfEj6R08DAABHGd4cAwAAAACXtKkVRyH8xKqdHwAilnnpC+jwdSXzDsBt2Y485OdU5igAZ3q7cXWYBQDPy3xWM6PZoQfgin1+VLmN14qIDQAA///s3cENgCAMAMA+HMwVgIGU0dzMkGB8+DHGmBjuRoBHaSllsjsAAHDVioOpZBN3AQAAgCcM1GAUmuoA4FTdKzGIxeN34E3H78ip5LnHUnUVAKKfObfWx2c1AOA7PfaucjQAbqryNn4hInYAAAD//+zd4QmAQAgG0ButFQ5aqH2CVnC0MOxnQRBE3HtTqKifpxoAAHDN8iMAAADwSKU2mycwgqhUfgAgl83XLfrcQy3IAKbse9SCwNvO5xp1vJWL+IJQAMa0HLNHycYA8Ck9GgA3op5p6Nv4j9baDgAA///s3bEJgEAMBdA4ojpRJpPbTFIIglhYCEreG+FShBT3v1ANUlPXtAAAC09JREFUAAC4UQfevC4pYRcAAAB4YPNYNJEGDQAXAtvpou6eybSBtxztlpqRAdqoj1hDuzEAfNN5RwvYAGgt3W38VkTs7N3hCYAgEAZQbTNHCFpTW6HRQrgfQUT/gvS9FQSPD727xekBAMCzCHymJwIAAACv1m31cMwsDpvJAeAu6qMayRTkH+ALfRlK/7ex15ZjeJU6CzCWfreXvbaiMQsA/iEyWrnkNADGdkRuy3Ibv5ZSOgEAAP//7N3BDYAgDAXQHhzMFZCFdDQ2MyQcMXoyAd5boQfS0uZvKggAAK+kigEAAABfSE1lFRbkAOCZfyVWUfsfC7TAbzrJyOYwAGOqB1nFMRYAjK+952fKx95movo0gHlc+jamEhE3AAAA///s3cEJwCAQBMAjnVmCkIZSWSwtHNwz+A3RmRIUlEWPPewoAADMZfOJQQEAAABgpp/9tkBsYlQLPwDwou5J70psQQ4CvlLNyNmK3Ny7AL9xVbNxM5gFAGvJv/ZyGsAS8vxuld3kNtYSEQ8AAAD//+zd2w2DIBQAUDpZ2xGuupD7mDiCcbIaW74b/TCinLMBfBAu3MfjzBXpFM0Z8gUdAGC3aJvJZDEOpJMntyX+BwC4Pm/r/0UX63uBYjKqMA6j8wAANoguPvaJSrw1XQNKkP8kn/I6AIrSf5v0/oZaAQCVibZ55RhN/ihAudZ4bVbLwu2llBYAAAD//+zdIQ4AIQwEwAr+zfFzAkGcQOAg6UzSF9RUbLbFlgEA4FgTvgAAAAA2hIDIwlcpADjX3IkkUVfoFuCqf/BfwQbAVYo0AIBp3QNjPgUbAE9RpEE+EdEBAAD//+zdwQmAMAwF0K7mCIEu5D6FjKgXrx6KaNW+N0IOhXxI/9AWIU21jKBNDwC44gj0NM9yh1UowV/Z/wEAvk+2fi5qyAqYRrb0FgBAh6ixmReTWLKlo0nglXywAfAIB1kAQBe7GsAQblaYVyllBwAA///s3LEJwDAMBEAVWTDxRN7MoxlBCrcOIQR0N4JcSeb/qD4AAADYkY25Z7uGAx4AAABwU6hBFd1LA8C2rnCYInIvUsAG/NIaFBDaAniVIg0A4DG7GsBn8q9qZBbKyCktIiYAAAD//+zdwQ2AIBAEQErTEk4pU6VFQ+KLH+jDhJkaSGAJtyjVAACATuW81tg3P4sBAADA5CKHx8JMoxzFegeATnX/jBxKNZhCzUfOjMDfGdoCeE2RBgDwuSarLU9Oc68KME6RBrRSSjcAAAD//+zdwQnAIAwF0KzmCEIHcvQiePBUiwdB8h5kAi+GmK9QDQAA2FP8RAsAAAB51ad6yEMmxWkDwDYzJbLo/ZHlSuAaAjYAfrOMBQAcM+4cvdoUsKFfA/gmABFWIuIFAAD//+zcwQ2AIBBFwW1xlTJNKEFKM3jSxItcjGGmCcKHPFENAAAY0Ae7XJdmoAMAAIBpCWowi1a36sM8AAzq52iW9KbEFLLkXrcqyAb8zkNgI2w/wOSENACAz10CGyf3NYAbIQ14IyIOAAAA///s3cENgCAQBMArDUtAbYiC1BI1xg9v/GhupgT43CbsYakGAAAMOrZ9qst8Oj8AAADIpa61KEWSSHPZAPBaMz+SRLnzkqVswJ91RQS/IgOZKGMBAJ8nrwE87zdkNxgQERcAAAD//+zdsQ3AIAwEQK+IlH0yGowWQRqKVKEC341AAUKy/4VqAADAmt60VJ0hAAAApKL5hiyahUgAWNff03KVZribJO65QRRgZ1qRgcNZxgIAtvXxXxOyAZxoBCCO2Y333gP+iogHAAD//+zd0Q2AMAgFQEZzhaoD2X1MuqLpDOpH4W6F/kADD6EaAADwwmxM27EbggQAAIAi2tku/wAU0j02AHymqyMpYpt907iH5UwgHVeRgcVZxgIA0hKKCCQiABH+EBEPAAAA///s3bENgDAMBECvxggB1iSswGYgd/QgBPhuhKSwXnI+SjUAAOCidelDm8bdOQIAAEAJlm6oYstf9d02ANwj52qbm6J2qsjcZOEX+DUPtoAPUKIBAJR1LkUMmQ14N9kNnhARBwAAAP//7N2xDcAgDATAX43R2CcSI2S1iJ4SKQjfjWBXX/itVAMAAPZoSV6zBAAAgHvNb8vWSyHdsgFgu65UgypmfhrPkKGAMhxsAYfw0RgAYEFmAw6iRAP+kOQDAAD//+zdwQmAMAwF0G5mV4hmH+lmjiYFj56kiNj3VsihCfQnlmoAAMAAfZiNbXVdDAAAAH4qMqoPNUyk9Wv6Cg4AY/X3NTKavpJJ7JFx6CuBWQlsAS+xRAMA4IGbma1eOYBFHgAYzBIN+IJSygkAAP//7N3BCYAwEATAa80SovZjRWqJihDFlyhEEDNTQj45wu1GqQYAABQyj1OTunZxngAAAPBLAg9Uw4/iAPCe7Z5NfTJbUoshLwwDVO+iZENgC7hrD2Ip0QAAKCwH3Y93rFPJRtgVAB5SogFfFBErAAAA///s3cEJgDAMBdCMVkcouFD3ETqCq4kHL0E8KYp9b4T2FPj5UaoBAAD3miJi9aYAAADwH3WuxXIDA2k+GwAe1wSxGUTZ56m+dMFhgCQvxLuKDJywiAUA8JJUsqEcEbhyZCzMbvBlEbEBAAD//+zdwQ2AMAgFUFZE3cfVHK3pwcRoj5qovLcCh/KbAJZqAADAjXoIznnafJQBAADArxh4pIx+PV+1AeBZ/b3NJfWYVLEer3wCMHa+ihwGtqCafYHGZekOAADvMOrT5DYoR3aDr4qIBgAA///s3TENACAMRcGPMywA/r2QMCEBmjsLnTr0tRkeAAAAAAAAAAAAAMC7xpr9OtIS6IK/+WQMAFCU0AaUcnY3AQ0oIMkGAAD//+zcQREAIAwDwfh3hTOmPwYFhe66yCMnqgEAAAAAAAAAAAAA8JgrtOGwBT0JaAAADHeENiKSCC3VVlsR0IB/JdkAAAD//+zdsQ0AAAgCMP6/2hfcSLT9ggEwqgEAAAAAAAAAAAAAcIRnZKhQwgIAYM1IItTIbvBRkgEAAP//7NyhEQAgDAPA7L8LsAKjcZiyQBX3r6LrIlJPNQAAAAAAAAAAAAAAPmawBW1qgHXzGnM7LQAAXXQ3aKO7AU+SAwAA///s3DEKACAMA8D8vF8XHQXpWvDuDVkyJE41AAAAAAAAAAAAAAA+dA22tpIDOAywAAAYQ3eDJ90N6CVZAAAA///s3bEBABAMBMCsiIUshBW11CrcdalTfZGPUg0AAAAAAAAAAAAAADap5LrMPiTzovX4Kkbr1ZYBALiNwg0+ILsBZyJiAgAA///s3CEOACAMA8B+fT/HIhAYki3cvaC2onWqAQAAAAAAAAAAAADAtcNoy+kGXdWey/gKAICf6G4MorsB7yRZAAAA///s3bkRACAMAzCvCOy/CzV0ueNppCmcwo5RDQAAAAAAAAAAAAAAjlHc4pHlW3EUrwAAoKyNvmdo9xs3GM0A/kkyAQAA///s3DEKACAMA8D8XPy5uIl0rgh3T2inDIlRDQAAAAAAAAAAAAAAWhXDG1He4jDvYyhdAQDAG8Xwxja8A9kN+EKSBQAA///s3LENwCAMBEDvvwuwAmyGkOgSepzcbfDuvnh7qgEAAAAAAAAAAAAAwLUOA64w4krlMbTaeiu1//04AADwFfpbequfjZcQuhuQV0RMAAAA///s3bENACEMA0CPxgrw++9CR4GEeCEqdLdBShd2jGoAAAAAAAAAAAAAAPCU+rWSpGxuUur6b1WsGnwjBgAATshvV8luALMkHQAA///s3TERAAAIA7H6V40DGJjgEhdd+k41AAAAAAAAAAAAAABg0BSXL1IZBgAA3vq035xgACwlKQAAAP//AwABfYYWIBDxNQAAAABJRU5ErkJggg==',
			// 	width: 60,
			// 	opacity: 1,
			// 	border: [false, false, false, false],
			// }];
			// aHeaderColomns.push({
			// 	border: [false, false, false, false],
			// 	columns: [{
			// 		width: '*',
			// 		text: ''
			// 	}, {
			// 		width: 'auto',
			// 		table: {
			// 			body: [
			// 				[{
			// 					text: "UR NEXUS",
			// 					fontSize: 14,
			// 					bold: true,
			// 					alignment: "center",
			// 					border: [false, false, false, false]
			// 				}],
			// 				[{
			// 					text: oHeader,
			// 					fontSize: 14,
			// 					bold: true,
			// 					alignment: "center",
			// 					border: [false, false, false, false]
			// 				}],
			// 				[{
			// 					text: oSrvtyp,
			// 					fontSize: 14,
			// 					bold: true,
			// 					alignment: "center",
			// 					border: [false, false, false, false]
			// 				}],
			// 			],
			// 			alignment: "center"
			// 		}
			// 	}, {
			// 		width: '*',
			// 		text: ''
			// 	}, ]
			// });
			// aHeaderColomns.push({
			// 	image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWwAAABuCAYAAAADICkGAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAIjfSURBVHhe7Z0FeBTn9v9nQ/VWbv329ta9t0Zb3KKb3SRoEhLiuLtLgUIFKe6aECUhuLtLS7FSqhSHCoUK7W2Lfv/f874zKxEILRV+/z3Pc57ZHdvZ2ZnPfue85z2vAZ/5zGc+89lVYT5g+8xnPvPZVWI+YPvMZz7z2VViPmD7zGc+89lVYj5g+8xnPvPZVWI+YPvMZz7z2VViPmD7zGc+89lVYj5g+8xnPvPZ38Yu0E/rl0WYD9g+85nPXGbU6wWj5iAY4SNhhE6B4T8NRuBUGME59EwYIVmc0sOmw3Bkc5qrX4fTZVqd7yPoNfNh1JgBo84sGLVnwoiczSlfx8yBEc3XMfPoc2HEzdeetAhGwgIYKZwmL4TRYAmM+nzdcBVfL4fRbDWMJnzdbK1+3YrTlvQ26/ma3m4DjLacdtwEowO9yzswOtG7vwujG6c9tvP1ezB674bx6i4Yr3Hal97vA/oeGAM+hvHmRzAGfcrXn8AYspf+OYwR+2CM3A9jlOmjD9MPwRhzhM7X447CGOvh8t41j+tM/gLGxGMe/hX9SxiTTJ/M9y7/mvv+CsM+OW7+GoXNB2yf+cxnLjP69iDUXofRawhsXSYQgmkEZB6MRnPhV59AbUSYNiZ0GxG4Tfi+Kb0Z59FtLQjYlvRWhG3rxYQpp204bbuMQF0Koz2n7ZfD1nEFocrXnVZq70wQd+O0O0HcbR2nBG8Pei9CuOd62HpthK33Rvj13Qyjz0bClkB+7V3Y+m2F0Z/+OkH81jY6oTxgO/wG7IDt7V3wG0Iwv70HpYZ8SPB+CNtIAplTv5GE8+hPYBvzGaH6KWzjOJ3wOfwmEM5T9sE2hWCeegBG6kEYafR0AjqL8M06Clv2MZSaTtDmEL7ifC/zjDzOyyWcTbfN+Aq2PEJY5ovn87XL5f039OMwZp7w9pyvkXbgrPlrFDYfsH3mM5+5zBgWReg1g21gZ/j1702AU213HwG/DuMJZCrrhoR3A8I6ZR78GnLaeD5sCtxUyQLu5nSBtgI4Yd1qMfxaE9wK4oR2Ow1tBe8OnAq8XeCmd11DaFM5dye4BdrihLbxqkCboBZg9xWnaia0jde2EtwE9hsE95uEtrjAe9BO2AbvhDH4A06poodRRQ8nuMVHENyjNLSNMVTUAu7xe2EjtI1J9MkEt/iUA/CjK3CnH4YtXaBNQNONHIKZwLZxqoCdK8A2fTrnEdYK2AS3l+dTRStoE9gzigB29nGk7feFRHzmM5+VwGxjAvhI74AxshYhlwJjYCuCuzvB2I/wHAq/jmMI30wCehaMZAK7wVxCnLBuyGkjTpuIa+Vta05wC8AVuEV5c6qUtwnudgQ2p7b2hHZHvjbBbRPFLfDm9PZXqbJbUXn3WAdbjw2w9aTS7rUJNgK8lAD8tc0ENpW3UtsCboE2lTbBbXtrB8FNtU03Br0PPwVuN7z9BNyjP+Z3FmhTaY8luMcR3OM/h23SPvhNMpX2FFNpT6PSJriNjCMK2qUKQFuB3APaLnDnCqw5T5S2C9yisE1oe4I7mwp7/xnz1yhsPmD7zGc+c5ltdBjVZhDVpp3wcvJ1KOEWA2NIUyrXjoTia1S8g+HXaRhsbTOorqebiptK+3IUN9W2rY1AW0IloriXw9bBVNsWsKm+a4/fjiOnfiT0uUxCJEpxc9rbVNwSJiG0jX5U22Z4xCbQpsq2SYhkoIa2MXi3VtpDd2toDyesxUVpjzKVtgK2hrYxUUPbUtritqmEdoYGtpH5e5W2CeyCStsHbJ/5zGclNWNcIIwJhPREcUJ7PNX2pGCqT4J8VB0CrwGMAR0IyL4wXn2byroXjPiBBGoubPXnqFCJUZ/uUtyEdyHFzamltF2K21LdWnHbCG6/TgS3qO9mXNZ5LffJbbtvwDVU2QJuG8EtStuvt8S2N6kYt+21rfCTEIkV2zaVtm3AdrrAW4P7WoH2W4S3xLZH87XEtQXeYz6Dn4RISqK0s0uotGW5QNpTYYviFi+otCWG7QO2z3zms5KYMS5Iq+qJBLVAewJBrTxEAdxvohN+oyMIuhSq4ShzK+DunsNhtJ1ItZ0NI2EmjOS5Zox7nltxN3UrblHbfi0ltl1AcbcnsCVUQnUt0Da6iNJeiRu6rFGf81g/KmxpoLSUtiu2LWpbQiQFGiNVTJtKm64UN5W28TYB3fs97PiKoBzEeRIaGfkhgS0hEjOmXVBpT6EraGul7TfNW2kLrFUDZDFK2w3qAu6ltOnTfcD2mc98VkIzJgRTURPWEhJxKW0L4PTxnD+R8BaAjw+HMbAeAtIHEJadYXR9HbUm5WHYovdwS7Ncqm2CWMIl9WerzBK/plTdl1LcbbmNqbZt7SS2vQIP91uDiWsJS9muHUHdmU6l7SdZJWZcW8IlorYlVKLA3Zfgpgu0/VQWiVbYorTl9SNjPkT0zP24e/guAnsPjGEfwk+FSMwwSQGlrbJIJprQlkZICY9I9ogZ07Zg7Qnt36S0079E2gEfsH3mM5+VwIzxGtg2KmlxBW3lAnET2nSbwFrWnUhFPpyvR8bB6NcYA7ZsNPfEfcUPgVE3Ff9oQhgHZ1B156sYt2qYlPi2pbgJbFtzKu0WorS12lbhkfbLcb0AvOkyzNpxGPWm7OT8BYhO3aEbMHvo0IhS2pJJ0ovvrSySPu8oaHsrbXpfmXL7t7Zi1rtf8w9nJ659m/sdtgc2QrtIpT2eSnuCOME91QyPiE8zY9qSPaJAXRjal620M77yAdtnPvNZyUyp54kE8WSCWTmhLT6J0BblLQpbqWwP1T1J1LbMjyAIIwnVelTKLai4B2DsynfMPQNBfdfAiJ0Fo450mKGL4ia0bc2osFtIqIQQVrncnKpQiShuglu8OcEtjZcRs7Bh71cYuYrwbMv3kv4nroBtZpH0lBCJh9J+bStK9d8Mo9smzN9DuHZ/B3HzD+G7C+f4mgpcNUYS2EMJ6+KUtpX2ZyltaYikylYNkVTaNlHamQWUdjan0wltgtwCdrFZI5bSTvcB22c+81kJTcFaoG0Be5LA2nQBt8S3LbXtUtyh8FOKOwQ2wttvdHWq7mQq26ZU04l4a9k67Dh2HFUGLEbZ7gtx8PhJTFj0Ea6Jp+KWMIeobQVsa0pgt14Mm3S8saDdZjkhvlQdY+8FVL/1uazDahhd+CfQfT1s3dbBTzrcSEOkhEi88rXFt+Pewe+gRvqnqDhmN9YdPYLQqe/zqYDqetBuGEM0tI3hBLfkal9UaUtoxIK2VtpuYOvONS6FLapaoG2q7GKzRiz3KWyf+cxnJTVjMoE8hcCeSjiLu5S2h0+hi8IuSnGr19x+bAASFw/Dwe+/gzNzPCHcmTAeiIixueYnaTPCM2FEzaRLhxyCuukC+BWKbS+h2l4FI34mnu2+Ctnr9sNoOA9Vx27HbR25njROdpXONmaHGxPaVr62X+8tKoPk+s7L9WdyefCE9zF5zwncJZkjor4H79ZK+20T3hdT2p7ZI55KexqVdgaBLbFrgbYo6stV2j6F7TOf+aykZkwicAXYAuWpdIGyp1vQvqjipo8LQOm85jh39mecxXkYvZx4YmQ/tJqxGE+9mYpWU5chYiAVsT0Hh05+i3f3H8cjBKpKBfSIbevONlTTdbLNIzwLVZuk8VKU7qszR/7T01Tarh6SbmhLl3altJutwbdnz2DI6kMw2m9W2w1bewS3vLYNu06e4vrbYFMZJGYWCVV2sUrbM3vEytO2lLbKHDnq6saulLaESDyVtgXsopS2T2H7zGc+K6kpUE8mtFPDtAu0LbV9ScUt8DZdqe0gGANfoHp9DsagSjjw7VfmpwARU6ioG78Nw38Q2k7dqeYdoho36kg+txSHEsW9wN0o2XoZFfZsBI6gGq4/D+2mb8fX//sJ1yabQO8sPSQlDXAt/Lq6oa0aJbuuR2TmB+i9kIq43Sq8umYvMnedwKPD3kGXFYdQazoVtHRxl0wSUdoC7EspbTN7xEtpS5625GhnHIafh9K24tmFskaKUtoK2L6u6T7zmc9KYCok4gnsKYS05QLsEiluT3BLDnc4SkmYZNDL6LZiFHI+exf/eftV1JmoVXPeDirW4DEwHHNgBKWreWJBb1Axq6wSQrvZPMKbcBbVXZ/va+bj4xOiRH/SXeTrEvKSjSKhERUeEWgT1j0kg4SeuADLPv4C8Vkf4omhu7Dl0ElM3fGNAny3+QRtn3d1Fsmg9wso7YtkjxRS2gS3WSzKpbQlDGIpbYG3BewilbYP2D7zmc8uw4yphHUa4ZpG2IqnFnBPtX0RxW0jwMV1bFuc82U6uiKVaxWCMQIvTelrfiqoln+AETkB9UbtpMrORM/UbajUj4o5ZT6CB2/E3a0J5QaEdaOlGDR3h9qmwlsrYEQR1PUWqferPifwGlGNd1lFEK+CresalOq+nIDXjZUrPj2hyrz+cOpn9d7WYR3e3HgEZ/ELjE6bYHtDcrR1l3altEuSPWIqbQG2qvKnXMIjWmlLTFsaIt1Km16s0ub7aV8idf+v6viKMh+wfeYzn7nMmEJgC7QFzmkCX4G0OF/LvBIqbtuEgnnc4nadTTLWH4/nJKHNsmEwutlRZupIGK27Ys5H+82jAFpOfo/gnqHqby/54LCaV/X1ZQQ41XWTBfjlglahRmw+XnlzAx7puhLjFhGUTQl11UOS0O5K77QFLw/bgHv7bMdrc3aj9PD3MHrzQQxa9inKDtuMgauohJsT/K7CUWa+tqW0PbNHLqa0var8uZW2ytGW0qwWsC+ltNMF2D6F7TOf+awE5jc1mLAJgi0tDLZUgnsaoSuuFDdh7Km2xS+puGWeVtsuxT2yIrI+WWZ+IiHU9TkCM4Uwro2tX7qL9z9MRb3ww29Q9zWq5DhpaFxANT0HGSs+xvUNF8MIy4CRtMBcGwgauVmnCUq8u9NqXNtpjeqAU37wJrW8zWzCNnYpvvyfVrBG53cQnf6xft1mne5gQ2gXUtqDLq60VZU/qmy/8RrYup72QZ7Lg7BJF3ZC25ZJSAuYJZZtQruw0uZ76enoA7bPfOazktg1VNPXpNlhSw8joAlYcQG2wFugfTmKW4BtxrZdPSetOiVvv4DAWe1QY0EPGCNeQZ/NOnY9eq1kirSCUeM1ZGz7TM0TO3byWxgOGe1mCiau0vONmjPxUOdlqDZ0HT7+6kcc/fE4ob4cXXOpiBvkw2i/Ev/uuxHZ7x3Bv3uvxDWd12Hbl99gwZ4v0HwmIdxiEX668Atul67ukq9t9YosoLQL5Wl7Km1XPW2CW0IjltJWjZB0yc8WpW3Gs1XGiAC7KKUtgx/4gO0zn/mspGakBeOaDDuuJbCvmeaAX7qDKpEATw0ngAjxK6S4ldIeF6DytY0x1RC1oLd5BMCkDRLKaId7+ozH6DW7zblAcO9l+OKHnzB0/icwyqZTYVupfsDcnQdhVEzHQ93dyv06aaCMXYwfL/yo3hutV+DGdhLv1iO6GPELUHb4Ozj000kq8bXwkzKtHtAWpe1V5a+A0laDIcjINRIeocq2jd2rlLaNSltUtp/VhT1VlLaER6RzjcSxvaHtVto+YPvMZz67DLuW0L2RgL4hPRzXp4bhek6vmxbGR3o7/Ahyb8VNAIvinliV02ANbIGxUtxc5qm4LWCLyhbwe8a2Bd5jpDEyEFVmUV2/9gp2HD9mHhFwW6txBPQwdMj4xJwDfHb8Bxi1stA8W1ICz6t5Axa8j0lbjuCtlZ9g5Jp9KNViBTYe+hIpaTtR9q1NMJqvVuutPfQjItM+wv1vrFfv7++9Rdfalq7sVl1tC9yqaNR2D6VNN5W2GghBwiLWyDVmPW2b9Ih0hUboqYS2AFs1RFJpU20rpV0opu0Dts985rPLsOsyAnBjhgP/SDfBnenA9Rmh8FM9IP1xDZV3KYLaJuCeKso7BH23jMcDuYmwTQyBn0BbhU4cKCWAdiltE9SjXoYx4DHYJofDz4xr69g215UKgGP5RzCuGv41Kdo8Im0PdxuJQQt2Y/LGLzB3x2FMWa0zRcT2fvUdnu+xAvVG6A4xYnuOnoBRIR357+qGzJUfE4Z1crF+3zfq/a8XfoLhWISak9/HJ999DxnVxq8PFbZZV9sFbLrtdaptD6XtlT0iY0SqkWsKKO2JBLa4KO0p5uAHrnQ/3QjpgrYnsKd94csS8ZnPfFYy+0d6EG5Kd+KfmWG4ldObqLCvJZSfntMA/d+dSLXsj1LTwnWMe0oQSuc3Uttt/2ofIVVOq+/RpQl7QnvIswrcKt4tsB74mFpXzBhRhvviPAmLjKFCH0dYi9Iez+3HBKDt6sGE5tN4Jf1VGF0a4OvTluo8h2ELqGj/MwprP7M64pzFp9/8jMB+qyi2fwEu6Lknz5zG5gNfYdSmY7i++Qp8/dMpNf/ChdP4V6+NGLd6r3p/72sbVd62q662uAVsT6VNd41cIzFtcQmLFBwjUpS2FIqSIlGW0lYq26w5osqxFqg5YsWxFbB9CttnPvNZCeyWjEDclunErRlhuCXdgVuzBbblMf7D+ThDEgbM60CoBKFUOgE7qRpBW5nQepyQIoBFSY9+wdyTNmNCFSppgnicP2FcFTdQSXfZNJLrVeD7aoif3x8jtmXCT8AtnWzGByFodgdza8A2LpiQDME1PeviFzP0IZaxaR+O/vATX13AjiMnsOPoF3qBac631mHN++6wSoucd/F4vw3mu/NYcZiqumouZrx3kO/PwGi6whydnQrbVNpq+DGv0Ig5cs3AHbhm0E4CW0IjH8ImwKYrpS3AptIWlV1qHKFNcIvS1t3XCew0XdnPs+aIpbIVuNOO+YDtM5/5rGR2R4Y/3Y47s5y4MyMUtxPet2cQ2pMFsKUJmwDcRPUt6tkyNazYNM5L5XojnsGj2clK5P7464+4UUIko1/BW1smYsj2VK4bRIhJzJtwH/a83oFpxkAq8tH8E+h9F6rmNcKUXYupXKsgapFukBy5eTkeHzEURlI39V5L6XN498AJGDe9ie9+/Z+erewsRqz+1HzttgsXzuH7X35G6NAd2PnNKXzDfdzSZCmMbuvo69UINsq70yWu/TqB3Znw7vEODIll9yW8OxPkA3fT3+W6O2CMJKhlOkyATZXtGRqxqvvJiDVU2u4iUe7QiBUekXraRppPYfvMZz4rod2W7Y97COm7c+y4K5vAzgrDbQT2rZnhVN10Ku5bMkNxfRYV9hR/3J1ZmwCqQgAF42ZCe8+3xzDvAEE36BHCqzRVZTAeyogz967NGPg04V+FACSge92GZhveRkB+G65fDh03T1HrDKeiN/o9RsBXRfCcdmqe2Lx9BGXLWISPzeI7M/ahTNT3OZw+fwEnfpasEHnvBt9LXddi95cnzHfAQ32X4+nX1+L0WYkXX4DRZjUeGUBot1wOo8s6jF69F/e+sUWlBi777CTm7v2ay9ah3owP1fZGn/fQZLaEVLhtC63cbxtNYEuetowPqTrWUGmb3dddoRHlEh6RdD8qbc/8bMkemXbQB2yf+cxnJbO7MgNwH8F8b44T/yKw7+H0bk7vzHTgjnS7VtzpobiF69ySEYIbpvF1enWUoiq/iar5zBldae7e9EiCSfK5ZfzHpxAwtyM2ff85xn8wm+r8vxi0TYAriAXuVpkiBPj4akhY/oaaL1ZvZX+u+zICZrTDfZMjMfGzhXhmYhJ2f231iDyHPos3o1RSBs6fkz0R4BfO4+D3P8GoqsFv2Xn8igPfSgjF0y5g28HvYMTNRueZH6g54zdTCacsQ+4HX6r3t/cntFuvxA/nfkLbRVTEbbfg5TFbcd/I96m+t+mwicS0+3yAa4dTgQ//SIdIZCR2U2krlV2oJ6Sk+RXIzxa1TfU91Temo898dnXbOQUkbRcueCrLK2v/zqmGf0234/7pofgPVba8vic7mIrbQcVtxx3Z4Qra/yTAb6XyvoUK/GZOb0534posOwH1PAH9KIwMQpiAN8ZXxpzPNyN8WVeC7RnCqyLXKY/pn680PxH4/vx5gu5lOhV5v/9wHTuarBsIo/9DOPDjSXMtoFxuK6ryR9B07WBzjjYj7lW8Oec99fqX0zrHWuxskefpAnJ3HcMdbdw9JHd99T3qjtqKcdtP4t1Dx3Bd+40YsXE/qk0giJuvwc84g4zNVMTN16LKFJ2dctdbu3HbAF1l0Oj/ji4UNUTnZmtg00d794QsmJ+te0Lq/GyJZ6vR16ccQ9o+z9COt/mA7TOf+cxlD2T74/5sBx6c7sSDWaH493QH/p0dgnuzw+gOF7jvzAyn4nbg9owI3D4tTDVS/iPDiRszw3ADp5K7fY3kaU+oYu6ZsBlKYKuMEYL8rYdQb+mrGLJtGv6bmwRj0H9x6hfdwSV+cV8Yw14h2AMQttCKV2v7b1p9DNg5A7+cOY2tJ/Yhe9d2fPOrLuZ0+pxulCzdfiH+d1pUqhvelp09557385mfuMZZvP+lVtNiLXMJ15TF5jvg5r4b8MCbuu72RFHfLdYiJvNDNFhIGL9GRd2eCn/wDg3soqr7efWEpNIuGBoRlS3QJrBtWVTbU77wAdtnPrtq7fw5nD59Gs3bdkGlQAfsEXVQvmoIho0ca65wZe2BHH88kOfAAwT2AzmhWmnTvRR3TjA9lMrbUtwOl+KWBsmbCPIb+PpazitFkBsjnibInoR0uvEjsG/LqIFd336OynM6EMplVZzbGFywAfJBgq4SoVcR104IweD3MvBEaqy5VNuBk9/AaPMAMt9ba84RO4M5u77EYpUh4s4quZjd3HQxlu4/wscYrcjLjNiM1tP38M/gGALHbcPAlQcQmP4+FfYqPDJkq9qrFJUy3niXin+HWXNkJ/zoBXtC+o10p/oVys+myvYeE5LATj1AYPvysH3ms6vWnDXrIL5+E9SJSUJIWG3Yq0ehXSdv5Xml7LGcQDxEWD+eVx2PTQ/HIzlOPJwdSsUdRsVNtU1w35cVgnv4XtS2S3FnheFOaZyUhsl0J25JF6VNcE8Lxw2p4SiVGYFS6eEElaTuBeDzU18i7/N1hBmBLdklEirpeyearx6MgLltCPnnsfNLnSctZgyrQAX7GJqtfFvPMKMdcz5YipWHdQEnb6N29lDTxdnP5624to4bT3tvPyZu2KdeH/n2FIzYVWg0Z5d6n5xLxdx+I5rO/AyhaTIeJJX1W5LyJzVHZGxISfWjyvboCWkbUSA/WxogrfzsyVTZXvnZ9LSDPmD7zGdXqx0+cgSOiGhE1k3GuvXr1Lxvjh/H8KGj1esrbY/nBuCR/CA8PiMUj+WF4JEZDjycZ1eK+34q7Ps5/Y+ESai0/01w/4sAF8V9V5YTd2fY8c/s6qrTjcS2b8mQjjcOXJdlx7WE9zXpIfDjPBXbHvMKjHHlCSsCfHIVvPVuLg7++CXnVybQA1V2SI1l/cyjAkZ9mI/KMztg4eGt+PXsWew79RUO/3gc275yF4gSKzNiDOInzzbfXdpOnf4Vr5sNjrhwAf878xOMgOn46LCOnY9dT6DWmwtbh1X4Z18CWgb37UXvS3UtKX/SC7JAzREVGinQE1L3gvwUpcborJGCY0JKvRGV5jeJCvvzX9RnF2U+YPvMZ39j++bEN6heqx5q1InH119/bc794+zp3CA8kWvHU3lOPJkbiieopB+nin4sJwyPUm0/wunDhPP9hPZ/qLzv4/Q+Kuy7JURCiAu478oMVbHt2zxi2zdkOnGjwJvzrpOu7VTeakQb6Rk5NRivzG2C73/5iX8KcQQ4FfekKngxOw43jAvBgPemUc0+bB4huXr2An76+VfC8z48NCHSnOu29/gndznWNW07cO4XnPMKoZzFhHcPwUiah6kbZH9nYTRfws/crPO0+71DF2AX6AkpNUcGmzVHPHpC2iRrxIpnFzVSjShtUdmE+NS9OiZflPmA7TNl588XH++72DKxC+f/uKyF32oXPeY/4XDPn7/043hJrHGrDohPaYyUxi1QIzoB3Xr2QY9efdC4ZXscOXbUXOvK2dO5/ngiPwTP5IfiaarsJ2fY8WReYcWtGiUJaVHb91F5C7j/bYLbnU3ijm3fKo2RWQ5Vp0TUtsS2/SSTRAZLmFCWTmU9ujThFQJj2NPm0WiT+tnGyBew8MA76v0F87ed+eFy7Ph2L86o3/Mcjn77Jb77sXh1WrR5XydNMz/EpM2fm++AiLEEc/JitEnfCb9ea/CP3hvx9BDO67wFtv4boAY+kHojUkN74A74mUrbZiltyRpR9bM/Vu43+jPYZNADyRqZsE9DW4BNlS1ZI8ZEKmwfsH1WEvvx1CksX7kK6zduUr52w0Zs36bTpSz74KOPsY7z12/gOps2YSXX//Gn4lu1/0r76MM9WLOex2p+Hzne+fMW4sTJ78w1/lhbvnQZP3ez6/PXrLe6RpfcXixfFbGJjRCT2BB1E+ojKr4RasWmoFpwGPYd0LHWK2nPTw8kqEPw3IwwuoPgduBpAro4xf0gpw8QxBIquZ+K+16+98omyQrDHQT07ZK3LaESKmyB9vV8L4WiHsypjXl7t6DGwh6EdiUqTUJ8TFnMPqAr6YmN3ZlDmFdF0+X9zTnath0/pKZnJDuE/4/zP10HI9YoYVOjto4zP0SdwVvMd2K/ouGEdznV/+onzuhOLFuPnCK4l+Ga7vq46mVRSfckuHvRX6NLDW3pCWkpbVHZ4lLRT1x6Q44SpW3GslVVP4lnm/nZEhqRQXwn7sPUz34XsAt//eLUi2euqM+uPtt/4AAqBThRJyYRtesmoHqdWLRq28Vcqm3w2yPgqBWrlst6Fas51XZ/F7OuwU8/3YcKVYNd30WmQY6a6EKF+mfZc2UqIzI2CbVjElAzKp4KOdFcUnIbOXoCMrNzkZll+XQ1nTh5Co5/e+X/eP47IwClqaZfnBWKF2aG4NmZDvw33+5W3PkEd14oHqXafiw3BA8S6g9y+h8q6/skk0QaJbPdse27s8JxD1W29I5UeduitPn+xnSCOa0aum8YZ34y8Oj0WAI7GMbQ52H0uA7h89pgqMB66HN451t3N/M9xw/D6HQt/1zqqffnCvKIb88R4q4HqQvFd0QR23FEg//chfNU6+51931zEsbL6fj1tN7TnA++xhMDt+PR/utRdigB3XElpm48gJt6v0to67KstjcJa1VzRFL9OB0swKbSHqaVts3MGlHjQU7Yq1S2leqn8rPH7UXap78jre/bb79F9ci6KFcpCI2bt8NpM+fx0KGDcNaKQvmKAWjTrrua57Or2w4fPozw2rGo36QlH8FbIqF+U3Tv6R4oVWz02Imol9xULZf1wmvG4tDhK/9o/nvs5InjqOhvR2Kz9qjfuIU61rrx9dG5u4b1hSsUrriUVQ0JR4OmrdTnJzVshoSGzc0lf197cUYgyhDIrxDML3P6wkwnnieUn5vhpIfimbwwPE01/WSuuB2P8fVjVNMqtk2F/QDV9QNZHrFtiWsT4Cpvm8C+zVTat6ZLDDuAgHoOzVcNxrDtaQRZearPQPNIgAmfLCH0HoUxvhJSP5in5p0/r/+QW60ZhFYbx+KXn34tpCkVX81OM0bwk9h89GKxf72x3u9pGJUnYslH7vXbUIG3znkXM3Z+g7b50i1df358zocwGq3Eu0d1uVbptq5qjrwqqX5mA6TkZ4vKHiqhEcnPtrJGPtaNkON1aMQwY9k2UdrjPv9twLaUSgX/UF5szVGfF15ccmM0btlGzX+FALfm101owBv7NTXfZ1evKWBTPXsBu0dhYMcmN+HyFmq9sBoC7Mtr5PkjzHrqO/HNCVQLcfLYBJQC6xb8Hk3QqEUrtfzPtKohYeZx/D5gz50/H+kZOcii0hYfO34yeUQF+Qf0eCw9Kwhl8x14aXYIXsoPRmkq7NIzQ/E8wS3Afpav/5sfotT2U1TZTxDmTxTIJpH8bSu2/W++vjfTI287Kwz/zHRSXb6IxuveQr1VfXXPyCmEd7odD+VaqtkE49I3CPHSqqNNn12Zap5YzIoB5itth7//Dka/f6nXp818ak87c+60Utwnv/8BZ03oihm18jB50fvmO2Dnka/Raa6Emk7jxKmfMW2He2Dgf3RcjvBJ7vCJ0XMz/tN/I8LGEsqtVuMg9504kwq6J8H9+nZcM9gcYuztD+BnVvZTudlW1giVtsrNnvQ5/CSeLWERzk/75Dcq7PPnzqq8zwbqBm6h1ELVQCc+/fhT1IiM43t9Yyc3ao7omGRzK59drXY1A1vsAq/XMD711WtI9W/CWkRF9ah4c3nxRXX+CLtSwO7QqTtq1UtCNIVR3cSGqBDgMJdceSs7sxoq5NtRnoAux2lZKu0yhHPpmWEoTZUtivsFpbgdeJYKXNT2U9ND8URuwdg2wU3FLZkk/7HytrnuvRl2PvqXw/iP5pqfCPxAcWiMfQHXpIURYs+hxdoh5hIoJZ645i3zHeCc1QZGn5upTKuac9xmDCuLGvO7mu887PwFnLtwFr/+7xSMJ9oS3t4hkjP887Ps82/dOdCZmwjVatPx9Y9WrvZ5GA3WYPyGj5D30ZeoNlbnZ3/90/cwmq1CYq5uU3hl3Hsw3qC67rSRwN5FlS2ZIzrVr1DWiMrNltCIqbTHfPbbgG39e1eoZkdS0w5oSFgnNmiGmIT6an75aiFo0LgDUpo0R3xKUzRp6a6o5bOr065GYHu2m0TUqquf+kxYJzdqAUdEbXPpn29XCtjd+BvIbyH7kXMeEv7Hfadyc/xRcVYwKsxxovzsUJSdFYYyhPQrVNwvzwx2xbYF3KK4/5tP5/QJlU0SjEepslVsOy8MD1JlW3nbEt+WLu53Eer/SK+KtuuHm5+o7fo0qf5XBn23TkXKil4wel9PwD1GiL2MnI9113CBrtiDOcmE80N4aFqMem9Z3mfuHo/Dds1D9dntcfTHE1IPqgg7h7WffY1j38go7efIO9n3GRgPjMSUDe4sEVur5Wg97V30XPgB+qw+gHFbdd3txXuOwqg5G5sPfqvep23h+96r8ah0oukoo7TrrvFGD8J70Falsm3DCG6JZQuwpaLfGDNrRHpBSu1sKRA1ggr7t4RErEfMdes2omylAITXjkHFACdOntAlCjOn56NclUCE1oiCPSIS33//PecWeWZ8dpXY1QhsS1jUiaqH+AYa1HLs4sFhdcwGqb/murxSwJbf4M8CduVZgahCZV15Tihf21Fxth0VCOpyMx1U23a8nO/Ay4SypbifJ5hfyHW6skncse0IpbYfFld52/QsydUOw81ZAVSWjyFxWT8sOPoOIT0BxshH8PFxd/jh+A8/wBhVGkZaBKSetmcq5k2TQzHjU53il/P5JoTMaYNrxjkRv9K7QdnofitGbM0z3xW089iyj5C9caB6p6F+Hid/PU3I/4QfT32L/jM/witvu4cdM+rOxHUEuGXPDNyMykO3IGX6XjzSX0Il+jqTUMkzI3WYZfuRL2D0orrutYUq22qA5JTQ9swaUal+kjEy4hMq7IJVBd12yUZHyz7f692jyLID+698apHP/hq7moDtqaybNGuNOI9jkhCdvz0c33/356TvFWdXI7Arzq6CanPtqEKvPCcYleY4UInQLjfbgfIEeJlZ4SiTH4YXZwq0JbZtp9IOcmWTSGz7ackg4VTyth/Nc+DR3FAV176P0xtTyyF+eR8M2DENVRamENQPwS9NRpsph7WHdfW7s2e0kq44txVh/SzuyI2G0f8efmYSbp9ch+D7t1p+xux6nvfZKhjDy1CRP45+W3PUvM++OoaMvW7Yit59aGQ0fvr1nGQAethZ9V9wxlTvp09LSES/Xv35cRhVM7DkfRmVBnh1PoHaeBnu7LgaA+bthpGyRM0XM9qsxJNv6/j27m++UV3Ynxv7AZzpH2DkGp1FdccAwlrys1Wqn45nW6ERlTUixaF+L7BFwVyqceOPaPzw2Z9vV6PC7tLtVUTFN1THI8csYZCqweE4cuSvz1y5GoHtP9sfQbNDEUCF7U9AV5vrRDXCutLsEFSSUMmsUJSfGeKKbb88QxS3ziZRsW0qbYltP0X1/RQB/SgV+CPTCW0q7X9nBaHMPO+2rnore+PmtKq4TTrRjH0R277Q9UP+9/MZwvwJTPvQXQb1qelNYUypQriH4MX8xuZcAvL7A4T44+izZRo6bByuBkUw3rgfcz/3zK8Gkpa8BqPvSwWATV2s5PUFDF1KkFZKV68tixr7DgYs+QwP9lwLI2kWus76SM2vOvZ9NdjBy8O3qfcT1x2B0YJ/HJ1W4M43tqHTIp2GGDCZkO7GdS6cgfxVGD138Pi261KsEh6R0Aih7coaGf4Rpn6sqxYWZRcNiRQE8ceffIK169Zj3YYN2PX++zj1k/ufQNa9aO8y2uf7D2LNunXYsHGjcnkt84qyJUuXYcOmTXpd6aCxajU+/WwvHzo8jumCW2Vd2tzHdvSLY3jnnXfVfletWaPee1pJ8snPnfduuPjy66+wfv16ZOfMUHmy03Nzeeyb8FWB7sRynkqy/7/C/ipgS/frLZ6/R4EefMWdr+69eiMyNhn1eawaZq0UJPd8om+WS12PRdm5Ag2Tn3z6KVatXoN1/G137d6NHz2veY9sg6LsagR24NxqCJpjR8B8O/znBdMdhHYIqsxxojJBXnG2ExUlPOKKbdtVbPsFM7atgc1pnpNKOwiPTafq5utHcx14ODsED2SFmJ+kbfnBd2GkPY97Mmug07tDYYx7Ccbbd1N1Pgdjcnlkf6brZv9iUtYY9hQMGQB4XGnV8Nhp3Ri+rqpGsbFs8ZF3qFTLcd5zOE1FzQtBzZ/w4SI1Fdt8dD/u6zkAX54iHD040jLrY6z54DB+Ovs/fP3TGcxZ71GAqukiVVdk6/5jOPrD9zCaLIfRYR0MKm6j22p0maejEPf03wSj1Soc/0GnQButCfK2m/D0OMK682o174GRhPZwQl/1gnRnjRjDPkbq71HYM2cvQDRvCv/g6qheOw61o5OU16gdjxBnHdSOjMP0GXPMtS9uk6amwhFR17UPeS3zirIXXqmGOnWT9bpRSep1RM1YBDqqIyquPmbNdLcyl8SOffUlXu3zOvx5E4XXjFK1GepEJ6v9htWIQdUgJ7r3eQNffVFyZbZqxUq069ITVQJDFbgi66YgKiGZii8FsfGN1XGH8bMks6Z9565YyvX/zvZnAvvYl1+i3xuDeF2Fq3Pk+XuEc5+VqgXz3PbCgX3uG8bTxk6cjOpR9VzHKh5ZLxkbN+vY5u+x9WvWol5yYx5bGK+5euqYpPiSvuZrIqJ2DM/DBHPt4u1qBHbIHH/YCWf7XAdfhyJ4bhgBLoo7DAGEdVUCuiqVd4UCsW0rb1vi2i9SaT8+IwgPZwbBvigON057Do/lhSto355VhfBPwYff7cWWb/bgzkx/lJpU1vx0bRXmNMONaXY1CLAx/mXs/lpfA+mfEZATK9CrYML22XggM5KvK8E2SdIEq6Dm4lfVehtPEnxvPYrsvStx8IevcfDbLzBs1wLC8BW13GqEtL3eDWMXbNVvXOYWhNcnz6SqdrNtzCKqYRn/MZn7qjubkF6DUt1XoRSnRnd6s1X4+KsTWH+AMO9MkLdei+fHEcrNdKNpYOonMHrvxmvrpKPOrzD67eZx6swRq0ONMfRDKuzLALY1xI/chIF2gWOKignKhaJuDtP1e90SL+vYq9eiOtF/g8Upm8ysPMQm8vHV3Ie8lnlFmX9odd3pwFzXuljlBlBphIS2v6MGvvzSGure20SVWU8Iffu9icDQGuqit76H67t47FeWVw5yYFr2dLXd+WLSwD78+BME86apGR2PxAayz1Z0d2OXdr53fRb3zfVqxyTCWSMKn3+uG1fOnfOse3ABx7/+Bm8MfBujCIORYyZg2IjRWLDU3cjhab37veFaT6Z9+3vnpVqWmZ2DESPHqPUEMn3fHMRnjaKV4R8J7KJ+j/iUJub50V7w95CsJAlvTJ4mj6nev0dUfANCsLl5rt3bSY9CSUWtQtjWjknG6NFj8dVXkgkgVrziPndW77tZ284IrxOLZO5b/67e+5d58t2lu7gc24LFS9V2RVlJgT1q7BSMGD3O9Vv2e0Mawi640PGnAnuuPxwLg+CYH4TQeYEIWhCC4HkhpuIOotoORTUq8Ipese1QvEKovzIrBC/ODMWLBPijOZXNPQIrDm3Av9LL4pbUsngk247rpzwPY8pTuH7SSyp75JrJL6n1zppfeM2XVKITZRT2Kng+P5mK+y4q5kdhTCqDa6Ro1KRKekWaMeQJKnQpFhUIY+SLMAbeTzBTpXsobrFKeS2V6n54eoo5h38Au93d38UebDYT096RePMFyQSknYMRkAojZjZey9uG5/uvQdMcXcq181zCu/Vy2KiYbd3XwiYD+PbcAKMN1XQbKu6+m2F7TUZf36o8KG0Pjp/+juvwff9tnMfv+NY2TNp5GKXHE9bSoWYsp2/vQdrlAFvs0IF9VI0OJDRt5+opZt1MciFrgPNiNpfJI2m9hi0Q5Kxu7qFok1BBTGIDvT+6vJZ5RZkUa5cbVi5U6fggF7y1nYKh+VrU7YEDumupp1nRHGmQioxrqC50a1s5dvkO8l2898dljdoTqpGYNatoBb9q7XpUkRvRtZ3eh9on37uOmYCWPzPPG17WT+Q5rcRjXr3Ss+i6tkMHDiIgLBKxSU0QQ68Vk4Lho4suo1mumoPgbKrWq5fSDOUqBJlLvK19l+6oW6+h2qf0UKwSEGYuKWx/hsK+3N+jQaN2CK1eG3Nm655ulgn8vK8J7bJfz33XoygIcdREu86Xrh/dom0n1SNSQ9a8trkv+V3l+PSx6v2q35ZTe/VIjJ0wydyDt5UU2HXrpaBuYmP1W8pvWinI+z76M4EdPjcA4YR0+Fw7wuYGwTnfAQeBLYrbTigHUX0HEdSese3Ks6i0ZzlRnmpbwiRlqLDvySht7hHY+dWHMFIfwqwDy8w5QO0FbXFvTlU8MD0Yd+QEIHiO+9w45nfAdelV8cLMBuYcgmrMc7g+IwzXpUr6XyAez01CwIIOBLU/4V4NNZf2woKD7+GG8cG6e/uo8sj7TIcfxJYckPoejyJwJsH9+sMoNS4EL01rYS4VO48hiz8ioNNwQsIkpnUdpePgkWO2UFkvVIr7rJnHbUTlw2hHSCfM0iOu96CqlpHWpZpfn02ENl0q+vU3u653fkfXG5GBDoZwOvBDVM6RP4jzXJdKXIYUo8JO+/gy0vrOnT2LKv4hrotWpkmNmqFmnWQ4q9dBAi/Uerx4gkLDEduAFxDXURcSPTapEQYNGWnuqbBdDrCT6jdT3aK79eiDnq/2R8NmbRAaUQe1qWoTGrdVx6ZuBN5I1UJ4gStCW5pE29DhY9RjsvV54vH1WyA4xKm+g3wXJ2+4qNhG5o2ob0b5znKzedt5nPj2O1SsFurqbizrJjZsg9qxiTwf1dWxtWrTWR135669ER2ThGq8+aIIXgG5dU5l+2ohDnx9XHdrtUwDM8Y8Fp5nnk9RXEWZvz3CtV6DIo9XW/cevRHfwA2bkLBa5pLC9kcDe+Dg4eppzPotZB8JjXhM6vcQoLXg/iJRpy7VM6851/fj+ZK6IJ6WyN/OJRyKdL2tfI68lnMpaX5neX3DzAjwtI2bNsFZK9Jru0RCVnK7I/k7xvP3q8knpLAavAeatPbYdysKlVr49FN3rQvLSgps9eeu/qzM36gAkP9MYDsXBKEWIV19YQgiCG7nIjscC4IRuiAU9vnBCOY0aH6IV2y7yuxQVKDiLjc7GBXya+DZ3Cp4Iq88bkp7ETErU3BT6ou4Zeoz+gNMJfXjmR9xzcSn8Wiek1Oq6TH/hjH8ARjjHsPNWVVwRxZV8+TyhP2n+Pz7Y1SfpXG9jNaeEQE/6Sk5leCeSlUt9bTHlMbRU+6MIOPt0gR5NUL0H+i8biS++N+3eD63IZ7NcP8BXDPWTng+ibl7N5pzgIV73DVx3j3wA4y4WQgY6Ib+Ta1XwkiZDSN8DhqkEe715uPo/wjXCwRuw0VU2RthE5Xdm9NXN8GvN4FNUNteM0uwvvmerjUyaAf8Bu4itAnugZLyR7U98iP4icoe+D6mfnTK/MTCVgjYbTt04Q3ZTF0c+kJrrka42LylcGxQwgACIs8bwz8w3Fxa2C4H2MXZ1q3b1TBJ+sbSN0xsUkP07v+muYa2n3/9FRWp0q0bRv5QRD116tLTXMNtS5YsUyEOa5/yfWLimiIjM9tcQ1vX7r3VzWUdv9yEkdEJWFxM2MIyKTwvj+fWTSf7j0tsitf6eR9zQWBeHNjV3d+N05IBuxXsfxGwT373PaoEh7v2LdtLSKxV247mGm5btWoNnDWlE4x1HerfIy09w1xDYFgdVYLC4B8SUcgDHDUQxu3jpCyp+jx9fUoIJjZRd/wqaK2orusl6/Mk6yY1bIoaUYk4cMidGyy2f/8B1K4bp4SC9XQlbo8ofF5LDGyeZyu8I+fnrwR2jQX+iJyvoV2LyjpiYSgi5lNt871zHuFNQIcS0MFU2O7YtgOVFbideCjrWfR45y1M2JVB1VwLT2RXQ5lZDjyZbUfk8ibmp5AzG9/CfVlVceO00tj5pR5AwLG0E+7JCsK92aGq8p8M9mtMfIXwfRn/zAjHTRnS6SYC16eH6dFrpPExLZSK2o6HUiOUXDv2wzdUqU+hzhJ93WbtXUzFeyeM8QT0sGdhDiyDCe/mEJj/Rb+tuYT2NgzcvhYPddCFqHTWCJ98RlEph+SgbJ8V+OXcr7C1WIQOeRIS+RF+TRbAaLMUZV/Xg0q8vmgvjA4EuoRDelFtU2nbRGn3paqWwQ76m9CWqn4Dt8E2gLB+eydsgwlsGZ3G7AFpDNyJ1I9LCOyfT58xQaAvQpkKrA8cKhxysCzISaXXuA3X54XO9WvWScDOXe6++Z52JYAtduTwQVV5zdqP1DOpXM0bWIOGj0a8+uMhWOixVNaNW7Y2lxa28eMnITbO/ecjNYilFrGnSSch6zPlBpM46uVYdKy0B+j9y+fUjk0yl2j7vwzswSPcv4d4Ap/OGvBcFGdjx45HvUQLoC0UIBs2L3lv2uMnT2DQ28MRxj/3RPOJTI63Vt0UZE+fYa4FV1y9cqBTPano89kSoeHR+NJjcNaCFhYRxWMy98ttqkfHUaXrx2fLrkZg11xYFXWosusstqPOomDUXOBADQH2AjuBHQIHlbfEt0Vlq9g23X9uEJW2A6/MqIZ+73mPaP7cTGmIDMG/s0pTST9MAN8Fv3FP4L7sSng6Nxg3ZVXE7P0r1Lppexfi5vSKajQbgfbd06XaH8Gd5cTthPXNmXbXCDY3pIbhmnQ7rkurTmgHUYGXI5AfgzHqBXppHPje/fSa/xkBOro8FTvhPuQZtF43moCsiuSlb5hr8Olv/RwYrdogYKz72pi29Sg6Td6MOXu+guGfSRU9Hw2mSOlVCpCff4GRSLWduBTXtF2Bm3osgdFiGeZ/dBL/6inhkQ3wo8q2UW2r0Iipsm0yQg1Vtp8qwepRN1uNTkNgD/iAwPZ+8vY0L2DPnD1bqVC5MMRFTbbrWHTsz2pYHJ86japFF1gXj41vhMxsb2Vq2ZUAtnWD9ej7FuKSG7n2JWGHOXPccWd7RE3Ub+T+Iwnn4+6JE3rYn+LSxIIdFgTlMbw1/xS84SaNnHLDyOdJY2On7hpmUsqxJCahHevGS+KTSXgdXejGsv/LwPa3O11/7Gq7OpHYd0CndBb3e4Q45Xy7ISqFyC5lOh1VXunrZNbc+agZG6+gKn/c8kdRJ8p7MNevjh1FmCsUpf+MExu61aCnWdd97oxZiExwh9tieS0OHurd3fpqBHadhf6oOz8Y0VTWUfNDNbznByCC4K4uinsBFfdcgbYDoXz/Uu4reCX3ZfhTaZcnsAfuGGbuSVvNBbG4N/1FbDisQdd2WR88MqMinsp34qk8qf7nxC1TXsbDM0Jx3ZQX8HB2uOrK/p8ca0AEB26XwRBkuLEsGQwhTCltGSvyGipsW1oI7s6MRPbe9XhmZiP+IfiruHb1BT3U51lmvP0EbhlfEw9nxvP1M4R3AOHtnZ1iNAxE2+xFGLqainveh7iv1UKs2afhKVnURvV0GDFzMWDxPuw5fgJGnTxkbt2LebsJ9OSlBP4iTNp4DFLTxmixAjYZSkyAraBtqWz6GxIekdCIFIcisKXWiFT0kw41lwPstwaNUBX5rItQ4o3LVuh/v+JsOZdHxmjIyw0RndAI4ycXnap3pRS22JKlSxBdT/al/yhikpti3ISp5lJR/rVcN6B4OB+RL2U1YxLM/ekbQ1S8mPkfgSbNW6m4piyXG0wyHZSVMB9c/yHI8RAcDVuidRvvcMD/TWCfw+lff/UKY4nL08qlzF4j0rW+bGsPr4MLZhW3y7EahLE0HFr7CeZ+fvjB/di5as061IlNdH2W3APDR7nrNBdl333/PcKquyGvQoNNvJ/grkZgRy2qgpjFIYheQmAvDkbkolC6ncrbqdR29YXBOrZNaPvProJtX2/D+sMb8FxOWQQQ4s9kPo/xu9Pw0YmDeItq++HsCrh5ymPm3gm+sz/j5mnP4oV8rjtTBkYIxVNU2o/nhOLxXKcqHKVHa3fgXirt/xDaUlf7Tk7/6am0pQEyk4qZgB79/jRz7wTaOBmFnYp74H2oMKMJ1n25B1FLexPOj+O7X/Rv3n3DRBhjqkLGjrw3NQo/nzmLr349if8MddcrT1tLxRuajdsbzjTnSAx7OcE8D9c0pbKuMxdGg0VYvVf34Zi/6wiM5itgNFqgc7PNrBFbb4llb6bC3gxbP3ECm+AuZY1Qo2LZu9zV/Ajy1D0lDIlIQ5l1YYjXqpuAd7Z6jzhS0KRzSJ3oJHMbgjOpCUaNmWgu9bYrCezde/ao8IsVo4xLaY6OXfS/6r7PP1epWZ43U6v2RVTxKmDSEKmzAYq+MTJ4rFJK1oKVjAAyupjvWtAkHl43ToNOPDKhIfLyvQcL/b+qsA/s2+dVZ1sa2KTR8FKW2EivW9zvUVIbNmKclxCpFZOIDevdjU3SYUcGOLCWS5vIpClp5tLiLcTh/hOS68ZR4E/oagR2LBV2PAEdt8iBOKrsGII6hqCOJKhFbavYNmEdsKAyZn46y9yKYmZNfZTNrYKXZlbGvWn/wtM5z+Jlqfw3246XZvBPYFFLbDm5Ffa5cXwfiBepsJ8ntJ+kS5nWp/LC8VhemKo/IiVaH84K00qbLmNF3ktY35klw46F4eZsB/5JhX0TFfZ1EiKZ4s6QEmBfP8mBfae+RtaBZVSvD8MYS9U9rgp6b5psrsX1Bv+XSjwMxltP0B8nPCUVsIxeaD4wX9c8D0biPBj2dNQYuoGvZ8BI0T0vgwdL3vUSXNd0sXovZtTMw6RV+3FDZ35uF0K7B6H9qhXLJrTF+1Fp021qhJoCsWyp5vfmjpIDu2uPPl7Alov4Uh0RpHXdE9hyM8tNXZRdSWAfOXKMsHBnVAiUuvP4xQoCQlRxswLx6KLsYjeOpbIDgiJUZogFwCBHuBrkQazoR/tz+IUKs1pIhNefQbXACHO52/6vAvvgoUNev4ec46Qmlwb2pUBWUhszfpI6l7IfcbmuZbgwywoCW67LrOziiga5ze60skrEJfPHu8H9agR2vSXVEL/YjvhlwYhbEoTYpSFU3IGI5LzIhTq2XWtRMKrPD4QjPwSrD65A7qfZVNZPo9u77oFMyudXRKVZkkXiQIW5dpTOD8JjWRUJ6gC8nB9MsIfiOS5Xw5AppU1oywDAhLXUH3lEikVN10pbYtr3ZQXjnuxg3JEVQqUdqsaIvDnTiRsIbJso7REE8LBHqLgDMGaHOyS794eTMEY/D78pXGfYi3DMb4sH06MJ8GCCXOdzV8htz9cyUnsg7hsdreaJGbHusq5PdVpI9byIqnohgt5cjaC3Cd6WhHkzwrlqBh7qvRRGkjsaIfFsW7e1uKbrJiptiWXrND9b362w9ZcxIIuIZcugva9vQ+qHUkivaPMCdt9+g8wBP/VFKJ1TFix0d+csyuRil96IepuLA1tugsLAvvSNUZQJJAQW+obxBvaZ06cRGiE3k75ZZLkMd3Upu9iNY410MS09C5FxVuyyBRIatybkLv54L1kFOq2P++V2EmpKn1Y4zv9XA/vIHwLsC+oPzVkz2rVfmUpWzqXsSgF72IixXgpb4LzWY3zFooB9KSHx1fHjHiERPjXxzziufjNzqbarEdiJi/yRsigUSUtDkUg4Jwi8F4UglvNiOI1e6EDUfDvC5wUieF4lVM5/BVVnVUDA/EoYss1dx7rJiiYoPydA9Y6sIp1r5oWgwiwHXuFr6WBTZoZTFY8qTaUt3dmfEpcSrbnheJjLHs8Ow8Om0hZo35cTirtyQnBvhjRChuHO9Aj8k9C+hVNj1JMwRhLYfG9MkRKv3m1DxkAun+iPZ6YnUcU+DzUquzRAmj0f5c42Br3IZWVQaWYbGB1Kw+jVlcDup5ZbZtjTYDQkpEV1N1msFHbFt3SWiFFf3s9Hu7w96n2Dae/BaLeC+1pOta1T/Yw+G2HrIwrbHcvWaX7iEsumK2CXUGGPmzTZS4nIRdKpSy9zadFWMCRyMWBPTctUqVzW/uV16rRMc+nlmQJ2zYLA7m0uhRoiysrIkHUkf/awOfx9cY1cJQVEdFyiWlffjIQ2Xyc30I1U0igqbvWcq9+0jQsWEuOPa9QKEbU14E3R7rKSANtq9Kp2CWBb37HLq/2QkCKA1etdDNgHjxzlsRUAdhFDhF0OsK1G4kr+oV6/hzQCHzQ7PP3e3+NSJvnwrs+m14iKw4cf6BtL7HKAbZ3/rJxcRCdYOeW6TaJNu05qmWVXJbCXVkHK0kB6CFKosBOWhSJhCVU2PdaMbddZGIh6SyMw45NMOObqBsnwBYRv7rPo9V5P9HinK5V0WYRI78jZIYS2XUN7bjDKE9rlZkYoaL9Cpf2KKhxlx3O5dBnsVxWNslNpO/AwpzI6+31c5z8y7Fi2XdXTvic7FLfx/S0EtzFe95IUM8ZVxnVpTs4rjbAF+rfI+IzQHPwoNnwhw3sBr2/JILwrENhcT6A9ojyMCVTXY/yRvMxdnvW6/nEE7Ov4d0d3W4ZRJxMV+29Am0wq4cgclGpDdR2fh1V7v0A5gttoRzjHL8a/eq6G0WYFmmXpdMWnBxDWPTfCr4+ERURpW7FsE9hvuWPZRr9dSP3A6plb2LyAvWv3B6ge6a7PIFN7jWjs+fgTc43CphR2FBWn2kYa/wjsMUWrwp69CY/6Gh7ikfWSsHxF4R5/JbGiFbYb2M3bdVWZHPqzWqhRSKQzxsUsvkSAOI9ffvmFCreGa13rezdprodPs6x9p66I9si6kZu3fNUg/GQWECoIqqKB7f3nZwEw0FHTtZ6ko1UMsKv5Bc0pDW4uUAqwdUNqUbZk2TL+Gbk7tggkOnfR9Rksu1xgW4Br0a6L1+8Rzz+uuOSGallxVrLf4+K2jtdnzWj5Tu5zUDHAyjbR5/+yFfaF83CE1UFiozbqT1j9/gmNMTnV3fgldlUCe7EAOwj1CepkQrv+EodS3Il8rxV3GCrkPGKuDcz5NBf2uRVQfb5O/wuaHYTgWQFwznXCMTsUAZz6E9gBKk9bK22BtqW0pQaJFI56TmLaUk87PwxPE9pP5DrxUJ4Dj00Pw0MqPCKhkVDckysj13CaEYbbMqsTzmbcmfbq9vGE78u4e1od3JBOIL/5b0K5IkFeDV22uO8jYxAV9xQBtgO2qU7YJoYQ2CF4Jtvd6LhwP0HaLRlGpzeprAfBiJ6hOtL0nb5dLW+WTjVcfwFsrRdxupCAJqxbLELX/N14Y+XnuuZIc1224MiPp2C0Wqm7rr9KYEsvSAG2xLMlN/utbbAN3Mk/Fnr/95G6pyTAtkAQHIHkxu3URSgXiMBA4DBixGicLKK+8M5du1E9mpDnurJNrFy4GYUf9yW9qgYfiy2wy4UcVjtGdYP/LfbDDz8grJbV6FMY2PMXLFI95qzvodQtlWZ8QkO8u1WXRCxo9QkU3SFC3xjBF1GjP//8P9SIjlXratf7j6qboDpXJDXSN77nclGv357UA0AUZadOfeuVXibAnpLq7ixi2aAhI1SvUmvfEhtPTCkcE5Y85BjVSKrXk/1KT8JTpwp3ff3iiy9U6MaCu7g8GQwd6d01/vJDItpmz1tAKLrLoKbwcyRtNKpuIjZt0SlfBe1yfo+CdvLb7zBx0lQEOt1/bNZ3GjBslLmWtvd37lINkdY6MXzymznLu0HYsrkLF8EufQDUPs1ri6/liUd6wnra1QjspGXV0GhxEBouDUbDZcEEtwN1l1ZAcPZ/ETb/ZcQtkc4zL2LL4XX46cyPiJ9TGzWWBLqySHS+djDsnIbMD0bo3FCEzileaZfN1yPZvEJYP0/F/UJuKJ6RmtqEtIRIpGDUowT0w1TUMiK7DIIgo7LfLXnaWUG4MT0Yj0yPw5idWTCmViTc3aPQdNw8hgCvBL9phPPwF9Fg1VsImdmBoCagVVjEw6WA1JDSGL09S2279tD7hKk7s+xfrQjs5Dkwaubj259/weI9hHL8fPi1WKI60NjoRutleLG/jmNLnRGj4xoYbVcgOo3KueNqlB6xEw9SoRt9NxYdyx5EYHN+6p4f1D6KMhewLbW3eNlyqjKJN+rHfesiiSMgwqpHoVJQKOomNVSP2UotN2hGpWF1Fac3as35DVWesawTm9IYlahopIu4ez3uk1NRqZbFEfRJKU1VbzS174s5PzehfmMkNLaOsTCwxRx8OtAA0p8pU2kwrBkTD//QCARRbUoWgipCRDjEN3DfhOJyE6mMBt4snp+vhkRr1goNmrf3Wl/tn99R/sB0D1Brvt6XnNMmLdvqY/fYn95nE3WsVsOkuJz3mnWTERuXxG00vBzhNVA3oZH5B2muR49r0hjVAsNRT+qucLvgYCfqJvJ7ea3H89S4rapWKPVMkjkvifOq2iNQvXYU4ng+tWLU69cmTAtWGPytwBaTMgA6vc7j9+D5qhWTQFFQQxVsEpBf7u9hucyPiKqnar2EUxzEuOqC6O3F5fzKcHbqGuI2SQ3p/BzPPyp5ncAngKTkRlxHg7ICr+Gg8FqIikvm+XULGpnKn2f3Xt6hI7GrUmET2A0J7PrLQtCAHrekLMZv0R1M1h5YiFrzyiNpsROh819AcP4LqLWkGqIXhCJqUbBqlJTwSA2qaOkZGTZXoC2V/4pW2uVUbW0HXuZ8qav9vBSOypPRa/To7BIeUfW0Ce2HcsJwP6cyco0UjLo7x6mgfQf9H9JxJq0qrp1sR/hS3W/k7GkdkjRGPUuQB1NBv0x4VyWc/VFqchgBLZD2APZEAlv87RdhDKtGwL+Cf06yYuHCxgswQlJh1OYfQ0AajLr58Gu2mCqaCrv1YiptArud5GKvgNF0gfl6OQYv+YTQXgWj83JEZ+pa2kbzZQrYnrFslZc9cBuM194rGbA9rWfv11RaXIIHYK2LRS5AuaAFHuL6QndDRq/vuVyDyr1M70NSoBbxz8GyOAE8L0pZ39r2Yq4/1zq2ooH9HdVsVYJLClPJsVvrCsTkGGSe5z7d+3O753IvVzdY4fXlXHhC0tv1oLDKC+xPvrcnrC2XY3Sdb/lM1/cosB4Vvf5tuB+u5z7nBdaT72/+jrI/va7+HE9YS82VsOp11Hm0wjBivwfY3317ApX5hx8vx+o6Jn2+9O+hj8k6J5f1e5iuj8uqJVK0e16/6hyo7S6+jjxpus+pXl8+Iyq+EZ8S9CC/Be2KAbvnnwfs+kuroinVdaMlAWhMj11UAfmf6uJW0z4cjdiFFVF/SRDilvF35HoxiyVPOxjR8wltquraC0NRnWpb8rVVr0jOC6LSds7mH948b6Ut2SNSf6ScFIzKt6P0rGA97BgVtowXqUavoeKWUdmfzKHKnh6shhtTY0RKfjaVdqlJUm61LG7IDMKtXGaMeV4NL2aZZIg8PiMZn536Gv/NrKsaJY3UUEKc64qbwL5WFPbYKmi5diiV9kswxnP+gOfw/jF3L28jLhWb953ErG1HCO482JoSyi0J7BaLYGullbbRnsq6/Qr4dVqpQiYSEPz4yx+5Dt+3WoXm+XuotteqvGx3LFvnZdsG7oDxquRhlzCGLXbmtC75mZEzHYFB4eqRWtLirAtWLpjf5npbufCCnLUx4G13i7JYgnljFN6uZC7j+XXv6Qa2FTs9deoUYhNTIEWVRLnpi968oQvso0gAN7EA99e5HIMCtbg6fnEpP9pU5YWrDBQZwd5zPdNlPYGPFPqXEIvAqbjvL138ZV/yNBRBFW49dXnG2gXYUh3QWj+8ZsmArYou0X795Req7OaqVkjB30Nq03gdj+fvYPnf4PeQcyRhkypBTvR73V3WtmCbRNWQCFW4SraRa1uu8aLsksDu8ZoKH8ky2Z90QvqjrP5yfzRdZkfDpYFotIy+NBRxC8vAnvsUoheV4XId205aEorEJSGIX+hQ0I4mpKOprqMXBaLWQjvqSI9IKSA116GgHUqFHUyoF1TaZQnwsjPD6A68xNcvzQyn0pbMESeepuJ+RsaIpPp+gor6YSrsR5TSFmgTsJPcJVTvzaqBGzOCcEt6IBXyE2ixaQjuyooijCthyHYzREvdYQx/hsAmjCWG7QFsY4I/Kufp0gdTP5gLYwT/CMZyfpe7MWDDbOTsJEwD3L2+s7YeUGVXjRYLtbei2qbSVsq6HRV0B8kQWYF7uy3Hir3HuQ5BLjWyGy/EtRLDVr7RFcu28rI1sEvY07Eoy8qZgca8UMr72xEYVhPh1WOovOpepsfAzsfJQD56d+neW41cU9BCI2JU4Xpnkdtf3GUbB9Vg4xbF15rYsWsX+r35FkIiIhHgqI6wiLqoXivO/Dx+ds1IxLtCLBoOcoPIIAQycMJvOa4r4jVieAyJXgM5yEASUly/dYduWLBwCVq17YCKVR1qfq2oBK4r6yfydSKCnTVUg9qGzVswbvwERCc2QpUQp9q35/eXkrIVqgahdduOyJ813zxrhe3NQUMQwH3KNnJsZSr6Y98+7wJJJTFp4H5z4GAEEz6B3J8jLBoRteqp43HK71ErUj8Zmb/FX/17OCOiERJah2KjBlq07YzM7Ok4XQDQBe3pF15yXdMylWu8KLtUB6EmrdoixBmpjiOc5/y5lyoTPlqQXGlrRGA3J5CbLgtGM3qTZUGEdgCnIcpFXTegW1kk8ZwXuzQIsYR3FAEv3dmjCehaBLZU/Ku5IBhh0jOS6lpi2oWUtsrTDnEr7Ty7qqktSvuF/FA93JjqWOPA45xKx5oHcxx4MJswnfQsTki1PFqf9yag1FQp11oP9db1JbSfw/VpwSiVFkbwlseJX37C/lNfwhhZ2hvYMlUNkPShz2D1wV0YuiOXwK6Eh6fFkvHnUXfmQKrnOEJ3CLLfc1/rRmiaConYlAuwl8DWdpmpsiWGLdCmspY4d5cNCJqgOyEazZbDJr0f+26CX4FYtvHqFqS+f5khETFLoRa0z3lzHjp8+LJ8/4ED+EUNblm87T94kOseKrRtSf3AoQM4crTwaDEFVY9l3373HQ6ozzyMg1SI0oiZ3FjXsLYAUSs6Ae9te0/tt+Dn/Rl+kC4FiDa/8w7Wq2HVNmHtunXFFtf6guvKOrKu8g0bcerHoseH8/z+Bw4eUt/f04QHRV0D3xz/mr+V+3fat28fVfPFf9uS2M9U3nKdWN/71Kkf0LC5DvF4/h7btm/7038PKX72zTfFNxYXZ5/t/ZzbHzH3c0hd40WZvUYd1x9TUcA+evSY6nxkHc/ez3VDfXHX9u+xhiawmyhYB6PpihA0Xh6EhgRzY7pAuv6SQJfSlgyShKU6X1ugLUo7irCWqUC7JhV4GMEdRvUtDZHFKe1yorRl2LH8MJSeFUqlHaaU9rMqP1vCI048zunj08PxYK7uDXkfFfd1E8uix3tjcO208oTsU+a3AHI/JTDTKuA6GStymp2gfgky+roxlbCeynkuhW25CfERXGdMZXoVvLHBnfUTkNqfiph/BLEDMGHlh9h+4BiMyDwCeyFszbRLLRHV+EiFbbTXbhNod1qJ66XXY33pJXkBt0qmyKu6F6TR5x1dGMqq5tf7HaR+UMKOM/+/W0hYlLphrBtHGi1/PFX8yfPZH2tOPgVZsJbfI6xmDI5/XXwFvavVAkPcRcXEgxy6Md4KI/2Z1mR5FTQnlFsQ0uISzxa13ZQquslifwVtcYG2l9ImtEVpxxPadblMQVti2ouCqLR1yp+TCjvMVNp2GTdSxowUaNMrS9YIpxVmBhHaDqW0pWONDDf2HJX1c1TaMhr7kzlOPCaZI5w+KCOxZ9txa3pl3MP3xlidbmi1uRjDniaUq+IGGZFmYkVcOyWc8OZ64gLtImLZLoCPD8Y1o51qP2ILDu6kgo5Hr/mrEDV0NYxyU+DXeD5sjRfAaEpYq1j2Yncsuy3/MCQsIrHszvQua2Hrvk6PA0l4l+rxLl4YRUB33IjrJJ5tlV7ttR6pu4of7d8HbNP27NmjxhVUsV8TEJUC9A9W3NOGz/44++ijj1CzwO8hWSRi/5d+j5WrVyPaLJ6mvqcA26kV9l/xPZuuqIYWhG9zBWytspXSXk7VTSBfTGkLtJOptOtJBxtXTDuYStuJ6nwtsWyttEPVCDYBptIWYFeb5VTQLk+lLaPWlFVK26FCI9ITUsW0qbB1zRFCOycM92YH4/bMaqoXpORn35oZiIoLdXprxoFVBPh/0fMd3Sekz/Z0GBMqFAa2pbStjBFpfOTUNoFwH18JL07X+2u7chyB6s7T7jeHAI+ZCYPQNprQqbS9YtmW0u5ohkYIbAVtGZWmJ73zeoxf/ynm7/kGRjcqbqWwJYYtwP4TFbY8pnlmFWg7z/lFXXx/3Y13/ry3elFphw11S7zEsaURs2Xr9uZSn/2Rpi8X78f7OvJ7NHD/HtKTsMElOj79/c37epcxUKWjlGe7Sb36jdH7tf7mGn++NVlWDW1W+KP5skDlAm1R2s0JbXGBdkmUtiumbSrtOgsCUIPq2q209Qg2WmkHUWk71KjslefojjVl+LrMrBA1sK/0hHw+145nZthd+dn35/ijxqIWeHPHFNgml8H9WXb8OysEd2RIr8VnCOeyuHZaIIIX6AqKX/5IME54UcNaBj2Q0IgnsAsobZsAfGIYjJHlCVIq9bGEfe8qal+nzT9So+YsGEl0yc+W0EjzRe68bDOWrRofLZXdlX8i3dfTBdoblQLvv/gDvqbClk40/amyu23BlD1fq/0XZX+Ywh45eiLiEhujXZfu+J/Zs09s8NDRqBOVgDcHDMbpP+GRT46hS7c+yM2fiQ8+/NgrxPHVF18gZ/oMhIZHecFB1FyN6CQsXOIeg85nV8YS6zdD+449kJ2bx9/jQ6/f4/jXXxf9e3BaOzYFs+YU3xj6d7XMnBw1wO6nn7iHEDt/7gxWr16nYC1tJrrdRF93kke+Zp2uT/FXmAC7NYHdYkUwWq4MUg2PzQltNS2h0vaKaS9yoi5VtVT6q7HQUazS9p8bRlg7UGWuHeXnOFGGXpYQt3pCviBFovIJbZWfHYZr0/6Ln8xyqR02vYU7MwOojp8jZJ9TtUbukOJQWQTy5MpwLm6PR2fEw2+aQJpQniagFmibwPaEtgVsyckeXRltVg03u6/bYQz3R4+V7tpHFfovR4Wey9F0ItV25AwYzRaYjY+LdSy7LV1qiYjCVsCmSyyb0L5GRqWRno/0a3pRYb/2joZ2dwH2ZaT1XQmTsfukNGuipDKlNFVDQ4l17NFLdX2WhiRJi6oRpfNXCyvyK2eS6lc3qTFiEuqjOm8Gyf8ODqutXHoV6t6IlsKRm0antoXXdlft8tmVM/k9pBt/TIL8/nEev0ct1Y2+uN9DasFcjZaRmYuadeNVyQcpeBUQWgP2iEhzrFENaut7Snpfreg4c8u/xlosp8Je5o/WBHPrFSFouTRQuUtpKy+50pYSrVGLguicqnQ/T6UdAuccqux5wQghrAOorqvNpNKeaQ3sa0dZqmnpCemdn23HfVTY7dfoanoB8xpRVT+J/T9o0N2Z6Y/bqbSldrYMeOCXGojrpobgunQ7StGNVCpnKzQiKttTaZvANqRzzVs6Jr7t+D4YQ2WoMq7X7WVEzk3Fgg/3wKgxEvN26hS8RmMI3foLdFjEM5YtaX4CblHZHend1iq3idImrG2itPsQ3DL2o6T4ddmI1N1/MrClzoK+4ehNzC7Z351ElQCHyiO1bsaQ8Dr44mjJOl38VpPONNKpRt0U/FxRMZ7uOk5zmdw0VYIjcPKklEz960I2/1fN8/ewzvnFf49mapBlq4Tt1WaZZoVK97Vn5sAX+p5a2PyosnqufPZHSa25KOzl/mhJYLeit1wWxPdU2HSltE1ol0hpc369RQ5zMAQnIqmwIxcEU2k7UYMK2ylKe54o7RAC20mV7YA/p6K0JTRSbrYT5VRPyBCUduVnh+Fpqu5nZNix7Coqte9ewvvxGe6R5red3Mv5L+Haaf5Uxq/gH5lO3JTuxPUE+DV0W1oEYU0oC7BFabuAzXmesexRFTFqh64pYwx6XnWoGb19Jh4c0ZkQFp+Iaq/pethffPctVfYcE9gesWxJ7/OMZQuwu6/TDZA9OVW1RQTaki1Chd11M1I/+JNDIkmNmypVlNykORo27YjKQQ4131k9SnUQaCCdPBq1Q5VAPf+PtI5deqKuOYSZu4OGp+vc63opjVVtk6h6SfjZzO302ZW3Ev8eyY3hrF0XUXGJ+P77qzdTJ5MKOza54SW/Z3Tc3+O6a7GiMtoSxG1WBCsXlS3eiuBuuSTAI6ZtNkpeQmknEtZxS4IRT3WtRrDhNJKArjk/GBHzQxE+T4YbC1SFoiQ/O3AWVfZsO6rOdqDSHDsqUGlLI6Q7a4QqW7JGckPx1IxgPDU9DI9SfRujnwHO6Cf1D775iKB+Ek1WD8SXP5zANVMrqrEgb6C6vt4cC9KW5oRN8rElg0QN5EtFLa7S/kylLRAfWQHGgKdUt/Wb+d6y+4b3oBoeCqNeOhqO3YFe+dthJM6FISl+nrFsqehXRCxbKWwBdw9R2VJfZBNski3SdQ2m7ChenPwhwN63fz/KVeWPUjeBqsGBoSPHqPnvvLsVFaqFqlCIVJfLys1X8/+IfFLLpkxLR4NWbRHKP4uA0Oqql5gU05eejzKythS2kuHEXnv9TWzh8Wn76xTO/3Ur0e8RVhuv9u2HDZs2m1v9cSGzP9pyc2fjpUoBCOF3uvT3/OuvOwF2aw9gW0rbgrZLaauY9qWVdtISB+Kkt6SptCM5FWjXlF6Q83VZVgcBLvnZQQR4EBV2tbl2upPAdqgRayQ/u7isEamf/cgMQjsvFNekVUC/7SNxhyjpqS9jzgF9XoftyiOU/XFDZiihbY4FOS1cQVup6zQ7IW0Ce4oHsOkqlj3RgVLjud7A59X+xHI/ohru1pWQJrQjMjmlum5EZd10vq4lQmiLyra1JrjbEtxmPrbyris1sHsIsDfCTwF7M4G9hcvWEth/UVrfmjXri6xOt2z5Kpw7a443/yfb2TNnsH/fPhw6dAjHjn1hzr36rGCWizQDXI3pbv9Xfo+S2NXwPVutqIIOK/3RZmUI2tItcLfyUNqtVFikZNkjyXydzG0SF4UgbnGIGgShzqIgRM/Xo7LXosKuPp8qu2B+9iw7Ks8JNkMjUtkvVJdjLSZr5PFsBx6aHow70v1Vup9U9Lt+ajVsOLIDpefWx82pdtyS4cQ/qKivLyqWPVXe0wvFsuU1ndCWocaezWmqztOyvbsJ5iR8/+tPWLjzIAx7Fq5tMhNGEwmJLEIps+ejnxSFEmC3o8omtBW4RWVLSERi2VTYRu8N8JMRaURhd9yEKbuL72vwxwHbQxR5NipeOO9+fe5PBIwFswtFDJj7dwTd3s8/x9PPv4SqIeGoGhyOF16uiKXLvAdE3rh+AwYNGYnJU9P1jD+w8fZK29X2e/xWs54er5bv2YoKu93KAAVngbaX0uY8iWkXVtrFZI8sDkTyilAk8b2ERqRTTcwiqmxJ+Vvo0MONUWVLzRFnwawRiWNTaVeZG6qyRsrPcuKV2YR2gayR/0rWCNX3rVPL4JZp5QjtCPxnuh33TA/DvzODCN+yuI3K+vaMCDXgwW+KZauONFw2gT66KoyhFXVFv3bukab6z34fRvxsApvqutkC+DWjwm7pURRK0vw6LIOt8yoYXUxgdyewRV3LaDQy7qNMO2/8i4Dts99lhw4f5eNzPdVIKx5ZN0WNn2nZ3PmLEOCsreo7S+ZNnZgkc4nPfPbbre1yKuxlAWi/MpAeUEhpu2LahHWrpYGXUNrBaLA8FPU5TVbpfiFIoMquS4UtSjuSU0n3k+7rkjUS5soaCUHI7BD4zw1CAEFdhaCWWLbuuh7iqur3gmSMzJTY8n+x7esPMO/ASpSa8gweyCG0s0Px7xwZcd2OOzNCVZjkVvrNBPaNGZcZy5bQiIB7Qgj+NTVSl2AVxd23Jlbt+9w8c+dgOLNgSM9HgXZzcWl8tLJFdKOjXwdTaUsnGs9skV4EtzQ+dtyAKbu+MvdZ2HzA/pua1KBwj6jTUhV/kpFRLIuOiUdyk9auxjsZ+ssaAs1nPvut1m5FNXRYEYi29PYrg9BaYF1QadNFaUu6nyhtaXy0lHYzLpNu7A0JZxUakVi2TJc4CGxR2XY93Jik+VFhRxLcMvhBdaprlTVCxa0GP5hDlT0vGAFzw1BVYtlU2mVnh+uqfnN0Vb8XCOvHqKajl7g7VDVY8yr+lVVVjwMpdbPFMx1qxPV/ZjlwS2YYbuT7G6Zdbiyb897QaX5H//cDjIGPUm3Xoip2DxxiRGTDaDSP0Karno+6u7rKGFGNj8vg13GlBnZXgbWo7ALZIp0I7Pd9wL7qrCCwZdxMKexkWd16DRDfQGcayDohzjpFFr/ymc8uxzqsrIzOVNadCOuOK/wvqbRbrhB17c4eUXVH6FIwqvFSfzQguGXkmhSBNl9L1/X4xUF0GR8yCJGSp73QjloLJZbtmTXicGeNzLGjysxQVJwdjPIzg1FmhkP1gHx+ph3P5AfhrvTy5tEDyat74t6sang406ybnWXH3dky4noobqPCvn1a2G+PZQ97Afu/Pak+xzaO88YFweifSEg3gdF0LIwGc2BrOF93VxdXHWmk8XGRHuBAskYKZIv4dTWzRVRONlV2x/VI3VF8G4cP2H9Tu5TC3rZ9J8r5B6sa1zWj49G4ZVtzic989tutw8oqhDWBvToYnVaJ0g66uNLmPIF2M6pqleZHOFtV/poQ2gLpBkuD0WCFQ0E7ZbGuOSJKO5rvJT87itCuRcUt+dnhVNeFs0ZClcquRNWtao1IPDvfoWLZL86MwON51fBSbg0029wHN6c+h8dznXh4eriqm30foX2PxLRznLg9O+zSseyCNUYsYEtIZKId/5xcHQsPvkt1XQ3GyMroujYdfVZRTTfqhVLN82HUp7puOFcXhGpu9Xw0q/i1dVfvs7JFFLAlW6SXmS1ytQFbGmJK2vOxJOmAan+F0sJ0Y88fmU5YUlO1V4pIW5MY9sUUttixI4cwcfI0zMifq95fmR6jhRvCfk/j2OVuq86H+hre28k5upzfSz73cta/2Lm7nP3o4y+8L5l/uefC2s2V+V1LZh1XVkJXKusuhHBXglqgfVGlTWiLt1wpIRF3j0ip8idhksZmaESgrZQ236v8bLNIVLwobFHbCwNRh7CuQVh71s+2ao0EzJJaI/SiekDmh+Kp3GA8nFMNT+Y68FhuiKrm90COHfdRWUtFv7v5+i6JZWfqWPYtmXbcmO7AdWlhKCUlWCUsUlSNEZmKW+CWLuojyukY9gB3OdfGuQR1iwkEtqjrubqKX7OF8FNlVxfD1lLCIkt0JxrJGum0qshsEaP9Vaqwd76/G9k50zFs5FiMGjNBjR4+aco0zJozF9t27sRZc2Scktqxo8dUStX+ffvN3mR/L5O60pK/btnXXx+/qMIuyn4PWD1N0s9kBPd9Zt3lK2GHDh3Bgf0HXCMaXcpkZHn5rVQa3NHfngZ39MgxbN+2A2s3bMTa9RuxY/sOfFdMR5wvjh7G5ne28o9xM9asW48vvio+lngpO378G7y/azc2bt6C/fwOv8nO//mCQoDdZXkAuhDW4sUp7daEslLaZmikhQqNSMEoHdNWKptuZY2oMSIJbSs/W3eoIbCtnpDSACmNj/SwRVb9bJ01EkilLbHsyqoXpHcPSIllP5pbTQ1yIF3WZaCDx/LseqCD6Xq0danmJ7Hsu8xYtgwldmuWAzdmOHFdRjiuyZS4NaFcsMaIUtiWa2BLXrZtAl8LsIeXRd6na9V5+/70j1TWbxLYuZwS2o3oTebrbBEBtjQ+Shd1s+djkdkiEsO+WoB97qweNHPilFRU9Q9F9ag4VW9CHvnFZaDT2KSGiI6rr0IA5SrZsdRjTEjLzp792XwFpKamo57UMglyIqxWXdVpIbx2DEIjIlE1OAx93hyCY1+4U2g8lZQUn3/qufLwD60O/5AIlKvmQJ/X3jSXFjZZJuvIuv72CLz4SjUsWVq4eNSF8zr//KNPPkX/NwYg0FkLQc6aulMFXTqT1KybiBmz56Bugnsk74IKe8HCRUjPyEZWdq7y8eMnCrHNpZc2rQT16x/4BzZ4xGjYw3UnIquDh0yr8ftUj4zHyLHj9Mq080WApKAKlWNq3rItKvo7VKcRdf7Ncy9dsNt06KzW8/yTkSyYtp17qTTG0OqRan3V0YTbVg50okGztli4eKm5doHPNNPmVq9dh35vDkBEnTh1LmXbmlHxqB2TqFxeS0mE2lGxmDNvIZ9O5qiBpKsEhanaMrV4bdWum6DWlQ4ulYPseHuE9yjrnuZ5DF8fP47XBw3hvuxqCDSplSI1deR7SHpmdHwDZOfOUOuKai5KOUuBq2Yt2qASv68cp5w7GSQ5LjEF09LNoa7+QOu0qjK6UUl3XemvvEilvSIA7VbZtdJW4CbITXBLwagWLnAHFZ2fvTSwUNZIXapqycuusyDQVWtEskYc80IQTKUdNIf31twQrx6QMrTYfzJfwbidqQiaG4tHZgTiGUL6SelQQ1A/kmvHg9lOBez7qbL/ReV9V2YIbsuw45Z0CYuEEtoSFglVGSPesWxCW5S2QFuBWwNbw5vzBdqitt8ua545wrRhJzzQYwaMMEK78Wz4NddxbGmA9DMbH/UAB0vh10HnZOtskXXKVWGoduswdcdVktZXOyYedWKTkNykvWsEjqJc0tyqBkSYWxW2tavWqm7vdeNkJHIZf7BgF2g9komkxAk8Ro7WNXM9zTOtTraJS2mGMeP0YKRFmSyTdWRd2aZO3eRiFXG3Xn0I6ppqhPOCXbTl+0n1tpiExkhuqBsVZV5Bhd22c3dExaQgKrEBovlHVpl/cpdnGhZSqEvGHoxLaoqURm1cx+F2OVfN+OfRDJWr2XHk0AG1XXE2c+ZcVOIfV0xSE8TVtwav9d6n/MYyZJllp3/5GbVjE1CDkJXRzAuub7lU8NOjyDcwt/S2lCbNVXmBuPrS9V2fS9nOeu05L7FRa0Tyzz+S+0rkefb8HGsbmTZo0gaxCU1QLdiBEyeKH3Xm7WGjUIXnMT5ZroGizmNrJPH4I+s1wktlq6ptPGH/wQd7EGB3ok69BkWeNykvKwP+VvZ3YskS73z8K2mdVlUioAXY2juvDC6ktNsR2m0JbE+lbXWsEaUtwC7UE9IMjUg4pAGhnVIgayRmkR2R0nXdVWsklCrbDgfVdTBhHjzPiYB5Dq8ekC/mU8mv7mIeOXDTpKfxzIwwPJnvxBO5YQS4gyqbUM8jtCUskh2Cu3McBLYT/8wMx01U1jfwtQJ2SWPZAmwpAmWp7DEBMAaWg/FGfarqruo4/kfxaQRnwdZIl12VbBG/llTYUsVPlV0lsAtki6j0Pknta78OU/7OwLYU1qChIxDDC1LfVDrzQQri1E1qgKiE+ogmmOS1VP+TAUlbtemgtrPszBk9TNXYCVMQElGL27thJ/uSqdQxcZeztG7KVqqS2rgJU9X2lnk3+rVQI4XLALTFmedo4rLfgor4/Hn9BCHqWf4orGPSx6CPTYCkj1t/prWvovbnVdSK24SE1TKXlNyaNGuNqLgU13cs2q3jlM9pjYrVgtXjvlhBVf3W4GFKlbvPvd5e9i/zxBvxM0W1WyYQrBLk0L9JgXPiWWLVmi+v5fevyc8paN17vqaumYLbyL5lXzJ1n3fvfcqxWetJHRz9Haz19DVjp+oXO28+JVnWo3dfqvJEcxu9vrU/fTx6cGnZXz0C/Y0Bg80ttU2aOk092Xj/Dnp9t3DR82Qd+VPq0+91c+sra51XVkZ3Kuiuq/zRjV5QaXckxDsu91fQlpi2qGwNbW+lrQdA0PnZLeiSNdKEyroBoS2xbCs/O5HArkeIq6p+VNtR0gNyoe4BGSHxbKmbrar5mXWzVSw7FJWosF+ZGYQqs91VHP+R+ryuMSIj01BNe8ay71d52aG4N8uOO7J0xsjNmXbcnObEjYT0NYS0TVS2xLIvBWxxAfZ4iaGnoNQo6UyTQHXcxjwSIGEM4Zsyl0qbwG42/yLZIpy6Gh/XEuprkPq3BrY5mGilgGBenG3VhSkXZQQvyjadeqn6yFnZM5BNn8wLu3XHHqpOyTiCuaC9s2kLgsNqqsJS1gUuN408FjtrRKF+0zaqxGXN6AQFh/qum6CVGl3mJ4/iO78X2EXFnBs3b6MUpLWOeDxvaAmJSPgnhUCsykfzeLWOdaNqL7i/gsCWPOzLsc5de6JuovUHqUEgoadq9up8UqA6pstrGdncExrxVKa1YuqZe3Hbzt27ERRWxzxfel1rnxIGEUiLBzpqUCk2NLcCf48a3Kf3n2tUvRT+Hg71e9WmGpeBk5MaNnOtI9Oo+MYYM977yah7j74ewNZPOhIWiaKSbtSiPUHcXNXw8PxjEJfPrBkdh/A6sWjSqoP6HYO4nlw77vVaqBDHhrXetaqzcvPUdu7vzT8aHquzZjQiKASSGrbgkyO/Q3gdnkv+1nY9ao5lElsPCq+lFLX1OTLV5YfjlJiISWhgHov7HEVExiIzR1eSu5LWeWUlFRLp4gK1p9IORge+7kBg65h2oIppSyeagkrbyhqx8rMbcXljAtuKZWtgm7FsTl2x7AI9IMOpqkOpsouMZc9y4tm8yohb3BzPUG3/N9+u6ozokWmsWHY4HpJR1qmw7yW47yW078x24vaMMNxCiN8yLUyFRa7ltBTVtupAI8C2ej4KpAXYBXs+Sq/Hwc/j+7O6Tcbo/wKMPm3RKHueej905scwEmforuoXyxbpsgpGNzO9T0ajabP27w1ssc/37aMyq+e66OtSUc+ee/Fi9acKDBorJqOh633oC1tuEKn29kWB2g3btm6FgxCIb8xHV7UuQUTlM8gjVnmlFfbGzZvgrM0/DS6T5eJR9ZLRqVsPcw23dZMa3vGedaEvrbAvB9i79+xRatE63zJ11IzC0JGjzTXc1r1XXxU2sI5D1pXfavuuXWq59YQktc/lKUGvR0XauB3CIuqoBuOCkXVpfBQbOmK0apvw/OP0D43AgsXesf/Tv/6MRk0J/xRvaFcJtIYM03VVunkAW45TCkwVtAsUCDXqJPD4PM5tbNHhq1hC03MQYPnzmTA5zVyqQ0oSW/cEezT/eBs3b43vTuqnEMt+PXMGnbr0xPTpuuDZBbPQk2xv/Q7isbwOnRQV6VnZeP+DPfjok08wY9Yc1KhdFzEStjLXk+Py5x/qDz/K4CAFz/Bvt66rqqDHqmrovjrQ5d343qW0qbLFO6wOQTvVuUa7jmcHuoBdMGvE6lDjFcumsla1Rjhf8rJlwIOCPSCrXzSWHYIKs0PwQl4QXiKcX5gVosaAfHamrjHyJF8/QZX9IGEtsez/TNcZI/fkBOGuLKeKY/8zMwz/yAjFDWlhhLYDpQhum+Rhmz0fbanhhLcJbXFTaauej6Mr482tuizES9ObwhiURBXdBe2y1+PlHoRxSr7Ox27q0fhoZovY2kqPx+Ua2gJvM1tEKeydf3NgHzhwwHyU1hejhAwG8fG6KPNspPJ8vXDBYkTGUKWaN6I81oqyKmjW4+yHH32McCpv/ZmEHuHtb3eXT7zSCrtV2058HNaAleXxKY3Rscur5lJ3aEFGIxGTfbmHLLuyCrtTt15eoQMppm+pNWkIk/NquVgjngNRjdaxCLhGj3Ofi/NnTyPAXkMpWnU8XEdGTpnL30Sbu1CVZ02NatXcsJKpKPGPP9NdfaU9zvMYxCL4lGSBViAZQWW75/3d5lJvhS37c48+7g20nJw8BWPr+9SNr48ZM2eZS922k39KMlK7tV4cf7M33nKHMyRrScoCWNeInKPmLd3DynmGjC5ccJ+Dc2d1+G78hMnqycpSz7L/pnwKK8669+iDaB6r9f3kz+7VPld2OLEuBLaEQrqvCtBOYHddWc2ttKmsJTzSfpUAO0hDm67j2QQ2wSzunTUShCYqlh1YbK2RhKUOxC4t3AOyuFh2VTOWXXFOqOqy/hLhLB1pVI0R6VAjsewZhDZB/vB0B+7P1j0f/01VfXdOMO7ODsOtWeG4LSsCN2U6cL2k9xHYfi5gi8K2m8AWWJvQtoCtqvhxnWEVMGV7HuFdiYo7lgBuTgU9irDOg19DAlqyRZoVzhaxikEZki0i0BZgWyGRvzuw5YaSVnTrhpcLUi5MZ80Y5Obl4n8/uzM/xDxvYstaduiuIGjdXJF1k7GpCNXkaXUJKksd6Ru8DoGpbyzvPOjfprA3brTKZmolZT32yj4DPOK4Rdns2bMRy8d+z/1dKYVdSYFSn2tpfKsTXTjE4WmbN29B7Vh3xorEeVu11VkeYmvWbVJZFdZy1VZQ/+LjLy5Zthy1uI31xBFXvwm6v9rHXFq0ZU3PVeEB63MEuqnTMs2lhRW2G9jetp7nUWqvWPuRAQakbnVRJiPh6GtAt6l06e4+Rrl29FNFC3XtBobWwFmzLaUkFhDifiJMbNQWUXUvXQ+maYs2/N31NrKtf7AeYf1KmSjsXqsroceaIPSkW9BWSnsFwc33XQh0aYDsRIh3WBWsvA1VdaH8bKW0NbhbrrArtd1UGiKprrXSdodGkgnoOEK8noplB6tYdm2PWLZjbqgrL9tf8rJn64EOKs0MQvlZdpTJt7trjMykylax7GA8nuPEI3kOPCKxbEnxI7DvyQnB3SqOHYrb08NVd3XJGLkhQ4BNWBfq+UgwFxnL5nxVEKoyjLEhCMnvgp/PnCage8BokQubysmWruqetUUkW4TwbkN13aFAtkhXAfZqpG7/G6f1WSqkGQEgylouRE8XaIU4I1EvvoFqGLQUaEELcHgoPMKoir93rLAoGzxktPmZ+gYXlb9/v849/r3A9lTEBz7fp9Sg68Yn8Np16aWWFWfv796N6rXjXNtcKYX90Scfe+y3BeomNsGU1GlqWcFGRMukmUHqVlvHksTH8fjERuZSYFpGtrdiTRDFqmN5xdm4iZNVmqa1jfwhLC4iDdLTPtu3H9XruENnovRHjh5vLr2Ywva2DZu2ENjuPxgF7KyigS37sD5P9i2fYVnVIAeX6T9hibHXb6Z7mxZ3Hj1NGludNXVYSv60asbEY9OWd9Syora35u07cBBhdaL0dvTqteKwywxPXQnrRmD3XF25SGB3JbA7K2ALqKXruqT3aWALnD17Qqoa2kppm6ERAlsaIhsvpdomsBuZwJa8bHcPSEK7mFi2U9UY8YhlC7ClIw0BXp5Tq8bIiwT2c1TZVixb6mXLAAcPE9j35zqosHW2yD3TzZ6PBPbNAuyMMNxApV3qt2aLjKqCFquGq3M4ZM0WGE3HwKYaHSUf24S11BYRhS3QbivALlBbRFL7RGH/nYHtaTWjZcSXhiqVygKfBpKGRL3kRlSqYXj19QHqkdnTpJHIurFUyh5vrktZWkaWCzSyrQyKKh1GxK5EDHujqYhXr1vvBQgBzfhJ3lkpBe3o0WP8/BjXd7pSCnutHEu0jCeo9xtdLwnz5y8ylxY2K1dY0hDdcGqu/nQsmzA51Ru+/K6b333XXFq0deXx10uxjr+l+q5ffVX80Eg8Epz85gQcNa0wlj6Po8a6Gx5LDmxR2L8N2KLixeSs2MM0ONX1kdIMbw8bqZaVxDZs4FNJFI+B28t5lfNbUpMRnKzfIjIuGbNmX7nBibusroI+9B5r/AlsCY24Y9nag9DNjGVb+dmitNt7ZI14xrJbEcqeVf2sWiMK2BIWoatYNuF+sVi2Do0EI1TFskMQSFWtRqbhtBLhXX6mHS8RzK8Q1i/MDMELuU7VCPkk1fWjkjFCVf1AlgP35+hsEQmN3Mn3d2dJHDtUxbNvIKBd2SIC66J6PnopbLoo7ImhKDU+HMbAV9Q5PPbTNzDqD1Dd1G0NCG0pCCWDGkhHGiu9z8zHLpgtYrRYjSlXQ8cZSzmPnjAZVYP5D1svRd0gckPom8INJ8lcqOgfhO++0yMzXKD6sHvcWOqRvGlLtexilmWOtyfbyLZXEtieinjdho2FgD2W3/Ni5v35V05hSzhA9mUdi4SF5s4rHthW+EkyRryA7fGHOIrfXb6TtU/5rp7HWpR16d7L1Yiozj2B/cWXF+tZqBWmdCSxzslfCeyPP/kUETUttd9C5Z2Pn1g4c6k4W7thA2p5ALtysLv95FIW7coa4R9uYn2kTbtyHWoE2K/SuxPWAu1uXsAO0MCmwrbys5XSFlCbDZCSNSIZI1Ys21XVj5CWkEhjCYkoYNvRaElwyWPZVNXO+cGuWHagWWOkyqwQVCSwK8xx4OVZYS5gP09gq1HW88PxWK6d7sADVNVWtsh9fH0XVfedVNfSVf3WzHDcSJWts0UE0oSx6vkor01IC7CLqpMtCls60YzzR7XsLjx3VNDtCexm0wlsglqALV3UCW1bgXzsgtkiRsurBNgFbcGipejQpTv8g6ujBh/hJYsjpZEuJ6pdMgrc8buqQeHqwlc3a1PeANUuPV6k3KR/FLA9Ffb77+9Gjeh4V7xW/nB69x+glhVnBYF9pRT2Zj5214rUaY2ybVRCoxL1oJOMhOKBPeGygT1g0DCeL4Erj5/b1IxNwJoCKXNFmSdA/wpge4ZEglW+v14Wn9wY3Xrr3OiShER27NiBmubvIPuQP6xTJSyZIPeE9VvI09KaNbp79JWwHmsqoe8qQntNAHrTRWV7Zo1IpkjB/Gzxglkjrli2qbStWHbr5XZVFKq4WHYi1bU7L9uOKKvGCN+HLySwPWLZgQS3GmWd0C4/S8Z+dKBMXihK54fixXwH/iuNjwS3ZIs8SWg/TGX9YLZDZYsIuP813er5GIp/UmHfnOkws0UI7Uw7bFJqVaA9VepmF58tYqPK1o2QITBGE9yvtYSt5wCq6Ryq7NmwUVmr0Ehzc2CDVovg18pM71Mpfsths1R2yxVI3XHM/DUK298O2KLoCoY7dr3/PobzxrRH1HBdqCpLoHYsdmx/T60jXZE1ELViq147HvvMeHRxdjFgHzx0CGE13cCOIVzGjS9eFY8dN0mtI+vK/jwV8bfffo9QyQNX+9IeEnbxR+A/SmF/c/IEnNXd2THSg65RE3dN3+LsSgNbwih1qUqt8yUZD8NGFU4rLGh/J2BXDCBkzHMi30MarcVKWqwpMMQK4/H6im+MKVMvrdAXLVqE6Fj3NeusHoNjF30yuTzrsbYKXlsjDY/+Cto9OO1OYFtK2w1qz6wRQtrMGpF6I57Alqp+rlj2cgKbylqArbqsW7Fss8aIAraM/8hpwRoj1QnsMALbqjEi9bID5ofAn+q6ymzd87HMzDDVXV3GfpTBDSRb5GkC+wkC+yn6w7lhrmwRGeDg7pwQ3MP3t2c6cWu6UwFbZ4uEwS+D4BUwq7DIxbNFNLD5fjzXm8D13k6B0asPVfUIGClU1QJsc1ADv2a60VENHSY1Rayhw6zaIn93YHuPTXjxC/3r49+ojgTWjSYpVbPm6MatAYOHmF299TLJZEggWLQVvd+LAfv7H35AqCtGKamGjdBv4FC1zFNBWSGDN98eiQQqZwUgbiOAXeuhGB0EdBKfCixARcUlYVKazuEs2HNO7I9S2GLB9ghTYfN706VBdOu2nWqZldZX0K40sD/6+CNEuNIq9T6Dw2rjh+91fr1U5yvqOP5OwG7VtqNKH7X2ExmbjPketU48rahrJqW+O3dd2mikU4/nCPEFlbrkkMvAvboTkXxmC15XhXPNf4/1WFkJ/VZXQe+1QehNWPdUKruw0haX/GzpTKO6rpux7HYmsAv2gLRi2XrAA49YttllvdFi6QWpa4xI46OuMRKImIVOQtuOmlTT1ec7VL1s5wIq7dmhCJ5nRwBBXXluMKrKqDRzqLBnSEEod7bIc3nS+BiCJ3KcKizyyHRdEErFsrOosDn/9iy6mS3yj2mENmEtXdWNaYSvq/Gx6GwRS2GrsIgJbaNbiDqX1cfmwkiWbBGqbMkUaToftgL52Hpgg6VewJ6y7W+usLv1ek3lt37zbfHDu4upzAKPbASpSbHKfBx8Z+t7quCOvrk0FOslNUaDZi3x1ddFN2bNmDGnWGCLBdrd3YUVFEVBmT0zve2CyqKwjku2kfimjMtomYRMJCNDH1sLNGzcgccbhbeHjjDX8LbvvvseTo9GxyulsMXeHjJG5fxa50m2D3TWQE6e7tRRlEkvxSsJbLEgfqa1jXxPgVZQaHVs2VJ8g6Vnmt1fAWwrhi2WP3uBEg3u89iS0K2Od7frP7+CtnH9OkLYLVBWrl6LGlHxrm2lsTyQ338rr+WC9umnexHK609lo/B3kM5Gkfzs3BmzzTWujPVY5Q3sHqKyPZS2F7BXVvOIZUtxKO9YtqsHJL0l4Vwwli2vpcaIqOxGi4OQQmDXX+L0rjFCdR1FiFv1ssMIbIc0Ps51IphK25+gFmBXJrg9q/i9QGA/n+/As6Ku80Lo4Xg8z4mHsgXYWmFbwL4tiyrbzBaRburXZYSaJVc9gc33RQHbVNgWsNXrPhXVudz/3QkYdcfDZqnsIvKxdXqfR/W+liv//sAeRZjVqZdM6EUiNi4Z4yelYvny5erGkkayaRlZiIqvrxoirZtMLtrKgd5x6pjEZHVTabDom0gucEfNaFX9r+urr/OG6628e5/X0LpDJ5fCkRumILBrRca5GncsMAaFVcfwcRNUl3npgDGGxyodbiyYWccmNTcKWmWvR2hdX0LSCgWGyY2boRuPSY6tR88+6NCttws+4ldSYePCOVSoGoyEJroUgD5mgiuhgcoXb9auC3r26us6V337van+/KxjuVLAnjVzrqq8aG0nLschdTmC+H1adeiO7jwX0vOza49X0fPV11SXeWvdvxLYVtSjWnA4Epu6SyHIbyFd1SXMlJ6Rg2xeI1K5sGGztrqLvUd2jVg8Pzu+gWzr/h3knETUjsZbbw/FgGEjEJ2QDKn4Zx2vrBvXqBXC+IcvVsSDyG+2XmuqoP+aaui71h99OX11dYCX0i6YNeIKkRDa3URdFxPLdveANGPZZmjEimXrGiMhOsVvSZCrxkg9KmvJFpGiULXMbBGn5GWrsR+tno+SMaKr+FWcFYoy+dL4KKOrW9kioaoTzWMzpPHRrsuuEtjSTV0aIO/KDMUdWWZX9YwI3JAWSpUdCjV0WEnS+6zqfQrYEsfmn0z2WHU+jbojYJMBDaQDTbH52Mtc+dhG8+UEdvFD/f1tgC03n1ysSY3bIDqxMSJjUlTnl1oxCaoTjUBCw1Nf2KK0Jb1P7Lwaif08p+dUOU+pz+GuzaBvAtlOOtbE1efFzkdRacRMNIfYstYpCOzpeXNUL0BrP7JucsPWqJfYVLXUS1GquCQ+nroaQ7kfTuXG7tC1t7kXt7333g5UDgozj0fvz/rsxAb87jy2evWbqWOUfbj/LK6cwrbiq1s2byVs5Fjc58By+ZOrx3Mk50lcXlsNpnr57wf2mTO6M1Tztp35pORZOEnvQ94nmL9XvBxHCn8zvvZc568AthUSscIan3zyGaoGOb06fcm5sqrrRfMakaJlAmpZpxav62EjxqhtLQuVcBnVtc6E0seeItdZUhNep025ra7cp49Xf0bVECe+NZ9Iiwod/VazgN1nbQD6rK5mxrK10hZgdyOElbo2gW3FsrsQyl0lhl1MLNsrL1v1iHTHsgXYEr/WQ4nZkbI4GElmLFt3pLGbVfykq7oAO1gVhQqV9D4qben5KAP1VlTAdqiR1V8msJ93ZYuYwJbaItPtXtki4jKowR1U1wrY6RG4nsC+LkMaGksAbMkWceVjE/LjwwntYBivJ1Ex94Ct/XgYKdJ5xopjSz62ALuIfOxOGthTtxc/1N/fAtjDR41VjU7JjawL0n1TerpctEmN2iqIx6e4O2542tmzZ5HQoJFSOdJ7TkGP+7UueLmZPOHjuW/pOGMB2wJb7ah6qJug/0z0ugWPT0PT2kdswxaoGuzAz//70S3DPOzjjz/mY3111I6tz+PU21gu+ynq+GSZZANYWSdiojw1sGX5ZSps0z7a84GCdlSMnPtmVIGt9bHIPgu45/HIo7tnHrYCdrIGtjrWEipsy0aNm4hK/kGIS2ym9m3txzoW9d6cerp8phewe3oCu9UlgS37l3Xlzz8zK89c6m0a2PrPXwGbn1HQNq3fpOpm1/O4zgpfJ3pZHK+PZ14sgy+OuW/KC+fOIpxPgXUT5E/aW5hY+5FtVZlbQjw4NALffVt8qdffYwLs101g9xVoq9CIqGztKpZNkHuqbNUDksukwp/EsjsT1DqWHeTKy7ayRVqr0EgQWi2Vin7moL1U2TpbxFTZXD9lsQOJ5lBidam0owjq2gtDUGe+jErjUI2PoaK051JhU2kHzjYH650dgrKzJDTixEszdbaI1BaRbJGnCO2nckNVV3WpLSKhEamV/a+cYFVb5NaMcJWTLQMbqGyRdAE2XeqKSGqfuMBaXMAtLtCWqdWBRgbrlWyREckw+vWDrfM42BrM1vnYapzHhapyX9H52ALsFZj8dwf2itVrVJF8uTmk/ocoJ6lYJ5Xt5CaRBj+pXhZeJwbB9hqYnj9TbXf+nC5Z6m26oWbjps3o/mpvBITWUIWOpBC+KmIvxemLcLmBpWLf/gO6MJFng48UQJKwhRRkch9bU5fLvLpU3FJsKDou0TWizfkigG3ZrDkL0IA3oBTOl9i7ZLxId+mijk2OO8BeC6vWrDG3Blq36YiISL1cjr1MpUBzScnsnMe5mzt3voK/hEOkaL80Ql7sXEmR/+qRcebWwMAhI1RFRLWc20njmdW2cCmzamz8/PMvGDlqDMJ4HoIcNVQIwDXwQIHPt1w+Uz7bslZtu6C6HDuX6XMSxLmFfwM5NjlGa9+OGtGYPEX39vS2C2ofsi9ZT/Ytn+Fp587pJ4Uff/xJPdXJftV1wmvWuj7k+pV5wc5a6unFUxl7qmNpo5Ha5BISkmvKvX1jdaxSvuGtgUPMta+ssras/fJn0W35c+i4/Hl0UtPSaL/0ObRf9oLy1sueR+slz6HVkhfpLxC+L6LFoufQjK+b05ssLo0mi15Ag0Wl0ZCesvhlJC8sjaSFL2tf8DIS5r+IpHkvI27BS6jH97HzXkTd+S8pr0OvtfBF1J5TFhHzyiBizisImfsSgmeXQ+CcMvDPfwWV88uiAv3l/JdRNq8cns97CS9ML49nppfFEzkv45Hs8ng0sxzuzyqD/3B6T9YruGtaOdyWUQ53TCuDf6SWxY2p5XBtahlcO7UMAfwSwVueoK1AtVyW03IwxvH9BPp4eU0fw/lj6aPlNX0kfZSHD+My8eHcx3Duc2AQjG6tqKLfghEzDUZkPoy6M2DEzaLPhpFAgCfTpfu6GriXqrvJIs5fhBFbih+h6G8BbMtOnjiO2fPmY+ykyejKR89uPV9Dh869MGTYWKRlZOLTve5GvMuxH099j8NHj6phnyQmXpwvX7mK654yt/K2X86cQd6MfIwcO1EBXGKZ3ai25PjGjJuC6bl5OHi4+NjTxezkN8exd/8BBZIN/KMpdGxUhKtWrVFZMpZt3b4Da9dvMNfZjOVLlxUl6C/bvvzyKzU0mPTOLHQcpq+jb1jvBvLHH+3hubWOZRP/gNfieDENvSW1fQcPqIGGpdOR52d7unymfLZl27e9p8qVWsuXLteF/gum2cmxyTFa661eux7793lfW9Y2sg9rPdm3fMbF7Ief/qcKSQ0dPhaduvZW18fgIWPUPFlWElu+fCUmTklHJz5Syz7eHj4GC+YvNJf+sbbti0XYeWwxtn+xTPmOL5bSl2HbsSXYLv6F+FK8x+k2cc7bdmwpth3llP4u58myd7mPreKcJ77l6GK8Q7emm75YjM1cvvnIUk6XYtPh5dh0ZBk20jcdWY61R5diPZet4rZr6CsPL9Z+hK+PLMaKQ8uxir7o8FIsPbwMCw+uxOJDK7HwwDIsos+jy+s5B5bz9XLM3r8Mc+l5fJ1Pz/t8GfI/X47s/UsxnfOzP+d031Jk7V2OHC5L27sM0/h62mdLOV2K1E+XIPUz+qfLTF+ONHrqJ/r9VE6nyvyPuc4nSzDtw1WY+v4WpG37AFO3HEDq+kPK0zbQOZ2y5TCmbqK/cxRTNx/BlK1HMeXdoxi74QgOHi+aQWJ/G2CXVC3IjVSSjgmW/RYV8kcol+LsSn6WZ0W4yzU5p5fLe/ktLnb8f9a5l20KQtmygsdY0uO92D4vto/fbao9phi73B/IZ1epFc+3v5XC9pnPfOYznxVvPmD7zGc+89lVYj5g+8xnPvPZVWHA/wNXMHMxVFmXKwAAAABJRU5ErkJggg==',
			// 	width: 130,
			// 	opacity: 1,
			// 	border: [false, false, false, false],
			// });

			// var oHeaderBody = [aHeaderColomns];
			// //extra add
			// doc.content.push({
			// 	table: {
			// 		headerRows: 1,
			// 		widths: [100, "*", 130],
			// 		body: oHeaderBody,
			// 		border: [false, false, false, true],
			// 	},
			// 	layout: {
			// 		defaultBorder: true,
			// 	}
			// });
			// //extra
			// var oSimpleForm = {
			// 	table: {
			// 		widths: [100, 200, 90, 200, 90, 200, 90, 100],
			// 		//	widths:[70,100,90,100,90,100,90,100],
			// 		heigths: 10,
			// 		body: [
			// 			[{
			// 				text: 'eTicket No      :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.Docno,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Well Name       	:',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.WellName,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Vendor ID            :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.Lifnr,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}],

			// 			[{
			// 				text: "Contract No",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "66000003651",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Rig Code              :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.RigCode,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Vendor Name     :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.Lifnr,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}],

			// 			[{
			// 				text: "PO No",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "65109809890",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Rig Short Name  :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: getData.RigShrtName,
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: 'Vendor Ref. No. :',
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}],

			// 			[{
			// 				text: "",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, false],
			// 				alignment: 'left'
			// 			}, {
			// 				text: "",
			// 				style: 'headerLabel',
			// 				alignment: 'left',
			// 				border: [false, false, false, false]
			// 			}]
			// 		]
			// 	}
			// };
			// // oSimpleForm.table.body.push(oMCRow);

			// doc.content.push(oSimpleForm);
			// var oBorderTable = {
			// 	table: {
			// 		margin: [0, 0, 0, 0],
			// 		widths: ["*"],

			// 		body: [
			// 			[{
			// 				text: "",
			// 				style: 'headerLabel',
			// 				border: [false, false, false, true]
			// 			}]

			// 		]
			// 	}
			// };
			// doc.content.push(oBorderTable);

			// //extra
			// // var firstTableData = this.getFirstTableData();
			// var secondTableData = this.getSecondTableData();
			// doc.content.push({
			// 	style: "header",
			// 	alignment: "center",
			// 	text: "Operational Report"
			// });
			// doc.content.push({
			// 	table: {
			// 		headerRows: 1,
			// 		// widths: [100, "*", 130],
			// 		widths: Array(secondTableData[0].length).fill('*'),
			// 		body: secondTableData,
			// 		border: [false, false, false, true],
			// 	},
			// 	layout: {
			// 		defaultBorder: true,
			// 	}
			// });
			// doc.content.push({

			// 	text: '',
			// 	pageBreak: 'after'

			// });

			// doc.footer = function (page, pages) {
			// 		return {
			// 			margin: [5, 0, 10, 0],
			// 			height: 30,
			// 			columns: [{
			// 				alignment: "left",
			// 				fontSize: 9,
			// 				text: "oVendorId"
			// 			}, {
			// 				alignment: "right",
			// 				text: [{
			// 						text: page.toString(),
			// 						italics: true
			// 					},
			// 					" of ", {
			// 						text: pages.toString(),
			// 						italics: true
			// 					}
			// 				]
			// 			}]
			// 		}
			// 	}
			//////////////////////////////////////////////////////////////////////
			pdfMake.createPdf(doc).download('Document.pdf');
		},

		onItemPress: function (oEvent) {
			debugger;

			var that = this;
			var oIndex = oEvent.getSource().sId.split('-')[8]
				// var getIndex = oIndex.split('/')[1];
				// var getData = that.getView().getModel('data').getData().VendAttNav;
			var getData = oEvent.getParameters('item').item.mProperties;
			// var mimetype = getData[oIndex].Mimetype;
			// var base64 = getData[oIndex].FileValue;
			var mimetype = getData.mediaType;
			var base64 = getData.url;
			var oBlob = that.b64toBlob(base64, mimetype);
			var oURL = URL.createObjectURL(oBlob);
			window.open(oURL);
		},
		b64toBlob: function (b64Data, contentType, sliceSize) {

			contentType = contentType || '';
			sliceSize = sliceSize || 512;
			var oContent = atob(b64Data);
			var binaryArrays = [];
			for (var a = 0; a < oContent.length; a += sliceSize) {
				var contentSlice = oContent.slice(a, a + sliceSize);
				var contentSliceLength = new Array(contentSlice.length);
				for (var i = 0; i < contentSlice.length; i++) {
					contentSliceLength[i] = contentSlice.charCodeAt(i);
				}
				var binaryArray = new Uint8Array(contentSliceLength);
				binaryArrays.push(binaryArray);
			}
			var blob = new Blob(binaryArrays, {
				type: contentType
			});
			return blob;
		},

		_onObjectMatched: function (evt) {;
			controller = this;
			controller.ConsPdf = "";
			navBackFlg = "X";
			this.changeMade = "";
			this.sSelectedReason = true;
			this.itemDetails = evt.getParameter('arguments');
			//nexus
			var itemDetails = new JSONModel(this.itemDetails);
			this.getView().setModel(itemDetails, "itemDetails");
			//
			this.DrssNo = evt.getParameter("arguments").DrssNo;
			this.Rqtype = evt.getParameter("arguments").Rqtype;
			this.Gid = evt.getParameter("arguments").Gid;
			this.Mjahr = evt.getParameter("arguments").Mjahr;
			this.Etkt = evt.getParameter("arguments").Etkt;
			// this.getView().getModel("oETicketModel").setData({}); // reset eticket model on navigating to service order.
			sap.ui.getCore().getModel("oETicketModel").setData({});
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Sos = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Tvd = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().Operations = false;
			this.getOwnerComponent().getModel("JoblogFormsModel").getData().NonCharge = false;
			this.getView().getModel("DisputeVisibilityModel").getData().DisputeVisibility = false;
			this.getView().getModel("DisputeVisibilityModel").refresh(true);
			this.getOwnerComponent().getModel("JoblogFormsModel").refresh(true);
			// this.getRequestData(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);
			//extra
			this._onObjectJL(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);
			this.VendorInvc(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);
			//extra
			this._MessageManager = Core.getMessageManager();
			// F4 Model 
			var f4Model = new JSONModel([]);
			this.getView().setModel(f4Model, "F4Models");

			this.MorningReport(this.itemDetails.DrssNo, this.itemDetails.Mjahr);

			//this.getETicketInfo();
			// if (eTicket === "X") {
			if ("X" === "X") {
				this.onPreviewETicketPress();
			}
			eTicket = "";
			this.joblogginAttachment = [];

			var RaiseDispute = "";

			controller.ForemanBase64 = "";
			controller.VendorBase64 = "";

			this.getModel("jobLog").setData([]);
			this.getModel("oSummaryReportModelDetail").setData([]);
			this.getModel("oTSModel").setData([]);
			this.getModel("oTVDModel").setData([]);
			this.getModel("oSensorOffsetModel").setData([]);
		},
		VendorInvc: function (docNo, year) {
			debugger;
			var oModel = this.getView().getModel("oETicketHdr");
			oModel.read("/VendInvcSet(Etkt='" + docNo + "',Mjahr='" + year + "')", {

				success: function (oData, oResponse) {

					var VendorInvc = {
						VendorInvc: oData.VendorInvc
					}

					var VendorInvcModel = new JSONModel();
					VendorInvcModel.setData(VendorInvc);
					this.getView().setModel(VendorInvcModel, 'VendorInvcModel');

				}.bind(this),
				error: function (oData, response) {

					var data = oData.results;
					console.log(data);
					MessageBox.success(oData.statusText);

				}
			});
		},
		_onObjectJL: function (docNo, year, Rqtype) {

			var that = this;
			// this.itemDetails = oEvent.getParameters('arguments').arguments;
			var oModel = this.getView().getModel("oReqHeaderSetModel");
			// var Docno = this.itemDetails.DrssNo;

			// var Mjahr = this.itemDetails.Mjahr;
			var flag = "V"
			var filter1 = new sap.ui.model.Filter('Docno', 'EQ', docNo);
			var filter2 = new sap.ui.model.Filter('Mjahr', 'EQ', year);
			var filter3 = new sap.ui.model.Filter('LogType', 'EQ', "OPE");
			// sap.ui.core.BusyIndicator.show();

			oModel.read("/JobOpelistSet", {
				filters: [filter1, filter2, filter3],

				success: function (oData, oResponse) {

					that.jobLoggingitem = oData.results;
					var OprsubtItem = [];
					var OpraprItem = [];
					var OprallItem = [];
					var Opractlog = [];
					var OprREJC = [];

					that.jobLoggingitem.forEach((element) => {
						if (element.Status === "SUBT") {
							// var servieitem = {};
							OprsubtItem.push(element);

						} else if (element.Status === "INIT") {
							Opractlog.push(element);

						} else if (element.Status === "APRV") {
							OpraprItem.push(element);

						}
					});

					var OPRsubtItemModel = new JSONModel();
					OPRsubtItemModel.setData(OprsubtItem);
					that.getView().setModel(OPRsubtItemModel, 'OPRsubtItemModel');

					var OPRactlogModel = new JSONModel();
					OPRactlogModel.setData(Opractlog);
					that.getView().setModel(OPRactlogModel, 'OPRactlogModel');

					var OPRaprItemModel = new JSONModel();
					OPRaprItemModel.setData(OpraprItem);
					that.getView().setModel(OPRaprItemModel, 'OPRaprItemModel');

					var Jboperation = new JSONModel();
					Jboperation.setData(that.jobLoggingitem)
					that.getView().setModel(Jboperation, "Jboperation");

					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oData, response) {
					var data = oData.results;
					MessageBox.success("Data Load Error");
					sap.ui.core.BusyIndicator.hide();

				}

			});

			oModel.read("/JobLoggingSet(Docno='" + docNo + "',Mjahr='" + year + "')", {
				urlParameters: {

					"$expand": "JoblogOpeListNav,JoblogToAttachNav,JoblogToDRSSNav,JoblogToPOConsupNav,JoblogToSerListNav,JoblogToTimesheetNav,JoblogToPumpsheetNav"

				},
				success: function (oData, oResponse) {

					that.JoblogToSerListNav = oData.JoblogToSerListNav.results;
					var JoblogToSerListNav = new JSONModel();
					JoblogToSerListNav.setData(that.JoblogToSerListNav);
					that.getView().setModel(JoblogToSerListNav, 'JoblogToSerListNav');

					var obj = {
						itemselect: ""
					};
					var DropJB = new JSONModel();
					DropJB.setData(obj);
					that.getView().setModel(DropJB, 'DropJB');

					that.JoblogToPOConsupNav = oData.JoblogToPOConsupNav.results;
					var JoblogToPOConsupNav = new JSONModel();
					JoblogToPOConsupNav.setData(that.JoblogToPOConsupNav);
					that.getView().setModel(JoblogToPOConsupNav, 'JoblogToPOConsupNav');

					that.JoblogToDRSSNav = oData.JoblogToDRSSNav.results;
					var subtItem = [];
					var aprItem = [];
					var allItem = [];
					var actlog = [];
					var REJC = [];

					that.JoblogToDRSSNav.forEach((element) => {
						if (element.Jlstatus === "SUBT") {
							// var servieitem = {};
							subtItem.push(element);

						} else if (element.Jlstatus === "INIT") {
							actlog.push(element);

						} else if (element.Jlstatus === "APRV") {
							aprItem.push(element);

						}

					});
					var subtItemModel = new JSONModel();
					subtItemModel.setData(subtItem);
					that.getView().setModel(subtItemModel, 'subtItemModel');

					var actlogModel = new JSONModel();
					actlogModel.setData(actlog);
					that.getView().setModel(actlogModel, 'actlogModel');

					var aprItemModel = new JSONModel();
					aprItemModel.setData(aprItem);
					that.getView().setModel(aprItemModel, 'aprItemModel');

					var Jbservice = new JSONModel();
					Jbservice.setData(that.JoblogToDRSSNav);
					that.getView().setModel(Jbservice, 'Jbservice');

					that.JoblogOpeListNav = oData.JoblogOpeListNav.results;
					var obj = {
						length: that.JoblogOpeListNav.length
					}

					that.DetailObj.Docno = oData.Docno;
					that.DetailObj.Ebeln = oData.Ebeln;
					that.DetailObj.Mjahr = oData.Mjahr;
					that.DetailObj.PoConperc = oData.PoConperc;

					that.DetailObj.PoTitle = oData.PoTitle;
					that.DetailObj.PoTrgtval = oData.PoTrgtval;
					that.DetailObj.ServiceDesc = oData.ServiceDesc;
					that.DetailObj.ServiceId = oData.ServiceId;

					that.DetailObj.SesConsv = oData.SesConsv;
					that.DetailObj.TotalCommit = oData.TotalCommit;
					that.DetailObj.TotalValue = oData.TotalValue;
					that.DetailObj.WsiteDhaGateDis = oData.WsiteDhaGateDis;

					var DetailObj = new JSONModel();
					DetailObj.setData(that.DetailObj);
					that.oView.setModel(DetailObj, 'DetailObj')

				},
				error: function (oData, response) {

					var data = oData.results;
					console.log(data);
					MessageBox.success(oData.statusText);

				}
			});

		},
		//nexus code
		// onJobLoggingListPresseTicket: function (oEvent) {
		// 	debugger;
		// 	var Data = oEvent.getSource().getBindingContext("data").getProperty(oEvent.getSource().getBindingContext(
		// 		"data").getPath());
		// 	var formType = Data.FormType;
		// 	eTicket = "X";
		// 	FormCode = Data.FormCode;
		// 	controller.FormCode = Data.FormCode;

		// 	if (Data.FileUpload !== "") {
		// 		this.getView().getModel("JobLogAttachmentEditModel").getData().Editable = Data.FileUpload;
		// 		this.getView().getModel("JobLogAttachmentEditModel").refresh(true);
		// 	}

		// 	if (formType === "AF") {
		// 		if (!this.JobLogAttachmentsDialog) {
		// 			this.JobLogAttachmentsDialog = sap.ui.xmlfragment(this.getView().getId(),
		// 				"zdwo_nx_drss_ven.view.fragment.OC.JobLogAttachmentsDialog", this);
		// 			this.getView().addDependent(this.JobLogAttachmentsDialog);
		// 		}

		// 		var itemsModel = this.getView().getModel("itemsModel").getData();

		// 		if (typeof Data['FormCode'] !== 'undefined') {
		// 			if (Data['FormFreq'] === "03") {
		// 				this.onmonthlyAttachment(Data);
		// 			} else {
		// 				this.JobLogAttachmentsDialog.open();
		// 				this.oFilterJobLogAttach();
		// 				this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
		// 			}
		// 		}
		// 	} else if (formType === "EF") {
		// 		var itemModelData = this.getItemModelData();
		// 		var makeDate = itemModelData.Reqdt;
		// 		makeDate.setMonth(makeDate.getMonth() - 1);
		// 		var lastmonth = makeDate.getMonth() + 1;
		// 		var lastyear = makeDate.getFullYear();
		// 		this.getRouter().navTo(Data.FormRout, {
		// 			DrssNo: itemModelData.Docno,
		// 			Rqtype: itemModelData.Rqtype,
		// 			Gid: this.Gid,
		// 			Mjahr: itemModelData.Mjahr,
		// 			Srvtype: itemModelData.SrvtypeCode,
		// 			Zmonth: lastmonth,
		// 			Zyear: lastyear,
		// 			FormCode: FormCode
		// 		});
		// 	} else {
		// 		// Do Nothing
		// 	}

		// },

		// Addd based on Sathya Comments
		onPageRefresh: function () {
			this.getRequestData(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);
			this._MessageManager = Core.getMessageManager();
			// F4 Model 
			var f4Model = new JSONModel();
			this.getView().setModel(f4Model, "F4Models");
			//this.getETicketInfo();
			if (eTicket === "X") {
				this.onPreviewETicketPress();
			}
			eTicket = "";
			this.joblogginAttachment = [];
		},

		getJoblogging: function () {
			return new Promise(function (resolve, reject) {

				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", controller.DrssNo),
					new sap.ui.model.Filter("Mjahr", "EQ", controller.Mjahr)
				];
				this.busyDialog.open();
				this.getView().getModel("VendorService").read("/JobloggingFormsSet", {
					filters: oFilter,
					success: function (oData) {
						for (var i = 0; i < oData.results.length; i++) {
							if (oData.results[i].FormCode === "F020") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().Tvd = true;
							}

							if (oData.results[i].FormCode === "F021") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().Sos = true;
							}

							if (oData.results[i].FormCode === "F038") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().Operations = true;
							}

							if (oData.results[i].FormCode === "F048") {
								this.getOwnerComponent().getModel("JoblogFormsModel").getData().NonCharge = true;
							}
						}
						var oJsonModel = new JSONModel(oData.results);
						this.getView().setModel(oJsonModel, "JobLoggingModel");
						this.busyDialog.close();
						resolve(oData);
					}.bind(this),
					error: function (oError) {
						this.busyDialog.close();
						reject();
					}.bind(this)
				});
			}.bind(this));
		},

		// //Get Request Data
		getRequestData: function (docNo, year, Rqtype) {

			if (!docNo) {
				var docNo = this.DrssNo;
			}
			if (!year) {
				var year = this.Mjahr;
			}
			if (!Rqtype) {
				var Rqtype = this.Rqtype;
			}
			// var oModel = this.getView().getModel("VendorService");
			var oModel = this.getView().getModel("oReqHeaderSetModel");
			// this.busyDialog.open();
			oModel.read("/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + Rqtype + "')", {
				urlParameters: {
					"$expand": "HeaderToAttNav,HeaderToCommNav,HeaderToItemNav,HeaderToUserInfoNav,HeaderToWfLogNav,HeaderToItemNav/ItemToCommNav,HeaderToWfActionNav,HeaderToItemNav/ItemToEdrssNav,HeaderToItemNav/ItemToDrssTSNav"
				},
				success: function (oData) {
					if (oData.Jltab) {
						this.getJoblogging();
					}

					if (oData.Ettab) {
						this.getETicketInfo(oData.Rqstat);
						this.getView().byId("iconTabBar2").setSelectedKey("eTicket");
						this.getView().byId("iconTabBar3").setVisible(false);
					} else if (oData.Rqstat === "JOBL") {
						this.getView().byId("iconTabBar3").setVisible(true);
						this.getView().byId("iconTabBar2").setSelectedKey("JobLogging");
						this.getETicketInfo("rejectedETicket");
					} else {
						this.getView().byId("iconTabBar3").setVisible(true);
						this.getView().byId("iconTabBar2").setSelectedKey("BasicData");
					}

					this.prepareData(oData);
					this.FormsListCall();
					if (oData.ReqReject == "X") {
						this._venRejReqAlert(oData);
					}

					this._checkConsPdfBtnVisibility();

					// this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					// this.busyDialog.close();
					var msgs = this.getErrorMessages(oResponse);
					var itemsModel = new JSONModel(null);
					itemsModel.setSizeLimit(5000);
					this.getView().setModel(itemsModel, "itemsModel");
					this.getView().getModel("itemsModel").refresh(true);
				}.bind(this)
			});
		},

		_venRejReqAlert: function (oData) {
			MessageBox.information("Service order ( " + oData.Docno + " ) is awaiting for foremen's approval for request cancellation.", {
				//actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact"
			});
		},

		prepareData: function (oData) {;

			this.removeResultProp(oData);
			var itemsModel = new JSONModel(oData);
			itemsModel.setSizeLimit(5000);
			this.getView().setModel(itemsModel, "itemsModel");
			//this.getView().setModel(new JSONModel(oData), "itemsModel");
			this.getView().getModel("itemsModel").setSizeLimit(5000);
			this.getOwnerComponent().getModel("itemsModel").setSizeLimit(5000);
			this.getOwnerComponent().getModel("itemsModel").setData(oData);
			if (oData.hasOwnProperty("HeaderToAttNav") && oData.HeaderToAttNav.length) {
				this.Attachments = oData.HeaderToAttNav;
			} else {
				oData.HeaderToAttNav = [];
			}
			var oPromis = this.getConfig(oData.Rqtype, oData.Fldvar);
			oPromis.then(this.onResolve, this.onReject);

			var oTreeTable = this.byId("ReferenceTable1");
			oTreeTable.expandToLevel(1);

			if (oData.Jledit) {
				controller.onGetConsPDFData();
			}
		},

		checkPoItemFun: function (oItemsModel) {
			controller.checkpo = '';
			var itemsModelData = oItemsModel.getData();
			$.each(itemsModelData['HeaderToItemNav'], function (ind, obj) {
				if (obj['PoNo'] !== "") {
					controller.checkpo = obj['PoNo'];
					this.changeMade = "X";
					return;
				}
			}.bind(this));
		},

		onResolve: function (controller) {
			var model = controller.getView().getModel("itemsModel");
			if (controller.getView().getModel("itemsModel").getProperty("/Rqstat") === "INIT" ||
				controller.getView().getModel("itemsModel").getProperty("/Rqstat") === "") {
				controller.setViewMode(true);
			} else {
				controller.setViewMode(false);
			};
			controller.ItemCommentColor();
			controller.checkPoItemFun(model);
		},

		_getSelectModelFields: function (oData) {
			var promise = new Promise(function (resolve, reject) {
				var oModel = this.getView().getModel("oDataModel");
				var itemsModel = this.getModel("itemsModel").getData();
				var oSelectModel = this.getView().getModel("SelectModel");
				var oSelcData = oSelectModel.getData();
				var objData = {
					JLSTATUS: "",
					//  ZDWO_RADIUS:"",
					//  ZP_RS_PRRTY:"",
					//  ZDWO_HOLE_SIZE:""
				};

				for (var prop in objData) {
					//if (func.hasOwnProperty(prop)) {
					var aFilters = [];
					aFilters.push(new Filter("Field", FilterOperator.EQ, prop));
					// aFilters.push(new Filter("Descr4", FilterOperator.EQ, oData.Rqtype));
					oModel.read("/F4SearchHelpSet", {
						filters: aFilters,
						success: function (oData) {
							if (oData.results.length > 0) {
								var odataField = oData.results[0].Descr2;

								if (odataField !== "" && (odataField === "ZDWO_RADIUS" || odataField === "ZP_RS_PRRTY" ||
										odataField === "ZDWO_HOLE_SIZE")) {
									itemsModel[odataField] = oData.results;

								} else if (odataField !== "") {
									oSelcData[odataField] = oData.results;
									oSelectModel.refresh();
									console.log(oData);
								}
							}
							//  resolve();
						}.bind(this),
						error: function (oResponse) {
							var msgs = this.getErrorMessages(oResponse);
							//	reject();
						}.bind(this)
					});
					//  }
				}
			}.bind(this));
			return promise;
		},

		onSelectionChange: function (evt) {
			var source = evt.getSource();
			var isSelected = source.getSelected();
			var oSearchModel = this.searchHelpDialog.getModel("searchHelpModel");
			var selectedItem = source.getParent().getParent().getBindingContext("searchHelpModel").getObject();
			var index = oSearchModel.getData()['selectedItems'].indexOf(selectedItem);
			if (isSelected) {
				if (index < 0) {
					oSearchModel.getData()['selectedItems'].push(selectedItem);
				}
			} else {
				if (index > -1) {
					oSearchModel.getData()['selectedItems'].splice(index, 1);
				}
			}
			oSearchModel.refresh();
			this.checkTableItems();

		},

		checkTableItems: function () {
			var oTableItems = Core.byId("serviceSelectedTable").getItems();
			$.each(oTableItems, function (ind, obj) {
				obj.setSelected(true);
			});
			Core.byId("serviceSelectedTable").getModel("searchHelpModel").refresh();

		},

		onSelectedService: function (evt) {
			var oSource = evt.getParameter('selectedItem');

		},

		removeResultProp: function (oData) {
			for (var key in oData) {
				if (oData[key] && oData[key].hasOwnProperty("results")) {
					oData[key] = oData[key].results;
					for (var i in oData[key]) {
						this.removeResultProp(oData[key][i]);
					}
				}
			}
		},

		onSelectService: function (evt) {
			var oSource = evt.getSource();
			var isSelected = oSource.getSelected();

			if (isSelected) {
				var oObject = oSource.getParent().getParent().getBindingContext("searchHelpModel").getObject();

				this.selectedItem['Maktxo'] = oObject.ServStext;
				this.selectedItem['ServLtext'] = oObject.ServLtext;
				this.getView().getModel("itemsModel").refresh();
			}

		},
		onNavBack: function (oEvent) {;
			this.oRouter.navTo("Inbox");

			// var oPgModel = this.getView().getModel("itemsModel");

			// if (oPgModel['oData']['Rqstat'] === "SUBT" || oPgModel['oData']['Rqstat'] === "RSUB") {
			// 	MessageBox.warning("Do you want to save the Service Order?", {
			// 		actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO, sap.m.MessageBox.Action.CANCEL],
			// 		styleClass: "sapUiSizeCompact",
			// 		onClose: function (sAction) {
			// 			if (sAction === "YES") {
			// 				var aPromise = [];
			// 				aPromise.push(this.onSaveOC());
			// 				Promise.all(aPromise).then(function (oRequest) {
			// 					var oPageModel = this.getView().getModel("itemsModel").getData();
			// 					/*if(this.itemDetails.DrssNo === "0000000000"){*/
			// 					this.itemDetails.DrssNo = oPageModel.Docno;
			// 					MessageBox.success("The Service Order has been saved with ID #" + oPageModel['Docno'], {
			// 						actions: [MessageBox.Action.CLOSE],
			// 						onClose: function () {
			// 							/// var sPreviousHash = History.getInstance().getPreviousHash();
			// 							history.go(-1);
			// 						}.bind(this)
			// 					});
			// 					/*}*/
			// 				}.bind(this));
			// 			} else if (sAction === "CANCEL") {

			// 			} else {
			// 				history.go(-1);
			// 			}
			// 		}.bind(this)
			// 	});
			// } else {
			// 	history.go(-1);
			// 	//this.getRouter().navTo(history['state']['sap'].history[history['state']['sap'].history.length-2]);
			// }
		},

		/*	   prepareAttachments : function(attachments){
					//this.ItemsAttachmentsModel = this.getView().getModel("itemsAttachment").getData();
					
					this.attachments = attachments;
					this.headerLevelAttachments = [];
					this.itemsAttachmentsValues = [];
					this.joblogginAttachment = [];
					if (attachments.length>0){
					
						$.each(attachments,function(ind,obj){
							var attachItem = obj;
							    if (obj['Category'] === '03'){
								   this.joblogginAttachment.push(attachItem);
								  //var itemLevel = "03";
							    }else if(obj['Category'] === "01"){
								   this.itemsAttachmentsValues.push(attachItem);
							    }else {
							       this.headerLevelAttachments.push(attachItem);
							    }
								/*if(attachItem.Category === itemLevel ){
									this.headerLevelAttachments.push(attachItem);
								}
								else{
									this.itemsAttachmentsValues.push(attachItem);
									
								}*/
		/*		}.bind(this));
				}
			if (this.getView().getModel("itemsAttachment")){
				this.getView().getModel("itemsAttachment").setData(this.itemsAttachmentsValues);
				
			}else {
				this.getView().setModel(new JSONModel(this.itemsAttachmentsValues), "itemsAttachment");
			}
			
			this.getView().getModel("itemsAttachment").refresh();
			return this.headerLevelAttachments;
		},*/

		//Bind the header comments
		/*	onHeaderCommentsPress : function(oEvent){
				var commentsTxt = this.byId("commentsTxt");
				var sPath = oEvent.getParameter("item").getBindingContext("itemsModel").getPath();
				commentsTxt.bindElement({ path: sPath, model: "itemsModel" });
			},
			*/
		onHeaderCommentsPress: function (oEvent, oSelected) {
			var commentsTxt = this.byId("commentsTxt");
			var aSelectedKey = oEvent.getSource().getSelectedKey();
			if (oSelected === "Comments" || aSelectedKey === "HDR") {
				this.getView().byId("segmentedButton").setSelectedKey("HDR");
				sPath = "/HeaderToCommNav/0";
				commentsTxt.setRows(1);
				commentsTxt.setCols(100);
				commentsTxt.setMaxLength(72);
			} else {
				var sPath = oEvent.getParameter("item").getBindingContext("itemsModel").getPath();
				commentsTxt.setRows(10);
				commentsTxt.setCols(100);
				commentsTxt.setMaxLength(200);
			}
			commentsTxt.bindElement({
				path: sPath,
				model: "itemsModel"
			});

		},

		handleSelcHeader: function (evt) {
			var oSelectedTab = evt.getParameter("key");
			if (oSelectedTab === "Comments") {
				this.onHeaderCommentsPress(evt, oSelectedTab);
			}
			if (oSelectedTab === "eTicket") {
				this.getView().byId("iconTabBar3").setVisible(false);
			} else {
				this.getView().byId("iconTabBar3").setVisible(true);
			}
		},

		// On Drilling Program Search

		OnDrillingProgSearch: function (oEvent) {
			var sValue = oEvent.getParameter("query") + "*";
			var aFilters = [new Filter("DpPgmNum", FilterOperator.EQ, sValue)];
			var oModel = this.getOwnerComponent().getModel("VendorService");
			this.busyDialog.open();
			oModel.read("/DrillPgmSet", {
				filters: aFilters,
				success: function (oData) {
					// console.log(oData);
					var model = new JSONModel(oData);
					this.getView().setModel(model, "DrillingModel");
					this.busyDialog.close();
				}.bind(this),
				error: function (Error) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(Error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}

			});
		},

		OnCpyFrOtherSearch: function (oEvent) {
			var sValue = oEvent.getParameter("query") + "*";
			var aFilters = [new Filter("Wellnm", FilterOperator.EQ, sValue),
				new Filter("Rqtype", FilterOperator.EQ, this.itemDetails.Rqtype)
			];
			var oModel = this.getOwnerComponent().getModel("VendorService");
			this.busyDialog.open();
			oModel.read("/ServiceSearchWellSet", {
				filters: aFilters,
				success: function (oData) {
					// console.log(oData);
					var model = new JSONModel(oData);
					this.getView().setModel(model, "cpyfotherModel");
					this.busyDialog.close();
				}.bind(this),
				error: function (Error) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(Error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}

			});
		},

		/*onSelectServiceClose: function (evt) {
			var oSelectedItems = sap.ui.getCore().byId("checkedList").getSelectedItems();
		    this.checkforSelectedService(oSelectedItems,"service");
			this.searchHelpDialog.close();
		},
		*/
		onWFRemarks: function (evt) {
			if (!this.WFRemarksDialog) {
				this.WFRemarksDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.OC.WFRemarksDialog", this);
				this.getView().addDependent(this.WFRemarksDialog);
			}
			this.WFRemarksDialog.open();
		},
		onCloseWFRemarks: function () {
			if (this.WFRemarksDialog) {
				this.WFRemarksDialog.close();
			}
			if (this.WFRemakDialog) {
				this.WFRemakDialog.close();
			}
		},

		// Seach Help Dialog Fragment
		onValueHelp: function (evt) {
			var me = this;
			var oSource = evt.getSource();
			this.core = Core;
			this.pageModel = this.getView().getModel("itemsModel").getData();
			if (oSource.getParent().getBindingContext("itemsModel")) {
				this.selectedItem = oSource.getParent().getBindingContext("itemsModel").getObject();
				controller.oSelectedObj = oSource.getParent().getBindingContext("itemsModel").getObject();
			}
			if (me.searchHelpDialog && me.serviceCount === 1) {
				/* var oSuggestionItem = sap.ui.getCore().byId("suggestionItems");
	           if (oSuggestionItem && this.itemDetails.srvDesc !==""){
		           oSuggestionItem.setSelectedKey(this.itemDetails.serviceDesc);
	            }*/
				Core.byId("searchField").setValue("");
				me.searchHelpDialog.open();
			} else {
				var promise = new Promise(function (resolve, reject) {
					me.getSelectedServiceData(me.pageModel.SrvtypeCode).then(function (response) {
						if (me.serviceCount === 0 && !me.searchHelpDialog || me.searchHelpDialog) {
							if (me.searchHelpDialog) {
								me.searchHelpDialog.destroyContent();
							}
							me.searchHelpDialog = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.SearchHelpForService", me);
							me.serviceCount++;
						} else {
							me.serviceCount++;
						}
						var oData = [];
						oData.ServiceItemsTable = response;
						oData.selectedItems = [];
						me.service = oData;
						var model = new JSONModel(oData);
						me.searchHelpDialog.setModel(model, "searchHelpModel");
						me.searchHelpDialog.open();
						me.core.byId("searchField").setValue("");
						me.searchHelpDialog.getModel("searchHelpModel").refresh();
						if (me.pageModel.SrvtypText && me.pageModel.SrvtypText !== "") {
							var oSuggestionItem = Core.byId("selectedSrcCode");
							if (oSuggestionItem) {
								oSuggestionItem.setValue(me.pageModel.SrvtypText);
							}
						}
					});
				});
			}
		},

		// on mode select
		onListCheck: function (evt) {
			var oSelectedTableItem = evt.getParameter("listItem").getBindingContext("searchHelpModel").getObject();
			var sSelTabItemProperty = oSelectedTableItem['Serviceid'];
			var aTreeItems = sap.ui.getCore().byId("serviceSelectId");
			for (var x = 0; x < aTreeItems.getItems().length; x++) {
				var oTempItemData = aTreeItems.getItems()[x].getBindingContext("searchHelpModel").getObject();
				if (sSelTabItemProperty === oTempItemData['Serviceid']) {
					oTempItemData['selected'] = false;
				}
			}
			aTreeItems.getModel("searchHelpModel").refresh();
			var oSearchModel = this.searchHelpDialog.getModel("searchHelpModel");
			var index = oSearchModel.getData()['selectedItems'].indexOf(oSelectedTableItem);
			oSearchModel.getData()['selectedItems'].splice(index, 1);
			oSearchModel.refresh();
			this.checkTableItems();
		},

		loadServiceList: function () {
			var that = this;
			that.model = this.getOwnerComponent().getModel("VendorService");
			var promise = new Promise(function (resolve, reject) {
				//  var aFilters = [new Filter("SrvtypeCode", FilterOperator.EQ, that.servtypeItem),];
				that.model.read("/ServiceTypesSet", {
					success: function (oData) {
						//	that.prepareData(oData);
						resolve(oData);
					},
					error: function (Error) {
						reject(Error);
					}
				});
			});
			return promise;
		},

		// On service search based on each item
		selectChange: function (oEvent, serviceDesc) {
			var that = this;
			if (oEvent) {
				if (oEvent.getParameter('selectedItem') != null) {
					this.selectedKey = oEvent.getParameter('selectedItem').getKey();
				}

			} else {
				this.selectedKey = serviceDesc;
			}
			var promise = new Promise(function (resolve, reject) {
				that.getSelectedServiceData(that.selectedKey).then(function (response) {
					that.searchHelpDialog.getModel("searchHelpModel").getData().ServiceItemsTable = response;
					that.searchHelpDialog.getModel("searchHelpModel").refresh();
				});
			});
		},

		getSelectedServiceData: function (oSelcSrvKey) {
			var that = this;
			var oPageModel = this.getView().getModel("itemsModel").getData();
			that.model = this.getOwnerComponent().getModel("VendorService");
			var aFilters = [new Filter("SrvtypeCode", FilterOperator.EQ, oSelcSrvKey),
				new Filter("Location", FilterOperator.EQ, oPageModel['Location']),
				new Filter("Radius", FilterOperator.EQ, oPageModel['Radius']),
				new Filter("HoleSize", FilterOperator.EQ, oPageModel['HoleSize'])
			];
			var promise = new Promise(function (resolve, reject) {
				that.model.read("/ServiceMasterSet", {
					filters: aFilters,
					success: function (oData) {
						oData = that.SrvTreeConversion.prepareTree(oData);
						//	that.prepareData(oData);
						resolve(oData);
					}.bind(this),
					error: function (Error) {
						//	reject(Error);
					}
				});
			});
			return promise;
		},

		// Select UOM 
		selectUOM: function (evt) {
			this.selectedcontxtForUOM = evt.getSource().getParent().getBindingContext("itemsModel").getObject();
			var getData = evt.getSource().data();
			/*if (!this.uomDialog){*/
			var oDataModel = this.getView().getModel("oDataModel");
			var aFilters = [new Filter("Field", FilterOperator.EQ, getData.Field),
				new Filter("Rqtype", FilterOperator.EQ, "E5")
			];
			oDataModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oRes) {
					var oModel = new JSONModel(oRes);
					if (!this.uomDialog) {
						this.uomDialog = sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.UOMDialog", this);
					}
					this.uomDialog.setModel(oModel, "UOM");
					this.uomDialog.open();
				}.bind(this),
				error: function (error) {}
			});
			/*}
			else {
				this.uomDialog.open();
			}*/
		},

		UOMhandleClose: function (evt) {
			var getItem = evt.getParameter("selectedItem").getBindingContext("UOM").getObject();
			this.selectedcontxtForUOM.Meins = getItem.Value1;
			this.getView().getModel("itemsModel").refresh();
		},

		onSelectServiceClose: function (evt) {
			var oSelectedItems = Core.byId("serviceSelectedTable").getSelectedItems();
			this.checkforSelectedService(oSelectedItems, "service");
			this.searchHelpDialog.close();
			this.checkForDuplicates();
			this.serviceCount = 0;
		},

		checkForDuplicates: function () {

			this.UniqueData = [];
			this.sDuplicateSrvid = [];
			if (controller.aDuplicates.length > 0) {
				var sDuplicateLineItem = "";
				$.each(controller.aDuplicates, function (ind, obj) {
					if (ind === 0) {
						sDuplicateLineItem = obj['Zeile'];
					} else {
						//var iCheckMatch = this.matchString(sDuplicateLineItem, obj['Zeile'], 'ig');
						//  if (iCheckMatch.length === 0){
						sDuplicateLineItem = sDuplicateLineItem + ", " + obj['Zeile'];
						//  }
					}
				}.bind(this));

				MessageBox.information("Selected Service ID was already added at line item #" + sDuplicateLineItem);
			}
			this.sequenceOrder();
		},

		sequenceOrder: function () {
			var oModel = this.getView().getModel("itemsModel");
			this.itemData = oModel.getProperty("/HeaderToItemNav");
			var oSeq = [];
			$.each(this.itemData, function (ind, obj) {
				if (ind === 0) {
					iNewIndex = parseInt("0000") + 10;
				} else {
					var iLastItemIndex = oSeq.length - 1,
						iNewIndex = parseInt(oSeq[iLastItemIndex].Zeile) + 10;
				}
				var Zeile = this.addZeil(iNewIndex, 4);
				//  var count = (ind+1).toString();
				obj.Zeile = Zeile;
				oSeq.push(obj);

			}.bind(this));
			oModel.getData()['HeaderToItemNav'] = oSeq;
			this.getView().byId("ReferenceTable").getModel("itemsModel").refresh();
		},

		clearTableItems: function (evt) {
			var oData = Core.byId("serviceSelectedTable").getModel("searchHelpModel").getData();
			oData.selectedItems = [];
			Core.byId("serviceSelectedTable").getModel("searchHelpModel").refresh();
			this.serviceCount = 0;
			this.searchHelpDialog.close();
			this.onValueHelp(evt);
		},

		onCloseSearchDialog: function () {
			this.searchHelpDialog.close();
		},

		onFilterServiceSearchm: function () {
			var that = this;
			var promise = new Promise(function (resolve, reject) {
				that.getSelectedServiceData().then(function (response) {
					that.getView().setModel(model, "itemsDialog");
					that.getView().getModel("itemsDialog").refresh();
				});
			});
		},

		onDialogSuggest: function (event) {
			var sValue = event.getParameter("suggestValue"),
				aFilters = [];
			if (sValue) {
				aFilters = [
					new Filter([
						new Filter("Fieldtext", function (sText) {
							return (sText || "").toUpperCase().indexOf(sValue.toUpperCase()) > -1;
						})

					], false)
				];
			}
			this.oSearchField.getBinding('suggestionItems').filter(aFilters);
			this.oSearchField.suggest();
		},

		addStagePress: function () {
			// Still not implemented
			this.searchHelpDialog.close();
		},
		// Create Page Selection
		checkforSelectedService: function (oSelectedData, oValue, oModelName) {
			var oModel = this.getView().getModel("itemsModel");
			var HeaderToRefNav = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var getData = oModel.getProperty("/HeaderToItemNav");
			controller.aDuplicates = [];
			//  var pageModelData = oModel.getData()['HeaderToItemNav'];
			this.custHeaderToItemNav = [];
			$.each(oSelectedData, function (ind, obj1) {
				var obj = this.addItem();

				// this.itemsObj  = obj;
				var pageModelData = oModel.getData()['HeaderToItemNav'];
				if (oValue === "service") {
					var oObject = obj1.getBindingContext("searchHelpModel").getObject();
					var sText = "";
					if (oObject['ServStext']) {
						var sText = oObject['ServStext']
					} else {
						var sText = oObject['ServLtext']
					}
					if (oModel.getData().HeaderToItemNav.length === 1 && ind === 0 && oModel.getData().HeaderToItemNav[ind].Maktxo === "") {
						obj.Maktxo = oObject['ServStext'];
						obj.ServLtext = oObject['ServLtext'];
					} else {
						var HeaderToRefNav = oModel.getData()['HeaderToItemNav'];
						var iLastItemIndex = HeaderToRefNav.length - 1,
							iNewIndex = parseInt(HeaderToRefNav[iLastItemIndex].Zeile) + 10;
						var Zeile = this.addZeil(iNewIndex, 4);
						obj.Zeile = Zeile;
						obj.ItemToCommNav[0].Zeile = Zeile;
						obj.Maktxo = sText;
						obj.ServLtext = oObject['ServLtext'];
					}
					obj.Meins = oObject.UOM;
					if (!oObject.Serviceid) {
						oObject.Serviceid = "";
					}
					obj.ServiceId = oObject.Serviceid;

					// check deplicates
					var oCheckValues = getData.filter(item => obj['Maktxo'] === item['Maktxo']);
					if (oCheckValues.length > 0) {
						controller.aDuplicates.push(oCheckValues[0]);
						return;
					}

					if (ind === 0) {
						controller.oSelectedObj['Maktxo'] = sText;
						controller.oSelectedObj['ServLtext'] = oObject['ServLtext'];
						controller.oSelectedObj['Meins'] = obj.Meins;
						controller.oSelectedObj['ServiceId'] = obj.ServiceId;
						return;
					}

				}

				if (pageModelData[pageModelData.length - 1].Maktxo === '') {
					var lastIndexData = pageModelData[pageModelData.length - 1];
					lastIndexData.Maktxo = obj.Maktxo;
					lastIndexData.ServLtext = obj['ServLtext'];
					lastIndexData.Meins = obj.Meins;
					if (!obj.Serviceid) {
						oObject.Serviceid = "";
					}
					lastIndexData.ServiceId = obj.ServiceId;
				} else {
					if (oModel.getData().HeaderToItemNav.length === 1 && ind === 0 &&
						oModel.getData().HeaderToItemNav[ind].Maktxo === "") {
						oModel.getData().HeaderToItemNav[0].Maktxo = obj.Maktxo;
						oModel.getData().HeaderToItemNav[0].ServLtext = obj['ServLtext'];
					} else {
						oModel.getData().HeaderToItemNav.push(obj);
					}
				}

			}.bind(this));
			oModel.refresh();
			return oSelectedData;
		},

		// Add Stage for the copy from other well
		onCpyPressforCopyfrmDrss: function (evt) {
			//this.getView().byId("copyFromOtherWellTable").getSelectedItems()[0].getBindingContext("DrillingModel").getObject()
			var oTable = this.getView().byId("copyFromOtherWellTable");
			var oSelectedItems = oTable.getSelectedItems();
			this.checkforSelectedService(oSelectedItems, "cpyfdrss");
			var removeSelections = oTable.removeSelections(true);
			if (oSelectedItems.length > 0) {
				this.getView().byId("iconTabBar3").setSelectedKey("Item Information");
			}

			//this.searchHelpDialog.close();
		},

		// Search Help Dialog ends here
		// On View Search Suggest starts here
		onViewItemSuggest: function (event) {
			var sValue = event.getParameter("suggestValue"),
				aFilters = [];
			if (sValue) {
				aFilters = [
					new Filter([
						new Filter("Fieldtext", function (sText) {
							return (sText || "").toUpperCase().indexOf(sValue.toUpperCase()) > -1;
						})

					], false)
				];
			}
			this.searchField.getBinding('suggestionItems').filter(aFilters);
			this.searchField.suggest();
		},
		// On View Suggest search ends here	

		onClose: function () {
			if (this._ItemsCommondialog) {
				this._ItemsCommondialog.close();
			}
			if (this.JobLogAttachmentsDialog) {

				this.JobLogAttachmentsDialog.close();
				this.JobLogAttachmentsDialog.destroy();
				delete this.JobLogAttachmentsDialog
			}

		},

		onCloseAttachmentPopUp: function () {

			if (this._ItemsCommondialog) {
				this._ItemsCommondialog.close();
			}
			if (this.JobLogAttachmentsDialog) {

				this.JobLogAttachmentsDialog.close();
				this.JobLogAttachmentsDialog.destroy();
				delete this.JobLogAttachmentsDialog
			}
			if (this.VATdialog) {

				this.VATdialog.close();
				this.VATdialog.destroy();
				delete this.VATdialog
			}
			if (this.Invoice) {

				this.Invoice.close();
				this.Invoice.destroy();
				delete this.Invoice
			}

		},

		getItemsDialogs: function () {
			var me = this;
			var promise = new Promise(function (resolve, reject) {
				me.gModel.callFunction("/SHELP_GET_FIELDS", {
					method: "GET",
					urlParameters: {
						SHLPNAME: "ZUPLG_DOCNO_SH",
						SHLPTYPE: "SH"
					},
					success: function (oData) {
						resolve(oData);
						//// console.log(oData);
					},
					error: function (error) {
						reject(error);
					}
				});
			});
			return promise;
		},

		checkValidation: function () {
			var errorList = this.validationControlsByFieldGroupId();
			this.instantiateErrorMessageModel(errorList);
			this.createMessagePopoverModel();
			return errorList;
		},

		removeParams: function (items) {
			$.each(items['HeaderToItemNav'], function (ind, obj) {
				if (obj['SplArray'] || obj['EText']) {
					delete obj['SplArray'];
					delete obj['EText'];
				}
			}.bind(this))

			return items;
		},

		onSaveOC: function (evt) {
			var me = this;
			// var oModel = this.getOwnerComponent().getModel("VendorService");
			var oModel = this.getOwnerComponent().getModel("oReqHeaderSetModel");
			var itemModel = this.getView().getModel("itemsModel");
			itemModel.getData()['HeaderToItemNav'] = this._AddedByVendorsItems(itemModel.getData()['HeaderToItemNav']);
			this.reqItems = itemModel.getData();
			// Validation check

			if (itemModel.getData().EstSdt > itemModel.getData().EstEdt) {
				sap.m.MessageBox.error("Estimate End Date cannot be less than Estimate Start Date", {
					title: "Error",
				});
				return;
			}

			return new Promise(function (resolve, reject) {
				var errorCheck = this.checkValidation();

				if (errorCheck.length > 0) {
					reject();
					return;

				}
				// OData Service Request
				var length = this.reqItems.HeaderToItemNav.length;
				for (var i = 0; i < length; i++) {
					if (this.reqItems.HeaderToItemNav[i].ServLtext === "" && this.reqItems.HeaderToItemNav[i].DelInd == "") {
						sap.m.MessageBox.error("Service Name cannot be empty");
						return;
					}

					/*if(this.reqItems.HeaderToItemNav[i].Menge === ""){
						sap.m.MessageBox.error("Service Quantity cannot be empty");
						return;
					}*/

					if (this.reqItems.HeaderToItemNav[i].Meins === "" && this.reqItems.HeaderToItemNav[i].DelInd == "") {
						sap.m.MessageBox.error("Service UoM cannot be empty");
						return;
					}
				}
				delete this.reqItems['HeaderToUserInfoNav'];
				delete this.reqItems['ZDWO_HOLE_SIZE'];
				delete this.reqItems['ZDWO_RADIUS'];
				delete this.reqItems['ZDWO_RADIUS'];

				delete this.reqItems.FormsList;

				// Remove length from a vendor name 12/02/2022
				/* if (this.reqItems['VEND_NAME'].length>30){
				 this.reqItems['VEND_NAME'] = this.reqItems['VEND_NAME'].slice(0,29);
				 }*/

				this.OnAddCmdtoField();
				this.reqItems = this.removeParams(this.reqItems);
				oModel.create("/ReqHeaderSet", this.reqItems, {
					method: "POST",
					success: function (oData) {
						if (this.itemDetails.DrssNo === "0000000000") {
							this.itemDetails.DrssNo = oData.Docno;
							sap.m.MessageToast.show("The Service Order has been created with ID #" + oData.Docno);
						} else {
							sap.m.MessageToast.show("The Service Order ID # " + oData.Docno + " has been successfully updated");
						}
						this.prepareData(oData);
						this.busyDialog.close();
						resolve();
						this.instantiateErrorMessageModel();
						this.resetFieldGroupIdValueState();
						this.busyDialog.close();
					}.bind(this),
					error: function (oResponse, error) {
						this.busyDialog.close();
						var msgs = this.getErrorMessages(oResponse);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();
					}.bind(this)
				});

			}.bind(this));
		},

		getErrorMsg: function (oResponse) {
			return JSON.parse(oResponse.responseText).error.message.value;

		},

		instantiateErrorMessageModel: function (Messages) {
			if (Messages && Messages.length > 0) {
				this.getView().setModel(new JSONModel({
					MessageCount: Messages.length,
					Messages: Messages
				}), "ErrorMessagesModel");
			} else {
				this.getView().setModel(new JSONModel({}), "ErrorMessagesModel");
			}

			if (this.oMessagePopover) {
				this.oMessagePopover.close();
			}
		},

		//Instantiate MessagePopOver
		createMessagePopoverModel: function () {
			if (this.oMessagePopover) {
				this.oMessagePopover.close();
			}
			if (!this.oMessagePopover) {
				this.oMessagePopover = new sap.m.MessagePopover({
					items: {
						path: 'ErrorMessagesModel>/Messages/',
						template: new sap.m.MessageItem({
							type: "{ErrorMessagesModel>severity}",
							title: "{ErrorMessagesModel>message}"
						})
					}
				});
			}
			this.getView().byId("MessagePopoverBtn").addDependent(this.oMessagePopover);
			if (this.getView().getModel("ErrorMessagesModel").getProperty("/Messages") && this.getView().getModel("ErrorMessagesModel").getProperty(
					"/Messages").length > 0) {
				this.oMessagePopover.openBy(this.getView().byId("MessagePopoverBtn"));
			}
		},

		// Message Handler
		handleMessagePopoverPress: function () {
			if (this.oMessagePopover) {
				this.oMessagePopover.openBy(this.getView().byId("MessagePopoverBtn"));
			} else {
				this.createMessagePopoverModel();
			}
		},

		onShowHideMaster: function () {
			var oAppView = this.getOwnerComponent().getModel("appView"),
				sMode;
			sMode = oAppView.getProperty("/mode");
			//	(sMode === "ShowHideMode") ? oAppView.setProperty("/mode", ("HideMode")): oAppView.setProperty("/mode", ("ShowHideMode"));
		},

		onCloseDialog: function () {
			this.selectFragment.close();
		},

		addZeil: function (num, size) {
			var s = num + "";
			while (s.length < size) s = "0" + s;
			return s;
		},

		onAddNewLine_ref: function (oEvent) {
			this.changeMade = "X";
			this.changeWFActionButton();
			//	var HeaderToRefNav = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");

			this.itemsObj = dataObject;

			var HeaderToRefNav = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var dataObject = this.addItem();
			var aCheckItem = [];
			/*$.each(HeaderToRefNav,function(ind,obj){
			}.bind(this));*/

			for (var ind in HeaderToRefNav) {
				if (HeaderToRefNav[ind]['Maktxo'] === "" && (HeaderToRefNav[ind]['ServLtext'] === "" || typeof HeaderToRefNav[ind]['ServLtext'] ===
						'undefined') && HeaderToRefNav[ind]['VendorAdd'] !== "") {
					sap.m.MessageBox.error("Please fill the added line item");
					return
				}
			}

			if (HeaderToRefNav) {
				var iLastItemIndex = HeaderToRefNav.length - 1,
					iNewIndex = parseInt(HeaderToRefNav[iLastItemIndex].Zeile) + 10;
				var Zeile = this.addZeil(iNewIndex, 4);
				dataObject.Zeile = Zeile;
				HeaderToRefNav.push(dataObject);
			} else {
				var results = [];
				dataObject.Zeile = "0010";
				results.push(dataObject);
				HeaderToRefNav = results;
			}
			this.getView().getModel("itemsModel").refresh();
		},

		addItem: function () {

			var oModel = this.getView().getModel("itemsModel");
			var HeaderToRefNav = oModel.getProperty("/HeaderToItemNav");
			var DataForPoItem = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav/0");
			var PoNo = DataForPoItem.PoNo;
			var PoItem = DataForPoItem.PoItem;
			var PckgNo = DataForPoItem.PckgNo;
			var LineNo = DataForPoItem.LineNo;
			/// var getData = oModel.getProperty("/HeaderToItemNav");
			if (oModel.getData().HeaderToItemNav.length > 0) {
				var oMoData = oModel.getData().HeaderToItemNav;
				var Zeile = oMoData[oMoData.length - 1].Zeile;
			} else {
				var Zeile = "0010";
			}

			var item = {
				Docno: this.itemDetails.DrssNo,
				Mjahr: this.itemDetails.Mjahr,
				Zeile: "",
				Eqpdesc: "",
				Eqpconttype: "",
				Itype: "",
				Matnr: "",
				Maktxo: "",
				Wgbez: "",
				ServiceId: "",
				Leadtime: "000",
				Mafd: "",
				Vendor: "",
				Meins: "",
				Menge: "0.000",
				Rmenge: "0",
				Rolegroup: "",
				FcompMenge: "0",
				Iphase: "",
				//Badgeno: "",
				PoNo: PoNo,
				PoItem: PoItem,
				PckgNo: PckgNo,
				LimitInd: "",
				ServLtext: "",
				LineNo: LineNo,
				CoInd: "",
				GrPrice: "0.00",
				Curr: "",
				/*VenGrPrice:"0.000",*/
				VenGrPrice: "0.00",
				/*VenPropQty:"0",*/
				VenPropQty: "0.000",
				Ename: "",
				WorkFrom: null,
				WorkTo: null,
				Wfstatus: "",
				Discount: "0.000",
				VendorAdd: "X1",
				DelInd: "",
				ItemToCommNav: [{
					Descrip: "Item Comments",
					Text: "",
					Docno: "",
					Mjahr: "0000",
					Ntdid: "ITM",
					Tdid: "ZTXT",
					Tdobject: "ZPDRSS",
					Txttype: "I",
					Zeile: Zeile
				}]
			};
			return item;
		},

		itemDeletePress: function (evt) {

			var getPath = evt.getParameter('id').split('-').reverse()[0];
			var that = this;
			that.oEvent = evt.getSource();
			that.oIconCell = evt.getSource().getParent().getParent().getCells()[8];
			that.oBindingObject = evt.getSource().getParent().getParent().getBindingContext("itemsModel").getObject();
			MessageBox.information("This service will be deleted. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {

						//if (typeof that.oBindingObject['EText'] !== "undefined" && that.oBindingObject['EText'] !== ''){
						//that.oIconCell.setColor("#000");
						var oSelecObject = this.getView().getModel("itemsModel").getObject("/HeaderToItemNav")[getPath];
						if (oSelecObject.VendorAdd === "" || oSelecObject.VendorAdd === "X") {
							oSelecObject.DelInd = "V";
							that.notificationPress(that.oEvent, true);
						} else if (oSelecObject.VendorAdd === "X1") {
							this.getView().getModel("itemsModel").getData()['HeaderToItemNav'].splice(getPath, 1);
							//oSelecObject.DelInd = "V";
							//that.notificationPress(that.oEvent,true);
						}
						/*else {
						   oSelecObject.DelInd = "V";
						}*/
						//}else {
						//MessageBox.warning("Please enter your comments before deleting this item");
						//that.oIconCell.setColor("#E9967A");
						//that.notificationPress(that.oEvent,true);
						//}

						this.getView().getModel("itemsModel").refresh();
						this.changeMade = "X";
						this.changeWFActionButton();
					}

				}.bind(this)
			});

			this.getView().byId("ReferenceTable").getModel('itemsModel').refresh();

		},

		itemDeleteUndoPress: function (evt) {
			var getPath = evt.getParameter('id').split('-').reverse()[0];
			MessageBox.information("This marked for deletion will be removed. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						if (this.getView().getModel("itemsModel").getObject("/HeaderToItemNav")[getPath].DelInd === "V") {
							this.getView().getModel("itemsModel").getObject("/HeaderToItemNav")[getPath].DelInd = "";
						}
						this.getView().getModel("itemsModel").refresh();
						this.changeMade = "X";
						this.changeWFActionButton();
					}
				}.bind(this)
			});

		},

		ChooseVendorID: function (oEvt) {
			var me = this;
			var oFilter = [];
			var promise = new Promise(function (resolve, reject) {
				me.loadDomainValues(oFilter)
					.then(function (res) {
						if (!me._vendorSelectDialog) {
							me._vendorSelectDialog = new sap.ui.xmlfragment(".fragment.HeaderFragments.Vendor", me);
						}
						var model = new JSONModel(res);
						me._vendorSelectDialog.setModel(model, "vendorModel");
						me._vendorSelectDialog.open();
						///		// console.log("fdsafsaf",res); 
					});
				return promise;
			});
		},

		vendorSelect: function (oEvt) {
			var oSelectedValue = oEvt.getParameter("selectedItem").getBindingContext('vendorModel').getObject().FIELDVAL;
			this.getView().byId("vendorInput").setValue(oSelectedValue);
		},

		vendorSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilterVId = new Filter("FIELDVAL", FilterOperator.Contains, sValue);
			//	var oFilterVName = new Filter("VENDNAME", FilterOperator.Contains, sValue);
			//	var oFilter = [];
			//	oFilter.push(oFilterVId);
			//	oFilter.push(oFilterVName);
			var oBinding = oEvent.getParameter("itemsBinding");
			oBinding.filter([oFilterVId]);
		},

		ChangeMade: function (oEvt) {
			this.changeMade = "X";
			this.changeWFActionButton();
		},

		handleCloseButton: function () {
			this._pPopover.close();
		},

		closeComments: function () {
			this.getView().byId("commentsId").close();
		},

		// SearchHelp Functions

		ChooseValueFromSearchHelp: function (oEvt) {

			this.loadDomainValue(oEvt);
		},

		// Retrive searchHelp Values from back-end
		loadDomainValue: function (evt) {
			var oSource = evt.getSource();
			this.filedValue = oSource.data().Field;
			this.oDialogTitle = oSource.data().Title;
			//var fieldname = "ZZ_RIG_CD";
			var oDataModel = this.getView().getModel("VendorService");
			this.busyDialog.open();
			var aFilters = [new Filter("Field", FilterOperator.EQ, this.filedValue)];

			if (this.filedValue === "WLLCLASS") {
				aFilters.push(new Filter("Rqtype", FilterOperator.EQ, this.itemDetails.Rqtype));
			}

			oDataModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				/*	urlParameters: {
						   "$skip":0,
						   "$Top":20
						},*/
				success: function (oData) {
					if (this.filedValue === "VENDOR" || this.filedValue === "WELL_NAME" || this.filedValue === "RIG_CODE" || this.filedValue ===
						"COPY_REF") {
						this.OpenTableSelectdialog(oData, this.filedValue);
					} else {
						if (!this.HeaderSearchHelp) {

							this.HeaderSearchHelp = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Header.SearchHelp", this);
						}

						oData = this.handleColumnData(oData, this.filedValue);
						var f4Model = new JSONModel(oData);
						this.HeaderSearchHelp.setModel(f4Model, "F4Models");
						this.HeaderSearchHelp.setTitle(this.oDialogTitle);
						//	this.getView().getModel("F4Models").setData(data);
						this.HeaderSearchHelp.open();

					}
					this.busyDialog.close();
					//		this.getView().getModel("F4Models").setProperty("/" + this.field, oData);
					/*	oData = oData.results;
						this.getView().getModel("F4Models").setProperty("/" + this.field, oData);
						this.busyDialog.close();*/
				}.bind(this),
				error: function (oResponse) {
					this.busyDialog.close();
					var msgs = this.getErrorMessages(oResponse);
				}.bind(this)
			});
		},

		OpenTableSelectdialog: function (oData, fieldValue) {

			if (!this.f4SearchHelp) {
				this.f4SearchHelp = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Header.f4Help", this);
			}

			oData = this.handleColumnData(oData, fieldValue);
			var f4Model = new JSONModel(oData);
			this.f4SearchHelp.setModel(f4Model, "F4Models");
			this.f4SearchHelp.setTitle(this.oDialogTitle);
			//	this.getView().getModel("F4Models").setData(data);
			this.f4SearchHelp.open();
		},

		onExeucte: function (evt) {
			var oDataModel = this.getView().getModel("VendorService");
			if (this.HeaderSearchHelp) {
				var oSearchHelpModel = this.HeaderSearchHelp.getModel("F4Models");
			} else if (this.f4SearchHelp) {
				var oSearchHelpModel = this.f4SearchHelp.getModel("F4Models");
			}

			var oTable = oSearchHelpModel.getData()['columns'];
			var aFilter = [new Filter("Field", FilterOperator.EQ, this.filedValue)];
			$.each(oTable, function (ind, obj) {
				if (obj['oValue']) {
					aFilter.push(new Filter(obj.field, FilterOperator.EQ, obj.oValue));
				}
			}.bind(this));
			//var aFilters = [new Filter("Field", FilterOperator.EQ, this.filedValue)];
			var max_hits = 50;
			if (oSearchHelpModel.getData()["dialog"]["maxHits"]) {
				max_hits = oSearchHelpModel.getData()["dialog"]["maxHits"];
			} else {
				max_hits = 50;;
			}
			oDataModel.read("/F4SearchHelpSet", {
				filters: aFilter,
				urlParameters: {
					MAX_HITS: max_hits,

					/* "$skip":0,
					 "$Top":20*/
				},
				success: function (oData) {
					oData = this.handleColumnData(oData, this.filedValue);
					oSearchHelpModel.setData(oData);
					oSearchHelpModel.refresh();
				}.bind(this),
				error: function () {}
			});
		},

		//Set the value of the input field from search help		
		onDrssSearchSelected: function (evt) {
			var selectedItem = evt.getSource().getBindingContext("F4Models").getObject();
			var DrssNo = selectedItem.col1;
			var Mjahr = selectedItem.col2;
			this.itemDetails.DrssNo = "0000000000";

			this.isConfigRequired = false;
			this.getRequestData(DrssNo, Mjahr, this.itemDetails.Rqtype);
			//this.byId("tbl_drss").removeSelections();
		},

		notificationPress: function (oEvent, iDelete) {

			if (iDelete) {
				var oButton = oEvent;
			} else {
				var oButton = oEvent.getSource();
			}
			var oView = controller.getView();
			if (!this.itemCommentsPop) {
				this.itemCommentsPop = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.Comments", this);
				oView.addDependent(this.itemCommentsPop);
			}
			if (iDelete) {
				var data = oButton.getParent().getParent().getBindingContext("itemsModel").getObject();
				var sPath = oButton.getParent().getParent().getBindingContext("itemsModel").getPath();
			} else {
				var data = oButton.getParent().getBindingContext("itemsModel").getObject();
				var sPath = oButton.getParent().getBindingContext("itemsModel").getPath();
			}

			oPreviousComments = data.EText;

			var oPageModel = this.getView().getModel("itemsModel").getData();
			if (oPageModel['HeaderToWfActionNav'].length > 0) {
				this.itemCommentsPop.setContentWidth("50%");
			} else {
				this.itemCommentsPop.setContentWidth("25%");
			}
			//data['EText'] = true;
			this.onOpenComment(data);
			controller.oSelCommentPath = sPath;
			//  data.VendorAdd = 'X';
			var model = new JSONModel(data);
			this.itemCommentsPop.setModel(model, "itemsComments");
			this.itemCommentsPop.open();
		},

		OnAddCmdtoField: function () {

			if (typeof controller.oSelCommentPath !== "undefined") {
				var oObject = this.getView().getModel("itemsModel").getProperty(controller.oSelCommentPath);
				//   var oField = oObject["ItemToCommNav"][0]['Text'];
				var oComment = Core.byId("ItemCommentsTxt").getValue();
				//oTxtAreaIpt = inputfield + 
				var userInfoModel = controller.getModel("UserInfoModel").getData();
				var itemsNav = this.getView().getModel("itemsModel").getData()['HeaderToItemNav'];
				$.each(itemsNav, function (ind, obj) {
					var oField = obj['ItemToCommNav'][0]['Text'];
					if (typeof obj['EText'] !== "undefined" && obj['EText'] !== "") {
						if (oField === "") {
							oField = obj['EText'] + "/b1" + new Date().toLocaleString() + "/b1" + userInfoModel['VenUserId'];
						} else {
							oField = oField + " /n1" + obj['EText'] + "/b1" + new Date().toLocaleString() + "/b1" + userInfoModel['VenUserId'];
						}
						obj['ItemToCommNav'][0]['Text'] = oField;

						delete obj['EText'];
						delete obj['SplArray'];
					}
				}.bind(this));
			}
			// Remove these two fields before submit
			//	delete oObject['EText'];
			//delete oObject['SplArray'];
			//oObject["ItemToCommNav"][0]['Text'] = oField;

			this.getView().getModel("itemsModel").refresh();

		},

		onOpenComment: function (data) {

			//var oComment = Core.byId("ItemCommentsTxt").getValue();
			var oSelObject = data["ItemToCommNav"][0];
			var oField = oSelObject['Text'];
			data['SplArray'] = [];
			var oSplittedArray = [];
			if (oField.match(/n1/g) !== null) {
				var oArr = oField.split('/n1');
				for (var obj in oArr) {
					var oInnerArr = oArr[obj].split('/b');
					var nObj = {
						Text: oInnerArr[0],
						CreatedDateTime: oInnerArr[1],
						CreatedBy: oInnerArr[2]
					}
					oSplittedArray.push(nObj);
				}
				data['SplArray'] = oSplittedArray;
			} else if (oField.match(/b1/g) !== null) {
				var oInnerArr = oField.split('/b1');
				var nObj = {
					Text: oInnerArr[0],
					CreatedDateTime: oInnerArr[1],
					CreatedBy: oInnerArr[2]
				}
				oSplittedArray.push(nObj);
				data['SplArray'] = oSplittedArray;
			}
			this.getView().getModel().refresh();
		},

		/*		
				removeEmptyText :function(data, sPath){
					var oItemModel =  this.getView().getModel('itemsModel');
					if(data['ItemToCommNav'].length > 0){
						for(var i= data['ItemToCommNav'].length -1 ; i>=0;i--){
							if(data['ItemToCommNav'][i]['Text'] === ""){
								oItemModel.getProperty(sPath)['ItemToCommNav'].splice(i, 1);
							}
						}
					}
					this.getView().getModel("itemsModel").refresh();
					//return data;
				},
				*/
		/*onAddCommentPress:function(evt){
			
	       // sap.ui.getCore().byId("idTimeline").setVisible(false);
			sap.ui.getCore().byId("ItemCommentsTxt").setVisible(true);
			//this.getView().byId("ItemCommentsTxt").setVisible(true);
			var aCommentModel = this.itemCommentsPop.getModel("itemsComments");
			var aCommentsList = aCommentModel.getData()['ItemToCommNav'];
			var getYear = new Date().getFullYear();
			var obj ={ Text:sap.ui.getCore().byId("ItemCommentsTxt").getValue(),
					   Docno: aCommentModel.getData()['Docno'],
					   Mjahr: getYear.toString(),
					   Ntdid: "ITM",
					   Tdid: "ZTXT",
					   Tdobject: "ZPDRSS",
					   Txttype: "I",
					   Zeile: aCommentModel.getData()['Zeile'] };
			aCommentsList.push(obj);
			aCommentModel.refresh();
			var ItemCommentsTxt = Core.byId("ItemCommentsTxt");
			var oLen = aCommentsList.length-1;
			var sPath = "/ItemToCommNav/"+ oLen.toString();
			ItemCommentsTxt.bindElement({ path: sPath, model: "itemsComments" });
			sap.ui.getCore().byId("ItemCommentsTxt").setValue("");
			//evt.getSource().setVisible(true);
			//ItemCommentsTxt.setVisible(false);
		},*/

		// Adding the comments color
		ItemCommentColor: function () {
			var oItemsTable = this.getView().byId("ReferenceTable").getItems();
			if (oItemsTable.length > 0) {
				//var aTableItems = oItemsTable[0].getCells()[8].setColor('#FF0000');
				for (var obj in oItemsTable) {
					var itemContext = oItemsTable[obj].getBindingContext("itemsModel").getObject();
					if (itemContext['ItemToCommNav'].length > 0) {
						var oChkValue = itemContext['ItemToCommNav'][0].Text;
						var oCell = oItemsTable[obj].getCells()[9];
						oCell.setColor('#000000');
						if (oChkValue !== "" || (typeof itemContext['EText'] !== "undefined" && itemContext['EText'] !== "")) {
							oCell.setColor('#59ed3f');
						}
					}
				}
			}
		},

		onLineItemChange: function (evt) {

			var oSource = evt.getSource().getValue();
		},

		/*onClosePopUp :function(evt){
			this.ItemCommentColor();
			var oSelTblObj = this.getView().getModel("itemsModel").getProperty(controller.oSelCommentPath);
			if(oSelTblObj.VendorAdd === ""){
			   oSelTblObj.DelInd = "V";
			}
			evt.getSource().getParent().close();
		},*/

		onSavePopUp: function (evt) {
			this.ItemCommentColor();

			var oSelTblObj = this.getView().getModel("itemsModel").getProperty(controller.oSelCommentPath);
			if (oSelTblObj.VendorAdd === "") {
				oSelTblObj.DelInd = "V";
			}

			evt.getSource().getParent().close();
		},
		onClosePopUp: function (evt) {
			//Do not save the additional comments, restore it to previous comments. 
			evt.getSource().getParent().getModel("itemsComments").setProperty("/EText", oPreviousComments);
			evt.getSource().getParent().close();

		},

		//Fired when SegmentedButton (item comments) is clicked
		onItemCommentsPress: function (oEvent) {
			var ItemCommentsTxt = sap.ui.getCore().byId("ItemCommentsTxt");
			var sPath = oEvent.getParameter("item").getBindingContext("itemsComments").getPath();
			ItemCommentsTxt.bindElement({
				path: sPath,
				model: "itemsComments"
			});
		},

		//Item Attachment
		attachPress: function (oEvent) {
			var oButton = oEvent.getSource();
			if (!this._pPopover) {
				this._pPopover = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.Attachments", this);
				this.getView().addDependent(this._pPopover)
			}
			this.selectedContext = oButton.getParent()._getPropertiesToPropagate()['oBindingContexts']['itemsModel'].getObject();
			controller.selectedContext = this.selectedContext;
			var oItemFileUpload = sap.ui.getCore().byId("UploadCollection");
			var oItemsModel = this.getView().getModel("itemsModel")['Rqstat'];
			if (oItemsModel === "INIT") {
				oItemFileUpload.setUploadEnabled(true);
			} else {
				oItemFileUpload.setUploadEnabled(false);
			}
			this._pPopover.openBy(oButton);
			this.oFilterItemsAttach();
		},

		oFilterItemsAttach: function () {
			//this.byId("uploadCollectionJobLog").data({ItemValue:controller.FormCode}) ;
			var oBinding = Core.byId("UploadCollection").getBinding("items");
			if (oBinding) {
				//oBinding.filter(null);
				oBinding.filter([
					new sap.ui.model.Filter("Category", "EQ", "02"),
					new sap.ui.model.Filter("Zeile", "EQ", controller.selectedContext['Zeile'])
				]);
			}
			oBinding.refresh();
		},

		/*	
		SplitAttachmentItems:function(evt){
			var oSource =  evt.getSource();
			var oContexts = oSource.getParent()._getPropertiesToPropagate()['oBindingContexts'];
			 if (oContexts){
				var oSelectedContextModel = oContexts['itemsModel'].getObject();
  				var oData = [];
				 for (var obj in  this.Attachments){
					  if (oSelectedContextModel.Zeile === this.Attachments[obj].Zeile){
						oData.push(this.Attachments[obj]);
					}
				}
			}
			 return oData;
		},*/

		onCheck: function () {
			var errorList = this.validationControlsByFieldGroupId();
			this.instantiateErrorMessageModel(errorList);
			this.createMessagePopoverModel();

			/*if(errorList.length > 0){
				this.instantiateErrorMessageModel(errorList);
					this.createMessagePopoverModel();
			}
			else{
				this.createMessagePopoverModel();
			}*/
		},

		onServiceMasterFilter: function (evt) {
			var oTable = Core.byId("serviceSelectId");
			var oBinding = oTable.getBinding("items");
			oTable.expandToLevel(100);
			var aFilters = [];
			var sQuery = evt.getSource().getValue();

			const aWords = sQuery.split(" ");
			var sWord = "";
			for (var x = 0; x < aWords.length; x++) {
				sWord = aWords[x];
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord.toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord.toUpperCase()));
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord[0].toUpperCase() + sWord.substr(1)
					.toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("ServLtext", sap.ui.model.FilterOperator.Contains, sWord));
			}
			var oFilter = [new sap.ui.model.Filter(aFilters, false)];
			oBinding.filter(oFilter);
		},

		setViewMode: function (flag) {
			var configModel = this.getView().getModel("configModel");
			var tempOb = {
				rigno: ["/Editable"],
				prrty: ["/Editable"],
				rqddt: ["/Editable"],
				prrtyreason: ["/Editable"],
				rqdtm: ["/Editable"],
				estedt: ["/Editable"],
				wellnm: ["/Editable"],
				wcposid: ["/Editable"],
				wlltype: ["/Editable"],
				lifnr: ["/Editable"],
				shoptyp: ["/Editable"],
				phone: ["/Editable"],
				aufnr: ["/Editable"],
				ovrcc: ["/Editable"],
				estimate: ["/Editable"],
				estmtyp: ["/Editable"],
				notification: ["/Editable"],
				craftno1: ["/Editable"],
				craftno2: ["/Editable"],
				certifier: ["/Editable"],
				ident: ["/Editable"],
				deliervia: ["/Editable"],
				wllclass: ["/Editable"],
				actedt: ["/Editable"],
				area: ["/Editable"],
				distancedh: ["/Editable"],
				taxireason: ["/Editable"],
				vehtype: ["/Editable"],
				taxiroute: ["/Editable"],
				taxitrip: ["/Editable"],
				driver: ["/Editable"],
				drivernumber: ["/Editable"],
				doornumber: ["/Editable"],
				platenumber: ["/Editable"],
				comments: ["/Editable"],
				badgeno: ["/Editable"],
				maktxo: ["/Editable"],
				ServLtext: ["/Editable"],
				trdrvmobile: ["/Editable"],
				pickuplocation: ["/Editable"],
				dropofflocation: ["/Editable"],
				contract: ["/Editable"],
				flightdetails: ["/Editable"],
				hdtxt: ["/Editable"],
				addpassengerbtn: ["/Visible"],
				deletepassengerbtn: ["/Visible"],
				additembtn_ref: ["/Visible"],
				deleteitembtn_ref: ["/Visible"],
				referencetab: ['/Editable'],
				commentstab: ['/Editable']
			};

			for (var key in tempOb) {
				var prop = "/" + key + tempOb[key][0];
				configModel.setProperty(prop, flag);
			}
		},

		//Validate form fields
		validationControlsByFieldGroupId: function () {
			var oControls = this.getView().getControlsByFieldGroupId("Mandatory");
			var errorList = [];

			var check = true;
			for (var i = 0; i < oControls.length; i++) {
				var control = oControls[i];
				//Validate dropdown
				if (control.constructor === sap.m.Select) {
					if (control.getSelectedKey().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						control.setValueState("None");
						check = check && true;
					}
				}
				//Validate Input field
				if (control.constructor === sap.m.Input) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						check = check && true;
						control.setValueState("None");
					}
				}
				if (control.constructor === sap.m.TextArea) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {

						check = check && true;
						control.setValueState("None");
					}
				}
				//Validate date picker control
				if (control.constructor === sap.m.DatePicker) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						this.datePickerValidation(control);
					}
					/*else{
						check = check && true;
						control.setValueState("None");
					}*/
				}
				//Validate time picker control
				if (control.constructor === sap.m.TimePicker) {
					if (control.getValue().length === 0) {
						check = check && false;
						control.setValueState("Error");
						errorList.push({
							severity: "Error",
							message: control.getValueStateText(),
							description: control.getValueStateText()
						});
					} else {
						check = check && true;
						control.setValueState("None");
					}
				}
			}
			return errorList;
		},

		// Date picker validation
		datePickerValidation: function (datePicker) {
			var dateValue = datePicker.get
		},

		onBeforeUploadStarts: function (oEvent) {
			//var oUploadCollection = oEvent.getSource();
			var oDataModel = this.getView().getModel("VendorService");

			this.AttachLevel = oEvent.getSource().data().Field;
			// this.reqItems['VEND_NAME'] = this.reqItems['VEND_NAME'].slice(0,29);
			/*	var oFileTypeSpl =  oEvent.getParameter('fileName').split('.')[1];
				oEvent.getParameter('fileName') = oEvent.getParameter('fileName').slice(0,29)+"."+oFileTypeSpl; */

			if (this.AttachLevel === "ItemAttach") {
				this.Catog = "02";
				this.itemValue = "0010";

				var oItem_Header = new sap.m.UploadCollectionParameter({
					name: "item",
					value: this.itemValue
				});

			} else if (this.AttachLevel === "JobLogAttach") {
				this.Catog = "03"
				this.itemValue = this.byId("uploadCollectionJobLog").data().ItemValue;
				var oItem_Header = new sap.m.UploadCollectionParameter({
					name: "Form",
					value: this.itemValue
				});
			} else {
				this.Catog = "01"
				this.itemValue = "0000";
				var oItem_Header = new sap.m.UploadCollectionParameter({
					name: "item",
					value: this.itemValue
				});
			}

			oDataModel.refreshSecurityToken();
			var sSecurityToken = oDataModel.getSecurityToken();

			var oSlugHeader = new sap.m.UploadCollectionParameter({
				name: "SLUG",
				value: oEvent.getParameter("fileName")
			});

			var oSecurityToken = new sap.m.UploadCollectionParameter({
				name: "X-CSRF-Token",
				value: sSecurityToken
			});

			var oReqid_Header = new sap.m.UploadCollectionParameter({
				name: "REQID",
				value: this.getDocno()
			});

			var oCate_Header = new sap.m.UploadCollectionParameter({
				name: "CATE",
				value: this.Catog
			});

			var oYear_Header = new sap.m.UploadCollectionParameter({
				name: "YEAR",
				value: this.getYear()
			});

			oEvent.getParameters().addHeaderParameter(oSlugHeader);
			oEvent.getParameters().addHeaderParameter(oSecurityToken);
			oEvent.getParameters().addHeaderParameter(oReqid_Header);
			oEvent.getParameters().addHeaderParameter(oCate_Header);
			oEvent.getParameters().addHeaderParameter(oYear_Header);
			oEvent.getParameters().addHeaderParameter(oItem_Header);

			//	oUploadCollection.setBusy(true);
		},

		getReqType: function () {
			return this.itemDetails.Rqtype;
		},

		//returen the document no which is maintained in the model
		getDocno: function () {
			return this.itemDetails.DrssNo;
		},

		//returen year
		getYear: function () {
			return this.itemDetails.Mjahr;
		},

		//Event is fired when the value of the file path has been changed.
		onUploadChange: function (evt) {
			var oFileUploader = evt.getSource();
			var oDataModel = this.getView().getModel("VendorService");
			var sServiceUrl = oDataModel.sServiceUrl;
			var sUrl = sServiceUrl + "/FileSet('" + oFileUploader.getValue() + "')";
			//	    	var sUrl = sServiceUrl + "/FileSet/";
			this.busyDialog.open();
			oDataModel.refreshSecurityToken();
			var sSecurityToken = oDataModel.getSecurityToken();
			oFileUploader.removeAllHeaderParameters();
			oFileUploader.setUploadUrl(sUrl);
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: oFileUploader.getValue()
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "X-CSRF-Token",
				value: sSecurityToken
			}));

			/*oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "Content-Type",
					value: evt.getParameter("files")[0].type 
	    	  }));*/

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "CATE",
				value: this.Catog
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "REQID",
				value: this.getDocno().toString()
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "YEAR",
				value: this.getYear().toString()
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "item",
				value: oFileUploader.data().item.toString()
			}));
			oFileUploader.upload();
			oFileUploader.clear();
		},

		//Event is fired as soon as the upload request is completed (either successful or unsuccessful)
		onUploadComplete: function (evt) {

			// this._OCReqData(this.itemDetails.DrssNo,this.itemDetails.Mjahr,this.itemDetails.Rqtype,this.itemDetails.SrvtypeCode);
			// var oModel = this.getView().getModel("VendorService");
			var oModel = this.getView().getModel("oReqHeaderSetModel");
			var docNo = this.getDocno();
			var year = this.getYear();
			this.oSets = "HeaderToAttNav," + "HeaderToItemNav";
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			//   var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "')";
			var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + this.itemDetails.Rqtype + "')";
			oModel.read(params, {
				urlParameters: {
					"$expand": this.oSets
				},
				success: function (oData) {
					oData.HeaderToAttNav = oData.HeaderToAttNav.results;
					var oItemsModel = this.getView().getModel("itemsModel");
					oItemsModel.setData(oData);
					//Data.HeaderToAttNav = oData.HeaderToAttNav.results;
					//oData.HeaderToAttNav = this.prepareAttachments(oData.HeaderToAttNav.results);

					//if(this.AttachLevel === "ItemAttach"){
					// this.getView().getModel("itemsAttachment").refresh();

					// this.attachPress(evt);
					//}
					//	this.prepareData(oData);
					//    this.SelectPriorities();
					//    this.SelectHoleSize();
					//    this.SelectRadius();
					// busyDialog.close();

					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
		},

		// UOM Search Dialog
		UOMSearch: function (evt) {
			var oBinding = evt.getSource().getBinding("items");
			var oSearchValue = evt.getParameter("value");
			var lowerCase = oSearchValue.toLowerCase();
			var upperCase = oSearchValue.toUpperCase();
			var asIS = oSearchValue;
			var aFilters = [
				new sap.ui.model.Filter("Value1", sap.ui.model.FilterOperator.Contains, lowerCase),
				new sap.ui.model.Filter("Value1", sap.ui.model.FilterOperator.Contains, upperCase),
				new sap.ui.model.Filter("Value1", sap.ui.model.FilterOperator.Contains, asIS),
				new sap.ui.model.Filter("Descr1", sap.ui.model.FilterOperator.Contains, lowerCase),
				new sap.ui.model.Filter("Descr1", sap.ui.model.FilterOperator.Contains, upperCase),
				new sap.ui.model.Filter("Descr1", sap.ui.model.FilterOperator.Contains, asIS)
			];
			var oFilter = [new sap.ui.model.Filter(aFilters, false)];
			oBinding.filter(oFilter);
		},

		onFilePressed: function (evt) {
			var source = evt.getSource();
			var sPath = source.getParent().getBindingContextPath();
			var oModel = source.getParent().getParent().getBinding("items").getModel();

			var dataObject = oModel.getProperty(sPath);
			var sServiceUrl = this.getView().getModel("VendorService").sServiceUrl;
			var Brelguid = dataObject.Brelguid.replaceAll("-", "");
			var url = sServiceUrl + "/FileSet('" + Brelguid + "')/$value";
			sap.m.URLHelper.redirect(url, true);
		},

		oCurrentYear: function () {
			var year = new Date();
			return year.getFullYear();
		},

		onFileDeleted: function (oEvent) {
			var docId = oEvent.getParameter("documentId");
			var oModel = this.getView().getModel("VendorService");
			oModel.read("/DeleteAttachmentSet('" + docId + "')", {

				success: function (oData) {
					// this.onUploadComplete();
					this.onUploadCompleteJob();

					this.getView().setBusy(false);
				}.bind(this),
				error: function (error) {
					this.getView().setBusy(false);
					//var msgs = this.getErrorMessages(error);
					this.onMessageHandle(error)
						//this.instantiateErrorMessageModel(msgs);
						//this.createMessagePopoverModel();
				}.bind(this)
			});

			/*      var oItem = oEvent.getParameter('item');
			     if (oItem){
				      if (oItem.getBindingContext("itemsAttachment")){
					     this.AttachLevel = "ItemAttach";
				       }else{
					     this.AttachLevel  = "HeaderAttach";
			         }
			     }
				var oModel = this.getView().getModel("VendorService");
				var docId = oEvent.getParameter("documentId");
				var year = this.oCurrentYear();;
				oModel.remove("/FileSet(Brelguid='" + docId + "')", {
					success: function (oData) {
						this.onUploadComplete();
					}.bind(this),
					error: function (error) {
						this.onMessageHandle(error)
					}.bind(this)
				});*/

		},

		/*    onFileDeleted: function (oEvent) {
			      var oItem = oEvent.getParameter('item');
			     if (oItem){
				      if (oItem.getBindingContext("itemsAttachment")){
					     this.AttachLevel = "ItemAttach";
				       }else{
					     this.AttachLevel  = "HeaderAttach";
			         }
			     }
				var oModel = this.getView().getModel("VendorService");
				var docId = oEvent.getParameter("documentId");
				var year = this.oCurrentYear();;
				oModel.remove("/FileSet(Brelguid='" + docId + "')", {
					success: function (oData) {
						this.onUploadComplete();
					}.bind(this),
					error: function (error) {
						this.onMessageHandle(error)
					}.bind(this)
				});
			},*/

		onMessageHandle: function (error) {
			if (JSON.parse(error.responseText)['error']['innererror']['errordetails'].length > 0) {
				MessageBox.error(JSON.parse(error.responseText)['error']['innererror']['errordetails'][0]['message']);
			}
		},

		//Delete a passenger
		onDeleteLineItem: function (evt) {
			this.lineItemDel = evt.getSource();
			var message = evt.getSource().data().LineItem;
			MessageBox.warning("Are you sure you want to delete the " + message + "?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						var lineItem = this.lineItemDel;

						var oTable = lineItem.getParent().getParent();
						var property = oTable.getBinding("items").getPath();
						var itemsList = this.getView().getModel("taxiModel").getProperty(property);
						var item = lineItem.getParent();
						var splittedIndex = item.getBindingContextPath().split("/");
						var index = parseInt(splittedIndex[splittedIndex.length - 1]);
						itemsList.splice(index, 1);
						this.getView().getModel("taxiModel").refresh(true);
						delete this.PassenerDel;
					}
				}.bind(this)
			});
		},

		onPrintPress: function () {

			// var oDataModel = this.getView().getModel("VendorService");
			var oDataModel = this.getView().getModel("oReqHeaderSetModel");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: this.getDocno(),
				Year: this.getYear(),
				FormType: 'AC',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		copyFromRef: function () {

			var that = this;
			if (!this._pPopoverCopyFrom) {
				that._pPopoverCopyFrom = new sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.OC.Items.CopyFromRef", that);
			}

			that._pPopoverCopyFrom.open();

		},

		populateFields: function (sId, oContext) {

			var oField = this._Dialog.getModel("field_list").getObject(oContext + "/");

			//// console.log(oField.fieldType);
			if (oField.fieldType === "Input") {

				var oInput = new sap.m.Input({
					value: "",
					showValueHelp: oField.shAvail,
					valueHelpRequest: this.getF4Value
				});
				oInput.setModel(this._Dialog.getModel("field_list"));
				oInput.setModel(this.model, "oData");
				oInput.bindValue(oContext + "/value");
				oInput.addCustomData(new sap.ui.core.CustomData({
					key: "SHLPNAME",
					value: oField.shName
				}));
				oInput.addCustomData(new sap.ui.core.CustomData({
					key: "SHLPTYPE",
					value: oField.shType
				}));
				oInput.addCustomData(new sap.ui.core.CustomData({
					key: "Fieldname",
					value: oField.shField
				}));

				oInput.attachBrowserEvent("keypress", function (e) {

					if (e.which === 13) {
						//// console.log("Enter Pressed");
						this.oViewModel.setProperty("/fieldsExpanded", false);
						this.onExeucte();
					}
				}.bind(this));

				return new sap.ui.layout.form.FormElement({
					label: oField.fieldLabel,
					fields: [oInput]
				});

			} else if (oField.fieldType === "Date") {
				var oInput = new sap.m.DatePicker({
					value: "",
					valueFormat: "yyyyMMdd"
				});
				oInput.setModel(this._Dialog.getModel("field_list"));
				oInput.bindValue(oContext + "/value");

				return new sap.ui.layout.form.FormElement({
					label: oField.fieldLabel,
					fields: [oInput]
				});

			} else if (oField.fieldType === "Time") {
				var oInput = new sap.m.TimePicker({
					value: "",
					valueFormat: "HHmmss"
				});
				oInput.setModel(this._Dialog.getModel("field_list"));
				oInput.bindValue(oContext + "/value");

				return new sap.ui.layout.form.FormElement({
					label: oField.fieldLabel,
					fields: [oInput]
				});
			}
		},

		onPrintPress: function () {

			// var oDataModel = this.getView().getModel("VendorService");
			var oDataModel = this.getView().getModel("oReqHeaderSetModel");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: this.getDocno(),
				Year: this.getYear(),
				FormType: 'RQ',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		onPrintACPress: function () {;
			// var oDataModel = this.getView().getModel("VendorService");
			var oDataModel = this.getView().getModel("oReqHeaderSetModel");
			var sRead = oDataModel.createKey("/RequestFormSet", {
				Docno: this.getDocno(),
				Year: this.getYear(),
				FormType: 'AC',
				LogId: ''
			}) + "/$value";
			sRead = oDataModel.sServiceUrl + sRead;
			window.open(sRead);
		},

		//Show the dialog for DRSS
		onCopyOldRef: function () {
			if (!this.DRSSDialog) {
				this.DRSSDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.f4.DRSSSearchDialog", this);
				//	this.getView().addDependent(this.DRSSDialog);	
			}
			var data = {
				drss: {
					Field: 'COPY_REF',
					Maxhit: '50',
					Descr1: '',
					Descr2: '',
					Descr3: '',
					Descr4: '',
					Referance: '',
					Referance1: ''
				}
			};
			var model = new JSONModel(data);
			this.DRSSDialog.setModel(model, "SearchModel");
			this.DRSSDialog.open();
		},

		//  Copy from Drss

		onDRSSExeucte: function (evt) {
			this.getView().getModel("SearchModel").setProperty("/drss/Referance1", this.itemDetails.Rqtype);
			var searchParams = this.getView().getModel("SearchModel").getProperty("/drss");
			this.field = searchParams.Field
			this.loadDomainF4Values(searchParams);
		},

		onWFGraphOC: function () {
			//	this.getView().getModel("WFGraphModel")
			var model = new JSONModel();
			this.getView().setModel(model, "WFGraphModel");
			var oModel = this.getView().getModel("itemsModel").getProperty("/HeaderToWfLogNav");
			this.onWFGraph(oModel);
		},

		onCloseWF: function () {
			this.WFGraphDialog.close();
			this.WFGraphDialog.destroy();
			delete this.WFGraphDialog;
		},

		changeWFActionButton: function () {

			var wfButtons = this.getView().getModel("itemsModel").getProperty("/HeaderToWfActionNav");
			if (wfButtons.length > 0) {
				for (var i = wfButtons.length - 1; i >= 0; i--) {
					if (wfButtons[i].Actlabel === "Accept") {
						this.getView().getModel("itemsModel").getData()['HeaderToWfActionNav'].splice(i, 1);
					}

					if (wfButtons[i].Actlabel === "Reject") {
						this.getView().getModel("itemsModel").getData()['HeaderToWfActionNav'].splice(i, 1);
					}

					if (wfButtons[i].Actlabel === "Return") {
						this.getView().getModel("itemsModel").getData()['HeaderToWfActionNav'].splice(i, 1);
					}
				}
			}
			this.getView().getModel("itemsModel").refresh();
		},
		onRejectSelection: function (evt) {

			//var oSelectedItem = evt.getParameter("selectedItem").getBindingContext("mRejectedReason").getObject();
			var oSelectedItem = evt.getParameter('value');
			if (oSelectedItem === 'Other') {
				this.getView().byId("commentInput").setVisible(true);
				this.getView().byId("commentLabel").setVisible(true);
				this.dRejectedReason.getModel('mRejectedReason').refresh();
				return;
			} else {
				this.getView().byId("commentInput").setVisible(false);
				this.getView().byId("commentLabel").setVisible(false);
			}
			this.getView().byId("selectinput").setValueState("None");
			this.sSelectedReason = false;
		},

		onSelectLiveChange: function (evt) {
			var oSelectedKey = evt.getSource().getSelectedKey();
			if (oSelectedKey === '') {
				evt.getSource().setValueState("Error");
			} else {
				evt.getSource().setValueState("None");
			}
		},

		onSubReason: function () {

			var oControl = this.getView().byId("selectinput");
			var oCommentField = this.getView().byId("commentInput");
			if (oControl.getSelectedKey() == "" || oControl.getSelectedKey() === "Other") {
				if (oControl.getSelectedKey() == "Other") {

					if (oCommentField.getValue() === "") {
						sap.m.MessageBox.error("Please Enter reason!");
						oCommentField.setValueState("Error");
						return;
					} else {
						oCommentField.setValueState("None");
					}
				}
				if (oControl.getSelectedKey() == "") {
					sap.m.MessageBox.error("Please select a Reason");
					oControl.setValueState('Error');
					return;
				} else {
					oControl.setValueState('None');
				}

			} else {

				oCommentField.setValueState('None');
				oControl.setValueState('None');
			}

			if (oControl.getSelectedKey() == "Other") {
				this.oRejReasonText = this.getView().byId("commentInput").getValue();
			} else {
				this.oRejReasonText = oControl.getSelectedKey();
			}

			this.oSeletedReason = "";
			this.sSelectedReason = false;
			this.oSeletedReason = this.getView().byId("commentInput").getValue();
			this.onWFAction();
			this.dRejectedReason.close();

		},

		// On vendor refrence live chaneg
		onVendorRefNum: function (evt) {
			var getSource = evt.getParameter('value');
			this.changeMade = "";
			if (getSource !== "") {
				this.changeMade = "X";
				//this.changeWFActionButton();
			} else {
				//this.changeWFActionButton();
			}

		},

		// On rejection Reason
		_onRejectionReason: function (btnText) {
			var oPageModel = this.getView().getModel("itemsModel").getData();
			var oModel = this.getView().getModel("oDataModel");
			if (btnText === "Reject") {
				var oReasonType = "REJ";
			} else {
				var oReasonType = "RET";
			}
			this.busyDialog.open();
			var aFilters = [];
			//  if(!this.dRejectedReason){
			aFilters.push(new Filter("Field", FilterOperator.EQ, "REJECT_RES"));
			aFilters.push(new Filter("Referance", FilterOperator.EQ, oReasonType));
			aFilters.push(new Filter("Referance1", FilterOperator.EQ, oPageModel['Srvtyp']));
			aFilters.push(new Filter("Referance2", FilterOperator.EQ, oPageModel['Location']));
			oModel.read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					if (!this.dRejectedReason) {
						this.dRejectedReason = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.f4.RejectionReasonDialog",
							this);
						this.getView().addDependent(this.dRejectedReason);
					}

					oData['title'] = btnText;
					oData.results.push({
						Descr1: "Other"
					})
					var model = new JSONModel(oData);
					this.dRejectedReason.setModel(model, "mRejectedReason");
					this.dRejectedReason.getModel('mRejectedReason').setSizeLimit(oData.results.length);
					this.dRejectedReason.open();
					this.getView().byId("commentInput").setVisible(false);
					this.getView().byId("commentLabel").setVisible(false);
					this.getView().byId("commentInput").setValue("");
					this.getView().byId("selectinput").setSelectedKey('');
					this.getView().byId("selectinput").setValueState('None');
					this.getView().byId("selectinput").setValueState('None');
					this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.busyDialog.open();
				}.bind(this)
			});

			//  }

			/* else {
	           
	           this.getView().byId("commentInput").setVisible(false);
               this.getView().byId("commentLabel").setVisible(false);
	           this.getView().byId("commentInput").setValue("");
               this.getView().byId("selectinput").setSelectedKey('');
	           this.dRejectedReason.open();
           }*/
		},
		onClose: function (evt) {
			this.sSelectedReason = true;
			evt.getSource().getParent().close();
		},

		_AddedByVendorsItems: function (items) {
			$.each(items, function (ind, obj) {
				if (obj['VendorAdd'] === "X1") {
					obj['VendorAdd'] = "X";
				}
			});
			return items;
		},

		onWFAction: function (oEvent) {
			//var oActionItems = oEvent.getSource().getBindingContext("itemsModel").getProperty(oEvent.getSource().getBindingContext("itemsModel").getPath());
			var oPgData = this.getView().getModel("itemsModel").getData();
			var ReqItems = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var ReqItems = this._AddedByVendorsItems(ReqItems);
			var length = ReqItems.length;
			this.serviceAvailed = false;
			for (var i = 0; i < length; i++) {
				if (ReqItems[i].DelInd === "" && ReqItems[i].DispFilled === "X") {
					this.serviceAvailed = true;
				}
			}

			if (oEvent) {
				var oButtontext = oEvent.getSource().getText();
				this.sWrkflwBtnTxt = oButtontext;
			}

			if ((this.serviceAvailed === false) && (this.sWrkflwBtnTxt === "Revise")) {
				sap.m.MessageBox.error("Please fill atleast one service");
				return;
			}

			var oActionItems = {};
			$.each(oPgData['HeaderToWfActionNav'], function (ind, obj) {
				if (obj['Actlabel'] === this.sWrkflwBtnTxt) {
					oActionItems = obj;
				}

			}.bind(this))

			if (typeof oPgData !== "undefined") {
				var ReqItemsSet = oPgData.HeaderToItemNav;
			}

			if (this.sWrkflwBtnTxt !== "Reject") {

				if (this.changeMade === "X" && oPgData.Rqstat !== 'ACPT' && this.sWrkflwBtnTxt === "Revise" && (oActionItems.Action === "03" ||
						oActionItems.Action === "02")) {
					sap.m.MessageBox.error("Changes Made. Press Revise Button");
					return;
				}
				if (this.changeMade !== "X" && this.sWrkflwBtnTxt !== "Return" && oPgData.Rqstat !== 'ACPT') {
					sap.m.MessageBox.error("No changes Made. Please fill service");
					return;
				}

				for (var i = 0; i < length; i++) {
					if (ReqItems[i].ServLtext === "" && ReqItems[i].DelInd === "") {
						sap.m.MessageBox.error("Service Name cannot be empty");
						return;
					}

					/*if(ReqItems[i].Menge === ""){
						sap.m.MessageBox.error("Service Quantity cannot be empty");
						return;
					}*/

					if (ReqItems[i].Meins === "" && ReqItems[i].DelInd === "") {
						sap.m.MessageBox.error("Service UoM cannot be empty");
						return;
					}

					/*if (ReqItems[i]['PoNo'] ==="" && this.sWrkflwBtnTxt ==="Revise"){
						sap.m.MessageBox.error("Please select po line item!");
						return; 
					}*/
				}
				//sSelectedReason
			}

			this.sText = "";
			//Core.byId("submissionNote").setValue(sText);
			//var sAction = "Revise";
			this.OnAddCmdtoField();
			//TODO: change sAction based on the selected button

			//only if it is revise or reject
			if (oActionItems.RemarksReq === 'X' || this.sWrkflwBtnTxt === "Reject" || this.sWrkflwBtnTxt === "Return") {

				if ((this.sWrkflwBtnTxt === "Reject" || this.sWrkflwBtnTxt === "Return") && this.sSelectedReason) {
					this._onRejectionReason(this.sWrkflwBtnTxt);
					return;
				}

				if (this.sWrkflwBtnTxt !== "Reject" && this.sWrkflwBtnTxt !== "Return") {

					/*if (!this.oSubmitDialog) {*/
					this.oSubmitDialog = new Dialog({
						type: DialogType.Message,
						title: "Confirm",
						content: [
							new Label({
								//	text: "The request will be submitted as "+sAction+". Do you want to continue ?",
								text: "Do you want to continue ?",
								labelFor: "submissionNote"
							}),
							new sap.m.TextArea({
								width: "100%",
								value: "",
								growingMaxLines: 15,
								growing: true,
								placeholder: "Remarks (required)",
								liveChange: function (oEvent) {
									this.sText = oEvent.getParameter("value");
									this.oSubmitDialog.getBeginButton().setEnabled(this.sText.length > 0);
								}.bind(this)
							})
						],
						beginButton: new Button({
							type: ButtonType.Emphasized,
							text: "Submit",
							enabled: false,
							press: function () {

								var aPromise = [];
								aPromise.push(this.onSaveOC());
								Promise.all(aPromise).then(function (results) {
									var sText = this.sText;
									var ReqItemsSet = undefined;
									this.sSelectedReason = true;
									this.WFExecuteAction(this.DrssNo, this.Mjahr, oActionItems.Action, oActionItems.Stattype, sText, this.Gid,
										ReqItemsSet);

								}.bind(this));

								this.oSubmitDialog.close();
							}.bind(this)
						}),
						endButton: new Button({
							text: "Cancel",
							press: function () {
								this.sSelectedReason = true;
								this.oSubmitDialog.close();
							}.bind(this)
						})
					});
					this.oSubmitDialog.open();
				} else {
					//var sText = this.sText;
					var ReqItemsSet = undefined;
					this.sSelectedReason = true;
					this.WFExecuteAction(this.DrssNo, this.Mjahr, oActionItems.Action, oActionItems.Stattype, this.oRejReasonText, this.Gid,
						ReqItemsSet);

				}
				/*}*/

			} else {
				MessageBox.information("Do you want to continue ?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: "sapUiSizeCompact",
					onClose: function (sAction) {
						if (sAction === "YES") {
							var ReqItemsSet = undefined;
							this.sSelectedReason = true;
							this.WFExecuteAction(this.DrssNo, this.Mjahr, oActionItems.Action, oActionItems.Stattype, '', this.Gid, ReqItemsSet);
						} else {
							this.sSelectedReason = true;
						}
					}.bind(this)
				});
			}
		},

		isLetter: function (str) {
			return str.length === 1 && str.match(/[a-z]/i);
		},

		onDispItemPress: function (oEvent) {

			var ReqHeader = this.getView().getModel("itemsModel").getData();
			if (ReqHeader.EstSdt === null) {
				sap.m.MessageBox.error("Estimate Start Date cannot be empty");
				return;
			}

			if (ReqHeader.EstEdt === null) {
				sap.m.MessageBox.error("Estimate End Date cannot be empty");
				return;
			}

			var ReqItems = this.getView().getModel("itemsModel").getProperty("/HeaderToItemNav");
			var length = ReqItems.length;
			for (var i = 0; i < length; i++) {
				if (ReqItems[i].ServLtext === "" && ReqItems[i].DelInd == "") {
					sap.m.MessageBox.error("Service Name cannot be empty");
					return;
				}
				var serviceTextCondensed = (ReqItems[i].ServLtext).replaceAll(' ', '');
				if ((serviceTextCondensed.match(/^[a-zA-Z0-9]/)) || (serviceTextCondensed.length > 0)) {

				} else {
					if (ReqItems[i].DelInd === "") {
						sap.m.MessageBox.error("Service Name cannot be empty");
						return;
					}
				}

				/*if(ReqItems[i].Menge === ""){
					sap.m.MessageBox.error("Service Quantity cannot be empty");
					return;
				}*/

				if (ReqItems[i].Meins === "" && ReqItems[i].DelInd == "") {
					sap.m.MessageBox.error("Service UoM cannot be empty");
					return;
				}
			}
			var oItem = oEvent.getSource().getBindingContext('itemsModel').getObject();
			var oItemPath = oEvent.getSource().getBindingContext('itemsModel').sPath;
			this.oItemPath = oItemPath;

			var iPoNum = "";
			if (typeof oItem.PoNo !== "undefined" && typeof oItem.PoNo !== "") {
				var iPoNum = parseInt(oItem.PoNo);
			}
			var iPoItem = "";
			if (typeof oItem.PoItem !== "undefined" && typeof oItem.PoItem !== "") {
				var iPoItem = parseInt(oItem.PoItem);
			}

			var sLim_ind = oItem.LimitInd;
			var sCO_ind = oItem.CoInd;
			this.changeMade = "X";
			//this.changeWFActionButton();

			if ((iPoNum !== 0) && (iPoItem !== 0)) {

				if (typeof sCO_ind === "undefined" || sCO_ind === "") {
					if (typeof oItem.PoNo !== "undefined") {
						if (oItem.PoNo.substring(0, 2) === "66") {
							sCO_ind = "C";
						} else {
							sCO_ind = "PO";
						}
					} else {
						sCO_ind = "PO";
					}

				}

				if (typeof sLim_ind === "undefined" || sLim_ind === "") {
					sLim_ind = "0";
				}

				//this.getRouter().navTo("DispatchedServices", {objectId : this.getRequestId(), item: oItem.getProperty("Zeile"), EBELN: iPoNum, EBELP: iPoItem, lim_ind: sLim_ind, co_ind: sCO_ind  }, true);

				if (!this._DispServicesDialog) {
					this._DispServices = new DispatchedServicesSplit(this, "zdwo_nx_drss_ven.view.fragment.DispatchedServicesSplit");
				}

				/*   if (sap.ui.getCore().byId("treeMaster")){
	                sap.ui.getCore().byId("treeMaster").setBusy(true);
              }
*/
				this._DispServicesDialog = this._DispServices.createFragment(oItem.Docno, oItem.Zeile, iPoNum, iPoItem, "", sLim_ind, sCO_ind,
					oItem.ServiceId, oItem['Maktxo'], oItem);

				return;
			}
			var oModel = this.getView().getModel("VendorService");
			new POContractSelector(this.getView(), oModel, this, this.getView().getModel('itemsModel').getProperty("/Lifnr"),
				this.Rqtype,
				function (oPOItem) {

					iPoNum = oPOItem.EBELN;
					iPoItem = oPOItem.EBELP;

					// Update the selected PO/Line item of the request.
					oModel.callFunction("/SetPOForReqItm", {
						method: "GET",
						urlParameters: {
							Docno: oItem.Docno,
							Zeile: oItem.Zeile,
							PO: oPOItem.EBELN,
							PONO: oPOItem.EBELP

						},
						success: function (oData) {
							// me.hit_list.setData(oData)
							this.getView().getModel().setProperty(oItemPath + "/PoItem", oPOItem.EBELP);
							this.getView().getModel().setProperty(oItemPath + "/PoNo", oPOItem.EBELN);

							// // console.log(oData);
							var Contract = oPOItem.EBELN;
							var Rqtype = oItem.Rqtype;
							var that = this;
						}.bind(this),
						error: function (error) {

						}
					});
					// Navigate to Dispatched services.
					//this.getRouter().navTo("DispatchedServices", {objectId : this.getRequestId(), item: oItem.Zeile, EBELN: oPOItem.EBELN, EBELP: oPOItem.EBELP }, true);

					if (!this._DispServicesDialog) {
						this._DispServices = new DispatchedServicesSplit(this, "zdwo_nx_drss_ven.view.fragment.DispatchedServicesSplit");
					}

					if (oPOItem.CONTRACT === "undefined" || oPOItem.CONTRACT === "") {
						this._DispServicesDialog = this._DispServices.createFragment(oItem.Docno, oItem.Zeile, iPoNum, iPoItem, "", sLim_ind, sCO_ind,
							oItem['ServiceId'], oItem['Maktxo'], oItem);
					} else {
						this._DispServicesDialog = this._DispServices.createFragment(oItem.Docno, oItem.Zeile, iPoNum, iPoItem, "", sLim_ind, sCO_ind,
							oItem['ServiceId'], oItem['Maktxo'], oItem, oPOItem.CONTRACT, oPOItem.KTPNR);
					}

				}.bind(this));
		},

		onDispatchSavePress: function (evt) {
			DispatchedServicesSplit.onAcceptConfirmation(evt);
			this._DispServicesDialog.close();
		},

		onFormTypeSelecteTicket: function (oEvent) {
			var Data = oEvent.getSource().getBindingContext("JobLoggingModel").getProperty(oEvent.getSource().getBindingContext(
				"JobLoggingModel").getPath());
			var itemModelData = this.getItemModelData();
			eTicket = "X";
			FormCode = Data.FormCode;

			var version = "0";

			if (this.getView().getModel("oETicketModel").getData()) {
				version = this.getView().getModel("oETicketModel").getData().Version;
			}

			if (Data.FileUpload !== "") {
				this.getView().getModel("JobLogAttachmentEditModel").getData().Editable = Data.FileUpload;
				this.getView().getModel("JobLogAttachmentEditModel").refresh(true);
			}

			var formType = Data.FormType;
			eTicket = "";
			FormCode = Data.FormCode;
			controller.FormCode = Data.FormCode;

			if (formType === "AF") {
				if (!this.JobLogAttachmentsDialog) {
					this.JobLogAttachmentsDialog = sap.ui.xmlfragment(this.getView().getId(),
						"zdwo_nx_drss_ven.view.fragment.OC.JobLogAttachmentsDialog", this);
					this.getView().addDependent(this.JobLogAttachmentsDialog);
				}

				var itemsModel = this.getView().getModel("itemsModel").getData();
				// this.byId("uploadCollectionJobLog").setUploadEnabled(false);

				// this.onmonthlyAttachment(Data);  

				if (typeof Data['FormCode'] !== 'undefined') {
					if (Data['FormFreq'] === "03") {
						this.onmonthlyAttachment(Data);
						//this.byId("uploadCollectionJobLog").setUploadEnabled(false);
					} else {
						this.JobLogAttachmentsDialog.open();
						this.oFilterJobLogAttach();
						this.JobLogAttachmentsDialog.setTitle(Data.FormName + " - Attachments");
						this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
					}
				}
			} else if (formType === "EF") {
				var makeDate = itemModelData.Reqdt;
				makeDate.setMonth(makeDate.getMonth() - 1);
				var lastmonth = makeDate.getMonth() + 1;
				var lastyear = makeDate.getFullYear();
				this.getRouter().navTo(Data.FormRout, {
					DrssNo: itemModelData.Docno,
					Rqtype: itemModelData.Rqtype,
					Gid: this.Gid,
					Mjahr: itemModelData.Mjahr,
					Srvtype: itemModelData.SrvtypeCode,
					Zmonth: lastmonth,
					Zyear: lastyear,
					FormCode: FormCode,
					Version: version
				});
			}

			controller.oETickVerChange = 'VersionChange';
			controller.oSelVersion = this.getView().getModel("oETicketModel").getData().Version;

			//this.getRouter().navTo("JL");
		},

		onJobLoggingListPress: function (oEvent) {;
			var Data = oEvent.getSource().getBindingContext("JobLoggingModel").getProperty(oEvent.getSource().getBindingContext(
				"JobLoggingModel").getPath());
			var formType = Data.FormType;
			eTicket = "";
			FormCode = Data.FormCode;
			controller.FormCode = Data.FormCode;

			if (Data.FileUpload !== "") {
				this.getView().getModel("JobLogAttachmentEditModel").getData().Editable = Data.FileUpload;
				this.getView().getModel("JobLogAttachmentEditModel").refresh(true);
			}

			if (formType === "AF") {
				if (!this.JobLogAttachmentsDialog) {
					this.JobLogAttachmentsDialog = sap.ui.xmlfragment(this.getView().getId(),
						"zdwo_nx_drss_ven.view.fragment.OC.JobLogAttachmentsDialog", this);
					this.getView().addDependent(this.JobLogAttachmentsDialog);
				}

				var itemsModel = this.getView().getModel("itemsModel").getData();
				// this.byId("uploadCollectionJobLog").setUploadEnabled(false);
				if (typeof Data['FormCode'] !== 'undefined') {
					if (Data['FormFreq'] === "03") {
						this.onmonthlyAttachment(Data);
						//this.byId("uploadCollectionJobLog").setUploadEnabled(false);
					} else {
						this.JobLogAttachmentsDialog.open();
						this.oFilterJobLogAttach();
						this.JobLogAttachmentsDialog.setTitle(Data.FormName + " - Attachments");
						this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
					}
				}
				// this.onmonthlyAttachment(Data);  
				// SrvTreeConversion.UploadBtnVisibility(Data,controller);
				/*if (typeof Data['FormCode'] !=='undefined'){
				   if (Data['FormFreq'] === "03"){
					 this.onmonthlyAttachment(Data);  
					 //this.byId("uploadCollectionJobLog").setUploadEnabled(false);
				   }else{
					   this.JobLogAttachmentsDialog.open(); 
						this.oFilterJobLogAttach();	
						this.JobLogAttachmentsDialog.setTitle(Data.FormName + " - Attachments");					   
					   this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
				  }
				}*/
				this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
			} else if (formType === "EF") {
				var itemModelData = this.getItemModelData();
				var makeDate = itemModelData.Reqdt;
				makeDate.setMonth(makeDate.getMonth() - 1);
				var lastmonth = makeDate.getMonth() + 1;
				var lastyear = makeDate.getFullYear();
				this.getRouter().navTo(Data.FormRout, {
					DrssNo: itemModelData.Docno,
					Rqtype: itemModelData.Rqtype,
					Gid: this.Gid,
					Mjahr: itemModelData.Mjahr,
					Srvtype: itemModelData.SrvtypeCode,
					Zmonth: lastmonth,
					Zyear: lastyear,
					FormCode: FormCode,
					Version: '0'
				});
			}

		},

		onmonthlyAttachment: function (Data) {
			var monthlyData = controller.getView().getModel("itemsModel").getObject("/HeaderToAttNav");
			var results = monthlyData.filter(obj => {
				return obj.Category === '03' && obj.Formcode === Data.FormCode
			});

			if (results.length === 0) {
				sap.m.MessageBox.error('There is no document available');
				return;
			}
			this.getView().getModel("oMonthlyListModel").setData(null);
			this.getView().getModel("oMonthlyListModel").setData(results);
			this.getView().getModel("oMonthlyListModel").refresh(true);
			if (!this.onmonthlyAttachmentDialog) {
				this.onmonthlyAttachmentDialog = sap.ui.xmlfragment(this.getView().getId(),
					"zdwo_nx_drss_ven.view.fragment.JobLogging.JobLoggingMonthlyList", this);
				this.getView().addDependent(this.onmonthlyAttachmentDialog);
			}
			this.onmonthlyAttachmentDialog.open();
			this.onmonthlyAttachmentDialog.setTitle(Data.FormName + " - Attachments");

		},

		onCloseMonthly: function () {
			if (this.onmonthlyAttachmentDialog) {
				this.onmonthlyAttachmentDialog.close();
			}

		},

		onConsolidatedPdf: function () {
			var itemModelData = this.getItemModelData();
			var makeDate = itemModelData.Reqdt;
			makeDate.setMonth(makeDate.getMonth() - 1);
			var lastmonth = makeDate.getMonth() + 1;
			var lastyear = makeDate.getFullYear();
			this.getRouter().navTo("JL", {
				DrssNo: itemModelData.Docno,
				Rqtype: itemModelData.Rqtype,
				Gid: this.Gid,
				Mjahr: itemModelData.Mjahr,
				Srvtype: itemModelData.SrvtypeCode,
				Zmonth: lastmonth,
				Zyear: lastyear,
				FormCode: FormCode,
				PdfRoute: 'X'
			});
		},

		// oFilterJobLogAttach: function () {
		// 	this.byId("uploadCollectionJobLog").data({
		// 		ItemValue: controller.FormCode
		// 	});
		// 	var oBinding = this.byId("uploadCollectionJobLog").getBinding("items");
		// 	if (oBinding) {
		// 		//oBinding.filter(null);
		// 		oBinding.filter([
		// 			new sap.ui.model.Filter("Category", "EQ", "03"),
		// 			new sap.ui.model.Filter("Formcode", "EQ", controller.FormCode)
		// 			//new sap.ui.model.Filter("Version","EQ",controller.oSelVersion)
		// 		]);
		// 	}
		// 	oBinding.refresh();
		// },

		onJobLoggingListPresseTicket: function (oEvent) {
			debugger;
			var Data = oEvent.getSource().getBindingContext("data").getProperty(oEvent.getSource().getBindingContext(
				"data").getPath());
			var formType = Data.Item;
			var getParamData = this.getView().getModel('oETicketModel').getData();
			// eTicket = "X";
			// FormCode = Data.FormCode;
			// controller.FormCode = Data.FormCode;

			// if (Data.FileUpload !== "") {
			// 	this.getView().getModel("JobLogAttachmentEditModel").getData().Editable = Data.FileUpload;
			// 	this.getView().getModel("JobLogAttachmentEditModel").refresh(true);
			// }

			if (formType === "SAUD") {
				if (!this.JobLogAttachmentsDialog) {
					this.JobLogAttachmentsDialog = sap.ui.xmlfragment(this.getView().getId(),
						"zdwo_nx_drss_ven.view.fragment.OC.JobLogAttachmentsDialog", this);
					this.getView().addDependent(this.JobLogAttachmentsDialog);
				}

				var itemsModel = this.getView().getModel("itemsModel").getData();

				// if (typeof Data['FormCode'] !== 'undefined') {
				// 	if (Data['FormFreq'] === "03") {
				// 		this.onmonthlyAttachment(Data);
				// 	}
				// else {
				this.JobLogAttachmentsDialog.open();
				// this.oFilterJobLogAttach();
				this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
				// }
				// }
			}

			if (formType === "VATC") {
				if (!this.VATdialog) {
					this.VATdialog = sap.ui.xmlfragment(this.getView().getId(),
						"zdwo_nx_drss_ven.view.fragment.OC.VATdialog", this);
					this.getView().addDependent(this.VATdialog);
				}

				var itemsModel = this.getView().getModel("itemsModel").getData();
				this.VATdialog.open();
				// this.oFilterJobLogAttach();
				// this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
			}
			if (formType === "NXIV") {
				debugger;
				if (!this.Invoice) {
					this.Invoice = sap.ui.xmlfragment(this.getView().getId(),
						"zdwo_nx_drss_ven.view.fragment.OC.Invoice", this);
					this.getView().addDependent(this.Invoice);
				}

				var itemsModel = this.getView().getModel("itemsModel").getData();
				this.Invoice.open();
				// this.oFilterJobLogAttach();
				this.byId("uploadCollectionJobLog").setUploadEnabled(Data.FileUpload);
			} else if (formType === "ZEFR") {
				this.getRouter().navTo('JL', {
					DrssNo: getParamData.Docno,
					Rqtype: getParamData.Rqtype,
					// Gid: Data.Gid,
					Etkt: getParamData.Etkt,
					Mjahr: getParamData.Mjahr,
					SrvtypeCode: getParamData.SrvtypeCode
						// RqstatColor: this.itemDetails.RqstatColor,
						// RqstatDesc: this.itemDetails.RqstatDesc,
						// SrvtypText: this.itemDetails.SrvtypText

				});
				// var itemModelData = this.getItemModelData();
				// var makeDate = itemModelData.Reqdt;
				// makeDate.setMonth(makeDate.getMonth() - 1);
				// var lastmonth = makeDate.getMonth() + 1;
				// var lastyear = makeDate.getFullYear();
				// this.getRouter().navTo(Data.FormRout, {
				// 	DrssNo: itemModelData.Docno,
				// 	Rqtype: itemModelData.Rqtype,
				// 	Gid: this.Gid,
				// 	Mjahr: itemModelData.Mjahr,
				// 	Srvtype: itemModelData.SrvtypeCode,
				// 	Zmonth: lastmonth,
				// 	Zyear: lastyear,
				// 	FormCode: FormCode
				// });
			} else {
				// Do Nothing
			}

		},

		onUploadCompleteJob: function (evt) {
			//controller.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getModel().setProperty(controller.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getPath()+"/FormStatus","SUBT")
			//this.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getModel().refresh();
			//var sPath = this.byId("uploadCollectionJobLog").getBindingContext("JobLoggingModel").getPath();
			//this.JobLogAttachmentsDialog.unbindElement("itemsModel");
			//this.JobLogAttachmentsDialog.bindElement({model:"itemsModel",path:sPath});

			// this._OCReqData(this.itemDetails.DrssNo,this.itemDetails.Mjahr,this.itemDetails.Rqtype,this.itemDetails.SrvtypeCode);

			if (typeof evt !== "undefined" && evt.mParameters.mParameters.status !== 201) {
				var responseRaw = evt.mParameters.mParameters.responseRaw;
				var start = responseRaw.indexOf("<errordetails>");
				var list = [];
				if (start > -1) {

					var end = responseRaw.indexOf("</errordetails>");
					var message = responseRaw.substr(start, end);
					var errorMessages = message.split("<message>");
					for (var i = 0; i < errorMessages.length; i++) {
						var erMsg = errorMessages[i];
						if (erMsg.indexOf("</message>") > -1) {
							var msg = {
								severity: "Error",
								message: erMsg.substr(0, erMsg.indexOf("</message>")),
								description: erMsg.substr(0, erMsg.indexOf("</message>"))
							};
							list.push(msg);
						}
					}
					if (list.length > 0) {
						this.instantiateErrorMessageModel(list);
						this.createMessagePopoverModel();

					}
				}

			} else {
				// var oModel = this.getView().getModel("VendorService");
				var oModel = this.getView().getModel("oReqHeaderSetModel");
				var docNo = this.getDocno();
				var year = this.getYear();
				this.oSets = "HeaderToAttNav," + "HeaderToItemNav";
				var busyDialog = new sap.m.BusyDialog({
					title: 'Loading...'
				});
				busyDialog.open();

				var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "',Rqtype='" + this.itemDetails.Rqtype + "')";
				oModel.read(params, {
					urlParameters: {
						"$expand": this.oSets
					},
					success: function (oData) {
						this.getJoblogging();
						this.getView().getModel("itemsModel").getData()['HeaderToAttNav'] = oData['HeaderToAttNav']['results'];
						this.getView().getModel("itemsModel").refresh();
						this.oFilterJobLogAttach();
						busyDialog.close();
					}.bind(this),

					error: function (oResponse) {
						busyDialog.close();
						if (oResponse.responseText) {
							var parsedJson = JSON.parse(oResponse.responseText);
							sap.m.MessageBox.error(parsedJson.error.message.value);
						}

					}.bind(this)
				});

			}
			//   var params = "/ReqHeaderSet(Docno='" + docNo + "',Mjahr='" + year + "')";
		},

		getItemModelData: function () {
			return this.getView().getModel("itemsModel").getData();
		},

		getJobLoggingModelData: function () {
			return this.getView().getModel("JobLoggingModel").getData();
		},

		onTreeSearchMaster: function (evt) {

			var oTable = Core.byId("treeMaster");
			var oBinding = oTable.getBinding("items");
			oTable.expandToLevel(100);
			var aFilters = [];
			var sQuery = evt.getSource().getValue();

			const aWords = sQuery.split(" ");
			var sWord = "";
			for (var x = 0; x < aWords.length; x++) {
				sWord = aWords[x];
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord.toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord.toUpperCase()));
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord[0].toUpperCase() + sWord.substr(
						1)
					.toLowerCase()));
				aFilters.push(new sap.ui.model.Filter("SHORT_TEXT", sap.ui.model.FilterOperator.Contains, sWord));
			}
			var oFilter = [new sap.ui.model.Filter(aFilters, false)];
			oBinding.filter(oFilter);

		},
		//HeaderToSaudizationNav
		getETicketInfo: function (oEvent, oETickVerChange) {
			debugger;
			// var oETicketingService = this.getView().getModel("oETicketingService");
			var oETicketingService = this.getView().getModel("oETicketHdr");
			this.busyDialog.open();
			this.sStatus = oEvent;
			var oSelectedVersion = "";
			if (oETickVerChange === 'VersionChange') {
				var oSelectedVersion = oEvent.getSource().getText();

			} else if (controller.oETickVerChange === 'VersionChange') {
				var oSelectedVersion = controller.oSelVersion;
			}

			if (oEvent === "JOBL") {
				// var sEntityPath = oETicketingService.createKey("/ETicketHdrSet", {
				// 	Etkt: "",
				// 	Version: oSelectedVersion
				// });
				var sEntityPath = oETicketingService.createKey("/ETicketHdrSet", {
					Etkt: controller.Etkt,
					Version: oSelectedVersion
				});
				var aFilters = []; /**/
				aFilters.push(new sap.ui.model.Filter("Docno", sap.ui.model.FilterOperator.EQ, this.getDocno()));
				aFilters.push(new sap.ui.model.Filter("Mjahr", sap.ui.model.FilterOperator.EQ, this.Mjahr));
			} else {
				var sEntityPath = oETicketingService.createKey("/ETicketHdrSet", {
					Etkt: this.getDocno(),
					Version: oSelectedVersion
				});
			}

			// if (this.eTicketDialog) {
			// 	this.eTicketDialog.setBusy(true);
			// }

			oETicketingService.read(sEntityPath, {
				filters: aFilters,
				urlParameters: {
					"$expand": "HeaderToItemNav,HeaderToRemarksNav,HeaderToWfLogNav,HeaderToOLDWfLogNav,HeaderToVrsnNav,HeaderToSaudizationNav,HeaderToFinanceDataNav,HeaderToVendAttNav"
				},
				success: function (oData) {
					if (oData.Dispute === "X") {
						this.getView().getModel("DisputeVisibilityModel").getData().DisputeVisibility = true;
					}
					this.getView().getModel("DisputeVisibilityModel").refresh(true);

					// var oETicketModel = this.getView().getModel("oETicketModel");
					var oETicketModel = sap.ui.getCore().getModel("oETicketModel");
					oData['HeaderToItemNav'] = oData['HeaderToItemNav'].results;
					oData['HeaderToEDrssNav'] = oData['HeaderToEDrssNav'].results;
					oData['HeaderToEFormsNav'] = oData['HeaderToEFormsNav'].results;
					oData['HeaderToWfLogNav'] = oData['HeaderToWfLogNav'].results;
					oData['HeaderToOLDWfLogNav'] = oData['HeaderToOLDWfLogNav'].results;
					oData['HeaderToVrsnNav'] = oData['HeaderToVrsnNav'].results;
					oData['HeaderToSaudizationNav'] = oData['HeaderToSaudizationNav'].results;
					oData['HeaderToFinanceDataNav'] = oData['HeaderToFinanceDataNav'].results;
					oData['HeaderToRemarksNav'] = oData['HeaderToRemarksNav'].results;
					oData['eTicket'] = oData['HeaderToItemNav'];
					oData['eDrss'] = oData['HeaderToEDrssNav'];
					oData['verDetailsTaxi'] = oData['HeaderToEFormsNav'];
					oData['saudiDetails'] = oData['HeaderToSaudizationNav'];
					//Nexus attachemnt for invoice doc
					oData['VendAttNav'] = oData['HeaderToVendAttNav'].results;

					// var RacNav = this.RacNav;
					var SAUDA = [];
					var InvoiceA = [];
					var VATCA = [];
					oData['VendAttNav'].forEach(function (item) {
						if (item.Item === "SAUD") {
							SAUDA.push(item);
						}
					});
					var SAUD = new JSONModel();
					SAUD.setData(SAUDA);
					this.getView().setModel(SAUD, "SAUD");

					oData['VendAttNav'].forEach(function (item) {
						if (item.Item === "NXIV") {
							InvoiceA.push(item);
						}
					});
					var Invoice = new JSONModel();
					Invoice.setData(InvoiceA);
					this.getView().setModel(Invoice, "Invoice");

					oData['VendAttNav'].forEach(function (item) {
						if (item.Item === "VATC") {
							VATCA.push(item);
						}
					});
					var VATC = new JSONModel();
					VATC.setData(VATCA);
					this.getView().setModel(VATC, "VATC");

					//check HeaderToItemNav in EticketItems menge is there but data>ItemToAccNav value is not there 
					this.getView().getModel("data").setData(oData);
					oETicketModel.setData(oData);
					this.getOwnerComponent().setModel(oETicketModel, "oCompETicketModel");
					if (controller.byId("ProcessFlowId")) {
						controller.byId("ProcessFlowId").updateModel(true);
					}

					if (controller.byId("OldProcessHeader")) {
						controller.byId("OldProcessHeader").updateModel(true);
					}
					if (controller.byId("processFlowHeader")) {
						controller.byId("processFlowHeader").updateModel(true);
					}

					if (oETickVerChange === 'VersionChange') {
						this.onPreviewETicketPress('VersionChange');
					}

					// if (this.eTicketDialog) {
					// 	this.eTicketDialog.setBusy(false);
					// }
					this.getOwnerComponent().setModel(oETicketModel, "oETicketModel");
					var oETicketModel = this.getView().getModel("oETicketModel").getData();
					var oItemsModel = this.getView().getModel("itemsModel").getData();
					var docNo = oETicketModel.Docno;
					if (docNo === "") {
						docNo = oItemsModel.Docno;
					}

					if (controller.ConsPdf == "X" && controller.ForemanBase64 !== "undefined") {
						this._postForemanConSubmit(oData.Version, docNo);
						// console.log("Foreman PDF");
						// console.log(controller.ForemanBase64);
						this._postVendorConSubmit(oData.Version, docNo);
						// console.log("Vendor PDF");
						// console.log(controller.VendorBase64);
					}
					// PDF Data
					var itemsModel = this.getView().getModel("itemsModel");
					var oJledit = itemsModel.getData().Jledit;
					if (oJledit && controller.oETicktClose) {
						controller.oForemanPdf = "";
						controller.onConsolidatedPdfAll();
						controller.oForemanPdf = "X"
						controller.onConsolidatedPdfAll();
					}

					this.busyDialog.close();

				}.bind(this),
				error: function (oError) {
					// this.busyDialog.close();
					sap.m.MessageBox.error("Data Load Error");
					if (oError.responseText) {
						var parsedJson = JSON.parse(oError.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
						this.busyDialog.close();
					}
				}.bind(this)
			});
		},

		onConsolidatedPdfAll: function (oEvent) {

			var doc = {
				pageSize: "A2",
				pageOrientation: "landscape",
				pageMargins: [30, 5, 30, 30],
				content: [],
				border: [false, false, false, true],

				styles: {
					tiny: {
						fontSize: 8
					},
					small: {
						fontSize: 8
					},
					medium: {
						fontSize: 8
					},
					smallTitle: {
						fontSize: 8.5,
						border: [false, false, false, false]
					},
					headerLabel: {
						fontSize: 11,
						bold: true,
						alignment: 'right',
						border: [false, false, false, false]
					},
					sectionTitle: {
						fontSize: 18,
						bold: true,
						alignment: 'center',
						margin: [0, 10, 0, 10]

					},
					subheader: {
						fontSize: 16,
						bold: true,
						margin: [0, 5, 0, 5]
					},
					pageTitle: {
						fontSize: 18,
						bold: true,
						color: '#0033a0',
						alignment: 'center',
						margin: [0, 10, 0, 10]
					}
				}
			};

			var oETicketModel = this.getOwnerComponent().getModel("oCompETicketModel");
			var itemsModel = this.getView().getModel("itemsModel").getData();

			if (itemsModel.Rqstat !== "ETKT" && itemsModel.Rqstat !== "ETRE" && itemsModel.Rqstat !== "ETKR") {
				if (typeof oETicketModel !== "undefined") {
					var oETKTData = oETicketModel.getData();
					if (typeof oETKTData.HeaderToItemNav !== "undefined") {
						if (oETKTData.HeaderToItemNav.length > 0) {
							this._oGetPdfHeader(doc, "");
							//  this._pdfHeaderLogo(doc,"");
							doc.content.push({
								text: 'eTicket Report - Version : ' + oETKTData.Version,
								style: 'pageTitle'
							});
							// doc.content.push(this._getETicketReportHeader("Ven_ETicket_header"));
							doc.content.push(this._getETicketReport(oETKTData, "after"));
						}
					}
				}
			}
			//create//
			var obj = {
				ApprBy: "T_CBAD_NFM1",
				ApprDat: "Wed Jul 17 2024 03: 00: 00 GMT + 0300(GMT + 03: 00) {}",
				// ApprTim: "{
				// 	ms: 44693000,
				// 	__edmType: 'Edm.Time'
				// }"",
				ArrDt: "null",
				ArrFrom: "",
				// ArrTm: "{
				// 	ms: 0,
				// 	__edmType: 'Edm.Time'
				// },
				ColLabel: "",
				ContRef: "10",
				Currency: "SAR",
				Depth: "",
				DepthFrom: "0.000",
				DepthTo: "0.000",
				Discounts: "0.000",
				Distance: "0.000",
				Docno: "3000006389",
				DprtDt: "null",
				// DprtTm: "{
				// 	ms: 0,
				// 	__edmType: 'Edm.Time'
				// }"",
				DprtTo: "",
				Edate: "null",
				EndDate: "Mon Mar 11 2024 03: 00: 00 GMT + 0300(GMT + 03: 00) {}",
				// EndTime: "{
				// 	ms: 0"
				// 	__edmType: 'Edm.Time'
				// }",
				Ernam: "T_CBAD_SOAX",
				// Ersda: Wed Jul 17 2024 03: 00: 00 GMT + 0300(GMT + 03: 00) {},
				Footage: "0000000000",
				FormnVlid: "",
				FromWell: "",
				GrandTotal: "0.000",
				GrossPrice: "300.000",
				HtFactor: "0000000000",
				Id: "",
				Jlstatus: "APRV",
				JobExecDate: null,
				JobId: "0001",
				JobLog: "JL0004",
				JobLogDesc: "Services",
				Mjahr: "2024",
				// MrEndDate: Mon Mar 11 2024 03: 00: 00 GMT + 0300(GMT + 03: 00) {},
				// Mrdate: Mon Mar 11 2024 03: 00: 00 GMT + 0300(GMT + 03: 00) {},
				Name: "",
				NoEquipment: "0000000000",
				NonCharge: "",
				QtyVol: "3.000",
				RelCampDate: null,
				// RelCampTime: {
				// 	ms: 0,
				// 	__edmType: 'Edm.Time'
				// },
				RelRigDate: null,
				// RelRigTime: {
				// 	ms: 0,
				// 	__edmType: 'Edm.Time'
				// },
				Sdate: null,
				ServiceDesc: "Motor: H/S >28\" L/R",
				Sno: "001",
				// StartDate: Mon Mar 11 2024 03: 00: 00 GMT + 0300(GMT + 03: 00) {},
				// StartTime: {
				// 	ms: 0,
				// 	__edmType: 'Edm.Time'
				// },
				SummaryOpr: "",
				Surcharge: "0.000",
				ToWell: "",
				TotNetValue: "0.000",
				TotalAmount: "300.000",
				TotalQty: "3.000",
				Tvd: "0000000000",
				Tvdbegin: "0000000000",
				Unit: "FT",
				UnitPrice: "100.000",
				VehPlateNo: "",
				Version: "0",
				VndsrvMatno: "",
				WGnrName: "",
				WsiteDhaGateDis: "0000",
				Zeile: "0010"
			};
			var oJobLogModel1 = this.getView().getModel("oSummaryReportModelDetail").setData(obj);
			var oJobLogModel = oJobLogModel1.getData();
			//end//
			// var oJobLogModel = this.getView().getModel("oSummaryReportModelDetail").getData();
			var filteredData = this._getFilteredTypeData(oJobLogModel);
			var aTSData = jQuery.extend(true, [], this.getView().getModel("oTSModel").getData());
			var oUniqueTSData = this._getUniqueTSData(aTSData);
			if (typeof filteredData !== "undefined") {
				this.getTimeSheetPDF('JL0001', doc, "Equipment", filteredData, oUniqueTSData);
				this.getTimeSheetPDF('JL0003', doc, "Personnel", filteredData, oUniqueTSData);
				this.getTimeSheetPDF('JL0007', doc, "Crew", filteredData, oUniqueTSData);
				this.getTimeSheetPDF('JL0004', doc, "Services", filteredData, oUniqueTSData);
			}
			//-------------------------------------------------------------
			var oJobLogData = this.getView().getModel("jobLog").getData();
			var f4Model = this.getView().getModel("F4Models").getData();
			var oJobLogData = oJobLogData.filter((element, index) => {
				return element.VendorDel !== 'X'
			});
			var oJobLogData = oJobLogData.sort(function (a, b) {
				return a.FrDate - b.FrDate
			});
			var oJobLogData = this.getView().getModel("jobLog").getData();
			oJobLogData = oJobLogData.filter(oItem => oItem.Created === true);
			if (oJobLogData.length > 0) {
				// console.log(oJobLogData.length);
				this._oGetPdfHeader(doc, "");
				doc.content.push({
					text: 'Operational Report',
					style: 'pageTitle'
				});
				doc.content.push(this._onOperationsReport(doc, "pageTitle"));
			}
			// Add Header 
			this._onSummaryReportGeneratePdf(doc);
			this._onOCDetailReportGenerate(doc);
			var oTVDModel = this.getView().getModel("oTVDModel").getData();
			if (oTVDModel.length > 0) {
				// console.log(oTVDModel.length);
				this._oGetPdfHeader(doc, "");
				doc.content.push({
					text: 'TVD',
					style: 'pageTitle'
				});
				doc.content.push(this.getTVDReport(oTVDModel, 'Tvd'));
			}
			var oSOSModel = this.getView().getModel("oSensorOffsetModel").getData();
			if (oSOSModel.length > 0) {
				this._oGetPdfHeader(doc, "");
				doc.content.push({
					text: 'Sensor Offset',
					style: 'pageTitle'
				});
				doc.content.push(this.getTVDReport(oSOSModel, 'Sos'));
			}
			var oSaudizationModel = this.getOwnerComponent().getModel("oSaudizationModel");
			if (oSaudizationModel) {
				if (oSaudizationModel.getData().length > 0) {
					this._oGetPdfHeader(doc, "");
					doc.content.push({
						text: 'Saudization Details',
						style: 'sectionTitle'
					});
					doc.content.push(this.getSaudizationReport(oSaudizationModel));
				}
			}
			var oJobLogModel = this.getView().getModel("JobLogModelPDF");
			var oDocNo = oJobLogModel.getData()['Docno'];
			if (doc.content.length == 0) {
				return;
			}
			var oDocNo = this.getView().getModel("itemsModel").getProperty("/Docno");
			if (doc.content[doc.content.length - 1]) {
				delete doc.content[doc.content.length - 1].pageBreak;
			}

			if (oEvent) {
				// pdfMake.createPdf(doc).download(oDocNo+ " - Consolidated.pdf");
				this.onPdfMakeErrorHandling(doc, oDocNo);
			} else {
				if (controller.oForemanPdf === "X") {
					controller.base64 = "";
					pdfMake.createPdf(doc).getBase64(
						function (encodedString) {
							controller.ForemanBase64 = encodedString;
							//console.log(controller.ForemanBase64)
						}.bind(this) // To bind the callback with the actual context
					);
				} else {
					controller.base64 = "";
					pdfMake.createPdf(doc).getBase64(
						function (encodedString) {
							controller.VendorBase64 = encodedString;
						}.bind(this)
					);
				}
			}
			controller.oForemanPdf = "";
		},

		_getInputComment: function () {
			var oETicketData = this.getView().getModel("oETicketModel").getData();
			this.eTicketingCommentsDialog = new Dialog({
				type: DialogType.Message,
				title: "Do you want to continue ?",
				content: [
					/*new Label({
						text: "Do you want to continue ?",
						labelFor: "submissionNote"
					}),*/
					new sap.m.TextArea({
						width: "100%",
						value: "",
						growingMaxLines: 15,
						growing: true,
						placeholder: "eTicket Remarks (required)",
						liveChange: function (oEvent) {
							var oComments = oEvent.getParameter("value");
							oETicketData.Comments = oComments;
							this.eTicketingCommentsDialog.getBeginButton().setEnabled(oComments.length > 0);
						}.bind(this)
					})
				],
				beginButton: new Button({
					type: ButtonType.Emphasized,
					text: "Submit",
					enabled: false,
					press: function () {
						this.onGenerateETicket();
						this.eTicketingCommentsDialog.close();
					}.bind(this)
				}),
				endButton: new Button({
					text: "Cancel",
					press: function () {
						//	this.sSelectedReason=true;
						this.eTicketingCommentsDialog.close();
					}.bind(this)
				})
			});
			this.eTicketingCommentsDialog.addStyleClass('eTicketWidthClass');
			this.eTicketingCommentsDialog.open();
		},

		onSubmitTicket: function (oEvent) {
			//  var oETicketData = 	this.getView().getModel("oETicketModel").getData();
			// Commented as per Vijay comment on 06/07/2023
			/*var itemsModelData= controller.getModel("itemsModel").getData();
			if(itemsModelData['Rqstat'] === 'ETKR' || itemsModelData['Rqstat'] === 'ETRE'){
				this._getInputComment();
			}else {
				this.onGenerateETicket(oEvent);
			}*/
			this._getInputComment();
			/*if(typeof controller.ForemanBase64 === "undefined"){
	           MessageBox.information("Consolidated PDF is not printed. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {	
						this._getInputComment();
					}	
				}.bind(this)
			   });
			
            }else {
	          
            }
			*/

		},

		onGenerateETicket: function () {

			var eTicketModel = this.getView().getModel("oETicketModel");
			if (eTicketModel.getObject("/SrvLoc") === "") {
				MessageBox.error("Please enter Work Location");
				return;
			}
			if (eTicketModel.getObject("/ExtReference") === "") {
				MessageBox.error("Please enter Supplier Invoice Number");
				return;
			}

			if (eTicketModel.getObject("/Dispute") === "") {
				MessageBox.information("Please confirm all operations and services log before submitting the eTicket. Do you want to continue ?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: "sapUiSizeCompact",
					onClose: function (sAction) {
						if (sAction === "YES") {
							this.eTicketSubmit();
						}
					}.bind(this)
				});
			} else {
				this.eTicketSubmit();
			}

		},

		_postForemanConSubmit: function (pVrsn, docNo) {
			var oVendorModel = controller.getOwnerComponent().getModel("oETicketingService");
			oVendorModel.create('/eTicketAttachSet', controller.ForemanBase64, {
				headers: {
					slug: "ForemanConsolidated.pdf",
					FormCode: "F040",
					version: pVrsn,
					etkt: docNo
				},
				success: function (oFrRes) {

				}.bind(this),
				error: function (err) {}
			})
		},

		_postVendorConSubmit: function (pVrsn, docNo) {
			var oVendorModel = controller.getOwnerComponent().getModel("oETicketingService");
			oVendorModel.create('/eTicketAttachSet', controller.VendorBase64, {
				headers: {
					slug: "VendorConsolidated.pdf",
					FormCode: "F039",
					version: pVrsn,
					etkt: docNo
				},

				success: function (oVenRes) {

				}.bind(this),
				error: function (err) {

				}
			})
		},
		eTicketSubmit: function () {
			var oETicketingService = this.getView().getModel("oETicketingService");
			var oETicketModel = this.getView().getModel("oETicketModel").getObject("/");
			var busyDialog = new sap.m.BusyDialog({
				title: 'Saving...'
			});
			busyDialog.open();
			oETicketModel.Operation = "02";
			delete oETicketModel.eTicket;
			delete oETicketModel.__metadata;
			delete oETicketModel.eDrss;
			delete oETicketModel.verDetailsTaxi;
			delete oETicketModel.saudiDetails;
			delete oETicketModel.HeaderToFinanceDataNav;
			//oETicketModel.JoblogForm = controller.base64;
			oETicketingService.create("/ETicketHdrSet", oETicketModel, {
				success: function (oData) {
					var msg = "eTicket Request updated successfully with refrence no " + oData.Docno + " ";
					MessageBox.success(msg);
					busyDialog.close();
					this.getRequestData(this.itemDetails.DrssNo, this.itemDetails.Mjahr, this.itemDetails.Rqtype);
					controller.ConsPdf = "X";
				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		onPreviewETicketPress: function (oEvent) {
			if (oEvent !== 'VersionChange') {
				this.getETicketInfo("JOBL");
			}
			/*else {
			    controller.oForemanPdf = "";
	            this.onConsolidatedPdfAll();
	            controller.oForemanPdf = "X"
	            this.onConsolidatedPdfAll();
			}*/
			controller.oETicktClose = true;

			// if (!this.eTicketDialog) {
			// 	this.eTicketDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.eTicketing.fragment.ETicketPreviewPopUp",
			// 		this);
			// 	this.getView().addDependent(this.eTicketDialog);
			// }
			// this.eTicketDialog.open();
		},

		oncloseJLType: function (oEvent) {
			this.eTicketDialog.close();
			controller.oETickVerChange = '';
			controller.oETicktClose = false;
			this.getETicketInfo(this.getView().getModel("itemsModel").getData().Rqstat);
		},

		oneTicketRemarks: function (oEvent) {
			/*if(!this.eTicketRemarksDialog){*/
			this.eTicketRemarksDialog = sap.ui.xmlfragment(this.getView().getId(),
				"zdwo_nx_drss_ven.view.eTicketing.fragment.eTicketRemarksOC",
				this);
			this.getView().addDependent(this.eTicketRemarksDialog);
			/*}*/
			this.eTicketRemarksDialog.open();
		},

		oncloseeTicketRemarks: function (oEvent) {
			this.eTicketRemarksDialog.close();
		},

		SelectServiceForStatus: function (evt) {
			if (!this.SelectServiceDialog) {
				this.SelectServiceDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.SelectServiceList", this);
				this.getView().addDependent(this.SelectServiceDialog);
			}
			this.SelectServiceCall(evt.getSource().data().DocNo, evt.getSource().data().Mjahr, evt.getSource().data().Zeile);
		},

		SelectServiceCall: function (Docno, Mjahr, Zeile) {
			this.busyDialog.open();
			var params = "/ReqItemsSet(Docno='" + Docno + "',Mjahr='" + Mjahr + "',Zeile='" + Zeile + "')/toVendorESV";
			var oModel = this.getView().getModel("VendorService");
			oModel.read(params, {
				success: function (oData) {
					this.getView().setModel(new JSONModel(oData.results), "SelectServiceModel");
					this.SelectServiceDialog.open();
					this.busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
					this.busyDialog.open();
				}.bind(this)
			});
		},

		onCloseSelectServiceDialog: function (evt) {
			this.SelectServiceDialog.close();
		},
		onStatusPressed: function (oEvent) {
			//;

			var oButton = oEvent.getSource();
			var sBindingPath = oEvent.getSource().getBindingContext("oETicketModel").getPath();

			// create popover
			if (!this._oPopover) {
				sap.ui.core.Fragment.load({
					name: "zdwo_nx_drss_ven.view.eTicketing.fragment.statusPopover",
					controller: this
				}).then(function (pPopover) {
					this._oPopover = pPopover;
					this.getView().addDependent(this._oPopover);
					this._oPopover.bindElement({
						path: sBindingPath,
						model: "oETicketModel"
					});
					this._oPopover.openBy(oButton);
				}.bind(this));
			} else {
				this._oPopover.bindElement({
					path: sBindingPath,
					model: "oETicketModel"
				});
				this._oPopover.openBy(oButton);
			}
		},

		onVersionClicked: function (oEvent) {
			//;
			var oButton = oEvent.getSource();
			// create popover
			if (!this._oVersionPopover) {
				sap.ui.core.Fragment.load({
					name: "zdwo_nx_drss_ven.view.eTicketing.fragment.versionHistoryPopover",
					controller: this
				}).then(function (pPopover) {
					this._oVersionPopover = pPopover;
					this.getView().addDependent(this._oVersionPopover);
					//this._oVersionPopover.bindItems( { path: "/HeaderToVrsnNav/results" , model:"oETicketModel"});
					this._oVersionPopover.openBy(oButton);
				}.bind(this));
			} else {
				//this._oVersionPopover.bindElement( { path: "/HeaderToVrsnNav/results" , model:"oETicketModel"});
				this._oVersionPopover.openBy(oButton);
			}
		},
		handleLinkPress: function (oEvent) {

			this.getETicketInfo(oEvent, "VersionChange");

		},

		onFlenameLengthExceed: function () {
			MessageBox.error("File name must not exceed 50 characters");
		},

		validate3Decimal: function (evt) {
			var oLocale = new sap.ui.core.Locale("en-US");
			var oFormatOptions = {
				minFractionDigits: 3,
				maxFractionDigits: 3
			};

			var val = evt.getSource().getValue().trim();
			var oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(oFormatOptions, oLocale);
			var newVal = oFloatFormat.parse(val);;
			evt.getSource().setValue(newVal);

		},

		getVersion: function (oContext) {
			return oContext.getProperty('Version');

		},

		getGroupHeader: function (oGroup) {
			return new GroupHeaderListItem({
				title: "Version: " + oGroup.key
			});
		},

		onETicktPDF: function () {

			var doc = {
				pageSize: "A3",
				pageOrientation: "landscape",
				pageMargins: [30, 5, 30, 30],
				content: [],
				styles: {
					small: {
						fontSize: 10
					},
					headerLabel: {
						fontSize: 11,
						bold: true,
						alignment: 'right',
						border: [false, false, false, false]
					},
					sectionTitle: {
						fontSize: 18,
						bold: true,
						alignment: 'center',
						margin: [0, 20, 0, 20]

					},
					pageTitle: {
						fontSize: 16,
						bold: true,
						color: '#0033a0',
						alignment: 'center',
						margin: [0, 0, 0, 5]
					},

					subheader: {
						fontSize: 13,
						bold: true,
						margin: [0, 5, 0, 5]
					},
				}
			};

			// this._oGetPdfHeader(doc, "");
			this._pdfHeaderLogo(doc, "");
			var oETicketModel = this.getOwnerComponent().getModel("oCompETicketModel");
			var oETKTData = oETicketModel.getData();
			doc.content.push({
				text: 'eTicket Report - Version : ' + oETKTData.Version,
				style: 'pageTitle'
			});
			//doc.content.push({ text: 'Version : ' + oETKTData.Version , style: 'subheader' });
			doc.content.push(this._getETicketReportHeader("Ven_ETicket_header"));

			var border = {
				table: {
					margin: [0, 0, 0, 50],
					widths: ["*"],
					body: [
						[{
							text: "",
							style: 'headerLabel',
							border: [false, false, false, true]
						}]
					]
				}
			}
			doc.content.push(border);
			doc.content.push({
				text: "",
				style: 'pageTitle'
			});
			doc.content.push(this._getETicketReport(oETKTData));
			var oItemsModel = this.getView().getModel("itemsModel");
			pdfMake.createPdf(doc).download(oItemsModel.getData()['Docno'] + "- ETicket.pdf");
		},

		onRecalleTicket: function (evt) {
			MessageBox.information("eTicket will be recalled and respective agents will be notified. Do you want to continue ?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						this.eTicketRecallFunction();
					}
				}.bind(this)
			});
		},

		eTicketRecallFunction: function () {;
			// var oModel = this.getView().getModel("oETicketingService");
			var oModel = this.getView().getModel("oETicketHdr");
			oModel.callFunction("/eTicketRecall", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr
				},
				success: function (oData) {
					MessageBox.success("eTicket Request recalled successfully", {
						actions: [MessageBox.Action.CLOSE],
						onClose: function () {
							this.onPageRefresh();
						}.bind(this)
					});
					//MessageBox.success("eTicket Request recalled successfully");	

				}.bind(this),
				error: function (error) {
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		fnComparator: function (a, b) {
			return parseInt(a) - parseInt(b);
		},

		onGetConsPDFData: function () {
			var oItemsModel = this.getView().getModel("itemsModel");
			if (oItemsModel) {
				var oDocNo = oItemsModel.getProperty("/Docno");
				var oMjahr = oItemsModel.getProperty("/Mjahr");
				var oSrvtyp = oItemsModel.getProperty("/Srvtyp");
			}

			this._loadPDFConfig();
			this._getOperationalReport();
			this._getData();
			this._getJobLogOpeSet();
			this._jobloggingServiceData();
			this._getDataTvd(oDocNo, oMjahr);
			this._getDataSos(oDocNo, oMjahr);
			this._MrDateRel(oDocNo, oMjahr, oSrvtyp);

		},

		_getFinalDataModel: function () {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			this.summarySheet = false;
			var aFilter = [];
			var oReportsOdataModel = this.getView().getModel("oReportsOdataModel");
			//if (this.DrssNo !== "") {
			var oItemsModel = this.getView().getModel("itemsModel").getData();
			var oDocFilter = new sap.ui.model.Filter("Docno", "EQ", oItemsModel['Docno']);
			aFilter.push(oDocFilter);
			//	}
			var selectModel = this.getModel("SelectModel").getProperty("/JLSTATUS");
			for (var i = 0; i < selectModel.length; i++) {
				aFilter.push(new sap.ui.model.Filter("Jlstatus", "EQ", selectModel[i].Value1));
			}
			var JobLogType = controller.aJLConfigTypes;
			for (var i = 0; i < controller.aJLConfigTypes.length; i++) {
				aFilter.push(new sap.ui.model.Filter("JobLog", "EQ", JobLogType[i].id));
			}
			oReportsOdataModel.read("/JobLogDetailsSet", {
				filters: aFilter,
				success: function (oData) {
					var aSummaryDetailsData = oData.results;
					var aTransprtations = aSummaryDetailsData.filter(x => x.JobLog === "JL0002");
					var aOthers = aSummaryDetailsData.filter(x => x.JobLog !== "JL0002");
					var sortedSDData = $.merge(aTransprtations, aOthers);
					var aJobLogTypesBasedStructure = [];
					sortedSDData.forEach(e => {
						if (!aJobLogTypesBasedStructure.find(x => x.JobLog === e.JobLog)) {
							aJobLogTypesBasedStructure.push({
								JobLog: e.JobLog,
								JobLogDesc: e.JobLogDesc,
								content: [],
								bIsGrouping: true,
								Jlstatus: "empty"
							});
						}
					});
					for (var i = 0; i < aJobLogTypesBasedStructure.length; i++) {
						sortedSDData.forEach(e => {
							if (aJobLogTypesBasedStructure[i].JobLog === e.JobLog) {
								aJobLogTypesBasedStructure[i].content.push(e);
							}
						});
					}
					this.getView().getModel("oSummaryReportModelDetail").setData(aSummaryDetailsData);
					var JL0001 = 0;
					var JL0002 = 0;
					var JL0003 = 0;
					var JL0004 = 0;
					var JL0005 = 0;
					var APRV = 0;
					var SUBT = 0;
					var REJC = 0;
					if (oData.results.length > 0) {
						for (var i = 0; i < oData.results.length; i++) {
							switch (oData.results[i].JobLog) {
							case "JL0001":
								JL0001 += parseInt(1)
								break;
							case "JL0002":
								JL0002 += parseInt(1)
								break;
							case "JL0003":
								JL0003 += parseInt(1)
								break;
							case "JL0004":
								JL0004 += parseInt(1)
								break;
							case "JL0005":
								JL0005 += parseInt(1)
								break;
							default:
								break;
							}
							switch (oData.results[i].Jlstatus) {
							case "APRV":
								APRV += parseInt(1)
								break;
							case "SUBT":
								SUBT += parseInt(1)
								break;
							case "REJC":
								REJC += parseInt(1)
								break;
							default:
								break;
							}
						}
					}
					busyDialog.close();

				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			})

			//// for summary Report
			//	var aFilter = [];
			oReportsOdataModel.read("/JobLogSmrySet", {
				filters: aFilter,
				success: function (oData) {
					var JL0001 = 0;
					var JL0002 = 0;
					var JL0003 = 0;
					var JL0004 = 0;
					var JL0005 = 0;
					var APRV = 0;
					var SUBT = 0;
					var REJC = 0;
					if (oData.results.length > 0) {
						for (var i = 0; i < oData.results.length; i++) {
							switch (oData.results[i].JobLog) {
							case "JL0001":
								JL0001 += parseInt(1)
								break;
							case "JL0002":
								JL0002 += parseInt(1)
								break;
							case "JL0003":
								JL0003 += parseInt(1)
								break;
							case "JL0004":
								JL0004 += parseInt(1)
								break;
							case "JL0005":
								JL0005 += parseInt(1)
								break;
							default:
								break;
							}

							switch (oData.results[i].Jlstatus) {
							case "APRV":
								APRV += parseInt(1)
								break;
							case "SUBT":
								SUBT += parseInt(1)
								break;
							case "REJC":
								REJC += parseInt(1)
								break;
							default:
								break;
							}

						}
					}
					this.emptyobject(oData.results);
				}.bind(this),
				error: function (oResponse) {
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}
				}.bind(this),
			});
		},

		_getJobLoggingServiceConfig: function () {
			var itemsModel = this.getModel("itemsModel");
			if (itemsModel) {
				var oDocNo = itemsModel.getProperty("/Docno");
				var oSrvtyp = itemsModel.getProperty("/Srvtyp");
			}

			if (!oSrvtyp) {
				oSrvtyp = this.Srvtype;
			}
			var oModel = this.getView().getModel("VendorService");
			var getJLcfg = new Promise(function (resolve, reject) {
				oModel.read("/JobLoggingServiceSet(ServiceType='" + oSrvtyp + "')", {
					urlParameters: {
						"$expand": "ServiceToJobLogNav"
					},
					success: function (oData) {
						// Get the JL configuration
						if (oData.ServiceToJobLogNav.results.length > 0) {
							controller.aJLConfigTypes = [];
							var getData = oData.ServiceToJobLogNav.results;
							$.each(getData, function (ind, obj) {
								if (obj.JobLogDesc !== "")
									var oJLObj = {
										id: obj.JobLog,
										desc: obj.JobLogDesc
									};
								controller.aJLConfigTypes.push(oJLObj);
							}.bind(this))
						}

						var JobLogCfgModel = new JSONModel(oData.ServiceToJobLogNav.results);
						this.getView().setModel(JobLogCfgModel, "JobLogCfgModel");

						resolve();
					}.bind(this),
					error: function (error) {
						var msgs = this.getErrorMessages(error);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();
						reject();
					}.bind(this)
				});
			}.bind(this));
			return getJLcfg;
		},

		_getJobLoggingData: function () {
			var oItemsModel = this.getView().getModel("itemsModel");
			if (oItemsModel) {
				var oDocNo = oItemsModel.getProperty("/Docno");
				//var oMjahr = oItemsModel.getProperty("/Mjahr");
			}
			var busyDialog = new sap.m.BusyDialog({
				title: 'Processing...'
			});
			busyDialog.open();
			this.Version = '0';
			var getJobLogging = new Promise(function (resolve, reject) {
				if (this.Version !== '' && this.Version !== '0') {
					var oFilter = [new sap.ui.model.Filter("Version", "EQ", this.Version)];
				} else {
					var oFilter = [];
				}
				this.Mjahr
				var oModel = this.getView().getModel("VendorService");
				oModel.read("/JobLoggingSet(Docno='" + oDocNo + "',Mjahr='" + this.Mjahr + "')", {
					urlParameters: {
						"$expand": "DRSSJobLoggingNAV,JobLoggingServiceDataNAV,JobLoggingNAV,TimesheetNAV"
					},
					filters: oFilter,
					success: function (oData) {
						var Inbox = 0;
						var Rejected = 0;
						var Approved = 0;
						var All = 0;
						//Begin of Addition for CAD Deductions
						var data = this.getView().getModel("JobLogCfgModel").getData();
						var results = "";
						var obj = oData.JobLoggingNAV.results[0];
						for (var i = 0; i < oData.JobLoggingServiceDataNAV.results.length; i++) {
							obj.Docno = oData.Docno;
							obj.Mjahr = oData.Mjahr;
							obj.Zeile = oData.Zeile;
							oData.JobLoggingServiceDataNAV.results[i].nodes = [obj];
						}
						var oTableItems = this.getView().getModel("JobLogFinalDataModel").getData();
						oTableItems.sort(function (a, b) {
							return a.Sno - b.Sno
						});
						//End of Addition for CAD Deductions		
						let limit = oData.JobLoggingNAV.results.length + oData.JobLoggingServiceDataNAV.results.length + oData.DRSSJobLoggingNAV.results
							.length;
						var oJsonModel = new JSONModel(oData);
						oJsonModel.setSizeLimit(limit);
						this.getView().setModel(oJsonModel, "JobLogModelPDF");
						this.getView().getModel("JobLogFinalDataModel").setData(null);
						this.getView().getModel("JobLogFinalDataModel").setData(oData.DRSSJobLoggingNAV.results);
						this.getView().getModel("oTSModel").setData(oData.TimesheetNAV.results);
						this.getView().getModel("JobLogFinalDataModel").setSizeLimit(limit);
						this.getView().getModel("JobLogFinalDataModel").refresh(true);
						busyDialog.close();
						resolve();
					}.bind(this),
					error: function (error) {
						busyDialog.close();
						reject();
						var msgs = this.getErrorMessages(error);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();

					}.bind(this)
				});
			}.bind(this));
			return getJobLogging;
		},

		_jobloggingServiceData: function () {

			const promise1 = Promise.resolve(3);
			const promise2 = 42;
			const promise3 = new Promise((resolve, reject) => {
				setTimeout(resolve, 100, 'foo');
			});

			var itemsModel = this.getModel("itemsModel");
			if (itemsModel) {
				var oDocNo = itemsModel.getProperty("/Docno");
				var oSrvtyp = itemsModel.getProperty("/Srvtyp");
			}

			if (!oSrvtyp) {
				oSrvtyp = this.Srvtype;
			}
			var oModel = this.getView().getModel("VendorService");
			const getJLcfg = new Promise(function (resolve, reject) {
				oModel.read("/JobLoggingServiceSet(ServiceType='" + oSrvtyp + "')", {
					urlParameters: {
						"$expand": "ServiceToJobLogNav"
					},
					success: function (oData) {
						// Get the JL configuration
						if (oData.ServiceToJobLogNav.results.length > 0) {
							controller.aJLConfigTypes = [];
							var getData = oData.ServiceToJobLogNav.results;
							$.each(getData, function (ind, obj) {
								if (obj.JobLogDesc !== "")
									var oJLObj = {
										id: obj.JobLog,
										desc: obj.JobLogDesc
									};
								controller.aJLConfigTypes.push(oJLObj);
							}.bind(this))
						}

						var JobLogCfgModel = new JSONModel(oData.ServiceToJobLogNav.results);
						this.getView().setModel(JobLogCfgModel, "JobLogCfgModel");

						resolve();
					}.bind(this),
					error: function (error) {
						var msgs = this.getErrorMessages(error);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();
						reject();
					}.bind(this)
				});
			}.bind(this));

			var oItemsModel = this.getView().getModel("itemsModel");
			if (oItemsModel) {
				var oDocNo = oItemsModel.getProperty("/Docno");
				//var oMjahr = oItemsModel.getProperty("/Mjahr");
			}
			var busyDialog = new sap.m.BusyDialog({
				title: 'Processing...'
			});
			busyDialog.open();
			this.Version = '0';
			const getJobLogging = new Promise(function (resolve, reject) {
				if (this.Version !== '' && this.Version !== '0') {
					var oFilter = [new sap.ui.model.Filter("Version", "EQ", this.Version)];
				} else {
					var oFilter = [];
				}
				this.Mjahr
				var oModel = this.getView().getModel("VendorService");
				oModel.read("/JobLoggingSet(Docno='" + oDocNo + "',Mjahr='" + this.Mjahr + "')", {
					urlParameters: {
						"$expand": "DRSSJobLoggingNAV,JobLoggingServiceDataNAV,JobLoggingNAV,TimesheetNAV"
					},
					filters: oFilter,
					success: function (oData) {
						var Inbox = 0;
						var Rejected = 0;
						var Approved = 0;
						var All = 0;
						//Begin of Addition for CAD Deductions
						var data = this.getView().getModel("JobLogCfgModel").getData();
						var results = "";
						var obj = oData.JobLoggingNAV.results[0];
						for (var i = 0; i < oData.JobLoggingServiceDataNAV.results.length; i++) {
							obj.Docno = oData.Docno;
							obj.Mjahr = oData.Mjahr;
							obj.Zeile = oData.Zeile;
							oData.JobLoggingServiceDataNAV.results[i].nodes = [obj];
						}
						var oTableItems = this.getView().getModel("JobLogFinalDataModel").getData();
						oTableItems.sort(function (a, b) {
							return a.Sno - b.Sno
						});
						//End of Addition for CAD Deductions		
						let limit = oData.JobLoggingNAV.results.length + oData.JobLoggingServiceDataNAV.results.length + oData.DRSSJobLoggingNAV.results
							.length;
						var oJsonModel = new JSONModel(oData);
						oJsonModel.setSizeLimit(limit);
						this.getView().setModel(oJsonModel, "JobLogModelPDF");
						this.getView().getModel("JobLogFinalDataModel").setData(null);
						this.getView().getModel("JobLogFinalDataModel").setData(oData.DRSSJobLoggingNAV.results);
						this.getView().getModel("oTSModel").setData(oData.TimesheetNAV.results);
						this.getView().getModel("JobLogFinalDataModel").setSizeLimit(limit);
						this.getView().getModel("JobLogFinalDataModel").refresh(true);
						busyDialog.close();
						resolve();
					}.bind(this),
					error: function (error) {
						busyDialog.close();
						reject();
						var msgs = this.getErrorMessages(error);
						this.instantiateErrorMessageModel(msgs);
						this.createMessagePopoverModel();

					}.bind(this)
				});
			}.bind(this));

			const getSelectModel = new Promise(function (resolve, reject) {
				var oModel = this.getView().getModel("oDataModel");
				var itemsModel = this.getModel("itemsModel").getData();
				var oSelectModel = this.getView().getModel("SelectModel");
				var oSelcData = oSelectModel.getData();
				var objData = {
					JLSTATUS: "",
					//  ZDWO_RADIUS:"",
					//  ZP_RS_PRRTY:"",
					//  ZDWO_HOLE_SIZE:""
				};
				for (var prop in objData) {
					//if (func.hasOwnProperty(prop)) {
					var aFilters = [];
					aFilters.push(new Filter("Field", FilterOperator.EQ, prop));
					// aFilters.push(new Filter("Descr4", FilterOperator.EQ, oData.Rqtype));
					oModel.read("/F4SearchHelpSet", {
						filters: aFilters,
						success: function (oData) {
							if (oData.results.length > 0) {
								var odataField = oData.results[0].Descr2;
								if (odataField !== "" && (odataField === "ZDWO_RADIUS" || odataField === "ZP_RS_PRRTY" ||
										odataField === "ZDWO_HOLE_SIZE")) {
									itemsModel[odataField] = oData.results;
								} else if (odataField !== "") {
									oSelcData[odataField] = oData.results;
									oSelectModel.refresh();
									console.log(oData);
								}
							}
							resolve();
						}.bind(this),
						error: function (oResponse) {
							var msgs = this.getErrorMessages(oResponse);
							reject();
						}.bind(this)
					});
					//  }
				}

			}.bind(this));

			Promise.all([getJLcfg, getJobLogging, getSelectModel]).then((values) => {
				this._getFinalDataModel();
			});

			// On Promise
			/*var aPromise = [];
			aPromise.push(this._getJobLoggingServiceConfig());
			aPromise.push(this._getJobLoggingData());
			aPromise.push(this._getSelectModelFields());
			Promise.all([this._getJobLoggingServiceConfig(),this._getJobLoggingData(),this._getSelectModelFields()]).then(function(oRequest) {
	           
				console.log("Got it")
        	}.bind(this));*/
		},

		_MrDateRel: function (Docno, Mjahr, SrvtypeCode) {

			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			var SrvtypeCode = this.getOwnerComponent().getModel("itemsModel").getObject("/SrvtypeCode");
			var oDataModel = this.getView().getModel("VendorService");
			oDataModel.read("/JobLoggingMrRelSet(Docno='" + Docno + "',Mjahr='" + Mjahr + "',SrvtypeCode='" + SrvtypeCode + "')", {
				success: function (oData) {
					this.getView().getModel("MrDateRelModel").setData(oData);
					this._checkConsPdfBtnVisibility();
					busyDialog.close();
				}.bind(this),
				error: function (oError) {
					busyDialog.close();
				}.bind(this)
			});
		},
		// F4 Model
		_getOperationalReport: function () {
			this.setModel(new JSONModel([]), "F4Models");
			//Holds LubSum enabled table data
			var oDataModel = this.getView().getModel("oDataModel");
			oDataModel.read("/F4SearchHelpSet", {
				filters: [new sap.ui.model.Filter("Field", "EQ", 'JOB_LOG_OPE')],
				success: function (oData) {
					oData = oData.results;
					this.getModel("F4Models").setData(oData);
					this.getModel("F4Models").refresh();
				}.bind(this),
				error: function (oError) {}.bind(this)
			});

		},

		emptyobject: function (oEvent) {
			var oLSSummaryModel = this.getView().getModel("oLSSummaryModel");
			var total1 = this.totalSummaryCost(oEvent);
			var summaryArray = [];
			const finalSummaryArray = [];
			var months = ["Jan'", "Feb'", "Mar'", "Apr'", "May'", "Jun'", "Jul'", "Aug'", "Sept'", "Oct'", "Nov'", "Dec'"];
			for (var i = 0; i < oEvent.length; i++) {
				var chartObject = {
					"ContRef": "",
					"Month": "",
					"Currency": "",
					"Discounts": "0.000",
					"Docno": "",
					"GrandTotal": "0.000",
					"Jlstatus": "",
					"JobLog": "",
					"JobLogDesc": "",
					"Sdate": null,
					"ServiceDesc": "",
					"Surcharge": "0.000",
					"TotNetValue": "0.000",
					"TotalAmount": "0.000",
					"TotalQty": "0.000",
					"Unit": "",
					"UnitPrice": "0.000",
					"ColTotalQty": "0.000",
					"ColTotalAmount": "0.000",
					"ColName": ""
				}

				if (oEvent[i].Mrdate) {
					var Day = months[oEvent[i].Mrdate.getMonth()] + oEvent[i].Mrdate.getDate();
					chartObject[Day] = oEvent[i].TotalQty;
					chartObject.Month = months[oEvent[i].Mrdate.getMonth()];
					chartObject.ColName = months[oEvent[i].Mrdate.getMonth()] + oEvent[i].Mrdate.getDate();
				}

				//chartObjectHdr[Day] = true;
				chartObject.ContRef = oEvent[i].ContRef;
				chartObject.Discounts = oEvent[i].Discounts;
				chartObject.Docno = oEvent[i].Docno;
				chartObject.GrandTotal = oEvent[i].GrandTotal;
				chartObject.Jlstatus = oEvent[i].Jlstatus;
				chartObject.JobLog = oEvent[i].JobLog;
				chartObject.JobLogDesc = oEvent[i].JobLogDesc;
				chartObject.Sdate = oEvent[i].Sdate;
				chartObject.ServiceDesc = oEvent[i].ServiceDesc;
				chartObject.Surcharge = oEvent[i].Surcharge;
				chartObject.TotNetValue = oEvent[i].TotNetValue;
				chartObject.TotalAmount = oEvent[i].TotalAmount;
				chartObject.TotalQty = oEvent[i].TotalQty;
				chartObject.Unit = oEvent[i].Unit;
				chartObject.UnitPrice = oEvent[i].UnitPrice;
				chartObject.Currency = oEvent[i].Currency;

				chartObject.Qty = oEvent[i].TotalQty;
				chartObject.Amount = oEvent[i].TotalAmount;
				chartObject.StartDate = oEvent[i].StartDate;
				chartObject.StartTime = oEvent[i].StartTime;
				chartObject.EndDate = oEvent[i].EndDate;
				chartObject.EndTime = oEvent[i].EndTime;
				chartObject.MrDate = oEvent[i].Mrdate;
				chartObject.MrEndDate = oEvent[i].MrEndDate;

				chartObject.Zeile = oEvent[i].Zeile;
				chartObject.JobId = oEvent[i].JobId;
				summaryArray.push(chartObject);

				finalSummaryArray.push(chartObject);

			}

			oLSSummaryModel.setProperty("/aUniqueColumns", finalSummaryArray);
			oLSSummaryModel.setProperty("/aRows", finalSummaryArray);

			//			if(!this.oLumpSumTableFragment) {
			//				this.oLumpSumTableFragment = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.OC.LumpSumTable", this);
			//				this.getView().addDependent(this.oLumpSumTableFragment);	
			//			}
			//			this.oLumpSumTableFragment.open();
			//			this.oLumpSumTableFragment.close();

			var uniqueArray = summaryArray.reduce((filter, current) => {
				var dk = filter.find(item => (item.Zeile === current.Zeile && item.JobId === current.JobId));
				if (!dk) {
					return filter.concat([current]);
				} else {

					var TotalQty = parseFloat(dk.TotalQty);
					var Qty = parseFloat(dk.Qty);
					TotalQty += parseFloat(current.TotalQty);
					var TotalAmount = parseFloat(dk.TotalAmount);
					TotalAmount += parseFloat(current.TotalAmount);
					/*var Day = 0;
					for(var j=1;j<=31;j++){
					   
					}*/
					var value = current.ColName;
					Day = this.numberfunction(dk[value]);
					Day += this.numberfunction(current[value]);
					dk[value] = (Day).toFixed(2);
					/*if(this.formatStringDateAramco(current.MrDate) === this.formatStringDateAramco(current.EndDate)){
						dk.Qty = (Day).toFixed(2);
					}*/
					dk.Qty = (Qty).toFixed(2);
					/*dk.TotalQty = (TotalQty).toFixed(2);*/
					dk.TotalQty = (TotalQty).toFixed(3);
					dk.TotalAmount = (TotalAmount).toFixed(2);
					return filter;
				}
			}, []);

			var ColoumnUniqueArray = summaryArray.reduce((filter, current) => {
				var cdk = filter.find(item => (item.Zeile === current.Zeile && item.JobId === current.JobId && item.ColName === current.ColName));
				if (!cdk) {
					return filter.concat([current]);
				} else {
					return filter;
				}
			}, []);

			//oLSSummaryModel.setProperty("/aUniqueColumns", ColoumnUniqueArray);
			//oLSSummaryModel.setProperty("/aRows", ColoumnUniqueArray);

			this.aUniqueSummaryColomns = ColoumnUniqueArray;
			// console.log(ColoumnUniqueArray)
			//// console.log(chartObjectHdr);
			//chartObjectHdr.TableData = uniqueArray;
			/*			this.getView().getModel("oSummaryReportModelPerDay").setData(null);
						this.getView().getModel("oSummaryReportModelPerDay").setData(uniqueArray);
						this.getView().getModel("oSummaryReportModelPerDay").refresh(true);*/

			//oLSSummaryModel.setProperty("/aRows",uniqueArray);
			/*
						var total = this.totalSummaryCost(uniqueArray);

						var userInfoModel = this.getView().getModel("UserInfoModel");*/

		},

		totalSummaryCost: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						total += parseFloat(cost[i].TotalAmount)
					}
					total = (total).toFixed(2);
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		numberfunction: function (sValue) {
			if (parseFloat(sValue)) {
				return parseFloat(sValue);
			} else {
				return 0;
			}
		},

		_getJobLogOpeSet: function () {
			var oItemsModel = this.getView().getModel("itemsModel").getData();
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			var oFilter = [new sap.ui.model.Filter("Docno", "EQ", oItemsModel.Docno),
				new sap.ui.model.Filter("Mjahr", "EQ", oItemsModel.Mjahr),
				new sap.ui.model.Filter("LogType", "EQ", 'OPE')
			];

			var oModel = this.getView().getModel("VendorService");
			var params = "/JobLogOpeSet";
			oModel.read(params, {
				filters: oFilter,
				success: function (oData) {
					oData = oData.results;
					var Inbox = 0;
					var Submitted = 0;
					var Approved = 0;

					for (var i = 0; i < oData.length; i++) {
						if (oData[i].VendorDel === "") {
							switch (oData[i].Status) {
							case "INIT":
								Inbox += parseInt(1)
								break;
							case "REJC":
								Inbox += parseInt(1)
								break;
							case "REVS":
								Inbox += parseInt(1)
								break;
							case "RECL":
								Inbox += parseInt(1)
								break;
							case "APRV":
								Approved += parseInt(1)
								break;
							case "SUBT":
								Submitted += parseInt(1)
								break;
							default:
								break;
							}
						}
					}

					this.getView().getModel("jobLog").setData(null);
					this.getView().getModel("jobLog").setData(oData);
					this.getView().getModel("jobLog").setSizeLimit(oData.length);
					this.getView().getModel("jobLog").refresh(true);
					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
		},

		// JobLog Model 
		_getData: function () {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			var oItemsModel = this.getView().getModel("itemsModel").getData();
			var oFilter = [new sap.ui.model.Filter("Docno", "EQ", oItemsModel.Docno),
				new sap.ui.model.Filter("Mjahr", "EQ", oItemsModel.Mjahr),
				new sap.ui.model.Filter("LogType", "EQ", 'OPE')
			];

			var oModel = this.getView().getModel("oDataModel");
			var params = "/JobLogOpeSet";
			oModel.read(params, {
				filters: oFilter,
				success: function (oData) {
					oData = oData.results;
					var Inbox = 0;
					var Submitted = 0;
					var Approved = 0;
					var Rejected = 0;
					var All = 0;

					for (var i = 0; i < oData.length; i++) {
						if (oData[i].VendorDel === "") {
							switch (oData[i].Status) {
							case "SUBT":
								Inbox += parseInt(1)
								break;
							case "APRV":
								Approved += parseInt(1)
								break;
							case "REJC":
								Rejected += parseInt(1)
								break;
							default:
								break;
							}
						}
					}
					this.getView().getModel("JobLogModelPDF").setProperty("/JobLogOpeSet", oData);
					this.getView().getModel("JobLogModelPDF").setSizeLimit(oData.length);
					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
			return oFilter;
		},

		_loadPDFConfig: function (oEvent) {
			var oReportsOdataModel = this.getView().getModel("oReportsOdataModel");
			oReportsOdataModel.read("/PDFJoblogSummarySet", {
				success: function (oData) {
					oData = oData.results;
					this.getView().getModel("oPDFMappingModel").setData(oData);
				}.bind(this),
				error: function (oResponse) {
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}
				}.bind(this)
			});
		},

		//Load  TVD Data
		_getDataTvd: function (Docno, Mjahr) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			if (this.Version !== '' && this.Version !== '0' && typeof this.Version !== "undefined") {
				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", Docno),
					new sap.ui.model.Filter("Mjahr", "EQ", Mjahr),
					new sap.ui.model.Filter("LogType", "EQ", 'TVD'),
					new sap.ui.model.Filter("Version", "EQ", this.Version)
				];
			} else {
				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", Docno),
					new sap.ui.model.Filter("Mjahr", "EQ", Mjahr),
					new sap.ui.model.Filter("LogType", "EQ", 'TVD')
				];
			}
			var oModel = this.getView().getModel("oDataModel");
			var params = "/JobLogOpeSet";
			oModel.read(params, {
				filters: oFilter,
				success: function (oData) {
					oData = oData.results;
					var Inbox = 0;
					var Submitted = 0;
					var Approved = 0;

					for (var i = 0; i < oData.length; i++) {
						if (oData[i].VendorDel === "") {
							switch (oData[i].Status) {
							case "SUBT":
								Inbox += parseInt(1)
								break;
							case "APRV":
								Approved += parseInt(1)
								break;
							default:
								break;
							}
						}
					}
					this.getView().getModel("oTVDModel").setData(null);
					this.getView().getModel("oTVDModel").setData(oData);
					this.getView().getModel("oTVDModel").setSizeLimit(oData.length);
					this.getView().getModel("oTVDModel").refresh(true);
					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
		},

		//Load Sensor Offset Data
		_getDataSos: function (Docno, Mjahr) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Loading...'
			});
			busyDialog.open();
			if (this.Version !== '' && this.Version !== '0' && typeof this.Version !== "undefined") {
				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", Docno),
					new sap.ui.model.Filter("Mjahr", "EQ", Mjahr),
					new sap.ui.model.Filter("LogType", "EQ", 'SOS'),
					new sap.ui.model.Filter("Version", "EQ", this.Version)
				];
			} else {
				var oFilter = [new sap.ui.model.Filter("Docno", "EQ", Docno),
					new sap.ui.model.Filter("Mjahr", "EQ", Mjahr),
					new sap.ui.model.Filter("LogType", "EQ", 'SOS')
				];
			}
			var oModel = this.getView().getModel("oDataModel");
			var params = "/JobLogOpeSet";
			oModel.read(params, {
				filters: oFilter,
				success: function (oData) {
					oData = oData.results;
					var Inbox = 0;
					var Submitted = 0;
					var Approved = 0;
					for (var i = 0; i < oData.length; i++) {
						if (oData[i].VendorDel === "") {
							switch (oData[i].Status) {
							case "SUBT":
								Inbox += parseInt(1)
								break;
							case "APRV":
								Approved += parseInt(1)
								break;
							default:
								break;
							}
						}
					}
					this.getView().getModel("oSensorOffsetModel").setData(null);
					this.getView().getModel("oSensorOffsetModel").setData(oData);
					this.getView().getModel("oSensorOffsetModel").setSizeLimit(oData.length);
					this.getView().getModel("oSensorOffsetModel").refresh(true);

					busyDialog.close();
				}.bind(this),
				error: function (oResponse) {
					busyDialog.close();
					if (oResponse.responseText) {
						var parsedJson = JSON.parse(oResponse.responseText);
						sap.m.MessageBox.error(parsedJson.error.message.value);
					}

				}.bind(this)
			});
		},

		_onFilterPress: function () {
			if (DrssNo !== "") {
				var oDocFilter = new sap.ui.model.Filter("Docno", "EQ", DrssNo);
				aFilter.push(oDocFilter);
			}

			for (var i = 0; i < JobLogStatus.length; i++) {
				aFilter.push(new sap.ui.model.Filter("Jlstatus", "EQ", JobLogStatus[i]));
			}

			for (var i = 0; i < JobLogType.length; i++) {
				aFilter.push(new sap.ui.model.Filter("JobLog", "EQ", JobLogType[i]));
			}
			return oFilter;
		},

		_getFilteredTypeData: function (aSummaryDetailsData) {
			if (aSummaryDetailsData.length && aSummaryDetailsData.length > 0) {
				var aTransprtations = aSummaryDetailsData.filter(x => x.JobLog === "JL0002");
				var aOthers = aSummaryDetailsData.filter(x => x.JobLog !== "JL0002");
				var sortedSDData = $.merge(aTransprtations, aOthers);
				var aJobLogTypesBasedStructure = [];
				sortedSDData.forEach(e => {
					if (!aJobLogTypesBasedStructure.find(x => x.JobLog === e.JobLog)) {
						aJobLogTypesBasedStructure.push({
							JobLog: e.JobLog,
							JobLogDesc: e.JobLogDesc,
							content: [],
							bIsGrouping: true,
							Jlstatus: "empty"
						});
					}
				});
				for (var i = 0; i < aJobLogTypesBasedStructure.length; i++) {
					sortedSDData.forEach(e => {
						if (aJobLogTypesBasedStructure[i].JobLog === e.JobLog) {
							aJobLogTypesBasedStructure[i].content.push(e);
						}
					});
				}
				return aJobLogTypesBasedStructure;
			}

		},

		_onOCDetailReportGenerate: function (doc) {

			var aJobLogModel = this.getView().getModel("oSummaryReportModelDetail").getData();
			if (aJobLogModel.length == 0) {
				return;
			}
			var oJobLogModel = aJobLogModel.sort(function (a, b) {
				return a.Mrdate - b.Mrdate
			});
			var arr = oJobLogModel;
			var res = [];
			var map = {};
			arr.forEach(item => {
				var temp = {};
				if (!map[item.Mrdate]) {
					map[item.Mrdate] = [];
					temp[item.Mrdate] = map[item.Mrdate];
					res.push(temp);
				};
				map[item.Mrdate].push(item);
			});
			var aHier = [];
			for (var ind in res) {
				for (var InnerInd in res[ind]) {
					aHier.push(res[ind][InnerInd]);
				}
			}
			$.each(aHier, function (ind, obj) {
				var oPersonalFilter = obj.filter(item => {
					return item
				});
				if (oPersonalFilter.length > 0) {
					var cDate = this.formatStringDateAramco(obj[0].Mrdate);
					if (typeof cDate == "undefined") {
						cDate = "";
					}
					var oSelectedStatus = ['JL0001', 'JL0002', 'JL0003', 'JL0004', 'JL0005', 'JL0006', 'JL0007', 'OT0001', 'OT0002', 'OT0003',
						'OT0004'
					];
					this.oFilteredStatusData = [];
					for (var ind in oSelectedStatus) {
						var aRecords = oPersonalFilter.filter(oItem => oItem.JobLog === oSelectedStatus[ind])
						this.oFilteredStatusData = this.oFilteredStatusData.concat(aRecords);
					}
					// console.log(this.oFilteredStatusData);
					this.oFilteredStatusData = this.oFilteredStatusData.filter(oItem => oItem.Jlstatus === "APRV");
					var oSummaryReportData = this.oFilteredStatusData;
					if (oSummaryReportData.length > 0) {
						if (ind === 0) {
							this._oGetPdfHeader(doc, "");
						}
						doc.content.push({
							text: 'Service Logging - Daily Detail' + " - " + cDate,
							style: 'pageTitle'
						});
						this.getDetailedReport(doc, oSummaryReportData);
					}
				}

			}.bind(this))
		},

		convertoPdf: function () {
			var oBase64 = controller.pdfBase
			const linkSource = `data:application/pdf;base64,${oBase64}`;
			//const linkSource =  "data:application/pdf;base64" +oBase64;
			const downloadLink = document.createElement("a");
			const fileName = "Consolidated.pdf";
			downloadLink.href = linkSource;
			downloadLink.download = fileName;
			downloadLink.click();
		},

		_getTimesheetRData: function (aJobLogModel) {
			var aTSData = this.getView().getModel("oTSModel").getData();
			var oJobLogModel = [];
			if (aTSData.length > 0) {
				$.each(aJobLogModel, function (ind, obj) {
					var aFilteredTS = aTSData.filter(oLineItemsData => {
						return obj.Docno === oLineItemsData.Docno &&
							obj.Mjahr === oLineItemsData.Mjahr &&
							obj.Zeile === oLineItemsData.Zeile &&
							obj.JobId === oLineItemsData.JobId &&
							obj.Sno === oLineItemsData.Sno;
					});
					if (aFilteredTS.length == 0) {
						oJobLogModel.push(obj);
					}
				}.bind(this))

			}

			return oJobLogModel;
		},

		formatStringDateAramco: function (oStrDate) {
			if (oStrDate instanceof Date) {
				//var sDate = oStrDate.toJSON();
				//var sDate = oStrDate.toString();
				var sFinalDate = (oStrDate.getMonth() + 1) + "/" + oStrDate.getDate() + "/" + oStrDate.getFullYear();

				return sFinalDate;
			} else if ((oStrDate === null) || (oStrDate === 'undefined') || (oStrDate === undefined)) {
				// Do Nothing
			} else {
				var st = oStrDate.split("T");
				var oVal = st[0];
				return oVal.substr(5, 2) + "/" + oVal.substr(8, 2) + "/" + oVal.substr(0, 4);
			}
		},
		_getFixedFields: function () {
			var aFixedFields = [];
			aFixedFields.push({
				"Fieldname": "ContRef",
				"FieldDesc": "Contract Ref No",
				"Source": "ContRef",
				"Width": 10,
				"Seqno": "000"
			});
			aFixedFields.push({
				"Fieldname": "AppBy",
				"FieldDesc": "App/Rej By",
				"Source": "ApprBy",
				"Width": 10,
				"Seqno": "999"
			});
			aFixedFields.push({
				"Fieldname": "AppDate",
				"FieldDesc": "App/Rej Date",
				"Source": "ApprDat",
				"Width": 10,
				"Seqno": "999"
			});
			aFixedFields.push({
				"Fieldname": "AppTime",
				"FieldDesc": "App/Rej Time",
				"Source": "ApprTim",
				"Width": 10,
				"Seqno": "999"
			});
			aFixedFields.push({
				"Fieldname": "Jlstatus",
				"FieldDesc": "Status",
				"Source": "Jlstatus",
				"Width": 6,
				"Seqno": "999"
			});
			return aFixedFields;

		},

		_populateTimesheet: function (oBody, oLineItemsData, iRowLength) {

			var aTSData = this.getView().getModel("oTSModel").getData();
			var aFilteredTS = aTSData.filter(obj => {
				return obj.Docno === oLineItemsData.Docno &&
					obj.Mjahr === oLineItemsData.Mjahr &&
					obj.Zeile === oLineItemsData.Zeile &&
					obj.JobId === oLineItemsData.JobId &&
					obj.Sno === oLineItemsData.Sno;
			});
			// this.TimeSheetData = oData;
			//	var oTSTable = this.timesheetDataObjectDisplay(aFilteredTS);
			if (aFilteredTS.length > 0) {

				oBody.push(this.getPDFCrewTimeSheet(oLineItemsData, aFilteredTS, iRowLength));
			}

		},

		getPDFCrewTimeSheet: function (oLineItemData, aTimesheetRecords, iRowLength) {

			var months = ["Jan'", "Feb'", "Mar'", "Apr'", "May'", "Jun'", "Jul'", "Aug'", "Sept'", "Oct'", "Nov'", "Dec'"];
			//var months = [ "01/", "02/", "03/", "04/", "05/", "06/","07/", "08/", "09/", "10/", "11/", "12/" ];
			var oTempRecord;
			var aColoumnUniqueArray = [];
			var aColumnsWidth = [];
			var aRowUniqueArray = [];
			var aColumnObjectArray = [];
			var aRowUniqueObjectArray = [];
			var iColumnCount;
			var sTempColName;
			var oTempCol;
			var sDay, sMonth, sYear, sID, sDate;
			for (var x = 0; x < aTimesheetRecords.length; x++) {
				oTempRecord = aTimesheetRecords[x];
				sTempColName = "";

				if (oTempRecord.TsDate) {
					sDay = oTempRecord.TsDate.getDate();
					sMonth = oTempRecord.TsDate.getMonth();
					sYear = oTempRecord.TsDate.getFullYear();
					sDate = this.formatStringDateAramco(oTempRecord.TsDate);

					sID = oTempRecord.Id;
					oTempCol = {
						day: sDay,
						month: sMonth,
						year: sYear,
						date: sDate,
						colName: months[oTempRecord.TsDate.getMonth()] + oTempRecord.TsDate.getDate()
					};
				}

				//chartObjectHdr[Day] = true;
				if (!aColoumnUniqueArray.includes(oTempCol.colName)) {
					aColoumnUniqueArray.push(oTempCol.colName);
					aColumnObjectArray.push(oTempCol);
				}

				if (!aRowUniqueArray.includes(oTempRecord.Id)) {
					aRowUniqueArray.push(oTempRecord.Id);
					aRowUniqueObjectArray.push(oTempRecord);
				}

			}
			var oSummaryReportData = aTimesheetRecords;
			var aColomns = [];
			var sHeaderBGColor = "#84bd00";

			if (oLineItemData.JobLog === "JL0001") {
				aColomns.push({
					text: "ID / Equipment No.",
					bold: true,
					fillColor: sHeaderBGColor,
					alignment: 'center',
					style: 'small'
				});
			} else {
				aColomns.push({
					text: "ID / Equipment No.",
					bold: true,
					fillColor: sHeaderBGColor,
					alignment: 'center',
					style: 'small'
				});
				aColomns.push({
					text: "Name / Equipment Desc",
					bold: true,
					fillColor: sHeaderBGColor,
					alignment: 'center',
					style: 'small'
				});
				aColomns.push({
					text: "Job Title",
					bold: true,
					fillColor: sHeaderBGColor,
					alignment: 'center',
					style: 'small'
				});
			}
			// aColomns.push({ text: "UOM", bold: true ,fillColor: '#0040ff',color:"#ffffff" , alignment: 'center'});
			//var aColoumnUniqueArray = this.aUniqueSummaryColomns ;
			for (var j = 0; j < aColumnObjectArray.length; j++) {
				aColomns.push({
					text: aColumnObjectArray[j].colName,
					bold: true,
					fillColor: sHeaderBGColor,
					alignment: 'center',
					style: 'small'
				});
			}

			aColomns.push({
				text: "Reference ID",
				bold: true,
				fillColor: sHeaderBGColor,
				alignment: 'center',
				style: 'small'
			});

			var oBody = [aColomns];
			var aColumnsWidth = [];
			var iColumnCount = aColoumnUniqueArray.length;

			var oType = new sap.ui.model.odata.type.DateTime({
				pattern: "MM/dd/yyyy"
			});

			//var oParentTableRow =  this.getView().getModel("JobLogPopUpModel").getData()['nodes'][0];
			/*var oList = this.getView().getModel("TimesheetModels").getBindings()[0]['oList'];
			var oReportData = oList;*/

			var oReportData = aTimesheetRecords;

			// IDs
			for (var x = 0; x < aRowUniqueObjectArray.length; x++) {
				var aRow = [];

				if (oLineItemData.JobLog === "JL0001") {
					aRow.push({
						text: aRowUniqueObjectArray[x].Id,
						style: 'small'
					});
				} else {
					aRow.push({
						text: aRowUniqueObjectArray[x].Id,
						style: 'small'
					});
					aRow.push({
						text: aRowUniqueObjectArray[x].Name,
						style: 'small'
					});
					aRow.push({
						text: aRowUniqueObjectArray[x].JobTitle,
						style: 'small'
					});
				}
				//loop through all the unique colomns (Dates)
				for (var y = 0; y < aColumnObjectArray.length; y++) {
					//look for data that matches date and value
					for (var z = 0; z < oReportData.length; z++) {
						if (oReportData[z].Id === aRowUniqueObjectArray[x].Id && this.formatStringDateAramco(oReportData[z].TsDate) ===
							aColumnObjectArray[y].date) {
							aRow.push({
								text: oReportData[z].Duration,
								style: 'small'
							});
						}
					}
				}

				var oIdGrp = aRowUniqueObjectArray[x].IdGroup;
				if (oIdGrp == '9999999999' || oIdGrp == aRowUniqueObjectArray[x].Id) {
					oIdGrp = '';
				}
				aRow.push({
					text: oIdGrp,
					style: 'small'
				});
				oBody.push(aRow);

			}
			aColumnsWidth.push("*");
			aColumnsWidth.push("*");
			aColumnsWidth.push("*");

			for (var j = 0; j < (iColumnCount); j++) {
				aColumnsWidth.push(22);
			}
			aColumnsWidth.push(100);
			return [{
				stack: [{
					text: "Timesheet",
					bold: true,
					alignment: 'center',
					fontSize: 11
				}, {
					table: {
						headerRows: 1,
						widths: aColumnsWidth,
						body: oBody
					}
				}],
				colSpan: iRowLength,
				margin: [0, 10, 0, 0]
			}];

		},
		////////////////////// end of detail pdf   /////////////

		getTVDReport: function (oTVDModel, oTabSelKey) {
			//var oTVDModel = this.getView().getModel("oTVDModel").getData();
			var aColomns = [{
				text: "SNo",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			}];
			aColomns.push({
				text: "Status",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Start Date",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Section/Lateral",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Run Number",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});

			if (oTabSelKey === "Tvd") {
				aColomns.push({
					text: "MD",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
				aColomns.push({
					text: "TVD",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
				aColomns.push({
					text: "Drilled Footage",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});

			} else {
				aColomns.push({
					text: "Sensor",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
				aColomns.push({
					text: "Offset From Bit",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
			}

			aColomns.push({
				text: "Classification",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "BHA#",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			if (oTabSelKey === "Tvd") {
				aColomns.push({
					text: "Previous Section MD",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
				aColomns.push({
					text: "Previous Section TVD",
					bold: true,
					fillColor: '#0040ff',
					color: "#ffffff",
					alignment: 'center',
					style: 'medium'
				});
			}
			aColomns.push({
				text: "Action By",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Foreman Comments",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			var oBody = [
				aColomns
			];
			var aColumnsWidth = [];
			var oTableItems = oTVDModel;
			for (var oItem = 0; oItem < oTableItems.length; oItem++) {
				var aRow = [];
				aRow.push({
					text: oTableItems[oItem]['Seqno'],
					style: 'small',
					alignment: 'left'
				});
				aRow.push({
					text: oTableItems[oItem]['StatusText'],
					style: 'small',
					alignment: 'center'
				});
				//	aRow.push({ text: oTableItems[oItem]['FrDate'], style: 'small', alignment: 'left' });
				if (oTableItems[oItem].FrDate !== null && typeof oTableItems[oItem].FrDate !== "undefined") {
					var sSDateSplit = oTableItems[oItem].FrDate.toLocaleString('fr', {
						hour12: false
					}).split(' ');
					aRow.push({
						text: this.dateMonthFormat(sSDateSplit[0]),
						style: 'small',
						alignment: 'left'
					});

				} else {
					aRow.push({
						text: oTableItems[oItem].FrDate,
						style: 'small',
						alignment: 'left'
					});
				}
				aRow.push({
					text: oTableItems[oItem]['HoleSize'],
					style: 'small',
					alignment: 'left'
				});
				aRow.push({
					text: oTableItems[oItem]['RunNo'],
					style: 'small',
					alignment: 'left'
				});

				if (oTabSelKey === "Tvd") {
					aRow.push({
						text: oTableItems[oItem]['Md'],
						style: 'small',
						alignment: 'left'
					});
					aRow.push({
						text: oTableItems[oItem]['Tvd'],
						style: 'small',
						alignment: 'left'
					});
					aRow.push({
						text: oTableItems[oItem]['DrillFtg'],
						style: 'small',
						alignment: 'left'
					});
				} else {
					aRow.push({
						text: oTableItems[oItem]['Sensor'],
						style: 'small',
						alignment: 'left'
					});
					aRow.push({
						text: oTableItems[oItem]['Soffset'],
						style: 'small',
						alignment: 'left'
					});
				}

				aRow.push({
					text: oTableItems[oItem]['Classification'],
					style: 'small',
					alignment: 'left'
				});
				aRow.push({
					text: oTableItems[oItem]['Bha'],
					style: 'small',
					alignment: 'left'
				});
				if (oTabSelKey === "Tvd") {
					aRow.push({
						text: oTableItems[oItem]['PrevMd'],
						style: 'small',
						alignment: 'left'
					});
					aRow.push({
						text: oTableItems[oItem]['PrevTvd'],
						style: 'small',
						alignment: 'left'
					});
				}
				aRow.push({
					text: oTableItems[oItem]['ActionBy'],
					style: 'small',
					alignment: 'left'
				});
				aRow.push({
					text: oTableItems[oItem]['RejCmnt'],
					style: 'small',
					alignment: 'left'
				});
				// comments
				oBody.push(aRow);
			}

			aColumnsWidth.push(30);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(60);
			aColumnsWidth.push(150);

			if (oTabSelKey === "Tvd") {
				return {
					table: {
						headerRows: 1,
						body: oBody,
						widths: aColumnsWidth,
					},
					pageBreak: 'after'
				}
			} else {
				return {
					table: {
						headerRows: 1,
						body: oBody

					},
					pageBreak: 'after'

				}
			}
		},

		getSaudizationReport: function (oSaudizationModel) {
			oSaudizationModel = oSaudizationModel.getData();
			//var oTVDModel = this.getView().getModel("oTVDModel").getData();
			var aColomns = [{
				text: "Year",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			}];
			aColomns.push({
				text: "Month",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Saudi Employees",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Total Employees",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});
			aColomns.push({
				text: "Saudi%",
				bold: true,
				fillColor: '#0040ff',
				color: "#ffffff",
				alignment: 'center',
				style: 'medium'
			});

			var oBody = [
				aColomns
			];
			var aColumnsWidth = [];
			var oTableItems = oSaudizationModel;
			for (var oItem = 0; oItem < oTableItems.length; oItem++) {
				var aRow = [];
				aRow.push({
					text: oTableItems[oItem]['Zyear'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['Zmonth'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['SaudiTot'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['ManpowerTot'],
					style: 'small',
					alignment: 'center'
				});
				aRow.push({
					text: oTableItems[oItem]['SaudizationPer'],
					style: 'small',
					alignment: 'center'
				});
				oBody.push(aRow);
			}
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			aColumnsWidth.push(100);
			return {
				table: {
					headerRows: 1,
					widths: aColumnsWidth,
					body: oBody
				},
				pageBreak: 'after'
			}
		},

		onServiceOrderModifyPress: function () {
			var oReq = this.getView().getModel("itemsModel").getData();
			if (oReq.EstSdt > oReq.EstEdt) {
				sap.m.MessageBox.error("Estimate End Date cannot be less than Estimate Start Date", {
					title: "Error",
				});
				return;
			}

			return new Promise(function (resolve, reject) {
				var errorCheck = this.checkValidation();

				if (errorCheck.length > 0) {
					reject();
					return;

				}

				MessageBox.warning("This Service Order will be updated. Do you want to continue ?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: "sapUiSizeCompact",
					onClose: function (sAction) {
						if (sAction === "YES") {
							this._onServOrderModifyPress();
						}
					}.bind(this)
				});

			}.bind(this));

		},

		_onServOrderModifyPress: function () {
			var oModel = this.getView().getModel("oDataModel");
			var oReq = this.getView().getModel("itemsModel").getData();
			oModel.callFunction("/VendorEstDate", {
				method: "GET",
				urlParameters: {
					Docno: oReq.Docno,
					Mjahr: oReq.Mjahr,
					estsdt: oReq.EstSdt,
					estedt: oReq.EstEdt,
					vendrefno: oReq.VendRefNo,
					Comments: ''
				},
				success: function (oData) {
					sap.m.MessageBox.success("Service Order " + oData.Docno + " was updated successful", {
						title: "Revision of Service Order"
					});
					this.getRouter().navTo("Inbox");
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			})
		},

		onJobTypeeTicketChange: function (oEvent) {
			this.getView().getModel("oETicketModel").getData().RddJobType = oEvent.getParameter("selectedItem").getProperty("key");
		},

		onRddUnitValueHelp: function (oEvent) {
			var aFilters = [];
			aFilters.push(new Filter("Field", FilterOperator.EQ, "ORGEH"));
			this.getView().getModel("VendorService").read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					var oModel = new JSONModel(oData);
					if (!this.RddUnit) {
						this.RddUnit = sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.RDDDialog", this);
					}
					this.RddUnit.setModel(oModel, "RDDUnit");
					this.RddUnit.open();
				}.bind(this),
				error: function (oResponse) {

				}.bind(this)
			});
		},

		RDDhandleClose: function (evt) {
			var getItem = evt.getParameter("selectedItem").getBindingContext("RDDUnit").getObject();
			this.getView().getModel("oETicketModel").getData().RddUnit = getItem.Descr1;
			this.getView().getModel("oETicketModel").refresh();

		},

		/*		onMaxlengthCheckMobileNo: function (oEvent) {
					if (oEvent.getParameter("value") === "") {
						sap.ui.getCore().byId(oEvent.getParameter("id")).setValue("0");
						return;
					}

					if (oEvent.getParameter("value").length > 10) {
						sap.m.MessageBox.error("Please enter a valid number");
						sap.ui.getCore().byId(oEvent.getParameter("id")).setValue("0");
						return;
					}
				},*/

		onRddUnitChange: function (oEvent) {
			if (oEvent.getParameter("value") === "") {
				sap.ui.getCore().byId(oEvent.getParameter("id")).setValue("00000000");
				return;
			}

			if (oEvent.getParameter("value").length > 8) {
				sap.m.MessageBox.error("Please enter a valid org code");
				sap.ui.getCore().byId(oEvent.getParameter("id")).setValue("00000000");
				return;
			}
		},

		onRddUserIdSearchValueHelp: function (evt) {
			if (!this.RddUserIdSearchHelpDialog) {
				this.RddUserIdSearchHelpDialog = sap.ui.xmlfragment(this.getView().getId(), "zdwo_nx_drss_ven.view.fragment.RddETicket_UserId",
					this);
				this.getView().addDependent(this.RddUserIdSearchHelpDialog);
			}

			var aFilters = [];
			aFilters.push(new Filter("Field", FilterOperator.EQ, "RDDENG"),
				new Filter("Maxhit", FilterOperator.EQ, "100"));
			this.getView().getModel("VendorService").read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					var oModel = new JSONModel(oData.results);
					this.RddUserIdSearchHelpDialog.setModel(oModel, "UserIdListModel");
					this.RddUserIdSearchHelpDialog.open();
				}.bind(this),
				error: function (oResponse) {

				}.bind(this)
			});
		},

		onRddUserIdExeucte: function (evt) {
			var aFilters = [];
			aFilters.push(new Filter("Field", FilterOperator.EQ, "RDDENG"));

			var data = this.getView().getModel("SearchModel").getData();
			if (data.NetworkId !== "") {
				aFilters.push(new Filter("Descr1", FilterOperator.EQ, data.NetworkId));
			}

			if (data.Uname !== "") {
				aFilters.push(new Filter("Descr2", FilterOperator.EQ, data.Uname));
			}

			if (data.Mail !== "") {
				aFilters.push(new Filter("Descr3", FilterOperator.EQ, data.Mail));
			}

			if (data.Maxhit !== "") {
				aFilters.push(new Filter("Maxhit", FilterOperator.EQ, data.Maxhit));
			}

			this.getView().getModel("VendorService").read("/F4SearchHelpSet", {
				filters: aFilters,
				success: function (oData) {
					this.RddUserIdSearchHelpDialog.getModel("UserIdListModel").setData(oData.results);
					this.RddUserIdSearchHelpDialog.getModel("UserIdListModel").refresh(true);
				}.bind(this),
				error: function (oResponse) {

				}.bind(this)
			});
		},

		onRiggUserSearchSelected: function (evt) {
			var getItem = evt.getParameter("listItem").getModel("UserIdListModel").getProperty(evt.getParameter("listItem").getBindingContextPath());
			this.getView().getModel("oETicketModel").getData().RddEng = getItem.Descr1;
			this.getView().getModel("oETicketModel").refresh();
			this.RddUserIdSearchHelpDialog.close();

		},

		onSearchValueInSearchHelp: function (evt) {
			var oTable = evt.getSource().getParent().getParent();
			var oBinding = oTable.getBinding("items");
			var value = evt.getSource().getValue().trim().toUpperCase();
			var filters = evt.getSource().data();
			var aFilters = [];
			var oFilters = [];
			if (value !== "") {
				for (var key in filters) {
					aFilters.push(new Filter({
						path: filters[key],
						operator: FilterOperator.Contains,
						value1: value,
						caseSensitive: false
					}));
				}
				oFilters.push(new sap.ui.model.Filter(aFilters));
			}
			oBinding.filter(oFilters);
			//this.getView().getModel("UserIdListModel").setProperty("/noRigs", oBinding.aIndices.length);
		},

		//Allow only mobile number
		onMaxlengthCheckMobileNo: function (evt) {
			var val = evt.getParameter("newValue");
			val = val.replace(/[^\d]/g, '');
			var first2Chars = val.substr(0, 2);
			if (first2Chars.length === 1 && first2Chars === "0") {
				evt.getSource().setValue(val);
			} else if (first2Chars.length === 2) {
				if (first2Chars === "05") {
					evt.getSource().setValue(val);
				} else {
					evt.getSource().setValue(first2Chars.substr(0, 1));
				}
			} else {
				evt.getSource().setValue("");
			}
		},

		FormsListCall: function () {
			// var oModel = this.getView().getModel("VendorService");
			var oModel = this.getView().getModel("oReqHeaderSetModel");
			var aFilters = [];
			var serviceCode = this.getView().getModel("itemsModel").getData().SrvtypeCode;

			aFilters.push(new Filter("Docno", FilterOperator.EQ, this.DrssNo),
				new Filter("Mjahr", FilterOperator.EQ, this.Mjahr),
				new Filter("FormLevel", FilterOperator.EQ, "I"),
				new Filter("SrvtypeCode", FilterOperator.EQ, serviceCode));
			oModel.read("/ServiceFormsSet", {
				filters: aFilters,
				success: function (oData) {
					this.getView().getModel("itemsModel").getData().FormsList = oData.results;
					this.getView().getModel("itemsModel").refresh();
				}.bind(this),
				error: function (oResponse) {
					var msgs = this.getErrorMessages(oResponse);
				}.bind(this)
			});
		},

		timesheetPress: function (oEvent) {
			var data = oEvent.getSource().getParent().getParent().getBindingContext("itemsModel").getObject("").ItemToDrssTSNav;

			if (oEvent.getSource().getParent().getParent().getBindingContext("itemsModel").getObject("").ServLtext === "" &&
				oEvent.getSource().getParent().getParent().getBindingContext("itemsModel").getObject("").DelInd === "") {
				sap.m.MessageBox.error("Service Name cannot be empty");
				return;
			}

			if (oEvent.getSource().getParent().getParent().getBindingContext("itemsModel").getObject("").Meins === "" &&
				oEvent.getSource().getParent().getParent().getBindingContext("itemsModel").getObject("").DelInd === "") {
				sap.m.MessageBox.error("Service UoM cannot be empty");
				return;
			}

			this.TimesheetEditable = false;

			if (this.TimesheetEditable === false && (data.length === undefined || data.length === 0)) {
				sap.m.MessageBox.error("No timesheet data available");
				return;
			}

			if (!this.timesheetDialog) {
				this.timesheetDialog = sap.ui.xmlfragment("zdwo_nx_drss_ven.view.fragment.JobLogging.TimesheetDisplay", this);

			}
			this.getView().addDependent(this.timesheetDialog);
			//this.onTimesheetDateCapturePopUp(this.TimeSheetData);

			//this.TimesheetDataEntryPath = oEvent.getSource().getParent().getParent().getBindingContextPath();

			this.timesheetDataObject(data);
			this.timesheetDialog.open();

			/*if(data === undefined){
									this.onTimesheetDateCapturePopUp();
									return;
								}
			
								if (data.length === undefined) {
									this.onTimesheetDateCapturePopUp();
								} else {
									if (data.length > 0) {
										this.timesheetDataObject(data);
										this.timesheetDialog.open(); 
									} else {
										this.onTimesheetDateCapturePopUp();
									}

								}*/
		},

		onCloseTimesheet: function (oEvent) {
			this.timesheetDialog.close();
			this.getView().getModel("TimesheetModels").refresh(true);
		},

		timesheetDataObject: function (oEvent) {
			var datesArray = [];
			var datesArrayCol = [];
			//var data = this.getView().getModel("dateValidate").getData();
			var months = ["Jan'", "Feb'", "Mar'", "Apr'", "May'", "Jun'", "Jul'", "Aug'", "Sept'", "Oct'", "Nov'", "Dec'"];
			//var months = [ "01/", "02/", "03/", "04/", "05/", "06/","07/", "08/", "09/", "10/", "11/", "12/" ];
			const listDate = [];
			const startDate = oEvent[0].TsDate;
			const endDate = oEvent[oEvent.length - 1].TsDate;
			const dateMove = new Date(startDate);
			let strDate = startDate;

			for (var m = moment(startDate); m.isBefore(endDate); m.add(1, 'days')) {
				listDate.push(new Date(m.format('YYYY-MM-DD')));
			}
			listDate.push(endDate);

			for (var i = 0; i < listDate.length; i++) {
				if (listDate[i]) {
					var chartObject = {
						Id: "",
						Name: "",
						JobTitle: ""
					}
					var Day = months[listDate[i].getMonth()] + listDate[i].getDate();
					chartObject[Day] = '0.00';
					chartObject.ColName = months[listDate[i].getMonth()] + listDate[i].getDate();
					datesArrayCol.push(chartObject);
				}
			}

			var resArr = [];
			oEvent.filter(function (item) {
				var i = resArr.findIndex(x => (x.Id == item.Id));
				if (i <= -1) {
					resArr.push(item);
				}
				return null;
			});

			for (var j = 0; j < resArr.length; j++) {
				resArr[j] = JSON.parse(JSON.stringify(resArr[j]));
				for (var i = 0; i < listDate.length; i++) {
					if (listDate[i]) {
						var Day = months[listDate[i].getMonth()] + listDate[i].getDate();
						this.date = this.formatStringDateAramco(listDate[i]);
						/*var Duration = [];
						oEvent.filter(function(item){
						  var i = Duration.findIndex(x => ((x.Id === item.Id)));
						  if(i <= -1){
							  Duration.push(item);
						  }
						  return null;
						});*/

						for (var k = 0; k < oEvent.length; k++) {
							if (resArr[j].Id === oEvent[k].Id && this.date === this.formatStringDateAramco(oEvent[k].TsDate)) {
								//resArr[j][Day] = oEvent[k].Duration;
								resArr[j][Day] = parseFloat(oEvent[k].Duration).toFixed(3);
							}
						}

						//;
						//
						resArr[j].ColName = months[listDate[i].getMonth()] + listDate[i].getDate();

					}
				}
				datesArray.push(resArr[j]);
			}

			var uniqueArray = datesArray.reduce((filter, current) => {
				var dk = filter.find(item => (item.Id === current.Id && this.formatStringDateAramco(item.TsDate) === this.formatStringDateAramco(
					current.TsDate)));
				if (!dk) {
					return filter.concat([current]);
				} else {
					var value = current.ColName;
					dk[value] = dk.Duration;
					return filter;
				}
			}, []);

			var ColoumnUniqueArray = datesArrayCol.reduce((filter, current) => {
				var cdk = filter.find(item => item.ColName === current.ColName);
				if (!cdk) {
					return filter.concat([current]);
				} else {
					return filter;
				}
			}, []);

			this.aUniqueSummaryColomns = ColoumnUniqueArray;
			this.getView().getModel("TimesheetModels").setData(null);
			this.getView().getModel("TimesheetModels").setData(uniqueArray);
			this.getView().getModel("TimesheetModels").refresh(true);

			var param1 = "TimesheetModels>Id";
			var param2 = "TimesheetModels>IdGroup";
			var oTable = sap.ui.getCore().byId("idTimesheetTableDisplay");
			oTable.destroyColumns();
			var oCell = [];

			/*if (this.getView().getModel("JobLogPopUpModel").getData().JobLog === 'JL0001') {
				var oColumn = new sap.m.Column({
					width: "5rem",
					header: new sap.m.Label({
						text: "ID / Equipment No."
					})
				});
				oTable.addColumn(oColumn);

				var cell1 = new sap.m.Input({
					value: "{TimesheetModels>Id}",
					editable: {
						parts: [{
							path: param1
						}, {
							path: param2
						}],
						formatter: this.editableFlag
					},
					maxLength: 10,
					visible: "{= (${TimesheetModels>Id} !== '9999999999')}",
					change: this.TimesheetIdChange
				});
				oCell.push(cell1);

			} else {*/
			var oColumn = new sap.m.Column({
				width: "5rem",
				header: new sap.m.Label({
					text: "ID / Equipment No."
				})
			});
			oTable.addColumn(oColumn);

			var cell1 = new sap.m.Input({
				value: "{TimesheetModels>Id}",
				maxLength: 10,
				enabled: this.TimesheetEditable,
				visible: "{= (${TimesheetModels>Id} !== '9999999999')}"
			});
			oCell.push(cell1);

			var oColumn = new sap.m.Column({
				width: "10rem",
				header: new sap.m.Label({
					text: "Name / Equipment Desc"
				})
			});
			oTable.addColumn(oColumn);

			var cell1 = new sap.m.Input({
				value: "{TimesheetModels>Name}",
				maxLength: 50,
				enabled: this.TimesheetEditable,
				visible: "{= (${TimesheetModels>Id} !== '9999999999')}"
			});
			oCell.push(cell1);

			var oColumn = new sap.m.Column({
				width: "10rem",
				header: new sap.m.Label({
					text: "Job Title"
				})
			});
			oTable.addColumn(oColumn);

			var cell1 = new sap.m.Input({
				value: "{TimesheetModels>JobTitle}",
				maxLength: 50,
				enabled: this.TimesheetEditable,
				editable: "{= (${TimesheetModels>Id} !== '9999999999')}"
			});
			oCell.push(cell1);

			/*}*/

			for (var j = 0; j < ColoumnUniqueArray.length; j++) {

				var ColoumnName = (ColoumnUniqueArray[j].ColName).replaceAll("Jan'", "01/").replaceAll("Feb'", "02/").replaceAll("Mar'", "03/").replaceAll(
					"Apr'", "04/").replaceAll("May'", "05/").replaceAll("Jun'", "06/").replaceAll("Jul'", "07/").replaceAll("Aug'", "08/").replaceAll(
					"Sept'", "09/").replaceAll("Oct'", "10/").replaceAll("Nov'", "11/").replaceAll("Dec'", "12/")

				oColumn = new sap.m.Column({
					width: "4rem",
					header: new sap.m.Label({
						text: ColoumnName
					})
				});
				oTable.addColumn(oColumn);

				cell1 = new sap.m.Input({
					value: "{TimesheetModels>" + ColoumnUniqueArray[j].ColName + "}",
					type: sap.m.InputType.Number,
					enabled: this.TimesheetEditable,
					change: function (oEvent) {
						if (parseFloat(oEvent.getParameter("newValue")) > -1) {

						} else {
							sap.m.MessageBox.error("Please enter a valid value");
							sap.ui.getCore().byId(oEvent.getParameter("id")).setValue("0.00");
						}
					},
					maxLength: 5
				});
				oCell.push(cell1);

			}

			var oColumn = new sap.m.Column({
				width: "5rem",
				header: new sap.m.Label({
					text: "Reference ID"
				})
			});
			oTable.addColumn(oColumn);

			var cell1 = new sap.m.Text({
				text: "{TimesheetModels>IdGroup}",
				visible: "{= (${TimesheetModels>Id}) !== (${TimesheetModels>IdGroup})}"
			});
			oCell.push(cell1);

			var param1 = "TimesheetModels>Id";
			var param2 = "TimesheetModels>IdGroup";

			var oColumn = new sap.m.Column({
				width: "2rem",
				header: new sap.m.Label({
					text: ""
				})
			});
			oTable.addColumn(oColumn);

			var cell1 = new sap.m.Button({
				icon: "sap-icon://citizen-connect",
				type: "Emphasized",
				tooltip: "Add Replacement",
				visible: this.TimesheetEditable,
				press: function (oEvent) {
					var oRecord = oEvent.getSource().getBindingContext('TimesheetModels').getObject();
					if (oRecord.Id === "") {
						sap.m.MessageBox.error("Please enter ID to proceed with Replacement");
						return;
					}
					this.TimesheetPath = oEvent.getSource().getBindingContext('TimesheetModels');
					controller.TimesheetPath = oEvent.getSource().getBindingContext('TimesheetModels');
					this.oRecord = oRecord.Id;
					controller.oRecord = oRecord.Id;
					this.onTimesheetConformation();
				}.bind(this)
			});
			oCell.push(cell1);

			var aColList = new sap.m.ColumnListItem({
				cells: oCell
			});

			var oColumn = new sap.m.Column({
				width: "3rem",
				header: new sap.m.Label({
					text: ""
				})
			});
			oTable.addColumn(oColumn);

			var cell1 = new sap.m.Button({
				icon: "sap-icon://delete",
				type: "Reject",
				visible: this.TimesheetEditable,
				press: function (oEvent) {
					var oRecord = oEvent.getSource().getBindingContext('TimesheetModels').getObject();
					controller.oData = oEvent.getSource().getModel("TimesheetModels");
					//var oData = oEvent.getSource().getModel("TimesheetModels").getObject("/");	
					MessageBox.information("This Timesheet item will be deleted. Do you want to continue ?", {
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						styleClass: "sapUiSizeCompact",
						onClose: function (sAction) {
							if (sAction === "YES") {
								var oData = controller.oData.getData();
								for (var i = 0; i < oData.length; i++) {
									if (oData[i] == oRecord) {
										if (oRecord.Sno) {
											if (oRecord.Sno !== '') {
												controller.DeleteTimesheetEntry(oRecord);
												oData.splice(i, 1);
												controller.oData.refresh();
												break;
											}
										} else {
											oData.splice(i, 1);
											controller.oData.refresh();
											break;
										}

									}
								}

								var oTimesheetCount = 0;
								for (var i = 0; i < oData.length; i++) {
									if (oRecord.IdGroup === oData[i].IdGroup) {
										oTimesheetCount += parseInt(1)
									}
								}
								if (oTimesheetCount === 1) {
									for (var i = 0; i < oData.length; i++) {
										if (oRecord.IdGroup === oData[i].IdGroup) {
											oData[i].IdGroup = "";
										}
									}
								}
								controller.oData.refresh();
							}
						}.bind(this)
					});
				}
			});
			oCell.push(cell1);

			var aColList = new sap.m.ColumnListItem({
				cells: oCell
			});

			oTable.bindAggregation("items", {
				path: "TimesheetModels>/",
				template: aColList
			});

		},

		/*onGenConsPDFJob : function(){
			
			controller.oForemanPdf = "";
            this.onConsolidatedPdfAll();
            controller.oForemanPdf = "X"
            this.onConsolidatedPdfAll();
			controller.ForemanBase64;
            controller.VendorBase64;
            var oETicketModel = this.getView().getModel("oETicketModel");
            var oData = oETicketModel.getData();
            this._postForemanConSubmit(oData.Version,oData.Docno);
		    this._postVendorConSubmit(oData.Version,oData.Docno);
		},*/

		MorningReport: function () {
			var oFilter = [new sap.ui.model.Filter("Docno", "EQ", this.itemDetails.DrssNo),
				new sap.ui.model.Filter("Mjahr", "EQ", this.itemDetails.Mjahr)
			];
			this.getView().setBusy(true);
			this.getView().getModel("VendorService").read("/MorningReportSet", {
				filters: oFilter,
				success: function (oData) {
					var MorningReportModel = new JSONModel(oData.results);
					this.getView().setModel(MorningReportModel, "MorningReportModel");
					this.getView().setBusy(false);
				}.bind(this),
				error: function (oError) {
					this.getView().setBusy(false);
				}.bind(this)
			});
		},

		onPressRequestForCancellation: function (oEvent) {
			var oTextArea = new sap.m.TextArea({
				width: "100%",
				placeholder: "Remarks (required)",
				liveChange: function (oEvent) {
					this.sText = oEvent.getParameter("value");
					this.oSubmitDialog.getBeginButton().setEnabled(this.sText.length > 0);
				}.bind(this)
			});
			this.oSubmitDialog = new sap.m.Dialog({
				type: sap.m.DialogType.Message,
				title: "Confirm",
				content: [
					new sap.m.Label({
						text: "Do you want to continue ?",
						labelFor: "submissionNote"
					}),
					oTextArea
				],
				beginButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: "Submit",
					enabled: false,
					press: function (evt) {
						this.applyRequestForCancellation(oTextArea.getProperty("value"));
					}.bind(this)
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function () {
						this.oSubmitDialog.close();
					}.bind(this)
				})
			});
			this.oSubmitDialog.open();
		},

		applyRequestForCancellation: function (sComments) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Updating...'
			});
			busyDialog.open();
			var oModel = this.getView().getModel("VendorService");
			oModel.callFunction("/VendorRequest", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr,
					Flag: 'C',
					Comments: sComments
				},
				success: function (oData) {
					busyDialog.close();
					MessageBox.success("Request submitted for cancellation successfully", {
						actions: [MessageBox.Action.CLOSE],
						onClose: function () {
							this.oSubmitDialog.close();
							this.onPageRefresh();
						}.bind(this)
					});

				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		onPressRecallCancellation: function (oEvent) {
			var busyDialog = new sap.m.BusyDialog({
				title: 'Updating...'
			});
			busyDialog.open();
			var oModel = this.getView().getModel("VendorService");
			oModel.callFunction("/VendorRequest", {
				method: "GET",
				urlParameters: {
					Docno: this.DrssNo,
					Mjahr: this.Mjahr,
					Flag: 'R',
					Comments: ''
				},
				success: function (oData) {
					busyDialog.close();
					MessageBox.success("Request for cancellation recalled successfully", {
						actions: [MessageBox.Action.CLOSE],
						onClose: function () {
							this.onPageRefresh();
						}.bind(this)
					});

				}.bind(this),
				error: function (error) {
					busyDialog.close();
					var msgs = this.getErrorMessages(error);
					this.instantiateErrorMessageModel(msgs);
					this.createMessagePopoverModel();
				}.bind(this)
			});
		},

		formateReqForCancellationBtn: function (bReqReject, sCancel) {
			return (bReqReject !== 'X' && sCancel === true);
		},
		formateRecallCancellationBtn: function (bReqReject, sCancel) {
			return (bReqReject === 'X' && sCancel === true);
		}

		/*onLogginTypeTableRowsUpdated: function(oEvent) {
			var sTableId = oEvent.getSource().getId().split("--")[2];
			var aRows = this.byId(sTableId).getRows();
			for (var i = 0; i< aRows.length; i++) {
				var oRowBindingContext = aRows[i].getRowBindingContext();
				if (oRowBindingContext) {
					var bServiceId = aRows[i].getRowBindingContext().getObject().ServiceId;
					var bFillServiceFlag = aRows[i].getRowBindingContext().getObject().FillServiceFlag;
					if(bServiceId === "") {
						$("#" + aRows[i].sId).addClass("ui-table-row-bg-color");
					} else {
						$("#" + aRows[i].sId).removeClass("ui-table-row-bg-color");
					}
					
					if(bFillServiceFlag === "False") {
						$("#" + aRows[i].sId).addClass("ui-table-row-bg-color_filled");
					} else {
						$("#" + aRows[i].sId).removeClass("ui-table-row-bg-color_filled");
					}
				}
			}
		},*/

	});
});