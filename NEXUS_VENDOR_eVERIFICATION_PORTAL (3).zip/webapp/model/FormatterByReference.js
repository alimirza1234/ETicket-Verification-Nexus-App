sap.ui.define([], function () {
	return {
			uploadEnabled : function (formStatus){
				//debugger;
				
				
			}
		}
	
}, true);