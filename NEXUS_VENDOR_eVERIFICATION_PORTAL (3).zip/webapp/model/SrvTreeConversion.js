sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
], function (BaseObject, JSONModel) {
	"use strict";
	return {

		prepareTree: function (oData) {

			oData.results = oData.results.filter(item => item.SrvtypeCode !== "");

			this.level1 = [];
			var aHier = [];
			//this.key =true;
			var aHierReturn = [];
			var aFlatNodes = [];
			var oFlat = {};
			var oParent = null;
			var iNodeLevel = 1;
			$.each(oData.results, function (ind, obj) {
					var i = 1;
					if (obj.PackageLevel1 === "00" && obj.PackageLevel2 === "00") { // No Tree
						aHier[obj.ServStext] = {
							text: obj.ServStext,
							children: [],
							ServLtext: obj.ServLtext,
							ServStext: obj.ServStext,
							SrvtypeCode: obj.SrvtypeCode,
							selected: false,
							ServiceId: obj.ServiceId,
							txtVisible: true
						};
					} else {
						//Level 1
						if (!aHier["L1" + obj.PackageLevel1] && obj.PackageLevel1 !== "00") { // level 1 = 01
							aHier["L1" + obj.PackageLevel1] = {
								text: obj.Pkg1Desc,
								SrvtypeCode: obj.SrvtypeCode,
								children: [],
								txtVisible: true,
								selected: false
							};
						}
						//Level 2

						oParent = aHier["L1" + obj.PackageLevel1];
						if (oParent && !oParent.children["L2" + obj.PackageLevel2] && obj.PackageLevel2 !== "00") { // level 2 = 01
							oParent.children["L2" + obj.PackageLevel2] = {
								text: obj.Pkg2Desc,
								SrvtypeCode: obj.SrvtypeCode,
								children: [],
								txtVisible: false,
								selected: false
							};
						}

						//Level 3
						if (oParent) {
							oParent = aHier["L1" + obj.PackageLevel1].children["L2" + obj.PackageLevel2];
							if (oParent && !oParent.children["L3" + obj.PackageLevel3] && obj.PackageLevel3 !== "00") {
								oParent.children["L3" + obj.PackageLevel3] = {
									text: obj.Pkg3Desc,
									SrvtypeCode: obj.SrvtypeCode,
									children: [],
									txtVisible: false,
									selected: false
								};
							}
						}
						//Level 4
						if (oParent) {
							oParent = aHier["L1" + obj.PackageLevel1].children["L2" + obj.PackageLevel2].children["L3" + obj.PackageLevel3];
							if (oParent && !oParent.children["L4" + obj.PackageLevel4] && obj.PackageLevel4 !== "00") {
								oParent.children["L4" + obj.PackageLevel4] = {
									text: obj.Pkg4Desc,
									SrvtypeCode: obj.SrvtypeCode,
									children: [],
									txtVisible: false,
									selected: false
								};
							}
						}
						//Level 5
						if (oParent) {
							oParent = aHier["L1" + obj.PackageLevel1].children["L2" + obj.PackageLevel2].children["L3" + obj.PackageLevel3].children["L4" +
								obj.PackageLevel4];
							if (oParent && !oParent.children["L5" + obj.PackageLevel5] && obj.PackageLevel5 !== "00") {
								oParent.children["L5" + obj.PackageLevel5] = {
									text: obj.Pkg5Desc,
									SrvtypeCode: obj.SrvtypeCode,
									children: [],
									txtVisible: false,
									selected: false
								};
							}
						}

						//Find node level
						if (obj.PackageLevel1 === "00") {
							var serviceText = "";
							if (obj.ServLtext === "") {
								serviceText = obj.ServStext;
							} else {
								serviceText = obj.ServLtext;
							}

							aHier[obj.ServStext] = {
								text: serviceText,
								children: [],
								ServLtext: serviceText,
								ServStext: obj.ServStext,
								Serviceid: obj.ServiceId,
								SrvtypeCode: obj.SrvtypeCode,
								selected: false,
								UOM: obj.Uom,
								btnVisible: false,
								txtVisible: true
							};

						} else {
							if (obj.PackageLevel2 === "00") {
								oParent = aHier["L1" + obj.PackageLevel1];
								var serviceText = "";
								if (obj.ServLtext === "") {
									serviceText = obj.ServStext;
								} else {
									serviceText = obj.ServLtext;
								}
								oParent.children.push({
									text: serviceText,
									children: [],
									ServLtext: serviceText,
									ServStext: obj.ServStext,
									Serviceid: obj.ServiceId,
									SrvtypeCode: obj.SrvtypeCode,
									selected: false,
									UOM: obj.Uom,
									btnVisible: false,
									txtVisible: true
								});
							} else {
								if (obj.PackageLevel3 === "00") {

									oParent = aHier["L1" + obj.PackageLevel1].children["L2" + obj.PackageLevel2];
									var serviceText = "";
									if (obj.ServLtext === "") {
										serviceText = obj.ServStext;
									} else {
										serviceText = obj.ServLtext;
									}
									oParent.children[obj.ServStext] = {
										text: serviceText,
										children: [],
										ServLtext: serviceText,
										ServStext: obj.ServStext,
										Serviceid: obj.ServiceId,
										SrvtypeCode: obj.SrvtypeCode,
										selected: false,
										UOM: obj.Uom,
										btnVisible: false,
										txtVisible: true
									};
								} else {
									if (obj.PackageLevel4 === "00") {
										oParent = aHier["L1" + obj.PackageLevel1].children["L2" + obj.PackageLevel2].children["L3" + obj.PackageLevel3];
										var serviceText = "";
										if (obj.ServLtext === "") {
											serviceText = obj.ServStext;
										} else {
											serviceText = obj.ServLtext;
										}
										oParent.children[obj.ServStext] = {
											text: serviceText,
											children: [],
											ServLtext: serviceText,
											ServStext: obj.ServStext,
											Serviceid: obj.ServiceId,
											SrvtypeCode: obj.SrvtypeCode,
											selected: false,
											UOM: obj.Uom,
											btnVisible: false,
											txtVisible: true
										};
									} else {
										if (obj.PackageLevel5 === "00") {
											oParent = aHier["L1" + obj.PackageLevel1].children["L2" + obj.PackageLevel2].children["L3" + obj.PackageLevel3].children[
												"L4" + obj.PackageLevel4];
											var serviceText = "";
											if (obj.ServLtext === "") {
												serviceText = obj.ServStext;
											} else {
												serviceText = obj.ServLtext;
											}
											oParent.children[obj.ServStext] = {
												text: serviceText,
												children: [],
												ServLtext: serviceText,
												ServStext: obj.ServStext,
												Serviceid: obj.ServiceId,
												SrvtypeCode: obj.SrvtypeCode,
												selected: false,
												UOM: obj.Uom,
												btnVisible: false,
												txtVisible: true
											};
										} else {
											oParent = aHier["L1" + obj.PackageLevel1].children["L2" + obj.PackageLevel2].children["L3" + obj.PackageLevel3].children[
												"L4" + obj.PackageLevel4].children["L5" + obj.PackageLevel5];
											var serviceText = "";
											if (obj.ServLtext === "") {
												serviceText = obj.ServStext;
											} else {
												serviceText = obj.ServLtext;
											}
											oParent.children[obj.ServStext] = {
												text: serviceText,
												children: [],
												ServLtext: serviceText,
												ServStext: obj.ServStext,
												Serviceid: obj.ServiceId,
												SrvtypeCode: obj.SrvtypeCode,
												selected: false,
												UOM: obj.Uom,
												btnVisible: false,
												txtVisible: true
											};
										}
									}
								}
							}
						}
					}
				}.bind(this))
				//   if (this.key){
			this.data = [];
			for (var node in aHier) {
				if (aHier[node].Serviceid) {
					this.data.push(aHier[node]);
				} else {
					if (aHier[node].text !== '' && aHier[node].text !== undefined) {
						var oNode = {
							text: aHier[node].text,
							txtVisible: aHier[node].txtVisible,
							children: [],
							Serviceid: aHier[node].ServiceId
						};
						this.data.push(oNode);

						/*		var i = 0;
								var ind = 1;*/

						//get the last pushed Item
						var oL1Parent = this.data[this.data.length - 1];
						var aL2Children = aHier[node].children;
						for (var oL2Child in aL2Children) {
							if (aL2Children[oL2Child].Serviceid) {
								oL1Parent.children.push(aL2Children[oL2Child]);
							} else {
								if (aL2Children[oL2Child].text !== '' && aL2Children[oL2Child].text !== undefined) {
									oL1Parent.children.push({
										text: aL2Children[oL2Child].text,
										txtVisible: aL2Children[oL2Child].txtVisible,
										children: []
									})

									// third Level
									/*   var j=0;
					                   var ind1 = 1;*/
									var oL2Parent = oL1Parent.children[oL1Parent.children.length - 1];
									var aL3Children = aL2Children[oL2Child].children;
									for (var oL3Child in aL3Children) {
										/* j++;
					                       ind1 = ind1-1;
						                    if (j === 1){
							                  // oParent[oParent.length-1].children = [];
							                   oParent['children'] = [];
						                    }*/

										if (aL3Children[oL3Child].Serviceid) {
											oL2Parent['children'].push(aL3Children[oL3Child])
										} else {
											oL2Parent['children'].push({
													text: aL3Children[oL3Child].text,
													txtVisible: aL3Children[oL3Child].txtVisible,
													children: []
												})
												// fourth level
												/* var k = 0;*/
												// var oParent = oParent[oParent.length-1].children;
												// var oParent = nextChild2[node2];
											var oL4Parent = oL2Parent.children[oL2Parent.children.length - 1];
											var aL4Children = aL3Children[oL3Child].children;
											for (var oL4Child in aL4Children) {
												// k++;
												if (!oParent['children']) {
													// oParent[oParent.length-1].children = [];
													oParent['children'] = [];
												}
												if (aL4Children[oL4Child].Serviceid) {
													// oParent[oParent.length-1].children.push(nextChild3[node3])
													oL4Parent['children'].push(aL4Children[oL4Child]);
												} else {
													oL4Parent['children'].push({
														text: aL4Children[oL4Child].text,
														txtVisible: aL4Children[oL4Child].txtVisible,
														children: []
													})
												}
											}
										}
									}
									/* // Fifth level
	                            var n = 0;
	                            var oParent = oParent[oParent.length-1].children;
		                        var nextChild4 = nextChild3[node3].children;
								for(var node4 in nextChild4){
							       n++;
				                   if (n === 1){
					                   oParent[oParent.length-1].children = [];
			                           oParent[oParent.length-1].children.push(nextChild4[node4]);
				                    }else{
					                   oParent[oParent.length-1].children.push(nextChild4[node4])
				                    }
						     }*/
								}
							}
						}
					}
				}
			}

			var aFiltArr = [];
			$.each(this.data, function (ind, obj) {
				if (obj.children.length) {
					// Removed empty text from the array list
					aFiltArr.push(obj);
				}
			}.bind(this));

			console.log(aFiltArr);

			return aFiltArr;
		},

		buildTree: function (oData) {
			var oHier = {};
			var aHier = [];
			var sTempPath = "";
			$.each(oData.results, function (ind, obj) {
				sTempPath = "";
				if (!oHier[obj.SrvtypeCode]) {
					oHier[obj.SrvtypeCode] = {
						SrvtypeCode: obj.SrvtypeCode,
						SrvtypeDesc: obj.ServDesc,
						children: [],
						Checkbox: false
					};
				}

				if (obj.Pkg1Desc != "") {
					sTempPath += obj.Pkg1Desc;
				}
				if (obj.Pkg2Desc != "") {
					sTempPath += "--> " + obj.Pkg2Desc;
				}
				if (obj.Pkg3Desc != "") {
					sTempPath += "--> " + obj.Pkg3Desc;
				}
				if (obj.Pkg4Desc != "") {
					sTempPath += "--> " + obj.Pkg4Desc;
				}
				if (obj.Pkg5Desc != "") {
					sTempPath += "--> " + obj.Pkg5Desc;
				}

				if (obj.ServLtext !== "") {
					sTempPath += "--> " + obj.ServLtext;
				}

				if (obj.ServLtext == "") {
					sTempPath += "--> " + obj.ServStext;
				}

				oHier[obj.SrvtypeCode].children.push({
					Serviceid: obj.ServiceId,
					SrvtypeDesc: sTempPath,
					SrvtypeCode: obj.SrvtypeCode,
					RqType: obj.RqType,
					ServStext: obj.ServStext,
					UOM: obj.Uom,
					Checkbox: true,
					selected: false
				});

			});
			console.log(oHier);
			for (var ind in oHier) {
				aHier.push(oHier[ind])
			}

			/*			for (let key in yourobject) {
			               console.log(key, yourobject[key]);
			}
				*/
			console.log(aHier);
			return aHier;

		},

		//-------------------------------------------------------------------------------------------------------------------------------------

		prepareTreeforAll: function (oData) {
			oData.results = oData.results.filter(item => item.SrvtypeCode !== "");
			this.level1 = [];
			var aHier = [];
			var aHierReturn = [];
			var aFlatNodes = [];
			var oFlat = {};
			var oParent = null;
			var iNodeLevel = 1;
			$.each(oData.results, function (ind, obj) {
				var i = 1;
				/*if (!aHier[obj.SrvtypeCode] ){
					 aHier[obj.SrvtypeCode]  ={text:obj.ServStext , children:[], ServLtext: obj.ServLtext,
												 ServStext: obj.ServStext,
												 SrvtypeCode : obj.SrvtypeCode,
										         selected:false,
												 ServiceId :obj.ServiceId,
												 txtVisible:true };
				}*/

				if (!aHier[obj.SrvtypeCode]) {
					aHier[obj.SrvtypeCode] = {
						text: obj.ServStext,
						children: [],
						ServLtext: obj.ServLtext,
						ServStext: obj.ServStext,
						SrvtypeCode: obj.SrvtypeCode,
						ServDesc: obj.ServDesc,
						selected: false,
						ServiceId: obj.ServiceId,
						txtVisible: true
					};
				}

				if (obj.PackageLevel1 === "00" && obj.PackageLevel2 === "00") {
					aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc] = {
						text: obj.ServStext,
						children: [],
						ServLtext: obj.ServLtext,
						ServStext: obj.ServStext,
						SrvtypeCode: obj.SrvtypeCode,
						selected: false,
						ServiceId: obj.ServiceId,
						txtVisible: true
					};
				} else {
					//Level 1
					if (!aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc] && obj.Pkg1Desc !== "00") {
						aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc] = {
							text: obj.Pkg1Desc,
							SrvtypeCode: obj.SrvtypeCode,
							children: [],
							txtVisible: true,
							selected: false
						};
						//aFlatNodes.push({id: , text: , parentID:"" });
					}
					//Level 2
					oParent = aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc];
					if (oParent && !oParent.children["L2" + obj.Pkg2Desc] && obj.PackageLevel2 !== "00") {
						oParent.children["L2" + obj.Pkg2Desc] = {
							text: obj.Pkg2Desc,
							SrvtypeCode: obj.SrvtypeCode,
							children: [],
							txtVisible: false,
							selected: false
						};
					}

					//Level 3
					if (oParent) {
						oParent = aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc].children["L2" + obj.Pkg2Desc];
						if (oParent && !oParent.children["L3" + obj.Pkg3Desc] && obj.PackageLevel3 !== "00") {
							oParent.children["L3" + obj.Pkg3Desc] = {
								text: obj.Pkg3Desc,
								SrvtypeCode: obj.SrvtypeCode,
								children: [],
								txtVisible: false,
								selected: false
							};
						}
					}
					//Level 4
					if (oParent) {
						oParent = aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc].children["L2" + obj.Pkg2Desc].children["L3" + obj.Pkg3Desc];
						if (oParent && !oParent.children["L4" + obj.Pkg4Desc] && obj.PackageLevel4 !== "00") {
							oParent.children["L4" + obj.Pkg4Desc] = {
								text: obj.Pkg4Desc,
								SrvtypeCode: obj.SrvtypeCode,
								children: [],
								txtVisible: false,
								selected: false
							};
						}
					}
					//Level 5
					if (oParent) {
						oParent = aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc].children["L2" + obj.Pkg2Desc].children["L3" + obj.Pkg3Desc].children[
							"L4" + obj.Pkg4Desc];
						if (oParent && !oParent.children["L5" + obj.Pkg5Desc] && obj.PackageLevel5 !== "00") {
							oParent.children["L5" + obj.Pkg5Desc] = {
								text: obj.Pkg5Desc,
								SrvtypeCode: obj.SrvtypeCode,
								children: [],
								txtVisible: false,
								selected: false
							};
						}
					}

					/*				//Find node level
								if( obj.PackageLevel1 === "00"  ){
							        var serviceText = "";
							        if (obj.ServLtext === ""){
							           serviceText= obj.ServStext;
						            }else {
								       serviceText= obj.ServLtext;
						            }

							        aHier[obj.SrvtypeCode].ServStext  ={text:serviceText , children:[], ServLtext: serviceText,
								    ServStext: obj.ServStext,
									Serviceid:obj.ServiceId,
									SrvtypeCode : obj.SrvtypeCode,
									selected:false,
									UOM:obj.Uom,
									btnVisible:false,
									txtVisible:true };*/

					//Find node level
					if (obj.PackageLevel1 === "00" || obj.PackageLevel2 === "") {

						if (obj.PackageLevel2 === "") {
							var serviceText = "";
							if (obj.ServLtext === "") {
								serviceText = obj.ServStext;
							} else {
								serviceText = obj.ServLtext;
							}
							aHier[obj.SrvtypeCode] = {
								text: serviceText,
								children: [],
								ServLtext: serviceText,
								ServStext: obj.ServStext,
								Serviceid: obj.ServiceId,
								SrvtypeCode: obj.SrvtypeCode,
								ServDesc: obj.ServDesc,
								selected: false,
								UOM: obj.Uom,
								btnVisible: false,
								txtVisible: true
							};
						} else {
							var serviceText = "";
							if (obj.ServLtext === "") {
								serviceText = obj.ServStext;
							} else {
								serviceText = obj.ServLtext;
							}

							aHier[obj.SrvtypeCode][obj.ServStext] = {
								text: serviceText,
								children: [],
								ServLtext: serviceText,
								ServStext: obj.ServStext,
								Serviceid: obj.ServiceId,
								SrvtypeCode: obj.SrvtypeCode,
								selected: false,
								UOM: obj.Uom,
								btnVisible: false,
								txtVisible: true
							};

						}

					} else {
						if (obj.PackageLevel2 === "00") {
							oParent = aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc];
							var serviceText = "";
							if (obj.ServLtext === "") {
								serviceText = obj.ServStext;
							} else {
								serviceText = obj.ServLtext;
							}
							oParent.children.push({
								text: serviceText,
								children: [],
								ServLtext: serviceText,
								ServStext: obj.ServStext,
								Serviceid: obj.ServiceId,
								SrvtypeCode: obj.SrvtypeCode,
								selected: false,
								UOM: obj.Uom,
								btnVisible: false,
								txtVisible: true
							});
						} else {
							if (obj.PackageLevel3 === "00") {

								oParent = aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc].children["L2" + obj.Pkg2Desc];
								//	oParent = aHier[obj.SrvtypeCode].children["L1"+obj.Pkg1Desc];
								var serviceText = "";
								if (obj.ServLtext === "") {
									serviceText = obj.ServStext;
								} else {
									serviceText = obj.ServLtext;
								}
								oParent.children[obj.ServStext] = {
									text: serviceText,
									children: [],
									ServLtext: serviceText,
									ServStext: obj.ServStext,
									Serviceid: obj.ServiceId,
									SrvtypeCode: obj.SrvtypeCode,
									selected: false,
									UOM: obj.Uom,
									btnVisible: false,
									txtVisible: true
								};
							} else {
								if (obj.PackageLevel4 === "00") {
									oParent = aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc].children["L2" + obj.Pkg2Desc].children["L3" + obj.Pkg3Desc];
									//oParent = aHier[obj.SrvtypeCode].children["L1"+obj.PackageLevel1].children["L2"+obj.PackageLevel2]
									var serviceText = "";
									if (obj.ServLtext === "") {
										serviceText = obj.ServStext;
									} else {
										serviceText = obj.ServLtext;
									}
									oParent.children[obj.ServStext] = {
										text: serviceText,
										children: [],
										ServLtext: serviceText,
										ServStext: obj.ServStext,
										Serviceid: obj.ServiceId,
										SrvtypeCode: obj.SrvtypeCode,
										selected: false,
										UOM: obj.Uom,
										btnVisible: false,
										txtVisible: true
									};
								} else {
									if (obj.PackageLevel5 === "00") {
										// oParent = aHier[obj.SrvtypeCode].children["L1"+obj.PackageLevel1].children["L2"+obj.PackageLevel2].children["L3"+obj.PackageLevel3 ].children["L4"+obj.PackageLevel4 ];
										oParent = aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc].children["L2" + obj.Pkg2Desc].children["L3" + obj.Pkg3Desc];
										var serviceText = "";
										if (obj.ServLtext === "") {
											serviceText = obj.ServStext;
										} else {
											serviceText = obj.ServLtext;
										}
										oParent.children[obj.ServStext] = {
											text: serviceText,
											children: [],
											ServLtext: serviceText,
											ServStext: obj.ServStext,
											Serviceid: obj.ServiceId,
											SrvtypeCode: obj.SrvtypeCode,
											selected: false,
											UOM: obj.Uom,
											btnVisible: false,
											txtVisible: true
										};
									} else {
										//oParent = aHier[obj.SrvtypeCode].children["L1"+obj.PackageLevel1].children["L2"+obj.PackageLevel2].children["L3"+obj.PackageLevel3 ].children["L4"+obj.PackageLevel4 ].children["L5"+obj.PackageLevel5 ];
										oParent = aHier[obj.SrvtypeCode].children["L1" + obj.Pkg1Desc].children["L2" + obj.Pkg2Desc].children["L3" + obj.Pkg3Desc].children[
											"L4" + obj.Pkg4Desc]
										var serviceText = "";
										if (obj.ServLtext === "") {
											serviceText = obj.ServStext;
										} else {
											serviceText = obj.ServLtext;
										}
										oParent.children[obj.ServStext] = {
											text: serviceText,
											children: [],
											ServLtext: serviceText,
											ServStext: obj.ServStext,
											Serviceid: obj.ServiceId,
											SrvtypeCode: obj.SrvtypeCode,
											selected: false,
											UOM: obj.Uom,
											btnVisible: false,
											txtVisible: true
										};
									}
								}
							}
						}
					}
				}
			}.bind(this))

			console.log(aHier);
			//   if (this.key){
			this.data = [];
			for (var node in aHier) {
				if ((aHier[node].Serviceid && aHier[node].ServLtext !== "") || (aHier[node].Serviceid && aHier[node].ServStext !== "")) {
					this.data.push(aHier[node]);
				} else {
					if ((aHier[node].SrvtypeCode && aHier[node].SrvtypeCode !== '') && (aHier[node].ServLtext !== "" || aHier[node].ServStext !== "")) {
						// Level 0  DPDS
						var oNode = {
							text: aHier[node].ServDesc,
							txtVisible: aHier[node].txtVisible,
							children: [],
							Serviceid: aHier[node].ServiceId
						};
						this.data.push(oNode);

						// Level 1 Offshore - Shallow
						var oL0Parent = this.data[this.data.length - 1];
						var aL1Children = aHier[node].children;
						for (var oL1Child in aL1Children) {
							if (aL1Children[oL1Child].Serviceid) {
								oL0Parent.children.push(aL1Children[oL1Child]);
							} else {
								if (aL1Children[oL1Child].text && aL1Children[oL1Child].text !== '' && aL1Children[oL1Child].text !== undefined) {
									oL0Parent.children.push({
										text: aL1Children[oL1Child].text,
										txtVisible: aL1Children[oL1Child].txtVisible,
										children: [],
										Serviceid: aL1Children[oL1Child].ServiceId
									})

									// Level 2 Drilling
									//get the last pushed Item
									var oL1Parent = oL0Parent.children[oL0Parent.children.length - 1];
									var aL2Children = aL1Children[oL1Child].children;

									for (var oL2Child in aL2Children) {
										if (aL2Children[oL2Child].Serviceid) {
											oL1Parent.children.push(aL2Children[oL2Child]);
										} else {
											if (aL2Children[oL2Child].text && aL2Children[oL2Child].text !== '' && aL2Children[oL2Child].text !== undefined) {
												oL1Parent.children.push({
														text: aL2Children[oL2Child].text,
														txtVisible: aL2Children[oL2Child].txtVisible,
														children: []
													})
													// Level 3 Motor
												var oL2Parent = oL1Parent.children[oL1Parent.children.length - 1];
												var aL3Children = aL2Children[oL2Child].children;
												for (var oL3Child in aL3Children) {

													if (aL3Children[oL3Child].Serviceid) {
														oL2Parent['children'].push(aL3Children[oL3Child])
													} else {
														oL2Parent['children'].push({
															text: aL3Children[oL3Child].text,
															txtVisible: aL3Children[oL3Child].txtVisible,
															children: []
														})

														// Level 4 Motor to drill Medium Radius 12"-12-1/4" Hole size, footage below 2000'

														var oL3Parent = oL2Parent.children[oL2Parent.children.length - 1];
														var aL4Children = aL3Children[oL3Child].children;
														for (var oL4Child in aL4Children) {

															if (aL4Children[oL4Child].Serviceid) {
																oL3Parent['children'].push(aL4Children[oL4Child])
															} else {
																oL3Parent['children'].push({
																	text: aL4Children[oL4Child].text,
																	txtVisible: aL4Children[oL4Child].txtVisible,
																	children: []
																})

																var oL4Parent = oL3Parent.children[oL3Parent.children.length - 1];
																var aL5Children = aL4Children[oL4Child].children;
																for (var oL5Child in aL5Children) {

																	if (aL5Children[oL5Child].Serviceid) {
																		oL4Parent['children'].push(aL5Children[oL5Child])
																	} else {
																		oL4Parent['children'].push({
																			text: aL5Children[oL5Child].text,
																			txtVisible: aL5Children[oL5Child].txtVisible,
																			children: []
																		})
																	}
																}
															}
														}

													}
												}
											}
										}
									}

								}
							}
						}
					}
				}
			}

			var aFiltArr = [];
			$.each(this.data, function (ind, obj) {
				//if (obj.children.length){
				// Removed empty text from the array list
				aFiltArr.push(obj);
				//}
			}.bind(this));

			return aFiltArr;
		}

		/*ConvertData:function(item){
			
			 this.oConvData = [];
		     var pushedData = [];
			for (var node in item){
				if (item[node].children.length===0){
					this.oConvData.push(item[node]);
				}else{
					var obj = {"text":item[node].text, txtVisible:item[node].txtVisible, children:[]};
					for(var node1 in item[node].children){
						if (item[node].children.length===0){
					        this.oConvData.push(aHier[node]);
					}
				}
				
			}
			
			
		}*/

	}

});