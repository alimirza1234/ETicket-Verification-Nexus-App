sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		// Model for app view
		createAppView: function () {
			var oModel = new JSONModel({
				mode: "ShowHideMode",
				addEnabled: true,
				is_auth: false,
				ven_id: "",
				ven_name: "",
				savedDispFlag: true,
				navBackMTreeFlag: false,
				inv_show: false
			});
			return oModel;
		},

	};
});