sap.ui.define([], function () {
	"use strict";

	return {
		numberUnit: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		toggleCancelSOBTN: function (a) {
			var btn = this;
			btn.setVisible(true);

		},

		removeResults: function (data) {
			debugger;
			data = data.results;
			return data;

		},
		//nexus
		StatState: function (Rqstat) {
			switch (Rqstat) {
			case "":
				return "Warning";
				break;
			case "INIT":
				return "Warning";
				break;
			case "APRV":
				return "Success";
				break;
			case "APPR":
				return "Success";
				break;
			case "REVW":
				return "Success";
				break;
			case "RGIS":
				return "Success";
				break;
			case "SUBT":
				return "Warning";
				break;
			case "INPR":
				return "Warning";
				break;
			case "REJC":
				return "Error";
				break;
			case "REJT":
				return "Error";
				break;
			case "RECL":
				return "Error";
				break;
			default:
				return "None";
			}
		},
		//nexus
		StatCode: function (StatCode) {
			if (StatCode == "INIT") {
				return "To be submitted"
			} else if (StatCode == "SUBT") {
				return "Submitted"
			} else if (StatCode == "APRV") {
				return "Approved"
			} else if (StatCode == "REJC") {
				return "Rejected"
			} else {
				return ""
			}
		},

		//nexus
		status: function (e) {
			if (e == "Approved") {
				return "Success"
			} else if (e == "Rejected") {
				return "Warning"
			} else if (e == "Sos") {
				return "Warning"
			} else {
				return "Success"
			}
		},
		//Nexus invoice doc text
		AttachmentText: function (oResponse) {
			if (oResponse === "SAUD") {
				return "Saudization Certificate";
			} else if (oResponse === "VATC") {
				return "VAT Certificate";
			} else if (oResponse === "VATC") {
				return "VAT Certificate";
			} else if (oResponse === "NXIV") {
				return "Tax Invoice";
			} else if (oResponse === "ZEFR") {
				return "E-JobLogging";
			}

		},
		getTooltipText: function (sStatus, sAgentText) {
			if (sStatus && sStatus.length > 0) {
				return sStatus;
			} else {
				return sAgentText;
			}

		},

		//Summation of entered quantities
		quantityCount: function (items, status) {
			var count = 0;
			for (var i in items) {
				var item = items[i];

				count += parseFloat(item.Menge);
			}
			return parseFloat(count).toFixed(3);
		},

		//Summation of entered percentages
		percentageCount: function (items, status) {
			var count = 0;
			for (var i in items) {
				var item = items[i];
				var percentage = item.Percentage;
				count += (item.Percentage) * 1;
			}
			return count; //Math.round(count)+"%";
		},

		TotalNetValue: function (oMenge, Tbtwr) {
			var oNetPrice = "0.00";
			if (typeof oMenge !== "undefined" && oMenge !== "" && typeof Tbtwr !== "undefined" && Tbtwr !== "") {
				var oNetPrice = parseFloat(oMenge) * parseFloat(Tbtwr);
				oNetPrice = oNetPrice.toFixed(2);
			}
			return oNetPrice;
		},

		//Summation of net value
		netValueCount: function (items, Tbtwr) {
			var netValue = 0;
			for (var i in items) {
				var item = items[i];
				if (typeof item.Menge !== "undefined" && item.Menge !== "" && typeof Tbtwr !== "undefined" && Tbtwr !== "") {
					netValue += parseFloat(item.Menge) * parseFloat(Tbtwr);
				}
			}
			return parseFloat(netValue).toFixed(2);
		},

		onAccAssState: function (Menge, oAccAssItem) {
			debugger;

			var totalQuantity = 0;
			var oState = "";
			for (var record in oAccAssItem['results']) {
				totalQuantity += parseFloat(oAccAssItem['results'][record]['Menge']);
			}
			//totalQuantity = Math.round(totalQuantity);
			if (parseFloat(totalQuantity) === parseFloat(Menge)) {
				oState = "Success";
			} else {
				oState = "Warning";
			}
			return oState;

		},

		onAccAssText: function (Menge, oAccAssItem) {
			debugger;
			var totalQuantity = 0;
			var oState = "";
			for (var record in oAccAssItem['results']) {
				totalQuantity += parseFloat(oAccAssItem['results'][record]['Menge']);
			}
			//totalQuantity = Math.round(totalQuantity);
			if (parseFloat(totalQuantity) === parseFloat(Menge)) {
				oState = "Done";
			} else {
				oState = "Pending";
			}
			return oState;

		},

		// NPO Status
		onAccAssRefState: function (oAccAssItem) {
			var oState = "";
			var totalQuantity = 0;
			for (var record in oAccAssItem['results']) {
				totalQuantity += parseFloat(oAccAssItem['results'][record]['Menge']);
			}

			if (parseFloat(totalQuantity) > 0) {
				oState = "Success";
			} else {
				oState = "Warning";
			}
			return oState;
		},

		onAccAssRefText: function (oAccAssItem) {

			var oStateText = "";
			var totalQuantity = 0;
			for (var record in oAccAssItem['results']) {
				totalQuantity += parseFloat(oAccAssItem['results'][record]['Menge']);
			}

			if (parseFloat(totalQuantity) > 0) {
				oStateText = "Done";
			} else {
				oStateText = "Pending";
			}

			return oStateText;
		},

		getStatusIcon: function (oResponse) {
			debugger;
			if (oResponse === "Negative") {
				return "sap-icon://decline";
			} else if (oResponse === "Positive") {
				return "sap-icon://accept";
			} else if (oResponse === "Critical") {
				return "sap-icon://pending";
			} else {
				return "sap-icon://employee";
			}

		},

		numberUnitQty: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(3);
		},

		setVehicleInspectionSelection: function (status, taxiDisp) {
			if (taxiDisp === "X") {
				return true;
			} else {
				if (status === "DSUB" || status === "ACKG" || status === "APPR") {
					return false;
				}
			}

			/*else{
				if(taxiDisp === 'X'){
					return true;	
				}
				else{
					return false;
				}
			}*/
		},

		ChngtypeDesc: function (Chngtype) {
			if (Chngtype === "HDR") {
				return "Header";
			}
			if (Chngtype === "ITM") {
				return "Item";
			} else {
				return "";
			}
		},

		CommentsColor: function (sColor) {
			if (sColor === "") {
				return "#031E48";
			} else {
				return "#18c560";
			}

		},

		setStatusText: function (Status, StatusText) {
			if (Status === "") {
				return "New";
			}
			if (Status === "SAVE") {
				return "Draft";
			} else {
				return StatusText;
			}
		},

		seFormType: function (formType) {
			if (formType === "AF") {
				return "Attachment";
			} else if (formType === "EF") {
				return "eForm"
			} else {
				return formType;
			}
		},

		Disp_filledFormatter: function (sDispFlag) {
			if (sDispFlag === "X") {
				return "Accept";
			}

			return "Reject";
		},

		setMasterPageDeleteMode: function (status, taxiDisp) {
			if ((status === "SAVE" || status === "REJT" || status === "RECL" || status === "") && taxiDisp === 'X') {
				return true;
			} else {
				return false;
			}
		},

		setVIAttachVisibleDelete: function (Status, TaxiDisp) {
			if (TaxiDisp === "X") {
				if (Status === "REJT" || Status === "SAVE" || Status === "RECL") {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},

		setVehicleInspectionHeaderKeyDisplayMode: function (status, taxiDisp) {
			if (taxiDisp === 'X') {
				return true;
			} else {
				return false;
			}
		},
		setVehicleInspectionHeaderDisplayMode: function (status, taxiDisp) {
			if ((status === "" || status === "SAVE" || status === "RECL")) {
				return true;
			} else {
				return false;
			}
			/*			if(taxiDisp === 'X'){
							if(status === "DSUB"){
								return false;	
							}
							else{
								return true;
							}
						}
						else{
							return false;
						}	*/
		},

		setVehicleInspectionDisplayMode: function (status, taxiDisp) {
			if (status === "DSUB" || status === "ACKG" || status === "APPR") {
				return false;
			} else {
				if (taxiDisp === 'X') {
					return true;
				} else {
					return false;
				}
			}
		},

		setManPowerDisplayMode: function (status, taxiDisp) {
			if (status === "DSUB" || status === "ACKG" || status === "APPR") {
				return false;
			} else {
				if (taxiDisp === 'X') {
					return true;
				} else {
					return false;
				}
			}
		},

		setManPowerTableHeaderCheckBoxes: function (status, taxiDisp, date, vendor, ManPowerSet) {
			if (date === null || vendor === "" || ManPowerSet.length === 0) {
				return false;
			} else {
				if (status === "DSUB" || status === "ACKG" || status === "APPR") {
					return false;
				} else {
					if (taxiDisp === 'X' && ManPowerSet.length > 0) {
						return true;
					} else {
						return false;
					}
				}
			}
		},

		setVehicleInspectionSubmitBtnVisible: function (status, VehInspItemSet, taxiDisp) {
			if (VehInspItemSet.length === 0) {
				return false
			} else {
				if (taxiDisp === "X") {
					if (status === "DSUB" || status === "ACKG" || status === "APPR") {
						return false;
					} else {
						return true;
					}
				} else {
					return false;
				}
			}

		},
		setVehicleInspectionSaveBtnVisible: function (status, VehInspItemSet, taxiDisp) {
			/*if(VehInspItemSet.length === 0){
				return false;
			}
			else{
				if(taxiDisp === "X"){
					if(status === "" || status === "SAVE" ){
						return true;
					}
					else{
						return false;
					}	
				}
				else{
					return false;
				}	
			}*/
			if (VehInspItemSet.length === 0) {
				return false
			} else {
				if (taxiDisp === "X") {
					if (status === "DSUB" || status === "ACKG" || status === "APPR") {
						return false;
					} else {
						return true;
					}
				} else {
					return false;
				}
			}

		},

		setVehicleInspectionCorrectiveActionSelection: function (status, taxiDisp, Pass) {
			if (status === "DSUB" || status === "ACKG" || status === "APPR") {
				return false;
			} else {
				if (taxiDisp === 'X') {
					if (Pass === "") {
						return true;
					} else {
						return false;
					}

				} else {
					return false;
				}
			}
		},

		setManPowerSubmitBtnVisible: function (status, taxiDisp) {
			if (taxiDisp === "X") {
				if (status === "DSUB" || status === "ACKG" || status === "APPR") {
					return false;
				} else {
					return true;
				}
			} else {
				return false;
			}
		},

		setVehicleInspectionRecallBtnVisible: function (status, taxiDisp) {
			if (taxiDisp === "X") {
				if (status === "DSUB") {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},

		setManPowerRecallBtnVisible: function (status, taxiDisp) {
			if (taxiDisp === "X") {
				if (status === "DSUB") {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},

		setVehicleInspectionAckBtnVisib: function (status, vendor) {
			if (status === "DSUB" && vendor.length > 0) {
				return true;
			} else {
				return false;
			}
		},

		setTimeSheetVisibility: function (reqStatus, date) {
			var status = false;
			if (reqStatus) {
				if (reqStatus === "SUBT") {
					status = false;
				} else {
					status = true;
				}
			}

			return status;
		},

		DeductionInd: function (Ind) {
			if (Ind === "X") {
				return "true";
			} else {
				return "false";
			}
		},

		currencyFromat: function (amt) {
			if (amt) {
				amt = amt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				return amt;
			}

		},

		setWFBtnsVisible: function (status, taxiGL) {
			if (taxiGL === "X") {
				if (status === "ACKG") {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},

		setActionColVisibility: function (ManPowerSet) {
			var visible = true;
			if (ManPowerSet && ManPowerSet.length > 0) {
				if (ManPowerSet[0].Status === "SUBT") {
					visible = false;
				} else {
					visible = true;
				}
			}

			return visible;
		},

		removeLeadingZerosService: function (sNum) {
			sNum = parseInt(sNum);
			var data = "";
			if (sNum > 0) {
				data = 'Services :' + (sNum).toString();
			}
			return data;
		},

		removeLeadingZerosOperation: function (sNum) {
			sNum = parseInt(sNum);
			var data = "";
			if (sNum > 0) {
				data = '  Operations :' + (sNum).toString();
			}
			return data;
		},

		EformFlagFormatter: function (sNum) {
			sNum = parseInt(sNum);
			var data = "";
			if (sNum > 0) {
				data = '   e-Form :' + (sNum).toString();
			}
			return data;
		},

		removeLeadingZeros: function (sNum) {
			sNum = parseInt(sNum);
			return (sNum).toString();
		},

		formTypeFormatter: function (formCode) {
			switch (formCode) {
			case "VI":
				return "Vehicle Inspection";
				break;
			case "MPI":
				return "Manpower";
				break;
			}
		},

		dateTimeJoiner: function (oDate, oTime) {
			if (oDate === null || typeof oDate === "undefined" || oTime === null || typeof oTime === "undefined") {
				return;
			}
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			if (!isNaN(oTime)) {
				oDate.setMilliseconds(oTime + TZOffsetMs);
			}
			oDate.setMilliseconds(oTime.ms + TZOffsetMs);
			return oDate;
		},

		dateTimeJoinerInbox: function (oDate, oTime) {
			if (oDate === null || typeof oDate === "undefined" || oTime === null || typeof oTime === "undefined") {
				return;
			}
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			if (!isNaN(oTime)) {
				oDate.setMilliseconds(oTime + TZOffsetMs);
			}
			oDate.setMilliseconds(oTime.ms + TZOffsetMs);
			var dateTime = (oDate.getMonth() + 1) + "/" + oDate.getDate() + "/" + oDate.getFullYear() + ' ' + oDate.toISOString().split("T")[1];
			return dateTime;
		},

		RemarksFormatter: function (Remarks) {
			if (Remarks && Remarks === "") {
				return false;
			} else {
				return true;
			}
		},

		setWFRemarksVisible: function (Remarks, Action) {
			if (Remarks === "" && Action === "") {
				return false;
			} else {
				return true;
			}
		},

		formatStringDateAramco: function (oStrDate) {
			if (oStrDate instanceof Date) {
				var sFinalDate = (oStrDate.getMonth() + 1) + "/" + oStrDate.getDate() + "/" + oStrDate.getFullYear();

				return sFinalDate;
			} else if ((oStrDate === null) || (oStrDate === 'undefined') || (oStrDate === undefined)) {
				// Do Nothing
			} else {
				var st = oStrDate.split("T");
				var oVal = st[0];
				sFinalDate = oVal.substr(5, 2) + "/" + oVal.substr(8, 2) + "/" + oVal.substr(0, 4);
			}
		},

		setCostCenterVisibility: function (visible, Rqtype) {
			return (visible && Rqtype === 'EXD');
		},

		setFieldGroupId: function (required, visible) {
			if (visible) {
				if (required) {
					return "Mandatory";
				} else {
					return null;
				}
			} else {
				return null;
			}
		},

		setPageTitle: function (description, docNo) {
			var title = description;
			if (docNo !== "") {
				title += " - " + docNo;
			} else {
				title += " - New";
			}

			return title;
		},

		ActionColor: function (Action) {
			if (Action === "01") {
				return sap.m.ButtonType.Emphasized;
			} else if (Action === "02") {
				return sap.m.ButtonType.Negative;
			} else if (Action === "12") {
				return sap.m.ButtonType.Negative;
			} else {
				return sap.m.ButtonType.Success;
			}
		},
		ActionColorWaterWell: function (Action) {
			if (Action === "01") {
				return sap.m.ButtonType.Success; //sap.m.ButtonType.Emphasized;
			} else if (Action === "02") {
				return sap.m.ButtonType.Negative;
			} else if (Action === "12") {
				return sap.m.ButtonType.Negative;
			} else if (Action === "05") { // return
				return sap.m.ButtonType.Critical;
			} else {
				return sap.m.ButtonType.Success;
			}
		},
		ActionIconWaterWell: function (Action) {
			if (Action === "05") { // return
				return "sap-icon://undo";
			} else {
				return "";
			}
		},

		ButtonActionColor: function (Action) {
			if (Action === "Default") {
				return sap.m.ButtonType.Emphasized;
			} else if (Action === "Reject") {
				return sap.m.ButtonType.Negative;
			} else {
				return sap.m.ButtonType.Success;
			}
		},

		setButtonVisible: function (lineItem, list) {
			var index = list.indexOf(lineItem);
			if (index > -1) {
				if (list.length === 1) {
					return false;
				} else {
					if (lineItem === list[list.length - 1]) {
						return true;
					} else {
						return false;
					}
				}
			} else {
				return false;
			}
		},

		totalCostCalculation: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						total += parseFloat(cost[i].TotalAmount)
					}
					total = (total).toFixed(2);
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		JLStatus: function (Rqstat) {
			switch (Rqstat) {
			case "":
				return "To be submitted";
				break;
			case "INIT":
				return "To be submitted";
				break;
			case "APRV":
				return "Approved";
				break;
			case "APPR":
				return "Approved";
				break;
			case "SUBT":
				return "Submitted";
				break;
			case "REJC":
				return "Rejected";
				break;
			case "REJT":
				return "Rejected";
				break;
			case "RECL":
				return "Recalled";
				break;
			case "REVW":
				return "Reviewed";
				break;
			case "INPR":
				return "In Progress";
				break;
			case "RGIS":
				return "Reviewed By GIS";
				break;
			case "empty":
				return "";
				break;
			default:
				return "None";
			}
		},

		JLStatusState: function (Rqstat) {
			switch (Rqstat) {
			case "":
				return "Warning";
				break;
			case "INIT":
				return "Warning";
				break;
			case "APRV":
				return "Success";
				break;
			case "APPR":
				return "Success";
				break;
			case "REVW":
				return "Success";
				break;
			case "RGIS":
				return "Success";
				break;
			case "SUBT":
				return "Warning";
				break;
			case "INPR":
				return "Warning";
				break;
			case "REJC":
				return "Error";
				break;
			case "REJT":
				return "Error";
				break;
			case "RECL":
				return "Error";
				break;
			default:
				return "None";
			}
		},

		totalDiscountCalculation: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var Discounts = 0;
					for (var i = 0; i < cost.length; i++) {
						Discounts += parseFloat(cost[i].Discounts)
					}
					Discounts = (Discounts).toFixed(2);
					Discounts = Discounts.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return Discounts;
				}
			}
		},

		totalSurchageCalculation: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var Surcharge = 0;
					for (var i = 0; i < cost.length; i++) {
						Surcharge += parseFloat(cost[i].Surcharge)
					}
					Surcharge = (Surcharge).toFixed(2);
					Surcharge = Surcharge.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return Surcharge;
				}
			}
		},

		totalNetCalculation: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var Surcharge = 0;
					var Discounts = 0;
					var total = 0;
					var totalNetVal = 0;
					for (var i = 0; i < cost.length; i++) {
						total += parseFloat(cost[i].TotalAmount)
						Surcharge += parseFloat(cost[i].Surcharge)
						Discounts += parseFloat(cost[i].Discounts)
					}
					totalNetVal = ((total + Surcharge) - Discounts);
					totalNetVal = (totalNetVal).toFixed(2);
					totalNetVal = totalNetVal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return totalNetVal;
				}
			}
		},

		setDelPassengerButtonVisible: function (lineItem, list, rqstat) {
			if (rqstat !== "INIT" && rqstat !== "" && rqstat !== "CLSD" && rqstat !== "RECL") {
				return false;
			} else {
				var index = list.indexOf(lineItem);
				if (index > -1) {
					if (list.length === 1) {
						return false;
					} else {
						if (lineItem === list[list.length - 1]) {
							return true;
						} else {
							return false;
						}
					}
				} else {
					return false;
				}
			}
		},

		setMessageStripItemAttachVisibility: function (docNo) {
			if (docNo === "New" || docNo === "") {
				return true;
			} else {
				return false;
			}

		},

		deleteService: function (delInd) {
			if (delInd === "V") {
				return "Marked for deletion by Vendor";
			} else if (delInd === "F") {
				return "Marked for deletion by Foreman";
			} else {
				return "";
			}
		},

		inspTypeFormatter: function (inspType) {
			if (inspType == "CCH") {
				return "Checklist";

			} else if (inspType == "FIN") {
				return "Final";
			}
		},

		setItemUploadEnabled: function (docNo, rqStat) {
			if (rqStat === "INIT" || rqStat === "RECL") {
				return true;
			} else {
				return false;
			}
		},

		fontClass: function (fClass) {
			if (fClass == "") {
				return "";
			} else {
				return "newText";
			}
		},

		getMSRequsetStatusTxt: function (Rqstat) {
			var sReqStatusTxt = "";
			switch (Rqstat) {
			case "RS":
				sReqStatusTxt = "Request Sent"; // request sent to other vendors by the market share	
				break;
			case "RR":
				sReqStatusTxt = "Response Recieved"; // response revieved from a vendor		
				break;
			default:
				sReqStatusTxt = "";
				break;
			}

			return sReqStatusTxt;
		},
		PriorityTxt: function (sPriority) {
			var sPriorityText = "";
			switch (sPriority) {
			case "1":
				sPriorityText = "Hold";
				break;
			case "2":
				sPriorityText = "Normal";
				break;
			case "3":
				sPriorityText = "Taxi hot";
				break;
			case "4":
				sPriorityText = "Pickup";
				break;
			case "5":
				sPriorityText = "Emergency";
				break;
			default:
				break;
			}

			return sPriorityText;

		},
		PriorityState: function (sPriority) {

			switch (sPriority) {
			case "1":
				return "Information";
				break;
			case "2":
				return "None";
				break;
			case "3":
				return "None";
				break;
			case "4":
				return "Warning";
				break;
			case "5":
				return "Error";
				break;
			default:
				return "None";
			}
		},

		getMSRelevantTxt: function (Ind) {
			if (Ind === "X" || Ind === true) {
				return "Yes";
			} else {
				return "No";
			}
		},

		getMSRelevantStatus: function (IndStatus) {
			if (IndStatus === "X" || IndStatus === true) {
				return "Information";
			} else {
				return "Warning";
			}
		},

		RequsetStatusTxt: function (Rqstat, Statustxt, Disflg) {
			var oDisFlag;
			if (Disflg) {
				oDisFlag = "Final";
			} else {
				oDisFlag = "Initial";
			}
			var sReqStatusTxt;
			switch (Rqstat) {
			case "":
				sReqStatusTxt = "New";
				break;

			case "00":
				sReqStatusTxt = "Draft";
				break;

			case "INIT":
				sReqStatusTxt = "Draft";
				break;

			case "PRCS":
				sReqStatusTxt = "In Progress";
				break;
			case "SUBT":
				return "Submitted";
				break;
			case "RSUB":
				return "Re-Submitted";
				break;
			case "COMP":
				sReqStatusTxt = "Accepted";
				break;

			case "CMPL":
				sReqStatusTxt = "Completed";
				break;

			case "COES":
				sReqStatusTxt = "Completed with Entry Sheet";
				break;

			case "CLSD":
				sReqStatusTxt = "Rejected";
				break;

			case "HOLD":
				sReqStatusTxt = "On Hold";
				break;

			case "CEUN":
				return "Completed with Unapproved Entry Sheet";
				break;

			case "CEAN":
				return "Completed with Approved Entry Sheet";
				break;
			case "JOBL":
				return "Job Logging";
				break;
			case "ETKT":
				return "eTicket Generated";
				break;
			case "ETKR":
				return "eTicket Rejected";
				break;
			case "ETRE":
				return "eTicket Recalled";
				break;
			case "CNCL":
				return "Cancelled";
				break;

			case "CLOS":
				return "Closed";
				break;

			case "NOIV":
				return "Completed";
				break;

			case "NSHW":
				return "Completed with no Show";
				break;
			case "VNSH":
				return "Vendor completed with no Show";
				break;
			case "ACPT":
				return "Accepted";
				break;
			case "RETN":
				return "Returned";
				break;
			case "REVS":
				return "Revised";
				break;
			case "CADU":
				return "CAD Updated";
				break;
			case "DPAP":
				return "Taxi Dispatcher Approved";
			case "DISP":
				return "Dispatched by Vendor";
			case "VCOM":
				return "Vendor Completed";
			case "RECL":
				return "Recalled";

			case "DREL":
				return "Recalled by dispatcher";
			case "RS":
				return "Request Sent"; // request sent to other vendors by the market share		
			case "RR":
				return "Response Recieved"; // response revieved from a vendor	
			case "CRT1":
				return "Pending With Certifier 1";
				break;
			case "CRT2":
				return "Pending With Certifier 2";
				break;
			case "CRT3":
				return "Pending With Certifier 3";
				break;
			case "CADV":
				return "Pending With CAD Verifier";
				break;
			case "CADR":
				return "Pending With CAD Reviewer";
				break;
			case "FAPR":
				return "Pending With Final Approver";
				break;
			case "SESG":
				return "SES Generated";
				break;
			case "RQRJ":
				return "Request for cancellation";
				break;
			case "INVP":
				return "Paid";
				break;
			case "RDGK":
				return "Pending With RDD Gate Keeper";
				break;
			case "CADD":
				return "Pending With CAD Distributor";
				break;
			case "FIRP":
				return "Pending with Finance Rej. Pool";
				break;
			case "RQEX":
				return "Requested for Extension";
				break;
			case "NRES":
				return "No Response";
				break;
			default:
				sReqStatusTxt = "Draft";
			}

			return sReqStatusTxt;
		},

		RequsetStatusState: function (Rqstat) {
			switch (Rqstat) {

			case "":
				return "Information";
				break;
			case "00":
				return "None";
				break;
			case "INIT":
				return "None";
				break;
			case "PRCS":
				return "Warning";
				break;
			case "SUBT":
				return "Warning";
				break;
			case "RSUB":
				return "Warning";
				break;
			case "RQEX":
				return "Warning";
				break;
			case "COMP":
				return "Success";
				break;
			case "CMPL":
				return "Success";
				break;
			case "CLSD":
				return "Error";
				break;
			case "HOLD":
				return "Error";
				break;
			case "CEUN":
				return "Success";
				break;
			case "CEAN":
				return "Success";
				break;
			case "CNCL":
				return "Error";
				break;
			case "NOIV":
				return "Success";
				break;
			case "NSHW":
				return "Error";
				break;
			case "VNSH":
				return "Error";
				break;
			case "CLOS":
				return "Error";
				break;
			case "ACPT":
				return "Success";
				break;
			case "RETN":
				return "Error";
				break;
			case "JOBL":
				return "Success";
				break;
			case "ETKT":
				return "Success";
				break;
			case "ETKR":
				return "Error";
				break;
			case "ETRE":
				return "Error";
				break;
			case "REVS":
				return "Warning";
				break;

			case "DPAP":
				return "Success";
			case "DISP":
				return "Success";
			case "VCOM":
				return "Success";
			case "RECL":
				return "Error";
			case "DREL":
				return "Error";
			case "CRT1":
				return "Warning";
				break;
			case "CRT2":
				return "Warning";
				break;
			case "CRT3":
				return "Warning";
				break;
			case "CADV":
				return "Warning";
				break;
			case "CADR":
				return "Warning";
				break;
			case "FAPR":
				return "Warning";
				break;
			case "SESG":
				return "Success";
				break;
			case "RQRJ":
				return "Error";
				break;
			case "INVP":
				return "Success";
				break;
			case "RDGK":
				return "Success";
				break;
			case "CADD":
				return "Success";
				break;
			case "FIRP":
				return "Success";
				break;
			default:
				return "None";
			}
		},

		TaxiRequsetStatusState: function (Rqstat) {
			switch (Rqstat) {
			case "00":
				return "None";
				break;
			case "INIT":
				return "None";
				break;
			case "PRCS":
				return "Warning";
				break;
			case "SUBT":
				return "Warning";
				break;
			case "RSUB":
				return "Warning";
				break;
			case "COMP":
				return "Success";
				break;
			case "CMPL":
				return "Success";
				break;
			case "CLSD":
				return "Indication01";
				break;
			case "HOLD":
				return "Indication01";
				break;
			case "CEUN":
				return "Success";
				break;
			case "CEAN":
				return "Success";
				break;
			case "CNCL":
				return "Indication01";
				break;
			case "NOIV":
				return "Success";
				break;
			case "NSHW":
				return "Indication01";
				break;
			case "VNSH":
				return "Indication01";
				break;
			case "CLOS":
				return "Indication01";
				break;
			case "ACPT":
				return "Success";
				break;
			case "JOBL":
				return "Success";
				break;
			case "ETKT":
				return "Success";
				break;
			case "ETKR":
				return "Error";
				break;
			case "ETRE":
				return "Error";
				break;
			case "RETN":
				return "Error";
				break;
			case "REVS":
				return "Warning";
				break;
			case "DPAP":
				return "Success";
			case "DISP":
				return "Success";
			case "VCOM":
				return "Success";
			case "RECL":
				return "Error";
			case "DREL":
				return "Error";
			case "CRT1":
				return "Warning";
				break;
			case "CRT2":
				return "Warning";
				break;
			case "CRT3":
				return "Warning";
				break;
			case "CADV":
				return "Warning";
				break;
			case "CADR":
				return "Warning";
				break;
			case "FAPR":
				return "Warning";
				break;
			case "SESG":
				return "Success";
				break;
			case "RQRJ":
				return "Error";
				break;
			case "INVP":
				return "Success";
				break;
			case "RDGK":
				return "Success";
				break;
			case "CADD":
				return "Success";
				break;
			case "FIRP":
				return "Success";
				break;
			default:
				return "None";
			}
		},

		FormFrequency: function (sFeq) {
			switch (sFeq) {
			case "01":
				return "Daily";
				break;
			case "02":
				return "Weekly";
				break;
			case "03":
				return "Monthly";
				break;
			case "04":
				return "Quaterly";
				break;
			case "05":
				return "Yearly";
				break;
			default:
				return "None";
			}
		},

		FormStatus: function (status) {
			var sReqStatusTxt = "";
			switch (status) {
			case "":
				sReqStatusTxt = "New";
				break;

			case "00":
				sReqStatusTxt = "Draft";
				break;

			case "INIT":
				sReqStatusTxt = "Draft";
				break;

			case "PRCS":
				sReqStatusTxt = "Submitted";
				break;
			case "SUBT":
				return "Submitted";
				break;
			case "RSUB":
				return "Re-Submitted";
				break;
			case "COMP":
				sReqStatusTxt = "Accepted";
				break;

			case "CMPL":
				sReqStatusTxt = "Completed";
				break;

			case "COES":
				sReqStatusTxt = "Completed with Entry Sheet";
				break;

			case "CLSD":
				sReqStatusTxt = "Rejected";
				break;

			case "HOLD":
				sReqStatusTxt = "On Hold";
				break;

			case "CEUN":
				return "Completed with Unapproved Entry Sheet";
				break;

			case "CEAN":
				return "Completed with Approved Entry Sheet";
				break;

			case "CNCL":
				return "Cancelled";
				break;

			case "CLOS":
				return "Closed";
				break;

			case "NOIV":
				return "Completed";
				break;

			case "NSHW":
				return "Completed with no Show";
				break;
			case "VNSH":
				return "Vendor completed with no Show";
				break;

			case "ACPT":
				return "Accepted";
				break;
			case "JOBL":
				return "Job Logging";
				break;
			case "ETKT":
				return "eTicket Generated";
				break;
			case "ETKR":
				return "eTicket Rejected";
				break;
			case "ETRE":
				return "eTicket Recalled";
				break;
			case "RETN":
				return "Returned";
				break;
			case "REVS":
				return "Revised";
				break;
			case "DPAP":
				return "Taxi Dispatcher Approved";
			case "DISP":
				return "Dispatched by Vendor";
			case "VCOM":
				return "Vendor Completed";
			case "RECL":
				return "Recalled";
			case "DREL":
				return "Recalled by dispatcher";
			case "01":
				return "Daily";
				break;
			case "02":
				return "Weekly";
				break;
			case "03":
				return "Monthly";
				break;
			case "04":
				return "Quaterly";
				break;
			case "05":
				return "Yearly";
				break;
			case "SUBA":
				return "Submitted without Approval";
				break;
			case "CRT1":
				return "Pending With Certifier 1";
				break;
			case "CRT2":
				return "Pending With Certifier 2";
				break;
			case "CRT3":
				return "Pending With Certifier 3";
				break;
			case "CADV":
				return "Pending With CAD Verifier";
				break;
			case "CADR":
				return "Pending With CAD Reviewer";
				break;
			case "FAPR":
				return "Pending With Final Approver";
				break;
			case "SESG":
				return "SES Generated";
				break;
			case "RQRJ":
				return "Request for cancellation";
				break;
			case "INVP":
				return "Paid";
				break;
			case "RDGK":
				return "Pending With RDD Gate Keeper";
				break;
			case "CADD":
				return "Pending With CAD Distributor";
				break;
			case "FIRP":
				return "Pending with Finance Rej. Pool";
				break;
			default:
				sReqStatusTxt = "Draft";
			}

			return sReqStatusTxt;
		},

		timeFormatter: function (time) {
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "hh:mm:ss a"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;

			if (time === null || typeof time === "undefined") {
				return "";
			}

			if (!isNaN(time)) {
				var timestr = timeFormat.format(new Date(time + TZOffsetMs));
				return timestr;
			}

			var timestr = timeFormat.format(new Date(time.ms + TZOffsetMs));
			return timestr;
		},

		RequsetStatus: function (Rqstat) {
			switch (Rqstat) {
			case "00":
				return "Draft";
				break;
			case "INIT":
				return "Draft";
				break;
			case "PRCS":
				return "In Process";
				break;
			case "SUBT":
				return "Submitted";
				break;
			case "RSUB":
				return "Re-Submitted";
				break;
			case "COMP":
				return "Accepted";
				break;
			case "CLSD":
				return "Rejected";
				break;
			case "HOLD":
				return "On Hold";
				break;
			case "CEUN":
				return "Completed with Unapproved Entry Sheet";
				break;
			case "CEAN":
				return "Completed with Approved Entry Sheet";
				break;
			case "CNCL":
				return "Cancelled";
				break;
			case "CLOS":
				return "Closed";
				break;
			case "NOIV":
				return "Completed";
				break;
			case "NSHW":
				return "Completed";
				break;
			case "VNSH":
				return "Completed";
				break;
			case "ACPT":
				return "Accepted";
				break;
			case "JOBL":
				return "Job Logging";
				break;
			case "ETKT":
				return "eTicket Generated";
				break;
			case "ETKR":
				return "eTicket Rejected";
				break;
			case "ETRE":
				return "eTicket Recalled";
				break;
			case "RETN":
				return "Returned";
				break;
			case "CMPL":
				return "Completed";
				break;
			case "REVS":
				return "Revised";
				break;
			case "DPAP":
				return "Approved by Taxi Dispatcher";
			case "DISP":
				return "Dispatched by Vendor";
			case "VCOM":
				return "Vendor Completed";
			case "RECL":
				return "Recalled";
			case "DREL":
				return "Recalled by dispatcher";
			case "CRT1":
				return "Pending With Certifier 1";
				break;
			case "CRT2":
				return "Pending With Certifier 2";
				break;
			case "CRT3":
				return "Pending With Certifier 3";
				break;
			case "CADV":
				return "Pending With CAD Verifier";
				break;
			case "CADR":
				return "Pending With CAD Reviewer";
				break;
			case "FAPR":
				return "Pending With Final Approver";
				break;
			case "SESG":
				return "SES Generated";
				break;
			case "RQRJ":
				return "Request for cancellation";
				break;
			case "INVP":
				return "Paid";
				break;
			case "RDGK":
				return "Pending With RDD Gate Keeper";
				break;
			case "CADD":
				return "Pending With CAD Distributor";
				break;
			case "FIRP":
				return "Pending with Finance Rej. Pool";
				break;
			default:
				return "Draft";
			}
		},

		RequsetStatusState: function (Rqstat) {
			switch (Rqstat) {
			case "00":
				return "None";
				break;
			case "INIT":
				return "None";
				break;
			case "PRCS":
				return "Warning";
				break;
			case "SUBT":
				return "Warning";
				break;
			case "RSUB":
				return "Warning";
				break;
			case "COMP":
				return "Success";
				break;
			case "CLSD":
				return "Error";
				break;
			case "HOLD":
				return "Error";
				break;
			case "CEUN":
				return "Success";
				break;
			case "CEAN":
				return "Success";
				break;
			case "CNCL":
				return "Error";
				break;
			case "CLOS":
				return "Error";
				break;
			case "NOIV":
				return "Error";
				break;
			case "NSHW":
				return "Error";
				break;
			case "VNSH":
				return "Error";
				break;
			case "ACPT":
				return "Success";
				break;
			case "JOBL":
				return "Success";
				break;
			case "ETKT":
				return "Success";
				break;
			case "ETKR":
				return "Error";
				break;
			case "ETRE":
				return "Error";
				break;
			case "RETN":
				return "Error";
				break;
			case "CMPL":
				return "Success";
				break;
			case "REVS":
				return "Warning";
				break;
			case "DPAP":
				return "Success";
			case "DISP":
				return "Success";
			case "VCOM":
				return "Success";
			case "RECL":
				return "Error";
			case "DREL":
				return "Error";
			case "CRT1":
				return "Warning";
				break;
			case "CRT2":
				return "Warning";
				break;
			case "CRT3":
				return "Warning";
				break;
			case "CADV":
				return "Warning";
				break;
			case "CADR":
				return "Warning";
				break;
			case "FAPR":
				return "Warning";
				break;
			case "SESG":
				return "Success";
				break;
			case "RQRJ":
				return "Error";
				break;
			case "INVP":
				return "Success";
				break;
			case "RDGK":
				return "Success";
				break;
			case "CADD":
				return "Success";
				break;
			case "FIRP":
				return "Success";
				break;
			case "ACKW":
				return "Success";
				break;
			case "REVW":
				return "Success";
				break;
			case "NRES":
				return "Warning";
				break;
			case "RQEX":
				return "Warning";
				break;
			default:
				return "None";

			}

		},

		taxiJobLogStatusState: function (Rqstat) {
			switch (Rqstat) {
			case "":
				return "None";
				break;
			case "INIT":
				return "None";
				break;
			case "PRCS":
				return "Warning";
				break;
			case "SUBT":
				return "Warning";
				break;
			case "RSUB":
				return "Warning";
				break;
			case "COMP":
				return "Success";
				break;
			case "CLSD":
				return "Error";
				break;
			case "HOLD":
				return "Error";
				break;
			case "APPR":
				return "Success";
				break;
			case "CEAN":
				return "Success";
				break;
			case "CNCL":
				return "Error";
				break;
			case "CLOS":
				return "Error";
				break;
			case "NOIV":
				return "Error";
				break;
			case "NSHW":
				return "Error";
				break;
			case "VNSH":
				return "Error";
				break;
			case "ACPT":
				return "Success";
				break;
			case "JOBL":
				return "Success";
				break;
			case "ETKT":
				return "Success";
				break;
			case "ETKR":
				return "Error";
				break;
			case "ETRE":
				return "Error";
				break;
			case "RETN":
				return "Error";
				break;
			case "CMPL":
				return "Success";
				break;
			case "REVS":
				return "Warning";
				break;
			case "DPAP":
				return "Success";
			case "DISP":
				return "Success";
			case "VCOM":
				return "Success";
			case "RECL":
				return "Error";
			case "DREL":
				return "Error";
			case "CRT1":
				return "Warning";
				break;
			case "CRT2":
				return "Warning";
				break;
			case "CRT3":
				return "Warning";
				break;
			case "CADV":
				return "Warning";
				break;
			case "CADR":
				return "Warning";
				break;
			case "FAPR":
				return "Warning";
				break;
			case "SESG":
				return "Success";
				break;
			case "RQRJ":
				return "Error";
				break;
			case "INVP":
				return "Success";
				break;
			case "RDGK":
				return "Success";
				break;
			case "CADD":
				return "Success";
				break;
			case "FIRP":
				return "Success";
				break;
			default:
				return "None";

			}

		},

		// timeUploadData 
		eticketStatusTxt: function (txt) {
			switch (txt) {
			case "01":
				return "Draft";
				break;
			case "02":
				return "Submitted";
				break;
			case "03":
				return "Approved";
				break;
			case "04":
				return "Rejected";
				break;
			}
		},

		// timeUploadData 
		eticketStatusState: function (state) {
			switch (state) {
			case "01":
				return "None";
				break;
			case "02":
				return "Warning";
				break;
			case "03":
				return "Success";
				break;
			case "04":
				return "Error";
				break;
			}
		},

		// Montly upload Status
		MontlyUStatus: function (state1) {
			switch (state1) {
			case "":
				return "Success";
				break;
			case "DSUB":
				return "Indication03";
				break;
			case "APPR":
				return "Success";
				break;
			case "SAVE":
				return "None";
				break;
			case "ATTH":
				return "Success";
				break;
			case "SUBT":
				return "Success";
				break;
			case "REJC":
				return "Error";
				break;
			case "REJT":
				return "Error";
				break;
			case "RECL":
				return "Error";
				break;
			case "ACKG":
				return "Information";
				break;
			default:
				return "None";
			}
		},

		Srvtyp: function (Srvtype) {
			if (Srvtype === " " || Srvtype === "") {
				return "No Selection";
			}
			return Srvtype;
		},

		formatWFGroup: function (sAgnType, sPosGrpTxt, sUsrRoleTxt) {
			switch (sAgnType) {
			case 'PSGRP':
				return sPosGrpTxt;
				break;
			case 'FROLE':
				return sUsrRoleTxt;
				break;
			default:
				return "";
			}
		},

		WFTimeFormatter: function (time) {
			if (time) {

				if (time.ms == 0) {
					return "";
				}

				var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "hh:mm:ss a"
				});
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;

				if (time === null || typeof time === "undefined")
					return "";

				if (!isNaN(time)) {
					var timestr = timeFormat.format(new Date(time + TZOffsetMs));
					return timestr;
				}

				var timestr = timeFormat.format(new Date(time.ms + TZOffsetMs));
				return timestr;
			}
		},

		formatRemainingMenge: function (Menge, InvociedMenge) {
			var iMenge, iInvociedMenge;

			var iMenge = parseFloat(Menge);
			var iInvociedMenge = parseFloat(InvociedMenge);

			return (iMenge - iInvociedMenge);

		},

		FormMandatory: function (sValue) {
			if (sValue === "") {
				return "Yes";
			} else {
				return "No";
			}
		},

		checkboxVisible: function (oValue) {
			if (oValue) {
				if (oValue.length === 0 || oValue.length === null) {
					var nValue = true;
				} else {
					var nValue = false;
				}
			} else {
				var nValue = false;
			}
			return nValue;
		},

		headerStatusValue: function (srvText, docNo) {
			if (srvText !== '' && docNo !== "") {
				var value = srvText + " - " + docNo;
			} else {
				var value = srvText;
			}
			return value;
		},
		headerStatusValueWithETicketVersion: function (srvText, docNo, eTicketVersion) {
			if (srvText !== '' && docNo !== "" && eTicketVersion && parseFloat(eTicketVersion) > 0) {
				var value = srvText + " - " + docNo + " (Version - " + eTicketVersion + ")";
			} else if (srvText !== '' && docNo !== "") {
				var value = srvText + " - " + docNo;
			} else {
				var value = srvText;
			}
			return value;
		},

		jobJogFormStatus: function (status) {
			var sReqStatusTxt = "";
			switch (status) {
			case "":
				sReqStatusTxt = "";
				break;

			case "INIT":
				sReqStatusTxt = "";
				break;

			case "SUBT":
				sReqStatusTxt = "Submitted";
				break;

			case "REJT":
				sReqStatusTxt = "Rejected";
				break;
			case "RECL":
				sReqStatusTxt = "Recalled";
				break;
			case "APPR":
				sReqStatusTxt = "Approved";
				break;
			case "SUBA":
				return "Submitted";
				break;
			case "FILL":
				return "Filled";
				break;
			case "INPR":
				return "In Progress";
				break;
			case "NATT":
				return "No Attachment";
				break;
			case "ATTH":
				return "Attached";
				break;
			case "CADU":
				return "CAD Updated";
				break;
			default:
				sReqStatusTxt = "";
			}

			return sReqStatusTxt;
		},

		jobJogFormStatusState: function (status) {

			switch (status) {
			case "SUBT":
				return sap.ui.core.ValueState.Success;
				break;
			case "REJT":
				return sap.ui.core.ValueState.Error;
				break;
			case "RECL":
				return sap.ui.core.ValueState.Error;
				break;
			case "APPR":
				return sap.ui.core.ValueState.Success
				break;
			case "SUBA":
				return sap.ui.core.ValueState.Success
				break;
			case "FILL":
				return sap.ui.core.ValueState.Success
				break;
			case "INPR":
				return sap.ui.core.ValueState.Warning
				break;
			case "NATT":
				return sap.ui.core.ValueState.None
				break;
			case "ATTH":
				return sap.ui.core.ValueState.Success
				break;
			case "CADU":
				return sap.ui.core.ValueState.Success
				break;
			default:
				return sap.ui.core.ValueState.None;
			}

		},
		jobJogFormStatusIcon: function (status) {

			switch (status) {
			case "SUBT":
				return "sap-icon://accept";
				break;
			case "REJT":
				return "sap-icon://decline";
				break;
			case "APPR":
				return "sap-icon://accept";
				break;
			case "SUBA":
				return "sap-icon://accept";
				break;
			case "FILL":
				return "sap-icon://accept";
				break;
			case "INPR":
				return "sap-icon://accept";
				break;
			case "NATT":
				return "sap-icon://decline";
				break;
			case "ATTH":
				return "sap-icon://accept";
				break;
			case "CADU":
				return "sap-icon://accept";
				break;
			default:
				return "";
			}

		},

		setTimeSheetWFBtnsVisible: function (status, taxiGL) {
			if (taxiGL === "X") {
				if (status === "SUBT") {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},

		jobLogType: function (FormType) {
			if (FormType === "Attachment") {
				return "Attachment";
			} else if (FormType === "EF") {
				return "eForm";
			} else {
				return "";
			}
		},

		// Workflow Status for E-Ticket	
		getWFStatusPosition: function (sPosition) {
			if (sPosition && sPosition.length > 0) {
				return parseInt(sPosition) - 1;
			} else {
				return 0;
			}
		},
		getWFStatusID: function (sPosition) {
			if (sPosition && sPosition.length > 0) {
				return parseInt(sPosition) + "";
			} else {
				return "0";
			}
		},
		/*getNodeState: function(sResponse, sRecievedDate, sResponseDate){
			if(sResponse && sResponse !== "" && ( sResponse !== "Rejected" )  && sRecievedDate && sResponseDate){
				
				if(sResponse === "Withdrawn" || sResponse === "Return to Initiator"|| sResponse === "Return to Last Agent"){
					return  [{state:sap.suite.ui.commons.ProcessFlowNodeState.Neutral, value: 20}];
				}else{
					return  [{state:sap.suite.ui.commons.ProcessFlowNodeState.Positive, value: 20}];
				}
				
				
				
			}else if(sResponse && sResponse !== ""&& ( sResponse === "Rejected" ) && sRecievedDate && sResponseDate ){
				// pending with the user
				return  [{state:sap.suite.ui.commons.ProcessFlowNodeState.Negative, value: 20}];
			}
			else if(sRecievedDate  && !sResponseDate){
				// pending with the user
				return  [{state:sap.suite.ui.commons.ProcessFlowNodeState.Critical, value: 20}];
			}
			else if(!sRecievedDate  && !sResponseDate ){

				return  [{state:sap.suite.ui.commons.ProcessFlowNodeState.Neutral, value: 20}];
			}
		},*/
		/*		getStateIcon: function(sResponse, sRecievedDate, sResponseDate){
					if(sResponse && sResponse !== "" && ( sResponse !== "Rejected" )  && sRecievedDate && sResponseDate){
						if(sResponse === "Withdrawn" || sResponse === "Return to Initiator" || sResponse === "Return to Last Agent"){
							return  "sap-icon://reset";
						}else{
							return  "sap-icon://accept";
						}
					}else if(sResponse && sResponse !== ""&& ( sResponse === "Rejected" )  && sRecievedDate && sResponseDate){
						// pending with the user
						return "sap-icon://decline";
					}
					else if(sRecievedDate  && !sResponseDate){
						// pending with the user
						return  "sap-icon://pending";
					}
					else if(!sRecievedDate  && !sResponseDate ){

						return  "sap-icon://employee";
					}
				},
				*/

		saudiStatusText: function (oSaflagText) {
			switch (oSaflagText) {
			case "F":
				return "Fullfilled";
				break;
			case "N":
				return "Not Fulfilled ";
				break;

			default:
				return "Not Available";
			}

		},

		saudiStatus: function (oSaflag) {
			switch (oSaflag) {
			case "F":
				return "Success";
				break;
			case "N":
				return "Information";
				break;
			default:
				return "None";
			}
		},

		eTicketCheckRadio: function (radioIndex) {
			var value = "";
			if (radioIndex === "1") {
				value = 0;
			} else if (radioIndex === "2") {
				value = 1;
			}

			return value;
		},

		getStatusColor: function (oResponse) {

			if (oResponse == "Negative") {
				return [{
					state: sap.suite.ui.commons.ProcessFlowNodeState.Negative,
					value: 20
				}];
			} else if (oResponse == "Positive") {
				return [{
					state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
					value: 20
				}];
			} else if (oResponse == "Yellow") {
				return [{
					state: sap.suite.ui.commons.ProcessFlowNodeState.Negative,
					value: 10
				}, {
					state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
					value: 10
				}];
			} else if (oResponse == "Critical") {
				return [{
					state: sap.suite.ui.commons.ProcessFlowNodeState.Critical,
					value: 20
				}];
			} else {
				return [{
					state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
					value: 20
				}];
			}

		},

		getStateIcon: function (oResponse) {

			if (oResponse === "Negative") {
				return "sap-icon://decline";

			} else if (oResponse === "Positive") {
				return "sap-icon://accept";

			} else if (oResponse === "Critical") {
				return "sap-icon://pending";

			} else if (oResponse === "Yellow") {
				return "sap-icon://arrow-top";

			} else {
				return "sap-icon://employee";
			}

		},

		getQuantityEditable: function (node) {

			/* for(var node in nodes){
           var oQtyVol = Number(nodes[node].QtyVol);
           if (oQtyVol > 0){
	         return false;
             break;
           }else{
	         return true;
           }
         }*/
			var oQtyVol = Number(node);
			if (oQtyVol > 0) {
				return false;

			} else {
				return true;
			}
		},

		getRemarksLabel: function (Rowtext) {
			var getData = Rowtext.match(/Re-submitted/g);
			if (getData !== null) {
				return "Re-Submitted Remarks";
			} else {
				return '';
			}
		},

		onQuanChangeLabel: function (oType) {
			var rType = "Quantity";
			if (typeof oType !== "undefined") {
				if (oType.match(/Transportation/g) !== null) {
					rType = "Chargeable Distance (KM Per Contract)";
				}
			}

			return rType;
		},
		formatTime: function (sTime) {
			var result = "";
			if (sTime) {
				var oTimeFormat = new sap.ui.model.odata.type.Time({
					pattern: 'HH:mm:ss'
				});

				result = oTimeFormat.formatValue(sTime, "string");
			}
			return result;
		},

		toStrNum: function (sNum) {
			return parseFloat(sNum).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		},

		pdfBtnVisibility: function (rqstat) {

			var aArrState = ["PRCS", "JOBL", "ABRS", "ABSV", "BLIN", "CADD", "CADR", "CADV", "CCIN", "CEAN", "CEUN", "COES", "COMP", "CRT1",
				"CRT2", "CRT3", "CRT4", "CWVA", "OSDE", "DISP", "ETKF", "ETKR", "ETKT", "ETNS", "ETRE", "FAPR", "FIRP", "HDSO", "HOLD", "INVG",
				"INVP", "NOIV", "NSHW", "RLIN", "SESG", "SESC", "WFER", "WFIS", "DERW"
			];

			var afilterArr = aArrState.filter(item => {
				return rqstat === item
			});

			if (afilterArr.length > 0) {
				return true;
			} else {
				return false;
			}
			/*if (rqstat === 'ETKT'|| rqstat === "CRT1" || rqstat === "CRT2"|| rqstat === "CRT3"|| rqstat === "CADV"|| rqstat === "CADR"|| rqstat === "FAPR" ||
			    rqstat === "SESG"|| rqstat === "RQRJ"|| rqstat === "ARJC" || rqstat === "INVP" || rqstat === "RDGK" || rqstat === "CADD" ||  rqstat ==="FIRP"){
				return true;
			}else {
				return false;
			}*/

		},

		formatToRoundNumber: function (sValue) {
			var iNumber = "";
			if (sValue) {
				var iNumber = sValue.replace(/^0+/, '');
			}
			return iNumber;
		},

		totalMealsCalculation: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					var Breakfast = 0;
					var Lunch = 0;
					var Dinner = 0;
					var MidNight = 0;

					for (var i = 0; i < cost.length; i++) {
						Breakfast += parseFloat(cost[i].Breakfast)
						Lunch += parseFloat(cost[i].Lunch)
						Dinner += parseFloat(cost[i].Dinner)
						MidNight += parseFloat(cost[i].MidNight)
					}
					total = Breakfast + Lunch + Dinner + MidNight
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		totalMealsMandaysCalculation: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					var Breakfast = 0;
					var Lunch = 0;
					var Dinner = 0;
					var MidNight = 0;

					for (var i = 0; i < cost.length; i++) {
						Breakfast += parseFloat(cost[i].Breakfast)
						Lunch += parseFloat(cost[i].Lunch)
						Dinner += parseFloat(cost[i].Dinner)
						MidNight += parseFloat(cost[i].MidNight)
					}
					total = Breakfast + Lunch + Dinner + MidNight;
					total = (total / 3).toFixed(2);
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		totalMealsManMonthCalculation: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var ManMonth = 0;
					var total = 0;
					var Breakfast = 0;
					var Lunch = 0;
					var Dinner = 0;
					var MidNight = 0;

					for (var i = 0; i < cost.length; i++) {
						Breakfast += parseFloat(cost[i].Breakfast)
						Lunch += parseFloat(cost[i].Lunch)
						Dinner += parseFloat(cost[i].Dinner)
						MidNight += parseFloat(cost[i].MidNight)
					}
					total = Breakfast + Lunch + Dinner + MidNight;
					ManMonth = (total / 3).toFixed(2);
					ManMonth = (ManMonth / 30.42).toFixed(2);
					ManMonth = ManMonth.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return ManMonth;
				}
			}
		},

		totalBFCalculation_S: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						total += parseFloat(cost[i].Breakfast)
					}
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		totalBFCalculation_J: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						if (cost[i].MealCategory === "J") {
							total += parseFloat(cost[i].Breakfast)
						}
					}
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		totalLunchCalculation_S: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						total += parseFloat(cost[i].Lunch)
					}
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		totalLunchCalculation_J: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						if (cost[i].MealCategory === "J") {
							total += parseFloat(cost[i].Lunch)
						}
					}
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		totalDinnerCalculation_S: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						total += parseFloat(cost[i].Dinner)
					}
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		totalDinnerCalculation_J: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						if (cost[i].MealCategory === "J") {
							total += parseFloat(cost[i].Dinner)
						}
					}
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		totalMidSnackCalculation_S: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						total += parseFloat(cost[i].MidNight)
					}
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		totalMidSnackCalculation_J: function (cost) {
			if (cost) {
				if (cost.length > 0) {
					var total = 0;
					for (var i = 0; i < cost.length; i++) {
						if (cost[i].MealCategory === "J") {
							total += parseFloat(cost[i].MidNight)
						}
					}
					total = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
					return total;
				}
			}
		},

		retInboxStatusCode: function (Rqtype, status) {
			// CAD Verifier // Initiator

			if (Rqtype === "10") {
				if (status === "Inbox") {
					return 'INIT' + ";" + 'ACPT' + ";" + 'HOLD' + ";" + 'RECL' + ";" + 'RETN' + ";" + 'RQEX' + ";" + 'NRES';
				} else if (status === "Submitted") {
					return 'SUBT';
				} else if (status === "Accepted") {
					return 'ACPT';
				} else if (status === "eTicket") {
					return 'CRT1' + ";" + 'CRT2' + ";" + 'CRT3' + ";" + 'CRT4' + ";" + 'ETKT' + ";" + 'CADV' + ";" + 'CADR' + ";" + 'FAPR' + ";" +
						'SESG' + ";" + 'INVG' + ";" + 'INVP' + ";" + 'RDGK' + ";" + 'CADD' + ";" + 'FIRP';
				} else if (status === "Rejected") {
					return 'CLSD';
				}
				// CAD Reviewer
			} else if (Rqtype === "11") {
				if (status === "Inbox") {
					return 'SUBT' + ";" + 'REVW';
				} else if (status === "Accepted") {
					return 'ACPT';
				} else if (status === "Rejected") {
					return 'CLSD';
				} else if (status === "eTicket") {
					return 'CRT1' + ";" + 'CRT2' + ";" + 'CRT3' + ";" + 'CRT4' + ";" + 'ETKT' + ";" + 'CADV' + ";" + 'CADR' + ";" + 'FAPR' + ";" +
						'SESG' + ";" + 'INVG' + ";" + 'INVP' + ";" + 'RDGK' + ";" + 'CADD' + ";" + 'FIRP';
				}
			}

		}

		/*		
				eTicketValueCheck :  function(value){
					
					var oValue = "";
					if (value === "X"){
						oValue = 'EtktValue'
					}
					
					return oValue;
					
				}*/

	};

});