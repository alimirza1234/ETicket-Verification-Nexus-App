sap.ui.define([
	"NX_HomePage/ZDWO_NX_HOMEPAGE/test/unit/controller/Root.controller"
], function () {
	"use strict";
});